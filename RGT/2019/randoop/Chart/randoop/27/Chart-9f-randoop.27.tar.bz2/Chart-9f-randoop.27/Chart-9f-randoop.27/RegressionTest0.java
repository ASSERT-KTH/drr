import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((int) 'a', true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) (short) 0, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        int int0 = org.jfree.data.time.SerialDate.MAXIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9999 + "'", int0 == 9999);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((int) '#');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        java.lang.Comparable comparable0 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries(comparable0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4', (int) (byte) 10, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((int) (short) -1, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_FIRST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        int int0 = org.jfree.data.time.SerialDate.MONDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        java.lang.String str3 = day2.toString();
        java.util.Calendar calendar4 = null;
        try {
            day2.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "9-January-1900" + "'", str3.equals("9-January-1900"));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_UPPER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2958465 + "'", int0 == 2958465);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_BOTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod0 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod0, (double) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        int int0 = org.jfree.data.time.SerialDate.MINIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1900 + "'", int0 == 1900);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate2);
        try {
            org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (short) 100, (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = timeSeries1.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (short) 0, (int) (byte) 1, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = null;
        try {
            java.lang.Number number3 = timeSeries1.getValue(regularTimePeriod2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate3);
        java.lang.String str5 = day4.toString();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day4);
        java.util.Calendar calendar7 = null;
        try {
            day4.peg(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "9-January-1900" + "'", str5.equals("9-January-1900"));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass3 = spreadsheetDate2.getClass();
        try {
            org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) '#', (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(2);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(0L);
        boolean boolean5 = fixedMillisecond3.equals((java.lang.Object) 100.0d);
        try {
            timeSeries1.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3, (java.lang.Number) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        java.text.DateFormatSymbols dateFormatSymbols0 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        org.junit.Assert.assertNotNull(dateFormatSymbols0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = spreadsheetDate4.getClass();
        boolean boolean6 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SerialDate serialDate7 = null;
        try {
            boolean boolean8 = spreadsheetDate4.isOnOrAfter(serialDate7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod0 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod0, (java.lang.Number) 1.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        int int0 = org.jfree.data.time.SerialDate.TUESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(9);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Nearest" + "'", str1.equals("Nearest"));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = timeSeries1.getDataItem((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        timeSeries1.clear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = null;
        try {
            timeSeries1.add(timeSeriesDataItem3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test041() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test041");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560192906752L + "'", long1 == 1560192906752L);
//    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        timeSeries1.clear();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.getDataItem((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate5 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass8 = spreadsheetDate7.getClass();
        java.util.Date date9 = null;
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date9, timeZone10);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate4, (java.lang.Class) wildcardClass8);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getFirstMillisecond();
        int int15 = year13.getYear();
        int int16 = year13.getYear();
        try {
            timeSeries12.update((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Calendar calendar1 = null;
        try {
            day0.peg(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        int int0 = org.jfree.data.time.SerialDate.FOURTH_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        long long2 = year1.getFirstMillisecond();
        int int3 = year1.getYear();
        try {
            org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(2958465, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(12, false);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "December" + "'", str2.equals("December"));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(8, 1900, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((int) (byte) 0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addMonths((int) (byte) -1, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) '#');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        long long4 = year3.getFirstMillisecond();
        int int5 = year3.getYear();
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2, (org.jfree.data.time.RegularTimePeriod) year3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        long long9 = fixedMillisecond8.getMiddleMillisecond();
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, 0.0d, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate3);
        java.lang.String str5 = day4.toString();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day4);
        int int7 = timeSeries1.getItemCount();
        try {
            timeSeries1.delete(2958465, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "9-January-1900" + "'", str5.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        long long4 = year3.getFirstMillisecond();
        int int5 = year3.getYear();
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2, (org.jfree.data.time.RegularTimePeriod) year3);
        java.util.Calendar calendar7 = null;
        try {
            long long8 = year3.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(timeSeries6);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(9);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        long long4 = year3.getFirstMillisecond();
        int int5 = year3.getYear();
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2, (org.jfree.data.time.RegularTimePeriod) year3);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate10);
        java.lang.String str12 = day11.toString();
        timeSeries8.delete((org.jfree.data.time.RegularTimePeriod) day11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day11.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day11, (java.lang.Number) 1L);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getFirstMillisecond();
        long long19 = year17.getFirstMillisecond();
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year17, (java.lang.Number) 10.0f);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "9-January-1900" + "'", str12.equals("9-January-1900"));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1546329600000L + "'", long18 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1546329600000L + "'", long19 == 1546329600000L);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate5 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass8 = spreadsheetDate7.getClass();
        java.util.Date date9 = null;
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date9, timeZone10);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate4, (java.lang.Class) wildcardClass8);
        java.lang.Comparable comparable13 = timeSeries12.getKey();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate17);
        java.lang.String str19 = day18.toString();
        timeSeries15.delete((org.jfree.data.time.RegularTimePeriod) day18);
        int int21 = day18.getDayOfMonth();
        long long22 = day18.getSerialIndex();
        int int23 = day18.getDayOfMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries12.getDataItem((org.jfree.data.time.RegularTimePeriod) day18);
        java.util.Calendar calendar25 = null;
        try {
            long long26 = day18.getLastMillisecond(calendar25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(comparable13);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "9-January-1900" + "'", str19.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 9 + "'", int21 == 9);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 10L + "'", long22 == 10L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 9 + "'", int23 == 9);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(2019);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Month month1 = new org.jfree.data.time.Month(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        int int0 = org.jfree.data.time.SerialDate.SECOND_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        long long4 = year3.getFirstMillisecond();
        int int5 = year3.getYear();
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2, (org.jfree.data.time.RegularTimePeriod) year3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond7.next();
        timeSeries6.delete(regularTimePeriod8);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = timeSeries6.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(9999);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2019);
        try {
            int int3 = spreadsheetDate1.compareTo((java.lang.Object) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Integer cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear((int) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate5 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass8 = spreadsheetDate7.getClass();
        java.util.Date date9 = null;
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date9, timeZone10);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate4, (java.lang.Class) wildcardClass8);
        java.lang.Comparable comparable13 = timeSeries12.getKey();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate17);
        java.lang.String str19 = day18.toString();
        timeSeries15.delete((org.jfree.data.time.RegularTimePeriod) day18);
        int int21 = day18.getDayOfMonth();
        long long22 = day18.getSerialIndex();
        int int23 = day18.getDayOfMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries12.getDataItem((org.jfree.data.time.RegularTimePeriod) day18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond(0L);
        boolean boolean28 = fixedMillisecond26.equals((java.lang.Object) 100.0d);
        int int30 = fixedMillisecond26.compareTo((java.lang.Object) 1);
        long long31 = fixedMillisecond26.getMiddleMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = fixedMillisecond32.next();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, regularTimePeriod33);
        try {
            timeSeries12.removeAgedItems((long) 5, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(comparable13);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "9-January-1900" + "'", str19.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 9 + "'", int21 == 9);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 10L + "'", long22 == 10L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 9 + "'", int23 == 9);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(timeSeries34);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        int int0 = org.jfree.data.time.SerialDate.FRIDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate3);
        java.lang.String str5 = day4.toString();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        boolean boolean10 = fixedMillisecond8.equals((java.lang.Object) 100.0d);
        int int12 = fixedMillisecond8.compareTo((java.lang.Object) 1);
        long long13 = fixedMillisecond8.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (double) 9999);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        boolean boolean17 = timeSeriesDataItem15.equals((java.lang.Object) year16);
        try {
            timeSeries1.add(timeSeriesDataItem15, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "9-January-1900" + "'", str5.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = spreadsheetDate4.getClass();
        boolean boolean6 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate9 = spreadsheetDate4.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass12 = spreadsheetDate11.getClass();
        boolean boolean13 = spreadsheetDate4.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate11);
        int int14 = spreadsheetDate11.getYYYY();
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1900 + "'", int14 == 1900);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        long long2 = fixedMillisecond1.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("2019");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        int int0 = org.jfree.data.time.SerialDate.THIRD_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        long long4 = year3.getFirstMillisecond();
        int int5 = year3.getYear();
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2, (org.jfree.data.time.RegularTimePeriod) year3);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries6.addChangeListener(seriesChangeListener7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getSerialIndex();
        java.lang.Number number11 = null;
        try {
            timeSeries6.update((org.jfree.data.time.RegularTimePeriod) year9, number11);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate5 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass8 = spreadsheetDate7.getClass();
        java.util.Date date9 = null;
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date9, timeZone10);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate4, (java.lang.Class) wildcardClass8);
        java.lang.Comparable comparable13 = timeSeries12.getKey();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate17);
        java.lang.String str19 = day18.toString();
        timeSeries15.delete((org.jfree.data.time.RegularTimePeriod) day18);
        int int21 = day18.getDayOfMonth();
        long long22 = day18.getSerialIndex();
        int int23 = day18.getDayOfMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries12.getDataItem((org.jfree.data.time.RegularTimePeriod) day18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond(0L);
        boolean boolean28 = fixedMillisecond26.equals((java.lang.Object) 100.0d);
        int int30 = fixedMillisecond26.compareTo((java.lang.Object) 1);
        long long31 = fixedMillisecond26.getMiddleMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = fixedMillisecond32.next();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, regularTimePeriod33);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = null;
        try {
            timeSeries34.update(regularTimePeriod35, (java.lang.Number) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(comparable13);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "9-January-1900" + "'", str19.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 9 + "'", int21 == 9);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 10L + "'", long22 == 10L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 9 + "'", int23 == 9);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(timeSeries34);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass6 = spreadsheetDate5.getClass();
        boolean boolean7 = spreadsheetDate2.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears((int) '4', (org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass14 = spreadsheetDate13.getClass();
        boolean boolean15 = spreadsheetDate10.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate21 = spreadsheetDate17.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate20);
        boolean boolean22 = spreadsheetDate13.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate17);
        boolean boolean23 = spreadsheetDate5.isOn((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) 'a');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate3);
        java.lang.String str5 = day4.toString();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day4);
        try {
            timeSeries1.update((-1), (java.lang.Number) 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "9-January-1900" + "'", str5.equals("9-January-1900"));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        int int0 = org.jfree.data.time.SerialDate.SUNDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        int int5 = fixedMillisecond1.compareTo((java.lang.Object) (-1L));
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate11);
        java.lang.String str13 = day12.toString();
        timeSeries9.delete((org.jfree.data.time.RegularTimePeriod) day12);
        int int15 = day12.getDayOfMonth();
        long long16 = day12.getSerialIndex();
        int int17 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) day12);
        timeSeries7.setMaximumItemAge((long) '4');
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timeSeries7.removePropertyChangeListener(propertyChangeListener20);
        boolean boolean22 = fixedMillisecond1.equals((java.lang.Object) propertyChangeListener20);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "9-January-1900" + "'", str13.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 9 + "'", int15 == 9);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 10L + "'", long16 == 10L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        int int0 = org.jfree.data.time.SerialDate.FOLLOWING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((int) (short) 0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Nearest" + "'", str1.equals("Nearest"));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        int int0 = org.jfree.data.time.SerialDate.THURSDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass3 = spreadsheetDate2.getClass();
        try {
            org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (byte) 10, (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        timeSeries1.clear();
        java.lang.Comparable comparable3 = timeSeries1.getKey();
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(0L);
        boolean boolean8 = fixedMillisecond6.equals((java.lang.Object) 100.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = fixedMillisecond6.previous();
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 3);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + 'a' + "'", comparable3.equals('a'));
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 'a' + "'", comparable4.equals('a'));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate5 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass8 = spreadsheetDate7.getClass();
        java.util.Date date9 = null;
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date9, timeZone10);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate4, (java.lang.Class) wildcardClass8);
        java.lang.Comparable comparable13 = timeSeries12.getKey();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate17);
        java.lang.String str19 = day18.toString();
        timeSeries15.delete((org.jfree.data.time.RegularTimePeriod) day18);
        int int21 = day18.getDayOfMonth();
        long long22 = day18.getSerialIndex();
        int int23 = day18.getDayOfMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries12.getDataItem((org.jfree.data.time.RegularTimePeriod) day18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond(0L);
        boolean boolean28 = fixedMillisecond26.equals((java.lang.Object) 100.0d);
        int int30 = fixedMillisecond26.compareTo((java.lang.Object) 1);
        long long31 = fixedMillisecond26.getMiddleMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = fixedMillisecond32.next();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, regularTimePeriod33);
        timeSeries12.setNotify(false);
        try {
            java.lang.Number number38 = timeSeries12.getValue((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(comparable13);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "9-January-1900" + "'", str19.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 9 + "'", int21 == 9);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 10L + "'", long22 == 10L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 9 + "'", int23 == 9);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(timeSeries34);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        java.lang.String str2 = year1.toString();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (byte) 10, year1);
        java.util.Calendar calendar4 = null;
        try {
            long long5 = month3.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        long long2 = year0.getFirstMillisecond();
        java.util.Calendar calendar3 = null;
        try {
            year0.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        java.lang.String str2 = year1.toString();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (byte) 10, year1);
        java.util.Calendar calendar4 = null;
        try {
            long long5 = month3.getMiddleMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        int int0 = org.jfree.data.time.SerialDate.LAST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (byte) 10);
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year0.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass6 = spreadsheetDate5.getClass();
        boolean boolean7 = spreadsheetDate2.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate10 = spreadsheetDate5.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate9);
        try {
            org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) '#', (org.jfree.data.time.SerialDate) spreadsheetDate5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(serialDate10);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(2958465);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate3);
        java.lang.String str5 = day4.toString();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day4);
        int int7 = day4.getDayOfMonth();
        long long8 = day4.getSerialIndex();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = day4.getFirstMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "9-January-1900" + "'", str5.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9 + "'", int7 == 9);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate5 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass8 = spreadsheetDate7.getClass();
        java.util.Date date9 = null;
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date9, timeZone10);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate4, (java.lang.Class) wildcardClass8);
        java.lang.Comparable comparable13 = timeSeries12.getKey();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate17);
        java.lang.String str19 = day18.toString();
        timeSeries15.delete((org.jfree.data.time.RegularTimePeriod) day18);
        int int21 = day18.getDayOfMonth();
        long long22 = day18.getSerialIndex();
        int int23 = day18.getDayOfMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries12.getDataItem((org.jfree.data.time.RegularTimePeriod) day18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond(0L);
        boolean boolean28 = fixedMillisecond26.equals((java.lang.Object) 100.0d);
        int int30 = fixedMillisecond26.compareTo((java.lang.Object) 1);
        long long31 = fixedMillisecond26.getMiddleMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = fixedMillisecond32.next();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, regularTimePeriod33);
        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond(0L);
        boolean boolean38 = fixedMillisecond36.equals((java.lang.Object) 100.0d);
        timeSeries12.setKey((java.lang.Comparable) boolean38);
        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries12.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond41);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = null;
        try {
            timeSeries12.add(regularTimePeriod43, (double) 100L, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(comparable13);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "9-January-1900" + "'", str19.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 9 + "'", int21 == 9);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 10L + "'", long22 == 10L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 9 + "'", int23 == 9);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem42);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate5 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass8 = spreadsheetDate7.getClass();
        java.util.Date date9 = null;
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date9, timeZone10);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate4, (java.lang.Class) wildcardClass8);
        java.lang.Comparable comparable13 = timeSeries12.getKey();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate17);
        java.lang.String str19 = day18.toString();
        timeSeries15.delete((org.jfree.data.time.RegularTimePeriod) day18);
        int int21 = day18.getDayOfMonth();
        long long22 = day18.getSerialIndex();
        int int23 = day18.getDayOfMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries12.getDataItem((org.jfree.data.time.RegularTimePeriod) day18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond(0L);
        boolean boolean28 = fixedMillisecond26.equals((java.lang.Object) 100.0d);
        int int30 = fixedMillisecond26.compareTo((java.lang.Object) 1);
        long long31 = fixedMillisecond26.getMiddleMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = fixedMillisecond32.next();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, regularTimePeriod33);
        try {
            java.lang.Number number36 = timeSeries12.getValue(9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9999, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(comparable13);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "9-January-1900" + "'", str19.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 9 + "'", int21 == 9);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 10L + "'", long22 == 10L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 9 + "'", int23 == 9);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(timeSeries34);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.lang.String str3 = year2.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (byte) 10);
        boolean boolean6 = year0.equals((java.lang.Object) timeSeriesDataItem5);
        java.util.Calendar calendar7 = null;
        try {
            year0.peg(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(11, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30 + "'", int2 == 30);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        int int2 = timeSeries1.getMaximumItemCount();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        java.lang.Comparable comparable0 = null;
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass3 = spreadsheetDate2.getClass();
        java.util.Date date4 = null;
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date4, timeZone5);
        try {
            org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries(comparable0, (java.lang.Class) wildcardClass3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNull(regularTimePeriod6);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        java.lang.String[] strArray0 = org.jfree.data.time.SerialDate.getMonths();
        org.junit.Assert.assertNotNull(strArray0);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate3);
        java.lang.String str5 = day4.toString();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day4);
        long long7 = timeSeries1.getMaximumItemAge();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "9-January-1900" + "'", str5.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass6 = spreadsheetDate5.getClass();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str1, "", "9-January-1900", (java.lang.Class) wildcardClass6);
        timeSeries7.setDomainDescription("hi!");
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries7.getDataItem((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate5 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass8 = spreadsheetDate7.getClass();
        java.util.Date date9 = null;
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date9, timeZone10);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate4, (java.lang.Class) wildcardClass8);
        java.lang.Comparable comparable13 = timeSeries12.getKey();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate17);
        java.lang.String str19 = day18.toString();
        timeSeries15.delete((org.jfree.data.time.RegularTimePeriod) day18);
        int int21 = day18.getDayOfMonth();
        long long22 = day18.getSerialIndex();
        int int23 = day18.getDayOfMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries12.getDataItem((org.jfree.data.time.RegularTimePeriod) day18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = fixedMillisecond25.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries12.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25);
        java.util.Calendar calendar28 = null;
        fixedMillisecond25.peg(calendar28);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(comparable13);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "9-January-1900" + "'", str19.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 9 + "'", int21 == 9);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 10L + "'", long22 == 10L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 9 + "'", int23 == 9);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNull(timeSeriesDataItem27);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(8);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(9);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("SerialDate.weekInMonthToString(): invalid code.");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        java.util.TimeZone timeZone3 = null;
        try {
            org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date1, timeZone3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        java.util.TimeZone timeZone2 = null;
        try {
            org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date1, timeZone2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("Nearest");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        long long4 = year3.getFirstMillisecond();
        int int5 = year3.getYear();
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2, (org.jfree.data.time.RegularTimePeriod) year3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond7.next();
        timeSeries6.delete(regularTimePeriod8);
        try {
            timeSeries6.delete(1900, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate5 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass8 = spreadsheetDate7.getClass();
        java.util.Date date9 = null;
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date9, timeZone10);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate4, (java.lang.Class) wildcardClass8);
        java.lang.Comparable comparable13 = timeSeries12.getKey();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate17);
        java.lang.String str19 = day18.toString();
        timeSeries15.delete((org.jfree.data.time.RegularTimePeriod) day18);
        int int21 = day18.getDayOfMonth();
        long long22 = day18.getSerialIndex();
        int int23 = day18.getDayOfMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries12.getDataItem((org.jfree.data.time.RegularTimePeriod) day18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond(0L);
        boolean boolean28 = fixedMillisecond26.equals((java.lang.Object) 100.0d);
        int int30 = fixedMillisecond26.compareTo((java.lang.Object) 1);
        long long31 = fixedMillisecond26.getMiddleMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = fixedMillisecond32.next();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, regularTimePeriod33);
        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond(0L);
        boolean boolean38 = fixedMillisecond36.equals((java.lang.Object) 100.0d);
        timeSeries12.setKey((java.lang.Comparable) boolean38);
        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries12.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond41);
        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate46);
        java.lang.String str48 = day47.toString();
        timeSeries44.delete((org.jfree.data.time.RegularTimePeriod) day47);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = day47.previous();
        java.util.Date date51 = day47.getStart();
        org.jfree.data.time.Month month52 = new org.jfree.data.time.Month(date51);
        try {
            timeSeries12.add((org.jfree.data.time.RegularTimePeriod) month52, (double) 2019L, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.SpreadsheetDate.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(comparable13);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "9-January-1900" + "'", str19.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 9 + "'", int21 == 9);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 10L + "'", long22 == 10L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 9 + "'", int23 == 9);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem42);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "9-January-1900" + "'", str48.equals("9-January-1900"));
        org.junit.Assert.assertNotNull(regularTimePeriod50);
        org.junit.Assert.assertNotNull(date51);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        long long4 = year3.getFirstMillisecond();
        int int5 = year3.getYear();
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2, (org.jfree.data.time.RegularTimePeriod) year3);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries6.addChangeListener(seriesChangeListener7);
        boolean boolean9 = timeSeries6.getNotify();
        try {
            timeSeries6.delete((int) (short) 100, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate3);
        java.lang.String str5 = day4.toString();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day4.previous();
        java.util.Date date8 = day4.getStart();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date8);
        long long10 = month9.getSerialIndex();
        java.util.Calendar calendar11 = null;
        try {
            long long12 = month9.getLastMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "9-January-1900" + "'", str5.equals("9-January-1900"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 22801L + "'", long10 == 22801L);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths(false);
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addMonths(5, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        java.util.TimeZone timeZone2 = null;
        try {
            org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date1, timeZone2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate3);
        java.lang.String str5 = day4.toString();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day4);
        int int7 = timeSeries1.getItemCount();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(0L);
        boolean boolean11 = fixedMillisecond9.equals((java.lang.Object) 100.0d);
        int int13 = fixedMillisecond9.compareTo((java.lang.Object) 1);
        long long14 = fixedMillisecond9.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (double) 9999);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        boolean boolean18 = timeSeriesDataItem16.equals((java.lang.Object) year17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = timeSeriesDataItem16.getPeriod();
        try {
            timeSeries1.add(timeSeriesDataItem16);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "9-January-1900" + "'", str5.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(10, 2, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate5 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass8 = spreadsheetDate7.getClass();
        java.util.Date date9 = null;
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date9, timeZone10);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate4, (java.lang.Class) wildcardClass8);
        java.lang.Comparable comparable13 = timeSeries12.getKey();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate17);
        java.lang.String str19 = day18.toString();
        timeSeries15.delete((org.jfree.data.time.RegularTimePeriod) day18);
        int int21 = day18.getDayOfMonth();
        long long22 = day18.getSerialIndex();
        int int23 = day18.getDayOfMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries12.getDataItem((org.jfree.data.time.RegularTimePeriod) day18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond(0L);
        boolean boolean28 = fixedMillisecond26.equals((java.lang.Object) 100.0d);
        int int30 = fixedMillisecond26.compareTo((java.lang.Object) 1);
        long long31 = fixedMillisecond26.getMiddleMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = fixedMillisecond32.next();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, regularTimePeriod33);
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
        long long36 = year35.getFirstMillisecond();
        int int37 = year35.getYear();
        int int38 = year35.getYear();
        try {
            timeSeries12.update((org.jfree.data.time.RegularTimePeriod) year35, (java.lang.Number) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(comparable13);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "9-January-1900" + "'", str19.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 9 + "'", int21 == 9);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 10L + "'", long22 == 10L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 9 + "'", int23 == 9);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1546329600000L + "'", long36 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 2019 + "'", int37 == 2019);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2019 + "'", int38 == 2019);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        long long4 = year3.getFirstMillisecond();
        int int5 = year3.getYear();
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2, (org.jfree.data.time.RegularTimePeriod) year3);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate10);
        java.lang.String str12 = day11.toString();
        timeSeries8.delete((org.jfree.data.time.RegularTimePeriod) day11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day11.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day11, (java.lang.Number) 1L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day11.next();
        org.jfree.data.time.SerialDate serialDate18 = day11.getSerialDate();
        int int19 = day11.getDayOfMonth();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "9-January-1900" + "'", str12.equals("9-January-1900"));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 9 + "'", int19 == 9);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(5);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Thursday" + "'", str1.equals("Thursday"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate5);
        java.lang.String str7 = day6.toString();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) day6);
        int int9 = day6.getDayOfMonth();
        long long10 = day6.getSerialIndex();
        int int11 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) day6);
        java.util.Calendar calendar12 = null;
        try {
            day6.peg(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "9-January-1900" + "'", str7.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        long long4 = year3.getFirstMillisecond();
        int int5 = year3.getYear();
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2, (org.jfree.data.time.RegularTimePeriod) year3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond7.next();
        timeSeries6.delete(regularTimePeriod8);
        try {
            java.lang.Number number11 = timeSeries6.getValue(12);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 12, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate3);
        java.lang.String str5 = day4.toString();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day4.previous();
        java.lang.String str8 = day4.toString();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getFirstMillisecond();
        int int14 = year12.getYear();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (org.jfree.data.time.RegularTimePeriod) year12);
        int int16 = day4.compareTo((java.lang.Object) timeSeries10);
        int int17 = day4.getDayOfMonth();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "9-January-1900" + "'", str5.equals("9-January-1900"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "9-January-1900" + "'", str8.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 9 + "'", int17 == 9);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        long long4 = year3.getFirstMillisecond();
        int int5 = year3.getYear();
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2, (org.jfree.data.time.RegularTimePeriod) year3);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate10);
        java.lang.String str12 = day11.toString();
        timeSeries8.delete((org.jfree.data.time.RegularTimePeriod) day11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day11.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day11, (java.lang.Number) 1L);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate20);
        java.lang.String str22 = day21.toString();
        timeSeries18.delete((org.jfree.data.time.RegularTimePeriod) day21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day21.previous();
        java.lang.String str25 = day21.toString();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate29);
        java.lang.String str31 = day30.toString();
        timeSeries27.delete((org.jfree.data.time.RegularTimePeriod) day30);
        int int33 = day30.getDayOfMonth();
        long long34 = day30.getSerialIndex();
        int int35 = day30.getDayOfMonth();
        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) day21, (org.jfree.data.time.RegularTimePeriod) day30);
        java.lang.Object obj37 = null;
        int int38 = day21.compareTo(obj37);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "9-January-1900" + "'", str12.equals("9-January-1900"));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "9-January-1900" + "'", str22.equals("9-January-1900"));
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "9-January-1900" + "'", str25.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "9-January-1900" + "'", str31.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 9 + "'", int33 == 9);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 10L + "'", long34 == 10L);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 9 + "'", int35 == 9);
        org.junit.Assert.assertNotNull(timeSeries36);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_NONE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate3);
        java.lang.String str5 = day4.toString();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day4.previous();
        java.lang.String str8 = day4.toString();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getFirstMillisecond();
        int int14 = year12.getYear();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (org.jfree.data.time.RegularTimePeriod) year12);
        int int16 = day4.compareTo((java.lang.Object) timeSeries10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(0L);
        boolean boolean20 = fixedMillisecond18.equals((java.lang.Object) 100.0d);
        int int22 = fixedMillisecond18.compareTo((java.lang.Object) 1);
        long long23 = fixedMillisecond18.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (double) 9999);
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        boolean boolean27 = timeSeriesDataItem25.equals((java.lang.Object) year26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = timeSeriesDataItem25.getPeriod();
        try {
            timeSeries10.add(timeSeriesDataItem25, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "9-January-1900" + "'", str5.equals("9-January-1900"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "9-January-1900" + "'", str8.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths(true);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate3);
        java.lang.String str5 = day4.toString();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day4.previous();
        org.jfree.data.time.SerialDate serialDate8 = day4.getSerialDate();
        int int9 = day4.getDayOfMonth();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "9-January-1900" + "'", str5.equals("9-January-1900"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate3);
        java.lang.String str5 = day4.toString();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day4);
        int int7 = timeSeries1.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getFirstMillisecond();
        int int13 = year11.getYear();
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries9.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (org.jfree.data.time.RegularTimePeriod) year11);
        boolean boolean15 = timeSeries1.equals((java.lang.Object) year11);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = timeSeries1.getTimePeriod(9);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "9-January-1900" + "'", str5.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1546329600000L + "'", long12 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate5 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass8 = spreadsheetDate7.getClass();
        java.util.Date date9 = null;
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date9, timeZone10);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate4, (java.lang.Class) wildcardClass8);
        java.lang.Comparable comparable13 = timeSeries12.getKey();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate17);
        java.lang.String str19 = day18.toString();
        timeSeries15.delete((org.jfree.data.time.RegularTimePeriod) day18);
        int int21 = day18.getDayOfMonth();
        long long22 = day18.getSerialIndex();
        int int23 = day18.getDayOfMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries12.getDataItem((org.jfree.data.time.RegularTimePeriod) day18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond(0L);
        boolean boolean28 = fixedMillisecond26.equals((java.lang.Object) 100.0d);
        int int30 = fixedMillisecond26.compareTo((java.lang.Object) 1);
        long long31 = fixedMillisecond26.getMiddleMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = fixedMillisecond32.next();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, regularTimePeriod33);
        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond(0L);
        boolean boolean38 = fixedMillisecond36.equals((java.lang.Object) 100.0d);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond36, (java.lang.Number) 9);
        try {
            timeSeries12.add(timeSeriesDataItem40);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.SpreadsheetDate.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(comparable13);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "9-January-1900" + "'", str19.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 9 + "'", int21 == 9);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 10L + "'", long22 == 10L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 9 + "'", int23 == 9);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate5 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass8 = spreadsheetDate7.getClass();
        java.util.Date date9 = null;
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date9, timeZone10);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate4, (java.lang.Class) wildcardClass8);
        boolean boolean13 = timeSeries12.isEmpty();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries12.getDataItem((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date1);
        java.util.TimeZone timeZone4 = null;
        try {
            org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date1, timeZone4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        boolean boolean3 = fixedMillisecond1.equals((java.lang.Object) 100.0d);
        long long4 = fixedMillisecond1.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((int) '4');
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        int int3 = day2.getMonth();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate9);
        java.lang.String str11 = day10.toString();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) day10);
        int int13 = day10.getDayOfMonth();
        long long14 = day10.getSerialIndex();
        int int15 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) day10);
        java.util.Collection collection16 = timeSeries5.getTimePeriods();
        boolean boolean17 = day2.equals((java.lang.Object) collection16);
        java.util.Calendar calendar18 = null;
        try {
            day2.peg(calendar18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "9-January-1900" + "'", str11.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 9 + "'", int13 == 9);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(collection16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate10 = spreadsheetDate6.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass13 = spreadsheetDate12.getClass();
        java.util.Date date14 = null;
        java.util.TimeZone timeZone15 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date14, timeZone15);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate9, (java.lang.Class) wildcardClass13);
        boolean boolean18 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate4, (org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(9);
        int int21 = spreadsheetDate20.getDayOfMonth();
        int int22 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate24);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate29);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate33 = spreadsheetDate29.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate32);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass36 = spreadsheetDate35.getClass();
        java.util.Date date37 = null;
        java.util.TimeZone timeZone38 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date37, timeZone38);
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate32, (java.lang.Class) wildcardClass36);
        boolean boolean41 = spreadsheetDate24.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate27, (org.jfree.data.time.SerialDate) spreadsheetDate32);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate(9);
        int int44 = spreadsheetDate43.getDayOfMonth();
        int int45 = spreadsheetDate24.compare((org.jfree.data.time.SerialDate) spreadsheetDate43);
        boolean boolean46 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate24);
        int int47 = spreadsheetDate1.getMonth();
        org.jfree.data.time.SerialDate serialDate48 = null;
        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate50);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate53 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate54 = spreadsheetDate50.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate53);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate56 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass57 = spreadsheetDate56.getClass();
        java.util.Date date58 = null;
        java.util.TimeZone timeZone59 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass57, date58, timeZone59);
        org.jfree.data.time.TimeSeries timeSeries61 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate53, (java.lang.Class) wildcardClass57);
        try {
            boolean boolean63 = spreadsheetDate1.isInRange(serialDate48, (org.jfree.data.time.SerialDate) spreadsheetDate53, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 8 + "'", int21 == 8);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 8 + "'", int44 == 8);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertNotNull(wildcardClass57);
        org.junit.Assert.assertNull(regularTimePeriod60);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate3);
        java.lang.String str5 = day4.toString();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day4);
        boolean boolean7 = timeSeries1.getNotify();
        int int8 = timeSeries1.getMaximumItemCount();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "9-January-1900" + "'", str5.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2147483647 + "'", int8 == 2147483647);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        long long4 = year3.getFirstMillisecond();
        int int5 = year3.getYear();
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2, (org.jfree.data.time.RegularTimePeriod) year3);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate10);
        java.lang.String str12 = day11.toString();
        timeSeries8.delete((org.jfree.data.time.RegularTimePeriod) day11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day11.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day11, (java.lang.Number) 1L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
        timeSeries1.removeChangeListener(seriesChangeListener17);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries1.getDataItem(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "9-January-1900" + "'", str12.equals("9-January-1900"));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass6 = spreadsheetDate5.getClass();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str1, "", "9-January-1900", (java.lang.Class) wildcardClass6);
        int int8 = timeSeries7.getMaximumItemCount();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2147483647 + "'", int8 == 2147483647);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        java.lang.String str2 = year1.toString();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (byte) 10, year1);
        java.util.Calendar calendar4 = null;
        try {
            year1.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
    }

//    @Test
//    public void test159() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test159");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond0.getFirstMillisecond(calendar2);
//        long long4 = fixedMillisecond0.getLastMillisecond();
//        java.util.Date date5 = fixedMillisecond0.getEnd();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560192923479L + "'", long3 == 1560192923479L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560192923479L + "'", long4 == 1560192923479L);
//        org.junit.Assert.assertNotNull(date5);
//    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        java.lang.String str2 = year1.toString();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (byte) 10, year1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.previous();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = month3.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate5 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass12 = spreadsheetDate11.getClass();
        boolean boolean13 = spreadsheetDate8.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addYears((int) '4', (org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SerialDate serialDate15 = spreadsheetDate4.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate11);
        int int16 = spreadsheetDate4.toSerial();
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 9 + "'", int16 == 9);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(6, 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30 + "'", int2 == 30);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        java.lang.String str2 = year1.toString();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate8);
        java.lang.String str10 = day9.toString();
        timeSeries6.delete((org.jfree.data.time.RegularTimePeriod) day9);
        int int12 = day9.getDayOfMonth();
        long long13 = day9.getSerialIndex();
        int int14 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) day9);
        int int15 = year1.compareTo((java.lang.Object) int14);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(1, year1);
        java.util.Calendar calendar17 = null;
        try {
            long long18 = month16.getMiddleMillisecond(calendar17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "9-January-1900" + "'", str10.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 9 + "'", int12 == 9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("9-January-1900");
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate5);
        java.lang.String str7 = day6.toString();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) day6);
        int int9 = day6.getDayOfMonth();
        long long10 = day6.getSerialIndex();
        int int11 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) day6);
        timeSeries1.setMaximumItemAge((long) '4');
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener14);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        java.lang.String str17 = year16.toString();
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year16, (java.lang.Number) 1900);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "9-January-1900" + "'", str7.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "2019" + "'", str17.equals("2019"));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate3);
        java.lang.String str5 = day4.toString();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day4.previous();
        java.util.Date date8 = day4.getStart();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond(0L);
        boolean boolean13 = fixedMillisecond11.equals((java.lang.Object) 100.0d);
        int int15 = fixedMillisecond11.compareTo((java.lang.Object) 1);
        long long16 = fixedMillisecond11.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 9999);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        boolean boolean20 = timeSeriesDataItem18.equals((java.lang.Object) year19);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate23);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass27 = spreadsheetDate26.getClass();
        boolean boolean28 = spreadsheetDate23.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate26);
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.addYears((int) '4', (org.jfree.data.time.SerialDate) spreadsheetDate26);
        int int30 = timeSeriesDataItem18.compareTo((java.lang.Object) spreadsheetDate26);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate32);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass36 = spreadsheetDate35.getClass();
        boolean boolean37 = spreadsheetDate32.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate35);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate39);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate43 = spreadsheetDate39.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate42);
        boolean boolean44 = spreadsheetDate35.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate39);
        org.jfree.data.time.SerialDate serialDate45 = spreadsheetDate26.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate35);
        int int46 = month9.compareTo((java.lang.Object) serialDate45);
        long long47 = month9.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "9-January-1900" + "'", str5.equals("9-January-1900"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + (-2206281600001L) + "'", long47 == (-2206281600001L));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        boolean boolean3 = fixedMillisecond1.equals((java.lang.Object) 100.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond1.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond1.next();
        java.lang.String str7 = regularTimePeriod6.toString();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str7.equals("Wed Dec 31 16:00:00 PST 1969"));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        long long4 = year3.getFirstMillisecond();
        int int5 = year3.getYear();
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2, (org.jfree.data.time.RegularTimePeriod) year3);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.lang.String str9 = year8.toString();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (byte) 10, year8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass16 = spreadsheetDate15.getClass();
        boolean boolean17 = spreadsheetDate12.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate23 = spreadsheetDate19.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate22);
        boolean boolean24 = spreadsheetDate15.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month10, (org.jfree.data.time.RegularTimePeriod) day25);
        org.jfree.data.time.TimeSeries timeSeries27 = null;
        try {
            java.util.Collection collection28 = timeSeries26.getTimePeriodsUniqueToOtherSeries(timeSeries27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(timeSeries26);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Last" + "'", str1.equals("Last"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass6 = spreadsheetDate5.getClass();
        boolean boolean7 = spreadsheetDate2.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears((int) '#', (org.jfree.data.time.SerialDate) spreadsheetDate5);
        java.lang.String str9 = spreadsheetDate5.getDescription();
        int int10 = spreadsheetDate5.getDayOfWeek();
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 3 + "'", int10 == 3);
    }

//    @Test
//    public void test172() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test172");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
//        long long4 = year3.getFirstMillisecond();
//        int int5 = year3.getYear();
//        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2, (org.jfree.data.time.RegularTimePeriod) year3);
//        long long7 = fixedMillisecond2.getFirstMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond2.getFirstMillisecond(calendar8);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertNotNull(timeSeries6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560192924809L + "'", long7 == 1560192924809L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560192924809L + "'", long9 == 1560192924809L);
//    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Nearest");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        java.lang.Class<?> wildcardClass3 = seriesException1.getClass();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        long long4 = year3.getFirstMillisecond();
        int int5 = year3.getYear();
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2, (org.jfree.data.time.RegularTimePeriod) year3);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate10);
        java.lang.String str12 = day11.toString();
        timeSeries8.delete((org.jfree.data.time.RegularTimePeriod) day11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day11.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day11, (java.lang.Number) 1L);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate20);
        java.lang.String str22 = day21.toString();
        timeSeries18.delete((org.jfree.data.time.RegularTimePeriod) day21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day21.previous();
        java.lang.String str25 = day21.toString();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate29);
        java.lang.String str31 = day30.toString();
        timeSeries27.delete((org.jfree.data.time.RegularTimePeriod) day30);
        int int33 = day30.getDayOfMonth();
        long long34 = day30.getSerialIndex();
        int int35 = day30.getDayOfMonth();
        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) day21, (org.jfree.data.time.RegularTimePeriod) day30);
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate40);
        java.lang.String str42 = day41.toString();
        timeSeries38.delete((org.jfree.data.time.RegularTimePeriod) day41);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = day41.previous();
        java.lang.String str45 = day41.toString();
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year();
        long long50 = year49.getFirstMillisecond();
        int int51 = year49.getYear();
        org.jfree.data.time.TimeSeries timeSeries52 = timeSeries47.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond48, (org.jfree.data.time.RegularTimePeriod) year49);
        int int53 = day41.compareTo((java.lang.Object) timeSeries47);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem55 = timeSeries36.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day41, (double) (short) 10);
        int int56 = day41.getMonth();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "9-January-1900" + "'", str12.equals("9-January-1900"));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "9-January-1900" + "'", str22.equals("9-January-1900"));
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "9-January-1900" + "'", str25.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "9-January-1900" + "'", str31.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 9 + "'", int33 == 9);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 10L + "'", long34 == 10L);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 9 + "'", int35 == 9);
        org.junit.Assert.assertNotNull(timeSeries36);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "9-January-1900" + "'", str42.equals("9-January-1900"));
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "9-January-1900" + "'", str45.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1546329600000L + "'", long50 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 2019 + "'", int51 == 2019);
        org.junit.Assert.assertNotNull(timeSeries52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
        org.junit.Assert.assertNotNull(timeSeriesDataItem55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_SECOND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = spreadsheetDate4.getClass();
        boolean boolean6 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass12 = spreadsheetDate11.getClass();
        boolean boolean13 = spreadsheetDate8.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate19 = spreadsheetDate15.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate18);
        boolean boolean20 = spreadsheetDate11.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean21 = spreadsheetDate4.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate24);
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.addMonths(1, (org.jfree.data.time.SerialDate) spreadsheetDate24);
        boolean boolean27 = spreadsheetDate4.isBefore(serialDate26);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        boolean boolean3 = fixedMillisecond1.equals((java.lang.Object) 100.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond1.previous();
        long long6 = fixedMillisecond1.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("9-January-1900");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(12, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("December");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        int int0 = org.jfree.data.time.SerialDate.WEDNESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        long long4 = year3.getFirstMillisecond();
        int int5 = year3.getYear();
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2, (org.jfree.data.time.RegularTimePeriod) year3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond7.next();
        timeSeries6.delete(regularTimePeriod8);
        java.util.List list10 = timeSeries6.getItems();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = null;
        java.lang.Number number12 = null;
        try {
            timeSeries6.update(regularTimePeriod11, number12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(list10);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, (int) (short) 100, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass2 = spreadsheetDate1.getClass();
        java.util.Date date3 = null;
        java.util.TimeZone timeZone4 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date3, timeZone4);
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date6, timeZone7);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertNull(regularTimePeriod8);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate5 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass8 = spreadsheetDate7.getClass();
        java.util.Date date9 = null;
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date9, timeZone10);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate4, (java.lang.Class) wildcardClass8);
        java.lang.Comparable comparable13 = timeSeries12.getKey();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate17);
        java.lang.String str19 = day18.toString();
        timeSeries15.delete((org.jfree.data.time.RegularTimePeriod) day18);
        int int21 = day18.getDayOfMonth();
        long long22 = day18.getSerialIndex();
        int int23 = day18.getDayOfMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries12.getDataItem((org.jfree.data.time.RegularTimePeriod) day18);
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        long long29 = year28.getFirstMillisecond();
        int int30 = year28.getYear();
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries26.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, (org.jfree.data.time.RegularTimePeriod) year28);
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        java.lang.String str34 = year33.toString();
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month((int) (byte) 10, year33);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate37);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass41 = spreadsheetDate40.getClass();
        boolean boolean42 = spreadsheetDate37.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate40);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate44);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate48 = spreadsheetDate44.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate47);
        boolean boolean49 = spreadsheetDate40.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate44);
        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate40);
        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries26.createCopy((org.jfree.data.time.RegularTimePeriod) month35, (org.jfree.data.time.RegularTimePeriod) day50);
        timeSeries12.delete((org.jfree.data.time.RegularTimePeriod) day50);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(comparable13);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "9-January-1900" + "'", str19.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 9 + "'", int21 == 9);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 10L + "'", long22 == 10L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 9 + "'", int23 == 9);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1546329600000L + "'", long29 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
        org.junit.Assert.assertNotNull(timeSeries31);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "2019" + "'", str34.equals("2019"));
        org.junit.Assert.assertNotNull(wildcardClass41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(timeSeries51);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate3);
        java.lang.String str5 = day4.toString();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day4);
        int int7 = day4.getDayOfMonth();
        long long8 = day4.getSerialIndex();
        int int9 = day4.getYear();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass12 = spreadsheetDate11.getClass();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, (java.lang.Class) wildcardClass12);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate17);
        java.lang.String str19 = day18.toString();
        timeSeries15.delete((org.jfree.data.time.RegularTimePeriod) day18);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        timeSeries22.setMaximumItemAge((long) (short) 1);
        boolean boolean25 = day18.equals((java.lang.Object) timeSeries22);
        try {
            timeSeries13.add((org.jfree.data.time.RegularTimePeriod) day18, (java.lang.Number) 10.0d);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Day, but the TimeSeries is expecting an instance of org.jfree.data.time.SpreadsheetDate.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "9-January-1900" + "'", str5.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9 + "'", int7 == 9);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1900 + "'", int9 == 1900);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "9-January-1900" + "'", str19.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (byte) 1, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        int int4 = spreadsheetDate2.getYYYY();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        long long6 = year5.getFirstMillisecond();
        int int7 = year5.getYear();
        int int8 = year5.getYear();
        try {
            int int9 = spreadsheetDate2.compareTo((java.lang.Object) year5);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.Year cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1900 + "'", int4 == 1900);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        long long4 = year3.getFirstMillisecond();
        int int5 = year3.getYear();
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2, (org.jfree.data.time.RegularTimePeriod) year3);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate10);
        java.lang.String str12 = day11.toString();
        timeSeries8.delete((org.jfree.data.time.RegularTimePeriod) day11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day11.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day11, (java.lang.Number) 1L);
        long long17 = day11.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "9-January-1900" + "'", str12.equals("9-January-1900"));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-2208268800000L) + "'", long17 == (-2208268800000L));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        java.lang.String str2 = year1.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (double) (byte) 10);
        int int5 = year1.getYear();
        try {
            org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(2147483647, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        int int0 = org.jfree.data.time.SerialDate.NEAREST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(9);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-457) + "'", int1 == (-457));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("SerialDate.weekInMonthToString(): invalid code.");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        boolean boolean3 = fixedMillisecond1.equals((java.lang.Object) 100.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond1.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond1.next();
        long long7 = fixedMillisecond1.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Last");
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate5);
        java.lang.String str7 = day6.toString();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) day6);
        int int9 = day6.getDayOfMonth();
        long long10 = day6.getSerialIndex();
        int int11 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) day6);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.getDataItem((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "9-January-1900" + "'", str7.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(1900);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate3);
        java.lang.String str5 = day4.toString();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day4.previous();
        java.lang.String str8 = day4.toString();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getFirstMillisecond();
        int int14 = year12.getYear();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (org.jfree.data.time.RegularTimePeriod) year12);
        int int16 = day4.compareTo((java.lang.Object) timeSeries10);
        long long17 = day4.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "9-January-1900" + "'", str5.equals("9-January-1900"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "9-January-1900" + "'", str8.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-2208268800000L) + "'", long17 == (-2208268800000L));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate3);
        java.lang.String str5 = day4.toString();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day4.previous();
        java.lang.String str8 = day4.toString();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getFirstMillisecond();
        int int14 = year12.getYear();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (org.jfree.data.time.RegularTimePeriod) year12);
        int int16 = day4.compareTo((java.lang.Object) timeSeries10);
        try {
            java.lang.Number number18 = timeSeries10.getValue((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "9-January-1900" + "'", str5.equals("9-January-1900"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "9-January-1900" + "'", str8.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = spreadsheetDate4.getClass();
        boolean boolean6 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
        int int7 = spreadsheetDate1.toSerial();
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        timeSeries1.clear();
        java.lang.Comparable comparable3 = timeSeries1.getKey();
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        java.lang.String str6 = year5.toString();
        int int7 = year5.getYear();
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 2019);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + 'a' + "'", comparable3.equals('a'));
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 'a' + "'", comparable4.equals('a'));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate5 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass8 = spreadsheetDate7.getClass();
        java.util.Date date9 = null;
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date9, timeZone10);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate4, (java.lang.Class) wildcardClass8);
        java.lang.Comparable comparable13 = timeSeries12.getKey();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate17);
        java.lang.String str19 = day18.toString();
        timeSeries15.delete((org.jfree.data.time.RegularTimePeriod) day18);
        int int21 = day18.getDayOfMonth();
        long long22 = day18.getSerialIndex();
        int int23 = day18.getDayOfMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries12.getDataItem((org.jfree.data.time.RegularTimePeriod) day18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond(0L);
        boolean boolean28 = fixedMillisecond26.equals((java.lang.Object) 100.0d);
        int int30 = fixedMillisecond26.compareTo((java.lang.Object) 1);
        long long31 = fixedMillisecond26.getMiddleMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = fixedMillisecond32.next();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, regularTimePeriod33);
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
        long long39 = year38.getFirstMillisecond();
        int int40 = year38.getYear();
        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries36.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond37, (org.jfree.data.time.RegularTimePeriod) year38);
        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate45);
        java.lang.String str47 = day46.toString();
        timeSeries43.delete((org.jfree.data.time.RegularTimePeriod) day46);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = day46.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = timeSeries36.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day46, (java.lang.Number) 1L);
        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate55 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate55);
        java.lang.String str57 = day56.toString();
        timeSeries53.delete((org.jfree.data.time.RegularTimePeriod) day56);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = day56.previous();
        java.lang.String str60 = day56.toString();
        org.jfree.data.time.TimeSeries timeSeries62 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate64 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate64);
        java.lang.String str66 = day65.toString();
        timeSeries62.delete((org.jfree.data.time.RegularTimePeriod) day65);
        int int68 = day65.getDayOfMonth();
        long long69 = day65.getSerialIndex();
        int int70 = day65.getDayOfMonth();
        org.jfree.data.time.TimeSeries timeSeries71 = timeSeries36.createCopy((org.jfree.data.time.RegularTimePeriod) day56, (org.jfree.data.time.RegularTimePeriod) day65);
        org.jfree.data.time.TimeSeries timeSeries73 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate75 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day76 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate75);
        java.lang.String str77 = day76.toString();
        timeSeries73.delete((org.jfree.data.time.RegularTimePeriod) day76);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = day76.previous();
        java.lang.String str80 = day76.toString();
        org.jfree.data.time.TimeSeries timeSeries82 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond83 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year84 = new org.jfree.data.time.Year();
        long long85 = year84.getFirstMillisecond();
        int int86 = year84.getYear();
        org.jfree.data.time.TimeSeries timeSeries87 = timeSeries82.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond83, (org.jfree.data.time.RegularTimePeriod) year84);
        int int88 = day76.compareTo((java.lang.Object) timeSeries82);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem90 = timeSeries71.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day76, (double) (short) 10);
        int int91 = fixedMillisecond26.compareTo((java.lang.Object) (short) 10);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(comparable13);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "9-January-1900" + "'", str19.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 9 + "'", int21 == 9);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 10L + "'", long22 == 10L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 9 + "'", int23 == 9);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1546329600000L + "'", long39 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2019 + "'", int40 == 2019);
        org.junit.Assert.assertNotNull(timeSeries41);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "9-January-1900" + "'", str47.equals("9-January-1900"));
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertNull(timeSeriesDataItem51);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "9-January-1900" + "'", str57.equals("9-January-1900"));
        org.junit.Assert.assertNotNull(regularTimePeriod59);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "9-January-1900" + "'", str60.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "9-January-1900" + "'", str66.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 9 + "'", int68 == 9);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 10L + "'", long69 == 10L);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 9 + "'", int70 == 9);
        org.junit.Assert.assertNotNull(timeSeries71);
        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "9-January-1900" + "'", str77.equals("9-January-1900"));
        org.junit.Assert.assertNotNull(regularTimePeriod79);
        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "9-January-1900" + "'", str80.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + long85 + "' != '" + 1546329600000L + "'", long85 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 2019 + "'", int86 == 2019);
        org.junit.Assert.assertNotNull(timeSeries87);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 1 + "'", int88 == 1);
        org.junit.Assert.assertNotNull(timeSeriesDataItem90);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 1 + "'", int91 == 1);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(12);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate3);
        java.lang.String str5 = day4.toString();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day4);
        boolean boolean7 = timeSeries1.getNotify();
        boolean boolean8 = timeSeries1.getNotify();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "9-January-1900" + "'", str5.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(11);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("October 2019");
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(12);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate5);
        java.lang.String str7 = day6.toString();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) day6);
        int int9 = day6.getDayOfMonth();
        long long10 = day6.getSerialIndex();
        int int11 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) day6);
        timeSeries1.setMaximumItemAge((long) '4');
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener14);
        boolean boolean17 = timeSeries1.equals((java.lang.Object) (byte) 1);
        timeSeries1.fireSeriesChanged();
        java.lang.String str19 = timeSeries1.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate25 = spreadsheetDate21.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate24);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass28 = spreadsheetDate27.getClass();
        java.util.Date date29 = null;
        java.util.TimeZone timeZone30 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass28, date29, timeZone30);
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate24, (java.lang.Class) wildcardClass28);
        java.lang.Comparable comparable33 = timeSeries32.getKey();
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate37);
        java.lang.String str39 = day38.toString();
        timeSeries35.delete((org.jfree.data.time.RegularTimePeriod) day38);
        int int41 = day38.getDayOfMonth();
        long long42 = day38.getSerialIndex();
        int int43 = day38.getDayOfMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries32.getDataItem((org.jfree.data.time.RegularTimePeriod) day38);
        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond(0L);
        boolean boolean48 = fixedMillisecond46.equals((java.lang.Object) 100.0d);
        int int50 = fixedMillisecond46.compareTo((java.lang.Object) 1);
        long long51 = fixedMillisecond46.getMiddleMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = fixedMillisecond52.next();
        org.jfree.data.time.TimeSeries timeSeries54 = timeSeries32.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond46, regularTimePeriod53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = fixedMillisecond46.previous();
        java.lang.Class<?> wildcardClass56 = regularTimePeriod55.getClass();
        try {
            timeSeries1.add(regularTimePeriod55, (java.lang.Number) 1560192906752L, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "9-January-1900" + "'", str7.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(comparable33);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "9-January-1900" + "'", str39.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 9 + "'", int41 == 9);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 10L + "'", long42 == 10L);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 9 + "'", int43 == 9);
        org.junit.Assert.assertNull(timeSeriesDataItem44);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 0L + "'", long51 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod53);
        org.junit.Assert.assertNotNull(timeSeries54);
        org.junit.Assert.assertNotNull(regularTimePeriod55);
        org.junit.Assert.assertNotNull(wildcardClass56);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("Last");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        java.lang.Object obj0 = null;
        try {
            org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent(obj0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(100, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (java.lang.Number) 11);
        java.lang.Object obj4 = timeSeriesDataItem3.clone();
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate3);
        java.lang.String str5 = day4.toString();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day4);
        java.util.Collection collection7 = timeSeries1.getTimePeriods();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = timeSeries1.getTimePeriod((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "9-January-1900" + "'", str5.equals("9-January-1900"));
        org.junit.Assert.assertNotNull(collection7);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        int int2 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.next();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass9 = spreadsheetDate8.getClass();
        boolean boolean10 = spreadsheetDate5.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass16 = spreadsheetDate15.getClass();
        boolean boolean17 = spreadsheetDate12.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate23 = spreadsheetDate19.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate22);
        boolean boolean24 = spreadsheetDate15.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate19);
        boolean boolean25 = spreadsheetDate8.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate15);
        int int26 = year0.compareTo((java.lang.Object) boolean25);
        java.util.Calendar calendar27 = null;
        try {
            long long28 = year0.getLastMillisecond(calendar27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(1900);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year0.getLastMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(2958465, (-457));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        long long4 = year3.getFirstMillisecond();
        int int5 = year3.getYear();
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2, (org.jfree.data.time.RegularTimePeriod) year3);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate10);
        java.lang.String str12 = day11.toString();
        timeSeries8.delete((org.jfree.data.time.RegularTimePeriod) day11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day11.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day11, (java.lang.Number) 1L);
        java.util.Calendar calendar17 = null;
        try {
            long long18 = day11.getFirstMillisecond(calendar17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "9-January-1900" + "'", str12.equals("9-January-1900"));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_LOWER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(6, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30 + "'", int2 == 30);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (byte) 10, 1900, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate5 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass8 = spreadsheetDate7.getClass();
        java.util.Date date9 = null;
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date9, timeZone10);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate4, (java.lang.Class) wildcardClass8);
        java.lang.Comparable comparable13 = timeSeries12.getKey();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate17);
        java.lang.String str19 = day18.toString();
        timeSeries15.delete((org.jfree.data.time.RegularTimePeriod) day18);
        int int21 = day18.getDayOfMonth();
        long long22 = day18.getSerialIndex();
        int int23 = day18.getDayOfMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries12.getDataItem((org.jfree.data.time.RegularTimePeriod) day18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond(0L);
        boolean boolean28 = fixedMillisecond26.equals((java.lang.Object) 100.0d);
        int int30 = fixedMillisecond26.compareTo((java.lang.Object) 1);
        long long31 = fixedMillisecond26.getMiddleMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = fixedMillisecond32.next();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, regularTimePeriod33);
        try {
            timeSeries12.update(5, (java.lang.Number) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(comparable13);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "9-January-1900" + "'", str19.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 9 + "'", int21 == 9);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 10L + "'", long22 == 10L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 9 + "'", int23 == 9);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(timeSeries34);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(date1);
        try {
            org.jfree.data.time.SerialDate serialDate4 = serialDate2.getNearestDayOfWeek((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(serialDate2);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        timeSeries1.clear();
        java.lang.Comparable comparable3 = timeSeries1.getKey();
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate(regularTimePeriod6, (java.lang.Number) 0.0f);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate14 = spreadsheetDate10.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass17 = spreadsheetDate16.getClass();
        java.util.Date date18 = null;
        java.util.TimeZone timeZone19 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date18, timeZone19);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate13, (java.lang.Class) wildcardClass17);
        java.lang.Comparable comparable22 = timeSeries21.getKey();
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate26);
        java.lang.String str28 = day27.toString();
        timeSeries24.delete((org.jfree.data.time.RegularTimePeriod) day27);
        int int30 = day27.getDayOfMonth();
        long long31 = day27.getSerialIndex();
        int int32 = day27.getDayOfMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries21.getDataItem((org.jfree.data.time.RegularTimePeriod) day27);
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond(0L);
        boolean boolean37 = fixedMillisecond35.equals((java.lang.Object) 100.0d);
        int int39 = fixedMillisecond35.compareTo((java.lang.Object) 1);
        long long40 = fixedMillisecond35.getMiddleMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = fixedMillisecond41.next();
        org.jfree.data.time.TimeSeries timeSeries43 = timeSeries21.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35, regularTimePeriod42);
        timeSeries21.setNotify(false);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate47);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate51 = spreadsheetDate47.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate50);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate53 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass54 = spreadsheetDate53.getClass();
        java.util.Date date55 = null;
        java.util.TimeZone timeZone56 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass54, date55, timeZone56);
        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate50, (java.lang.Class) wildcardClass54);
        java.lang.Comparable comparable59 = timeSeries58.getKey();
        org.jfree.data.time.TimeSeries timeSeries61 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate63 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate63);
        java.lang.String str65 = day64.toString();
        timeSeries61.delete((org.jfree.data.time.RegularTimePeriod) day64);
        int int67 = day64.getDayOfMonth();
        long long68 = day64.getSerialIndex();
        int int69 = day64.getDayOfMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem70 = timeSeries58.getDataItem((org.jfree.data.time.RegularTimePeriod) day64);
        org.jfree.data.time.FixedMillisecond fixedMillisecond72 = new org.jfree.data.time.FixedMillisecond(0L);
        boolean boolean74 = fixedMillisecond72.equals((java.lang.Object) 100.0d);
        int int76 = fixedMillisecond72.compareTo((java.lang.Object) 1);
        long long77 = fixedMillisecond72.getMiddleMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond78 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = fixedMillisecond78.next();
        org.jfree.data.time.TimeSeries timeSeries80 = timeSeries58.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond72, regularTimePeriod79);
        org.jfree.data.time.TimeSeries timeSeries81 = timeSeries21.addAndOrUpdate(timeSeries58);
        java.util.Collection collection82 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries58);
        timeSeries1.setMaximumItemCount(8);
        timeSeries1.setMaximumItemCount((int) '#');
        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + 'a' + "'", comparable3.equals('a'));
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 'a' + "'", comparable4.equals('a'));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(comparable22);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "9-January-1900" + "'", str28.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 9 + "'", int30 == 9);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 10L + "'", long31 == 10L);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 9 + "'", int32 == 9);
        org.junit.Assert.assertNull(timeSeriesDataItem33);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertNotNull(timeSeries43);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertNotNull(wildcardClass54);
        org.junit.Assert.assertNull(regularTimePeriod57);
        org.junit.Assert.assertNotNull(comparable59);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "9-January-1900" + "'", str65.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 9 + "'", int67 == 9);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 10L + "'", long68 == 10L);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 9 + "'", int69 == 9);
        org.junit.Assert.assertNull(timeSeriesDataItem70);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 1 + "'", int76 == 1);
        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 0L + "'", long77 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod79);
        org.junit.Assert.assertNotNull(timeSeries80);
        org.junit.Assert.assertNotNull(timeSeries81);
        org.junit.Assert.assertNotNull(collection82);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("Nearest");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = spreadsheetDate4.getClass();
        boolean boolean6 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate9 = spreadsheetDate4.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass12 = spreadsheetDate11.getClass();
        boolean boolean13 = spreadsheetDate4.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate11);
        try {
            org.jfree.data.time.SerialDate serialDate15 = spreadsheetDate11.getPreviousDayOfWeek((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate5 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass12 = spreadsheetDate11.getClass();
        boolean boolean13 = spreadsheetDate8.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addYears((int) '4', (org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SerialDate serialDate15 = spreadsheetDate4.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate11);
        try {
            org.jfree.data.time.SerialDate serialDate17 = spreadsheetDate4.getNearestDayOfWeek(8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate10 = spreadsheetDate6.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass13 = spreadsheetDate12.getClass();
        java.util.Date date14 = null;
        java.util.TimeZone timeZone15 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date14, timeZone15);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate9, (java.lang.Class) wildcardClass13);
        boolean boolean18 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate4, (org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate9);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries19.removeChangeListener(seriesChangeListener20);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate5 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass8 = spreadsheetDate7.getClass();
        java.util.Date date9 = null;
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date9, timeZone10);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate4, (java.lang.Class) wildcardClass8);
        java.lang.Comparable comparable13 = timeSeries12.getKey();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate17);
        java.lang.String str19 = day18.toString();
        timeSeries15.delete((org.jfree.data.time.RegularTimePeriod) day18);
        int int21 = day18.getDayOfMonth();
        long long22 = day18.getSerialIndex();
        int int23 = day18.getDayOfMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries12.getDataItem((org.jfree.data.time.RegularTimePeriod) day18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond(0L);
        boolean boolean28 = fixedMillisecond26.equals((java.lang.Object) 100.0d);
        int int30 = fixedMillisecond26.compareTo((java.lang.Object) 1);
        long long31 = fixedMillisecond26.getMiddleMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = fixedMillisecond32.next();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, regularTimePeriod33);
        timeSeries12.setNotify(false);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate38);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate42 = spreadsheetDate38.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate41);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass45 = spreadsheetDate44.getClass();
        java.util.Date date46 = null;
        java.util.TimeZone timeZone47 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass45, date46, timeZone47);
        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate41, (java.lang.Class) wildcardClass45);
        java.lang.Comparable comparable50 = timeSeries49.getKey();
        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate54 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate54);
        java.lang.String str56 = day55.toString();
        timeSeries52.delete((org.jfree.data.time.RegularTimePeriod) day55);
        int int58 = day55.getDayOfMonth();
        long long59 = day55.getSerialIndex();
        int int60 = day55.getDayOfMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem61 = timeSeries49.getDataItem((org.jfree.data.time.RegularTimePeriod) day55);
        org.jfree.data.time.FixedMillisecond fixedMillisecond63 = new org.jfree.data.time.FixedMillisecond(0L);
        boolean boolean65 = fixedMillisecond63.equals((java.lang.Object) 100.0d);
        int int67 = fixedMillisecond63.compareTo((java.lang.Object) 1);
        long long68 = fixedMillisecond63.getMiddleMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond69 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = fixedMillisecond69.next();
        org.jfree.data.time.TimeSeries timeSeries71 = timeSeries49.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond63, regularTimePeriod70);
        org.jfree.data.time.TimeSeries timeSeries72 = timeSeries12.addAndOrUpdate(timeSeries49);
        int int73 = timeSeries49.getMaximumItemCount();
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(comparable13);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "9-January-1900" + "'", str19.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 9 + "'", int21 == 9);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 10L + "'", long22 == 10L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 9 + "'", int23 == 9);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertNotNull(wildcardClass45);
        org.junit.Assert.assertNull(regularTimePeriod48);
        org.junit.Assert.assertNotNull(comparable50);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "9-January-1900" + "'", str56.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 9 + "'", int58 == 9);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 10L + "'", long59 == 10L);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 9 + "'", int60 == 9);
        org.junit.Assert.assertNull(timeSeriesDataItem61);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1 + "'", int67 == 1);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 0L + "'", long68 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod70);
        org.junit.Assert.assertNotNull(timeSeries71);
        org.junit.Assert.assertNotNull(timeSeries72);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 2147483647 + "'", int73 == 2147483647);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate5 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass8 = spreadsheetDate7.getClass();
        java.util.Date date9 = null;
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date9, timeZone10);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate4, (java.lang.Class) wildcardClass8);
        java.lang.Comparable comparable13 = timeSeries12.getKey();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate17);
        java.lang.String str19 = day18.toString();
        timeSeries15.delete((org.jfree.data.time.RegularTimePeriod) day18);
        int int21 = day18.getDayOfMonth();
        long long22 = day18.getSerialIndex();
        int int23 = day18.getDayOfMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries12.getDataItem((org.jfree.data.time.RegularTimePeriod) day18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = fixedMillisecond25.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries12.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, (double) 10L);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(comparable13);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "9-January-1900" + "'", str19.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 9 + "'", int21 == 9);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 10L + "'", long22 == 10L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 9 + "'", int23 == 9);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNull(timeSeriesDataItem27);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        long long4 = year3.getFirstMillisecond();
        int int5 = year3.getYear();
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2, (org.jfree.data.time.RegularTimePeriod) year3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond7.next();
        timeSeries6.delete(regularTimePeriod8);
        java.util.List list10 = timeSeries6.getItems();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate21 = spreadsheetDate17.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass24 = spreadsheetDate23.getClass();
        java.util.Date date25 = null;
        java.util.TimeZone timeZone26 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date25, timeZone26);
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate20, (java.lang.Class) wildcardClass24);
        boolean boolean29 = spreadsheetDate12.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate15, (org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SerialDate serialDate31 = spreadsheetDate12.getFollowingDayOfWeek(6);
        timeSeries6.setKey((java.lang.Comparable) 6);
        timeSeries6.setDescription("December");
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(serialDate31);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        int int0 = org.jfree.data.time.SerialDate.PRECEDING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((-457));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = spreadsheetDate4.getClass();
        boolean boolean6 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate10);
        java.lang.String str12 = day11.toString();
        timeSeries8.delete((org.jfree.data.time.RegularTimePeriod) day11);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        timeSeries15.setMaximumItemAge((long) (short) 1);
        boolean boolean18 = day11.equals((java.lang.Object) timeSeries15);
        try {
            int int19 = spreadsheetDate1.compareTo((java.lang.Object) timeSeries15);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.TimeSeries cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "9-January-1900" + "'", str12.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = spreadsheetDate4.getClass();
        boolean boolean6 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate12 = spreadsheetDate8.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass19 = spreadsheetDate18.getClass();
        boolean boolean20 = spreadsheetDate15.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addYears((int) '4', (org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SerialDate serialDate22 = spreadsheetDate11.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate18);
        boolean boolean23 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond(0L);
        boolean boolean27 = fixedMillisecond25.equals((java.lang.Object) 100.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = fixedMillisecond25.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = fixedMillisecond25.previous();
        long long30 = fixedMillisecond25.getSerialIndex();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate32);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate36 = spreadsheetDate32.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate35);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass39 = spreadsheetDate38.getClass();
        java.util.Date date40 = null;
        java.util.TimeZone timeZone41 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass39, date40, timeZone41);
        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate35, (java.lang.Class) wildcardClass39);
        java.lang.Comparable comparable44 = timeSeries43.getKey();
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate48);
        java.lang.String str50 = day49.toString();
        timeSeries46.delete((org.jfree.data.time.RegularTimePeriod) day49);
        int int52 = day49.getDayOfMonth();
        long long53 = day49.getSerialIndex();
        int int54 = day49.getDayOfMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem55 = timeSeries43.getDataItem((org.jfree.data.time.RegularTimePeriod) day49);
        org.jfree.data.time.FixedMillisecond fixedMillisecond57 = new org.jfree.data.time.FixedMillisecond(0L);
        boolean boolean59 = fixedMillisecond57.equals((java.lang.Object) 100.0d);
        int int61 = fixedMillisecond57.compareTo((java.lang.Object) 1);
        long long62 = fixedMillisecond57.getMiddleMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond63 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = fixedMillisecond63.next();
        org.jfree.data.time.TimeSeries timeSeries65 = timeSeries43.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond57, regularTimePeriod64);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = fixedMillisecond57.previous();
        java.lang.Class<?> wildcardClass67 = regularTimePeriod66.getClass();
        int int68 = fixedMillisecond25.compareTo((java.lang.Object) regularTimePeriod66);
        try {
            int int69 = spreadsheetDate11.compareTo((java.lang.Object) fixedMillisecond25);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.FixedMillisecond cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertNotNull(wildcardClass39);
        org.junit.Assert.assertNull(regularTimePeriod42);
        org.junit.Assert.assertNotNull(comparable44);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "9-January-1900" + "'", str50.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 9 + "'", int52 == 9);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 10L + "'", long53 == 10L);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 9 + "'", int54 == 9);
        org.junit.Assert.assertNull(timeSeriesDataItem55);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1 + "'", int61 == 1);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 0L + "'", long62 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod64);
        org.junit.Assert.assertNotNull(timeSeries65);
        org.junit.Assert.assertNotNull(regularTimePeriod66);
        org.junit.Assert.assertNotNull(wildcardClass67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 1 + "'", int68 == 1);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate3);
        java.lang.String str5 = day4.toString();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day4);
        int int7 = timeSeries1.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getFirstMillisecond();
        int int13 = year11.getYear();
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries9.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (org.jfree.data.time.RegularTimePeriod) year11);
        boolean boolean15 = timeSeries1.equals((java.lang.Object) year11);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent16 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeries1);
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener17);
        int int19 = timeSeries1.getItemCount();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = null;
        try {
            timeSeries1.add(timeSeriesDataItem20, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "9-January-1900" + "'", str5.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1546329600000L + "'", long12 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        long long2 = year1.getFirstMillisecond();
        int int3 = year1.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year1.next();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass10 = spreadsheetDate9.getClass();
        boolean boolean11 = spreadsheetDate6.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass17 = spreadsheetDate16.getClass();
        boolean boolean18 = spreadsheetDate13.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate24 = spreadsheetDate20.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate23);
        boolean boolean25 = spreadsheetDate16.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate20);
        boolean boolean26 = spreadsheetDate9.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate16);
        int int27 = year1.compareTo((java.lang.Object) boolean26);
        try {
            org.jfree.data.time.Month month28 = new org.jfree.data.time.Month((int) (short) 0, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate3);
        java.lang.String str5 = day4.toString();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day4);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        timeSeries8.setMaximumItemAge((long) (short) 1);
        boolean boolean11 = day4.equals((java.lang.Object) timeSeries8);
        timeSeries8.setRangeDescription("October 2019");
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "9-January-1900" + "'", str5.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(0, 1900, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate3);
        java.lang.String str5 = day4.toString();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day4);
        int int7 = timeSeries1.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getFirstMillisecond();
        int int13 = year11.getYear();
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries9.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (org.jfree.data.time.RegularTimePeriod) year11);
        boolean boolean15 = timeSeries1.equals((java.lang.Object) year11);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent16 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeries1);
        java.lang.String str17 = timeSeries1.getDescription();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "9-January-1900" + "'", str5.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1546329600000L + "'", long12 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(str17);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate5 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass8 = spreadsheetDate7.getClass();
        java.util.Date date9 = null;
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date9, timeZone10);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate4, (java.lang.Class) wildcardClass8);
        java.lang.Comparable comparable13 = timeSeries12.getKey();
        java.lang.String str14 = timeSeries12.getDomainDescription();
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(comparable13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Time" + "'", str14.equals("Time"));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (byte) 1, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        int int4 = spreadsheetDate2.getYYYY();
        int int5 = spreadsheetDate2.toSerial();
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1900 + "'", int4 == 1900);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        int int2 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.previous();
        java.util.Calendar calendar5 = null;
        try {
            year0.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (byte) 10);
        int int4 = year0.getYear();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate8);
        java.lang.String str10 = day9.toString();
        timeSeries6.delete((org.jfree.data.time.RegularTimePeriod) day9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day9.previous();
        java.lang.String str13 = day9.toString();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getFirstMillisecond();
        int int19 = year17.getYear();
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16, (org.jfree.data.time.RegularTimePeriod) year17);
        int int21 = day9.compareTo((java.lang.Object) timeSeries15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day9.previous();
        int int23 = year0.compareTo((java.lang.Object) regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "9-January-1900" + "'", str10.equals("9-January-1900"));
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "9-January-1900" + "'", str13.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1546329600000L + "'", long18 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        java.lang.String str2 = year1.toString();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (byte) 10, year1);
        long long4 = month3.getLastMillisecond();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = month3.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1572591599999L + "'", long4 == 1572591599999L);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(date2);
        org.jfree.data.time.SerialDate serialDate4 = null;
        try {
            org.jfree.data.time.SerialDate serialDate5 = serialDate3.getEndOfCurrentMonth(serialDate4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate3);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        int int0 = org.jfree.data.time.SerialDate.FIRST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate5 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass8 = spreadsheetDate7.getClass();
        java.util.Date date9 = null;
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date9, timeZone10);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate4, (java.lang.Class) wildcardClass8);
        java.lang.Comparable comparable13 = timeSeries12.getKey();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate17);
        java.lang.String str19 = day18.toString();
        timeSeries15.delete((org.jfree.data.time.RegularTimePeriod) day18);
        int int21 = day18.getDayOfMonth();
        long long22 = day18.getSerialIndex();
        int int23 = day18.getDayOfMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries12.getDataItem((org.jfree.data.time.RegularTimePeriod) day18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = fixedMillisecond25.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries12.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25);
        timeSeries12.removeAgedItems(true);
        boolean boolean30 = timeSeries12.isEmpty();
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(comparable13);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "9-January-1900" + "'", str19.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 9 + "'", int21 == 9);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 10L + "'", long22 == 10L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 9 + "'", int23 == 9);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNull(timeSeriesDataItem27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(12);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-457) + "'", int1 == (-457));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = spreadsheetDate4.getClass();
        boolean boolean6 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass11 = spreadsheetDate10.getClass();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean6, "December", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass11);
        boolean boolean13 = timeSeries12.isEmpty();
        java.lang.Object obj14 = timeSeries12.clone();
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(8);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 8");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        long long4 = year3.getFirstMillisecond();
        int int5 = year3.getYear();
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2, (org.jfree.data.time.RegularTimePeriod) year3);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate10);
        java.lang.String str12 = day11.toString();
        timeSeries8.delete((org.jfree.data.time.RegularTimePeriod) day11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day11.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day11, (java.lang.Number) 1L);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate20);
        java.lang.String str22 = day21.toString();
        timeSeries18.delete((org.jfree.data.time.RegularTimePeriod) day21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day21.previous();
        java.lang.String str25 = day21.toString();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate29);
        java.lang.String str31 = day30.toString();
        timeSeries27.delete((org.jfree.data.time.RegularTimePeriod) day30);
        int int33 = day30.getDayOfMonth();
        long long34 = day30.getSerialIndex();
        int int35 = day30.getDayOfMonth();
        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) day21, (org.jfree.data.time.RegularTimePeriod) day30);
        long long37 = timeSeries1.getMaximumItemAge();
        try {
            timeSeries1.delete(12, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "9-January-1900" + "'", str12.equals("9-January-1900"));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "9-January-1900" + "'", str22.equals("9-January-1900"));
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "9-January-1900" + "'", str25.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "9-January-1900" + "'", str31.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 9 + "'", int33 == 9);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 10L + "'", long34 == 10L);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 9 + "'", int35 == 9);
        org.junit.Assert.assertNotNull(timeSeries36);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 9223372036854775807L + "'", long37 == 9223372036854775807L);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        int int0 = org.jfree.data.time.SerialDate.SATURDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(7);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(3);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate3);
        java.lang.String str5 = day4.toString();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day4);
        int int7 = day4.getMonth();
        int int8 = day4.getYear();
        java.util.Date date9 = day4.getEnd();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "9-January-1900" + "'", str5.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1900 + "'", int8 == 1900);
        org.junit.Assert.assertNotNull(date9);
    }

//    @Test
//    public void test261() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test261");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond2.getLastMillisecond(calendar3);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560192940238L + "'", long4 == 1560192940238L);
//    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(11);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        long long4 = year3.getFirstMillisecond();
        int int5 = year3.getYear();
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2, (org.jfree.data.time.RegularTimePeriod) year3);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate10);
        java.lang.String str12 = day11.toString();
        timeSeries8.delete((org.jfree.data.time.RegularTimePeriod) day11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day11.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day11, (java.lang.Number) 1L);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate20);
        java.lang.String str22 = day21.toString();
        timeSeries18.delete((org.jfree.data.time.RegularTimePeriod) day21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day21.previous();
        java.lang.String str25 = day21.toString();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate29);
        java.lang.String str31 = day30.toString();
        timeSeries27.delete((org.jfree.data.time.RegularTimePeriod) day30);
        int int33 = day30.getDayOfMonth();
        long long34 = day30.getSerialIndex();
        int int35 = day30.getDayOfMonth();
        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) day21, (org.jfree.data.time.RegularTimePeriod) day30);
        long long37 = timeSeries1.getMaximumItemAge();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent38 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeries1);
        java.lang.String str39 = seriesChangeEvent38.toString();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "9-January-1900" + "'", str12.equals("9-January-1900"));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "9-January-1900" + "'", str22.equals("9-January-1900"));
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "9-January-1900" + "'", str25.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "9-January-1900" + "'", str31.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 9 + "'", int33 == 9);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 10L + "'", long34 == 10L);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 9 + "'", int35 == 9);
        org.junit.Assert.assertNotNull(timeSeries36);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 9223372036854775807L + "'", long37 == 9223372036854775807L);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((-457));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = spreadsheetDate4.getClass();
        boolean boolean6 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate12 = spreadsheetDate8.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass19 = spreadsheetDate18.getClass();
        boolean boolean20 = spreadsheetDate15.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addYears((int) '4', (org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SerialDate serialDate22 = spreadsheetDate11.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate18);
        boolean boolean23 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate25);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass29 = spreadsheetDate28.getClass();
        boolean boolean30 = spreadsheetDate25.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate28);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate32);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate36 = spreadsheetDate32.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate35);
        boolean boolean37 = spreadsheetDate28.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate32);
        int int38 = spreadsheetDate11.compare((org.jfree.data.time.SerialDate) spreadsheetDate32);
        try {
            org.jfree.data.time.SerialDate serialDate40 = spreadsheetDate11.getFollowingDayOfWeek((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date2 = fixedMillisecond1.getTime();
        int int3 = month0.compareTo((java.lang.Object) date2);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date1);
        java.util.Calendar calendar4 = null;
        try {
            month3.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        java.util.Calendar calendar3 = null;
        try {
            day2.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate5 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass8 = spreadsheetDate7.getClass();
        java.util.Date date9 = null;
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date9, timeZone10);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate4, (java.lang.Class) wildcardClass8);
        java.lang.Comparable comparable13 = timeSeries12.getKey();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate17);
        java.lang.String str19 = day18.toString();
        timeSeries15.delete((org.jfree.data.time.RegularTimePeriod) day18);
        int int21 = day18.getDayOfMonth();
        long long22 = day18.getSerialIndex();
        int int23 = day18.getDayOfMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries12.getDataItem((org.jfree.data.time.RegularTimePeriod) day18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond(0L);
        boolean boolean28 = fixedMillisecond26.equals((java.lang.Object) 100.0d);
        int int30 = fixedMillisecond26.compareTo((java.lang.Object) 1);
        long long31 = fixedMillisecond26.getMiddleMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = fixedMillisecond32.next();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, regularTimePeriod33);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener35 = null;
        timeSeries12.removeChangeListener(seriesChangeListener35);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(comparable13);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "9-January-1900" + "'", str19.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 9 + "'", int21 == 9);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 10L + "'", long22 == 10L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 9 + "'", int23 == 9);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(timeSeries34);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("hi!");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate5 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass8 = spreadsheetDate7.getClass();
        java.util.Date date9 = null;
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date9, timeZone10);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate4, (java.lang.Class) wildcardClass8);
        java.lang.Comparable comparable13 = timeSeries12.getKey();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate17);
        java.lang.String str19 = day18.toString();
        timeSeries15.delete((org.jfree.data.time.RegularTimePeriod) day18);
        int int21 = day18.getDayOfMonth();
        long long22 = day18.getSerialIndex();
        int int23 = day18.getDayOfMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries12.getDataItem((org.jfree.data.time.RegularTimePeriod) day18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond(0L);
        boolean boolean28 = fixedMillisecond26.equals((java.lang.Object) 100.0d);
        int int30 = fixedMillisecond26.compareTo((java.lang.Object) 1);
        long long31 = fixedMillisecond26.getMiddleMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = fixedMillisecond32.next();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, regularTimePeriod33);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = fixedMillisecond26.previous();
        long long36 = fixedMillisecond26.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(comparable13);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "9-January-1900" + "'", str19.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 9 + "'", int21 == 9);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 10L + "'", long22 == 10L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 9 + "'", int23 == 9);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass2 = spreadsheetDate1.getClass();
        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(class3);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate10 = spreadsheetDate6.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass13 = spreadsheetDate12.getClass();
        java.util.Date date14 = null;
        java.util.TimeZone timeZone15 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date14, timeZone15);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate9, (java.lang.Class) wildcardClass13);
        boolean boolean18 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate4, (org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate9);
        timeSeries19.removeAgedItems((long) 9999, true);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate5 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass8 = spreadsheetDate7.getClass();
        java.util.Date date9 = null;
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date9, timeZone10);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate4, (java.lang.Class) wildcardClass8);
        boolean boolean13 = timeSeries12.isEmpty();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass19 = spreadsheetDate18.getClass();
        boolean boolean20 = spreadsheetDate15.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass25 = spreadsheetDate24.getClass();
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean20, "December", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass25);
        boolean boolean27 = timeSeries26.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries12.addAndOrUpdate(timeSeries26);
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
        long long30 = year29.getFirstMillisecond();
        timeSeries12.delete((org.jfree.data.time.RegularTimePeriod) year29);
        java.lang.String str32 = year29.toString();
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1546329600000L + "'", long30 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "2019" + "'", str32.equals("2019"));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("2019");
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        java.lang.Comparable comparable0 = null;
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate6 = spreadsheetDate2.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass13 = spreadsheetDate12.getClass();
        boolean boolean14 = spreadsheetDate9.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.addYears((int) '4', (org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.SerialDate serialDate16 = spreadsheetDate5.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate12);
        java.lang.Class<?> wildcardClass17 = spreadsheetDate5.getClass();
        try {
            org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries(comparable0, (java.lang.Class) wildcardClass17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month3, (double) 10.0f);
        timeSeriesDataItem5.setValue((java.lang.Number) 1560192940192L);
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(0, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        long long4 = year3.getFirstMillisecond();
        int int5 = year3.getYear();
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2, (org.jfree.data.time.RegularTimePeriod) year3);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.createCopy(9, 1900);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond(0L);
        boolean boolean13 = fixedMillisecond11.equals((java.lang.Object) 100.0d);
        int int15 = fixedMillisecond11.compareTo((java.lang.Object) 1);
        long long16 = fixedMillisecond11.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 9999);
        try {
            timeSeries1.add(timeSeriesDataItem18);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(30);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-452) + "'", int1 == (-452));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        long long4 = year3.getFirstMillisecond();
        int int5 = year3.getYear();
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2, (org.jfree.data.time.RegularTimePeriod) year3);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate10);
        java.lang.String str12 = day11.toString();
        timeSeries8.delete((org.jfree.data.time.RegularTimePeriod) day11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day11.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day11, (java.lang.Number) 1L);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate20);
        java.lang.String str22 = day21.toString();
        timeSeries18.delete((org.jfree.data.time.RegularTimePeriod) day21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day21.previous();
        java.lang.String str25 = day21.toString();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate29);
        java.lang.String str31 = day30.toString();
        timeSeries27.delete((org.jfree.data.time.RegularTimePeriod) day30);
        int int33 = day30.getDayOfMonth();
        long long34 = day30.getSerialIndex();
        int int35 = day30.getDayOfMonth();
        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) day21, (org.jfree.data.time.RegularTimePeriod) day30);
        long long37 = timeSeries1.getMaximumItemAge();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent38 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeries1);
        java.lang.Object obj39 = seriesChangeEvent38.getSource();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "9-January-1900" + "'", str12.equals("9-January-1900"));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "9-January-1900" + "'", str22.equals("9-January-1900"));
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "9-January-1900" + "'", str25.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "9-January-1900" + "'", str31.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 9 + "'", int33 == 9);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 10L + "'", long34 == 10L);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 9 + "'", int35 == 9);
        org.junit.Assert.assertNotNull(timeSeries36);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 9223372036854775807L + "'", long37 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(obj39);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate5 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass8 = spreadsheetDate7.getClass();
        java.util.Date date9 = null;
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date9, timeZone10);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate4, (java.lang.Class) wildcardClass8);
        java.lang.Comparable comparable13 = timeSeries12.getKey();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        long long15 = year14.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year14.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries12.getDataItem(regularTimePeriod16);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(comparable13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2019L + "'", long15 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("December");
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

//    @Test
//    public void test286() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test286");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        long long2 = fixedMillisecond0.getMiddleMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(0L);
//        long long5 = fixedMillisecond4.getMiddleMillisecond();
//        long long6 = fixedMillisecond4.getLastMillisecond();
//        boolean boolean7 = fixedMillisecond0.equals((java.lang.Object) fixedMillisecond4);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560192943183L + "'", long2 == 1560192943183L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        long long4 = year3.getFirstMillisecond();
        int int5 = year3.getYear();
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2, (org.jfree.data.time.RegularTimePeriod) year3);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.createCopy(9, 1900);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = null;
        try {
            timeSeries9.add(regularTimePeriod10, (double) '#', false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries9);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate5 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass8 = spreadsheetDate7.getClass();
        java.util.Date date9 = null;
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date9, timeZone10);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate4, (java.lang.Class) wildcardClass8);
        java.lang.Comparable comparable13 = timeSeries12.getKey();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate17);
        java.lang.String str19 = day18.toString();
        timeSeries15.delete((org.jfree.data.time.RegularTimePeriod) day18);
        int int21 = day18.getDayOfMonth();
        long long22 = day18.getSerialIndex();
        int int23 = day18.getDayOfMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries12.getDataItem((org.jfree.data.time.RegularTimePeriod) day18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond(0L);
        boolean boolean28 = fixedMillisecond26.equals((java.lang.Object) 100.0d);
        int int30 = fixedMillisecond26.compareTo((java.lang.Object) 1);
        long long31 = fixedMillisecond26.getMiddleMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = fixedMillisecond32.next();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, regularTimePeriod33);
        timeSeries12.setNotify(false);
        java.util.List list37 = timeSeries12.getItems();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = timeSeries12.getTimePeriod(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(comparable13);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "9-January-1900" + "'", str19.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 9 + "'", int21 == 9);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 10L + "'", long22 == 10L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 9 + "'", int23 == 9);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertNotNull(list37);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = spreadsheetDate4.getClass();
        boolean boolean6 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate12 = spreadsheetDate8.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate11);
        boolean boolean13 = spreadsheetDate4.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate8);
        int int14 = spreadsheetDate4.toSerial();
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) ' ');
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate3);
        java.lang.String str5 = day4.toString();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day4);
        int int7 = timeSeries1.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getFirstMillisecond();
        int int13 = year11.getYear();
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries9.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (org.jfree.data.time.RegularTimePeriod) year11);
        boolean boolean15 = timeSeries1.equals((java.lang.Object) year11);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent16 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeries1);
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener17);
        boolean boolean19 = timeSeries1.isEmpty();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "9-January-1900" + "'", str5.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1546329600000L + "'", long12 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        int int2 = year0.getYear();
        int int3 = year0.getYear();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass9 = spreadsheetDate8.getClass();
        boolean boolean10 = spreadsheetDate5.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate13 = spreadsheetDate8.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass16 = spreadsheetDate15.getClass();
        boolean boolean17 = spreadsheetDate8.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean18 = year0.equals((java.lang.Object) spreadsheetDate15);
        spreadsheetDate15.setDescription("Last");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2958465, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate10 = spreadsheetDate6.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass13 = spreadsheetDate12.getClass();
        java.util.Date date14 = null;
        java.util.TimeZone timeZone15 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date14, timeZone15);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate9, (java.lang.Class) wildcardClass13);
        boolean boolean18 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate4, (org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate9);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.lang.String str21 = year20.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass26 = spreadsheetDate25.getClass();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str21, "", "9-January-1900", (java.lang.Class) wildcardClass26);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year28.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries27.getDataItem(regularTimePeriod29);
        java.util.Collection collection31 = timeSeries19.getTimePeriodsUniqueToOtherSeries(timeSeries27);
        java.util.List list32 = timeSeries19.getItems();
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2019" + "'", str21.equals("2019"));
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNull(timeSeriesDataItem30);
        org.junit.Assert.assertNotNull(collection31);
        org.junit.Assert.assertNotNull(list32);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate5 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass8 = spreadsheetDate7.getClass();
        java.util.Date date9 = null;
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date9, timeZone10);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate4, (java.lang.Class) wildcardClass8);
        boolean boolean13 = timeSeries12.isEmpty();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass19 = spreadsheetDate18.getClass();
        boolean boolean20 = spreadsheetDate15.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass25 = spreadsheetDate24.getClass();
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean20, "December", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass25);
        boolean boolean27 = timeSeries26.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries12.addAndOrUpdate(timeSeries26);
        try {
            timeSeries12.setMaximumItemAge((long) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'periods' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(timeSeries28);
    }

//    @Test
//    public void test296() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test296");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
//        long long4 = year3.getFirstMillisecond();
//        int int5 = year3.getYear();
//        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2, (org.jfree.data.time.RegularTimePeriod) year3);
//        long long7 = fixedMillisecond2.getFirstMillisecond();
//        long long8 = fixedMillisecond2.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertNotNull(timeSeries6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560192944531L + "'", long7 == 1560192944531L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560192944531L + "'", long8 == 1560192944531L);
//    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(4, false);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "April" + "'", str2.equals("April"));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate11 = spreadsheetDate7.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass14 = spreadsheetDate13.getClass();
        java.util.Date date15 = null;
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass14, date15, timeZone16);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate10, (java.lang.Class) wildcardClass14);
        boolean boolean19 = spreadsheetDate2.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate5, (org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SerialDate serialDate21 = spreadsheetDate2.getFollowingDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addMonths(2, serialDate21);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 0, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        timeSeries1.clear();
        timeSeries1.clear();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate9);
        java.lang.String str11 = day10.toString();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) day10);
        int int13 = day10.getDayOfMonth();
        long long14 = day10.getSerialIndex();
        int int15 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) day10);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate19);
        java.lang.String str21 = day20.toString();
        timeSeries17.delete((org.jfree.data.time.RegularTimePeriod) day20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day20.previous();
        java.lang.String str24 = day20.toString();
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        long long29 = year28.getFirstMillisecond();
        int int30 = year28.getYear();
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries26.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, (org.jfree.data.time.RegularTimePeriod) year28);
        int int32 = day20.compareTo((java.lang.Object) timeSeries26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = day20.previous();
        try {
            org.jfree.data.time.TimeSeries timeSeries34 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) day10, regularTimePeriod33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start on or before end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "9-January-1900" + "'", str11.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 9 + "'", int13 == 9);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "9-January-1900" + "'", str21.equals("9-January-1900"));
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "9-January-1900" + "'", str24.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1546329600000L + "'", long29 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
        org.junit.Assert.assertNotNull(timeSeries31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
    }

//    @Test
//    public void test301() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test301");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.next();
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond0.getLastMillisecond(calendar2);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560192944834L + "'", long3 == 1560192944834L);
//    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        long long4 = year3.getFirstMillisecond();
        int int5 = year3.getYear();
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2, (org.jfree.data.time.RegularTimePeriod) year3);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.lang.String str9 = year8.toString();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (byte) 10, year8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass16 = spreadsheetDate15.getClass();
        boolean boolean17 = spreadsheetDate12.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate23 = spreadsheetDate19.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate22);
        boolean boolean24 = spreadsheetDate15.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month10, (org.jfree.data.time.RegularTimePeriod) day25);
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        timeSeries28.clear();
        timeSeries28.clear();
        int int31 = day25.compareTo((java.lang.Object) timeSeries28);
        int int32 = day25.getMonth();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = spreadsheetDate4.getClass();
        boolean boolean6 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate12 = spreadsheetDate8.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass19 = spreadsheetDate18.getClass();
        boolean boolean20 = spreadsheetDate15.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addYears((int) '4', (org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SerialDate serialDate22 = spreadsheetDate11.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate18);
        boolean boolean23 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate11);
        try {
            org.jfree.data.time.SerialDate serialDate25 = spreadsheetDate1.getNearestDayOfWeek(1900);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(9999, (-457));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate3);
        java.lang.String str5 = day4.toString();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day4);
        int int7 = timeSeries1.getItemCount();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeries1.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "9-January-1900" + "'", str5.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("Time");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(0, 2019, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        boolean boolean3 = fixedMillisecond1.equals((java.lang.Object) 100.0d);
        int int5 = fixedMillisecond1.compareTo((java.lang.Object) 1);
        long long6 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) 9999);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        boolean boolean10 = timeSeriesDataItem8.equals((java.lang.Object) year9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass17 = spreadsheetDate16.getClass();
        boolean boolean18 = spreadsheetDate13.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addYears((int) '4', (org.jfree.data.time.SerialDate) spreadsheetDate16);
        int int20 = timeSeriesDataItem8.compareTo((java.lang.Object) spreadsheetDate16);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate22);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass26 = spreadsheetDate25.getClass();
        boolean boolean27 = spreadsheetDate22.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate25);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate29);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate33 = spreadsheetDate29.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate32);
        boolean boolean34 = spreadsheetDate25.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate29);
        org.jfree.data.time.SerialDate serialDate35 = spreadsheetDate16.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate25);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate37);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate41 = spreadsheetDate37.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate40);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate44);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass48 = spreadsheetDate47.getClass();
        boolean boolean49 = spreadsheetDate44.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate47);
        org.jfree.data.time.SerialDate serialDate50 = org.jfree.data.time.SerialDate.addYears((int) '4', (org.jfree.data.time.SerialDate) spreadsheetDate47);
        org.jfree.data.time.SerialDate serialDate51 = spreadsheetDate40.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate47);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate53 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate53);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate56 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass57 = spreadsheetDate56.getClass();
        boolean boolean58 = spreadsheetDate53.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate56);
        org.jfree.data.time.FixedMillisecond fixedMillisecond60 = new org.jfree.data.time.FixedMillisecond(0L);
        boolean boolean62 = fixedMillisecond60.equals((java.lang.Object) 100.0d);
        int int64 = fixedMillisecond60.compareTo((java.lang.Object) 1);
        long long65 = fixedMillisecond60.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem67 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond60, (double) 9999);
        org.jfree.data.time.Year year68 = new org.jfree.data.time.Year();
        boolean boolean69 = timeSeriesDataItem67.equals((java.lang.Object) year68);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate72 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day73 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate72);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate75 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass76 = spreadsheetDate75.getClass();
        boolean boolean77 = spreadsheetDate72.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate75);
        org.jfree.data.time.SerialDate serialDate78 = org.jfree.data.time.SerialDate.addYears((int) '4', (org.jfree.data.time.SerialDate) spreadsheetDate75);
        int int79 = timeSeriesDataItem67.compareTo((java.lang.Object) spreadsheetDate75);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate81 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day82 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate81);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate84 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass85 = spreadsheetDate84.getClass();
        boolean boolean86 = spreadsheetDate81.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate84);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate88 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day89 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate88);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate91 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate92 = spreadsheetDate88.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate91);
        boolean boolean93 = spreadsheetDate84.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate88);
        org.jfree.data.time.SerialDate serialDate94 = spreadsheetDate75.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate84);
        boolean boolean95 = spreadsheetDate53.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate75);
        boolean boolean97 = spreadsheetDate25.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate47, (org.jfree.data.time.SerialDate) spreadsheetDate75, (int) '#');
        org.jfree.data.time.Day day98 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate25);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertNotNull(wildcardClass48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertNotNull(wildcardClass57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1 + "'", int64 == 1);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 0L + "'", long65 == 0L);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(wildcardClass76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(serialDate78);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 1 + "'", int79 == 1);
        org.junit.Assert.assertNotNull(wildcardClass85);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertNotNull(serialDate92);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + true + "'", boolean93 == true);
        org.junit.Assert.assertNotNull(serialDate94);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + true + "'", boolean95 == true);
        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + false + "'", boolean97 == false);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        long long4 = year3.getFirstMillisecond();
        int int5 = year3.getYear();
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2, (org.jfree.data.time.RegularTimePeriod) year3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date8 = fixedMillisecond7.getTime();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date8);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        boolean boolean12 = month9.equals((java.lang.Object) timeSeries11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month9.previous();
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month9, (java.lang.Number) 1.0d, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate5);
        java.lang.String str7 = day6.toString();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) day6);
        int int9 = day6.getDayOfMonth();
        long long10 = day6.getSerialIndex();
        int int11 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) day6);
        timeSeries1.setMaximumItemAge((long) '4');
        timeSeries1.setDescription("");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = null;
        try {
            java.lang.Number number17 = timeSeries1.getValue(regularTimePeriod16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "9-January-1900" + "'", str7.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        long long4 = year3.getFirstMillisecond();
        int int5 = year3.getYear();
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2, (org.jfree.data.time.RegularTimePeriod) year3);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries6.addChangeListener(seriesChangeListener7);
        boolean boolean9 = timeSeries6.getNotify();
        boolean boolean10 = timeSeries6.getNotify();
        try {
            timeSeries6.delete(1900, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        long long4 = year3.getFirstMillisecond();
        int int5 = year3.getYear();
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2, (org.jfree.data.time.RegularTimePeriod) year3);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate10);
        java.lang.String str12 = day11.toString();
        timeSeries8.delete((org.jfree.data.time.RegularTimePeriod) day11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day11.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day11, (java.lang.Number) 1L);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate20);
        java.lang.String str22 = day21.toString();
        timeSeries18.delete((org.jfree.data.time.RegularTimePeriod) day21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day21.previous();
        java.lang.String str25 = day21.toString();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate29);
        java.lang.String str31 = day30.toString();
        timeSeries27.delete((org.jfree.data.time.RegularTimePeriod) day30);
        int int33 = day30.getDayOfMonth();
        long long34 = day30.getSerialIndex();
        int int35 = day30.getDayOfMonth();
        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) day21, (org.jfree.data.time.RegularTimePeriod) day30);
        timeSeries1.removeAgedItems(true);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "9-January-1900" + "'", str12.equals("9-January-1900"));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "9-January-1900" + "'", str22.equals("9-January-1900"));
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "9-January-1900" + "'", str25.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "9-January-1900" + "'", str31.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 9 + "'", int33 == 9);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 10L + "'", long34 == 10L);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 9 + "'", int35 == 9);
        org.junit.Assert.assertNotNull(timeSeries36);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate5);
        java.lang.String str7 = day6.toString();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) day6);
        int int9 = day6.getDayOfMonth();
        long long10 = day6.getSerialIndex();
        int int11 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) day6);
        timeSeries1.setMaximumItemAge((long) '4');
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(0L);
        boolean boolean17 = fixedMillisecond15.equals((java.lang.Object) 100.0d);
        int int19 = fixedMillisecond15.compareTo((java.lang.Object) 1);
        long long20 = fixedMillisecond15.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (double) 9999);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        boolean boolean24 = timeSeriesDataItem22.equals((java.lang.Object) year23);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = timeSeriesDataItem22.getPeriod();
        int int26 = timeSeries1.getIndex(regularTimePeriod25);
        java.util.Collection collection27 = timeSeries1.getTimePeriods();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "9-January-1900" + "'", str7.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(collection27);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        long long4 = year3.getFirstMillisecond();
        int int5 = year3.getYear();
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2, (org.jfree.data.time.RegularTimePeriod) year3);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.createCopy(9, 1900);
        timeSeries9.setDescription("");
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries9);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        int int2 = year0.getYear();
        int int3 = year0.getYear();
        java.lang.String str4 = year0.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(8);
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((int) 'a');
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        boolean boolean3 = fixedMillisecond1.equals((java.lang.Object) 100.0d);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (java.lang.Number) 9);
        long long6 = fixedMillisecond1.getSerialIndex();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(100, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        long long4 = year3.getFirstMillisecond();
        int int5 = year3.getYear();
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2, (org.jfree.data.time.RegularTimePeriod) year3);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.lang.String str9 = year8.toString();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (byte) 10, year8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass16 = spreadsheetDate15.getClass();
        boolean boolean17 = spreadsheetDate12.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate23 = spreadsheetDate19.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate22);
        boolean boolean24 = spreadsheetDate15.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month10, (org.jfree.data.time.RegularTimePeriod) day25);
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        timeSeries28.clear();
        timeSeries28.clear();
        int int31 = day25.compareTo((java.lang.Object) timeSeries28);
        timeSeries28.removeAgedItems((long) '4', true);
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
        long long39 = year38.getFirstMillisecond();
        int int40 = year38.getYear();
        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries36.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond37, (org.jfree.data.time.RegularTimePeriod) year38);
        try {
            timeSeries28.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond37, (java.lang.Number) 2019L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1546329600000L + "'", long39 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2019 + "'", int40 == 2019);
        org.junit.Assert.assertNotNull(timeSeries41);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate7 = spreadsheetDate3.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate6);
        int int8 = year0.compareTo((java.lang.Object) spreadsheetDate3);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate3);
        try {
            org.jfree.data.time.SerialDate serialDate11 = spreadsheetDate3.getPreviousDayOfWeek(13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("Thursday");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 5 + "'", int1 == 5);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        java.lang.String str2 = year1.toString();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (byte) 10, year1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.previous();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = month3.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate3);
        java.lang.String str5 = day4.toString();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day4.previous();
        java.util.Date date8 = day4.getStart();
        java.lang.String str9 = day4.toString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "9-January-1900" + "'", str5.equals("9-January-1900"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "9-January-1900" + "'", str9.equals("9-January-1900"));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        long long4 = year3.getFirstMillisecond();
        int int5 = year3.getYear();
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2, (org.jfree.data.time.RegularTimePeriod) year3);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate10);
        java.lang.String str12 = day11.toString();
        timeSeries8.delete((org.jfree.data.time.RegularTimePeriod) day11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day11.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day11, (java.lang.Number) 1L);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate20);
        java.lang.String str22 = day21.toString();
        timeSeries18.delete((org.jfree.data.time.RegularTimePeriod) day21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day21.previous();
        java.lang.String str25 = day21.toString();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate29);
        java.lang.String str31 = day30.toString();
        timeSeries27.delete((org.jfree.data.time.RegularTimePeriod) day30);
        int int33 = day30.getDayOfMonth();
        long long34 = day30.getSerialIndex();
        int int35 = day30.getDayOfMonth();
        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) day21, (org.jfree.data.time.RegularTimePeriod) day30);
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate40);
        java.lang.String str42 = day41.toString();
        timeSeries38.delete((org.jfree.data.time.RegularTimePeriod) day41);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = day41.previous();
        java.lang.String str45 = day41.toString();
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year();
        long long50 = year49.getFirstMillisecond();
        int int51 = year49.getYear();
        org.jfree.data.time.TimeSeries timeSeries52 = timeSeries47.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond48, (org.jfree.data.time.RegularTimePeriod) year49);
        int int53 = day41.compareTo((java.lang.Object) timeSeries47);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem55 = timeSeries36.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day41, (double) (short) 10);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener56 = null;
        timeSeries36.addChangeListener(seriesChangeListener56);
        org.jfree.data.time.FixedMillisecond fixedMillisecond59 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        try {
            timeSeries36.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond59, (double) 1560192944834L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "9-January-1900" + "'", str12.equals("9-January-1900"));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "9-January-1900" + "'", str22.equals("9-January-1900"));
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "9-January-1900" + "'", str25.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "9-January-1900" + "'", str31.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 9 + "'", int33 == 9);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 10L + "'", long34 == 10L);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 9 + "'", int35 == 9);
        org.junit.Assert.assertNotNull(timeSeries36);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "9-January-1900" + "'", str42.equals("9-January-1900"));
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "9-January-1900" + "'", str45.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1546329600000L + "'", long50 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 2019 + "'", int51 == 2019);
        org.junit.Assert.assertNotNull(timeSeries52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
        org.junit.Assert.assertNotNull(timeSeriesDataItem55);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        long long4 = year3.getFirstMillisecond();
        int int5 = year3.getYear();
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2, (org.jfree.data.time.RegularTimePeriod) year3);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.lang.String str9 = year8.toString();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (byte) 10, year8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass16 = spreadsheetDate15.getClass();
        boolean boolean17 = spreadsheetDate12.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate23 = spreadsheetDate19.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate22);
        boolean boolean24 = spreadsheetDate15.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month10, (org.jfree.data.time.RegularTimePeriod) day25);
        java.util.Collection collection27 = timeSeries26.getTimePeriods();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries26.getDataItem((-457));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertNotNull(collection27);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate5);
        java.lang.String str7 = day6.toString();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) day6);
        int int9 = day6.getDayOfMonth();
        long long10 = day6.getSerialIndex();
        int int11 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) day6);
        timeSeries1.setMaximumItemCount(12);
        java.lang.String str14 = timeSeries1.getDomainDescription();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        java.lang.String str16 = year15.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass21 = spreadsheetDate20.getClass();
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str16, "", "9-January-1900", (java.lang.Class) wildcardClass21);
        timeSeries22.clear();
        java.util.Collection collection24 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries22);
        timeSeries22.clear();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener26 = null;
        timeSeries22.addChangeListener(seriesChangeListener26);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "9-January-1900" + "'", str7.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Time" + "'", str14.equals("Time"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "2019" + "'", str16.equals("2019"));
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(collection24);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate3);
        java.lang.String str5 = day4.toString();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day4);
        int int7 = timeSeries1.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getFirstMillisecond();
        int int13 = year11.getYear();
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries9.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (org.jfree.data.time.RegularTimePeriod) year11);
        boolean boolean15 = timeSeries1.equals((java.lang.Object) year11);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries1.createCopy(9999, 2147483647);
        timeSeries1.setMaximumItemAge(1569913200000L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "9-January-1900" + "'", str5.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1546329600000L + "'", long12 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(timeSeries18);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) 0, 30, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        int int5 = fixedMillisecond1.compareTo((java.lang.Object) (-1L));
        long long6 = fixedMillisecond1.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate5 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass8 = spreadsheetDate7.getClass();
        java.util.Date date9 = null;
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date9, timeZone10);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate4, (java.lang.Class) wildcardClass8);
        java.lang.Comparable comparable13 = timeSeries12.getKey();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate17);
        java.lang.String str19 = day18.toString();
        timeSeries15.delete((org.jfree.data.time.RegularTimePeriod) day18);
        int int21 = day18.getDayOfMonth();
        long long22 = day18.getSerialIndex();
        int int23 = day18.getDayOfMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries12.getDataItem((org.jfree.data.time.RegularTimePeriod) day18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond(0L);
        boolean boolean28 = fixedMillisecond26.equals((java.lang.Object) 100.0d);
        int int30 = fixedMillisecond26.compareTo((java.lang.Object) 1);
        long long31 = fixedMillisecond26.getMiddleMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = fixedMillisecond32.next();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, regularTimePeriod33);
        timeSeries12.setNotify(false);
        java.util.List list37 = timeSeries12.getItems();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = timeSeries12.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(comparable13);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "9-January-1900" + "'", str19.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 9 + "'", int21 == 9);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 10L + "'", long22 == 10L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 9 + "'", int23 == 9);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertNotNull(list37);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass6 = spreadsheetDate5.getClass();
        boolean boolean7 = spreadsheetDate2.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addMonths((int) (short) 0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        try {
            org.jfree.data.time.SerialDate serialDate10 = serialDate8.getPreviousDayOfWeek(11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(serialDate8);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Nearest");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        java.lang.Throwable[] throwableArray3 = seriesException1.getSuppressed();
        java.lang.Throwable[] throwableArray4 = seriesException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass10 = spreadsheetDate9.getClass();
        boolean boolean11 = spreadsheetDate6.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass16 = spreadsheetDate15.getClass();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean11, "December", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass16);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date1, "Thursday", "Thursday", (java.lang.Class) wildcardClass16);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate24 = spreadsheetDate20.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate23);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate27);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass31 = spreadsheetDate30.getClass();
        boolean boolean32 = spreadsheetDate27.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate30);
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.addYears((int) '4', (org.jfree.data.time.SerialDate) spreadsheetDate30);
        org.jfree.data.time.SerialDate serialDate34 = spreadsheetDate23.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate30);
        java.lang.Class<?> wildcardClass35 = spreadsheetDate23.getClass();
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate39);
        java.lang.String str41 = day40.toString();
        timeSeries37.delete((org.jfree.data.time.RegularTimePeriod) day40);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = day40.previous();
        java.util.Date date44 = day40.getStart();
        java.util.TimeZone timeZone45 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass35, date44, timeZone45);
        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month(date1, timeZone45);
        java.util.Calendar calendar48 = null;
        try {
            long long49 = month47.getFirstMillisecond(calendar48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "9-January-1900" + "'", str41.equals("9-January-1900"));
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(timeZone45);
        org.junit.Assert.assertNull(regularTimePeriod46);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate5 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass12 = spreadsheetDate11.getClass();
        boolean boolean13 = spreadsheetDate8.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addYears((int) '4', (org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SerialDate serialDate15 = spreadsheetDate4.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate11);
        java.lang.Class<?> wildcardClass16 = spreadsheetDate4.getClass();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate20);
        java.lang.String str22 = day21.toString();
        timeSeries18.delete((org.jfree.data.time.RegularTimePeriod) day21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day21.previous();
        java.util.Date date25 = day21.getStart();
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date25, timeZone26);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date25);
        java.util.Calendar calendar29 = null;
        try {
            long long30 = year28.getFirstMillisecond(calendar29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "9-January-1900" + "'", str22.equals("9-January-1900"));
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNull(regularTimePeriod27);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) (short) 10, (-457));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate3);
        java.lang.String str5 = day4.toString();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day4);
        int int7 = day4.getDayOfMonth();
        long long8 = day4.getSerialIndex();
        int int9 = day4.getDayOfMonth();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate15);
        java.lang.String str17 = day16.toString();
        timeSeries13.delete((org.jfree.data.time.RegularTimePeriod) day16);
        int int19 = day16.getDayOfMonth();
        long long20 = day16.getSerialIndex();
        int int21 = timeSeries11.getIndex((org.jfree.data.time.RegularTimePeriod) day16);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate23);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate27 = spreadsheetDate23.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate26);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass30 = spreadsheetDate29.getClass();
        java.util.Date date31 = null;
        java.util.TimeZone timeZone32 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date31, timeZone32);
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate26, (java.lang.Class) wildcardClass30);
        java.lang.Comparable comparable35 = timeSeries34.getKey();
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate39);
        java.lang.String str41 = day40.toString();
        timeSeries37.delete((org.jfree.data.time.RegularTimePeriod) day40);
        int int43 = day40.getDayOfMonth();
        long long44 = day40.getSerialIndex();
        int int45 = day40.getDayOfMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = timeSeries34.getDataItem((org.jfree.data.time.RegularTimePeriod) day40);
        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond(0L);
        boolean boolean50 = fixedMillisecond48.equals((java.lang.Object) 100.0d);
        int int52 = fixedMillisecond48.compareTo((java.lang.Object) 1);
        long long53 = fixedMillisecond48.getMiddleMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = fixedMillisecond54.next();
        org.jfree.data.time.TimeSeries timeSeries56 = timeSeries34.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond48, regularTimePeriod55);
        org.jfree.data.time.FixedMillisecond fixedMillisecond58 = new org.jfree.data.time.FixedMillisecond(0L);
        boolean boolean60 = fixedMillisecond58.equals((java.lang.Object) 100.0d);
        timeSeries34.setKey((java.lang.Comparable) boolean60);
        java.util.Collection collection62 = timeSeries11.getTimePeriodsUniqueToOtherSeries(timeSeries34);
        org.jfree.data.time.TimeSeries timeSeries64 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond65 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year66 = new org.jfree.data.time.Year();
        long long67 = year66.getFirstMillisecond();
        int int68 = year66.getYear();
        org.jfree.data.time.TimeSeries timeSeries69 = timeSeries64.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond65, (org.jfree.data.time.RegularTimePeriod) year66);
        org.jfree.data.time.TimeSeries timeSeries71 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate73 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day74 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate73);
        java.lang.String str75 = day74.toString();
        timeSeries71.delete((org.jfree.data.time.RegularTimePeriod) day74);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = day74.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem79 = timeSeries64.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day74, (java.lang.Number) 1L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = day74.next();
        timeSeries11.add(regularTimePeriod80, (java.lang.Number) 0L);
        boolean boolean83 = day4.equals((java.lang.Object) regularTimePeriod80);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "9-January-1900" + "'", str5.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9 + "'", int7 == 9);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "9-January-1900" + "'", str17.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 9 + "'", int19 == 9);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 10L + "'", long20 == 10L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(comparable35);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "9-January-1900" + "'", str41.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 9 + "'", int43 == 9);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 10L + "'", long44 == 10L);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 9 + "'", int45 == 9);
        org.junit.Assert.assertNull(timeSeriesDataItem46);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 0L + "'", long53 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod55);
        org.junit.Assert.assertNotNull(timeSeries56);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(collection62);
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 1546329600000L + "'", long67 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 2019 + "'", int68 == 2019);
        org.junit.Assert.assertNotNull(timeSeries69);
        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "9-January-1900" + "'", str75.equals("9-January-1900"));
        org.junit.Assert.assertNotNull(regularTimePeriod77);
        org.junit.Assert.assertNull(timeSeriesDataItem79);
        org.junit.Assert.assertNotNull(regularTimePeriod80);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate7 = spreadsheetDate3.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate6);
        int int8 = year0.compareTo((java.lang.Object) spreadsheetDate3);
        java.util.Calendar calendar9 = null;
        try {
            long long10 = year0.getFirstMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        long long4 = year3.getFirstMillisecond();
        int int5 = year3.getYear();
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2, (org.jfree.data.time.RegularTimePeriod) year3);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.lang.String str9 = year8.toString();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (byte) 10, year8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass16 = spreadsheetDate15.getClass();
        boolean boolean17 = spreadsheetDate12.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate23 = spreadsheetDate19.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate22);
        boolean boolean24 = spreadsheetDate15.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month10, (org.jfree.data.time.RegularTimePeriod) day25);
        java.lang.Comparable comparable27 = timeSeries26.getKey();
        boolean boolean28 = timeSeries26.isEmpty();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertTrue("'" + comparable27 + "' != '" + 'a' + "'", comparable27.equals('a'));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (java.lang.Number) 11);
        java.lang.Object obj4 = null;
        boolean boolean5 = timeSeriesDataItem3.equals(obj4);
        timeSeriesDataItem3.setValue((java.lang.Number) (short) 100);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate11);
        java.lang.String str13 = day12.toString();
        timeSeries9.delete((org.jfree.data.time.RegularTimePeriod) day12);
        int int15 = timeSeries9.getItemCount();
        timeSeries9.removeAgedItems((long) 4, true);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        long long23 = year22.getFirstMillisecond();
        int int24 = year22.getYear();
        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries20.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, (org.jfree.data.time.RegularTimePeriod) year22);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener26 = null;
        timeSeries25.addChangeListener(seriesChangeListener26);
        boolean boolean28 = timeSeries25.getNotify();
        java.util.Collection collection29 = timeSeries9.getTimePeriodsUniqueToOtherSeries(timeSeries25);
        boolean boolean30 = timeSeriesDataItem3.equals((java.lang.Object) collection29);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "9-January-1900" + "'", str13.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1546329600000L + "'", long23 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
        org.junit.Assert.assertNotNull(timeSeries25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(collection29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate6);
        java.lang.String str8 = day7.toString();
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day7);
        int int10 = timeSeries4.getItemCount();
        timeSeries4.removeAgedItems((long) 4, true);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getFirstMillisecond();
        int int19 = year17.getYear();
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16, (org.jfree.data.time.RegularTimePeriod) year17);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener21 = null;
        timeSeries20.addChangeListener(seriesChangeListener21);
        boolean boolean23 = timeSeries20.getNotify();
        java.util.Collection collection24 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries20);
        java.lang.Object obj25 = null;
        boolean boolean26 = timeSeries20.equals(obj25);
        boolean boolean27 = year0.equals(obj25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year0.previous();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "9-January-1900" + "'", str8.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1546329600000L + "'", long18 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(collection24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
    }

//    @Test
//    public void test345() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test345");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
//        long long4 = year3.getFirstMillisecond();
//        int int5 = year3.getYear();
//        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2, (org.jfree.data.time.RegularTimePeriod) year3);
//        long long7 = fixedMillisecond2.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertNotNull(timeSeries6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560192949682L + "'", long7 == 1560192949682L);
//    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        long long4 = year3.getFirstMillisecond();
        int int5 = year3.getYear();
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2, (org.jfree.data.time.RegularTimePeriod) year3);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.createCopy(9, 1900);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        java.lang.String str12 = year11.toString();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 10, year11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month13.previous();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate20 = spreadsheetDate16.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate19);
        boolean boolean21 = month13.equals((java.lang.Object) spreadsheetDate16);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month13, (java.lang.Number) 9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond(0L);
        boolean boolean27 = fixedMillisecond25.equals((java.lang.Object) 100.0d);
        int int29 = fixedMillisecond25.compareTo((java.lang.Object) 1);
        long long30 = fixedMillisecond25.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, (double) 9999);
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        boolean boolean34 = timeSeriesDataItem32.equals((java.lang.Object) year33);
        java.lang.Object obj35 = timeSeriesDataItem32.clone();
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate39);
        java.lang.String str41 = day40.toString();
        timeSeries37.delete((org.jfree.data.time.RegularTimePeriod) day40);
        int int43 = timeSeries37.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year();
        long long48 = year47.getFirstMillisecond();
        int int49 = year47.getYear();
        org.jfree.data.time.TimeSeries timeSeries50 = timeSeries45.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond46, (org.jfree.data.time.RegularTimePeriod) year47);
        boolean boolean51 = timeSeries37.equals((java.lang.Object) year47);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent52 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeries37);
        boolean boolean53 = timeSeriesDataItem32.equals((java.lang.Object) seriesChangeEvent52);
        try {
            timeSeries9.add(timeSeriesDataItem32, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2019" + "'", str12.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(obj35);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "9-January-1900" + "'", str41.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1546329600000L + "'", long48 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 2019 + "'", int49 == 2019);
        org.junit.Assert.assertNotNull(timeSeries50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate3);
        java.lang.String str5 = day4.toString();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day4);
        int int7 = day4.getDayOfMonth();
        long long8 = day4.getSerialIndex();
        int int9 = day4.getYear();
        int int10 = day4.getDayOfMonth();
        java.util.Calendar calendar11 = null;
        try {
            long long12 = day4.getLastMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "9-January-1900" + "'", str5.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9 + "'", int7 == 9);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1900 + "'", int9 == 1900);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 9 + "'", int10 == 9);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) (byte) -1, 13);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate3);
        java.lang.String str5 = day4.toString();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day4);
        int int7 = day4.getDayOfMonth();
        long long8 = day4.getSerialIndex();
        int int9 = day4.getYear();
        int int10 = day4.getDayOfMonth();
        long long11 = day4.getSerialIndex();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "9-January-1900" + "'", str5.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9 + "'", int7 == 9);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1900 + "'", int9 == 1900);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 9 + "'", int10 == 9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date3 = spreadsheetDate2.toDate();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date3);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(10, year5);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate4);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate6);
        java.lang.String str8 = day7.toString();
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day7);
        int int10 = timeSeries4.getItemCount();
        timeSeries4.removeAgedItems((long) 4, true);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getFirstMillisecond();
        int int19 = year17.getYear();
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16, (org.jfree.data.time.RegularTimePeriod) year17);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener21 = null;
        timeSeries20.addChangeListener(seriesChangeListener21);
        boolean boolean23 = timeSeries20.getNotify();
        java.util.Collection collection24 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries20);
        java.lang.Object obj25 = null;
        boolean boolean26 = timeSeries20.equals(obj25);
        boolean boolean27 = year0.equals(obj25);
        java.util.Calendar calendar28 = null;
        try {
            long long29 = year0.getFirstMillisecond(calendar28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "9-January-1900" + "'", str8.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1546329600000L + "'", long18 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(collection24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate5);
        java.lang.String str7 = day6.toString();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) day6);
        int int9 = day6.getDayOfMonth();
        long long10 = day6.getSerialIndex();
        int int11 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) day6);
        timeSeries1.setMaximumItemCount(12);
        java.lang.String str14 = timeSeries1.getDomainDescription();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        java.lang.String str16 = year15.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass21 = spreadsheetDate20.getClass();
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str16, "", "9-January-1900", (java.lang.Class) wildcardClass21);
        timeSeries22.clear();
        java.util.Collection collection24 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries22);
        timeSeries22.clear();
        try {
            timeSeries22.update(12, (java.lang.Number) 1560192922559L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 12, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "9-January-1900" + "'", str7.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Time" + "'", str14.equals("Time"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "2019" + "'", str16.equals("2019"));
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(collection24);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate3);
        java.lang.String str5 = day4.toString();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day4.previous();
        java.lang.String str8 = day4.toString();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getFirstMillisecond();
        int int14 = year12.getYear();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (org.jfree.data.time.RegularTimePeriod) year12);
        int int16 = day4.compareTo((java.lang.Object) timeSeries10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day4.previous();
        java.util.Calendar calendar18 = null;
        try {
            long long19 = day4.getFirstMillisecond(calendar18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "9-January-1900" + "'", str5.equals("9-January-1900"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "9-January-1900" + "'", str8.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate3);
        java.lang.String str5 = day4.toString();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day4);
        int int7 = day4.getDayOfMonth();
        long long8 = day4.getSerialIndex();
        int int9 = day4.getYear();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass12 = spreadsheetDate11.getClass();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, (java.lang.Class) wildcardClass12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate19 = spreadsheetDate15.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass22 = spreadsheetDate21.getClass();
        java.util.Date date23 = null;
        java.util.TimeZone timeZone24 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass22, date23, timeZone24);
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate18, (java.lang.Class) wildcardClass22);
        java.lang.Comparable comparable27 = timeSeries26.getKey();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate31);
        java.lang.String str33 = day32.toString();
        timeSeries29.delete((org.jfree.data.time.RegularTimePeriod) day32);
        int int35 = day32.getDayOfMonth();
        long long36 = day32.getSerialIndex();
        int int37 = day32.getDayOfMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries26.getDataItem((org.jfree.data.time.RegularTimePeriod) day32);
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond(0L);
        boolean boolean42 = fixedMillisecond40.equals((java.lang.Object) 100.0d);
        int int44 = fixedMillisecond40.compareTo((java.lang.Object) 1);
        long long45 = fixedMillisecond40.getMiddleMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = fixedMillisecond46.next();
        org.jfree.data.time.TimeSeries timeSeries48 = timeSeries26.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40, regularTimePeriod47);
        timeSeries26.setNotify(false);
        timeSeries26.clear();
        java.util.Collection collection52 = timeSeries13.getTimePeriodsUniqueToOtherSeries(timeSeries26);
        int int53 = timeSeries13.getItemCount();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "9-January-1900" + "'", str5.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9 + "'", int7 == 9);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1900 + "'", int9 == 1900);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(comparable27);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "9-January-1900" + "'", str33.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 9 + "'", int35 == 9);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 10L + "'", long36 == 10L);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 9 + "'", int37 == 9);
        org.junit.Assert.assertNull(timeSeriesDataItem38);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 0L + "'", long45 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod47);
        org.junit.Assert.assertNotNull(timeSeries48);
        org.junit.Assert.assertNotNull(collection52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate3);
        java.lang.String str5 = day4.toString();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day4.previous();
        java.util.Date date8 = day4.getStart();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date8);
        long long10 = month9.getSerialIndex();
        long long11 = month9.getLastMillisecond();
        java.lang.String str12 = month9.toString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "9-January-1900" + "'", str5.equals("9-January-1900"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 22801L + "'", long10 == 22801L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-2206281600001L) + "'", long11 == (-2206281600001L));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "January 1900" + "'", str12.equals("January 1900"));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(date1);
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date1, timeZone4);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(timeZone4);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate11 = spreadsheetDate7.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass14 = spreadsheetDate13.getClass();
        java.util.Date date15 = null;
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass14, date15, timeZone16);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate10, (java.lang.Class) wildcardClass14);
        boolean boolean19 = spreadsheetDate2.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate5, (org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(9);
        int int22 = spreadsheetDate21.getDayOfMonth();
        int int23 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate21);
        try {
            org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) '4', (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 8 + "'", int22 == 8);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        long long4 = year3.getFirstMillisecond();
        int int5 = year3.getYear();
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2, (org.jfree.data.time.RegularTimePeriod) year3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        long long9 = fixedMillisecond8.getMiddleMillisecond();
        int int10 = year3.compareTo((java.lang.Object) long9);
        java.util.Calendar calendar11 = null;
        try {
            long long12 = year3.getLastMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (byte) 10);
        int int4 = year0.getYear();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.lang.String str7 = year6.toString();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (byte) 10, year6);
        long long9 = month8.getLastMillisecond();
        java.lang.String str10 = month8.toString();
        int int11 = year0.compareTo((java.lang.Object) month8);
        long long12 = year0.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1572591599999L + "'", long9 == 1572591599999L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "October 2019" + "'", str10.equals("October 2019"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1546329600000L + "'", long12 == 1546329600000L);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("October 2019");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 0, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        java.lang.String str2 = year1.toString();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (byte) 10, year1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.previous();
        boolean boolean6 = month3.equals((java.lang.Object) 11);
        long long7 = month3.getFirstMillisecond();
        java.util.Calendar calendar8 = null;
        try {
            month3.peg(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1569913200000L + "'", long7 == 1569913200000L);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        timeSeries1.clear();
        java.lang.Comparable comparable3 = timeSeries1.getKey();
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate(regularTimePeriod6, (java.lang.Number) 0.0f);
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond(0L);
        boolean boolean14 = fixedMillisecond12.equals((java.lang.Object) 100.0d);
        int int16 = fixedMillisecond12.compareTo((java.lang.Object) 1);
        long long17 = fixedMillisecond12.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (double) 9999);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        boolean boolean21 = timeSeriesDataItem19.equals((java.lang.Object) year20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate24);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass28 = spreadsheetDate27.getClass();
        boolean boolean29 = spreadsheetDate24.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate27);
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.addYears((int) '4', (org.jfree.data.time.SerialDate) spreadsheetDate27);
        int int31 = timeSeriesDataItem19.compareTo((java.lang.Object) spreadsheetDate27);
        java.lang.Number number32 = timeSeriesDataItem19.getValue();
        try {
            timeSeries1.add(timeSeriesDataItem19, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + 'a' + "'", comparable3.equals('a'));
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 'a' + "'", comparable4.equals('a'));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + number32 + "' != '" + 9999.0d + "'", number32.equals(9999.0d));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = spreadsheetDate4.getClass();
        boolean boolean6 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate12 = spreadsheetDate8.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate11);
        boolean boolean13 = spreadsheetDate4.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar17 = null;
        long long18 = fixedMillisecond16.getLastMillisecond(calendar17);
        int int20 = fixedMillisecond16.compareTo((java.lang.Object) (-1L));
        try {
            int int21 = spreadsheetDate4.compareTo((java.lang.Object) fixedMillisecond16);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.FixedMillisecond cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        long long4 = year3.getFirstMillisecond();
        int int5 = year3.getYear();
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2, (org.jfree.data.time.RegularTimePeriod) year3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        long long9 = fixedMillisecond8.getMiddleMillisecond();
        int int10 = year3.compareTo((java.lang.Object) long9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year3, (java.lang.Number) 1.0f);
        java.util.Calendar calendar13 = null;
        try {
            year3.peg(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(11);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate5 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass8 = spreadsheetDate7.getClass();
        java.util.Date date9 = null;
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date9, timeZone10);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate4, (java.lang.Class) wildcardClass8);
        boolean boolean13 = timeSeries12.isEmpty();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass19 = spreadsheetDate18.getClass();
        boolean boolean20 = spreadsheetDate15.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass25 = spreadsheetDate24.getClass();
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean20, "December", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass25);
        boolean boolean27 = timeSeries26.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries12.addAndOrUpdate(timeSeries26);
        timeSeries12.setDescription("Time");
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date32 = fixedMillisecond31.getTime();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(date32);
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month(date32);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month34, (double) 10.0f);
        java.lang.Object obj37 = timeSeriesDataItem36.clone();
        java.lang.Object obj38 = null;
        boolean boolean39 = timeSeriesDataItem36.equals(obj38);
        try {
            timeSeries12.add(timeSeriesDataItem36);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.SpreadsheetDate.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(obj37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate5);
        java.lang.String str7 = day6.toString();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) day6);
        int int9 = day6.getDayOfMonth();
        long long10 = day6.getSerialIndex();
        int int11 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) day6);
        timeSeries1.setMaximumItemAge((long) '4');
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener14);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = timeSeries1.getTimePeriod((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "9-January-1900" + "'", str7.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = spreadsheetDate4.getClass();
        boolean boolean6 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate9 = spreadsheetDate4.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass12 = spreadsheetDate11.getClass();
        boolean boolean13 = spreadsheetDate4.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate19 = spreadsheetDate15.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate22);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass26 = spreadsheetDate25.getClass();
        boolean boolean27 = spreadsheetDate22.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate25);
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.addYears((int) '4', (org.jfree.data.time.SerialDate) spreadsheetDate25);
        org.jfree.data.time.SerialDate serialDate29 = spreadsheetDate18.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate25);
        int int30 = spreadsheetDate25.getMonth();
        org.jfree.data.time.SerialDate serialDate31 = spreadsheetDate11.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate25);
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(serialDate31);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = day32.previous();
        long long34 = day32.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-2206324800001L) + "'", long34 == (-2206324800001L));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate3);
        java.lang.String str5 = day4.toString();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day4);
        timeSeries1.fireSeriesChanged();
        java.lang.String str8 = timeSeries1.getDescription();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "9-January-1900" + "'", str5.equals("9-January-1900"));
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate5 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass8 = spreadsheetDate7.getClass();
        java.util.Date date9 = null;
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date9, timeZone10);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate4, (java.lang.Class) wildcardClass8);
        java.lang.Comparable comparable13 = timeSeries12.getKey();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate17);
        java.lang.String str19 = day18.toString();
        timeSeries15.delete((org.jfree.data.time.RegularTimePeriod) day18);
        int int21 = day18.getDayOfMonth();
        long long22 = day18.getSerialIndex();
        int int23 = day18.getDayOfMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries12.getDataItem((org.jfree.data.time.RegularTimePeriod) day18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = fixedMillisecond25.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries12.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = fixedMillisecond25.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = fixedMillisecond25.previous();
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(comparable13);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "9-January-1900" + "'", str19.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 9 + "'", int21 == 9);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 10L + "'", long22 == 10L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 9 + "'", int23 == 9);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNull(timeSeriesDataItem27);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate8 = spreadsheetDate4.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass15 = spreadsheetDate14.getClass();
        boolean boolean16 = spreadsheetDate11.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.addYears((int) '4', (org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SerialDate serialDate18 = spreadsheetDate7.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate14);
        java.lang.Class<?> wildcardClass19 = spreadsheetDate7.getClass();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate23);
        java.lang.String str25 = day24.toString();
        timeSeries21.delete((org.jfree.data.time.RegularTimePeriod) day24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = day24.previous();
        java.util.Date date28 = day24.getStart();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date28, timeZone29);
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560192924809L, "Thursday", "Nearest", (java.lang.Class) wildcardClass19);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent32 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) wildcardClass19);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "9-January-1900" + "'", str25.equals("9-January-1900"));
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNull(regularTimePeriod30);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate5 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass8 = spreadsheetDate7.getClass();
        java.util.Date date9 = null;
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date9, timeZone10);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate4, (java.lang.Class) wildcardClass8);
        java.lang.Comparable comparable13 = timeSeries12.getKey();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate17);
        java.lang.String str19 = day18.toString();
        timeSeries15.delete((org.jfree.data.time.RegularTimePeriod) day18);
        int int21 = day18.getDayOfMonth();
        long long22 = day18.getSerialIndex();
        int int23 = day18.getDayOfMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries12.getDataItem((org.jfree.data.time.RegularTimePeriod) day18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond(0L);
        boolean boolean28 = fixedMillisecond26.equals((java.lang.Object) 100.0d);
        int int30 = fixedMillisecond26.compareTo((java.lang.Object) 1);
        long long31 = fixedMillisecond26.getMiddleMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = fixedMillisecond32.next();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, regularTimePeriod33);
        java.util.Date date35 = fixedMillisecond26.getStart();
        long long36 = fixedMillisecond26.getFirstMillisecond();
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(comparable13);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "9-January-1900" + "'", str19.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 9 + "'", int21 == 9);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 10L + "'", long22 == 10L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 9 + "'", int23 == 9);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate3);
        java.lang.String str5 = day4.toString();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day4);
        int int7 = timeSeries1.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getFirstMillisecond();
        int int13 = year11.getYear();
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries9.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (org.jfree.data.time.RegularTimePeriod) year11);
        boolean boolean15 = timeSeries1.equals((java.lang.Object) year11);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries1.createCopy(9999, 2147483647);
        timeSeries1.removeAgedItems((long) 9999, true);
        int int22 = timeSeries1.getItemCount();
        java.util.List list23 = timeSeries1.getItems();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "9-January-1900" + "'", str5.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1546329600000L + "'", long12 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(list23);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        long long4 = year3.getFirstMillisecond();
        int int5 = year3.getYear();
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2, (org.jfree.data.time.RegularTimePeriod) year3);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate10);
        java.lang.String str12 = day11.toString();
        timeSeries8.delete((org.jfree.data.time.RegularTimePeriod) day11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day11.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day11, (java.lang.Number) 1L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day11.next();
        org.jfree.data.time.SerialDate serialDate18 = day11.getSerialDate();
        java.util.Calendar calendar19 = null;
        try {
            long long20 = day11.getLastMillisecond(calendar19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "9-January-1900" + "'", str12.equals("9-January-1900"));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(serialDate18);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate5 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass8 = spreadsheetDate7.getClass();
        java.util.Date date9 = null;
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date9, timeZone10);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate4, (java.lang.Class) wildcardClass8);
        boolean boolean13 = timeSeries12.isEmpty();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass19 = spreadsheetDate18.getClass();
        boolean boolean20 = spreadsheetDate15.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass25 = spreadsheetDate24.getClass();
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean20, "December", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass25);
        boolean boolean27 = timeSeries26.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries12.addAndOrUpdate(timeSeries26);
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
        long long30 = year29.getFirstMillisecond();
        timeSeries12.delete((org.jfree.data.time.RegularTimePeriod) year29);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        long long33 = year32.getFirstMillisecond();
        int int34 = year32.getYear();
        try {
            timeSeries12.add((org.jfree.data.time.RegularTimePeriod) year32, (double) 24234L, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.SpreadsheetDate.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1546329600000L + "'", long30 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1546329600000L + "'", long33 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 2019 + "'", int34 == 2019);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate5);
        java.lang.String str7 = day6.toString();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) day6);
        int int9 = day6.getDayOfMonth();
        long long10 = day6.getSerialIndex();
        int int11 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) day6);
        timeSeries1.setMaximumItemAge((long) '4');
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener14);
        boolean boolean17 = timeSeries1.equals((java.lang.Object) (byte) 1);
        timeSeries1.fireSeriesChanged();
        try {
            timeSeries1.update((int) (short) 0, (java.lang.Number) 1560192915140L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "9-January-1900" + "'", str7.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate7 = spreadsheetDate3.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate6);
        int int8 = year0.compareTo((java.lang.Object) spreadsheetDate3);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.lang.String str11 = year10.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass16 = spreadsheetDate15.getClass();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str11, "", "9-January-1900", (java.lang.Class) wildcardClass16);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year18.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries17.getDataItem(regularTimePeriod19);
        boolean boolean21 = day9.equals((java.lang.Object) regularTimePeriod19);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        long long26 = year25.getFirstMillisecond();
        int int27 = year25.getYear();
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries23.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (org.jfree.data.time.RegularTimePeriod) year25);
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate32);
        java.lang.String str34 = day33.toString();
        timeSeries30.delete((org.jfree.data.time.RegularTimePeriod) day33);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = day33.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries23.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day33, (java.lang.Number) 1L);
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate42);
        java.lang.String str44 = day43.toString();
        timeSeries40.delete((org.jfree.data.time.RegularTimePeriod) day43);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = day43.previous();
        java.lang.String str47 = day43.toString();
        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate51);
        java.lang.String str53 = day52.toString();
        timeSeries49.delete((org.jfree.data.time.RegularTimePeriod) day52);
        int int55 = day52.getDayOfMonth();
        long long56 = day52.getSerialIndex();
        int int57 = day52.getDayOfMonth();
        org.jfree.data.time.TimeSeries timeSeries58 = timeSeries23.createCopy((org.jfree.data.time.RegularTimePeriod) day43, (org.jfree.data.time.RegularTimePeriod) day52);
        long long59 = timeSeries23.getMaximumItemAge();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent60 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeries23);
        int int61 = day9.compareTo((java.lang.Object) seriesChangeEvent60);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2019" + "'", str11.equals("2019"));
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1546329600000L + "'", long26 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "9-January-1900" + "'", str34.equals("9-January-1900"));
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNull(timeSeriesDataItem38);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "9-January-1900" + "'", str44.equals("9-January-1900"));
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "9-January-1900" + "'", str47.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "9-January-1900" + "'", str53.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 9 + "'", int55 == 9);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 10L + "'", long56 == 10L);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 9 + "'", int57 == 9);
        org.junit.Assert.assertNotNull(timeSeries58);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 9223372036854775807L + "'", long59 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1 + "'", int61 == 1);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        boolean boolean3 = fixedMillisecond1.equals((java.lang.Object) 100.0d);
        int int5 = fixedMillisecond1.compareTo((java.lang.Object) 1);
        long long6 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) 9999);
        java.lang.Object obj9 = timeSeriesDataItem8.clone();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = spreadsheetDate4.getClass();
        boolean boolean6 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
        spreadsheetDate1.setDescription("December");
        java.lang.String str9 = spreadsheetDate1.toString();
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "9-January-1900" + "'", str9.equals("9-January-1900"));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = spreadsheetDate4.getClass();
        boolean boolean6 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate12 = spreadsheetDate8.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate11);
        boolean boolean13 = spreadsheetDate4.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate4);
        boolean boolean16 = day14.equals((java.lang.Object) (-452));
        java.util.Calendar calendar17 = null;
        try {
            long long18 = day14.getFirstMillisecond(calendar17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

//    @Test
//    public void test385() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test385");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(9);
//        org.jfree.data.time.SerialDate serialDate5 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate4);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.lang.Class<?> wildcardClass8 = spreadsheetDate7.getClass();
//        java.util.Date date9 = null;
//        java.util.TimeZone timeZone10 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date9, timeZone10);
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate4, (java.lang.Class) wildcardClass8);
//        java.lang.Comparable comparable13 = timeSeries12.getKey();
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate17);
//        java.lang.String str19 = day18.toString();
//        timeSeries15.delete((org.jfree.data.time.RegularTimePeriod) day18);
//        int int21 = day18.getDayOfMonth();
//        long long22 = day18.getSerialIndex();
//        int int23 = day18.getDayOfMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries12.getDataItem((org.jfree.data.time.RegularTimePeriod) day18);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond(0L);
//        boolean boolean28 = fixedMillisecond26.equals((java.lang.Object) 100.0d);
//        int int30 = fixedMillisecond26.compareTo((java.lang.Object) 1);
//        long long31 = fixedMillisecond26.getMiddleMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = fixedMillisecond32.next();
//        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, regularTimePeriod33);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond(0L);
//        boolean boolean38 = fixedMillisecond36.equals((java.lang.Object) 100.0d);
//        timeSeries12.setKey((java.lang.Comparable) boolean38);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries12.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond41);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate44);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate(9);
//        org.jfree.data.time.SerialDate serialDate48 = spreadsheetDate44.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate47);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.lang.Class<?> wildcardClass51 = spreadsheetDate50.getClass();
//        java.util.Date date52 = null;
//        java.util.TimeZone timeZone53 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass51, date52, timeZone53);
//        org.jfree.data.time.TimeSeries timeSeries55 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate47, (java.lang.Class) wildcardClass51);
//        java.lang.Comparable comparable56 = timeSeries55.getKey();
//        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate60 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate60);
//        java.lang.String str62 = day61.toString();
//        timeSeries58.delete((org.jfree.data.time.RegularTimePeriod) day61);
//        int int64 = day61.getDayOfMonth();
//        long long65 = day61.getSerialIndex();
//        int int66 = day61.getDayOfMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem67 = timeSeries55.getDataItem((org.jfree.data.time.RegularTimePeriod) day61);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond68 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = fixedMillisecond68.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem70 = timeSeries55.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond68);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = fixedMillisecond68.next();
//        int int72 = timeSeries12.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond68);
//        java.util.Calendar calendar73 = null;
//        long long74 = fixedMillisecond68.getLastMillisecond(calendar73);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(comparable13);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "9-January-1900" + "'", str19.equals("9-January-1900"));
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 9 + "'", int21 == 9);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 10L + "'", long22 == 10L);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 9 + "'", int23 == 9);
//        org.junit.Assert.assertNull(timeSeriesDataItem24);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertNotNull(timeSeries34);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem42);
//        org.junit.Assert.assertNotNull(serialDate48);
//        org.junit.Assert.assertNotNull(wildcardClass51);
//        org.junit.Assert.assertNull(regularTimePeriod54);
//        org.junit.Assert.assertNotNull(comparable56);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "9-January-1900" + "'", str62.equals("9-January-1900"));
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 9 + "'", int64 == 9);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 10L + "'", long65 == 10L);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 9 + "'", int66 == 9);
//        org.junit.Assert.assertNull(timeSeriesDataItem67);
//        org.junit.Assert.assertNotNull(regularTimePeriod69);
//        org.junit.Assert.assertNull(timeSeriesDataItem70);
//        org.junit.Assert.assertNotNull(regularTimePeriod71);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + (-1) + "'", int72 == (-1));
//        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 1560192956116L + "'", long74 == 1560192956116L);
//    }

//    @Test
//    public void test386() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test386");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(0L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2, (java.lang.Number) 11);
//        int int5 = fixedMillisecond0.compareTo((java.lang.Object) timeSeriesDataItem4);
//        long long6 = fixedMillisecond0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560192956463L + "'", long6 == 1560192956463L);
//    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(1900, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("Last");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Wed Dec 31 16:00:00 PST 1969");
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date2);
        java.util.Date date5 = day4.getStart();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate5 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass8 = spreadsheetDate7.getClass();
        java.util.Date date9 = null;
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date9, timeZone10);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate4, (java.lang.Class) wildcardClass8);
        boolean boolean13 = timeSeries12.isEmpty();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass19 = spreadsheetDate18.getClass();
        boolean boolean20 = spreadsheetDate15.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass25 = spreadsheetDate24.getClass();
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean20, "December", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass25);
        boolean boolean27 = timeSeries26.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries12.addAndOrUpdate(timeSeries26);
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
        long long30 = year29.getFirstMillisecond();
        timeSeries12.delete((org.jfree.data.time.RegularTimePeriod) year29);
        long long32 = year29.getFirstMillisecond();
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1546329600000L + "'", long30 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1546329600000L + "'", long32 == 1546329600000L);
    }

//    @Test
//    public void test392() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test392");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(9);
//        org.jfree.data.time.SerialDate serialDate5 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate4);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.lang.Class<?> wildcardClass8 = spreadsheetDate7.getClass();
//        java.util.Date date9 = null;
//        java.util.TimeZone timeZone10 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date9, timeZone10);
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate4, (java.lang.Class) wildcardClass8);
//        java.lang.Comparable comparable13 = timeSeries12.getKey();
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate17);
//        java.lang.String str19 = day18.toString();
//        timeSeries15.delete((org.jfree.data.time.RegularTimePeriod) day18);
//        int int21 = day18.getDayOfMonth();
//        long long22 = day18.getSerialIndex();
//        int int23 = day18.getDayOfMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries12.getDataItem((org.jfree.data.time.RegularTimePeriod) day18);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond(0L);
//        boolean boolean28 = fixedMillisecond26.equals((java.lang.Object) 100.0d);
//        int int30 = fixedMillisecond26.compareTo((java.lang.Object) 1);
//        long long31 = fixedMillisecond26.getMiddleMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = fixedMillisecond32.next();
//        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, regularTimePeriod33);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond(0L);
//        boolean boolean38 = fixedMillisecond36.equals((java.lang.Object) 100.0d);
//        timeSeries12.setKey((java.lang.Comparable) boolean38);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries12.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond41);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate44);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate(9);
//        org.jfree.data.time.SerialDate serialDate48 = spreadsheetDate44.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate47);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.lang.Class<?> wildcardClass51 = spreadsheetDate50.getClass();
//        java.util.Date date52 = null;
//        java.util.TimeZone timeZone53 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass51, date52, timeZone53);
//        org.jfree.data.time.TimeSeries timeSeries55 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate47, (java.lang.Class) wildcardClass51);
//        java.lang.Comparable comparable56 = timeSeries55.getKey();
//        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate60 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate60);
//        java.lang.String str62 = day61.toString();
//        timeSeries58.delete((org.jfree.data.time.RegularTimePeriod) day61);
//        int int64 = day61.getDayOfMonth();
//        long long65 = day61.getSerialIndex();
//        int int66 = day61.getDayOfMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem67 = timeSeries55.getDataItem((org.jfree.data.time.RegularTimePeriod) day61);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond68 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = fixedMillisecond68.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem70 = timeSeries55.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond68);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = fixedMillisecond68.next();
//        int int72 = timeSeries12.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond68);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond73 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date74 = fixedMillisecond73.getTime();
//        org.jfree.data.time.Day day75 = new org.jfree.data.time.Day(date74);
//        int int76 = day75.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = day75.previous();
//        try {
//            timeSeries12.add(regularTimePeriod77, (double) 1560192924164L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Day, but the TimeSeries is expecting an instance of org.jfree.data.time.SpreadsheetDate.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(comparable13);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "9-January-1900" + "'", str19.equals("9-January-1900"));
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 9 + "'", int21 == 9);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 10L + "'", long22 == 10L);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 9 + "'", int23 == 9);
//        org.junit.Assert.assertNull(timeSeriesDataItem24);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertNotNull(timeSeries34);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem42);
//        org.junit.Assert.assertNotNull(serialDate48);
//        org.junit.Assert.assertNotNull(wildcardClass51);
//        org.junit.Assert.assertNull(regularTimePeriod54);
//        org.junit.Assert.assertNotNull(comparable56);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "9-January-1900" + "'", str62.equals("9-January-1900"));
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 9 + "'", int64 == 9);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 10L + "'", long65 == 10L);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 9 + "'", int66 == 9);
//        org.junit.Assert.assertNull(timeSeriesDataItem67);
//        org.junit.Assert.assertNotNull(regularTimePeriod69);
//        org.junit.Assert.assertNull(timeSeriesDataItem70);
//        org.junit.Assert.assertNotNull(regularTimePeriod71);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + (-1) + "'", int72 == (-1));
//        org.junit.Assert.assertNotNull(date74);
//        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 10 + "'", int76 == 10);
//        org.junit.Assert.assertNotNull(regularTimePeriod77);
//    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass7 = spreadsheetDate6.getClass();
        boolean boolean8 = spreadsheetDate3.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addMonths((int) (short) 0, (org.jfree.data.time.SerialDate) spreadsheetDate3);
        try {
            org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(0, serialDate9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(serialDate9);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate3);
        java.lang.String str5 = day4.toString();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day4);
        int int7 = timeSeries1.getItemCount();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = fixedMillisecond8.next();
        boolean boolean10 = timeSeries1.equals((java.lang.Object) fixedMillisecond8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond8.previous();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "9-January-1900" + "'", str5.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate5 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass8 = spreadsheetDate7.getClass();
        java.util.Date date9 = null;
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date9, timeZone10);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate4, (java.lang.Class) wildcardClass8);
        boolean boolean13 = timeSeries12.isEmpty();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass19 = spreadsheetDate18.getClass();
        boolean boolean20 = spreadsheetDate15.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass25 = spreadsheetDate24.getClass();
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean20, "December", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass25);
        boolean boolean27 = timeSeries26.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries12.addAndOrUpdate(timeSeries26);
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
        long long30 = year29.getFirstMillisecond();
        timeSeries12.delete((org.jfree.data.time.RegularTimePeriod) year29);
        int int32 = year29.getYear();
        long long33 = year29.getLastMillisecond();
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1546329600000L + "'", long30 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2019 + "'", int32 == 2019);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1577865599999L + "'", long33 == 1577865599999L);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addMonths(1, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass10 = spreadsheetDate9.getClass();
        boolean boolean11 = spreadsheetDate6.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate14 = spreadsheetDate9.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass17 = spreadsheetDate16.getClass();
        boolean boolean18 = spreadsheetDate9.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate16);
        boolean boolean19 = spreadsheetDate2.isOn((org.jfree.data.time.SerialDate) spreadsheetDate16);
        try {
            org.jfree.data.time.SerialDate serialDate21 = spreadsheetDate16.getNearestDayOfWeek(9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate3);
        java.lang.String str5 = day4.toString();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day4);
        int int7 = timeSeries1.getItemCount();
        timeSeries1.removeAgedItems((long) 4, true);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        long long15 = year14.getFirstMillisecond();
        int int16 = year14.getYear();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (org.jfree.data.time.RegularTimePeriod) year14);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries17.addChangeListener(seriesChangeListener18);
        boolean boolean20 = timeSeries17.getNotify();
        java.util.Collection collection21 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries17);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        long long26 = year25.getFirstMillisecond();
        int int27 = year25.getYear();
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries23.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (org.jfree.data.time.RegularTimePeriod) year25);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        java.lang.String str31 = year30.toString();
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month((int) (byte) 10, year30);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate34);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass38 = spreadsheetDate37.getClass();
        boolean boolean39 = spreadsheetDate34.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate37);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate41);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate45 = spreadsheetDate41.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate44);
        boolean boolean46 = spreadsheetDate37.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate41);
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate37);
        org.jfree.data.time.TimeSeries timeSeries48 = timeSeries23.createCopy((org.jfree.data.time.RegularTimePeriod) month32, (org.jfree.data.time.RegularTimePeriod) day47);
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month32, (java.lang.Number) 2019, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "9-January-1900" + "'", str5.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1546329600000L + "'", long15 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(collection21);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1546329600000L + "'", long26 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "2019" + "'", str31.equals("2019"));
        org.junit.Assert.assertNotNull(wildcardClass38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(timeSeries48);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (byte) 10);
        java.util.Calendar calendar4 = null;
        try {
            year0.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        java.lang.String str2 = year1.toString();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (byte) 10, year1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.previous();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate10 = spreadsheetDate6.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate9);
        boolean boolean11 = month3.equals((java.lang.Object) spreadsheetDate6);
        java.lang.String str12 = month3.toString();
        long long13 = month3.getFirstMillisecond();
        java.util.Calendar calendar14 = null;
        try {
            long long15 = month3.getLastMillisecond(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "October 2019" + "'", str12.equals("October 2019"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1569913200000L + "'", long13 == 1569913200000L);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(7);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate3);
        java.lang.String str5 = day4.toString();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day4);
        boolean boolean7 = timeSeries1.getNotify();
        timeSeries1.setDescription("December");
        timeSeries1.removeAgedItems(false);
        try {
            timeSeries1.delete(30, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "9-January-1900" + "'", str5.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate6 = spreadsheetDate2.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addMonths(3, (org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass13 = spreadsheetDate12.getClass();
        boolean boolean14 = spreadsheetDate9.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate17 = spreadsheetDate12.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.SerialDate serialDate18 = serialDate7.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (byte) 1, (org.jfree.data.time.SerialDate) spreadsheetDate21);
        int int23 = spreadsheetDate21.getYYYY();
        boolean boolean24 = spreadsheetDate16.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(2019);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        java.lang.String str29 = year28.toString();
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month((int) (byte) 10, year28);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = month30.previous();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate33);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate37 = spreadsheetDate33.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate36);
        boolean boolean38 = month30.equals((java.lang.Object) spreadsheetDate33);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate41);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass45 = spreadsheetDate44.getClass();
        boolean boolean46 = spreadsheetDate41.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate44);
        org.jfree.data.time.SerialDate serialDate47 = org.jfree.data.time.SerialDate.addMonths((int) (short) 0, (org.jfree.data.time.SerialDate) spreadsheetDate41);
        boolean boolean48 = spreadsheetDate33.isAfter(serialDate47);
        boolean boolean49 = spreadsheetDate26.isOn(serialDate47);
        boolean boolean50 = spreadsheetDate21.isAfter(serialDate47);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1900 + "'", int23 == 1900);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "2019" + "'", str29.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(wildcardClass45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(6);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        int int3 = year0.compareTo((java.lang.Object) "9-January-1900");
        int int5 = year0.compareTo((java.lang.Object) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate5 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass8 = spreadsheetDate7.getClass();
        java.util.Date date9 = null;
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date9, timeZone10);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate4, (java.lang.Class) wildcardClass8);
        boolean boolean13 = timeSeries12.isEmpty();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass19 = spreadsheetDate18.getClass();
        boolean boolean20 = spreadsheetDate15.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass25 = spreadsheetDate24.getClass();
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean20, "December", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass25);
        boolean boolean27 = timeSeries26.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries12.addAndOrUpdate(timeSeries26);
        timeSeries12.setDescription("Time");
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(5, 31);
        try {
            timeSeries12.add((org.jfree.data.time.RegularTimePeriod) month33, (double) (-457));
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.SpreadsheetDate.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(timeSeries28);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(7, (int) ' ', (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        timeSeries1.clear();
        java.lang.Comparable comparable3 = timeSeries1.getKey();
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate(regularTimePeriod6, (java.lang.Number) 0.0f);
        timeSeries1.setRangeDescription("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries1.removeChangeListener(seriesChangeListener11);
        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + 'a' + "'", comparable3.equals('a'));
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 'a' + "'", comparable4.equals('a'));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (byte) 10);
        int int4 = year0.getYear();
        int int6 = year0.compareTo((java.lang.Object) '4');
        java.util.Calendar calendar7 = null;
        try {
            year0.peg(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) (short) -1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(12);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        int int2 = year0.getYear();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass10 = spreadsheetDate9.getClass();
        boolean boolean11 = spreadsheetDate6.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass16 = spreadsheetDate15.getClass();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean11, "December", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass16);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date1, "Thursday", "Thursday", (java.lang.Class) wildcardClass16);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(date1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass25 = spreadsheetDate24.getClass();
        boolean boolean26 = spreadsheetDate21.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate24);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate29 = spreadsheetDate24.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate28);
        java.util.Date date30 = spreadsheetDate24.toDate();
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date30, timeZone31);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(date1, timeZone31);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(timeZone31);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = spreadsheetDate4.getClass();
        boolean boolean6 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate9 = spreadsheetDate4.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass12 = spreadsheetDate11.getClass();
        boolean boolean13 = spreadsheetDate4.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate19 = spreadsheetDate15.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate22);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass26 = spreadsheetDate25.getClass();
        boolean boolean27 = spreadsheetDate22.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate25);
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.addYears((int) '4', (org.jfree.data.time.SerialDate) spreadsheetDate25);
        org.jfree.data.time.SerialDate serialDate29 = spreadsheetDate18.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate25);
        int int30 = spreadsheetDate25.getMonth();
        org.jfree.data.time.SerialDate serialDate31 = spreadsheetDate11.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate25);
        int int32 = spreadsheetDate11.getYYYY();
        int int33 = spreadsheetDate11.getMonth();
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1900 + "'", int32 == 1900);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
    }

//    @Test
//    public void test414() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test414");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
//        java.util.Date date3 = fixedMillisecond2.getTime();
//        java.util.Calendar calendar4 = null;
//        long long5 = fixedMillisecond2.getMiddleMillisecond(calendar4);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560192958777L + "'", long5 == 1560192958777L);
//    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate3);
        java.lang.String str5 = day4.toString();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day4);
        int int7 = timeSeries1.getItemCount();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = fixedMillisecond8.next();
        boolean boolean10 = timeSeries1.equals((java.lang.Object) fixedMillisecond8);
        int int11 = timeSeries1.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        long long16 = year15.getFirstMillisecond();
        int int17 = year15.getYear();
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries13.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (org.jfree.data.time.RegularTimePeriod) year15);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate22);
        java.lang.String str24 = day23.toString();
        timeSeries20.delete((org.jfree.data.time.RegularTimePeriod) day23);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = day23.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day23, (java.lang.Number) 1L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = timeSeries13.getNextTimePeriod();
        timeSeries1.delete(regularTimePeriod29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = null;
        try {
            timeSeries1.add(regularTimePeriod31, (double) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "9-January-1900" + "'", str5.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1546329600000L + "'", long16 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "9-January-1900" + "'", str24.equals("9-January-1900"));
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNull(timeSeriesDataItem28);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate6);
        java.lang.String str8 = day7.toString();
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day7);
        int int10 = timeSeries4.getItemCount();
        timeSeries4.removeAgedItems((long) 4, true);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getFirstMillisecond();
        int int19 = year17.getYear();
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16, (org.jfree.data.time.RegularTimePeriod) year17);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener21 = null;
        timeSeries20.addChangeListener(seriesChangeListener21);
        boolean boolean23 = timeSeries20.getNotify();
        java.util.Collection collection24 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries20);
        java.lang.Object obj25 = null;
        boolean boolean26 = timeSeries20.equals(obj25);
        boolean boolean27 = year0.equals(obj25);
        long long28 = year0.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "9-January-1900" + "'", str8.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1546329600000L + "'", long18 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(collection24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1546329600000L + "'", long28 == 1546329600000L);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate5 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass12 = spreadsheetDate11.getClass();
        boolean boolean13 = spreadsheetDate8.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addYears((int) '4', (org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SerialDate serialDate15 = spreadsheetDate4.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate11);
        java.lang.Class<?> wildcardClass16 = spreadsheetDate4.getClass();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate20);
        java.lang.String str22 = day21.toString();
        timeSeries18.delete((org.jfree.data.time.RegularTimePeriod) day21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day21.previous();
        java.util.Date date25 = day21.getStart();
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date25, timeZone26);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date25);
        int int29 = year28.getYear();
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "9-January-1900" + "'", str22.equals("9-January-1900"));
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1900 + "'", int29 == 1900);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("October 2019");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        long long4 = year3.getFirstMillisecond();
        int int5 = year3.getYear();
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2, (org.jfree.data.time.RegularTimePeriod) year3);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.lang.String str9 = year8.toString();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (byte) 10, year8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass16 = spreadsheetDate15.getClass();
        boolean boolean17 = spreadsheetDate12.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate23 = spreadsheetDate19.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate22);
        boolean boolean24 = spreadsheetDate15.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month10, (org.jfree.data.time.RegularTimePeriod) day25);
        java.lang.String str27 = month10.toString();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "October 2019" + "'", str27.equals("October 2019"));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.SerialDate serialDate4 = day3.getSerialDate();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(serialDate4);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(30, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate8 = spreadsheetDate4.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass15 = spreadsheetDate14.getClass();
        boolean boolean16 = spreadsheetDate11.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.addYears((int) '4', (org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SerialDate serialDate18 = spreadsheetDate7.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate14);
        java.lang.Class<?> wildcardClass19 = spreadsheetDate7.getClass();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate23);
        java.lang.String str25 = day24.toString();
        timeSeries21.delete((org.jfree.data.time.RegularTimePeriod) day24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = day24.previous();
        java.util.Date date28 = day24.getStart();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date28, timeZone29);
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560192924809L, "Thursday", "Nearest", (java.lang.Class) wildcardClass19);
        try {
            org.jfree.data.time.TimeSeries timeSeries34 = timeSeries31.createCopy(11, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "9-January-1900" + "'", str25.equals("9-January-1900"));
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNull(regularTimePeriod30);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(5);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate5 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass8 = spreadsheetDate7.getClass();
        java.util.Date date9 = null;
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date9, timeZone10);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate4, (java.lang.Class) wildcardClass8);
        boolean boolean13 = timeSeries12.isEmpty();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass19 = spreadsheetDate18.getClass();
        boolean boolean20 = spreadsheetDate15.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass25 = spreadsheetDate24.getClass();
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean20, "December", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass25);
        boolean boolean27 = timeSeries26.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries12.addAndOrUpdate(timeSeries26);
        timeSeries12.setDescription("Time");
        java.lang.String str31 = timeSeries12.getDomainDescription();
        try {
            timeSeries12.setMaximumItemCount((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'maximum' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Time" + "'", str31.equals("Time"));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(2);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((int) (short) 0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        long long4 = year3.getFirstMillisecond();
        int int5 = year3.getYear();
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2, (org.jfree.data.time.RegularTimePeriod) year3);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate10);
        java.lang.String str12 = day11.toString();
        timeSeries8.delete((org.jfree.data.time.RegularTimePeriod) day11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day11.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day11, (java.lang.Number) 1L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
        timeSeries1.removeChangeListener(seriesChangeListener17);
        timeSeries1.setNotify(true);
        timeSeries1.setMaximumItemAge(9223372036854775807L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date24 = fixedMillisecond23.getTime();
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month(date24);
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(date24);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month26, (double) 10.0f);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month26, (java.lang.Number) 0L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "9-January-1900" + "'", str12.equals("9-January-1900"));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(timeSeriesDataItem30);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        try {
            org.jfree.data.time.SerialDate serialDate4 = spreadsheetDate1.getPreviousDayOfWeek(30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate5 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass11 = spreadsheetDate10.getClass();
        boolean boolean12 = spreadsheetDate7.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(0L);
        boolean boolean16 = fixedMillisecond14.equals((java.lang.Object) 100.0d);
        int int18 = fixedMillisecond14.compareTo((java.lang.Object) 1);
        long long19 = fixedMillisecond14.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (double) 9999);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        boolean boolean23 = timeSeriesDataItem21.equals((java.lang.Object) year22);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate26);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass30 = spreadsheetDate29.getClass();
        boolean boolean31 = spreadsheetDate26.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate29);
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.addYears((int) '4', (org.jfree.data.time.SerialDate) spreadsheetDate29);
        int int33 = timeSeriesDataItem21.compareTo((java.lang.Object) spreadsheetDate29);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate35);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass39 = spreadsheetDate38.getClass();
        boolean boolean40 = spreadsheetDate35.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate38);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate42);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate46 = spreadsheetDate42.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate45);
        boolean boolean47 = spreadsheetDate38.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate42);
        org.jfree.data.time.SerialDate serialDate48 = spreadsheetDate29.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate38);
        boolean boolean49 = spreadsheetDate7.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate29);
        boolean boolean50 = spreadsheetDate4.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate7);
        java.lang.String str51 = spreadsheetDate7.getDescription();
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertNotNull(wildcardClass39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNull(str51);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (11) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(6);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June" + "'", str1.equals("June"));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond0.previous();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(2019, (int) '#', 2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(12, (int) (short) 0, 30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addMonths(1, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        java.util.Date date5 = spreadsheetDate2.toDate();
        try {
            org.jfree.data.time.SerialDate serialDate7 = spreadsheetDate2.getNearestDayOfWeek((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate5 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass8 = spreadsheetDate7.getClass();
        java.util.Date date9 = null;
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date9, timeZone10);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate4, (java.lang.Class) wildcardClass8);
        timeSeries12.setDomainDescription("9-January-1900");
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNull(regularTimePeriod11);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((int) 'a');
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate3);
        java.lang.String str5 = day4.toString();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day4);
        int int7 = timeSeries1.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getFirstMillisecond();
        int int13 = year11.getYear();
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries9.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (org.jfree.data.time.RegularTimePeriod) year11);
        boolean boolean15 = timeSeries1.equals((java.lang.Object) year11);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries1.createCopy(9999, 2147483647);
        timeSeries1.removeAgedItems((long) 9999, true);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond(0L);
        boolean boolean25 = fixedMillisecond23.equals((java.lang.Object) 100.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = fixedMillisecond23.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond23.previous();
        long long28 = fixedMillisecond23.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23);
        long long30 = fixedMillisecond23.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "9-January-1900" + "'", str5.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1546329600000L + "'", long12 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
    }

//    @Test
//    public void test439() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test439");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
//        long long4 = year3.getFirstMillisecond();
//        int int5 = year3.getYear();
//        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2, (org.jfree.data.time.RegularTimePeriod) year3);
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate10);
//        java.lang.String str12 = day11.toString();
//        timeSeries8.delete((org.jfree.data.time.RegularTimePeriod) day11);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day11.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day11, (java.lang.Number) 1L);
//        java.util.Collection collection17 = timeSeries1.getTimePeriods();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond(0L);
//        boolean boolean21 = fixedMillisecond19.equals((java.lang.Object) 100.0d);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond19.previous();
//        long long23 = fixedMillisecond19.getFirstMillisecond();
//        java.lang.Number number24 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        long long26 = day25.getSerialIndex();
//        boolean boolean27 = fixedMillisecond19.equals((java.lang.Object) long26);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertNotNull(timeSeries6);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "9-January-1900" + "'", str12.equals("9-January-1900"));
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNull(timeSeriesDataItem16);
//        org.junit.Assert.assertNotNull(collection17);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
//        org.junit.Assert.assertTrue("'" + number24 + "' != '" + 1L + "'", number24.equals(1L));
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 43626L + "'", long26 == 43626L);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate5 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass8 = spreadsheetDate7.getClass();
        java.util.Date date9 = null;
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date9, timeZone10);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate4, (java.lang.Class) wildcardClass8);
        java.lang.Comparable comparable13 = timeSeries12.getKey();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate17);
        java.lang.String str19 = day18.toString();
        timeSeries15.delete((org.jfree.data.time.RegularTimePeriod) day18);
        int int21 = day18.getDayOfMonth();
        long long22 = day18.getSerialIndex();
        int int23 = day18.getDayOfMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries12.getDataItem((org.jfree.data.time.RegularTimePeriod) day18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = fixedMillisecond25.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries12.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25);
        timeSeries12.setDomainDescription("April");
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(comparable13);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "9-January-1900" + "'", str19.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 9 + "'", int21 == 9);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 10L + "'", long22 == 10L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 9 + "'", int23 == 9);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNull(timeSeriesDataItem27);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = spreadsheetDate4.getClass();
        boolean boolean6 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate12 = spreadsheetDate8.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass19 = spreadsheetDate18.getClass();
        boolean boolean20 = spreadsheetDate15.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addYears((int) '4', (org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SerialDate serialDate22 = spreadsheetDate11.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate18);
        boolean boolean23 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate25);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass29 = spreadsheetDate28.getClass();
        boolean boolean30 = spreadsheetDate25.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate28);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate32);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate36 = spreadsheetDate32.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate35);
        boolean boolean37 = spreadsheetDate28.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate32);
        int int38 = spreadsheetDate11.compare((org.jfree.data.time.SerialDate) spreadsheetDate32);
        try {
            org.jfree.data.time.SerialDate serialDate40 = spreadsheetDate32.getPreviousDayOfWeek(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(7);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-458) + "'", int1 == (-458));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate10 = spreadsheetDate6.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass13 = spreadsheetDate12.getClass();
        java.util.Date date14 = null;
        java.util.TimeZone timeZone15 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date14, timeZone15);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate9, (java.lang.Class) wildcardClass13);
        boolean boolean18 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate4, (org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate9);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.lang.String str21 = year20.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass26 = spreadsheetDate25.getClass();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str21, "", "9-January-1900", (java.lang.Class) wildcardClass26);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year28.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries27.getDataItem(regularTimePeriod29);
        java.util.Collection collection31 = timeSeries19.getTimePeriodsUniqueToOtherSeries(timeSeries27);
        timeSeries19.removeAgedItems(false);
        timeSeries19.setNotify(false);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2019" + "'", str21.equals("2019"));
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNull(timeSeriesDataItem30);
        org.junit.Assert.assertNotNull(collection31);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate10 = spreadsheetDate6.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass13 = spreadsheetDate12.getClass();
        java.util.Date date14 = null;
        java.util.TimeZone timeZone15 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date14, timeZone15);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate9, (java.lang.Class) wildcardClass13);
        boolean boolean18 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate4, (org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate9);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries19.addChangeListener(seriesChangeListener20);
        timeSeries19.clear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = null;
        try {
            timeSeries19.add(regularTimePeriod23, (double) 100, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

//    @Test
//    public void test445() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test445");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        int int3 = day2.getMonth();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate9);
//        java.lang.String str11 = day10.toString();
//        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) day10);
//        int int13 = day10.getDayOfMonth();
//        long long14 = day10.getSerialIndex();
//        int int15 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) day10);
//        java.util.Collection collection16 = timeSeries5.getTimePeriods();
//        boolean boolean17 = day2.equals((java.lang.Object) collection16);
//        long long18 = day2.getLastMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "9-January-1900" + "'", str11.equals("9-January-1900"));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 9 + "'", int13 == 9);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
//        org.junit.Assert.assertNotNull(collection16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560236399999L + "'", long18 == 1560236399999L);
//    }

//    @Test
//    public void test446() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test446");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int3 = day0.compareTo((java.lang.Object) 2147483647);
//        long long4 = day0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        long long2 = fixedMillisecond1.getFirstMillisecond();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getFirstMillisecond(calendar3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond1.previous();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((-1));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        java.lang.String str3 = month2.toString();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate3);
        java.lang.String str5 = day4.toString();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day4);
        int int7 = day4.getDayOfMonth();
        long long8 = day4.getSerialIndex();
        int int9 = day4.getYear();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass12 = spreadsheetDate11.getClass();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, (java.lang.Class) wildcardClass12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate19 = spreadsheetDate15.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass22 = spreadsheetDate21.getClass();
        java.util.Date date23 = null;
        java.util.TimeZone timeZone24 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass22, date23, timeZone24);
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate18, (java.lang.Class) wildcardClass22);
        java.lang.Comparable comparable27 = timeSeries26.getKey();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate31);
        java.lang.String str33 = day32.toString();
        timeSeries29.delete((org.jfree.data.time.RegularTimePeriod) day32);
        int int35 = day32.getDayOfMonth();
        long long36 = day32.getSerialIndex();
        int int37 = day32.getDayOfMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries26.getDataItem((org.jfree.data.time.RegularTimePeriod) day32);
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond(0L);
        boolean boolean42 = fixedMillisecond40.equals((java.lang.Object) 100.0d);
        int int44 = fixedMillisecond40.compareTo((java.lang.Object) 1);
        long long45 = fixedMillisecond40.getMiddleMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = fixedMillisecond46.next();
        org.jfree.data.time.TimeSeries timeSeries48 = timeSeries26.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40, regularTimePeriod47);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = fixedMillisecond40.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40);
        timeSeries13.setRangeDescription("January 1900");
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "9-January-1900" + "'", str5.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9 + "'", int7 == 9);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1900 + "'", int9 == 1900);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(comparable27);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "9-January-1900" + "'", str33.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 9 + "'", int35 == 9);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 10L + "'", long36 == 10L);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 9 + "'", int37 == 9);
        org.junit.Assert.assertNull(timeSeriesDataItem38);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 0L + "'", long45 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod47);
        org.junit.Assert.assertNotNull(timeSeries48);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertNull(timeSeriesDataItem50);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(9999);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate3);
        java.lang.String str5 = day4.toString();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day4);
        int int7 = timeSeries1.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getFirstMillisecond();
        int int13 = year11.getYear();
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries9.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (org.jfree.data.time.RegularTimePeriod) year11);
        boolean boolean15 = timeSeries1.equals((java.lang.Object) year11);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent16 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeries1);
        java.util.List list17 = timeSeries1.getItems();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "9-January-1900" + "'", str5.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1546329600000L + "'", long12 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(list17);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass7 = spreadsheetDate6.getClass();
        boolean boolean8 = spreadsheetDate3.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addYears((int) '4', (org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.addYears(3, serialDate9);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        long long4 = year3.getFirstMillisecond();
        int int5 = year3.getYear();
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2, (org.jfree.data.time.RegularTimePeriod) year3);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.createCopy(9, 1900);
        timeSeries9.setNotify(false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries9);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate6 = spreadsheetDate2.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addMonths(3, (org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass13 = spreadsheetDate12.getClass();
        boolean boolean14 = spreadsheetDate9.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate17 = spreadsheetDate12.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.SerialDate serialDate18 = serialDate7.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate16);
        try {
            org.jfree.data.time.SerialDate serialDate20 = serialDate18.getPreviousDayOfWeek((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate18);
    }

//    @Test
//    public void test456() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test456");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
//        long long3 = fixedMillisecond2.getLastMillisecond();
//        java.util.Calendar calendar4 = null;
//        long long5 = fixedMillisecond2.getFirstMillisecond(calendar4);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560192963702L + "'", long3 == 1560192963702L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560192963702L + "'", long5 == 1560192963702L);
//    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        boolean boolean3 = fixedMillisecond1.equals((java.lang.Object) 100.0d);
        int int5 = fixedMillisecond1.compareTo((java.lang.Object) 1);
        long long6 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) 9999);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        boolean boolean10 = timeSeriesDataItem8.equals((java.lang.Object) year9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = timeSeriesDataItem8.getPeriod();
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond(0L);
        boolean boolean15 = fixedMillisecond13.equals((java.lang.Object) 100.0d);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (java.lang.Number) 9);
        boolean boolean18 = timeSeriesDataItem8.equals((java.lang.Object) fixedMillisecond13);
        long long19 = fixedMillisecond13.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        int int3 = day2.getMonth();
        int int4 = day2.getYear();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate5 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass8 = spreadsheetDate7.getClass();
        java.util.Date date9 = null;
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date9, timeZone10);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate4, (java.lang.Class) wildcardClass8);
        java.lang.Comparable comparable13 = timeSeries12.getKey();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate17);
        java.lang.String str19 = day18.toString();
        timeSeries15.delete((org.jfree.data.time.RegularTimePeriod) day18);
        int int21 = day18.getDayOfMonth();
        long long22 = day18.getSerialIndex();
        int int23 = day18.getDayOfMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries12.getDataItem((org.jfree.data.time.RegularTimePeriod) day18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond(0L);
        boolean boolean28 = fixedMillisecond26.equals((java.lang.Object) 100.0d);
        int int30 = fixedMillisecond26.compareTo((java.lang.Object) 1);
        long long31 = fixedMillisecond26.getMiddleMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = fixedMillisecond32.next();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, regularTimePeriod33);
        timeSeries12.setNotify(false);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate38);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate42 = spreadsheetDate38.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate41);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass45 = spreadsheetDate44.getClass();
        java.util.Date date46 = null;
        java.util.TimeZone timeZone47 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass45, date46, timeZone47);
        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate41, (java.lang.Class) wildcardClass45);
        java.lang.Comparable comparable50 = timeSeries49.getKey();
        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate54 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate54);
        java.lang.String str56 = day55.toString();
        timeSeries52.delete((org.jfree.data.time.RegularTimePeriod) day55);
        int int58 = day55.getDayOfMonth();
        long long59 = day55.getSerialIndex();
        int int60 = day55.getDayOfMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem61 = timeSeries49.getDataItem((org.jfree.data.time.RegularTimePeriod) day55);
        org.jfree.data.time.FixedMillisecond fixedMillisecond63 = new org.jfree.data.time.FixedMillisecond(0L);
        boolean boolean65 = fixedMillisecond63.equals((java.lang.Object) 100.0d);
        int int67 = fixedMillisecond63.compareTo((java.lang.Object) 1);
        long long68 = fixedMillisecond63.getMiddleMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond69 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = fixedMillisecond69.next();
        org.jfree.data.time.TimeSeries timeSeries71 = timeSeries49.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond63, regularTimePeriod70);
        org.jfree.data.time.TimeSeries timeSeries72 = timeSeries12.addAndOrUpdate(timeSeries49);
        java.lang.String str73 = timeSeries12.getDomainDescription();
        java.beans.PropertyChangeListener propertyChangeListener74 = null;
        timeSeries12.removePropertyChangeListener(propertyChangeListener74);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(comparable13);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "9-January-1900" + "'", str19.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 9 + "'", int21 == 9);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 10L + "'", long22 == 10L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 9 + "'", int23 == 9);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertNotNull(wildcardClass45);
        org.junit.Assert.assertNull(regularTimePeriod48);
        org.junit.Assert.assertNotNull(comparable50);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "9-January-1900" + "'", str56.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 9 + "'", int58 == 9);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 10L + "'", long59 == 10L);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 9 + "'", int60 == 9);
        org.junit.Assert.assertNull(timeSeriesDataItem61);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1 + "'", int67 == 1);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 0L + "'", long68 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod70);
        org.junit.Assert.assertNotNull(timeSeries71);
        org.junit.Assert.assertNotNull(timeSeries72);
        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "Time" + "'", str73.equals("Time"));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate5);
        java.lang.String str7 = day6.toString();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) day6);
        int int9 = day6.getDayOfMonth();
        long long10 = day6.getSerialIndex();
        int int11 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) day6);
        timeSeries1.setMaximumItemAge((long) '4');
        timeSeries1.setDescription("");
        timeSeries1.setMaximumItemAge((long) 4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "9-January-1900" + "'", str7.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((-1), true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate5 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass12 = spreadsheetDate11.getClass();
        boolean boolean13 = spreadsheetDate8.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addYears((int) '4', (org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SerialDate serialDate15 = spreadsheetDate4.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate11);
        java.lang.String str16 = spreadsheetDate11.toString();
        int int17 = spreadsheetDate11.getYYYY();
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "9-January-1900" + "'", str16.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1900 + "'", int17 == 1900);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = spreadsheetDate4.getClass();
        boolean boolean6 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        boolean boolean10 = fixedMillisecond8.equals((java.lang.Object) 100.0d);
        int int12 = fixedMillisecond8.compareTo((java.lang.Object) 1);
        long long13 = fixedMillisecond8.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (double) 9999);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        boolean boolean17 = timeSeriesDataItem15.equals((java.lang.Object) year16);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass24 = spreadsheetDate23.getClass();
        boolean boolean25 = spreadsheetDate20.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate23);
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.addYears((int) '4', (org.jfree.data.time.SerialDate) spreadsheetDate23);
        int int27 = timeSeriesDataItem15.compareTo((java.lang.Object) spreadsheetDate23);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate29);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass33 = spreadsheetDate32.getClass();
        boolean boolean34 = spreadsheetDate29.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate32);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate36);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate40 = spreadsheetDate36.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate39);
        boolean boolean41 = spreadsheetDate32.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate36);
        org.jfree.data.time.SerialDate serialDate42 = spreadsheetDate23.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate32);
        boolean boolean43 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate23);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate45);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate49 = spreadsheetDate45.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate48);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate52 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate52);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate55 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass56 = spreadsheetDate55.getClass();
        boolean boolean57 = spreadsheetDate52.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate55);
        org.jfree.data.time.SerialDate serialDate58 = org.jfree.data.time.SerialDate.addYears((int) '4', (org.jfree.data.time.SerialDate) spreadsheetDate55);
        org.jfree.data.time.SerialDate serialDate59 = spreadsheetDate48.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate55);
        java.lang.Class<?> wildcardClass60 = spreadsheetDate48.getClass();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate62 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate62);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate65 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass66 = spreadsheetDate65.getClass();
        boolean boolean67 = spreadsheetDate62.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate65);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate69 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate69);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate72 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass73 = spreadsheetDate72.getClass();
        boolean boolean74 = spreadsheetDate69.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate72);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate76 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day77 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate76);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate79 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate80 = spreadsheetDate76.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate79);
        boolean boolean81 = spreadsheetDate72.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate76);
        boolean boolean82 = spreadsheetDate65.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate72);
        boolean boolean84 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate48, (org.jfree.data.time.SerialDate) spreadsheetDate72, 2958465);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate86 = new org.jfree.data.time.SpreadsheetDate(4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate89 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day90 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate89);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate92 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass93 = spreadsheetDate92.getClass();
        boolean boolean94 = spreadsheetDate89.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate92);
        org.jfree.data.time.SerialDate serialDate95 = org.jfree.data.time.SerialDate.addYears((int) '4', (org.jfree.data.time.SerialDate) spreadsheetDate92);
        org.jfree.data.time.SerialDate serialDate96 = spreadsheetDate86.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate92);
        boolean boolean97 = spreadsheetDate48.isBefore(serialDate96);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertNotNull(wildcardClass56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(serialDate58);
        org.junit.Assert.assertNotNull(serialDate59);
        org.junit.Assert.assertNotNull(wildcardClass60);
        org.junit.Assert.assertNotNull(wildcardClass66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(wildcardClass73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(serialDate80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + true + "'", boolean81 == true);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + true + "'", boolean82 == true);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertNotNull(wildcardClass93);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
        org.junit.Assert.assertNotNull(serialDate95);
        org.junit.Assert.assertNotNull(serialDate96);
        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + true + "'", boolean97 == true);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass6 = spreadsheetDate5.getClass();
        boolean boolean7 = spreadsheetDate2.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate13 = spreadsheetDate9.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass20 = spreadsheetDate19.getClass();
        boolean boolean21 = spreadsheetDate16.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addYears((int) '4', (org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.SerialDate serialDate23 = spreadsheetDate12.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate19);
        boolean boolean24 = spreadsheetDate2.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate26);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass30 = spreadsheetDate29.getClass();
        boolean boolean31 = spreadsheetDate26.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate29);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate33);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate37 = spreadsheetDate33.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate36);
        boolean boolean38 = spreadsheetDate29.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate33);
        int int39 = spreadsheetDate12.compare((org.jfree.data.time.SerialDate) spreadsheetDate33);
        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.addMonths(13, (org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertNotNull(serialDate40);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate3);
        java.lang.String str5 = day4.toString();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day4);
        int int7 = timeSeries1.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getFirstMillisecond();
        int int13 = year11.getYear();
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries9.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (org.jfree.data.time.RegularTimePeriod) year11);
        boolean boolean15 = timeSeries1.equals((java.lang.Object) year11);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent16 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeries1);
        java.lang.String str17 = seriesChangeEvent16.toString();
        java.lang.Object obj18 = seriesChangeEvent16.getSource();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "9-January-1900" + "'", str5.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1546329600000L + "'", long12 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(obj18);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        boolean boolean3 = fixedMillisecond1.equals((java.lang.Object) 100.0d);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (java.lang.Number) 9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = timeSeriesDataItem5.getPeriod();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        int int2 = year0.getYear();
        int int3 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        java.lang.String str5 = year0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year0.previous();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        timeSeries1.clear();
        java.lang.Comparable comparable3 = timeSeries1.getKey();
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate(regularTimePeriod6, (java.lang.Number) 0.0f);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate14 = spreadsheetDate10.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass17 = spreadsheetDate16.getClass();
        java.util.Date date18 = null;
        java.util.TimeZone timeZone19 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date18, timeZone19);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate13, (java.lang.Class) wildcardClass17);
        java.lang.Comparable comparable22 = timeSeries21.getKey();
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate26);
        java.lang.String str28 = day27.toString();
        timeSeries24.delete((org.jfree.data.time.RegularTimePeriod) day27);
        int int30 = day27.getDayOfMonth();
        long long31 = day27.getSerialIndex();
        int int32 = day27.getDayOfMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries21.getDataItem((org.jfree.data.time.RegularTimePeriod) day27);
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond(0L);
        boolean boolean37 = fixedMillisecond35.equals((java.lang.Object) 100.0d);
        int int39 = fixedMillisecond35.compareTo((java.lang.Object) 1);
        long long40 = fixedMillisecond35.getMiddleMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = fixedMillisecond41.next();
        org.jfree.data.time.TimeSeries timeSeries43 = timeSeries21.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35, regularTimePeriod42);
        timeSeries21.setNotify(false);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate47);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate51 = spreadsheetDate47.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate50);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate53 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass54 = spreadsheetDate53.getClass();
        java.util.Date date55 = null;
        java.util.TimeZone timeZone56 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass54, date55, timeZone56);
        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate50, (java.lang.Class) wildcardClass54);
        java.lang.Comparable comparable59 = timeSeries58.getKey();
        org.jfree.data.time.TimeSeries timeSeries61 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate63 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate63);
        java.lang.String str65 = day64.toString();
        timeSeries61.delete((org.jfree.data.time.RegularTimePeriod) day64);
        int int67 = day64.getDayOfMonth();
        long long68 = day64.getSerialIndex();
        int int69 = day64.getDayOfMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem70 = timeSeries58.getDataItem((org.jfree.data.time.RegularTimePeriod) day64);
        org.jfree.data.time.FixedMillisecond fixedMillisecond72 = new org.jfree.data.time.FixedMillisecond(0L);
        boolean boolean74 = fixedMillisecond72.equals((java.lang.Object) 100.0d);
        int int76 = fixedMillisecond72.compareTo((java.lang.Object) 1);
        long long77 = fixedMillisecond72.getMiddleMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond78 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = fixedMillisecond78.next();
        org.jfree.data.time.TimeSeries timeSeries80 = timeSeries58.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond72, regularTimePeriod79);
        org.jfree.data.time.TimeSeries timeSeries81 = timeSeries21.addAndOrUpdate(timeSeries58);
        java.util.Collection collection82 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries58);
        timeSeries1.setMaximumItemCount(8);
        timeSeries1.clear();
        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + 'a' + "'", comparable3.equals('a'));
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 'a' + "'", comparable4.equals('a'));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(comparable22);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "9-January-1900" + "'", str28.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 9 + "'", int30 == 9);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 10L + "'", long31 == 10L);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 9 + "'", int32 == 9);
        org.junit.Assert.assertNull(timeSeriesDataItem33);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertNotNull(timeSeries43);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertNotNull(wildcardClass54);
        org.junit.Assert.assertNull(regularTimePeriod57);
        org.junit.Assert.assertNotNull(comparable59);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "9-January-1900" + "'", str65.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 9 + "'", int67 == 9);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 10L + "'", long68 == 10L);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 9 + "'", int69 == 9);
        org.junit.Assert.assertNull(timeSeriesDataItem70);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 1 + "'", int76 == 1);
        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 0L + "'", long77 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod79);
        org.junit.Assert.assertNotNull(timeSeries80);
        org.junit.Assert.assertNotNull(timeSeries81);
        org.junit.Assert.assertNotNull(collection82);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = spreadsheetDate4.getClass();
        boolean boolean6 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate9 = spreadsheetDate4.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass12 = spreadsheetDate11.getClass();
        boolean boolean13 = spreadsheetDate4.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate19 = spreadsheetDate15.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate22);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass26 = spreadsheetDate25.getClass();
        boolean boolean27 = spreadsheetDate22.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate25);
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.addYears((int) '4', (org.jfree.data.time.SerialDate) spreadsheetDate25);
        org.jfree.data.time.SerialDate serialDate29 = spreadsheetDate18.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate25);
        int int30 = spreadsheetDate25.getMonth();
        org.jfree.data.time.SerialDate serialDate31 = spreadsheetDate11.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate25);
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(serialDate31);
        try {
            org.jfree.data.time.SerialDate serialDate34 = serialDate31.getNearestDayOfWeek((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(serialDate31);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass10 = spreadsheetDate9.getClass();
        boolean boolean11 = spreadsheetDate6.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass16 = spreadsheetDate15.getClass();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean11, "December", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass16);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date1, "Thursday", "Thursday", (java.lang.Class) wildcardClass16);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = timeSeries18.getTimePeriod(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        java.lang.String str2 = year1.toString();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (byte) 10, year1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.previous();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate10 = spreadsheetDate6.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate9);
        boolean boolean11 = month3.equals((java.lang.Object) spreadsheetDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass18 = spreadsheetDate17.getClass();
        boolean boolean19 = spreadsheetDate14.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.addMonths((int) (short) 0, (org.jfree.data.time.SerialDate) spreadsheetDate14);
        boolean boolean21 = spreadsheetDate6.isAfter(serialDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass24 = spreadsheetDate23.getClass();
        java.lang.String str25 = spreadsheetDate23.getDescription();
        int int26 = spreadsheetDate6.compare((org.jfree.data.time.SerialDate) spreadsheetDate23);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate3);
        java.lang.String str5 = day4.toString();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day4);
        int int7 = day4.getDayOfMonth();
        long long8 = day4.getSerialIndex();
        int int9 = day4.getDayOfMonth();
        int int10 = day4.getDayOfMonth();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "9-January-1900" + "'", str5.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9 + "'", int7 == 9);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 9 + "'", int10 == 9);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        long long4 = year3.getFirstMillisecond();
        int int5 = year3.getYear();
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2, (org.jfree.data.time.RegularTimePeriod) year3);
        java.lang.Object obj7 = timeSeries1.clone();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        java.lang.String str2 = year1.toString();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (byte) 10, year1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.previous();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate10 = spreadsheetDate6.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate9);
        boolean boolean11 = month3.equals((java.lang.Object) spreadsheetDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate22 = spreadsheetDate18.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass25 = spreadsheetDate24.getClass();
        java.util.Date date26 = null;
        java.util.TimeZone timeZone27 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date26, timeZone27);
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate21, (java.lang.Class) wildcardClass25);
        boolean boolean30 = spreadsheetDate13.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate16, (org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate21);
        int int32 = month3.compareTo((java.lang.Object) timeSeries31);
        java.util.Calendar calendar33 = null;
        try {
            month3.peg(calendar33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate5 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass8 = spreadsheetDate7.getClass();
        java.util.Date date9 = null;
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date9, timeZone10);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate4, (java.lang.Class) wildcardClass8);
        boolean boolean13 = timeSeries12.isEmpty();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass19 = spreadsheetDate18.getClass();
        boolean boolean20 = spreadsheetDate15.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass25 = spreadsheetDate24.getClass();
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean20, "December", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass25);
        boolean boolean27 = timeSeries26.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries12.addAndOrUpdate(timeSeries26);
        timeSeries12.setDescription("Time");
        java.lang.String str31 = timeSeries12.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate35);
        java.lang.String str37 = day36.toString();
        timeSeries33.delete((org.jfree.data.time.RegularTimePeriod) day36);
        int int39 = day36.getDayOfMonth();
        long long40 = day36.getSerialIndex();
        int int41 = day36.getDayOfMonth();
        int int42 = timeSeries12.getIndex((org.jfree.data.time.RegularTimePeriod) day36);
        int int43 = timeSeries12.getItemCount();
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Time" + "'", str31.equals("Time"));
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "9-January-1900" + "'", str37.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 9 + "'", int39 == 9);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 10L + "'", long40 == 10L);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 9 + "'", int41 == 9);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
    }

//    @Test
//    public void test476() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test476");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
//        long long3 = fixedMillisecond2.getLastMillisecond();
//        java.util.Calendar calendar4 = null;
//        long long5 = fixedMillisecond2.getLastMillisecond(calendar4);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560192967030L + "'", long3 == 1560192967030L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560192967030L + "'", long5 == 1560192967030L);
//    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate5 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass8 = spreadsheetDate7.getClass();
        java.util.Date date9 = null;
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date9, timeZone10);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate4, (java.lang.Class) wildcardClass8);
        boolean boolean13 = timeSeries12.isEmpty();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass19 = spreadsheetDate18.getClass();
        boolean boolean20 = spreadsheetDate15.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass25 = spreadsheetDate24.getClass();
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean20, "December", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass25);
        boolean boolean27 = timeSeries26.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries12.addAndOrUpdate(timeSeries26);
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timeSeries12.removePropertyChangeListener(propertyChangeListener29);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(timeSeries28);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(9, (int) (byte) 0);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate4);
        java.lang.String str6 = day5.toString();
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) day5);
        int int8 = timeSeries2.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getFirstMillisecond();
        int int14 = year12.getYear();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (org.jfree.data.time.RegularTimePeriod) year12);
        boolean boolean16 = timeSeries2.equals((java.lang.Object) year12);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(10, year12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month17.next();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "9-January-1900" + "'", str6.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate5);
        java.lang.String str7 = day6.toString();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) day6);
        int int9 = day6.getDayOfMonth();
        long long10 = day6.getSerialIndex();
        int int11 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) day6);
        timeSeries1.setMaximumItemCount(12);
        java.lang.String str14 = timeSeries1.getDomainDescription();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        java.lang.String str16 = year15.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass21 = spreadsheetDate20.getClass();
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str16, "", "9-January-1900", (java.lang.Class) wildcardClass21);
        timeSeries22.clear();
        java.util.Collection collection24 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries22);
        java.beans.PropertyChangeListener propertyChangeListener25 = null;
        timeSeries22.addPropertyChangeListener(propertyChangeListener25);
        java.lang.Comparable comparable27 = timeSeries22.getKey();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "9-January-1900" + "'", str7.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Time" + "'", str14.equals("Time"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "2019" + "'", str16.equals("2019"));
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(collection24);
        org.junit.Assert.assertTrue("'" + comparable27 + "' != '" + "2019" + "'", comparable27.equals("2019"));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate5 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass8 = spreadsheetDate7.getClass();
        java.util.Date date9 = null;
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date9, timeZone10);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate4, (java.lang.Class) wildcardClass8);
        boolean boolean13 = timeSeries12.isEmpty();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass19 = spreadsheetDate18.getClass();
        boolean boolean20 = spreadsheetDate15.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass25 = spreadsheetDate24.getClass();
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean20, "December", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass25);
        boolean boolean27 = timeSeries26.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries12.addAndOrUpdate(timeSeries26);
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
        long long30 = year29.getFirstMillisecond();
        timeSeries12.delete((org.jfree.data.time.RegularTimePeriod) year29);
        int int32 = timeSeries12.getItemCount();
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1546329600000L + "'", long30 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate5 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass8 = spreadsheetDate7.getClass();
        java.util.Date date9 = null;
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date9, timeZone10);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate4, (java.lang.Class) wildcardClass8);
        java.lang.Comparable comparable13 = timeSeries12.getKey();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate17);
        java.lang.String str19 = day18.toString();
        timeSeries15.delete((org.jfree.data.time.RegularTimePeriod) day18);
        int int21 = day18.getDayOfMonth();
        long long22 = day18.getSerialIndex();
        int int23 = day18.getDayOfMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries12.getDataItem((org.jfree.data.time.RegularTimePeriod) day18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond(0L);
        boolean boolean28 = fixedMillisecond26.equals((java.lang.Object) 100.0d);
        int int30 = fixedMillisecond26.compareTo((java.lang.Object) 1);
        long long31 = fixedMillisecond26.getMiddleMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = fixedMillisecond32.next();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, regularTimePeriod33);
        timeSeries12.setNotify(false);
        timeSeries12.setNotify(false);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(comparable13);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "9-January-1900" + "'", str19.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 9 + "'", int21 == 9);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 10L + "'", long22 == 10L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 9 + "'", int23 == 9);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(timeSeries34);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(date2);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass11 = spreadsheetDate10.getClass();
        boolean boolean12 = spreadsheetDate7.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(0L);
        boolean boolean16 = fixedMillisecond14.equals((java.lang.Object) 100.0d);
        int int18 = fixedMillisecond14.compareTo((java.lang.Object) 1);
        long long19 = fixedMillisecond14.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (double) 9999);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        boolean boolean23 = timeSeriesDataItem21.equals((java.lang.Object) year22);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate26);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass30 = spreadsheetDate29.getClass();
        boolean boolean31 = spreadsheetDate26.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate29);
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.addYears((int) '4', (org.jfree.data.time.SerialDate) spreadsheetDate29);
        int int33 = timeSeriesDataItem21.compareTo((java.lang.Object) spreadsheetDate29);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate35);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass39 = spreadsheetDate38.getClass();
        boolean boolean40 = spreadsheetDate35.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate38);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate42);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate46 = spreadsheetDate42.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate45);
        boolean boolean47 = spreadsheetDate38.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate42);
        org.jfree.data.time.SerialDate serialDate48 = spreadsheetDate29.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate38);
        boolean boolean49 = spreadsheetDate7.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate29);
        org.jfree.data.time.SerialDate serialDate50 = org.jfree.data.time.SerialDate.addYears(11, (org.jfree.data.time.SerialDate) spreadsheetDate7);
        boolean boolean51 = year4.equals((java.lang.Object) serialDate50);
        boolean boolean53 = year4.equals((java.lang.Object) "Nearest");
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertNotNull(wildcardClass39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate5);
        java.lang.String str7 = day6.toString();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) day6);
        int int9 = day6.getDayOfMonth();
        long long10 = day6.getSerialIndex();
        int int11 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate17 = spreadsheetDate13.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass20 = spreadsheetDate19.getClass();
        java.util.Date date21 = null;
        java.util.TimeZone timeZone22 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass20, date21, timeZone22);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate16, (java.lang.Class) wildcardClass20);
        java.lang.Comparable comparable25 = timeSeries24.getKey();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate29);
        java.lang.String str31 = day30.toString();
        timeSeries27.delete((org.jfree.data.time.RegularTimePeriod) day30);
        int int33 = day30.getDayOfMonth();
        long long34 = day30.getSerialIndex();
        int int35 = day30.getDayOfMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries24.getDataItem((org.jfree.data.time.RegularTimePeriod) day30);
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond(0L);
        boolean boolean40 = fixedMillisecond38.equals((java.lang.Object) 100.0d);
        int int42 = fixedMillisecond38.compareTo((java.lang.Object) 1);
        long long43 = fixedMillisecond38.getMiddleMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = fixedMillisecond44.next();
        org.jfree.data.time.TimeSeries timeSeries46 = timeSeries24.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond38, regularTimePeriod45);
        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond(0L);
        boolean boolean50 = fixedMillisecond48.equals((java.lang.Object) 100.0d);
        timeSeries24.setKey((java.lang.Comparable) boolean50);
        java.util.Collection collection52 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries24);
        java.lang.Comparable comparable53 = timeSeries24.getKey();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "9-January-1900" + "'", str7.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(comparable25);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "9-January-1900" + "'", str31.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 9 + "'", int33 == 9);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 10L + "'", long34 == 10L);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 9 + "'", int35 == 9);
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 0L + "'", long43 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(timeSeries46);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(collection52);
        org.junit.Assert.assertTrue("'" + comparable53 + "' != '" + false + "'", comparable53.equals(false));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate3);
        java.lang.String str5 = day4.toString();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day4.previous();
        java.util.Date date8 = day4.getStart();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date8);
        java.util.Calendar calendar10 = null;
        try {
            month9.peg(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "9-January-1900" + "'", str5.equals("9-January-1900"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        boolean boolean3 = fixedMillisecond1.equals((java.lang.Object) 100.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.previous();
        long long5 = fixedMillisecond1.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(30, 30, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate5 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass8 = spreadsheetDate7.getClass();
        java.util.Date date9 = null;
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date9, timeZone10);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate4, (java.lang.Class) wildcardClass8);
        boolean boolean13 = timeSeries12.isEmpty();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass19 = spreadsheetDate18.getClass();
        boolean boolean20 = spreadsheetDate15.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass25 = spreadsheetDate24.getClass();
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean20, "December", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass25);
        boolean boolean27 = timeSeries26.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries12.addAndOrUpdate(timeSeries26);
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
        long long30 = year29.getFirstMillisecond();
        timeSeries12.delete((org.jfree.data.time.RegularTimePeriod) year29);
        int int32 = year29.getYear();
        java.lang.String str33 = year29.toString();
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1546329600000L + "'", long30 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2019 + "'", int32 == 2019);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "2019" + "'", str33.equals("2019"));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate5 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass8 = spreadsheetDate7.getClass();
        java.util.Date date9 = null;
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date9, timeZone10);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate4, (java.lang.Class) wildcardClass8);
        java.lang.Comparable comparable13 = timeSeries12.getKey();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate17);
        java.lang.String str19 = day18.toString();
        timeSeries15.delete((org.jfree.data.time.RegularTimePeriod) day18);
        int int21 = day18.getDayOfMonth();
        long long22 = day18.getSerialIndex();
        int int23 = day18.getDayOfMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries12.getDataItem((org.jfree.data.time.RegularTimePeriod) day18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond(0L);
        boolean boolean28 = fixedMillisecond26.equals((java.lang.Object) 100.0d);
        int int30 = fixedMillisecond26.compareTo((java.lang.Object) 1);
        long long31 = fixedMillisecond26.getMiddleMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = fixedMillisecond32.next();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, regularTimePeriod33);
        timeSeries12.setNotify(false);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate38);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate42 = spreadsheetDate38.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate41);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass45 = spreadsheetDate44.getClass();
        java.util.Date date46 = null;
        java.util.TimeZone timeZone47 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass45, date46, timeZone47);
        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate41, (java.lang.Class) wildcardClass45);
        java.lang.Comparable comparable50 = timeSeries49.getKey();
        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate54 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate54);
        java.lang.String str56 = day55.toString();
        timeSeries52.delete((org.jfree.data.time.RegularTimePeriod) day55);
        int int58 = day55.getDayOfMonth();
        long long59 = day55.getSerialIndex();
        int int60 = day55.getDayOfMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem61 = timeSeries49.getDataItem((org.jfree.data.time.RegularTimePeriod) day55);
        org.jfree.data.time.FixedMillisecond fixedMillisecond63 = new org.jfree.data.time.FixedMillisecond(0L);
        boolean boolean65 = fixedMillisecond63.equals((java.lang.Object) 100.0d);
        int int67 = fixedMillisecond63.compareTo((java.lang.Object) 1);
        long long68 = fixedMillisecond63.getMiddleMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond69 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = fixedMillisecond69.next();
        org.jfree.data.time.TimeSeries timeSeries71 = timeSeries49.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond63, regularTimePeriod70);
        org.jfree.data.time.TimeSeries timeSeries72 = timeSeries12.addAndOrUpdate(timeSeries49);
        timeSeries49.clear();
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(comparable13);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "9-January-1900" + "'", str19.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 9 + "'", int21 == 9);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 10L + "'", long22 == 10L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 9 + "'", int23 == 9);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertNotNull(wildcardClass45);
        org.junit.Assert.assertNull(regularTimePeriod48);
        org.junit.Assert.assertNotNull(comparable50);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "9-January-1900" + "'", str56.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 9 + "'", int58 == 9);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 10L + "'", long59 == 10L);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 9 + "'", int60 == 9);
        org.junit.Assert.assertNull(timeSeriesDataItem61);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1 + "'", int67 == 1);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 0L + "'", long68 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod70);
        org.junit.Assert.assertNotNull(timeSeries71);
        org.junit.Assert.assertNotNull(timeSeries72);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass5 = spreadsheetDate4.getClass();
        boolean boolean6 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass12 = spreadsheetDate11.getClass();
        boolean boolean13 = spreadsheetDate8.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate19 = spreadsheetDate15.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate18);
        boolean boolean20 = spreadsheetDate11.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean21 = spreadsheetDate4.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        long long26 = year25.getFirstMillisecond();
        int int27 = year25.getYear();
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries23.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (org.jfree.data.time.RegularTimePeriod) year25);
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = fixedMillisecond29.next();
        timeSeries28.delete(regularTimePeriod30);
        java.util.List list32 = timeSeries28.getItems();
        java.beans.PropertyChangeListener propertyChangeListener33 = null;
        timeSeries28.removePropertyChangeListener(propertyChangeListener33);
        boolean boolean35 = spreadsheetDate11.equals((java.lang.Object) timeSeries28);
        try {
            org.jfree.data.time.SerialDate serialDate37 = spreadsheetDate11.getPreviousDayOfWeek(9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1546329600000L + "'", long26 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(list32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

//    @Test
//    public void test492() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test492");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int3 = day0.compareTo((java.lang.Object) 2147483647);
//        int int4 = day0.getYear();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(4, true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Apr" + "'", str2.equals("Apr"));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate3);
        java.lang.String str5 = day4.toString();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day4);
        int int7 = timeSeries1.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getFirstMillisecond();
        int int13 = year11.getYear();
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries9.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (org.jfree.data.time.RegularTimePeriod) year11);
        boolean boolean15 = timeSeries1.equals((java.lang.Object) year11);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries1.createCopy(9999, 2147483647);
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond(0L);
        boolean boolean22 = fixedMillisecond20.equals((java.lang.Object) 100.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = fixedMillisecond20.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = fixedMillisecond20.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = fixedMillisecond20.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries1.addOrUpdate(regularTimePeriod25, (java.lang.Number) 1546329600000L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "9-January-1900" + "'", str5.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1546329600000L + "'", long12 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNull(timeSeriesDataItem27);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(13);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-456) + "'", int1 == (-456));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        java.lang.Comparable comparable0 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date4 = fixedMillisecond3.getTime();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass13 = spreadsheetDate12.getClass();
        boolean boolean14 = spreadsheetDate9.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass19 = spreadsheetDate18.getClass();
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean14, "December", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass19);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, "Thursday", "Thursday", (java.lang.Class) wildcardClass19);
        try {
            org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries(comparable0, "2019", "Thursday", (java.lang.Class) wildcardClass19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(wildcardClass19);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        boolean boolean3 = fixedMillisecond1.equals((java.lang.Object) 100.0d);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (java.lang.Number) 9);
        java.util.Calendar calendar6 = null;
        fixedMillisecond1.peg(calendar6);
        long long8 = fixedMillisecond1.getLastMillisecond();
        long long9 = fixedMillisecond1.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.SerialDate serialDate5 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.lang.Class<?> wildcardClass8 = spreadsheetDate7.getClass();
        java.util.Date date9 = null;
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date9, timeZone10);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate4, (java.lang.Class) wildcardClass8);
        java.lang.Comparable comparable13 = timeSeries12.getKey();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate17);
        java.lang.String str19 = day18.toString();
        timeSeries15.delete((org.jfree.data.time.RegularTimePeriod) day18);
        int int21 = day18.getDayOfMonth();
        long long22 = day18.getSerialIndex();
        int int23 = day18.getDayOfMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries12.getDataItem((org.jfree.data.time.RegularTimePeriod) day18);
        java.util.Calendar calendar25 = null;
        try {
            day18.peg(calendar25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(comparable13);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "9-January-1900" + "'", str19.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 9 + "'", int21 == 9);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 10L + "'", long22 == 10L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 9 + "'", int23 == 9);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate3);
        java.lang.String str5 = day4.toString();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day4.previous();
        java.util.Date date8 = day4.getStart();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date8);
        long long10 = month9.getSerialIndex();
        long long11 = month9.getLastMillisecond();
        java.util.Date date12 = month9.getEnd();
        long long13 = month9.getMiddleMillisecond();
        java.util.Calendar calendar14 = null;
        try {
            long long15 = month9.getFirstMillisecond(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "9-January-1900" + "'", str5.equals("9-January-1900"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 22801L + "'", long10 == 22801L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-2206281600001L) + "'", long11 == (-2206281600001L));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-2207620800001L) + "'", long13 == (-2207620800001L));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addMonths(1, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        java.util.Date date5 = spreadsheetDate2.toDate();
        try {
            org.jfree.data.time.SerialDate serialDate7 = spreadsheetDate2.getFollowingDayOfWeek((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(date5);
    }
}

