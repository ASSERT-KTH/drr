import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        try {
            java.awt.Color color1 = java.awt.Color.decode("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hi!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.jfree.chart.title.Title title0 = null;
        try {
            org.jfree.chart.event.TitleChangeEvent titleChangeEvent1 = new org.jfree.chart.event.TitleChangeEvent(title0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        int int1 = color0.getTransparency();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) '#', (double) (byte) 0, rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        java.awt.Paint paint0 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        java.awt.Color color0 = java.awt.Color.cyan;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        java.awt.Color color0 = java.awt.Color.yellow;
        int int1 = color0.getRGB();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-256) + "'", int1 == (-256));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        java.awt.color.ColorSpace colorSpace1 = null;
        float[] floatArray3 = new float[] { 100.0f };
        try {
            float[] floatArray4 = color0.getColorComponents(colorSpace1, floatArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray3);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        java.awt.Color color2 = java.awt.Color.getColor("RectangleEdge.TOP", (int) (short) 1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement1 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.ColumnArrangement columnArrangement2 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource0, (org.jfree.chart.block.Arrangement) columnArrangement1, (org.jfree.chart.block.Arrangement) columnArrangement2);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = null;
        try {
            legendTitle3.setHorizontalAlignment(horizontalAlignment4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'alignment' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        java.awt.Image image0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE;
        org.junit.Assert.assertNull(image0);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.jfree.chart.plot.Plot plot1 = null;
        try {
            org.jfree.chart.JFreeChart jFreeChart2 = new org.jfree.chart.JFreeChart("hi!", plot1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'plot' argument.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        java.awt.Color color0 = java.awt.Color.white;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = null;
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = null;
        try {
            org.jfree.chart.util.Size2D size2D4 = flowArrangement0.arrange(blockContainer1, graphics2D2, rectangleConstraint3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        int int0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALIGNMENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        try {
            defaultKeyedValues2D0.removeColumn(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("hi!", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name , locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("RectangleEdge.TOP", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        java.awt.Font font1 = null;
        try {
            org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'font' argument.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.jfree.chart.plot.Plot plot0 = null;
        try {
            org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent(plot0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        java.util.ResourceBundle.Control control3 = null;
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("", locale1, classLoader2, control3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets(0.0d, (double) 100.0f, (double) 192, (double) 1L);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.jfree.chart.plot.Plot plot1 = null;
        try {
            org.jfree.chart.JFreeChart jFreeChart2 = new org.jfree.chart.JFreeChart("", plot1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'plot' argument.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("Rotation.ANTICLOCKWISE", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.chart.util.TableOrder tableOrder0 = org.jfree.chart.util.TableOrder.BY_ROW;
        java.lang.String str1 = tableOrder0.toString();
        org.junit.Assert.assertNotNull(tableOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TableOrder.BY_ROW" + "'", str1.equals("TableOrder.BY_ROW"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.CENTER;
        java.lang.Object obj1 = null;
        boolean boolean2 = verticalAlignment0.equals(obj1);
        org.junit.Assert.assertNotNull(verticalAlignment0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        double double5 = rectangleInsets4.getBottom();
        double double6 = rectangleInsets4.getLeft();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 10.0d + "'", double6 == 10.0d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        java.util.ResourceBundle.clearCache();
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        java.awt.Color color2 = java.awt.Color.getColor("TableOrder.BY_ROW", 0);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        java.awt.Color color0 = java.awt.Color.darkGray;
        float[] floatArray1 = new float[] {};
        try {
            float[] floatArray2 = color0.getColorComponents(floatArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray1);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        java.awt.Color color0 = java.awt.Color.black;
        org.jfree.chart.block.FlowArrangement flowArrangement1 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.Block block2 = null;
        java.awt.Stroke stroke3 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        flowArrangement1.add(block2, (java.lang.Object) stroke3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = null;
        try {
            org.jfree.chart.block.LineBorder lineBorder6 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke3, rectangleInsets5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_START_ANGLE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 90.0d + "'", double0 == 90.0d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = null;
        try {
            org.jfree.chart.util.Size2D size2D4 = blockContainer1.arrange(graphics2D2, rectangleConstraint3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        java.lang.String str0 = org.jfree.chart.ui.Licences.GPL;
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        java.lang.String str1 = basicProjectInfo0.getCopyright();
        org.jfree.chart.ui.Library[] libraryArray2 = basicProjectInfo0.getLibraries();
        basicProjectInfo0.addOptionalLibrary("Rotation.ANTICLOCKWISE");
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(libraryArray2);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        float float0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.5f + "'", float0 == 0.5f);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            piePlot1.drawBackground(graphics2D4, rectangle2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        java.awt.Color color0 = java.awt.Color.WHITE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement7 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer8 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement7);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.util.Size2D size2D10 = blockContainer8.arrange(graphics2D9);
        blockContainer8.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D16 = blockContainer8.getBounds();
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor18 = null;
        java.awt.geom.Point2D point2D19 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D17, rectangleAnchor18);
        org.jfree.chart.plot.PlotState plotState20 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        try {
            piePlot1.draw(graphics2D6, rectangle2D16, point2D19, plotState20, plotRenderingInfo21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(size2D10);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(point2D19);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.util.Size2D size2D3 = blockContainer1.arrange(graphics2D2);
        blockContainer1.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D9 = blockContainer1.getBounds();
        double double10 = blockContainer1.getContentYOffset();
        org.junit.Assert.assertNotNull(size2D3);
        org.junit.Assert.assertNotNull(rectangle2D9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement1 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.ColumnArrangement columnArrangement2 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource0, (org.jfree.chart.block.Arrangement) columnArrangement1, (org.jfree.chart.block.Arrangement) columnArrangement2);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer9 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement8);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.util.Size2D size2D11 = blockContainer9.arrange(graphics2D10);
        blockContainer9.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D17 = blockContainer9.getBounds();
        java.lang.Object obj19 = textTitle6.draw(graphics2D7, rectangle2D17, (java.lang.Object) (short) 0);
        java.awt.Color color20 = java.awt.Color.black;
        int int21 = color20.getBlue();
        try {
            java.lang.Object obj22 = legendTitle3.draw(graphics2D4, rectangle2D17, (java.lang.Object) color20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(size2D11);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertNull(obj19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        java.awt.Font font1 = null;
        try {
            org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("TableOrder.BY_ROW", font1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'font' argument.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement1 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.ColumnArrangement columnArrangement2 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource0, (org.jfree.chart.block.Arrangement) columnArrangement1, (org.jfree.chart.block.Arrangement) columnArrangement2);
        columnArrangement1.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement5 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer6 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement5);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.util.Size2D size2D8 = blockContainer6.arrange(graphics2D7);
        blockContainer6.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D14 = blockContainer6.getBounds();
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = null;
        try {
            org.jfree.chart.util.Size2D size2D17 = columnArrangement1.arrange(blockContainer6, graphics2D15, rectangleConstraint16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(size2D8);
        org.junit.Assert.assertNotNull(rectangle2D14);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.08d + "'", double0 == 0.08d);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        double double0 = org.jfree.chart.plot.PiePlot.MAX_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.4d + "'", double0 == 0.4d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.util.Size2D size2D3 = blockContainer1.arrange(graphics2D2);
        java.lang.Object obj4 = null;
        boolean boolean5 = blockContainer1.equals(obj4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = null;
        try {
            org.jfree.chart.util.Size2D size2D8 = blockContainer1.arrange(graphics2D6, rectangleConstraint7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(size2D3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.util.Size2D size2D3 = blockContainer1.arrange(graphics2D2);
        java.lang.Object obj4 = null;
        boolean boolean5 = blockContainer1.equals(obj4);
        java.lang.Class<?> wildcardClass6 = blockContainer1.getClass();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement11 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer12 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement11);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.util.Size2D size2D14 = blockContainer12.arrange(graphics2D13);
        blockContainer12.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D20 = blockContainer12.getBounds();
        java.lang.Object obj22 = textTitle9.draw(graphics2D10, rectangle2D20, (java.lang.Object) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor23 = null;
        java.awt.geom.Point2D point2D24 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D20, rectangleAnchor23);
        java.awt.Color color25 = java.awt.Color.GREEN;
        float[] floatArray30 = new float[] { (byte) 1, (short) 0, (short) 100, (short) -1 };
        float[] floatArray31 = color25.getComponents(floatArray30);
        try {
            java.lang.Object obj32 = blockContainer1.draw(graphics2D7, rectangle2D20, (java.lang.Object) floatArray31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(size2D3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(size2D14);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNull(obj22);
        org.junit.Assert.assertNotNull(point2D24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray31);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        piePlot1.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        piePlot1.setDataset(pieDataset8);
        boolean boolean10 = piePlot1.isCircular();
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        java.text.NumberFormat numberFormat1 = null;
        java.text.NumberFormat numberFormat2 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("PieSection: 0, 100(1)", numberFormat1, numberFormat2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'numberFormat' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        int int3 = java.awt.Color.HSBtoRGB((float) (byte) 1, 0.5f, (float) 100L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-4325426) + "'", int3 == (-4325426));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        piePlot1.setLabelLinkMargin(0.0d);
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        piePlot1.setBaseSectionOutlinePaint((java.awt.Paint) color8);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.lang.String str1 = rectangleAnchor0.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleAnchor.BOTTOM_LEFT" + "'", str1.equals("RectangleAnchor.BOTTOM_LEFT"));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement1 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.ColumnArrangement columnArrangement2 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource0, (org.jfree.chart.block.Arrangement) columnArrangement1, (org.jfree.chart.block.Arrangement) columnArrangement2);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = null;
        try {
            org.jfree.chart.util.Size2D size2D6 = legendTitle3.arrange(graphics2D4, rectangleConstraint5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        try {
            java.awt.Color color1 = java.awt.Color.decode("Rotation.ANTICLOCKWISE");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Rotation.ANTICLOCKWISE\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        boolean boolean5 = piePlot1.equals((java.lang.Object) 2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor(15, 192, (int) (short) 10);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 0, (int) (byte) 100, (java.lang.Comparable) 1L, "RectangleEdge.TOP", "RectangleEdge.TOP");
        org.jfree.data.general.PieDataset pieDataset8 = null;
        pieSectionEntity7.setDataset(pieDataset8);
        java.lang.String str10 = pieSectionEntity7.toString();
        pieSectionEntity7.setSectionKey((java.lang.Comparable) 0);
        int int13 = pieSectionEntity7.getPieIndex();
        pieSectionEntity7.setSectionIndex(0);
        pieSectionEntity7.setToolTipText("JFreeChart version RectangleEdge.TOP.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nTableOrder.BY_ROW");
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "PieSection: 0, 100(1)" + "'", str10.equals("PieSection: 0, 100(1)"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 0, (int) (byte) 100, (java.lang.Comparable) 1L, "RectangleEdge.TOP", "RectangleEdge.TOP");
        org.jfree.chart.JFreeChart jFreeChart8 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent9 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0, jFreeChart8);
        org.jfree.chart.JFreeChart jFreeChart10 = chartChangeEvent9.getChart();
        org.jfree.chart.JFreeChart jFreeChart11 = chartChangeEvent9.getChart();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNull(jFreeChart10);
        org.junit.Assert.assertNull(jFreeChart11);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D();
        java.awt.Color color2 = java.awt.Color.GREEN;
        float[] floatArray7 = new float[] { (byte) 1, (short) 0, (short) 100, (short) -1 };
        float[] floatArray8 = color2.getComponents(floatArray7);
        boolean boolean9 = defaultKeyedValues2D1.equals((java.lang.Object) floatArray8);
        int int10 = defaultKeyedValues2D1.getColumnCount();
        int int11 = defaultKeyedValues2D1.getColumnCount();
        boolean boolean12 = rectangleAnchor0.equals((java.lang.Object) int11);
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement1 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.ColumnArrangement columnArrangement2 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource0, (org.jfree.chart.block.Arrangement) columnArrangement1, (org.jfree.chart.block.Arrangement) columnArrangement2);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray4 = null;
        try {
            legendTitle3.setSources(legendItemSourceArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'sources' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha((float) 0);
        boolean boolean4 = piePlot1.getIgnoreZeroValues();
        piePlot1.setIgnoreNullValues(true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setLabelLinkMargin(4.0d);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean13 = rectangleInsets11.equals((java.lang.Object) rectangleAnchor12);
        org.jfree.chart.block.ColumnArrangement columnArrangement14 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer15 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement14);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.util.Size2D size2D17 = blockContainer15.arrange(graphics2D16);
        blockContainer15.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D23 = blockContainer15.getBounds();
        java.awt.geom.Rectangle2D rectangle2D26 = rectangleInsets11.createInsetRectangle(rectangle2D23, true, false);
        org.jfree.chart.title.TextTitle textTitle28 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement30 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer31 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement30);
        java.awt.Graphics2D graphics2D32 = null;
        org.jfree.chart.util.Size2D size2D33 = blockContainer31.arrange(graphics2D32);
        blockContainer31.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D39 = blockContainer31.getBounds();
        java.lang.Object obj41 = textTitle28.draw(graphics2D29, rectangle2D39, (java.lang.Object) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor42 = null;
        java.awt.geom.Point2D point2D43 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D39, rectangleAnchor42);
        org.jfree.chart.plot.PlotState plotState44 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo45 = null;
        try {
            piePlot1.draw(graphics2D6, rectangle2D26, point2D43, plotState44, plotRenderingInfo45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(size2D17);
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertNotNull(size2D33);
        org.junit.Assert.assertNotNull(rectangle2D39);
        org.junit.Assert.assertNull(obj41);
        org.junit.Assert.assertNotNull(point2D43);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.util.Size2D size2D3 = blockContainer1.arrange(graphics2D2);
        blockContainer1.setHeight((double) 1);
        java.lang.Object obj6 = blockContainer1.clone();
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.Shape shape8 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity15 = new org.jfree.chart.entity.PieSectionEntity(shape8, pieDataset9, 0, (int) (byte) 100, (java.lang.Comparable) 1L, "RectangleEdge.TOP", "RectangleEdge.TOP");
        pieSectionEntity15.setSectionKey((java.lang.Comparable) 0L);
        boolean boolean19 = pieSectionEntity15.equals((java.lang.Object) "hi!");
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement23 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer24 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement23);
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.util.Size2D size2D26 = blockContainer24.arrange(graphics2D25);
        blockContainer24.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D32 = blockContainer24.getBounds();
        java.lang.Object obj34 = textTitle21.draw(graphics2D22, rectangle2D32, (java.lang.Object) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor35 = null;
        java.awt.geom.Point2D point2D36 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D32, rectangleAnchor35);
        pieSectionEntity15.setArea((java.awt.Shape) rectangle2D32);
        try {
            blockContainer1.draw(graphics2D7, rectangle2D32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(size2D3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(size2D26);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertNull(obj34);
        org.junit.Assert.assertNotNull(point2D36);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("hi!", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean6 = rectangleInsets4.equals((java.lang.Object) rectangleAnchor5);
        org.jfree.chart.block.ColumnArrangement columnArrangement7 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer8 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement7);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.util.Size2D size2D10 = blockContainer8.arrange(graphics2D9);
        blockContainer8.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D16 = blockContainer8.getBounds();
        java.awt.geom.Rectangle2D rectangle2D19 = rectangleInsets4.createInsetRectangle(rectangle2D16, true, false);
        org.jfree.chart.entity.ChartEntity chartEntity22 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D19, "RectangleEdge.TOP", "HorizontalAlignment.CENTER");
        java.lang.String str23 = chartEntity22.getToolTipText();
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(size2D10);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "RectangleEdge.TOP" + "'", str23.equals("RectangleEdge.TOP"));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.util.Size2D size2D3 = blockContainer1.arrange(graphics2D2);
        java.lang.Object obj4 = null;
        boolean boolean5 = blockContainer1.equals(obj4);
        java.lang.Class<?> wildcardClass6 = blockContainer1.getClass();
        java.util.List list7 = blockContainer1.getBlocks();
        org.junit.Assert.assertNotNull(size2D3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(list7);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.util.Size2D size2D3 = blockContainer1.arrange(graphics2D2);
        java.lang.Object obj4 = null;
        boolean boolean5 = blockContainer1.equals(obj4);
        java.lang.Object obj6 = blockContainer1.clone();
        boolean boolean7 = blockContainer1.isEmpty();
        org.junit.Assert.assertNotNull(size2D3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.calculateTopOutset((double) 0);
        java.lang.String str3 = rectangleInsets0.toString();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo8 = new org.jfree.chart.ui.BasicProjectInfo("JFreeChart version RectangleEdge.TOP.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nTableOrder.BY_ROW", "HorizontalAlignment.CENTER", "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        boolean boolean9 = rectangleInsets0.equals((java.lang.Object) "JFreeChart version RectangleEdge.TOP.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nTableOrder.BY_ROW");
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]" + "'", str3.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement1 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.ColumnArrangement columnArrangement2 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource0, (org.jfree.chart.block.Arrangement) columnArrangement1, (org.jfree.chart.block.Arrangement) columnArrangement2);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity12 = new org.jfree.chart.entity.PieSectionEntity(shape5, pieDataset6, 0, (int) (byte) 100, (java.lang.Comparable) 1L, "RectangleEdge.TOP", "RectangleEdge.TOP");
        pieSectionEntity12.setSectionKey((java.lang.Comparable) 0L);
        boolean boolean16 = pieSectionEntity12.equals((java.lang.Object) "hi!");
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement20 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer21 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement20);
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.util.Size2D size2D23 = blockContainer21.arrange(graphics2D22);
        blockContainer21.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D29 = blockContainer21.getBounds();
        java.lang.Object obj31 = textTitle18.draw(graphics2D19, rectangle2D29, (java.lang.Object) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor32 = null;
        java.awt.geom.Point2D point2D33 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D29, rectangleAnchor32);
        pieSectionEntity12.setArea((java.awt.Shape) rectangle2D29);
        java.lang.Object obj35 = null;
        try {
            java.lang.Object obj36 = legendTitle3.draw(graphics2D4, rectangle2D29, obj35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(size2D23);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertNull(obj31);
        org.junit.Assert.assertNotNull(point2D33);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        java.awt.Color color1 = java.awt.Color.GREEN;
        float[] floatArray6 = new float[] { (byte) 1, (short) 0, (short) 100, (short) -1 };
        float[] floatArray7 = color1.getComponents(floatArray6);
        boolean boolean8 = defaultKeyedValues2D0.equals((java.lang.Object) floatArray7);
        int int9 = defaultKeyedValues2D0.getColumnCount();
        int int10 = defaultKeyedValues2D0.getColumnCount();
        int int12 = defaultKeyedValues2D0.getRowIndex((java.lang.Comparable) true);
        java.lang.Object obj13 = defaultKeyedValues2D0.clone();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(obj13);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        java.lang.String str0 = org.jfree.chart.ui.Licences.LGPL;
    }

//    @Test
//    public void test087() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test087");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        java.lang.String str1 = projectInfo0.toString();
//        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D2 = new org.jfree.data.DefaultKeyedValues2D();
//        java.awt.Color color3 = java.awt.Color.GREEN;
//        float[] floatArray8 = new float[] { (byte) 1, (short) 0, (short) 100, (short) -1 };
//        float[] floatArray9 = color3.getComponents(floatArray8);
//        boolean boolean10 = defaultKeyedValues2D2.equals((java.lang.Object) floatArray9);
//        int int11 = defaultKeyedValues2D2.getColumnCount();
//        int int12 = defaultKeyedValues2D2.getColumnCount();
//        java.util.List list13 = defaultKeyedValues2D2.getColumnKeys();
//        projectInfo0.setContributors(list13);
//        java.lang.String str15 = projectInfo0.getVersion();
//        org.jfree.chart.ui.ProjectInfo projectInfo16 = org.jfree.chart.JFreeChart.INFO;
//        java.lang.String str17 = projectInfo16.toString();
//        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D18 = new org.jfree.data.DefaultKeyedValues2D();
//        java.awt.Color color19 = java.awt.Color.GREEN;
//        float[] floatArray24 = new float[] { (byte) 1, (short) 0, (short) 100, (short) -1 };
//        float[] floatArray25 = color19.getComponents(floatArray24);
//        boolean boolean26 = defaultKeyedValues2D18.equals((java.lang.Object) floatArray25);
//        int int27 = defaultKeyedValues2D18.getColumnCount();
//        int int28 = defaultKeyedValues2D18.getColumnCount();
//        java.util.List list29 = defaultKeyedValues2D18.getColumnKeys();
//        projectInfo16.setContributors(list29);
//        projectInfo0.setContributors(list29);
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JFreeChart version RectangleEdge.TOP.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nTableOrder.BY_ROW" + "'", str1.equals("JFreeChart version RectangleEdge.TOP.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nTableOrder.BY_ROW"));
//        org.junit.Assert.assertNotNull(color3);
//        org.junit.Assert.assertNotNull(floatArray8);
//        org.junit.Assert.assertNotNull(floatArray9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertNotNull(list13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "RectangleEdge.TOP" + "'", str15.equals("RectangleEdge.TOP"));
//        org.junit.Assert.assertNotNull(projectInfo16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "JFreeChart version RectangleEdge.TOP.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nTableOrder.BY_ROW" + "'", str17.equals("JFreeChart version RectangleEdge.TOP.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nTableOrder.BY_ROW"));
//        org.junit.Assert.assertNotNull(color19);
//        org.junit.Assert.assertNotNull(floatArray24);
//        org.junit.Assert.assertNotNull(floatArray25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//        org.junit.Assert.assertNotNull(list29);
//    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        java.awt.Color color0 = java.awt.Color.lightGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha((float) 0);
        java.awt.Stroke stroke4 = piePlot1.getBaseSectionOutlineStroke();
        java.lang.Comparable comparable5 = null;
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_RED;
        try {
            piePlot1.setSectionPaint(comparable5, (java.awt.Paint) color6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(color6);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) '#', (double) 1.0f, (double) 0.5f, 0.0d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        java.awt.Color color0 = java.awt.Color.gray;
        int int1 = color0.getGreen();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 128 + "'", int1 == 128);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        java.util.Locale locale1 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("hi!", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        java.awt.Paint[] paintArray0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.util.Size2D size2D3 = blockContainer1.arrange(graphics2D2);
        blockContainer1.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        double double9 = blockContainer1.getContentXOffset();
        org.junit.Assert.assertNotNull(size2D3);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setLabelLinkMargin(4.0d);
        java.awt.Paint paint6 = piePlot1.getShadowPaint();
        org.jfree.chart.StrokeMap strokeMap7 = new org.jfree.chart.StrokeMap();
        boolean boolean8 = piePlot1.equals((java.lang.Object) strokeMap7);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        java.awt.Stroke stroke6 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        piePlot1.setLabelOutlineStroke(stroke6);
        double double8 = piePlot1.getLabelLinkMargin();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean16 = rectangleInsets14.equals((java.lang.Object) rectangleAnchor15);
        org.jfree.chart.block.ColumnArrangement columnArrangement17 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer18 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement17);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.util.Size2D size2D20 = blockContainer18.arrange(graphics2D19);
        blockContainer18.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D26 = blockContainer18.getBounds();
        java.awt.geom.Rectangle2D rectangle2D29 = rectangleInsets14.createInsetRectangle(rectangle2D26, true, false);
        org.jfree.chart.entity.ChartEntity chartEntity32 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D29, "RectangleEdge.TOP", "HorizontalAlignment.CENTER");
        try {
            piePlot1.drawOutline(graphics2D9, rectangle2D29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.025d + "'", double8 == 0.025d);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(size2D20);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertNotNull(rectangle2D29);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        java.awt.Color color1 = java.awt.Color.GREEN;
        float[] floatArray6 = new float[] { (byte) 1, (short) 0, (short) 100, (short) -1 };
        float[] floatArray7 = color1.getComponents(floatArray6);
        boolean boolean8 = defaultKeyedValues2D0.equals((java.lang.Object) floatArray7);
        int int9 = defaultKeyedValues2D0.getColumnCount();
        int int10 = defaultKeyedValues2D0.getColumnCount();
        java.util.List list11 = defaultKeyedValues2D0.getColumnKeys();
        java.lang.Number number12 = null;
        defaultKeyedValues2D0.setValue(number12, (java.lang.Comparable) 192, (java.lang.Comparable) 1);
        try {
            defaultKeyedValues2D0.removeColumn((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(list11);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        double double5 = rectangleInsets4.getBottom();
        double double7 = rectangleInsets4.calculateTopOutset((double) (-1));
        double double8 = rectangleInsets4.getBottom();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        java.awt.Stroke stroke6 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        piePlot1.setLabelOutlineStroke(stroke6);
        piePlot1.setMaximumLabelWidth((-1.0d));
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        piePlot1.removeChangeListener(plotChangeListener10);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("RectangleAnchor.BOTTOM_LEFT");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name RectangleAnchor.BOTTOM_LEFT, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement3 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer4 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.util.Size2D size2D6 = blockContainer4.arrange(graphics2D5);
        blockContainer4.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D12 = blockContainer4.getBounds();
        java.lang.Object obj14 = textTitle1.draw(graphics2D2, rectangle2D12, (java.lang.Object) (short) 0);
        textTitle1.setPadding(0.0d, (double) (short) 1, (double) (short) 0, (double) (-256));
        java.awt.Font font20 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        textTitle1.setFont(font20);
        org.junit.Assert.assertNotNull(size2D6);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertNull(obj14);
        org.junit.Assert.assertNotNull(font20);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha((float) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean10 = rectangleInsets8.equals((java.lang.Object) rectangleAnchor9);
        double double12 = rectangleInsets8.calculateBottomInset((double) (-1L));
        piePlot1.setSimpleLabelOffset(rectangleInsets8);
        java.awt.Color color14 = java.awt.Color.DARK_GRAY;
        piePlot1.setBackgroundPaint((java.awt.Paint) color14);
        org.jfree.chart.util.Rotation rotation16 = piePlot1.getDirection();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor22 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean23 = rectangleInsets21.equals((java.lang.Object) rectangleAnchor22);
        double double25 = rectangleInsets21.calculateTopInset(0.0d);
        piePlot1.setLabelPadding(rectangleInsets21);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 100.0d + "'", double12 == 100.0d);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(rotation16);
        org.junit.Assert.assertNotNull(rectangleAnchor22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + (-1.0d) + "'", double25 == (-1.0d));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("TableOrder.BY_ROW", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        try {
            multiplePiePlot0.setPieChart(jFreeChart1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'pieChart' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean8 = rectangleInsets6.equals((java.lang.Object) rectangleAnchor7);
        org.jfree.chart.block.ColumnArrangement columnArrangement9 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer10 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement9);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.util.Size2D size2D12 = blockContainer10.arrange(graphics2D11);
        blockContainer10.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D18 = blockContainer10.getBounds();
        java.awt.geom.Rectangle2D rectangle2D21 = rectangleInsets6.createInsetRectangle(rectangle2D18, true, false);
        java.awt.geom.Point2D point2D22 = null;
        org.jfree.chart.plot.PlotState plotState23 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        try {
            multiplePiePlot0.draw(graphics2D1, rectangle2D21, point2D22, plotState23, plotRenderingInfo24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(size2D12);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertNotNull(rectangle2D21);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle0 = org.jfree.chart.plot.PieLabelLinkStyle.CUBIC_CURVE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        piePlot2.setForegroundAlpha((float) 0);
        java.awt.Stroke stroke5 = piePlot2.getBaseSectionOutlineStroke();
        boolean boolean6 = pieLabelLinkStyle0.equals((java.lang.Object) piePlot2);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle0);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement1 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.ColumnArrangement columnArrangement2 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource0, (org.jfree.chart.block.Arrangement) columnArrangement1, (org.jfree.chart.block.Arrangement) columnArrangement2);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean11 = rectangleInsets9.equals((java.lang.Object) rectangleAnchor10);
        org.jfree.chart.block.ColumnArrangement columnArrangement12 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer13 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement12);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.util.Size2D size2D15 = blockContainer13.arrange(graphics2D14);
        blockContainer13.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D21 = blockContainer13.getBounds();
        java.awt.geom.Rectangle2D rectangle2D24 = rectangleInsets9.createInsetRectangle(rectangle2D21, true, false);
        org.jfree.data.general.PieDataset pieDataset25 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity31 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D24, pieDataset25, 15, 0, (java.lang.Comparable) 1, "hi!", "RectangleEdge.TOP");
        java.awt.Paint paint36 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder37 = new org.jfree.chart.block.BlockBorder((double) 10, (double) '#', (double) 0L, 0.0d, paint36);
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = blockBorder37.getInsets();
        try {
            java.lang.Object obj39 = legendTitle3.draw(graphics2D4, rectangle2D24, (java.lang.Object) blockBorder37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(size2D15);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(rectangleInsets38);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha((float) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean10 = rectangleInsets8.equals((java.lang.Object) rectangleAnchor9);
        double double12 = rectangleInsets8.calculateBottomInset((double) (-1L));
        piePlot1.setSimpleLabelOffset(rectangleInsets8);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle14 = org.jfree.chart.plot.PieLabelLinkStyle.CUBIC_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle14);
        boolean boolean17 = pieLabelLinkStyle14.equals((java.lang.Object) "TableOrder.BY_ROW");
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 100.0d + "'", double12 == 100.0d);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.chart.PaintMap paintMap0 = new org.jfree.chart.PaintMap();
        java.awt.Paint paint2 = paintMap0.getPaint((java.lang.Comparable) (short) 10);
        java.awt.Paint paint4 = paintMap0.getPaint((java.lang.Comparable) 1.0f);
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNull(paint4);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.block.BlockBorder blockBorder2 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color1);
        multiplePiePlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.util.TableOrder tableOrder4 = org.jfree.chart.util.TableOrder.BY_ROW;
        multiplePiePlot0.setDataExtractOrder(tableOrder4);
        org.jfree.data.general.DatasetGroup datasetGroup6 = multiplePiePlot0.getDatasetGroup();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(tableOrder4);
        org.junit.Assert.assertNull(datasetGroup6);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        java.lang.Class<?> wildcardClass1 = verticalAlignment0.getClass();
        org.junit.Assert.assertNotNull(verticalAlignment0);
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 0, (int) (byte) 100, (java.lang.Comparable) 1L, "RectangleEdge.TOP", "RectangleEdge.TOP");
        org.jfree.chart.entity.ChartEntity chartEntity8 = new org.jfree.chart.entity.ChartEntity(shape0);
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = null;
        try {
            org.jfree.chart.util.Size2D size2D4 = textTitle1.arrange(graphics2D2, rectangleConstraint3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setForegroundAlpha((float) 0);
        java.awt.Stroke stroke6 = piePlot3.getBaseSectionOutlineStroke();
        piePlot3.setLabelLinkMargin((double) (-256));
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("PieSection: 0, 100(1)", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = null;
        try {
            java.awt.image.BufferedImage bufferedImage15 = jFreeChart10.createBufferedImage(0, 2, (int) (byte) 100, chartRenderingInfo14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown image type 100");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("", "");
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement1 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.ColumnArrangement columnArrangement2 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource0, (org.jfree.chart.block.Arrangement) columnArrangement1, (org.jfree.chart.block.Arrangement) columnArrangement2);
        org.jfree.chart.block.BlockContainer blockContainer4 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement1);
        java.lang.Class<?> wildcardClass5 = columnArrangement1.getClass();
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        java.awt.Color color1 = java.awt.Color.GREEN;
        float[] floatArray6 = new float[] { (byte) 1, (short) 0, (short) 100, (short) -1 };
        float[] floatArray7 = color1.getComponents(floatArray6);
        boolean boolean8 = defaultKeyedValues2D0.equals((java.lang.Object) floatArray7);
        int int9 = defaultKeyedValues2D0.getColumnCount();
        int int10 = defaultKeyedValues2D0.getColumnCount();
        java.util.List list11 = defaultKeyedValues2D0.getColumnKeys();
        int int13 = defaultKeyedValues2D0.getColumnIndex((java.lang.Comparable) "hi!");
        java.lang.Comparable comparable15 = null;
        try {
            java.lang.Number number16 = defaultKeyedValues2D0.getValue((java.lang.Comparable) "TableOrder.BY_ROW", comparable15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'columnKey' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        java.awt.Stroke stroke6 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        piePlot1.setLabelOutlineStroke(stroke6);
        piePlot1.setMaximumLabelWidth((-1.0d));
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        piePlot1.markerChanged(markerChangeEvent10);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        int int3 = java.awt.Color.HSBtoRGB(0.5f, (float) 10L, (-1.0f));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-254) + "'", int3 == (-254));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha((float) 0);
        boolean boolean4 = piePlot1.getIgnoreZeroValues();
        java.awt.Color color5 = java.awt.Color.YELLOW;
        java.awt.Color color6 = color5.darker();
        piePlot1.setShadowPaint((java.awt.Paint) color6);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor8 = null;
        try {
            piePlot1.setLabelDistributor(abstractPieLabelDistributor8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'distributor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        java.awt.Color color4 = java.awt.Color.getColor("RectangleEdge.TOP", (int) (short) 1);
        org.jfree.chart.ChartColor chartColor8 = new org.jfree.chart.ChartColor(15, 192, (int) (short) 10);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType9 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.awt.Color color10 = java.awt.Color.GREEN;
        boolean boolean11 = chartChangeEventType9.equals((java.lang.Object) color10);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        int int13 = color12.getTransparency();
        java.awt.Color color14 = java.awt.Color.BLACK;
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        java.awt.Paint[] paintArray16 = new java.awt.Paint[] { color4, chartColor8, color10, color12, color14, color15 };
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType17 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.awt.Color color18 = java.awt.Color.GREEN;
        boolean boolean19 = chartChangeEventType17.equals((java.lang.Object) color18);
        java.awt.Paint paint24 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder25 = new org.jfree.chart.block.BlockBorder((double) 10, (double) '#', (double) 0L, 0.0d, paint24);
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.Paint[] paintArray27 = new java.awt.Paint[] { color18, paint24, color26 };
        java.awt.Paint[] paintArray28 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray29 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray30 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray31 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier32 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray16, paintArray27, paintArray28, strokeArray29, strokeArray30, shapeArray31);
        boolean boolean33 = blockBorder1.equals((java.lang.Object) strokeArray30);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(chartChangeEventType9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(paintArray16);
        org.junit.Assert.assertNotNull(chartChangeEventType17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(paintArray27);
        org.junit.Assert.assertNotNull(paintArray28);
        org.junit.Assert.assertNotNull(strokeArray29);
        org.junit.Assert.assertNotNull(strokeArray30);
        org.junit.Assert.assertNotNull(shapeArray31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        java.lang.String str5 = rectangleInsets4.toString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "RectangleInsets[t=-1.0,l=10.0,b=100.0,r=1.0]" + "'", str5.equals("RectangleInsets[t=-1.0,l=10.0,b=100.0,r=1.0]"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        java.lang.String str3 = rectangleEdge2.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge2);
        legendTitle1.setLegendItemGraphicEdge(rectangleEdge2);
        boolean boolean6 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge2);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleEdge.TOP" + "'", str3.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D5 = new org.jfree.data.DefaultKeyedValues2D();
        java.awt.Color color6 = java.awt.Color.GREEN;
        float[] floatArray11 = new float[] { (byte) 1, (short) 0, (short) 100, (short) -1 };
        float[] floatArray12 = color6.getComponents(floatArray11);
        boolean boolean13 = defaultKeyedValues2D5.equals((java.lang.Object) floatArray12);
        int int14 = defaultKeyedValues2D5.getColumnCount();
        boolean boolean15 = rectangleInsets4.equals((java.lang.Object) defaultKeyedValues2D5);
        java.lang.Comparable comparable16 = null;
        try {
            defaultKeyedValues2D5.removeValue(comparable16, (java.lang.Comparable) "RectangleAnchor.BOTTOM_LEFT");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.util.Size2D size2D3 = blockContainer1.arrange(graphics2D2);
        java.lang.Object obj4 = null;
        boolean boolean5 = blockContainer1.equals(obj4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement11 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer12 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement11);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.util.Size2D size2D14 = blockContainer12.arrange(graphics2D13);
        blockContainer12.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D20 = blockContainer12.getBounds();
        java.lang.Object obj22 = textTitle9.draw(graphics2D10, rectangle2D20, (java.lang.Object) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor23 = null;
        java.awt.geom.Point2D point2D24 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D20, rectangleAnchor23);
        textTitle7.setBounds(rectangle2D20);
        org.jfree.chart.title.TextTitle textTitle27 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        try {
            java.lang.Object obj28 = blockContainer1.draw(graphics2D6, rectangle2D20, (java.lang.Object) textTitle27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(size2D3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(size2D14);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNull(obj22);
        org.junit.Assert.assertNotNull(point2D24);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        int int3 = java.awt.Color.HSBtoRGB((float) 0, (float) (short) 100, (float) 15);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-262450) + "'", int3 == (-262450));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        java.awt.Font font1 = null;
        java.awt.Color color2 = java.awt.Color.GREEN;
        float[] floatArray7 = new float[] { (byte) 1, (short) 0, (short) 100, (short) -1 };
        float[] floatArray8 = color2.getComponents(floatArray7);
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        java.lang.String str10 = rectangleEdge9.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge9);
        boolean boolean12 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge9);
        org.jfree.chart.util.Rotation rotation13 = org.jfree.chart.util.Rotation.ANTICLOCKWISE;
        java.lang.String str14 = rotation13.toString();
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment17 = textTitle16.getTextAlignment();
        boolean boolean18 = rotation13.equals((java.lang.Object) horizontalAlignment17);
        org.jfree.chart.util.VerticalAlignment verticalAlignment19 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.data.general.PieDataset pieDataset20 = null;
        org.jfree.chart.plot.PiePlot piePlot21 = new org.jfree.chart.plot.PiePlot(pieDataset20);
        piePlot21.setForegroundAlpha(0.0f);
        piePlot21.setStartAngle((double) 100L);
        piePlot21.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset28 = null;
        piePlot21.setDataset(pieDataset28);
        piePlot21.setMaximumLabelWidth((double) (byte) 100);
        java.awt.Stroke stroke33 = piePlot21.getSectionOutlineStroke((java.lang.Comparable) (short) 0);
        org.jfree.data.general.PieDataset pieDataset34 = null;
        org.jfree.chart.plot.PiePlot piePlot35 = new org.jfree.chart.plot.PiePlot(pieDataset34);
        piePlot35.setForegroundAlpha((float) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor43 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean44 = rectangleInsets42.equals((java.lang.Object) rectangleAnchor43);
        double double46 = rectangleInsets42.calculateBottomInset((double) (-1L));
        piePlot35.setSimpleLabelOffset(rectangleInsets42);
        piePlot21.setInsets(rectangleInsets42);
        try {
            org.jfree.chart.title.TextTitle textTitle49 = new org.jfree.chart.title.TextTitle("TableOrder.BY_ROW", font1, (java.awt.Paint) color2, rectangleEdge9, horizontalAlignment17, verticalAlignment19, rectangleInsets42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'font' argument.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "RectangleEdge.TOP" + "'", str10.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(rotation13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Rotation.ANTICLOCKWISE" + "'", str14.equals("Rotation.ANTICLOCKWISE"));
        org.junit.Assert.assertNotNull(horizontalAlignment17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(verticalAlignment19);
        org.junit.Assert.assertNull(stroke33);
        org.junit.Assert.assertNotNull(rectangleAnchor43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 100.0d + "'", double46 == 100.0d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.ANTICLOCKWISE;
        java.lang.String str1 = rotation0.toString();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = textTitle3.getTextAlignment();
        boolean boolean5 = rotation0.equals((java.lang.Object) horizontalAlignment4);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D11 = new org.jfree.data.DefaultKeyedValues2D();
        java.awt.Color color12 = java.awt.Color.GREEN;
        float[] floatArray17 = new float[] { (byte) 1, (short) 0, (short) 100, (short) -1 };
        float[] floatArray18 = color12.getComponents(floatArray17);
        boolean boolean19 = defaultKeyedValues2D11.equals((java.lang.Object) floatArray18);
        int int20 = defaultKeyedValues2D11.getColumnCount();
        boolean boolean21 = rectangleInsets10.equals((java.lang.Object) defaultKeyedValues2D11);
        boolean boolean22 = horizontalAlignment4.equals((java.lang.Object) rectangleInsets10);
        org.junit.Assert.assertNotNull(rotation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Rotation.ANTICLOCKWISE" + "'", str1.equals("Rotation.ANTICLOCKWISE"));
        org.junit.Assert.assertNotNull(horizontalAlignment4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("hi!", "");
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = textTitle1.getTextAlignment();
        java.lang.String str3 = horizontalAlignment2.toString();
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font5 = textTitle4.getFont();
        org.jfree.chart.util.VerticalAlignment verticalAlignment6 = textTitle4.getVerticalAlignment();
        org.jfree.chart.block.FlowArrangement flowArrangement9 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment2, verticalAlignment6, (double) (short) 0, (double) (short) 1);
        java.awt.Color color14 = java.awt.Color.LIGHT_GRAY;
        int int15 = color14.getGreen();
        org.jfree.chart.block.BlockBorder blockBorder16 = new org.jfree.chart.block.BlockBorder(10.0d, (double) 0L, (double) 0, (double) (byte) -1, (java.awt.Paint) color14);
        java.awt.Paint paint17 = blockBorder16.getPaint();
        boolean boolean18 = flowArrangement9.equals((java.lang.Object) blockBorder16);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "HorizontalAlignment.CENTER" + "'", str3.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(verticalAlignment6);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 192 + "'", int15 == 192);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha((float) 0);
        boolean boolean4 = piePlot1.getIgnoreZeroValues();
        double double5 = piePlot1.getShadowXOffset();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo9 = null;
        java.awt.image.BufferedImage bufferedImage10 = jFreeChart6.createBufferedImage((int) 'a', (int) (byte) 100, chartRenderingInfo9);
        java.awt.Paint paint11 = jFreeChart6.getBackgroundPaint();
        java.awt.RenderingHints renderingHints12 = null;
        try {
            jFreeChart6.setRenderingHints(renderingHints12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: RenderingHints given are null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(bufferedImage10);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 0, (int) (byte) 100, (java.lang.Comparable) 1L, "RectangleEdge.TOP", "RectangleEdge.TOP");
        org.jfree.data.general.PieDataset pieDataset8 = null;
        pieSectionEntity7.setDataset(pieDataset8);
        java.lang.String str10 = pieSectionEntity7.toString();
        pieSectionEntity7.setSectionKey((java.lang.Comparable) 0);
        int int13 = pieSectionEntity7.getPieIndex();
        int int14 = pieSectionEntity7.getPieIndex();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "PieSection: 0, 100(1)" + "'", str10.equals("PieSection: 0, 100(1)"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        piePlot1.setForegroundAlpha((float) (short) 100);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        piePlot9.setForegroundAlpha((float) 0);
        boolean boolean12 = piePlot9.getIgnoreZeroValues();
        double double13 = piePlot9.getShadowXOffset();
        piePlot9.setIgnoreZeroValues(true);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator16 = piePlot9.getLegendLabelGenerator();
        piePlot1.setLegendLabelGenerator(pieSectionLabelGenerator16);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 4.0d + "'", double13 == 4.0d);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator16);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        boolean boolean2 = textTitle0.equals((java.lang.Object) color1);
        java.lang.String str3 = textTitle0.getURLText();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 0, (int) (byte) 100, (java.lang.Comparable) 1L, "RectangleEdge.TOP", "RectangleEdge.TOP");
        org.jfree.chart.JFreeChart jFreeChart8 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent9 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0, jFreeChart8);
        org.jfree.chart.JFreeChart jFreeChart10 = chartChangeEvent9.getChart();
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        chartChangeEvent9.setChart(jFreeChart11);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot14 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.util.TableOrder tableOrder15 = org.jfree.chart.util.TableOrder.BY_COLUMN;
        multiplePiePlot14.setDataExtractOrder(tableOrder15);
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.chart.plot.Plot) multiplePiePlot14);
        chartChangeEvent9.setChart(jFreeChart17);
        java.lang.String str19 = chartChangeEvent9.toString();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNull(jFreeChart10);
        org.junit.Assert.assertNotNull(tableOrder15);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=0]" + "'", str19.equals("org.jfree.chart.event.ChartChangeEvent[source=0]"));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
        java.awt.Paint paint1 = blockBorder0.getPaint();
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = null;
        try {
            org.jfree.chart.util.Size2D size2D4 = legendTitle1.arrange(graphics2D2, rectangleConstraint3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        java.awt.Color color0 = java.awt.Color.magenta;
        int int1 = color0.getGreen();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        java.awt.Color color1 = java.awt.Color.GREEN;
        float[] floatArray6 = new float[] { (byte) 1, (short) 0, (short) 100, (short) -1 };
        float[] floatArray7 = color1.getComponents(floatArray6);
        boolean boolean8 = defaultKeyedValues2D0.equals((java.lang.Object) floatArray7);
        defaultKeyedValues2D0.clear();
        try {
            java.lang.Comparable comparable11 = defaultKeyedValues2D0.getColumnKey((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) (short) 0, 10.0f, 0.5f);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        java.awt.Color color2 = java.awt.Color.getColor("HorizontalAlignment.CENTER", (int) (short) -1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.util.TableOrder tableOrder2 = org.jfree.chart.util.TableOrder.BY_COLUMN;
        multiplePiePlot1.setDataExtractOrder(tableOrder2);
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.chart.plot.Plot) multiplePiePlot1);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement9 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer10 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement9);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.util.Size2D size2D12 = blockContainer10.arrange(graphics2D11);
        blockContainer10.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D18 = blockContainer10.getBounds();
        java.lang.Object obj20 = textTitle7.draw(graphics2D8, rectangle2D18, (java.lang.Object) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor21 = null;
        java.awt.geom.Point2D point2D22 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D18, rectangleAnchor21);
        org.jfree.chart.block.ColumnArrangement columnArrangement23 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer24 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement23);
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.util.Size2D size2D26 = blockContainer24.arrange(graphics2D25);
        blockContainer24.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D32 = blockContainer24.getBounds();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor33 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Point2D point2D34 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D32, rectangleAnchor33);
        org.jfree.chart.plot.PlotState plotState35 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = null;
        try {
            multiplePiePlot1.draw(graphics2D5, rectangle2D18, point2D34, plotState35, plotRenderingInfo36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(tableOrder2);
        org.junit.Assert.assertNotNull(size2D12);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertNull(obj20);
        org.junit.Assert.assertNotNull(point2D22);
        org.junit.Assert.assertNotNull(size2D26);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertNotNull(rectangleAnchor33);
        org.junit.Assert.assertNotNull(point2D34);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        java.awt.Stroke stroke2 = strokeMap0.getStroke((java.lang.Comparable) 4.0d);
        java.lang.Comparable comparable3 = null;
        try {
            boolean boolean4 = strokeMap0.containsKey(comparable3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(stroke2);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.Block block1 = null;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        flowArrangement0.add(block1, (java.lang.Object) stroke2);
        flowArrangement0.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement5 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer6 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement5);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.util.Size2D size2D8 = blockContainer6.arrange(graphics2D7);
        blockContainer6.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D14 = blockContainer6.getBounds();
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = null;
        try {
            org.jfree.chart.util.Size2D size2D17 = flowArrangement0.arrange(blockContainer6, graphics2D15, rectangleConstraint16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(size2D8);
        org.junit.Assert.assertNotNull(rectangle2D14);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.block.BlockBorder blockBorder2 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color1);
        multiplePiePlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.ui.Contributor contributor6 = new org.jfree.chart.ui.Contributor("RectangleEdge.TOP", "RectangleEdge.TOP");
        java.lang.String str7 = contributor6.getName();
        boolean boolean8 = multiplePiePlot0.equals((java.lang.Object) contributor6);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        multiplePiePlot0.setAggregatedItemsKey((java.lang.Comparable) "RectangleAnchor.CENTER");
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "RectangleEdge.TOP" + "'", str7.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.block.BlockBorder blockBorder2 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color1);
        multiplePiePlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        java.lang.Comparable comparable4 = multiplePiePlot0.getAggregatedItemsKey();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + "Other" + "'", comparable4.equals("Other"));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateLeftInset(0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("HorizontalAlignment.CENTER", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test152() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test152");
//        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
//        org.jfree.chart.ui.ProjectInfo projectInfo1 = org.jfree.chart.JFreeChart.INFO;
//        java.lang.String str2 = projectInfo1.toString();
//        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D3 = new org.jfree.data.DefaultKeyedValues2D();
//        java.awt.Color color4 = java.awt.Color.GREEN;
//        float[] floatArray9 = new float[] { (byte) 1, (short) 0, (short) 100, (short) -1 };
//        float[] floatArray10 = color4.getComponents(floatArray9);
//        boolean boolean11 = defaultKeyedValues2D3.equals((java.lang.Object) floatArray10);
//        int int12 = defaultKeyedValues2D3.getColumnCount();
//        int int13 = defaultKeyedValues2D3.getColumnCount();
//        java.util.List list14 = defaultKeyedValues2D3.getColumnKeys();
//        projectInfo1.setContributors(list14);
//        boolean boolean16 = defaultCategoryDataset0.equals((java.lang.Object) projectInfo1);
//        java.lang.Comparable comparable18 = null;
//        try {
//            defaultCategoryDataset0.incrementValue(89.0d, comparable18, (java.lang.Comparable) 1.0f);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowKey' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(projectInfo1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JFreeChart version RectangleEdge.TOP.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nTableOrder.BY_ROW" + "'", str2.equals("JFreeChart version RectangleEdge.TOP.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nTableOrder.BY_ROW"));
//        org.junit.Assert.assertNotNull(color4);
//        org.junit.Assert.assertNotNull(floatArray9);
//        org.junit.Assert.assertNotNull(floatArray10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertNotNull(list14);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        double double6 = piePlot1.getInteriorGap();
        piePlot1.setMinimumArcAngleToDraw(0.4d);
        piePlot1.setMinimumArcAngleToDraw((double) (short) 0);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator11 = piePlot1.getLabelGenerator();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.08d + "'", double6 == 0.08d);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator11);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        java.util.ResourceBundle.Control control3 = null;
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("hi!", locale1, classLoader2, control3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo1 = new org.jfree.chart.ui.BasicProjectInfo();
        java.lang.String str2 = basicProjectInfo1.getCopyright();
        basicProjectInfo0.addLibrary((org.jfree.chart.ui.Library) basicProjectInfo1);
        basicProjectInfo1.setName("RectangleEdge.TOP");
        java.lang.String str6 = basicProjectInfo1.getCopyright();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        java.awt.Color color2 = java.awt.Color.getColor("RectangleEdge.TOP", (int) (short) 1);
        org.jfree.chart.ChartColor chartColor6 = new org.jfree.chart.ChartColor(15, 192, (int) (short) 10);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.awt.Color color8 = java.awt.Color.GREEN;
        boolean boolean9 = chartChangeEventType7.equals((java.lang.Object) color8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        int int11 = color10.getTransparency();
        java.awt.Color color12 = java.awt.Color.BLACK;
        java.awt.Color color13 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        java.awt.Paint[] paintArray14 = new java.awt.Paint[] { color2, chartColor6, color8, color10, color12, color13 };
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType15 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.awt.Color color16 = java.awt.Color.GREEN;
        boolean boolean17 = chartChangeEventType15.equals((java.lang.Object) color16);
        java.awt.Paint paint22 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder23 = new org.jfree.chart.block.BlockBorder((double) 10, (double) '#', (double) 0L, 0.0d, paint22);
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.Paint[] paintArray25 = new java.awt.Paint[] { color16, paint22, color24 };
        java.awt.Paint[] paintArray26 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray27 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray28 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray29 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier30 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray14, paintArray25, paintArray26, strokeArray27, strokeArray28, shapeArray29);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot31 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.util.TableOrder tableOrder32 = org.jfree.chart.util.TableOrder.BY_COLUMN;
        multiplePiePlot31.setDataExtractOrder(tableOrder32);
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        boolean boolean35 = tableOrder32.equals((java.lang.Object) rectangleEdge34);
        org.jfree.chart.title.TextTitle textTitle37 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D38 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement39 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer40 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement39);
        java.awt.Graphics2D graphics2D41 = null;
        org.jfree.chart.util.Size2D size2D42 = blockContainer40.arrange(graphics2D41);
        blockContainer40.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D48 = blockContainer40.getBounds();
        java.lang.Object obj50 = textTitle37.draw(graphics2D38, rectangle2D48, (java.lang.Object) (short) 0);
        boolean boolean51 = textTitle37.getExpandToFitSpace();
        boolean boolean52 = tableOrder32.equals((java.lang.Object) textTitle37);
        boolean boolean53 = defaultDrawingSupplier30.equals((java.lang.Object) tableOrder32);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(chartChangeEventType7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(paintArray14);
        org.junit.Assert.assertNotNull(chartChangeEventType15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(paintArray25);
        org.junit.Assert.assertNotNull(paintArray26);
        org.junit.Assert.assertNotNull(strokeArray27);
        org.junit.Assert.assertNotNull(strokeArray28);
        org.junit.Assert.assertNotNull(shapeArray29);
        org.junit.Assert.assertNotNull(tableOrder32);
        org.junit.Assert.assertNotNull(rectangleEdge34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(size2D42);
        org.junit.Assert.assertNotNull(rectangle2D48);
        org.junit.Assert.assertNull(obj50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

//    @Test
//    public void test158() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test158");
//        org.jfree.data.general.PieDataset pieDataset0 = null;
//        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
//        piePlot1.setForegroundAlpha((float) 0);
//        boolean boolean4 = piePlot1.getIgnoreZeroValues();
//        double double5 = piePlot1.getShadowXOffset();
//        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
//        org.jfree.chart.ui.ProjectInfo projectInfo10 = org.jfree.chart.JFreeChart.INFO;
//        java.lang.String str11 = projectInfo10.toString();
//        projectInfo10.setVersion("RectangleEdge.TOP");
//        java.awt.Image image14 = projectInfo10.getLogo();
//        org.jfree.chart.ui.ProjectInfo projectInfo18 = new org.jfree.chart.ui.ProjectInfo("PieSection: 0, 100(1)", "", "RectangleAnchor.BOTTOM_LEFT", image14, "1.2.0-pre", "1.2.0-pre", "TableOrder.BY_ROW");
//        jFreeChart6.setBackgroundImage(image14);
//        org.jfree.chart.event.ChartChangeListener chartChangeListener20 = null;
//        try {
//            jFreeChart6.addChangeListener(chartChangeListener20);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
//        org.junit.Assert.assertNotNull(projectInfo10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "JFreeChart version RectangleEdge.TOP.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nTableOrder.BY_ROW" + "'", str11.equals("JFreeChart version RectangleEdge.TOP.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nTableOrder.BY_ROW"));
//        org.junit.Assert.assertNotNull(image14);
//    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        java.awt.Color color1 = java.awt.Color.GREEN;
        float[] floatArray6 = new float[] { (byte) 1, (short) 0, (short) 100, (short) -1 };
        float[] floatArray7 = color1.getComponents(floatArray6);
        boolean boolean8 = defaultKeyedValues2D0.equals((java.lang.Object) floatArray7);
        int int9 = defaultKeyedValues2D0.getColumnCount();
        int int10 = defaultKeyedValues2D0.getColumnCount();
        defaultKeyedValues2D0.setValue((java.lang.Number) 0, (java.lang.Comparable) "hi!", (java.lang.Comparable) (byte) -1);
        try {
            defaultKeyedValues2D0.removeColumn(15);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 15, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        java.lang.Comparable comparable1 = null;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setForegroundAlpha(0.0f);
        piePlot3.setStartAngle((double) 100L);
        piePlot3.setForegroundAlpha((float) (short) 100);
        double double10 = piePlot3.getShadowYOffset();
        java.awt.Stroke stroke11 = piePlot3.getBaseSectionOutlineStroke();
        try {
            strokeMap0.put(comparable1, stroke11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setForegroundAlpha((float) 0);
        java.awt.Stroke stroke6 = piePlot3.getBaseSectionOutlineStroke();
        piePlot3.setLabelLinkMargin((double) (-256));
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("PieSection: 0, 100(1)", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
        jFreeChart10.setBorderVisible(false);
        try {
            org.jfree.chart.plot.XYPlot xYPlot13 = jFreeChart10.getXYPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.PiePlot cannot be cast to org.jfree.chart.plot.XYPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        piePlot1.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        piePlot1.setDataset(pieDataset8);
        org.jfree.data.general.PieDataset pieDataset10 = piePlot1.getDataset();
        org.jfree.chart.plot.Plot plot11 = piePlot1.getRootPlot();
        org.junit.Assert.assertNull(pieDataset10);
        org.junit.Assert.assertNotNull(plot11);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.util.Size2D size2D3 = blockContainer1.arrange(graphics2D2);
        double double4 = blockContainer1.getContentYOffset();
        org.junit.Assert.assertNotNull(size2D3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        int int1 = color0.getBlue();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        int int3 = java.awt.Color.HSBtoRGB((float) 100L, (float) ' ', (float) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-7904) + "'", int3 == (-7904));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        piePlot1.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        piePlot1.setDataset(pieDataset8);
        piePlot1.setMaximumLabelWidth((double) (byte) 100);
        java.awt.Stroke stroke13 = piePlot1.getSectionOutlineStroke((java.lang.Comparable) (short) 0);
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        piePlot15.setForegroundAlpha((float) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor23 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean24 = rectangleInsets22.equals((java.lang.Object) rectangleAnchor23);
        double double26 = rectangleInsets22.calculateBottomInset((double) (-1L));
        piePlot15.setSimpleLabelOffset(rectangleInsets22);
        piePlot1.setInsets(rectangleInsets22);
        java.awt.Color color29 = java.awt.Color.BLUE;
        piePlot1.setLabelLinkPaint((java.awt.Paint) color29);
        org.jfree.data.general.PieDataset pieDataset31 = null;
        org.jfree.chart.plot.PiePlot piePlot32 = new org.jfree.chart.plot.PiePlot(pieDataset31);
        piePlot32.setForegroundAlpha(0.0f);
        java.awt.Color color35 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        piePlot32.setShadowPaint((java.awt.Paint) color35);
        piePlot1.setLabelPaint((java.awt.Paint) color35);
        org.junit.Assert.assertNull(stroke13);
        org.junit.Assert.assertNotNull(rectangleAnchor23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 100.0d + "'", double26 == 100.0d);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color35);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        java.awt.Color color0 = java.awt.Color.BLUE;
        int int1 = color0.getBlue();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setForegroundAlpha((float) 0);
        java.awt.Stroke stroke6 = piePlot3.getBaseSectionOutlineStroke();
        piePlot3.setLabelLinkMargin((double) (-256));
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("PieSection: 0, 100(1)", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
        jFreeChart10.setBorderVisible(false);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent13 = null;
        try {
            jFreeChart10.plotChanged(plotChangeEvent13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.TOP;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        piePlot1.setForegroundAlpha((float) (short) 100);
        double double8 = piePlot1.getShadowYOffset();
        java.awt.Stroke stroke9 = piePlot1.getBaseSectionOutlineStroke();
        java.lang.String str10 = piePlot1.getNoDataMessage();
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.0d + "'", double8 == 4.0d);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.util.TableOrder tableOrder2 = org.jfree.chart.util.TableOrder.BY_COLUMN;
        multiplePiePlot1.setDataExtractOrder(tableOrder2);
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.chart.plot.Plot) multiplePiePlot1);
        java.awt.Color color5 = java.awt.Color.PINK;
        multiplePiePlot1.setAggregatedItemsPaint((java.awt.Paint) color5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = null;
        try {
            multiplePiePlot1.setInsets(rectangleInsets7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(tableOrder2);
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setForegroundAlpha((float) 0);
        java.awt.Stroke stroke6 = piePlot3.getBaseSectionOutlineStroke();
        piePlot3.setLabelLinkMargin((double) (-256));
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("PieSection: 0, 100(1)", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
        jFreeChart10.setBorderVisible(false);
        boolean boolean13 = jFreeChart10.isBorderVisible();
        jFreeChart10.setBackgroundImageAlpha(0.0f);
        jFreeChart10.setAntiAlias(false);
        jFreeChart10.removeLegend();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        double double1 = multiplePiePlot0.getLimit();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent2 = null;
        multiplePiePlot0.notifyListeners(plotChangeEvent2);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        java.awt.Color color1 = java.awt.Color.GREEN;
        float[] floatArray6 = new float[] { (byte) 1, (short) 0, (short) 100, (short) -1 };
        float[] floatArray7 = color1.getComponents(floatArray6);
        boolean boolean8 = defaultKeyedValues2D0.equals((java.lang.Object) floatArray7);
        int int9 = defaultKeyedValues2D0.getColumnCount();
        try {
            defaultKeyedValues2D0.removeRow(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 0, (int) (byte) 100, (java.lang.Comparable) 1L, "RectangleEdge.TOP", "RectangleEdge.TOP");
        org.jfree.data.general.PieDataset pieDataset8 = null;
        pieSectionEntity7.setDataset(pieDataset8);
        java.lang.String str10 = pieSectionEntity7.toString();
        pieSectionEntity7.setSectionKey((java.lang.Comparable) 0);
        pieSectionEntity7.setURLText("PieSection: 0, 100(1)");
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "PieSection: 0, 100(1)" + "'", str10.equals("PieSection: 0, 100(1)"));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.chart.ui.Licences licences0 = org.jfree.chart.ui.Licences.getInstance();
        java.lang.String str1 = licences0.getGPL();
        org.junit.Assert.assertNotNull(licences0);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        java.lang.String str1 = rectangleEdge0.toString();
        boolean boolean2 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge0);
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleEdge.TOP" + "'", str1.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape0, "RectangleAnchor.BOTTOM_LEFT");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.block.BlockBorder blockBorder2 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color1);
        multiplePiePlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.util.TableOrder tableOrder4 = org.jfree.chart.util.TableOrder.BY_ROW;
        multiplePiePlot0.setDataExtractOrder(tableOrder4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = multiplePiePlot0.getDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot7 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.util.TableOrder tableOrder8 = org.jfree.chart.util.TableOrder.BY_COLUMN;
        multiplePiePlot7.setDataExtractOrder(tableOrder8);
        multiplePiePlot0.setDataExtractOrder(tableOrder8);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(tableOrder4);
        org.junit.Assert.assertNull(categoryDataset6);
        org.junit.Assert.assertNotNull(tableOrder8);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        double double6 = piePlot1.getInteriorGap();
        piePlot1.setMinimumArcAngleToDraw(0.4d);
        org.jfree.chart.plot.Plot plot9 = piePlot1.getRootPlot();
        java.awt.Stroke stroke10 = plot9.getOutlineStroke();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.08d + "'", double6 == 0.08d);
        org.junit.Assert.assertNotNull(plot9);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        piePlot1.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        piePlot1.setDataset(pieDataset8);
        org.jfree.data.general.PieDataset pieDataset10 = piePlot1.getDataset();
        piePlot1.setOutlineVisible(false);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset13 = new org.jfree.data.category.DefaultCategoryDataset();
        java.util.List list14 = defaultCategoryDataset13.getColumnKeys();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent15 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) piePlot1, (org.jfree.data.general.Dataset) defaultCategoryDataset13);
        try {
            defaultCategoryDataset13.removeColumn(255);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 255, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(pieDataset10);
        org.junit.Assert.assertNotNull(list14);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha((float) 0);
        boolean boolean4 = piePlot1.getIgnoreZeroValues();
        double double5 = piePlot1.getShadowXOffset();
        java.awt.Stroke stroke6 = piePlot1.getLabelLinkStroke();
        double double8 = piePlot1.getExplodePercent((java.lang.Comparable) 100.0d);
        piePlot1.setShadowYOffset((double) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.setLicenceText("PieSection: 0, 100(1)");
        org.junit.Assert.assertNotNull(projectInfo0);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font1 = textTitle0.getFont();
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = textTitle0.getVerticalAlignment();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle0);
        org.jfree.chart.event.TitleChangeListener titleChangeListener4 = null;
        textTitle0.addChangeListener(titleChangeListener4);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(verticalAlignment2);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        java.awt.Font font0 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        java.awt.Color color1 = java.awt.Color.GREEN;
        float[] floatArray6 = new float[] { (byte) 1, (short) 0, (short) 100, (short) -1 };
        float[] floatArray7 = color1.getComponents(floatArray6);
        boolean boolean8 = defaultKeyedValues2D0.equals((java.lang.Object) floatArray7);
        defaultKeyedValues2D0.clear();
        try {
            defaultKeyedValues2D0.removeColumn((java.lang.Comparable) 35.0d);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unknown key: 35.0");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha((float) 0);
        boolean boolean4 = piePlot1.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator5 = piePlot1.getLegendLabelToolTipGenerator();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator5);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("TableOrder.BY_ROW");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name TableOrder.BY_ROW, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        try {
            defaultCategoryDataset0.removeColumn((java.lang.Comparable) 2.0d);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unknown key: 2.0");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        java.lang.String str1 = basicProjectInfo0.getCopyright();
        java.lang.String str2 = basicProjectInfo0.getName();
        basicProjectInfo0.setVersion("PieSection: 0, 100(1)");
        org.jfree.chart.ui.Library[] libraryArray5 = basicProjectInfo0.getLibraries();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(libraryArray5);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        java.awt.Paint paint4 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder((double) 10, (double) '#', (double) 0L, 0.0d, paint4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = blockBorder5.getInsets();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = blockBorder5.getInsets();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 0, (int) (byte) 100, (java.lang.Comparable) 1L, "RectangleEdge.TOP", "RectangleEdge.TOP");
        pieSectionEntity7.setSectionKey((java.lang.Comparable) 0L);
        pieSectionEntity7.setPieIndex((int) (short) 1);
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement1 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.ColumnArrangement columnArrangement2 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource0, (org.jfree.chart.block.Arrangement) columnArrangement1, (org.jfree.chart.block.Arrangement) columnArrangement2);
        columnArrangement1.clear();
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity12 = new org.jfree.chart.entity.PieSectionEntity(shape5, pieDataset6, 0, (int) (byte) 100, (java.lang.Comparable) 1L, "RectangleEdge.TOP", "RectangleEdge.TOP");
        org.jfree.chart.JFreeChart jFreeChart13 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent14 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0, jFreeChart13);
        boolean boolean15 = columnArrangement1.equals((java.lang.Object) chartChangeEvent14);
        columnArrangement1.clear();
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        java.awt.Color color0 = java.awt.Color.GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setForegroundAlpha((float) 0);
        java.awt.Stroke stroke6 = piePlot3.getBaseSectionOutlineStroke();
        piePlot3.setLabelLinkMargin((double) (-256));
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("PieSection: 0, 100(1)", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
        org.jfree.chart.event.ChartProgressListener chartProgressListener11 = null;
        jFreeChart10.removeProgressListener(chartProgressListener11);
        float float13 = jFreeChart10.getBackgroundImageAlpha();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        try {
            java.awt.image.BufferedImage bufferedImage18 = jFreeChart10.createBufferedImage((int) 'a', (-262450), (int) (byte) 100, chartRenderingInfo17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown image type 100");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.5f + "'", float13 == 0.5f);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", "RectangleAnchor.CENTER");
        java.lang.String str3 = contributor2.getEmail();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleAnchor.CENTER" + "'", str3.equals("RectangleAnchor.CENTER"));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        float float6 = piePlot1.getBackgroundAlpha();
        java.awt.Paint paint8 = piePlot1.getSectionPaint((java.lang.Comparable) "HorizontalAlignment.CENTER");
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
        org.junit.Assert.assertNull(paint8);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = legendTitle1.getLegendItemGraphicPadding();
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        legendTitle1.setBackgroundPaint((java.awt.Paint) color3);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = legendTitle1.getLegendItemGraphicAnchor();
        java.awt.Color color6 = java.awt.Color.green;
        java.awt.Color color7 = color6.darker();
        boolean boolean8 = legendTitle1.equals((java.lang.Object) color7);
        java.awt.Font font9 = legendTitle1.getItemFont();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(font9);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        double double6 = piePlot1.getInteriorGap();
        java.awt.Paint paint7 = piePlot1.getLabelOutlinePaint();
        java.awt.Color color10 = java.awt.Color.getColor("RectangleEdge.TOP", (int) (short) 1);
        org.jfree.chart.ChartColor chartColor14 = new org.jfree.chart.ChartColor(15, 192, (int) (short) 10);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType15 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.awt.Color color16 = java.awt.Color.GREEN;
        boolean boolean17 = chartChangeEventType15.equals((java.lang.Object) color16);
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        int int19 = color18.getTransparency();
        java.awt.Color color20 = java.awt.Color.BLACK;
        java.awt.Color color21 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        java.awt.Paint[] paintArray22 = new java.awt.Paint[] { color10, chartColor14, color16, color18, color20, color21 };
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType23 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.awt.Color color24 = java.awt.Color.GREEN;
        boolean boolean25 = chartChangeEventType23.equals((java.lang.Object) color24);
        java.awt.Paint paint30 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder31 = new org.jfree.chart.block.BlockBorder((double) 10, (double) '#', (double) 0L, 0.0d, paint30);
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.Paint[] paintArray33 = new java.awt.Paint[] { color24, paint30, color32 };
        java.awt.Paint[] paintArray34 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray35 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray36 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray37 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier38 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray22, paintArray33, paintArray34, strokeArray35, strokeArray36, shapeArray37);
        piePlot1.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier38);
        java.awt.Paint paint40 = defaultDrawingSupplier38.getNextFillPaint();
        java.awt.Stroke stroke41 = defaultDrawingSupplier38.getNextStroke();
        org.jfree.chart.block.FlowArrangement flowArrangement42 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.Block block43 = null;
        java.awt.Stroke stroke44 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        flowArrangement42.add(block43, (java.lang.Object) stroke44);
        boolean boolean46 = defaultDrawingSupplier38.equals((java.lang.Object) flowArrangement42);
        try {
            java.awt.Shape shape47 = defaultDrawingSupplier38.getNextShape();
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.08d + "'", double6 == 0.08d);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(chartChangeEventType15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(paintArray22);
        org.junit.Assert.assertNotNull(chartChangeEventType23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(paintArray33);
        org.junit.Assert.assertNotNull(paintArray34);
        org.junit.Assert.assertNotNull(strokeArray35);
        org.junit.Assert.assertNotNull(strokeArray36);
        org.junit.Assert.assertNotNull(shapeArray37);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        java.awt.Color color1 = java.awt.Color.GREEN;
        float[] floatArray6 = new float[] { (byte) 1, (short) 0, (short) 100, (short) -1 };
        float[] floatArray7 = color1.getComponents(floatArray6);
        boolean boolean8 = defaultKeyedValues2D0.equals((java.lang.Object) floatArray7);
        int int9 = defaultKeyedValues2D0.getColumnCount();
        int int10 = defaultKeyedValues2D0.getColumnCount();
        java.util.List list11 = defaultKeyedValues2D0.getColumnKeys();
        try {
            defaultKeyedValues2D0.removeColumn((java.lang.Comparable) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unknown key: 10");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(list11);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        java.awt.Color color3 = java.awt.Color.red;
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.color.ColorSpace colorSpace5 = color4.getColorSpace();
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D6 = new org.jfree.data.DefaultKeyedValues2D();
        java.awt.Color color7 = java.awt.Color.GREEN;
        float[] floatArray12 = new float[] { (byte) 1, (short) 0, (short) 100, (short) -1 };
        float[] floatArray13 = color7.getComponents(floatArray12);
        boolean boolean14 = defaultKeyedValues2D6.equals((java.lang.Object) floatArray13);
        float[] floatArray15 = color3.getColorComponents(colorSpace5, floatArray13);
        float[] floatArray16 = java.awt.Color.RGBtoHSB((int) (byte) 100, (int) (short) 100, 100, floatArray13);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(colorSpace5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 0, (int) (byte) 100, (java.lang.Comparable) 1L, "RectangleEdge.TOP", "RectangleEdge.TOP");
        java.lang.String str8 = pieSectionEntity7.getURLText();
        pieSectionEntity7.setPieIndex(3);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "RectangleEdge.TOP" + "'", str8.equals("RectangleEdge.TOP"));
    }

//    @Test
//    public void test208() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test208");
//        org.jfree.data.general.PieDataset pieDataset0 = null;
//        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
//        piePlot1.setForegroundAlpha((float) 0);
//        boolean boolean4 = piePlot1.getIgnoreZeroValues();
//        double double5 = piePlot1.getShadowXOffset();
//        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
//        org.jfree.chart.ui.ProjectInfo projectInfo10 = org.jfree.chart.JFreeChart.INFO;
//        java.lang.String str11 = projectInfo10.toString();
//        projectInfo10.setVersion("RectangleEdge.TOP");
//        java.awt.Image image14 = projectInfo10.getLogo();
//        org.jfree.chart.ui.ProjectInfo projectInfo18 = new org.jfree.chart.ui.ProjectInfo("PieSection: 0, 100(1)", "", "RectangleAnchor.BOTTOM_LEFT", image14, "1.2.0-pre", "1.2.0-pre", "TableOrder.BY_ROW");
//        jFreeChart6.setBackgroundImage(image14);
//        org.jfree.chart.ChartRenderingInfo chartRenderingInfo23 = null;
//        try {
//            java.awt.image.BufferedImage bufferedImage24 = jFreeChart6.createBufferedImage(15, (int) (byte) 100, (int) (byte) -1, chartRenderingInfo23);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown image type -1");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
//        org.junit.Assert.assertNotNull(projectInfo10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "JFreeChart version RectangleEdge.TOP.\n1.2.0-pre.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nPieSection: 0, 100(1)" + "'", str11.equals("JFreeChart version RectangleEdge.TOP.\n1.2.0-pre.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nPieSection: 0, 100(1)"));
//        org.junit.Assert.assertNotNull(image14);
//    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        piePlot1.setLabelLinkMargin(0.0d);
        boolean boolean8 = piePlot1.getIgnoreZeroValues();
        org.jfree.chart.block.BlockBorder blockBorder13 = new org.jfree.chart.block.BlockBorder(0.0d, 0.025d, (double) 100, (double) (short) 100);
        boolean boolean14 = piePlot1.equals((java.lang.Object) 0.025d);
        piePlot1.setNoDataMessage("JFreeChart version RectangleEdge.TOP.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nTableOrder.BY_ROW");
        java.lang.Object obj17 = piePlot1.clone();
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(obj17);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha((float) 0);
        boolean boolean4 = piePlot1.getIgnoreZeroValues();
        double double5 = piePlot1.getShadowXOffset();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo9 = null;
        java.awt.image.BufferedImage bufferedImage10 = jFreeChart6.createBufferedImage((int) 'a', (int) (byte) 100, chartRenderingInfo9);
        java.awt.Image image11 = jFreeChart6.getBackgroundImage();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = null;
        try {
            java.awt.image.BufferedImage bufferedImage15 = jFreeChart6.createBufferedImage((int) (byte) -1, (int) (short) 1, chartRenderingInfo14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (-1) and height (1) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(bufferedImage10);
        org.junit.Assert.assertNull(image11);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.util.Size2D size2D3 = blockContainer1.arrange(graphics2D2);
        blockContainer1.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D9 = blockContainer1.getBounds();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean17 = rectangleInsets15.equals((java.lang.Object) rectangleAnchor16);
        org.jfree.chart.block.ColumnArrangement columnArrangement18 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer19 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement18);
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.util.Size2D size2D21 = blockContainer19.arrange(graphics2D20);
        blockContainer19.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D27 = blockContainer19.getBounds();
        java.awt.geom.Rectangle2D rectangle2D30 = rectangleInsets15.createInsetRectangle(rectangle2D27, true, false);
        org.jfree.data.general.PieDataset pieDataset31 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity37 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D30, pieDataset31, 15, 0, (java.lang.Comparable) 1, "hi!", "RectangleEdge.TOP");
        org.jfree.chart.title.TextTitle textTitle38 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font39 = textTitle38.getFont();
        org.jfree.chart.util.VerticalAlignment verticalAlignment40 = textTitle38.getVerticalAlignment();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent41 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle38);
        java.lang.Object obj42 = titleChangeEvent41.getSource();
        try {
            java.lang.Object obj43 = blockContainer1.draw(graphics2D10, rectangle2D30, (java.lang.Object) titleChangeEvent41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(size2D3);
        org.junit.Assert.assertNotNull(rectangle2D9);
        org.junit.Assert.assertNotNull(rectangleAnchor16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(size2D21);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(font39);
        org.junit.Assert.assertNotNull(verticalAlignment40);
        org.junit.Assert.assertNotNull(obj42);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        piePlot1.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        piePlot1.setDataset(pieDataset8);
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        piePlot1.removeChangeListener(plotChangeListener10);
        org.jfree.chart.block.FlowArrangement flowArrangement12 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.Block block13 = null;
        java.awt.Stroke stroke14 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        flowArrangement12.add(block13, (java.lang.Object) stroke14);
        piePlot1.setBaseSectionOutlineStroke(stroke14);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator17 = piePlot1.getToolTipGenerator();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = null;
        try {
            piePlot1.setInsets(rectangleInsets18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNull(pieToolTipGenerator17);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setForegroundAlpha((float) 0);
        java.awt.Stroke stroke6 = piePlot3.getBaseSectionOutlineStroke();
        piePlot3.setLabelLinkMargin((double) (-256));
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("PieSection: 0, 100(1)", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
        org.jfree.chart.event.ChartProgressListener chartProgressListener11 = null;
        jFreeChart10.removeProgressListener(chartProgressListener11);
        try {
            org.jfree.chart.plot.XYPlot xYPlot13 = jFreeChart10.getXYPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.PiePlot cannot be cast to org.jfree.chart.plot.XYPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setForegroundAlpha((float) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean12 = rectangleInsets10.equals((java.lang.Object) rectangleAnchor11);
        double double14 = rectangleInsets10.calculateBottomInset((double) (-1L));
        piePlot3.setSimpleLabelOffset(rectangleInsets10);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle16 = org.jfree.chart.plot.PieLabelLinkStyle.CUBIC_CURVE;
        piePlot3.setLabelLinkStyle(pieLabelLinkStyle16);
        defaultCategoryDataset0.removeChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot3);
        try {
            defaultCategoryDataset0.incrementValue(4.0d, (java.lang.Comparable) 0L, (java.lang.Comparable) 255);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unrecognised columnKey: 255");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 100.0d + "'", double14 == 100.0d);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle16);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha((float) 0);
        boolean boolean4 = piePlot1.getIgnoreZeroValues();
        double double5 = piePlot1.getShadowXOffset();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo9 = null;
        java.awt.image.BufferedImage bufferedImage10 = jFreeChart6.createBufferedImage((int) 'a', (int) (byte) 100, chartRenderingInfo9);
        java.awt.Paint paint11 = jFreeChart6.getBackgroundPaint();
        try {
            org.jfree.chart.title.Title title13 = jFreeChart6.getSubtitle((-7904));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(bufferedImage10);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha((float) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean10 = rectangleInsets8.equals((java.lang.Object) rectangleAnchor9);
        double double12 = rectangleInsets8.calculateBottomInset((double) (-1L));
        piePlot1.setSimpleLabelOffset(rectangleInsets8);
        java.awt.Paint paint14 = piePlot1.getLabelOutlinePaint();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator15 = piePlot1.getToolTipGenerator();
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 100.0d + "'", double12 == 100.0d);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(pieToolTipGenerator15);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        double double6 = piePlot1.getInteriorGap();
        java.awt.Paint paint7 = piePlot1.getLabelOutlinePaint();
        java.awt.Color color10 = java.awt.Color.getColor("RectangleEdge.TOP", (int) (short) 1);
        org.jfree.chart.ChartColor chartColor14 = new org.jfree.chart.ChartColor(15, 192, (int) (short) 10);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType15 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.awt.Color color16 = java.awt.Color.GREEN;
        boolean boolean17 = chartChangeEventType15.equals((java.lang.Object) color16);
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        int int19 = color18.getTransparency();
        java.awt.Color color20 = java.awt.Color.BLACK;
        java.awt.Color color21 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        java.awt.Paint[] paintArray22 = new java.awt.Paint[] { color10, chartColor14, color16, color18, color20, color21 };
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType23 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.awt.Color color24 = java.awt.Color.GREEN;
        boolean boolean25 = chartChangeEventType23.equals((java.lang.Object) color24);
        java.awt.Paint paint30 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder31 = new org.jfree.chart.block.BlockBorder((double) 10, (double) '#', (double) 0L, 0.0d, paint30);
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.Paint[] paintArray33 = new java.awt.Paint[] { color24, paint30, color32 };
        java.awt.Paint[] paintArray34 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray35 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray36 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray37 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier38 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray22, paintArray33, paintArray34, strokeArray35, strokeArray36, shapeArray37);
        piePlot1.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier38);
        java.awt.Paint paint40 = defaultDrawingSupplier38.getNextFillPaint();
        java.awt.Stroke stroke41 = defaultDrawingSupplier38.getNextStroke();
        org.jfree.chart.block.FlowArrangement flowArrangement42 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.Block block43 = null;
        java.awt.Stroke stroke44 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        flowArrangement42.add(block43, (java.lang.Object) stroke44);
        boolean boolean46 = defaultDrawingSupplier38.equals((java.lang.Object) flowArrangement42);
        flowArrangement42.clear();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.08d + "'", double6 == 0.08d);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(chartChangeEventType15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(paintArray22);
        org.junit.Assert.assertNotNull(chartChangeEventType23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(paintArray33);
        org.junit.Assert.assertNotNull(paintArray34);
        org.junit.Assert.assertNotNull(strokeArray35);
        org.junit.Assert.assertNotNull(strokeArray36);
        org.junit.Assert.assertNotNull(shapeArray37);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        java.awt.Color color0 = java.awt.Color.RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 0, (int) (byte) 100, (java.lang.Comparable) 1L, "RectangleEdge.TOP", "RectangleEdge.TOP");
        org.jfree.data.UnknownKeyException unknownKeyException9 = new org.jfree.data.UnknownKeyException("");
        boolean boolean10 = pieSectionEntity7.equals((java.lang.Object) "");
        java.lang.String str11 = pieSectionEntity7.toString();
        pieSectionEntity7.setToolTipText("JFreeChart version RectangleEdge.TOP.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nTableOrder.BY_ROW");
        java.lang.String str14 = pieSectionEntity7.getShapeCoords();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "PieSection: 0, 100(1)" + "'", str11.equals("PieSection: 0, 100(1)"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0" + "'", str14.equals("4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0"));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 0, (int) (byte) 100, (java.lang.Comparable) 1L, "RectangleEdge.TOP", "RectangleEdge.TOP");
        org.jfree.data.UnknownKeyException unknownKeyException9 = new org.jfree.data.UnknownKeyException("");
        boolean boolean10 = pieSectionEntity7.equals((java.lang.Object) "");
        java.lang.String str11 = pieSectionEntity7.toString();
        pieSectionEntity7.setToolTipText("JFreeChart version RectangleEdge.TOP.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nTableOrder.BY_ROW");
        org.jfree.data.general.PieDataset pieDataset14 = pieSectionEntity7.getDataset();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "PieSection: 0, 100(1)" + "'", str11.equals("PieSection: 0, 100(1)"));
        org.junit.Assert.assertNull(pieDataset14);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.chart.plot.Plot plot1 = null;
        try {
            org.jfree.chart.JFreeChart jFreeChart2 = new org.jfree.chart.JFreeChart("RectangleAnchor.CENTER", plot1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'plot' argument.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        piePlot1.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        piePlot1.setDataset(pieDataset8);
        piePlot1.setMaximumLabelWidth((double) (byte) 100);
        java.awt.Stroke stroke13 = piePlot1.getSectionOutlineStroke((java.lang.Comparable) (short) 0);
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        piePlot15.setForegroundAlpha((float) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor23 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean24 = rectangleInsets22.equals((java.lang.Object) rectangleAnchor23);
        double double26 = rectangleInsets22.calculateBottomInset((double) (-1L));
        piePlot15.setSimpleLabelOffset(rectangleInsets22);
        piePlot1.setInsets(rectangleInsets22);
        java.awt.Color color29 = java.awt.Color.BLUE;
        piePlot1.setLabelLinkPaint((java.awt.Paint) color29);
        java.awt.Font font31 = piePlot1.getLabelFont();
        piePlot1.setLabelLinksVisible(true);
        piePlot1.setIgnoreNullValues(false);
        org.junit.Assert.assertNull(stroke13);
        org.junit.Assert.assertNotNull(rectangleAnchor23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 100.0d + "'", double26 == 100.0d);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(font31);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        java.awt.Color color0 = java.awt.Color.green;
        java.awt.Color color1 = color0.darker();
        java.awt.color.ColorSpace colorSpace2 = color0.getColorSpace();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(colorSpace2);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        try {
            defaultKeyedValues2D0.removeColumn((java.lang.Comparable) 0.4d);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unknown key: 0.4");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.util.TableOrder tableOrder2 = org.jfree.chart.util.TableOrder.BY_COLUMN;
        multiplePiePlot1.setDataExtractOrder(tableOrder2);
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.chart.plot.Plot) multiplePiePlot1);
        java.awt.Color color5 = java.awt.Color.PINK;
        multiplePiePlot1.setAggregatedItemsPaint((java.awt.Paint) color5);
        double double7 = multiplePiePlot1.getLimit();
        org.junit.Assert.assertNotNull(tableOrder2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        java.awt.Color color2 = java.awt.Color.getColor("RectangleEdge.TOP", (int) (short) 1);
        org.jfree.chart.ChartColor chartColor6 = new org.jfree.chart.ChartColor(15, 192, (int) (short) 10);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.awt.Color color8 = java.awt.Color.GREEN;
        boolean boolean9 = chartChangeEventType7.equals((java.lang.Object) color8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        int int11 = color10.getTransparency();
        java.awt.Color color12 = java.awt.Color.BLACK;
        java.awt.Color color13 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        java.awt.Paint[] paintArray14 = new java.awt.Paint[] { color2, chartColor6, color8, color10, color12, color13 };
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType15 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.awt.Color color16 = java.awt.Color.GREEN;
        boolean boolean17 = chartChangeEventType15.equals((java.lang.Object) color16);
        java.awt.Paint paint22 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder23 = new org.jfree.chart.block.BlockBorder((double) 10, (double) '#', (double) 0L, 0.0d, paint22);
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.Paint[] paintArray25 = new java.awt.Paint[] { color16, paint22, color24 };
        java.awt.Paint[] paintArray26 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray27 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray28 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray29 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier30 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray14, paintArray25, paintArray26, strokeArray27, strokeArray28, shapeArray29);
        try {
            java.awt.Shape shape31 = defaultDrawingSupplier30.getNextShape();
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(chartChangeEventType7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(paintArray14);
        org.junit.Assert.assertNotNull(chartChangeEventType15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(paintArray25);
        org.junit.Assert.assertNotNull(paintArray26);
        org.junit.Assert.assertNotNull(strokeArray27);
        org.junit.Assert.assertNotNull(strokeArray28);
        org.junit.Assert.assertNotNull(shapeArray29);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double1 = rectangleInsets0.getTop();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0d + "'", double1 == 4.0d);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha((float) 0);
        boolean boolean4 = piePlot1.getIgnoreZeroValues();
        double double5 = piePlot1.getShadowXOffset();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot7 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.util.TableOrder tableOrder8 = org.jfree.chart.util.TableOrder.BY_COLUMN;
        multiplePiePlot7.setDataExtractOrder(tableOrder8);
        java.awt.Font font11 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        piePlot13.setForegroundAlpha((float) 0);
        java.awt.Stroke stroke16 = piePlot13.getBaseSectionOutlineStroke();
        piePlot13.setLabelLinkMargin((double) (-256));
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("PieSection: 0, 100(1)", font11, (org.jfree.chart.plot.Plot) piePlot13, false);
        multiplePiePlot7.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart20);
        boolean boolean22 = jFreeChart6.equals((java.lang.Object) jFreeChart20);
        org.jfree.chart.title.TextTitle textTitle23 = jFreeChart20.getTitle();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(tableOrder8);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(textTitle23);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        java.awt.Stroke stroke6 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        piePlot1.setLabelOutlineStroke(stroke6);
        piePlot1.setMaximumLabelWidth((-1.0d));
        boolean boolean10 = piePlot1.getIgnoreNullValues();
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        piePlot12.setForegroundAlpha(0.0f);
        piePlot12.setStartAngle((double) 100L);
        piePlot12.setForegroundAlpha((float) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement19 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.Block block20 = null;
        java.awt.Stroke stroke21 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        flowArrangement19.add(block20, (java.lang.Object) stroke21);
        piePlot12.setOutlineStroke(stroke21);
        piePlot1.setBaseSectionOutlineStroke(stroke21);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(stroke21);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 0, (int) (byte) 100, (java.lang.Comparable) 1L, "RectangleEdge.TOP", "RectangleEdge.TOP");
        org.jfree.data.general.PieDataset pieDataset8 = null;
        pieSectionEntity7.setDataset(pieDataset8);
        java.lang.String str10 = pieSectionEntity7.toString();
        pieSectionEntity7.setSectionKey((java.lang.Comparable) 0);
        int int13 = pieSectionEntity7.getPieIndex();
        pieSectionEntity7.setSectionKey((java.lang.Comparable) (byte) -1);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "PieSection: 0, 100(1)" + "'", str10.equals("PieSection: 0, 100(1)"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 0, (int) (byte) 100, (java.lang.Comparable) 1L, "RectangleEdge.TOP", "RectangleEdge.TOP");
        org.jfree.data.UnknownKeyException unknownKeyException9 = new org.jfree.data.UnknownKeyException("");
        boolean boolean10 = pieSectionEntity7.equals((java.lang.Object) "");
        java.lang.String str11 = pieSectionEntity7.toString();
        pieSectionEntity7.setToolTipText("JFreeChart version RectangleEdge.TOP.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nTableOrder.BY_ROW");
        org.jfree.data.general.PieDataset pieDataset14 = null;
        pieSectionEntity7.setDataset(pieDataset14);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "PieSection: 0, 100(1)" + "'", str11.equals("PieSection: 0, 100(1)"));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setForegroundAlpha((float) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean12 = rectangleInsets10.equals((java.lang.Object) rectangleAnchor11);
        double double14 = rectangleInsets10.calculateBottomInset((double) (-1L));
        piePlot3.setSimpleLabelOffset(rectangleInsets10);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle16 = org.jfree.chart.plot.PieLabelLinkStyle.CUBIC_CURVE;
        piePlot3.setLabelLinkStyle(pieLabelLinkStyle16);
        defaultCategoryDataset0.removeChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot3);
        java.lang.Comparable comparable21 = null;
        try {
            defaultCategoryDataset0.addValue((java.lang.Number) (short) 100, (java.lang.Comparable) (short) -1, comparable21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 100.0d + "'", double14 == 100.0d);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle16);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha((float) 0);
        boolean boolean4 = piePlot1.getIgnoreZeroValues();
        java.awt.Color color5 = java.awt.Color.YELLOW;
        java.awt.Color color6 = color5.darker();
        piePlot1.setShadowPaint((java.awt.Paint) color6);
        java.awt.Paint paint8 = piePlot1.getLabelPaint();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.util.TableOrder tableOrder2 = org.jfree.chart.util.TableOrder.BY_COLUMN;
        multiplePiePlot1.setDataExtractOrder(tableOrder2);
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.chart.plot.Plot) multiplePiePlot1);
        org.jfree.chart.title.Title title5 = null;
        jFreeChart4.removeSubtitle(title5);
        java.awt.Paint paint7 = jFreeChart4.getBackgroundPaint();
        org.junit.Assert.assertNotNull(tableOrder2);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        java.lang.Object obj2 = null;
        boolean boolean3 = columnArrangement0.equals(obj2);
        columnArrangement0.clear();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha((float) 0);
        boolean boolean4 = piePlot1.getIgnoreZeroValues();
        double double5 = piePlot1.getShadowXOffset();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo9 = null;
        java.awt.image.BufferedImage bufferedImage10 = jFreeChart6.createBufferedImage((int) 'a', (int) (byte) 100, chartRenderingInfo9);
        java.awt.Paint paint11 = jFreeChart6.getBackgroundPaint();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement16 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer17 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement16);
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.util.Size2D size2D19 = blockContainer17.arrange(graphics2D18);
        blockContainer17.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D25 = blockContainer17.getBounds();
        java.lang.Object obj27 = textTitle14.draw(graphics2D15, rectangle2D25, (java.lang.Object) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor28 = null;
        java.awt.geom.Point2D point2D29 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D25, rectangleAnchor28);
        org.jfree.chart.title.TextTitle textTitle31 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D32 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement33 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer34 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement33);
        java.awt.Graphics2D graphics2D35 = null;
        org.jfree.chart.util.Size2D size2D36 = blockContainer34.arrange(graphics2D35);
        blockContainer34.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D42 = blockContainer34.getBounds();
        java.lang.Object obj44 = textTitle31.draw(graphics2D32, rectangle2D42, (java.lang.Object) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor45 = null;
        java.awt.geom.Point2D point2D46 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D42, rectangleAnchor45);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo47 = null;
        try {
            jFreeChart6.draw(graphics2D12, rectangle2D25, point2D46, chartRenderingInfo47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(bufferedImage10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(size2D19);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNull(obj27);
        org.junit.Assert.assertNotNull(point2D29);
        org.junit.Assert.assertNotNull(size2D36);
        org.junit.Assert.assertNotNull(rectangle2D42);
        org.junit.Assert.assertNull(obj44);
        org.junit.Assert.assertNotNull(point2D46);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        java.lang.String str3 = rectangleEdge2.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge2);
        legendTitle1.setLegendItemGraphicEdge(rectangleEdge2);
        org.jfree.chart.block.BlockFrame blockFrame6 = legendTitle1.getFrame();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = legendTitle1.getItemLabelPadding();
        java.awt.Font font9 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot(pieDataset10);
        piePlot11.setForegroundAlpha((float) 0);
        java.awt.Stroke stroke14 = piePlot11.getBaseSectionOutlineStroke();
        piePlot11.setLabelLinkMargin((double) (-256));
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("PieSection: 0, 100(1)", font9, (org.jfree.chart.plot.Plot) piePlot11, false);
        jFreeChart18.setBorderVisible(false);
        legendTitle1.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart18);
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.title.TextTitle textTitle24 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.title.TextTitle textTitle26 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement28 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer29 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement28);
        java.awt.Graphics2D graphics2D30 = null;
        org.jfree.chart.util.Size2D size2D31 = blockContainer29.arrange(graphics2D30);
        blockContainer29.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D37 = blockContainer29.getBounds();
        java.lang.Object obj39 = textTitle26.draw(graphics2D27, rectangle2D37, (java.lang.Object) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor40 = null;
        java.awt.geom.Point2D point2D41 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D37, rectangleAnchor40);
        textTitle24.setBounds(rectangle2D37);
        java.awt.geom.Rectangle2D rectangle2D45 = rectangleInsets23.createOutsetRectangle(rectangle2D37, false, true);
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo46 = new org.jfree.chart.ui.BasicProjectInfo();
        basicProjectInfo46.setName("");
        java.lang.String str49 = basicProjectInfo46.getLicenceName();
        try {
            java.lang.Object obj50 = legendTitle1.draw(graphics2D22, rectangle2D37, (java.lang.Object) basicProjectInfo46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleEdge.TOP" + "'", str3.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(blockFrame6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(size2D31);
        org.junit.Assert.assertNotNull(rectangle2D37);
        org.junit.Assert.assertNull(obj39);
        org.junit.Assert.assertNotNull(point2D41);
        org.junit.Assert.assertNotNull(rectangle2D45);
        org.junit.Assert.assertNull(str49);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 0, (int) (byte) 100, (java.lang.Comparable) 1L, "RectangleEdge.TOP", "RectangleEdge.TOP");
        pieSectionEntity7.setToolTipText("Other");
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        java.awt.Color color0 = java.awt.Color.black;
        int int1 = color0.getGreen();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        java.awt.Color color1 = java.awt.Color.getColor("RectangleAnchor.CENTER");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha((float) 0);
        java.awt.Stroke stroke4 = piePlot1.getBaseSectionOutlineStroke();
        piePlot1.setLabelLinkMargin((double) (-256));
        piePlot1.setSectionOutlinesVisible(false);
        org.jfree.data.general.PieDataset pieDataset9 = piePlot1.getDataset();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(pieDataset9);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement3 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer4 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.util.Size2D size2D6 = blockContainer4.arrange(graphics2D5);
        blockContainer4.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D12 = blockContainer4.getBounds();
        java.lang.Object obj14 = textTitle1.draw(graphics2D2, rectangle2D12, (java.lang.Object) (short) 0);
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment17 = textTitle16.getTextAlignment();
        java.lang.String str18 = horizontalAlignment17.toString();
        textTitle1.setHorizontalAlignment(horizontalAlignment17);
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font21 = textTitle20.getFont();
        org.jfree.chart.util.VerticalAlignment verticalAlignment22 = textTitle20.getVerticalAlignment();
        textTitle1.setVerticalAlignment(verticalAlignment22);
        textTitle1.setURLText("Rotation.ANTICLOCKWISE");
        org.jfree.chart.util.VerticalAlignment verticalAlignment26 = org.jfree.chart.util.VerticalAlignment.TOP;
        textTitle1.setVerticalAlignment(verticalAlignment26);
        org.junit.Assert.assertNotNull(size2D6);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertNull(obj14);
        org.junit.Assert.assertNotNull(horizontalAlignment17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "HorizontalAlignment.CENTER" + "'", str18.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(verticalAlignment22);
        org.junit.Assert.assertNotNull(verticalAlignment26);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha((float) 0);
        boolean boolean4 = piePlot1.getIgnoreZeroValues();
        double double5 = piePlot1.getShadowXOffset();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot7 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.util.TableOrder tableOrder8 = org.jfree.chart.util.TableOrder.BY_COLUMN;
        multiplePiePlot7.setDataExtractOrder(tableOrder8);
        java.awt.Font font11 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        piePlot13.setForegroundAlpha((float) 0);
        java.awt.Stroke stroke16 = piePlot13.getBaseSectionOutlineStroke();
        piePlot13.setLabelLinkMargin((double) (-256));
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("PieSection: 0, 100(1)", font11, (org.jfree.chart.plot.Plot) piePlot13, false);
        multiplePiePlot7.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart20);
        boolean boolean22 = jFreeChart6.equals((java.lang.Object) jFreeChart20);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D23 = new org.jfree.data.DefaultKeyedValues2D();
        java.awt.Color color24 = java.awt.Color.GREEN;
        float[] floatArray29 = new float[] { (byte) 1, (short) 0, (short) 100, (short) -1 };
        float[] floatArray30 = color24.getComponents(floatArray29);
        boolean boolean31 = defaultKeyedValues2D23.equals((java.lang.Object) floatArray30);
        int int32 = defaultKeyedValues2D23.getColumnCount();
        int int33 = defaultKeyedValues2D23.getColumnCount();
        defaultKeyedValues2D23.setValue((java.lang.Number) 0, (java.lang.Comparable) "hi!", (java.lang.Comparable) (byte) -1);
        int int39 = defaultKeyedValues2D23.getColumnIndex((java.lang.Comparable) 0.08d);
        try {
            jFreeChart20.setTextAntiAlias((java.lang.Object) int39);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: -1 incompatible with Text-specific antialiasing enable key");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(tableOrder8);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(floatArray29);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setForegroundAlpha((float) 0);
        java.awt.Stroke stroke6 = piePlot3.getBaseSectionOutlineStroke();
        piePlot3.setLabelLinkMargin((double) (-256));
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("PieSection: 0, 100(1)", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
        try {
            org.jfree.chart.plot.XYPlot xYPlot11 = jFreeChart10.getXYPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.PiePlot cannot be cast to org.jfree.chart.plot.XYPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setLabelLinkMargin(4.0d);
        piePlot1.setSimpleLabels(true);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        piePlot1.setShadowPaint((java.awt.Paint) color4);
        java.awt.color.ColorSpace colorSpace6 = color4.getColorSpace();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(colorSpace6);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        piePlot1.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        piePlot1.setDataset(pieDataset8);
        piePlot1.setMaximumLabelWidth((double) (byte) 100);
        java.awt.Stroke stroke13 = piePlot1.getSectionOutlineStroke((java.lang.Comparable) (short) 0);
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        piePlot15.setForegroundAlpha((float) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor23 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean24 = rectangleInsets22.equals((java.lang.Object) rectangleAnchor23);
        double double26 = rectangleInsets22.calculateBottomInset((double) (-1L));
        piePlot15.setSimpleLabelOffset(rectangleInsets22);
        piePlot1.setInsets(rectangleInsets22);
        java.awt.Color color29 = java.awt.Color.BLUE;
        piePlot1.setLabelLinkPaint((java.awt.Paint) color29);
        java.awt.Font font31 = piePlot1.getLabelFont();
        piePlot1.setInteriorGap(0.0d);
        org.junit.Assert.assertNull(stroke13);
        org.junit.Assert.assertNotNull(rectangleAnchor23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 100.0d + "'", double26 == 100.0d);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(font31);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 0, (int) (byte) 100, (java.lang.Comparable) 1L, "RectangleEdge.TOP", "RectangleEdge.TOP");
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity14 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset8, (-254), 2, (java.lang.Comparable) "org.jfree.chart.event.ChartChangeEvent[source=0]", "PieSection: 0, 100(1)", "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        java.lang.String str15 = pieSectionEntity14.getToolTipText();
        java.lang.Object obj16 = pieSectionEntity14.clone();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PieSection: 0, 100(1)" + "'", str15.equals("PieSection: 0, 100(1)"));
        org.junit.Assert.assertNotNull(obj16);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        piePlot1.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        piePlot1.setDataset(pieDataset8);
        piePlot1.setForegroundAlpha((float) (byte) 0);
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        piePlot13.setForegroundAlpha(0.0f);
        piePlot13.setStartAngle((double) 100L);
        piePlot13.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset20 = null;
        piePlot13.setDataset(pieDataset20);
        piePlot13.setMaximumLabelWidth((double) (byte) 100);
        java.awt.Stroke stroke25 = piePlot13.getSectionOutlineStroke((java.lang.Comparable) (short) 0);
        org.jfree.data.general.PieDataset pieDataset26 = null;
        org.jfree.chart.plot.PiePlot piePlot27 = new org.jfree.chart.plot.PiePlot(pieDataset26);
        piePlot27.setForegroundAlpha((float) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor35 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean36 = rectangleInsets34.equals((java.lang.Object) rectangleAnchor35);
        double double38 = rectangleInsets34.calculateBottomInset((double) (-1L));
        piePlot27.setSimpleLabelOffset(rectangleInsets34);
        piePlot13.setInsets(rectangleInsets34);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = piePlot13.getSimpleLabelOffset();
        piePlot1.setSimpleLabelOffset(rectangleInsets41);
        boolean boolean43 = piePlot1.getIgnoreZeroValues();
        org.junit.Assert.assertNull(stroke25);
        org.junit.Assert.assertNotNull(rectangleAnchor35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 100.0d + "'", double38 == 100.0d);
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.zoom((double) '#');
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        piePlot7.setForegroundAlpha((float) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean16 = rectangleInsets14.equals((java.lang.Object) rectangleAnchor15);
        double double18 = rectangleInsets14.calculateBottomInset((double) (-1L));
        piePlot7.setSimpleLabelOffset(rectangleInsets14);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle20 = org.jfree.chart.plot.PieLabelLinkStyle.CUBIC_CURVE;
        piePlot7.setLabelLinkStyle(pieLabelLinkStyle20);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier22 = piePlot7.getDrawingSupplier();
        boolean boolean23 = piePlot1.equals((java.lang.Object) piePlot7);
        double double24 = piePlot1.getMinimumArcAngleToDraw();
        java.awt.Paint paint25 = piePlot1.getBaseSectionOutlinePaint();
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 100.0d + "'", double18 == 100.0d);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle20);
        org.junit.Assert.assertNotNull(drawingSupplier22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0E-5d + "'", double24 == 1.0E-5d);
        org.junit.Assert.assertNotNull(paint25);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        java.awt.Stroke stroke2 = strokeMap0.getStroke((java.lang.Comparable) 4.0d);
        org.jfree.chart.block.ColumnArrangement columnArrangement3 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer4 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.util.Size2D size2D6 = blockContainer4.arrange(graphics2D5);
        java.lang.Object obj7 = null;
        boolean boolean8 = blockContainer4.equals(obj7);
        java.lang.Class<?> wildcardClass9 = blockContainer4.getClass();
        java.awt.Paint paint14 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder15 = new org.jfree.chart.block.BlockBorder((double) 10, (double) '#', (double) 0L, 0.0d, paint14);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = blockBorder15.getInsets();
        blockContainer4.setFrame((org.jfree.chart.block.BlockFrame) blockBorder15);
        boolean boolean18 = strokeMap0.equals((java.lang.Object) blockContainer4);
        blockContainer4.setWidth(0.0d);
        org.junit.Assert.assertNull(stroke2);
        org.junit.Assert.assertNotNull(size2D6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        java.awt.Paint paint2 = textTitle1.getBackgroundPaint();
        textTitle1.setMargin((double) (-1), (double) 1, 0.025d, (double) 128);
        org.junit.Assert.assertNull(paint2);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        java.awt.Color color0 = java.awt.Color.YELLOW;
        java.awt.Color color1 = java.awt.Color.GREEN;
        float[] floatArray6 = new float[] { (byte) 1, (short) 0, (short) 100, (short) -1 };
        float[] floatArray7 = color1.getComponents(floatArray6);
        float[] floatArray8 = color0.getComponents(floatArray6);
        int int9 = color0.getAlpha();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 255 + "'", int9 == 255);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.block.BlockBorder blockBorder2 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color1);
        multiplePiePlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset4 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot5 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset4);
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        piePlot7.setForegroundAlpha((float) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean16 = rectangleInsets14.equals((java.lang.Object) rectangleAnchor15);
        double double18 = rectangleInsets14.calculateBottomInset((double) (-1L));
        piePlot7.setSimpleLabelOffset(rectangleInsets14);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle20 = org.jfree.chart.plot.PieLabelLinkStyle.CUBIC_CURVE;
        piePlot7.setLabelLinkStyle(pieLabelLinkStyle20);
        defaultCategoryDataset4.removeChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot7);
        multiplePiePlot0.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset4);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 100.0d + "'", double18 == 100.0d);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle20);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        java.lang.String str1 = basicProjectInfo0.getCopyright();
        org.jfree.chart.ui.Library[] libraryArray2 = basicProjectInfo0.getLibraries();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo3 = new org.jfree.chart.ui.BasicProjectInfo();
        java.lang.String str4 = basicProjectInfo3.getName();
        basicProjectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo3);
        basicProjectInfo3.setVersion("1.2.0-pre");
        org.jfree.chart.ui.Library[] libraryArray8 = basicProjectInfo3.getLibraries();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(libraryArray2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(libraryArray8);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder(0.0d, 0.025d, (double) 100, (double) (short) 100);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement11 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer12 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement11);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.util.Size2D size2D14 = blockContainer12.arrange(graphics2D13);
        blockContainer12.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D20 = blockContainer12.getBounds();
        java.lang.Object obj22 = textTitle9.draw(graphics2D10, rectangle2D20, (java.lang.Object) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor23 = null;
        java.awt.geom.Point2D point2D24 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D20, rectangleAnchor23);
        textTitle7.setBounds(rectangle2D20);
        java.awt.geom.Rectangle2D rectangle2D28 = rectangleInsets6.createOutsetRectangle(rectangle2D20, false, true);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor29 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Point2D point2D30 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D20, rectangleAnchor29);
        try {
            blockBorder4.draw(graphics2D5, rectangle2D20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(size2D14);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNull(obj22);
        org.junit.Assert.assertNotNull(point2D24);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertNotNull(rectangleAnchor29);
        org.junit.Assert.assertNotNull(point2D30);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        piePlot1.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        piePlot1.setDataset(pieDataset8);
        org.jfree.data.general.PieDataset pieDataset10 = piePlot1.getDataset();
        java.lang.String str11 = piePlot1.getNoDataMessage();
        piePlot1.setLabelLinkMargin(89.0d);
        double double14 = piePlot1.getShadowXOffset();
        try {
            piePlot1.setBackgroundImageAlpha((float) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(pieDataset10);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 0, (int) (byte) 100, (java.lang.Comparable) 1L, "RectangleEdge.TOP", "RectangleEdge.TOP");
        org.jfree.chart.JFreeChart jFreeChart8 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent9 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0, jFreeChart8);
        org.jfree.chart.JFreeChart jFreeChart10 = chartChangeEvent9.getChart();
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        chartChangeEvent9.setChart(jFreeChart11);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot14 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.util.TableOrder tableOrder15 = org.jfree.chart.util.TableOrder.BY_COLUMN;
        multiplePiePlot14.setDataExtractOrder(tableOrder15);
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.chart.plot.Plot) multiplePiePlot14);
        chartChangeEvent9.setChart(jFreeChart17);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType19 = chartChangeEvent9.getType();
        org.jfree.chart.JFreeChart jFreeChart20 = chartChangeEvent9.getChart();
        java.lang.String str21 = chartChangeEvent9.toString();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNull(jFreeChart10);
        org.junit.Assert.assertNotNull(tableOrder15);
        org.junit.Assert.assertNotNull(chartChangeEventType19);
        org.junit.Assert.assertNotNull(jFreeChart20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=0]" + "'", str21.equals("org.jfree.chart.event.ChartChangeEvent[source=0]"));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        java.awt.Paint paint4 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder((double) 10, (double) '#', (double) 0L, 0.0d, paint4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = blockBorder5.getInsets();
        double double8 = rectangleInsets6.calculateLeftOutset(90.0d);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 35.0d + "'", double8 == 35.0d);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.zoom((double) '#');
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        piePlot7.setForegroundAlpha((float) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean16 = rectangleInsets14.equals((java.lang.Object) rectangleAnchor15);
        double double18 = rectangleInsets14.calculateBottomInset((double) (-1L));
        piePlot7.setSimpleLabelOffset(rectangleInsets14);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle20 = org.jfree.chart.plot.PieLabelLinkStyle.CUBIC_CURVE;
        piePlot7.setLabelLinkStyle(pieLabelLinkStyle20);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier22 = piePlot7.getDrawingSupplier();
        boolean boolean23 = piePlot1.equals((java.lang.Object) piePlot7);
        org.jfree.chart.LegendItemSource legendItemSource24 = null;
        org.jfree.chart.title.LegendTitle legendTitle25 = new org.jfree.chart.title.LegendTitle(legendItemSource24);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = legendTitle25.getLegendItemGraphicPadding();
        piePlot7.setSimpleLabelOffset(rectangleInsets26);
        org.jfree.chart.util.UnitType unitType28 = rectangleInsets26.getUnitType();
        org.jfree.data.general.PieDataset pieDataset29 = null;
        org.jfree.chart.plot.PiePlot piePlot30 = new org.jfree.chart.plot.PiePlot(pieDataset29);
        piePlot30.setForegroundAlpha(0.0f);
        piePlot30.setLabelLinkMargin(4.0d);
        java.awt.Paint paint35 = piePlot30.getShadowPaint();
        boolean boolean36 = unitType28.equals((java.lang.Object) paint35);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 100.0d + "'", double18 == 100.0d);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle20);
        org.junit.Assert.assertNotNull(drawingSupplier22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNotNull(unitType28);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.calculateTopOutset((double) 0);
        double double3 = rectangleInsets0.getBottom();
        double double5 = rectangleInsets0.calculateLeftOutset(0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 8.0d + "'", double5 == 8.0d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha((float) 0);
        boolean boolean4 = piePlot1.getIgnoreZeroValues();
        double double5 = piePlot1.getShadowXOffset();
        java.awt.Stroke stroke6 = piePlot1.getLabelLinkStroke();
        java.awt.Paint paint7 = piePlot1.getBaseSectionPaint();
        boolean boolean8 = piePlot1.getLabelLinksVisible();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        piePlot1.setLabelPaint((java.awt.Paint) color9);
        double double11 = piePlot1.getStartAngle();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 90.0d + "'", double11 == 90.0d);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("JFreeChart version RectangleEdge.TOP.\n1.2.0-pre.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nPieSection: 0, 100(1)", "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", "RectangleAnchor.CENTER");
        org.jfree.chart.ui.Library[] libraryArray5 = basicProjectInfo4.getOptionalLibraries();
        org.junit.Assert.assertNotNull(libraryArray5);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        piePlot1.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        piePlot1.setDataset(pieDataset8);
        piePlot1.setMaximumLabelWidth((double) (byte) 100);
        java.awt.Stroke stroke13 = piePlot1.getSectionOutlineStroke((java.lang.Comparable) (short) 0);
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        piePlot15.setForegroundAlpha((float) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor23 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean24 = rectangleInsets22.equals((java.lang.Object) rectangleAnchor23);
        double double26 = rectangleInsets22.calculateBottomInset((double) (-1L));
        piePlot15.setSimpleLabelOffset(rectangleInsets22);
        piePlot1.setInsets(rectangleInsets22);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = piePlot1.getSimpleLabelOffset();
        int int30 = piePlot1.getBackgroundImageAlignment();
        java.awt.Paint paint32 = piePlot1.getSectionOutlinePaint((java.lang.Comparable) 192);
        org.junit.Assert.assertNull(stroke13);
        org.junit.Assert.assertNotNull(rectangleAnchor23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 100.0d + "'", double26 == 100.0d);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 15 + "'", int30 == 15);
        org.junit.Assert.assertNull(paint32);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setForegroundAlpha((float) 0);
        java.awt.Stroke stroke6 = piePlot3.getBaseSectionOutlineStroke();
        piePlot3.setLabelLinkMargin((double) (-256));
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("PieSection: 0, 100(1)", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
        jFreeChart10.setBorderVisible(false);
        jFreeChart10.setBackgroundImageAlpha(0.0f);
        try {
            org.jfree.chart.plot.CategoryPlot categoryPlot15 = jFreeChart10.getCategoryPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.PiePlot cannot be cast to org.jfree.chart.plot.CategoryPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha((float) 0);
        boolean boolean4 = piePlot1.getIgnoreZeroValues();
        double double5 = piePlot1.getShadowXOffset();
        java.awt.Stroke stroke6 = piePlot1.getLabelLinkStroke();
        java.awt.Paint paint7 = piePlot1.getBaseSectionPaint();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator8 = piePlot1.getURLGenerator();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(pieURLGenerator8);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement1 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.ColumnArrangement columnArrangement2 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource0, (org.jfree.chart.block.Arrangement) columnArrangement1, (org.jfree.chart.block.Arrangement) columnArrangement2);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement5 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer6 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement5);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.util.Size2D size2D8 = blockContainer6.arrange(graphics2D7);
        java.lang.Object obj9 = null;
        boolean boolean10 = blockContainer6.equals(obj9);
        java.lang.Class<?> wildcardClass11 = blockContainer6.getClass();
        java.awt.geom.Rectangle2D rectangle2D12 = blockContainer6.getBounds();
        try {
            legendTitle3.draw(graphics2D4, rectangle2D12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(size2D8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(rectangle2D12);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setForegroundAlpha((float) 0);
        java.awt.Stroke stroke6 = piePlot3.getBaseSectionOutlineStroke();
        piePlot3.setLabelLinkMargin((double) (-256));
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("PieSection: 0, 100(1)", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
        org.jfree.chart.event.ChartProgressListener chartProgressListener11 = null;
        jFreeChart10.removeProgressListener(chartProgressListener11);
        jFreeChart10.setTitle("hi!");
        try {
            org.jfree.chart.plot.XYPlot xYPlot15 = jFreeChart10.getXYPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.PiePlot cannot be cast to org.jfree.chart.plot.XYPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        java.util.Locale locale1 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("JFreeChart version RectangleAnchor.BOTTOM_LEFT.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nTableOrder.BY_ROW", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        piePlot1.setForegroundAlpha((float) (short) 100);
        double double8 = piePlot1.getShadowYOffset();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        piePlot1.handleClick(192, 0, plotRenderingInfo11);
        java.awt.Paint paint13 = piePlot1.getBaseSectionOutlinePaint();
        int int14 = piePlot1.getPieIndex();
        piePlot1.setMaximumLabelWidth((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.0d + "'", double8 == 4.0d);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        piePlot1.setForegroundAlpha((float) (short) 100);
        double double8 = piePlot1.getShadowYOffset();
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        piePlot10.setForegroundAlpha(0.0f);
        piePlot10.setStartAngle((double) 100L);
        piePlot10.setForegroundAlpha((float) (short) 100);
        double double17 = piePlot10.getShadowYOffset();
        piePlot1.setParent((org.jfree.chart.plot.Plot) piePlot10);
        float float19 = piePlot10.getBackgroundAlpha();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator20 = piePlot10.getLegendLabelURLGenerator();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator21 = null;
        piePlot10.setToolTipGenerator(pieToolTipGenerator21);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.0d + "'", double8 == 4.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 4.0d + "'", double17 == 4.0d);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 1.0f + "'", float19 == 1.0f);
        org.junit.Assert.assertNull(pieURLGenerator20);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int2 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = textTitle1.getTextAlignment();
        textTitle1.setHeight((double) (-262450));
        org.junit.Assert.assertNotNull(horizontalAlignment2);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = org.jfree.chart.util.VerticalAlignment.TOP;
        legendTitle1.setVerticalAlignment(verticalAlignment2);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.Color color5 = java.awt.Color.gray;
        java.awt.image.ColorModel colorModel6 = null;
        java.awt.Rectangle rectangle7 = null;
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement11 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer12 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement11);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.util.Size2D size2D14 = blockContainer12.arrange(graphics2D13);
        blockContainer12.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D20 = blockContainer12.getBounds();
        java.lang.Object obj22 = textTitle9.draw(graphics2D10, rectangle2D20, (java.lang.Object) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor23 = null;
        java.awt.geom.Point2D point2D24 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D20, rectangleAnchor23);
        java.awt.geom.AffineTransform affineTransform25 = null;
        java.awt.RenderingHints renderingHints26 = null;
        java.awt.PaintContext paintContext27 = color5.createContext(colorModel6, rectangle7, rectangle2D20, affineTransform25, renderingHints26);
        try {
            legendTitle1.draw(graphics2D4, rectangle2D20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(size2D14);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNull(obj22);
        org.junit.Assert.assertNotNull(point2D24);
        org.junit.Assert.assertNotNull(paintContext27);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        piePlot1.setForegroundAlpha((float) (short) 100);
        double double8 = piePlot1.getShadowYOffset();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        piePlot1.handleClick(192, 0, plotRenderingInfo11);
        java.awt.Paint paint13 = piePlot1.getBaseSectionOutlinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = null;
        try {
            piePlot1.setLabelPadding(rectangleInsets14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'padding' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.0d + "'", double8 == 4.0d);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.ColumnArrangement columnArrangement1 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer2 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.util.Size2D size2D4 = blockContainer2.arrange(graphics2D3);
        blockContainer2.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D10 = blockContainer2.getBounds();
        boolean boolean11 = blockContainer2.isEmpty();
        java.lang.Object obj12 = blockContainer2.clone();
        org.jfree.chart.LegendItemSource legendItemSource13 = null;
        org.jfree.chart.title.LegendTitle legendTitle14 = new org.jfree.chart.title.LegendTitle(legendItemSource13);
        org.jfree.chart.util.VerticalAlignment verticalAlignment15 = org.jfree.chart.util.VerticalAlignment.TOP;
        legendTitle14.setVerticalAlignment(verticalAlignment15);
        java.awt.Font font18 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset19 = null;
        org.jfree.chart.plot.PiePlot piePlot20 = new org.jfree.chart.plot.PiePlot(pieDataset19);
        piePlot20.setForegroundAlpha((float) 0);
        java.awt.Stroke stroke23 = piePlot20.getBaseSectionOutlineStroke();
        piePlot20.setLabelLinkMargin((double) (-256));
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart("PieSection: 0, 100(1)", font18, (org.jfree.chart.plot.Plot) piePlot20, false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo32 = null;
        java.awt.image.BufferedImage bufferedImage33 = jFreeChart27.createBufferedImage((int) (byte) 100, 128, (double) 1L, 90.0d, chartRenderingInfo32);
        legendTitle14.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart27);
        flowArrangement0.add((org.jfree.chart.block.Block) blockContainer2, (java.lang.Object) legendTitle14);
        boolean boolean36 = blockContainer2.isEmpty();
        org.junit.Assert.assertNotNull(size2D4);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(verticalAlignment15);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(bufferedImage33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        java.awt.Color color0 = java.awt.Color.blue;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.util.TableOrder tableOrder1 = org.jfree.chart.util.TableOrder.BY_COLUMN;
        multiplePiePlot0.setDataExtractOrder(tableOrder1);
        multiplePiePlot0.setAggregatedItemsKey((java.lang.Comparable) (-1));
        org.jfree.data.category.CategoryDataset categoryDataset5 = multiplePiePlot0.getDataset();
        java.lang.Object obj6 = multiplePiePlot0.clone();
        multiplePiePlot0.setLimit(2.0d);
        org.jfree.chart.util.TableOrder tableOrder9 = multiplePiePlot0.getDataExtractOrder();
        org.junit.Assert.assertNotNull(tableOrder1);
        org.junit.Assert.assertNull(categoryDataset5);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(tableOrder9);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        java.awt.Shape shape6 = piePlot1.getLegendItemShape();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        piePlot1.setCircular(true);
        org.junit.Assert.assertNotNull(shape6);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        piePlot1.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        piePlot1.setDataset(pieDataset8);
        org.jfree.data.general.PieDataset pieDataset10 = piePlot1.getDataset();
        piePlot1.setOutlineVisible(false);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset13 = new org.jfree.data.category.DefaultCategoryDataset();
        java.util.List list14 = defaultCategoryDataset13.getColumnKeys();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent15 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) piePlot1, (org.jfree.data.general.Dataset) defaultCategoryDataset13);
        defaultCategoryDataset13.clear();
        java.lang.Number number17 = null;
        defaultCategoryDataset13.addValue(number17, (java.lang.Comparable) 1, (java.lang.Comparable) "Other");
        try {
            java.lang.Number number23 = defaultCategoryDataset13.getValue((java.lang.Comparable) 'a', (java.lang.Comparable) "Other");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unrecognised rowKey: a");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNull(pieDataset10);
        org.junit.Assert.assertNotNull(list14);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement3 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer4 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.util.Size2D size2D6 = blockContainer4.arrange(graphics2D5);
        blockContainer4.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D12 = blockContainer4.getBounds();
        java.lang.Object obj14 = textTitle1.draw(graphics2D2, rectangle2D12, (java.lang.Object) (short) 0);
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment17 = textTitle16.getTextAlignment();
        java.lang.String str18 = horizontalAlignment17.toString();
        textTitle1.setHorizontalAlignment(horizontalAlignment17);
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font21 = textTitle20.getFont();
        org.jfree.chart.util.VerticalAlignment verticalAlignment22 = textTitle20.getVerticalAlignment();
        textTitle1.setVerticalAlignment(verticalAlignment22);
        textTitle1.setURLText("Rotation.ANTICLOCKWISE");
        org.jfree.chart.title.TextTitle textTitle27 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment28 = textTitle27.getTextAlignment();
        textTitle1.setHorizontalAlignment(horizontalAlignment28);
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = textTitle1.getPosition();
        textTitle1.setWidth((double) 100L);
        org.junit.Assert.assertNotNull(size2D6);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertNull(obj14);
        org.junit.Assert.assertNotNull(horizontalAlignment17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "HorizontalAlignment.CENTER" + "'", str18.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(verticalAlignment22);
        org.junit.Assert.assertNotNull(horizontalAlignment28);
        org.junit.Assert.assertNotNull(rectangleEdge30);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 255, 1.0d, 100.0d, (-1.0d));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        java.awt.Color color1 = java.awt.Color.GREEN;
        float[] floatArray6 = new float[] { (byte) 1, (short) 0, (short) 100, (short) -1 };
        float[] floatArray7 = color1.getComponents(floatArray6);
        boolean boolean8 = defaultKeyedValues2D0.equals((java.lang.Object) floatArray7);
        int int9 = defaultKeyedValues2D0.getColumnCount();
        int int10 = defaultKeyedValues2D0.getColumnCount();
        defaultKeyedValues2D0.setValue((java.lang.Number) 0, (java.lang.Comparable) "hi!", (java.lang.Comparable) (byte) -1);
        try {
            java.lang.Number number17 = defaultKeyedValues2D0.getValue((java.lang.Comparable) false, (java.lang.Comparable) "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unrecognised columnKey: RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        java.lang.String str0 = org.jfree.chart.labels.StandardPieSectionLabelGenerator.DEFAULT_SECTION_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement1 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.ColumnArrangement columnArrangement2 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource0, (org.jfree.chart.block.Arrangement) columnArrangement1, (org.jfree.chart.block.Arrangement) columnArrangement2);
        columnArrangement1.clear();
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity12 = new org.jfree.chart.entity.PieSectionEntity(shape5, pieDataset6, 0, (int) (byte) 100, (java.lang.Comparable) 1L, "RectangleEdge.TOP", "RectangleEdge.TOP");
        org.jfree.chart.JFreeChart jFreeChart13 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent14 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0, jFreeChart13);
        boolean boolean15 = columnArrangement1.equals((java.lang.Object) chartChangeEvent14);
        org.jfree.chart.LegendItemSource legendItemSource16 = null;
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle(legendItemSource16);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = legendTitle17.getLegendItemGraphicPadding();
        java.awt.Color color19 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        legendTitle17.setBackgroundPaint((java.awt.Paint) color19);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor21 = legendTitle17.getLegendItemGraphicAnchor();
        java.awt.Color color22 = java.awt.Color.green;
        java.awt.Color color23 = color22.darker();
        boolean boolean24 = legendTitle17.equals((java.lang.Object) color23);
        boolean boolean25 = columnArrangement1.equals((java.lang.Object) boolean24);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(rectangleAnchor21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        double double6 = piePlot1.getInteriorGap();
        piePlot1.setMinimumArcAngleToDraw(0.4d);
        org.jfree.chart.plot.Plot plot9 = piePlot1.getRootPlot();
        boolean boolean11 = piePlot1.equals((java.lang.Object) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double14 = rectangleInsets12.calculateTopOutset((double) 0);
        java.lang.String str15 = rectangleInsets12.toString();
        double double17 = rectangleInsets12.calculateTopOutset((double) '#');
        piePlot1.setLabelPadding(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.08d + "'", double6 == 0.08d);
        org.junit.Assert.assertNotNull(plot9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]" + "'", str15.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 4.0d + "'", double17 == 4.0d);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.util.TableOrder tableOrder1 = org.jfree.chart.util.TableOrder.BY_COLUMN;
        multiplePiePlot0.setDataExtractOrder(tableOrder1);
        multiplePiePlot0.setAggregatedItemsKey((java.lang.Comparable) (-1));
        org.jfree.data.category.CategoryDataset categoryDataset5 = multiplePiePlot0.getDataset();
        multiplePiePlot0.setAggregatedItemsKey((java.lang.Comparable) (-1.0d));
        org.junit.Assert.assertNotNull(tableOrder1);
        org.junit.Assert.assertNull(categoryDataset5);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo1 = new org.jfree.chart.ui.BasicProjectInfo();
        java.lang.String str2 = basicProjectInfo1.getCopyright();
        basicProjectInfo0.addLibrary((org.jfree.chart.ui.Library) basicProjectInfo1);
        basicProjectInfo1.setName("RectangleEdge.TOP");
        java.awt.Color color6 = java.awt.Color.gray;
        boolean boolean7 = basicProjectInfo1.equals((java.lang.Object) color6);
        org.jfree.chart.StrokeMap strokeMap8 = new org.jfree.chart.StrokeMap();
        java.awt.Stroke stroke10 = strokeMap8.getStroke((java.lang.Comparable) 4.0d);
        org.jfree.chart.block.ColumnArrangement columnArrangement11 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer12 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement11);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.util.Size2D size2D14 = blockContainer12.arrange(graphics2D13);
        java.lang.Object obj15 = null;
        boolean boolean16 = blockContainer12.equals(obj15);
        java.lang.Class<?> wildcardClass17 = blockContainer12.getClass();
        java.awt.Paint paint22 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder23 = new org.jfree.chart.block.BlockBorder((double) 10, (double) '#', (double) 0L, 0.0d, paint22);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = blockBorder23.getInsets();
        blockContainer12.setFrame((org.jfree.chart.block.BlockFrame) blockBorder23);
        boolean boolean26 = strokeMap8.equals((java.lang.Object) blockContainer12);
        boolean boolean27 = basicProjectInfo1.equals((java.lang.Object) blockContainer12);
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        try {
            blockContainer12.setBounds(rectangle2D28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'bounds' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(stroke10);
        org.junit.Assert.assertNotNull(size2D14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

//    @Test
//    public void test291() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test291");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        java.lang.String str1 = projectInfo0.toString();
//        projectInfo0.setVersion("RectangleEdge.TOP");
//        java.lang.String str4 = projectInfo0.getVersion();
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JFreeChart version RectangleEdge.TOP.\n1.2.0-pre.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nTableOrder.BY_ROW" + "'", str1.equals("JFreeChart version RectangleEdge.TOP.\n1.2.0-pre.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nTableOrder.BY_ROW"));
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "RectangleEdge.TOP" + "'", str4.equals("RectangleEdge.TOP"));
//    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) '4');
        pieLabelDistributor1.distributeLabels((double) 2, 100.0d);
        org.jfree.chart.plot.PieLabelRecord pieLabelRecord5 = null;
        try {
            pieLabelDistributor1.addPieLabelRecord(pieLabelRecord5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'record' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.util.Size2D size2D3 = blockContainer1.arrange(graphics2D2);
        java.lang.Object obj4 = null;
        boolean boolean5 = blockContainer1.equals(obj4);
        java.lang.Class<?> wildcardClass6 = blockContainer1.getClass();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment8 = org.jfree.chart.util.VerticalAlignment.CENTER;
        java.awt.Shape shape9 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity16 = new org.jfree.chart.entity.PieSectionEntity(shape9, pieDataset10, 0, (int) (byte) 100, (java.lang.Comparable) 1L, "RectangleEdge.TOP", "RectangleEdge.TOP");
        pieSectionEntity16.setSectionKey((java.lang.Comparable) 0L);
        boolean boolean19 = verticalAlignment8.equals((java.lang.Object) pieSectionEntity16);
        java.awt.Shape shape20 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset21 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity27 = new org.jfree.chart.entity.PieSectionEntity(shape20, pieDataset21, 0, (int) (byte) 100, (java.lang.Comparable) 1L, "RectangleEdge.TOP", "RectangleEdge.TOP");
        pieSectionEntity27.setSectionKey((java.lang.Comparable) 0L);
        boolean boolean31 = pieSectionEntity27.equals((java.lang.Object) "hi!");
        org.jfree.chart.title.TextTitle textTitle33 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D34 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement35 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer36 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement35);
        java.awt.Graphics2D graphics2D37 = null;
        org.jfree.chart.util.Size2D size2D38 = blockContainer36.arrange(graphics2D37);
        blockContainer36.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D44 = blockContainer36.getBounds();
        java.lang.Object obj46 = textTitle33.draw(graphics2D34, rectangle2D44, (java.lang.Object) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor47 = null;
        java.awt.geom.Point2D point2D48 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D44, rectangleAnchor47);
        pieSectionEntity27.setArea((java.awt.Shape) rectangle2D44);
        pieSectionEntity16.setArea((java.awt.Shape) rectangle2D44);
        java.lang.Object obj51 = null;
        try {
            java.lang.Object obj52 = blockContainer1.draw(graphics2D7, rectangle2D44, obj51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(size2D3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(verticalAlignment8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(size2D38);
        org.junit.Assert.assertNotNull(rectangle2D44);
        org.junit.Assert.assertNull(obj46);
        org.junit.Assert.assertNotNull(point2D48);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("JFreeChart version RectangleEdge.TOP.\n1.2.0-pre.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nPieSection: 0, 100(1)", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        piePlot1.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        piePlot1.setDataset(pieDataset8);
        org.jfree.chart.plot.Plot plot10 = piePlot1.getParent();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset11 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) piePlot1, (org.jfree.data.general.Dataset) defaultCategoryDataset11);
        try {
            defaultCategoryDataset11.removeColumn((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(plot10);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha((float) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean10 = rectangleInsets8.equals((java.lang.Object) rectangleAnchor9);
        double double12 = rectangleInsets8.calculateBottomInset((double) (-1L));
        piePlot1.setSimpleLabelOffset(rectangleInsets8);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle14 = org.jfree.chart.plot.PieLabelLinkStyle.CUBIC_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle14);
        boolean boolean16 = piePlot1.getSectionOutlinesVisible();
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 100.0d + "'", double12 == 100.0d);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_MINIMUM_ARC_ANGLE_TO_DRAW;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-5d + "'", double0 == 1.0E-5d);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setShadowXOffset((double) (byte) -1);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = piePlot1.getSimpleLabelOffset();
        org.junit.Assert.assertNotNull(rectangleInsets6);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setForegroundAlpha((float) 0);
        java.awt.Stroke stroke6 = piePlot3.getBaseSectionOutlineStroke();
        piePlot3.setLabelLinkMargin((double) (-256));
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("PieSection: 0, 100(1)", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
        org.jfree.chart.event.ChartProgressListener chartProgressListener11 = null;
        jFreeChart10.removeProgressListener(chartProgressListener11);
        boolean boolean13 = jFreeChart10.isBorderVisible();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        java.awt.Color color1 = color0.brighter();
        int int2 = color1.getRed();
        java.awt.Color color3 = color1.brighter();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 91 + "'", int2 == 91);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        float float6 = piePlot1.getBackgroundAlpha();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator7 = null;
        piePlot1.setLegendLabelURLGenerator(pieURLGenerator7);
        org.jfree.chart.LegendItemCollection legendItemCollection9 = piePlot1.getLegendItems();
        java.awt.Shape shape10 = piePlot1.getLegendItemShape();
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
        org.junit.Assert.assertNotNull(legendItemCollection9);
        org.junit.Assert.assertNotNull(shape10);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.util.List list1 = defaultCategoryDataset0.getColumnKeys();
        java.lang.Comparable comparable3 = null;
        try {
            defaultCategoryDataset0.addValue((double) 1.0f, comparable3, (java.lang.Comparable) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean6 = rectangleInsets4.equals((java.lang.Object) rectangleAnchor5);
        org.jfree.chart.block.ColumnArrangement columnArrangement7 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer8 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement7);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.util.Size2D size2D10 = blockContainer8.arrange(graphics2D9);
        blockContainer8.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D16 = blockContainer8.getBounds();
        java.awt.geom.Rectangle2D rectangle2D19 = rectangleInsets4.createInsetRectangle(rectangle2D16, true, false);
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D23 = rectangleInsets4.createInsetRectangle(rectangle2D20, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(size2D10);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(rectangle2D19);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.util.Size2D size2D7 = blockContainer5.arrange(graphics2D6);
        blockContainer5.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D13 = blockContainer5.getBounds();
        java.lang.Object obj15 = textTitle2.draw(graphics2D3, rectangle2D13, (java.lang.Object) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = null;
        java.awt.geom.Point2D point2D17 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D13, rectangleAnchor16);
        textTitle0.setBounds(rectangle2D13);
        textTitle0.setToolTipText("HorizontalAlignment.CENTER");
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = textTitle0.getPosition();
        boolean boolean22 = textTitle0.getNotify();
        org.junit.Assert.assertNotNull(size2D7);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNull(obj15);
        org.junit.Assert.assertNotNull(point2D17);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font1 = textTitle0.getFont();
        textTitle0.setID("1.2.0-pre");
        java.lang.Object obj4 = textTitle0.clone();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = textTitle0.getHorizontalAlignment();
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo8 = new org.jfree.chart.ui.BasicProjectInfo();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo9 = new org.jfree.chart.ui.BasicProjectInfo();
        java.lang.String str10 = basicProjectInfo9.getCopyright();
        basicProjectInfo8.addLibrary((org.jfree.chart.ui.Library) basicProjectInfo9);
        java.lang.Object obj12 = textTitle0.draw(graphics2D6, rectangle2D7, (java.lang.Object) basicProjectInfo8);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(horizontalAlignment5);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(obj12);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setForegroundAlpha((float) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean12 = rectangleInsets10.equals((java.lang.Object) rectangleAnchor11);
        double double14 = rectangleInsets10.calculateBottomInset((double) (-1L));
        piePlot3.setSimpleLabelOffset(rectangleInsets10);
        java.awt.Color color16 = java.awt.Color.DARK_GRAY;
        piePlot3.setBackgroundPaint((java.awt.Paint) color16);
        boolean boolean18 = defaultCategoryDataset0.hasListener((java.util.EventListener) piePlot3);
        int int19 = defaultCategoryDataset0.getColumnCount();
        java.lang.Comparable comparable20 = null;
        try {
            java.lang.Number number22 = defaultCategoryDataset0.getValue(comparable20, (java.lang.Comparable) "JFreeChart version RectangleAnchor.BOTTOM_LEFT.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nTableOrder.BY_ROW");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowKey' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 100.0d + "'", double14 == 100.0d);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        piePlot2.setForegroundAlpha((float) 0);
        boolean boolean5 = piePlot2.getIgnoreZeroValues();
        double double6 = piePlot2.getShadowXOffset();
        java.awt.Stroke stroke7 = piePlot2.getLabelLinkStroke();
        java.awt.Paint paint8 = piePlot2.getBaseSectionPaint();
        java.awt.Paint paint9 = piePlot2.getLabelPaint();
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot(pieDataset10);
        piePlot11.setForegroundAlpha(0.0f);
        piePlot11.zoom((double) '#');
        org.jfree.data.general.PieDataset pieDataset16 = null;
        org.jfree.chart.plot.PiePlot piePlot17 = new org.jfree.chart.plot.PiePlot(pieDataset16);
        piePlot17.setForegroundAlpha((float) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor25 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean26 = rectangleInsets24.equals((java.lang.Object) rectangleAnchor25);
        double double28 = rectangleInsets24.calculateBottomInset((double) (-1L));
        piePlot17.setSimpleLabelOffset(rectangleInsets24);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle30 = org.jfree.chart.plot.PieLabelLinkStyle.CUBIC_CURVE;
        piePlot17.setLabelLinkStyle(pieLabelLinkStyle30);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier32 = piePlot17.getDrawingSupplier();
        boolean boolean33 = piePlot11.equals((java.lang.Object) piePlot17);
        org.jfree.chart.LegendItemSource legendItemSource34 = null;
        org.jfree.chart.title.LegendTitle legendTitle35 = new org.jfree.chart.title.LegendTitle(legendItemSource34);
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = legendTitle35.getLegendItemGraphicPadding();
        piePlot17.setSimpleLabelOffset(rectangleInsets36);
        boolean boolean38 = piePlot2.equals((java.lang.Object) rectangleInsets36);
        org.jfree.chart.JFreeChart jFreeChart39 = new org.jfree.chart.JFreeChart("JFreeChart version RectangleAnchor.BOTTOM_LEFT.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nTableOrder.BY_ROW", (org.jfree.chart.plot.Plot) piePlot2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(rectangleAnchor25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 100.0d + "'", double28 == 100.0d);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle30);
        org.junit.Assert.assertNotNull(drawingSupplier32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha((float) 0);
        boolean boolean4 = piePlot1.getIgnoreZeroValues();
        double double5 = piePlot1.getShadowXOffset();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        boolean boolean7 = jFreeChart6.isNotify();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        textTitle1.setBackgroundPaint((java.awt.Paint) color2);
        int int4 = color2.getTransparency();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        piePlot1.setForegroundAlpha((float) (short) 100);
        double double8 = piePlot1.getShadowYOffset();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        piePlot1.handleClick(192, 0, plotRenderingInfo11);
        java.awt.Paint paint13 = null;
        try {
            piePlot1.setLabelPaint(paint13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.0d + "'", double8 == 4.0d);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = textTitle1.getTextAlignment();
        textTitle1.setURLText("RectangleEdge.TOP");
        textTitle1.setPadding(0.0d, (double) 1L, (double) (short) -1, (double) (byte) 10);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font1 = textTitle0.getFont();
        textTitle0.setWidth(0.0d);
        java.lang.String str4 = textTitle0.getURLText();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = null;
        try {
            org.jfree.chart.util.Size2D size2D7 = textTitle0.arrange(graphics2D5, rectangleConstraint6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        try {
            java.awt.Color color1 = java.awt.Color.decode("HorizontalAlignment.CENTER");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"HorizontalAlignment.CENTER\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.chart.PaintMap paintMap0 = new org.jfree.chart.PaintMap();
        java.lang.Object obj1 = paintMap0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) '4');
        pieLabelDistributor1.distributeLabels((double) 2, 100.0d);
        pieLabelDistributor1.distributeLabels((double) 1.0f, 89.0d);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        textTitle1.setWidth(0.0d);
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = null;
        try {
            textTitle1.setVerticalAlignment(verticalAlignment4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'alignment' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        try {
            java.text.AttributedString attributedString3 = standardPieSectionLabelGenerator0.generateAttributedSectionLabel(pieDataset1, (java.lang.Comparable) "PieSection: 0, 100(1)");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        java.awt.Color color1 = color0.brighter();
        java.awt.Color color2 = color0.darker();
        int int3 = color0.getBlue();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        piePlot1.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        piePlot1.setDataset(pieDataset8);
        org.jfree.chart.plot.Plot plot10 = piePlot1.getParent();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset11 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) piePlot1, (org.jfree.data.general.Dataset) defaultCategoryDataset11);
        java.lang.Comparable comparable15 = null;
        try {
            defaultCategoryDataset11.addValue((double) ' ', (java.lang.Comparable) 10, comparable15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(plot10);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setForegroundAlpha((float) 0);
        java.awt.Stroke stroke6 = piePlot3.getBaseSectionOutlineStroke();
        piePlot3.setLabelLinkMargin((double) (-256));
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("PieSection: 0, 100(1)", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
        org.jfree.chart.event.ChartProgressListener chartProgressListener11 = null;
        jFreeChart10.removeProgressListener(chartProgressListener11);
        jFreeChart10.setTitle("hi!");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        try {
            jFreeChart10.handleClick(0, 0, chartRenderingInfo17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        java.lang.Object obj2 = legendTitle1.clone();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        piePlot4.setForegroundAlpha(0.0f);
        piePlot4.setStartAngle((double) 100L);
        piePlot4.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset11 = null;
        piePlot4.setDataset(pieDataset11);
        piePlot4.setMaximumLabelWidth((double) (byte) 100);
        java.awt.Stroke stroke16 = piePlot4.getSectionOutlineStroke((java.lang.Comparable) (short) 0);
        org.jfree.data.general.PieDataset pieDataset17 = null;
        org.jfree.chart.plot.PiePlot piePlot18 = new org.jfree.chart.plot.PiePlot(pieDataset17);
        piePlot18.setForegroundAlpha((float) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean27 = rectangleInsets25.equals((java.lang.Object) rectangleAnchor26);
        double double29 = rectangleInsets25.calculateBottomInset((double) (-1L));
        piePlot18.setSimpleLabelOffset(rectangleInsets25);
        piePlot4.setInsets(rectangleInsets25);
        java.awt.Color color32 = java.awt.Color.BLUE;
        piePlot4.setLabelLinkPaint((java.awt.Paint) color32);
        java.awt.Font font34 = piePlot4.getLabelFont();
        legendTitle1.setItemFont(font34);
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.title.TextTitle textTitle37 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.title.TextTitle textTitle39 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D40 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement41 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer42 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement41);
        java.awt.Graphics2D graphics2D43 = null;
        org.jfree.chart.util.Size2D size2D44 = blockContainer42.arrange(graphics2D43);
        blockContainer42.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D50 = blockContainer42.getBounds();
        java.lang.Object obj52 = textTitle39.draw(graphics2D40, rectangle2D50, (java.lang.Object) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor53 = null;
        java.awt.geom.Point2D point2D54 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D50, rectangleAnchor53);
        textTitle37.setBounds(rectangle2D50);
        java.awt.geom.Rectangle2D rectangle2D58 = rectangleInsets36.createOutsetRectangle(rectangle2D50, false, true);
        legendTitle1.setLegendItemGraphicPadding(rectangleInsets36);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNull(stroke16);
        org.junit.Assert.assertNotNull(rectangleAnchor26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 100.0d + "'", double29 == 100.0d);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertNotNull(size2D44);
        org.junit.Assert.assertNotNull(rectangle2D50);
        org.junit.Assert.assertNull(obj52);
        org.junit.Assert.assertNotNull(point2D54);
        org.junit.Assert.assertNotNull(rectangle2D58);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.util.Size2D size2D3 = blockContainer1.arrange(graphics2D2);
        java.lang.Object obj4 = null;
        boolean boolean5 = blockContainer1.equals(obj4);
        java.lang.Class<?> wildcardClass6 = blockContainer1.getClass();
        java.awt.geom.Rectangle2D rectangle2D7 = blockContainer1.getBounds();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement12 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer13 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement12);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.util.Size2D size2D15 = blockContainer13.arrange(graphics2D14);
        blockContainer13.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D21 = blockContainer13.getBounds();
        java.lang.Object obj23 = textTitle10.draw(graphics2D11, rectangle2D21, (java.lang.Object) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = null;
        java.awt.geom.Point2D point2D25 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D21, rectangleAnchor24);
        try {
            blockContainer1.draw(graphics2D8, rectangle2D21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(size2D3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(size2D15);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertNull(obj23);
        org.junit.Assert.assertNotNull(point2D25);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        java.awt.Color color1 = java.awt.Color.GREEN;
        float[] floatArray6 = new float[] { (byte) 1, (short) 0, (short) 100, (short) -1 };
        float[] floatArray7 = color1.getComponents(floatArray6);
        boolean boolean8 = defaultKeyedValues2D0.equals((java.lang.Object) floatArray7);
        int int9 = defaultKeyedValues2D0.getColumnCount();
        int int10 = defaultKeyedValues2D0.getColumnCount();
        int int12 = defaultKeyedValues2D0.getRowIndex((java.lang.Comparable) true);
        try {
            java.lang.Comparable comparable14 = defaultKeyedValues2D0.getColumnKey((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha((float) 0);
        boolean boolean4 = piePlot1.getIgnoreZeroValues();
        double double5 = piePlot1.getShadowXOffset();
        java.awt.Stroke stroke6 = piePlot1.getLabelLinkStroke();
        java.awt.Paint paint7 = piePlot1.getBaseSectionPaint();
        org.jfree.chart.util.Rotation rotation8 = piePlot1.getDirection();
        java.awt.Shape shape9 = null;
        try {
            piePlot1.setLegendItemShape(shape9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'shape' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(rotation8);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha((float) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean10 = rectangleInsets8.equals((java.lang.Object) rectangleAnchor9);
        double double12 = rectangleInsets8.calculateBottomInset((double) (-1L));
        piePlot1.setSimpleLabelOffset(rectangleInsets8);
        java.awt.Paint paint14 = piePlot1.getLabelOutlinePaint();
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement16 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer17 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement16);
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.util.Size2D size2D19 = blockContainer17.arrange(graphics2D18);
        java.lang.Object obj20 = null;
        boolean boolean21 = blockContainer17.equals(obj20);
        java.lang.Class<?> wildcardClass22 = blockContainer17.getClass();
        java.awt.geom.Rectangle2D rectangle2D23 = blockContainer17.getBounds();
        org.jfree.chart.entity.ChartEntity chartEntity25 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D23, "JFreeChart version RectangleAnchor.BOTTOM_LEFT.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nTableOrder.BY_ROW");
        try {
            piePlot1.drawOutline(graphics2D15, rectangle2D23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 100.0d + "'", double12 == 100.0d);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(size2D19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(rectangle2D23);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        java.awt.Color color1 = java.awt.Color.GREEN;
        float[] floatArray6 = new float[] { (byte) 1, (short) 0, (short) 100, (short) -1 };
        float[] floatArray7 = color1.getComponents(floatArray6);
        boolean boolean8 = defaultKeyedValues2D0.equals((java.lang.Object) floatArray7);
        int int9 = defaultKeyedValues2D0.getColumnCount();
        int int10 = defaultKeyedValues2D0.getColumnCount();
        java.util.List list11 = defaultKeyedValues2D0.getColumnKeys();
        int int13 = defaultKeyedValues2D0.getColumnIndex((java.lang.Comparable) "hi!");
        defaultKeyedValues2D0.clear();
        try {
            defaultKeyedValues2D0.removeColumn((java.lang.Comparable) (-1L));
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unknown key: -1");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 0, (int) (byte) 100, (java.lang.Comparable) 1L, "RectangleEdge.TOP", "RectangleEdge.TOP");
        org.jfree.data.general.PieDataset pieDataset8 = null;
        pieSectionEntity7.setDataset(pieDataset8);
        java.lang.String str10 = pieSectionEntity7.toString();
        java.lang.Comparable comparable11 = pieSectionEntity7.getSectionKey();
        java.lang.String str12 = pieSectionEntity7.getToolTipText();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "PieSection: 0, 100(1)" + "'", str10.equals("PieSection: 0, 100(1)"));
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + 1L + "'", comparable11.equals(1L));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "RectangleEdge.TOP" + "'", str12.equals("RectangleEdge.TOP"));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setForegroundAlpha((float) 0);
        java.awt.Stroke stroke6 = piePlot3.getBaseSectionOutlineStroke();
        piePlot3.setLabelLinkMargin((double) (-256));
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("PieSection: 0, 100(1)", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
        double double11 = piePlot3.getInteriorGap();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment13 = org.jfree.chart.util.VerticalAlignment.CENTER;
        java.awt.Shape shape14 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset15 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity21 = new org.jfree.chart.entity.PieSectionEntity(shape14, pieDataset15, 0, (int) (byte) 100, (java.lang.Comparable) 1L, "RectangleEdge.TOP", "RectangleEdge.TOP");
        pieSectionEntity21.setSectionKey((java.lang.Comparable) 0L);
        boolean boolean24 = verticalAlignment13.equals((java.lang.Object) pieSectionEntity21);
        java.awt.Shape shape25 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset26 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity32 = new org.jfree.chart.entity.PieSectionEntity(shape25, pieDataset26, 0, (int) (byte) 100, (java.lang.Comparable) 1L, "RectangleEdge.TOP", "RectangleEdge.TOP");
        pieSectionEntity32.setSectionKey((java.lang.Comparable) 0L);
        boolean boolean36 = pieSectionEntity32.equals((java.lang.Object) "hi!");
        org.jfree.chart.title.TextTitle textTitle38 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D39 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement40 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer41 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement40);
        java.awt.Graphics2D graphics2D42 = null;
        org.jfree.chart.util.Size2D size2D43 = blockContainer41.arrange(graphics2D42);
        blockContainer41.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D49 = blockContainer41.getBounds();
        java.lang.Object obj51 = textTitle38.draw(graphics2D39, rectangle2D49, (java.lang.Object) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor52 = null;
        java.awt.geom.Point2D point2D53 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D49, rectangleAnchor52);
        pieSectionEntity32.setArea((java.awt.Shape) rectangle2D49);
        pieSectionEntity21.setArea((java.awt.Shape) rectangle2D49);
        piePlot3.drawBackgroundImage(graphics2D12, rectangle2D49);
        double double57 = piePlot3.getLabelGap();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.08d + "'", double11 == 0.08d);
        org.junit.Assert.assertNotNull(verticalAlignment13);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(size2D43);
        org.junit.Assert.assertNotNull(rectangle2D49);
        org.junit.Assert.assertNull(obj51);
        org.junit.Assert.assertNotNull(point2D53);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.025d + "'", double57 == 0.025d);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 0, (int) (byte) 100, (java.lang.Comparable) 1L, "RectangleEdge.TOP", "RectangleEdge.TOP");
        org.jfree.data.UnknownKeyException unknownKeyException9 = new org.jfree.data.UnknownKeyException("");
        boolean boolean10 = pieSectionEntity7.equals((java.lang.Object) "");
        java.lang.String str11 = pieSectionEntity7.toString();
        pieSectionEntity7.setToolTipText("JFreeChart version RectangleEdge.TOP.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nTableOrder.BY_ROW");
        java.awt.Shape shape14 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset15 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity21 = new org.jfree.chart.entity.PieSectionEntity(shape14, pieDataset15, 0, (int) (byte) 100, (java.lang.Comparable) 1L, "RectangleEdge.TOP", "RectangleEdge.TOP");
        org.jfree.data.general.PieDataset pieDataset22 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity28 = new org.jfree.chart.entity.PieSectionEntity(shape14, pieDataset22, (-254), 2, (java.lang.Comparable) "org.jfree.chart.event.ChartChangeEvent[source=0]", "PieSection: 0, 100(1)", "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        pieSectionEntity7.setArea(shape14);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "PieSection: 0, 100(1)" + "'", str11.equals("PieSection: 0, 100(1)"));
        org.junit.Assert.assertNotNull(shape14);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.Color color1 = color0.brighter();
        int int2 = color1.getTransparency();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        piePlot1.setForegroundAlpha((float) (short) 100);
        double double8 = piePlot1.getShadowYOffset();
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        piePlot10.setForegroundAlpha(0.0f);
        piePlot10.setStartAngle((double) 100L);
        piePlot10.setForegroundAlpha((float) (short) 100);
        double double17 = piePlot10.getShadowYOffset();
        piePlot1.setParent((org.jfree.chart.plot.Plot) piePlot10);
        float float19 = piePlot10.getBackgroundAlpha();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator20 = piePlot10.getLegendLabelURLGenerator();
        java.lang.String str21 = piePlot10.getNoDataMessage();
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.0d + "'", double8 == 4.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 4.0d + "'", double17 == 4.0d);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 1.0f + "'", float19 == 1.0f);
        org.junit.Assert.assertNull(pieURLGenerator20);
        org.junit.Assert.assertNull(str21);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        java.lang.ClassLoader classLoader0 = null;
        try {
            java.util.ResourceBundle.clearCache(classLoader0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.chart.util.TableOrder tableOrder0 = org.jfree.chart.util.TableOrder.BY_COLUMN;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = textTitle2.getTextAlignment();
        textTitle2.setURLText("RectangleEdge.TOP");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = textTitle2.getHorizontalAlignment();
        boolean boolean7 = tableOrder0.equals((java.lang.Object) horizontalAlignment6);
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement11 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer12 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement11);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.util.Size2D size2D14 = blockContainer12.arrange(graphics2D13);
        blockContainer12.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D20 = blockContainer12.getBounds();
        java.lang.Object obj22 = textTitle9.draw(graphics2D10, rectangle2D20, (java.lang.Object) (short) 0);
        org.jfree.chart.title.TextTitle textTitle24 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment25 = textTitle24.getTextAlignment();
        java.lang.String str26 = horizontalAlignment25.toString();
        textTitle9.setHorizontalAlignment(horizontalAlignment25);
        org.jfree.chart.title.TextTitle textTitle28 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font29 = textTitle28.getFont();
        org.jfree.chart.util.VerticalAlignment verticalAlignment30 = textTitle28.getVerticalAlignment();
        textTitle9.setVerticalAlignment(verticalAlignment30);
        org.jfree.chart.block.FlowArrangement flowArrangement34 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment6, verticalAlignment30, (double) '#', (double) 2);
        org.junit.Assert.assertNotNull(tableOrder0);
        org.junit.Assert.assertNotNull(horizontalAlignment3);
        org.junit.Assert.assertNotNull(horizontalAlignment6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(size2D14);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNull(obj22);
        org.junit.Assert.assertNotNull(horizontalAlignment25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "HorizontalAlignment.CENTER" + "'", str26.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertNotNull(verticalAlignment30);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.util.Size2D size2D3 = blockContainer1.arrange(graphics2D2);
        java.lang.Object obj4 = null;
        boolean boolean5 = blockContainer1.equals(obj4);
        java.lang.Class<?> wildcardClass6 = blockContainer1.getClass();
        blockContainer1.clear();
        blockContainer1.setMargin((double) 91, 181.0d, (double) (byte) 0, (double) (short) 0);
        org.junit.Assert.assertNotNull(size2D3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.util.Size2D size2D3 = blockContainer1.arrange(graphics2D2);
        blockContainer1.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        org.jfree.chart.block.BlockFrame blockFrame9 = blockContainer1.getFrame();
        org.junit.Assert.assertNotNull(size2D3);
        org.junit.Assert.assertNotNull(blockFrame9);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        int int1 = color0.getGreen();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        float float6 = piePlot1.getBackgroundAlpha();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator7 = null;
        piePlot1.setLegendLabelURLGenerator(pieURLGenerator7);
        java.awt.Paint paint9 = piePlot1.getLabelLinkPaint();
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.util.Size2D size2D3 = blockContainer1.arrange(graphics2D2);
        java.lang.Object obj4 = null;
        boolean boolean5 = blockContainer1.equals(obj4);
        java.lang.Class<?> wildcardClass6 = blockContainer1.getClass();
        blockContainer1.clear();
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        piePlot9.setForegroundAlpha((float) 0);
        boolean boolean12 = piePlot9.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator13 = piePlot9.getLegendLabelGenerator();
        boolean boolean14 = blockContainer1.equals((java.lang.Object) pieSectionLabelGenerator13);
        org.junit.Assert.assertNotNull(size2D3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) '4');
        pieLabelDistributor1.distributeLabels((double) 2, 100.0d);
        int int5 = pieLabelDistributor1.getItemCount();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean10 = rectangleInsets8.equals((java.lang.Object) rectangleAnchor9);
        double double12 = rectangleInsets8.calculateTopInset(0.0d);
        piePlot1.setInsets(rectangleInsets8);
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        piePlot15.setForegroundAlpha((float) 0);
        boolean boolean18 = piePlot15.getIgnoreZeroValues();
        double double19 = piePlot15.getShadowXOffset();
        java.awt.Stroke stroke20 = piePlot15.getLabelLinkStroke();
        piePlot1.setBaseSectionOutlineStroke(stroke20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        piePlot1.handleClick(255, (int) (short) 0, plotRenderingInfo24);
        java.awt.Paint paint26 = piePlot1.getLabelBackgroundPaint();
        java.lang.String str27 = piePlot1.getNoDataMessage();
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.0d) + "'", double12 == (-1.0d));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 4.0d + "'", double19 == 4.0d);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNull(str27);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj1 = null;
        int int2 = objectList0.indexOf(obj1);
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        piePlot5.setForegroundAlpha((float) 0);
        boolean boolean8 = piePlot5.getIgnoreZeroValues();
        double double9 = piePlot5.getShadowXOffset();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot5);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo13 = null;
        java.awt.image.BufferedImage bufferedImage14 = jFreeChart10.createBufferedImage((int) 'a', (int) (byte) 100, chartRenderingInfo13);
        java.awt.Paint paint15 = jFreeChart10.getBackgroundPaint();
        try {
            objectList0.set((-7904), (java.lang.Object) paint15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 4.0d + "'", double9 == 4.0d);
        org.junit.Assert.assertNotNull(bufferedImage14);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha((float) 0);
        boolean boolean4 = piePlot1.getIgnoreZeroValues();
        double double5 = piePlot1.getShadowXOffset();
        java.awt.Stroke stroke6 = piePlot1.getLabelLinkStroke();
        java.awt.Paint paint7 = piePlot1.getBaseSectionPaint();
        java.awt.Paint paint8 = piePlot1.getLabelPaint();
        piePlot1.setExplodePercent((java.lang.Comparable) 0.0d, (double) (-254));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font1 = textTitle0.getFont();
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = textTitle0.getVerticalAlignment();
        java.lang.Object obj3 = textTitle0.clone();
        java.lang.String str4 = textTitle0.getText();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        piePlot1.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        piePlot1.setDataset(pieDataset8);
        piePlot1.setMaximumLabelWidth((double) (byte) 100);
        org.jfree.data.general.PieDataset pieDataset12 = piePlot1.getDataset();
        double double13 = piePlot1.getLabelLinkMargin();
        piePlot1.setMaximumLabelWidth((double) 1L);
        org.junit.Assert.assertNull(pieDataset12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        double double1 = multiplePiePlot0.getLimit();
        java.awt.Paint paint2 = multiplePiePlot0.getAggregatedItemsPaint();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        piePlot7.setForegroundAlpha((float) 0);
        java.awt.Stroke stroke10 = piePlot7.getBaseSectionOutlineStroke();
        piePlot7.setLabelLinkMargin((double) (-256));
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("PieSection: 0, 100(1)", font5, (org.jfree.chart.plot.Plot) piePlot7, false);
        double double15 = piePlot7.getInteriorGap();
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment17 = org.jfree.chart.util.VerticalAlignment.CENTER;
        java.awt.Shape shape18 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset19 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity25 = new org.jfree.chart.entity.PieSectionEntity(shape18, pieDataset19, 0, (int) (byte) 100, (java.lang.Comparable) 1L, "RectangleEdge.TOP", "RectangleEdge.TOP");
        pieSectionEntity25.setSectionKey((java.lang.Comparable) 0L);
        boolean boolean28 = verticalAlignment17.equals((java.lang.Object) pieSectionEntity25);
        java.awt.Shape shape29 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset30 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity36 = new org.jfree.chart.entity.PieSectionEntity(shape29, pieDataset30, 0, (int) (byte) 100, (java.lang.Comparable) 1L, "RectangleEdge.TOP", "RectangleEdge.TOP");
        pieSectionEntity36.setSectionKey((java.lang.Comparable) 0L);
        boolean boolean40 = pieSectionEntity36.equals((java.lang.Object) "hi!");
        org.jfree.chart.title.TextTitle textTitle42 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D43 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement44 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer45 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement44);
        java.awt.Graphics2D graphics2D46 = null;
        org.jfree.chart.util.Size2D size2D47 = blockContainer45.arrange(graphics2D46);
        blockContainer45.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D53 = blockContainer45.getBounds();
        java.lang.Object obj55 = textTitle42.draw(graphics2D43, rectangle2D53, (java.lang.Object) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor56 = null;
        java.awt.geom.Point2D point2D57 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D53, rectangleAnchor56);
        pieSectionEntity36.setArea((java.awt.Shape) rectangle2D53);
        pieSectionEntity25.setArea((java.awt.Shape) rectangle2D53);
        piePlot7.drawBackgroundImage(graphics2D16, rectangle2D53);
        java.awt.geom.Point2D point2D61 = null;
        org.jfree.chart.plot.PlotState plotState62 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo63 = null;
        try {
            multiplePiePlot0.draw(graphics2D3, rectangle2D53, point2D61, plotState62, plotRenderingInfo63);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.08d + "'", double15 == 0.08d);
        org.junit.Assert.assertNotNull(verticalAlignment17);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(size2D47);
        org.junit.Assert.assertNotNull(rectangle2D53);
        org.junit.Assert.assertNull(obj55);
        org.junit.Assert.assertNotNull(point2D57);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        java.awt.Stroke stroke6 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        piePlot1.setLabelOutlineStroke(stroke6);
        piePlot1.setMaximumLabelWidth((-1.0d));
        piePlot1.setShadowYOffset((double) (short) 0);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        piePlot14.setForegroundAlpha(0.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor22 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean23 = rectangleInsets21.equals((java.lang.Object) rectangleAnchor22);
        double double25 = rectangleInsets21.calculateTopInset(0.0d);
        piePlot14.setInsets(rectangleInsets21);
        org.jfree.data.general.PieDataset pieDataset27 = null;
        org.jfree.chart.plot.PiePlot piePlot28 = new org.jfree.chart.plot.PiePlot(pieDataset27);
        piePlot28.setForegroundAlpha((float) 0);
        boolean boolean31 = piePlot28.getIgnoreZeroValues();
        double double32 = piePlot28.getShadowXOffset();
        java.awt.Stroke stroke33 = piePlot28.getLabelLinkStroke();
        piePlot14.setBaseSectionOutlineStroke(stroke33);
        piePlot1.setSectionOutlineStroke((java.lang.Comparable) 255, stroke33);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleAnchor22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + (-1.0d) + "'", double25 == (-1.0d));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 4.0d + "'", double32 == 4.0d);
        org.junit.Assert.assertNotNull(stroke33);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement5 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer6 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement5);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.util.Size2D size2D8 = blockContainer6.arrange(graphics2D7);
        blockContainer6.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D14 = blockContainer6.getBounds();
        java.lang.Object obj16 = textTitle3.draw(graphics2D4, rectangle2D14, (java.lang.Object) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D14, rectangleAnchor17);
        textTitle1.setBounds(rectangle2D14);
        java.awt.geom.Rectangle2D rectangle2D22 = rectangleInsets0.createOutsetRectangle(rectangle2D14, false, true);
        double double24 = rectangleInsets0.extendWidth((double) 10.0f);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(size2D8);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertNull(obj16);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 10.0d + "'", double24 == 10.0d);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.ANTICLOCKWISE;
        java.lang.String str1 = rotation0.toString();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = textTitle3.getTextAlignment();
        boolean boolean5 = rotation0.equals((java.lang.Object) horizontalAlignment4);
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("");
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        textTitle7.setBackgroundPaint((java.awt.Paint) color8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        java.awt.Color color11 = color10.brighter();
        textTitle7.setPaint((java.awt.Paint) color11);
        boolean boolean13 = rotation0.equals((java.lang.Object) textTitle7);
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font15 = textTitle14.getFont();
        org.jfree.chart.util.VerticalAlignment verticalAlignment16 = textTitle14.getVerticalAlignment();
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D19 = new org.jfree.data.DefaultKeyedValues2D();
        java.awt.Color color20 = java.awt.Color.GREEN;
        float[] floatArray25 = new float[] { (byte) 1, (short) 0, (short) 100, (short) -1 };
        float[] floatArray26 = color20.getComponents(floatArray25);
        boolean boolean27 = defaultKeyedValues2D19.equals((java.lang.Object) floatArray26);
        int int28 = defaultKeyedValues2D19.getColumnCount();
        int int29 = defaultKeyedValues2D19.getColumnCount();
        java.util.List list30 = defaultKeyedValues2D19.getColumnKeys();
        java.lang.Number number31 = null;
        defaultKeyedValues2D19.setValue(number31, (java.lang.Comparable) 192, (java.lang.Comparable) 1);
        java.lang.Object obj35 = textTitle14.draw(graphics2D17, rectangle2D18, (java.lang.Object) 192);
        boolean boolean36 = rotation0.equals(obj35);
        boolean boolean38 = rotation0.equals((java.lang.Object) 0.08d);
        org.junit.Assert.assertNotNull(rotation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Rotation.ANTICLOCKWISE" + "'", str1.equals("Rotation.ANTICLOCKWISE"));
        org.junit.Assert.assertNotNull(horizontalAlignment4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(verticalAlignment16);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(floatArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(list30);
        org.junit.Assert.assertNull(obj35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        piePlot1.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        piePlot1.setDataset(pieDataset8);
        org.jfree.data.general.PieDataset pieDataset10 = piePlot1.getDataset();
        java.lang.String str11 = piePlot1.getNoDataMessage();
        piePlot1.setLabelLinkMargin((double) 0.5f);
        java.awt.Paint paint14 = piePlot1.getNoDataMessagePaint();
        java.awt.Stroke stroke15 = piePlot1.getBaseSectionOutlineStroke();
        org.junit.Assert.assertNull(pieDataset10);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        double double6 = piePlot1.getInteriorGap();
        java.awt.Paint paint7 = piePlot1.getLabelOutlinePaint();
        java.awt.Color color10 = java.awt.Color.getColor("RectangleEdge.TOP", (int) (short) 1);
        org.jfree.chart.ChartColor chartColor14 = new org.jfree.chart.ChartColor(15, 192, (int) (short) 10);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType15 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.awt.Color color16 = java.awt.Color.GREEN;
        boolean boolean17 = chartChangeEventType15.equals((java.lang.Object) color16);
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        int int19 = color18.getTransparency();
        java.awt.Color color20 = java.awt.Color.BLACK;
        java.awt.Color color21 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        java.awt.Paint[] paintArray22 = new java.awt.Paint[] { color10, chartColor14, color16, color18, color20, color21 };
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType23 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.awt.Color color24 = java.awt.Color.GREEN;
        boolean boolean25 = chartChangeEventType23.equals((java.lang.Object) color24);
        java.awt.Paint paint30 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder31 = new org.jfree.chart.block.BlockBorder((double) 10, (double) '#', (double) 0L, 0.0d, paint30);
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.Paint[] paintArray33 = new java.awt.Paint[] { color24, paint30, color32 };
        java.awt.Paint[] paintArray34 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray35 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray36 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray37 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier38 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray22, paintArray33, paintArray34, strokeArray35, strokeArray36, shapeArray37);
        piePlot1.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier38);
        java.awt.Paint paint40 = defaultDrawingSupplier38.getNextFillPaint();
        java.awt.Stroke stroke41 = defaultDrawingSupplier38.getNextStroke();
        org.jfree.chart.block.FlowArrangement flowArrangement42 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.Block block43 = null;
        java.awt.Stroke stroke44 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        flowArrangement42.add(block43, (java.lang.Object) stroke44);
        boolean boolean46 = defaultDrawingSupplier38.equals((java.lang.Object) flowArrangement42);
        org.jfree.chart.block.ColumnArrangement columnArrangement47 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer48 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement47);
        java.awt.Graphics2D graphics2D49 = null;
        org.jfree.chart.util.Size2D size2D50 = blockContainer48.arrange(graphics2D49);
        blockContainer48.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D56 = blockContainer48.getBounds();
        boolean boolean57 = blockContainer48.isEmpty();
        java.awt.Graphics2D graphics2D58 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint59 = null;
        try {
            org.jfree.chart.util.Size2D size2D60 = flowArrangement42.arrange(blockContainer48, graphics2D58, rectangleConstraint59);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.08d + "'", double6 == 0.08d);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(chartChangeEventType15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(paintArray22);
        org.junit.Assert.assertNotNull(chartChangeEventType23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(paintArray33);
        org.junit.Assert.assertNotNull(paintArray34);
        org.junit.Assert.assertNotNull(strokeArray35);
        org.junit.Assert.assertNotNull(strokeArray36);
        org.junit.Assert.assertNotNull(shapeArray37);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(size2D50);
        org.junit.Assert.assertNotNull(rectangle2D56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        piePlot1.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        piePlot1.setDataset(pieDataset8);
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        piePlot1.removeChangeListener(plotChangeListener10);
        org.jfree.chart.block.FlowArrangement flowArrangement12 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.Block block13 = null;
        java.awt.Stroke stroke14 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        flowArrangement12.add(block13, (java.lang.Object) stroke14);
        piePlot1.setBaseSectionOutlineStroke(stroke14);
        piePlot1.zoom((double) (byte) 100);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha((float) 0);
        boolean boolean4 = piePlot1.getIgnoreZeroValues();
        double double5 = piePlot1.getShadowXOffset();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo9 = null;
        java.awt.image.BufferedImage bufferedImage10 = jFreeChart6.createBufferedImage((int) 'a', (int) (byte) 100, chartRenderingInfo9);
        java.awt.Image image11 = jFreeChart6.getBackgroundImage();
        org.jfree.chart.LegendItemSource legendItemSource12 = null;
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle(legendItemSource12);
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        java.lang.String str15 = rectangleEdge14.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge14);
        legendTitle13.setLegendItemGraphicEdge(rectangleEdge14);
        org.jfree.chart.block.BlockFrame blockFrame18 = legendTitle13.getFrame();
        java.awt.Paint paint23 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder24 = new org.jfree.chart.block.BlockBorder((double) 10, (double) '#', (double) 0L, 0.0d, paint23);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = blockBorder24.getInsets();
        double double27 = rectangleInsets25.calculateLeftOutset(0.025d);
        legendTitle13.setItemLabelPadding(rectangleInsets25);
        jFreeChart6.addSubtitle((org.jfree.chart.title.Title) legendTitle13);
        org.jfree.chart.LegendItemSource legendItemSource30 = null;
        org.jfree.chart.title.LegendTitle legendTitle31 = new org.jfree.chart.title.LegendTitle(legendItemSource30);
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        java.lang.String str33 = rectangleEdge32.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge32);
        legendTitle31.setLegendItemGraphicEdge(rectangleEdge32);
        org.jfree.chart.block.BlockFrame blockFrame36 = legendTitle31.getFrame();
        jFreeChart6.addLegend(legendTitle31);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(bufferedImage10);
        org.junit.Assert.assertNull(image11);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "RectangleEdge.TOP" + "'", str15.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNotNull(blockFrame18);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 35.0d + "'", double27 == 35.0d);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "RectangleEdge.TOP" + "'", str33.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertNotNull(rectangleEdge34);
        org.junit.Assert.assertNotNull(blockFrame36);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 0, (int) (byte) 100, (java.lang.Comparable) 1L, "RectangleEdge.TOP", "RectangleEdge.TOP");
        org.jfree.data.general.PieDataset pieDataset8 = pieSectionEntity7.getDataset();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNull(pieDataset8);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha((float) 0);
        boolean boolean4 = piePlot1.getIgnoreZeroValues();
        double double5 = piePlot1.getShadowXOffset();
        piePlot1.setIgnoreZeroValues(true);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator8 = piePlot1.getLegendLabelGenerator();
        java.awt.Stroke stroke9 = piePlot1.getLabelLinkStroke();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator8);
        org.junit.Assert.assertNotNull(stroke9);
    }

//    @Test
//    public void test357() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test357");
//        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
//        java.awt.Color color1 = java.awt.Color.GREEN;
//        float[] floatArray6 = new float[] { (byte) 1, (short) 0, (short) 100, (short) -1 };
//        float[] floatArray7 = color1.getComponents(floatArray6);
//        boolean boolean8 = defaultKeyedValues2D0.equals((java.lang.Object) floatArray7);
//        int int9 = defaultKeyedValues2D0.getColumnCount();
//        int int10 = defaultKeyedValues2D0.getColumnCount();
//        java.util.List list11 = defaultKeyedValues2D0.getColumnKeys();
//        defaultKeyedValues2D0.addValue((java.lang.Number) 15, (java.lang.Comparable) (-256), (java.lang.Comparable) (byte) 1);
//        org.jfree.chart.ui.ProjectInfo projectInfo16 = org.jfree.chart.JFreeChart.INFO;
//        java.lang.String str17 = projectInfo16.toString();
//        projectInfo16.setVersion("RectangleEdge.TOP");
//        java.util.List list20 = projectInfo16.getContributors();
//        boolean boolean21 = defaultKeyedValues2D0.equals((java.lang.Object) projectInfo16);
//        try {
//            java.lang.Comparable comparable23 = defaultKeyedValues2D0.getColumnKey((-1));
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(color1);
//        org.junit.Assert.assertNotNull(floatArray6);
//        org.junit.Assert.assertNotNull(floatArray7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(list11);
//        org.junit.Assert.assertNotNull(projectInfo16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "JFreeChart version RectangleEdge.TOP.\n1.2.0-pre.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nTableOrder.BY_ROW" + "'", str17.equals("JFreeChart version RectangleEdge.TOP.\n1.2.0-pre.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nTableOrder.BY_ROW"));
//        org.junit.Assert.assertNull(list20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        try {
            defaultKeyedValues2D0.removeColumn((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean6 = rectangleInsets4.equals((java.lang.Object) rectangleAnchor5);
        double double7 = rectangleInsets4.getTop();
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha((float) 0);
        boolean boolean4 = piePlot1.getIgnoreZeroValues();
        double double5 = piePlot1.getShadowXOffset();
        java.awt.Stroke stroke6 = piePlot1.getLabelLinkStroke();
        java.awt.Paint paint7 = piePlot1.getBaseSectionPaint();
        org.jfree.chart.util.Rotation rotation8 = piePlot1.getDirection();
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement12 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer13 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement12);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.util.Size2D size2D15 = blockContainer13.arrange(graphics2D14);
        blockContainer13.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D21 = blockContainer13.getBounds();
        java.lang.Object obj23 = textTitle10.draw(graphics2D11, rectangle2D21, (java.lang.Object) (short) 0);
        boolean boolean24 = textTitle10.getExpandToFitSpace();
        double double25 = textTitle10.getWidth();
        boolean boolean26 = rotation8.equals((java.lang.Object) textTitle10);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(rotation8);
        org.junit.Assert.assertNotNull(size2D15);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertNull(obj23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha((float) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean10 = rectangleInsets8.equals((java.lang.Object) rectangleAnchor9);
        double double12 = rectangleInsets8.calculateBottomInset((double) (-1L));
        piePlot1.setSimpleLabelOffset(rectangleInsets8);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle14 = org.jfree.chart.plot.PieLabelLinkStyle.CUBIC_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle14);
        java.lang.Object obj16 = null;
        boolean boolean17 = pieLabelLinkStyle14.equals(obj16);
        java.awt.Color color20 = java.awt.Color.getColor("RectangleEdge.TOP", (int) (short) 1);
        org.jfree.chart.ChartColor chartColor24 = new org.jfree.chart.ChartColor(15, 192, (int) (short) 10);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType25 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.awt.Color color26 = java.awt.Color.GREEN;
        boolean boolean27 = chartChangeEventType25.equals((java.lang.Object) color26);
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        int int29 = color28.getTransparency();
        java.awt.Color color30 = java.awt.Color.BLACK;
        java.awt.Color color31 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        java.awt.Paint[] paintArray32 = new java.awt.Paint[] { color20, chartColor24, color26, color28, color30, color31 };
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType33 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.awt.Color color34 = java.awt.Color.GREEN;
        boolean boolean35 = chartChangeEventType33.equals((java.lang.Object) color34);
        java.awt.Paint paint40 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder41 = new org.jfree.chart.block.BlockBorder((double) 10, (double) '#', (double) 0L, 0.0d, paint40);
        java.awt.Color color42 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.Paint[] paintArray43 = new java.awt.Paint[] { color34, paint40, color42 };
        java.awt.Paint[] paintArray44 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray45 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray46 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray47 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier48 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray32, paintArray43, paintArray44, strokeArray45, strokeArray46, shapeArray47);
        boolean boolean49 = pieLabelLinkStyle14.equals((java.lang.Object) shapeArray47);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 100.0d + "'", double12 == 100.0d);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(chartChangeEventType25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(paintArray32);
        org.junit.Assert.assertNotNull(chartChangeEventType33);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(paintArray43);
        org.junit.Assert.assertNotNull(paintArray44);
        org.junit.Assert.assertNotNull(strokeArray45);
        org.junit.Assert.assertNotNull(strokeArray46);
        org.junit.Assert.assertNotNull(shapeArray47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha((float) 0);
        boolean boolean4 = piePlot1.getIgnoreZeroValues();
        double double5 = piePlot1.getShadowXOffset();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot7 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.util.TableOrder tableOrder8 = org.jfree.chart.util.TableOrder.BY_COLUMN;
        multiplePiePlot7.setDataExtractOrder(tableOrder8);
        java.awt.Font font11 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        piePlot13.setForegroundAlpha((float) 0);
        java.awt.Stroke stroke16 = piePlot13.getBaseSectionOutlineStroke();
        piePlot13.setLabelLinkMargin((double) (-256));
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("PieSection: 0, 100(1)", font11, (org.jfree.chart.plot.Plot) piePlot13, false);
        multiplePiePlot7.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart20);
        boolean boolean22 = jFreeChart6.equals((java.lang.Object) jFreeChart20);
        org.jfree.chart.event.ChartProgressListener chartProgressListener23 = null;
        jFreeChart20.removeProgressListener(chartProgressListener23);
        try {
            org.jfree.chart.plot.CategoryPlot categoryPlot25 = jFreeChart20.getCategoryPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.PiePlot cannot be cast to org.jfree.chart.plot.CategoryPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(tableOrder8);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        java.lang.String str1 = basicProjectInfo0.getCopyright();
        org.jfree.chart.ui.Library[] libraryArray2 = basicProjectInfo0.getLibraries();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo3 = new org.jfree.chart.ui.BasicProjectInfo();
        java.lang.String str4 = basicProjectInfo3.getName();
        basicProjectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo3);
        basicProjectInfo3.setVersion("1.2.0-pre");
        org.jfree.chart.ui.Library[] libraryArray8 = basicProjectInfo3.getOptionalLibraries();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(libraryArray2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(libraryArray8);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha((float) 0);
        java.awt.Stroke stroke4 = piePlot1.getBaseSectionOutlineStroke();
        piePlot1.setLabelLinkMargin((double) (-256));
        piePlot1.setSectionOutlinesVisible(false);
        org.jfree.data.general.DatasetGroup datasetGroup9 = piePlot1.getDatasetGroup();
        double double10 = piePlot1.getLabelLinkMargin();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(datasetGroup9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-256.0d) + "'", double10 == (-256.0d));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("hi!", "RectangleEdge.TOP", "", "hi!");
        java.lang.String str5 = library4.getName();
        java.lang.String str6 = library4.getInfo();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        java.lang.String str1 = basicProjectInfo0.getName();
        org.jfree.chart.ui.Library[] libraryArray2 = basicProjectInfo0.getOptionalLibraries();
        basicProjectInfo0.setLicenceName("");
        basicProjectInfo0.setInfo("{0}");
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(libraryArray2);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        piePlot1.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        piePlot1.setDataset(pieDataset8);
        org.jfree.data.general.PieDataset pieDataset10 = piePlot1.getDataset();
        java.lang.String str11 = piePlot1.getNoDataMessage();
        java.awt.Paint paint12 = piePlot1.getLabelPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator13 = piePlot1.getLegendLabelGenerator();
        org.junit.Assert.assertNull(pieDataset10);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator13);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha((float) 0);
        boolean boolean4 = piePlot1.getIgnoreZeroValues();
        double double5 = piePlot1.getShadowXOffset();
        java.awt.Stroke stroke6 = piePlot1.getLabelLinkStroke();
        java.awt.Paint paint7 = piePlot1.getBaseSectionPaint();
        java.awt.Paint paint8 = piePlot1.getLabelPaint();
        org.jfree.data.general.PieDataset pieDataset9 = null;
        piePlot1.setDataset(pieDataset9);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("{0}", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        try {
            java.lang.Comparable comparable3 = defaultKeyedValues2D1.getColumnKey(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj1 = null;
        int int2 = objectList0.indexOf(obj1);
        java.lang.Object obj3 = null;
        int int4 = objectList0.indexOf(obj3);
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        piePlot6.setForegroundAlpha(0.0f);
        piePlot6.setStartAngle((double) 100L);
        piePlot6.setForegroundAlpha((float) (short) 100);
        double double13 = piePlot6.getShadowYOffset();
        java.awt.Stroke stroke14 = piePlot6.getBaseSectionOutlineStroke();
        boolean boolean15 = objectList0.equals((java.lang.Object) stroke14);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 4.0d + "'", double13 == 4.0d);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        boolean boolean2 = textTitle0.equals((java.lang.Object) color1);
        java.awt.Paint paint3 = textTitle0.getBackgroundPaint();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(paint3);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        piePlot2.setForegroundAlpha(0.0f);
        piePlot2.setStartAngle((double) 100L);
        piePlot2.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset9 = null;
        piePlot2.setDataset(pieDataset9);
        piePlot2.setMaximumLabelWidth((double) (byte) 100);
        java.awt.Stroke stroke14 = piePlot2.getSectionOutlineStroke((java.lang.Comparable) (short) 0);
        org.jfree.data.general.PieDataset pieDataset15 = null;
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot(pieDataset15);
        piePlot16.setForegroundAlpha((float) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean25 = rectangleInsets23.equals((java.lang.Object) rectangleAnchor24);
        double double27 = rectangleInsets23.calculateBottomInset((double) (-1L));
        piePlot16.setSimpleLabelOffset(rectangleInsets23);
        piePlot2.setInsets(rectangleInsets23);
        java.awt.Color color30 = java.awt.Color.BLUE;
        piePlot2.setLabelLinkPaint((java.awt.Paint) color30);
        java.awt.Font font32 = piePlot2.getLabelFont();
        org.jfree.chart.plot.Plot plot33 = null;
        try {
            org.jfree.chart.JFreeChart jFreeChart35 = new org.jfree.chart.JFreeChart("Rotation.ANTICLOCKWISE", font32, plot33, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'plot' argument.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(stroke14);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 100.0d + "'", double27 == 100.0d);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(font32);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        piePlot1.setShadowPaint((java.awt.Paint) color4);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator6 = piePlot1.getURLGenerator();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(pieURLGenerator6);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = textTitle1.getTextAlignment();
        textTitle1.setURLText("RectangleEdge.TOP");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = textTitle1.getHorizontalAlignment();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = null;
        try {
            org.jfree.chart.util.Size2D size2D8 = textTitle1.arrange(graphics2D6, rectangleConstraint7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertNotNull(horizontalAlignment5);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        java.awt.Color color1 = java.awt.Color.GREEN;
        float[] floatArray6 = new float[] { (byte) 1, (short) 0, (short) 100, (short) -1 };
        float[] floatArray7 = color1.getComponents(floatArray6);
        boolean boolean8 = defaultKeyedValues2D0.equals((java.lang.Object) floatArray7);
        int int9 = defaultKeyedValues2D0.getColumnCount();
        int int10 = defaultKeyedValues2D0.getColumnCount();
        int int12 = defaultKeyedValues2D0.getRowIndex((java.lang.Comparable) true);
        try {
            java.lang.Number number15 = defaultKeyedValues2D0.getValue((java.lang.Comparable) "4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0", (java.lang.Comparable) 1.0d);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unrecognised columnKey: 1.0");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        piePlot1.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        piePlot1.setDataset(pieDataset8);
        piePlot1.setMaximumLabelWidth((double) (byte) 100);
        java.awt.Stroke stroke13 = piePlot1.getSectionOutlineStroke((java.lang.Comparable) (short) 0);
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        piePlot15.setForegroundAlpha((float) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor23 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean24 = rectangleInsets22.equals((java.lang.Object) rectangleAnchor23);
        double double26 = rectangleInsets22.calculateBottomInset((double) (-1L));
        piePlot15.setSimpleLabelOffset(rectangleInsets22);
        piePlot1.setInsets(rectangleInsets22);
        java.awt.Color color29 = java.awt.Color.BLUE;
        piePlot1.setLabelLinkPaint((java.awt.Paint) color29);
        java.awt.Font font31 = piePlot1.getLabelFont();
        piePlot1.setLabelLinksVisible(true);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier34 = piePlot1.getDrawingSupplier();
        java.awt.Graphics2D graphics2D35 = null;
        org.jfree.chart.title.TextTitle textTitle37 = new org.jfree.chart.title.TextTitle("");
        java.awt.Color color38 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        textTitle37.setBackgroundPaint((java.awt.Paint) color38);
        textTitle37.setURLText("Rotation.ANTICLOCKWISE");
        java.awt.Graphics2D graphics2D42 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement43 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer44 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement43);
        java.awt.Graphics2D graphics2D45 = null;
        org.jfree.chart.util.Size2D size2D46 = blockContainer44.arrange(graphics2D45);
        blockContainer44.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D52 = blockContainer44.getBounds();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor53 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Point2D point2D54 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D52, rectangleAnchor53);
        org.jfree.data.general.PieDataset pieDataset55 = null;
        org.jfree.chart.plot.PiePlot piePlot56 = new org.jfree.chart.plot.PiePlot(pieDataset55);
        piePlot56.setForegroundAlpha(0.0f);
        piePlot56.setLabelLinkMargin(4.0d);
        java.awt.Paint paint61 = piePlot56.getShadowPaint();
        java.lang.Object obj62 = textTitle37.draw(graphics2D42, rectangle2D52, (java.lang.Object) piePlot56);
        piePlot1.drawBackgroundImage(graphics2D35, rectangle2D52);
        org.junit.Assert.assertNull(stroke13);
        org.junit.Assert.assertNotNull(rectangleAnchor23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 100.0d + "'", double26 == 100.0d);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(drawingSupplier34);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(size2D46);
        org.junit.Assert.assertNotNull(rectangle2D52);
        org.junit.Assert.assertNotNull(rectangleAnchor53);
        org.junit.Assert.assertNotNull(point2D54);
        org.junit.Assert.assertNotNull(paint61);
        org.junit.Assert.assertNull(obj62);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        java.lang.Object obj2 = defaultKeyedValues2D1.clone();
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        piePlot1.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        piePlot1.setDataset(pieDataset8);
        piePlot1.setMaximumLabelWidth((double) (byte) 100);
        java.awt.Stroke stroke13 = piePlot1.getSectionOutlineStroke((java.lang.Comparable) (short) 0);
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        piePlot15.setForegroundAlpha((float) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor23 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean24 = rectangleInsets22.equals((java.lang.Object) rectangleAnchor23);
        double double26 = rectangleInsets22.calculateBottomInset((double) (-1L));
        piePlot15.setSimpleLabelOffset(rectangleInsets22);
        piePlot1.setInsets(rectangleInsets22);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = piePlot1.getSimpleLabelOffset();
        piePlot1.setIgnoreZeroValues(false);
        piePlot1.setIgnoreNullValues(true);
        java.awt.Paint paint34 = piePlot1.getBaseSectionPaint();
        org.junit.Assert.assertNull(stroke13);
        org.junit.Assert.assertNotNull(rectangleAnchor23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 100.0d + "'", double26 == 100.0d);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(paint34);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        java.awt.Color color2 = java.awt.Color.getColor("RectangleEdge.TOP", (int) (short) 1);
        org.jfree.chart.ChartColor chartColor6 = new org.jfree.chart.ChartColor(15, 192, (int) (short) 10);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.awt.Color color8 = java.awt.Color.GREEN;
        boolean boolean9 = chartChangeEventType7.equals((java.lang.Object) color8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        int int11 = color10.getTransparency();
        java.awt.Color color12 = java.awt.Color.BLACK;
        java.awt.Color color13 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        java.awt.Paint[] paintArray14 = new java.awt.Paint[] { color2, chartColor6, color8, color10, color12, color13 };
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType15 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.awt.Color color16 = java.awt.Color.GREEN;
        boolean boolean17 = chartChangeEventType15.equals((java.lang.Object) color16);
        java.awt.Paint paint22 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder23 = new org.jfree.chart.block.BlockBorder((double) 10, (double) '#', (double) 0L, 0.0d, paint22);
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.Paint[] paintArray25 = new java.awt.Paint[] { color16, paint22, color24 };
        java.awt.Paint[] paintArray26 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray27 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray28 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray29 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier30 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray14, paintArray25, paintArray26, strokeArray27, strokeArray28, shapeArray29);
        java.awt.Stroke stroke31 = defaultDrawingSupplier30.getNextOutlineStroke();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(chartChangeEventType7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(paintArray14);
        org.junit.Assert.assertNotNull(chartChangeEventType15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(paintArray25);
        org.junit.Assert.assertNotNull(paintArray26);
        org.junit.Assert.assertNotNull(strokeArray27);
        org.junit.Assert.assertNotNull(strokeArray28);
        org.junit.Assert.assertNotNull(shapeArray29);
        org.junit.Assert.assertNotNull(stroke31);
    }

//    @Test
//    public void test382() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test382");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        java.lang.String str1 = projectInfo0.toString();
//        projectInfo0.setVersion("RectangleEdge.TOP");
//        org.jfree.chart.ui.ProjectInfo projectInfo4 = org.jfree.chart.JFreeChart.INFO;
//        java.lang.String str5 = projectInfo4.toString();
//        projectInfo4.setVersion("RectangleEdge.TOP");
//        java.awt.Image image8 = projectInfo4.getLogo();
//        projectInfo0.setLogo(image8);
//        java.util.List list10 = null;
//        projectInfo0.setContributors(list10);
//        java.util.List list12 = null;
//        projectInfo0.setContributors(list12);
//        org.jfree.data.general.PieDataset pieDataset14 = null;
//        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
//        piePlot15.setForegroundAlpha((float) 0);
//        boolean boolean18 = piePlot15.getIgnoreZeroValues();
//        double double19 = piePlot15.getShadowXOffset();
//        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot15);
//        java.util.List list21 = jFreeChart20.getSubtitles();
//        projectInfo0.setContributors(list21);
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JFreeChart version RectangleEdge.TOP.\nMultiple Pie Plot.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nTableOrder.BY_ROW" + "'", str1.equals("JFreeChart version RectangleEdge.TOP.\nMultiple Pie Plot.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nTableOrder.BY_ROW"));
//        org.junit.Assert.assertNotNull(projectInfo4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "JFreeChart version RectangleEdge.TOP.\nMultiple Pie Plot.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nTableOrder.BY_ROW" + "'", str5.equals("JFreeChart version RectangleEdge.TOP.\nMultiple Pie Plot.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nTableOrder.BY_ROW"));
//        org.junit.Assert.assertNotNull(image8);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 4.0d + "'", double19 == 4.0d);
//        org.junit.Assert.assertNotNull(list21);
//    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        java.awt.Color color3 = java.awt.Color.getHSBColor(0.0f, 0.0f, (float) 192);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj1 = textTitle0.clone();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        java.lang.String str3 = rectangleEdge2.toString();
        textTitle0.setPosition(rectangleEdge2);
        java.lang.String str5 = rectangleEdge2.toString();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleEdge.TOP" + "'", str3.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "RectangleEdge.TOP" + "'", str5.equals("RectangleEdge.TOP"));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("JFreeChart version RectangleAnchor.BOTTOM_LEFT.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nTableOrder.BY_ROW", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 0, (int) (byte) 100, (java.lang.Comparable) 1L, "RectangleEdge.TOP", "RectangleEdge.TOP");
        pieSectionEntity7.setSectionKey((java.lang.Comparable) true);
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment12 = textTitle11.getTextAlignment();
        textTitle11.setURLText("RectangleEdge.TOP");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = textTitle11.getHorizontalAlignment();
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement19 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer20 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement19);
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.util.Size2D size2D22 = blockContainer20.arrange(graphics2D21);
        blockContainer20.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D28 = blockContainer20.getBounds();
        java.lang.Object obj30 = textTitle17.draw(graphics2D18, rectangle2D28, (java.lang.Object) (short) 0);
        org.jfree.chart.title.TextTitle textTitle32 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment33 = textTitle32.getTextAlignment();
        java.lang.String str34 = horizontalAlignment33.toString();
        textTitle17.setHorizontalAlignment(horizontalAlignment33);
        org.jfree.chart.title.TextTitle textTitle36 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font37 = textTitle36.getFont();
        org.jfree.chart.util.VerticalAlignment verticalAlignment38 = textTitle36.getVerticalAlignment();
        textTitle17.setVerticalAlignment(verticalAlignment38);
        org.jfree.chart.block.ColumnArrangement columnArrangement42 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment15, verticalAlignment38, 0.0d, (double) (-1.0f));
        boolean boolean43 = pieSectionEntity7.equals((java.lang.Object) verticalAlignment38);
        java.lang.String str44 = pieSectionEntity7.toString();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(horizontalAlignment12);
        org.junit.Assert.assertNotNull(horizontalAlignment15);
        org.junit.Assert.assertNotNull(size2D22);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertNull(obj30);
        org.junit.Assert.assertNotNull(horizontalAlignment33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "HorizontalAlignment.CENTER" + "'", str34.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNotNull(verticalAlignment38);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "PieSection: 0, 100(true)" + "'", str44.equals("PieSection: 0, 100(true)"));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font1 = textTitle0.getFont();
        java.lang.Object obj2 = textTitle0.clone();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        try {
            java.lang.String[] strArray2 = jFreeChartResources0.getStringArray("");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key ");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        piePlot1.setForegroundAlpha((float) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement8 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.Block block9 = null;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        flowArrangement8.add(block9, (java.lang.Object) stroke10);
        piePlot1.setOutlineStroke(stroke10);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        piePlot1.setDataset(pieDataset13);
        piePlot1.setBackgroundImageAlignment((int) (byte) 1);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = null;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        piePlot2.setForegroundAlpha((float) 0);
        boolean boolean5 = piePlot2.getIgnoreZeroValues();
        double double6 = piePlot2.getShadowXOffset();
        java.awt.Stroke stroke7 = piePlot2.getLabelLinkStroke();
        java.awt.Paint paint8 = piePlot2.getBaseSectionPaint();
        org.jfree.chart.util.Rotation rotation9 = piePlot2.getDirection();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean16 = rectangleInsets14.equals((java.lang.Object) rectangleAnchor15);
        double double18 = rectangleInsets14.calculateTopInset(0.0d);
        boolean boolean19 = piePlot2.equals((java.lang.Object) double18);
        java.awt.Paint paint20 = piePlot2.getLabelShadowPaint();
        try {
            org.jfree.chart.block.BlockBorder blockBorder21 = new org.jfree.chart.block.BlockBorder(rectangleInsets0, paint20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(rotation9);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + (-1.0d) + "'", double18 == (-1.0d));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        java.awt.Color color1 = java.awt.Color.GREEN;
        float[] floatArray6 = new float[] { (byte) 1, (short) 0, (short) 100, (short) -1 };
        float[] floatArray7 = color1.getComponents(floatArray6);
        boolean boolean8 = defaultKeyedValues2D0.equals((java.lang.Object) floatArray7);
        defaultKeyedValues2D0.clear();
        java.awt.Paint paint10 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        boolean boolean11 = defaultKeyedValues2D0.equals((java.lang.Object) paint10);
        defaultKeyedValues2D0.addValue((java.lang.Number) 2.0d, (java.lang.Comparable) 35.0d, (java.lang.Comparable) "RectangleAnchor.CENTER");
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("JFreeChart version RectangleEdge.TOP.\nMultiple Pie Plot.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nTableOrder.BY_ROW", "1.2.0-pre", "hi!", "JFreeChart version RectangleEdge.TOP.\n1.2.0-pre.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nPieSection: 0, 100(1)", "JFreeChart version RectangleEdge.TOP.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nTableOrder.BY_ROW");
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setForegroundAlpha((float) 0);
        java.awt.Stroke stroke6 = piePlot3.getBaseSectionOutlineStroke();
        piePlot3.setLabelLinkMargin((double) (-256));
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("PieSection: 0, 100(1)", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
        jFreeChart10.setBorderVisible(false);
        boolean boolean13 = jFreeChart10.isBorderVisible();
        jFreeChart10.setBackgroundImageAlpha(0.0f);
        jFreeChart10.setAntiAlias(false);
        java.lang.Object obj18 = jFreeChart10.getTextAntiAlias();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(obj18);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        float float6 = piePlot1.getBackgroundAlpha();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        java.awt.Color color8 = color7.brighter();
        java.awt.Color color9 = color7.darker();
        piePlot1.setBaseSectionPaint((java.awt.Paint) color9);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement3 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer4 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.util.Size2D size2D6 = blockContainer4.arrange(graphics2D5);
        blockContainer4.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D12 = blockContainer4.getBounds();
        java.lang.Object obj14 = textTitle1.draw(graphics2D2, rectangle2D12, (java.lang.Object) (short) 0);
        boolean boolean15 = textTitle1.getExpandToFitSpace();
        java.lang.String str16 = textTitle1.getToolTipText();
        textTitle1.setExpandToFitSpace(false);
        org.junit.Assert.assertNotNull(size2D6);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertNull(obj14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(str16);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.util.TableOrder tableOrder2 = org.jfree.chart.util.TableOrder.BY_COLUMN;
        multiplePiePlot1.setDataExtractOrder(tableOrder2);
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.chart.plot.Plot) multiplePiePlot1);
        org.jfree.chart.title.LegendTitle legendTitle6 = jFreeChart4.getLegend((int) '4');
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement13 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer14 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.util.Size2D size2D16 = blockContainer14.arrange(graphics2D15);
        blockContainer14.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D22 = blockContainer14.getBounds();
        java.lang.Object obj24 = textTitle11.draw(graphics2D12, rectangle2D22, (java.lang.Object) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor25 = null;
        java.awt.geom.Point2D point2D26 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D22, rectangleAnchor25);
        textTitle9.setBounds(rectangle2D22);
        java.awt.geom.Rectangle2D rectangle2D30 = rectangleInsets8.createOutsetRectangle(rectangle2D22, false, true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo31 = null;
        try {
            jFreeChart4.draw(graphics2D7, rectangle2D22, chartRenderingInfo31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(tableOrder2);
        org.junit.Assert.assertNull(legendTitle6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(size2D16);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertNull(obj24);
        org.junit.Assert.assertNotNull(point2D26);
        org.junit.Assert.assertNotNull(rectangle2D30);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        java.awt.Paint paint0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        piePlot1.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        piePlot1.setDataset(pieDataset8);
        org.jfree.data.general.PieDataset pieDataset10 = piePlot1.getDataset();
        piePlot1.setOutlineVisible(false);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset13 = new org.jfree.data.category.DefaultCategoryDataset();
        java.util.List list14 = defaultCategoryDataset13.getColumnKeys();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent15 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) piePlot1, (org.jfree.data.general.Dataset) defaultCategoryDataset13);
        defaultCategoryDataset13.clear();
        org.jfree.data.general.PieDataset pieDataset17 = null;
        org.jfree.chart.plot.PiePlot piePlot18 = new org.jfree.chart.plot.PiePlot(pieDataset17);
        piePlot18.setForegroundAlpha(0.0f);
        piePlot18.setStartAngle((double) 100L);
        piePlot18.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset25 = null;
        piePlot18.setDataset(pieDataset25);
        org.jfree.data.general.PieDataset pieDataset27 = piePlot18.getDataset();
        piePlot18.setOutlineVisible(false);
        defaultCategoryDataset13.removeChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot18);
        org.junit.Assert.assertNull(pieDataset10);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNull(pieDataset27);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        java.lang.String str1 = basicProjectInfo0.getCopyright();
        org.jfree.chart.ui.Library[] libraryArray2 = basicProjectInfo0.getLibraries();
        basicProjectInfo0.setVersion("");
        java.lang.String str5 = basicProjectInfo0.getLicenceName();
        basicProjectInfo0.setLicenceName("JFreeChart version RectangleEdge.TOP.\n1.2.0-pre.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nPieSection: 0, 100(1)");
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(libraryArray2);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha((float) 0);
        boolean boolean4 = piePlot1.getIgnoreZeroValues();
        double double5 = piePlot1.getShadowXOffset();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo9 = null;
        java.awt.image.BufferedImage bufferedImage10 = jFreeChart6.createBufferedImage((int) 'a', (int) (byte) 100, chartRenderingInfo9);
        java.awt.Paint paint11 = jFreeChart6.getBackgroundPaint();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = null;
        try {
            java.awt.image.BufferedImage bufferedImage16 = jFreeChart6.createBufferedImage((int) (byte) 0, (-1), 1, chartRenderingInfo15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (0) and height (-1) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(bufferedImage10);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        java.awt.Color color1 = java.awt.Color.GREEN;
        float[] floatArray6 = new float[] { (byte) 1, (short) 0, (short) 100, (short) -1 };
        float[] floatArray7 = color1.getComponents(floatArray6);
        boolean boolean8 = defaultKeyedValues2D0.equals((java.lang.Object) floatArray7);
        java.lang.Object obj9 = defaultKeyedValues2D0.clone();
        int int10 = defaultKeyedValues2D0.getRowCount();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha((float) 0);
        boolean boolean4 = piePlot1.getIgnoreZeroValues();
        double double5 = piePlot1.getShadowXOffset();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        java.util.List list7 = jFreeChart6.getSubtitles();
        org.jfree.chart.plot.Plot plot8 = jFreeChart6.getPlot();
        java.lang.Object obj9 = jFreeChart6.clone();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertNotNull(plot8);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = textTitle1.getTextAlignment();
        java.lang.String str3 = horizontalAlignment2.toString();
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font5 = textTitle4.getFont();
        org.jfree.chart.util.VerticalAlignment verticalAlignment6 = textTitle4.getVerticalAlignment();
        org.jfree.chart.block.FlowArrangement flowArrangement9 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment2, verticalAlignment6, (double) (short) 0, (double) (short) 1);
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot(pieDataset10);
        piePlot11.setForegroundAlpha(0.0f);
        piePlot11.zoom((double) '#');
        org.jfree.data.general.PieDataset pieDataset16 = null;
        org.jfree.chart.plot.PiePlot piePlot17 = new org.jfree.chart.plot.PiePlot(pieDataset16);
        piePlot17.setForegroundAlpha((float) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor25 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean26 = rectangleInsets24.equals((java.lang.Object) rectangleAnchor25);
        double double28 = rectangleInsets24.calculateBottomInset((double) (-1L));
        piePlot17.setSimpleLabelOffset(rectangleInsets24);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle30 = org.jfree.chart.plot.PieLabelLinkStyle.CUBIC_CURVE;
        piePlot17.setLabelLinkStyle(pieLabelLinkStyle30);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier32 = piePlot17.getDrawingSupplier();
        boolean boolean33 = piePlot11.equals((java.lang.Object) piePlot17);
        org.jfree.chart.LegendItemSource legendItemSource34 = null;
        org.jfree.chart.title.LegendTitle legendTitle35 = new org.jfree.chart.title.LegendTitle(legendItemSource34);
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = legendTitle35.getLegendItemGraphicPadding();
        piePlot17.setSimpleLabelOffset(rectangleInsets36);
        java.awt.Paint paint38 = piePlot17.getBaseSectionOutlinePaint();
        piePlot17.setSectionOutlinesVisible(true);
        boolean boolean41 = verticalAlignment6.equals((java.lang.Object) true);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "HorizontalAlignment.CENTER" + "'", str3.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(verticalAlignment6);
        org.junit.Assert.assertNotNull(rectangleAnchor25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 100.0d + "'", double28 == 100.0d);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle30);
        org.junit.Assert.assertNotNull(drawingSupplier32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.awt.Paint paint2 = textTitle1.getBackgroundPaint();
        java.awt.Paint paint3 = textTitle1.getBackgroundPaint();
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNull(paint3);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font1 = textTitle0.getFont();
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = textTitle0.getVerticalAlignment();
        boolean boolean3 = textTitle0.getNotify();
        textTitle0.setMargin((double) (-4325426), 0.0d, 0.0d, (double) (byte) 10);
        java.lang.String str9 = textTitle0.getURLText();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        piePlot1.setShadowPaint((java.awt.Paint) color4);
        piePlot1.setIgnoreZeroValues(true);
        java.awt.Paint paint9 = null;
        piePlot1.setSectionOutlinePaint((java.lang.Comparable) 100.0f, paint9);
        double double12 = piePlot1.getExplodePercent((java.lang.Comparable) 0.08d);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Enumeration<java.lang.String> strEnumeration1 = jFreeChartResources0.getKeys();
        java.util.Locale locale2 = jFreeChartResources0.getLocale();
        try {
            java.lang.String[] strArray4 = jFreeChartResources0.getStringArray("Other");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key Other");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNotNull(strEnumeration1);
        org.junit.Assert.assertNull(locale2);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.CENTER;
        java.awt.Shape shape1 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity8 = new org.jfree.chart.entity.PieSectionEntity(shape1, pieDataset2, 0, (int) (byte) 100, (java.lang.Comparable) 1L, "RectangleEdge.TOP", "RectangleEdge.TOP");
        pieSectionEntity8.setSectionKey((java.lang.Comparable) 0L);
        boolean boolean11 = verticalAlignment0.equals((java.lang.Object) pieSectionEntity8);
        java.awt.Shape shape12 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity19 = new org.jfree.chart.entity.PieSectionEntity(shape12, pieDataset13, 0, (int) (byte) 100, (java.lang.Comparable) 1L, "RectangleEdge.TOP", "RectangleEdge.TOP");
        pieSectionEntity19.setSectionKey((java.lang.Comparable) 0L);
        boolean boolean23 = pieSectionEntity19.equals((java.lang.Object) "hi!");
        org.jfree.chart.title.TextTitle textTitle25 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement27 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer28 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement27);
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.chart.util.Size2D size2D30 = blockContainer28.arrange(graphics2D29);
        blockContainer28.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D36 = blockContainer28.getBounds();
        java.lang.Object obj38 = textTitle25.draw(graphics2D26, rectangle2D36, (java.lang.Object) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor39 = null;
        java.awt.geom.Point2D point2D40 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D36, rectangleAnchor39);
        pieSectionEntity19.setArea((java.awt.Shape) rectangle2D36);
        pieSectionEntity8.setArea((java.awt.Shape) rectangle2D36);
        pieSectionEntity8.setSectionIndex((int) '#');
        java.awt.Shape shape45 = pieSectionEntity8.getArea();
        pieSectionEntity8.setToolTipText("JFreeChart version RectangleAnchor.BOTTOM_LEFT.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nTableOrder.BY_ROW");
        org.junit.Assert.assertNotNull(verticalAlignment0);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(size2D30);
        org.junit.Assert.assertNotNull(rectangle2D36);
        org.junit.Assert.assertNull(obj38);
        org.junit.Assert.assertNotNull(point2D40);
        org.junit.Assert.assertNotNull(shape45);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.zoom((double) '#');
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        piePlot7.setForegroundAlpha((float) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean16 = rectangleInsets14.equals((java.lang.Object) rectangleAnchor15);
        double double18 = rectangleInsets14.calculateBottomInset((double) (-1L));
        piePlot7.setSimpleLabelOffset(rectangleInsets14);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle20 = org.jfree.chart.plot.PieLabelLinkStyle.CUBIC_CURVE;
        piePlot7.setLabelLinkStyle(pieLabelLinkStyle20);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier22 = piePlot7.getDrawingSupplier();
        boolean boolean23 = piePlot1.equals((java.lang.Object) piePlot7);
        double double24 = piePlot1.getMinimumArcAngleToDraw();
        piePlot1.setBackgroundImageAlignment((int) (short) 10);
        java.awt.Shape shape27 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset28 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity34 = new org.jfree.chart.entity.PieSectionEntity(shape27, pieDataset28, 0, (int) (byte) 100, (java.lang.Comparable) 1L, "RectangleEdge.TOP", "RectangleEdge.TOP");
        org.jfree.chart.JFreeChart jFreeChart35 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent36 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0, jFreeChart35);
        org.jfree.chart.JFreeChart jFreeChart37 = chartChangeEvent36.getChart();
        org.jfree.chart.JFreeChart jFreeChart38 = null;
        chartChangeEvent36.setChart(jFreeChart38);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot41 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.util.TableOrder tableOrder42 = org.jfree.chart.util.TableOrder.BY_COLUMN;
        multiplePiePlot41.setDataExtractOrder(tableOrder42);
        org.jfree.chart.JFreeChart jFreeChart44 = new org.jfree.chart.JFreeChart("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.chart.plot.Plot) multiplePiePlot41);
        chartChangeEvent36.setChart(jFreeChart44);
        jFreeChart44.setBackgroundImageAlpha((float) 'a');
        piePlot1.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart44);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 100.0d + "'", double18 == 100.0d);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle20);
        org.junit.Assert.assertNotNull(drawingSupplier22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0E-5d + "'", double24 == 1.0E-5d);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNull(jFreeChart37);
        org.junit.Assert.assertNotNull(tableOrder42);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.lang.Object obj1 = standardPieSectionLabelGenerator0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setLabelLinkMargin(4.0d);
        piePlot1.setExplodePercent((java.lang.Comparable) 0, (double) (-262450));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        java.lang.String str3 = rectangleEdge2.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge2);
        legendTitle1.setLegendItemGraphicEdge(rectangleEdge2);
        org.jfree.chart.block.BlockFrame blockFrame6 = legendTitle1.getFrame();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = legendTitle1.getItemLabelPadding();
        double double9 = rectangleInsets7.calculateLeftInset((double) 100);
        double double11 = rectangleInsets7.trimWidth(100.0d);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleEdge.TOP" + "'", str3.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(blockFrame6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 96.0d + "'", double11 == 96.0d);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.zoom((double) '#');
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        piePlot7.setForegroundAlpha((float) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean16 = rectangleInsets14.equals((java.lang.Object) rectangleAnchor15);
        double double18 = rectangleInsets14.calculateBottomInset((double) (-1L));
        piePlot7.setSimpleLabelOffset(rectangleInsets14);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle20 = org.jfree.chart.plot.PieLabelLinkStyle.CUBIC_CURVE;
        piePlot7.setLabelLinkStyle(pieLabelLinkStyle20);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier22 = piePlot7.getDrawingSupplier();
        boolean boolean23 = piePlot1.equals((java.lang.Object) piePlot7);
        org.jfree.chart.LegendItemSource legendItemSource24 = null;
        org.jfree.chart.title.LegendTitle legendTitle25 = new org.jfree.chart.title.LegendTitle(legendItemSource24);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = legendTitle25.getLegendItemGraphicPadding();
        piePlot7.setSimpleLabelOffset(rectangleInsets26);
        double double29 = rectangleInsets26.calculateBottomInset((double) 100.0f);
        double double30 = rectangleInsets26.getBottom();
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 100.0d + "'", double18 == 100.0d);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle20);
        org.junit.Assert.assertNotNull(drawingSupplier22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 2.0d + "'", double29 == 2.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 2.0d + "'", double30 == 2.0d);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        boolean boolean2 = jFreeChartResources0.containsKey("TableOrder.BY_ROW");
        try {
            java.lang.String str4 = jFreeChartResources0.getString("Other");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key Other");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha((float) 0);
        boolean boolean4 = piePlot1.getIgnoreZeroValues();
        double double5 = piePlot1.getShadowXOffset();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot7 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.util.TableOrder tableOrder8 = org.jfree.chart.util.TableOrder.BY_COLUMN;
        multiplePiePlot7.setDataExtractOrder(tableOrder8);
        java.awt.Font font11 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        piePlot13.setForegroundAlpha((float) 0);
        java.awt.Stroke stroke16 = piePlot13.getBaseSectionOutlineStroke();
        piePlot13.setLabelLinkMargin((double) (-256));
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("PieSection: 0, 100(1)", font11, (org.jfree.chart.plot.Plot) piePlot13, false);
        multiplePiePlot7.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart20);
        boolean boolean22 = jFreeChart6.equals((java.lang.Object) jFreeChart20);
        boolean boolean23 = jFreeChart6.getAntiAlias();
        jFreeChart6.setAntiAlias(true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(tableOrder8);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        piePlot1.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        piePlot1.setDataset(pieDataset8);
        org.jfree.data.general.PieDataset pieDataset10 = piePlot1.getDataset();
        java.lang.String str11 = piePlot1.getNoDataMessage();
        java.awt.Paint paint12 = piePlot1.getLabelPaint();
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.Color color14 = java.awt.Color.gray;
        java.awt.image.ColorModel colorModel15 = null;
        java.awt.Rectangle rectangle16 = null;
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement20 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer21 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement20);
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.util.Size2D size2D23 = blockContainer21.arrange(graphics2D22);
        blockContainer21.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D29 = blockContainer21.getBounds();
        java.lang.Object obj31 = textTitle18.draw(graphics2D19, rectangle2D29, (java.lang.Object) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor32 = null;
        java.awt.geom.Point2D point2D33 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D29, rectangleAnchor32);
        java.awt.geom.AffineTransform affineTransform34 = null;
        java.awt.RenderingHints renderingHints35 = null;
        java.awt.PaintContext paintContext36 = color14.createContext(colorModel15, rectangle16, rectangle2D29, affineTransform34, renderingHints35);
        try {
            piePlot1.drawBackground(graphics2D13, rectangle2D29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(pieDataset10);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(size2D23);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertNull(obj31);
        org.junit.Assert.assertNotNull(point2D33);
        org.junit.Assert.assertNotNull(paintContext36);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        float float6 = piePlot1.getBackgroundAlpha();
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.Block block8 = null;
        java.awt.Stroke stroke9 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        flowArrangement7.add(block8, (java.lang.Object) stroke9);
        piePlot1.setOutlineStroke(stroke9);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setForegroundAlpha((float) 0);
        java.awt.Stroke stroke6 = piePlot3.getBaseSectionOutlineStroke();
        piePlot3.setLabelLinkMargin((double) (-256));
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("PieSection: 0, 100(1)", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
        jFreeChart10.setBorderVisible(false);
        boolean boolean13 = jFreeChart10.isBorderVisible();
        jFreeChart10.setBackgroundImageAlpha(0.0f);
        org.jfree.data.general.PieDataset pieDataset16 = null;
        org.jfree.chart.plot.PiePlot piePlot17 = new org.jfree.chart.plot.PiePlot(pieDataset16);
        piePlot17.setForegroundAlpha(0.0f);
        piePlot17.setStartAngle((double) 100L);
        piePlot17.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset24 = null;
        piePlot17.setDataset(pieDataset24);
        org.jfree.data.general.PieDataset pieDataset26 = piePlot17.getDataset();
        java.lang.String str27 = piePlot17.getNoDataMessage();
        piePlot17.setLabelLinkMargin((double) 0.5f);
        java.awt.Paint paint30 = piePlot17.getNoDataMessagePaint();
        java.awt.Color color31 = java.awt.Color.BLACK;
        piePlot17.setBaseSectionOutlinePaint((java.awt.Paint) color31);
        java.awt.Color color33 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.color.ColorSpace colorSpace34 = color33.getColorSpace();
        java.awt.Color color35 = java.awt.Color.GREEN;
        float[] floatArray40 = new float[] { (byte) 1, (short) 0, (short) 100, (short) -1 };
        float[] floatArray41 = color35.getComponents(floatArray40);
        float[] floatArray42 = color31.getComponents(colorSpace34, floatArray41);
        java.awt.color.ColorSpace colorSpace43 = color31.getColorSpace();
        boolean boolean44 = jFreeChart10.equals((java.lang.Object) color31);
        jFreeChart10.setBackgroundImageAlignment((-4325426));
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(pieDataset26);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(colorSpace34);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(floatArray40);
        org.junit.Assert.assertNotNull(floatArray41);
        org.junit.Assert.assertNotNull(floatArray42);
        org.junit.Assert.assertNotNull(colorSpace43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        java.awt.Color color3 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        java.awt.Color color4 = color3.brighter();
        int int5 = color4.getRed();
        java.awt.Color color6 = java.awt.Color.green;
        java.awt.Color color7 = color6.darker();
        java.awt.Color color8 = java.awt.Color.PINK;
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D9 = new org.jfree.data.DefaultKeyedValues2D();
        java.awt.Color color10 = java.awt.Color.GREEN;
        float[] floatArray15 = new float[] { (byte) 1, (short) 0, (short) 100, (short) -1 };
        float[] floatArray16 = color10.getComponents(floatArray15);
        boolean boolean17 = defaultKeyedValues2D9.equals((java.lang.Object) floatArray16);
        float[] floatArray18 = color8.getColorComponents(floatArray16);
        float[] floatArray19 = color6.getRGBColorComponents(floatArray18);
        float[] floatArray20 = color4.getRGBComponents(floatArray18);
        float[] floatArray21 = java.awt.Color.RGBtoHSB((int) (byte) -1, (-256), (int) ' ', floatArray18);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 91 + "'", int5 == 91);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font1 = textTitle0.getFont();
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = textTitle0.getVerticalAlignment();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle0);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType4 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        titleChangeEvent3.setType(chartChangeEventType4);
        java.lang.String str6 = chartChangeEventType4.toString();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertNotNull(chartChangeEventType4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str6.equals("ChartChangeEventType.DATASET_UPDATED"));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.CLOCKWISE;
        org.junit.Assert.assertNotNull(rotation0);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.CENTER;
        java.awt.Shape shape1 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity8 = new org.jfree.chart.entity.PieSectionEntity(shape1, pieDataset2, 0, (int) (byte) 100, (java.lang.Comparable) 1L, "RectangleEdge.TOP", "RectangleEdge.TOP");
        pieSectionEntity8.setSectionKey((java.lang.Comparable) 0L);
        boolean boolean11 = verticalAlignment0.equals((java.lang.Object) pieSectionEntity8);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot13 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.util.TableOrder tableOrder14 = org.jfree.chart.util.TableOrder.BY_COLUMN;
        multiplePiePlot13.setDataExtractOrder(tableOrder14);
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.chart.plot.Plot) multiplePiePlot13);
        java.awt.Color color17 = java.awt.Color.PINK;
        multiplePiePlot13.setAggregatedItemsPaint((java.awt.Paint) color17);
        boolean boolean19 = verticalAlignment0.equals((java.lang.Object) multiplePiePlot13);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        multiplePiePlot13.handleClick((int) (byte) 1, 100, plotRenderingInfo22);
        org.junit.Assert.assertNotNull(verticalAlignment0);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(tableOrder14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        java.awt.Stroke stroke6 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        piePlot1.setLabelOutlineStroke(stroke6);
        piePlot1.setMaximumLabelWidth((-1.0d));
        org.jfree.data.general.PieDataset pieDataset10 = piePlot1.getDataset();
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        piePlot12.setForegroundAlpha(0.0f);
        piePlot12.setStartAngle((double) 100L);
        piePlot12.setLabelLinkMargin(0.0d);
        boolean boolean19 = piePlot12.getIgnoreZeroValues();
        org.jfree.chart.block.BlockBorder blockBorder24 = new org.jfree.chart.block.BlockBorder(0.0d, 0.025d, (double) 100, (double) (short) 100);
        boolean boolean25 = piePlot12.equals((java.lang.Object) 0.025d);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator26 = piePlot12.getURLGenerator();
        java.awt.Paint paint27 = piePlot12.getShadowPaint();
        piePlot1.setBaseSectionPaint(paint27);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(pieDataset10);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(pieURLGenerator26);
        org.junit.Assert.assertNotNull(paint27);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Enumeration<java.lang.String> strEnumeration1 = jFreeChartResources0.getKeys();
        java.util.Locale locale2 = jFreeChartResources0.getLocale();
        java.util.Locale locale3 = jFreeChartResources0.getLocale();
        java.util.Set<java.lang.String> strSet4 = jFreeChartResources0.keySet();
        org.junit.Assert.assertNotNull(strEnumeration1);
        org.junit.Assert.assertNull(locale2);
        org.junit.Assert.assertNull(locale3);
        org.junit.Assert.assertNotNull(strSet4);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        double double6 = piePlot1.getInteriorGap();
        piePlot1.setMinimumArcAngleToDraw(0.4d);
        piePlot1.setBackgroundAlpha((float) 10L);
        java.lang.Object obj11 = piePlot1.clone();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.08d + "'", double6 == 0.08d);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        piePlot2.setForegroundAlpha(0.0f);
        piePlot2.setStartAngle((double) 100L);
        piePlot2.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset9 = null;
        piePlot2.setDataset(pieDataset9);
        piePlot2.setMaximumLabelWidth((double) (byte) 100);
        java.awt.Stroke stroke14 = piePlot2.getSectionOutlineStroke((java.lang.Comparable) (short) 0);
        org.jfree.data.general.PieDataset pieDataset15 = null;
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot(pieDataset15);
        piePlot16.setForegroundAlpha((float) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean25 = rectangleInsets23.equals((java.lang.Object) rectangleAnchor24);
        double double27 = rectangleInsets23.calculateBottomInset((double) (-1L));
        piePlot16.setSimpleLabelOffset(rectangleInsets23);
        piePlot2.setInsets(rectangleInsets23);
        java.awt.Color color30 = java.awt.Color.BLUE;
        piePlot2.setLabelLinkPaint((java.awt.Paint) color30);
        java.awt.Font font32 = piePlot2.getLabelFont();
        org.jfree.data.general.PieDataset pieDataset33 = null;
        org.jfree.chart.plot.PiePlot piePlot34 = new org.jfree.chart.plot.PiePlot(pieDataset33);
        piePlot34.setForegroundAlpha(0.0f);
        piePlot34.setStartAngle((double) 100L);
        double double39 = piePlot34.getInteriorGap();
        java.awt.Paint paint40 = piePlot34.getLabelOutlinePaint();
        java.awt.Color color43 = java.awt.Color.getColor("RectangleEdge.TOP", (int) (short) 1);
        org.jfree.chart.ChartColor chartColor47 = new org.jfree.chart.ChartColor(15, 192, (int) (short) 10);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType48 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.awt.Color color49 = java.awt.Color.GREEN;
        boolean boolean50 = chartChangeEventType48.equals((java.lang.Object) color49);
        java.awt.Color color51 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        int int52 = color51.getTransparency();
        java.awt.Color color53 = java.awt.Color.BLACK;
        java.awt.Color color54 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        java.awt.Paint[] paintArray55 = new java.awt.Paint[] { color43, chartColor47, color49, color51, color53, color54 };
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType56 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.awt.Color color57 = java.awt.Color.GREEN;
        boolean boolean58 = chartChangeEventType56.equals((java.lang.Object) color57);
        java.awt.Paint paint63 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder64 = new org.jfree.chart.block.BlockBorder((double) 10, (double) '#', (double) 0L, 0.0d, paint63);
        java.awt.Color color65 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.Paint[] paintArray66 = new java.awt.Paint[] { color57, paint63, color65 };
        java.awt.Paint[] paintArray67 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray68 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray69 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray70 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier71 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray55, paintArray66, paintArray67, strokeArray68, strokeArray69, shapeArray70);
        piePlot34.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier71);
        java.awt.Paint paint73 = defaultDrawingSupplier71.getNextFillPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge74 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment75 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        java.lang.String str76 = horizontalAlignment75.toString();
        org.jfree.chart.title.TextTitle textTitle77 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font78 = textTitle77.getFont();
        org.jfree.chart.util.VerticalAlignment verticalAlignment79 = textTitle77.getVerticalAlignment();
        java.lang.String str80 = verticalAlignment79.toString();
        org.jfree.chart.block.ColumnArrangement columnArrangement81 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer82 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement81);
        java.awt.Graphics2D graphics2D83 = null;
        org.jfree.chart.util.Size2D size2D84 = blockContainer82.arrange(graphics2D83);
        blockContainer82.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D90 = blockContainer82.getBounds();
        boolean boolean91 = blockContainer82.isEmpty();
        org.jfree.chart.util.RectangleInsets rectangleInsets92 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double94 = rectangleInsets92.calculateTopOutset((double) 0);
        java.lang.String str95 = rectangleInsets92.toString();
        blockContainer82.setPadding(rectangleInsets92);
        org.jfree.chart.title.TextTitle textTitle97 = new org.jfree.chart.title.TextTitle("1.2.0-pre", font32, paint73, rectangleEdge74, horizontalAlignment75, verticalAlignment79, rectangleInsets92);
        org.junit.Assert.assertNull(stroke14);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 100.0d + "'", double27 == 100.0d);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.08d + "'", double39 == 0.08d);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(chartChangeEventType48);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertNotNull(paintArray55);
        org.junit.Assert.assertNotNull(chartChangeEventType56);
        org.junit.Assert.assertNotNull(color57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(paint63);
        org.junit.Assert.assertNotNull(color65);
        org.junit.Assert.assertNotNull(paintArray66);
        org.junit.Assert.assertNotNull(paintArray67);
        org.junit.Assert.assertNotNull(strokeArray68);
        org.junit.Assert.assertNotNull(strokeArray69);
        org.junit.Assert.assertNotNull(shapeArray70);
        org.junit.Assert.assertNotNull(paint73);
        org.junit.Assert.assertNotNull(rectangleEdge74);
        org.junit.Assert.assertNotNull(horizontalAlignment75);
        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "HorizontalAlignment.LEFT" + "'", str76.equals("HorizontalAlignment.LEFT"));
        org.junit.Assert.assertNotNull(font78);
        org.junit.Assert.assertNotNull(verticalAlignment79);
        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "VerticalAlignment.CENTER" + "'", str80.equals("VerticalAlignment.CENTER"));
        org.junit.Assert.assertNotNull(size2D84);
        org.junit.Assert.assertNotNull(rectangle2D90);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + true + "'", boolean91 == true);
        org.junit.Assert.assertNotNull(rectangleInsets92);
        org.junit.Assert.assertTrue("'" + double94 + "' != '" + 4.0d + "'", double94 == 4.0d);
        org.junit.Assert.assertTrue("'" + str95 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]" + "'", str95.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha((float) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean10 = rectangleInsets8.equals((java.lang.Object) rectangleAnchor9);
        double double12 = rectangleInsets8.calculateBottomInset((double) (-1L));
        piePlot1.setSimpleLabelOffset(rectangleInsets8);
        java.awt.Paint paint14 = piePlot1.getLabelOutlinePaint();
        org.jfree.data.general.DatasetGroup datasetGroup15 = piePlot1.getDatasetGroup();
        piePlot1.setCircular(false, false);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 100.0d + "'", double12 == 100.0d);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(datasetGroup15);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font1 = textTitle0.getFont();
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = textTitle0.getVerticalAlignment();
        boolean boolean3 = textTitle0.getNotify();
        textTitle0.setMargin((double) (-4325426), 0.0d, 0.0d, (double) (byte) 10);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        double double14 = rectangleInsets13.getBottom();
        double double16 = rectangleInsets13.calculateTopOutset((double) (-1));
        textTitle0.setPadding(rectangleInsets13);
        org.jfree.chart.event.TitleChangeListener titleChangeListener18 = null;
        textTitle0.removeChangeListener(titleChangeListener18);
        java.awt.Graphics2D graphics2D20 = null;
        java.awt.Shape shape21 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset22 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity28 = new org.jfree.chart.entity.PieSectionEntity(shape21, pieDataset22, 0, (int) (byte) 100, (java.lang.Comparable) 1L, "RectangleEdge.TOP", "RectangleEdge.TOP");
        pieSectionEntity28.setSectionKey((java.lang.Comparable) 0L);
        boolean boolean32 = pieSectionEntity28.equals((java.lang.Object) "hi!");
        org.jfree.chart.title.TextTitle textTitle34 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D35 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement36 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer37 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement36);
        java.awt.Graphics2D graphics2D38 = null;
        org.jfree.chart.util.Size2D size2D39 = blockContainer37.arrange(graphics2D38);
        blockContainer37.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D45 = blockContainer37.getBounds();
        java.lang.Object obj47 = textTitle34.draw(graphics2D35, rectangle2D45, (java.lang.Object) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor48 = null;
        java.awt.geom.Point2D point2D49 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D45, rectangleAnchor48);
        pieSectionEntity28.setArea((java.awt.Shape) rectangle2D45);
        org.jfree.chart.util.RectangleEdge rectangleEdge51 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        double double52 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D45, rectangleEdge51);
        org.jfree.chart.util.RectangleEdge rectangleEdge53 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        boolean boolean54 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge53);
        double double55 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D45, rectangleEdge53);
        java.awt.Color color56 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.lang.Object obj57 = textTitle0.draw(graphics2D20, rectangle2D45, (java.lang.Object) color56);
        textTitle0.setText("JFreeChart version RectangleEdge.TOP.\n1.2.0-pre.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nPieSection: 0, 100(1)");
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 100.0d + "'", double14 == 100.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-1.0d) + "'", double16 == (-1.0d));
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(size2D39);
        org.junit.Assert.assertNotNull(rectangle2D45);
        org.junit.Assert.assertNull(obj47);
        org.junit.Assert.assertNotNull(point2D49);
        org.junit.Assert.assertNotNull(rectangleEdge51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertNull(obj57);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) (byte) 10, (int) (short) -1, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Green");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.util.TableOrder tableOrder1 = org.jfree.chart.util.TableOrder.BY_COLUMN;
        multiplePiePlot0.setDataExtractOrder(tableOrder1);
        multiplePiePlot0.setAggregatedItemsKey((java.lang.Comparable) (-1));
        org.jfree.data.category.CategoryDataset categoryDataset5 = multiplePiePlot0.getDataset();
        double double6 = multiplePiePlot0.getLimit();
        org.jfree.chart.JFreeChart jFreeChart7 = multiplePiePlot0.getPieChart();
        org.junit.Assert.assertNotNull(tableOrder1);
        org.junit.Assert.assertNull(categoryDataset5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(jFreeChart7);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 0L, (double) (byte) 100, (double) (short) 1, (double) (byte) 100);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.util.TableOrder tableOrder1 = org.jfree.chart.util.TableOrder.BY_COLUMN;
        multiplePiePlot0.setDataExtractOrder(tableOrder1);
        multiplePiePlot0.setAggregatedItemsKey((java.lang.Comparable) (-1));
        org.jfree.data.category.CategoryDataset categoryDataset5 = multiplePiePlot0.getDataset();
        java.lang.Object obj6 = multiplePiePlot0.clone();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = multiplePiePlot0.getLegendItems();
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font9 = textTitle8.getFont();
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = textTitle8.getVerticalAlignment();
        boolean boolean11 = textTitle8.getNotify();
        textTitle8.setMargin((double) (-4325426), 0.0d, 0.0d, (double) (byte) 10);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        double double22 = rectangleInsets21.getBottom();
        double double24 = rectangleInsets21.calculateTopOutset((double) (-1));
        textTitle8.setPadding(rectangleInsets21);
        double double27 = rectangleInsets21.calculateBottomInset((double) 0.0f);
        boolean boolean28 = multiplePiePlot0.equals((java.lang.Object) double27);
        org.junit.Assert.assertNotNull(tableOrder1);
        org.junit.Assert.assertNull(categoryDataset5);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(verticalAlignment10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 100.0d + "'", double22 == 100.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + (-1.0d) + "'", double24 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 100.0d + "'", double27 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.lang.Object obj2 = defaultKeyedValues2D1.clone();
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        piePlot1.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        piePlot1.setDataset(pieDataset8);
        piePlot1.setMaximumLabelWidth((double) (byte) 100);
        org.jfree.chart.LegendItemCollection legendItemCollection12 = piePlot1.getLegendItems();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator13 = piePlot1.getLegendLabelGenerator();
        org.junit.Assert.assertNotNull(legendItemCollection12);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator13);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha((float) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean10 = rectangleInsets8.equals((java.lang.Object) rectangleAnchor9);
        double double12 = rectangleInsets8.calculateBottomInset((double) (-1L));
        piePlot1.setSimpleLabelOffset(rectangleInsets8);
        java.awt.Color color14 = java.awt.Color.DARK_GRAY;
        piePlot1.setBackgroundPaint((java.awt.Paint) color14);
        org.jfree.data.general.PieDataset pieDataset16 = null;
        org.jfree.chart.plot.PiePlot piePlot17 = new org.jfree.chart.plot.PiePlot(pieDataset16);
        piePlot17.setForegroundAlpha(0.0f);
        piePlot17.setStartAngle((double) 100L);
        piePlot17.setLabelLinkMargin(0.0d);
        boolean boolean24 = piePlot17.getIgnoreZeroValues();
        org.jfree.chart.plot.Plot plot25 = piePlot17.getParent();
        java.awt.Paint paint26 = piePlot17.getBaseSectionOutlinePaint();
        piePlot1.setShadowPaint(paint26);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 100.0d + "'", double12 == 100.0d);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(plot25);
        org.junit.Assert.assertNotNull(paint26);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        float float6 = piePlot1.getBackgroundAlpha();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator7 = null;
        piePlot1.setLegendLabelURLGenerator(pieURLGenerator7);
        org.jfree.chart.LegendItemCollection legendItemCollection9 = piePlot1.getLegendItems();
        double double11 = piePlot1.getExplodePercent((java.lang.Comparable) 0.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
        org.junit.Assert.assertNotNull(legendItemCollection9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.util.TableOrder tableOrder1 = org.jfree.chart.util.TableOrder.BY_COLUMN;
        multiplePiePlot0.setDataExtractOrder(tableOrder1);
        java.awt.Font font4 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        piePlot6.setForegroundAlpha((float) 0);
        java.awt.Stroke stroke9 = piePlot6.getBaseSectionOutlineStroke();
        piePlot6.setLabelLinkMargin((double) (-256));
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("PieSection: 0, 100(1)", font4, (org.jfree.chart.plot.Plot) piePlot6, false);
        multiplePiePlot0.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart13);
        int int15 = jFreeChart13.getSubtitleCount();
        org.junit.Assert.assertNotNull(tableOrder1);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        piePlot1.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        piePlot1.setDataset(pieDataset8);
        org.jfree.data.general.PieDataset pieDataset10 = piePlot1.getDataset();
        java.lang.String str11 = piePlot1.getNoDataMessage();
        piePlot1.setLabelLinkMargin((double) 0.5f);
        java.awt.Paint paint14 = piePlot1.getNoDataMessagePaint();
        java.awt.Color color15 = java.awt.Color.BLACK;
        piePlot1.setBaseSectionOutlinePaint((java.awt.Paint) color15);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.color.ColorSpace colorSpace18 = color17.getColorSpace();
        java.awt.Color color19 = java.awt.Color.GREEN;
        float[] floatArray24 = new float[] { (byte) 1, (short) 0, (short) 100, (short) -1 };
        float[] floatArray25 = color19.getComponents(floatArray24);
        float[] floatArray26 = color15.getComponents(colorSpace18, floatArray25);
        java.awt.color.ColorSpace colorSpace27 = color15.getColorSpace();
        int int28 = color15.getTransparency();
        org.junit.Assert.assertNull(pieDataset10);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(colorSpace18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(floatArray26);
        org.junit.Assert.assertNotNull(colorSpace27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        textTitle1.setBackgroundPaint((java.awt.Paint) color2);
        textTitle1.setURLText("Rotation.ANTICLOCKWISE");
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement7 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer8 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement7);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.util.Size2D size2D10 = blockContainer8.arrange(graphics2D9);
        blockContainer8.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D16 = blockContainer8.getBounds();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        org.jfree.data.general.PieDataset pieDataset19 = null;
        org.jfree.chart.plot.PiePlot piePlot20 = new org.jfree.chart.plot.PiePlot(pieDataset19);
        piePlot20.setForegroundAlpha(0.0f);
        piePlot20.setLabelLinkMargin(4.0d);
        java.awt.Paint paint25 = piePlot20.getShadowPaint();
        java.lang.Object obj26 = textTitle1.draw(graphics2D6, rectangle2D16, (java.lang.Object) piePlot20);
        double double27 = textTitle1.getContentYOffset();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(size2D10);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(rectangleAnchor17);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(obj26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 1.0d + "'", double27 == 1.0d);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        piePlot1.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        piePlot1.setDataset(pieDataset8);
        piePlot1.setMaximumLabelWidth((double) (byte) 100);
        java.awt.Stroke stroke13 = piePlot1.getSectionOutlineStroke((java.lang.Comparable) (short) 0);
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        piePlot15.setForegroundAlpha((float) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor23 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean24 = rectangleInsets22.equals((java.lang.Object) rectangleAnchor23);
        double double26 = rectangleInsets22.calculateBottomInset((double) (-1L));
        piePlot15.setSimpleLabelOffset(rectangleInsets22);
        piePlot1.setInsets(rectangleInsets22);
        java.awt.Color color29 = java.awt.Color.BLUE;
        piePlot1.setLabelLinkPaint((java.awt.Paint) color29);
        java.awt.Font font31 = piePlot1.getLabelFont();
        piePlot1.setLabelLinksVisible(true);
        org.jfree.chart.util.Rotation rotation34 = org.jfree.chart.util.Rotation.ANTICLOCKWISE;
        java.lang.String str35 = rotation34.toString();
        org.jfree.chart.title.TextTitle textTitle37 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment38 = textTitle37.getTextAlignment();
        boolean boolean39 = rotation34.equals((java.lang.Object) horizontalAlignment38);
        piePlot1.setDirection(rotation34);
        org.junit.Assert.assertNull(stroke13);
        org.junit.Assert.assertNotNull(rectangleAnchor23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 100.0d + "'", double26 == 100.0d);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(rotation34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Rotation.ANTICLOCKWISE" + "'", str35.equals("Rotation.ANTICLOCKWISE"));
        org.junit.Assert.assertNotNull(horizontalAlignment38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = legendTitle1.getLegendItemGraphicPadding();
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        legendTitle1.setBackgroundPaint((java.awt.Paint) color3);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = legendTitle1.getLegendItemGraphicAnchor();
        java.awt.Color color6 = java.awt.Color.green;
        java.awt.Color color7 = color6.darker();
        boolean boolean8 = legendTitle1.equals((java.lang.Object) color7);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot9 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.util.TableOrder tableOrder10 = org.jfree.chart.util.TableOrder.BY_COLUMN;
        multiplePiePlot9.setDataExtractOrder(tableOrder10);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        boolean boolean13 = tableOrder10.equals((java.lang.Object) rectangleEdge12);
        legendTitle1.setLegendItemGraphicEdge(rectangleEdge12);
        java.awt.Paint paint15 = legendTitle1.getItemPaint();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(tableOrder10);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        piePlot1.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        piePlot1.setDataset(pieDataset8);
        org.jfree.data.general.PieDataset pieDataset10 = piePlot1.getDataset();
        java.lang.String str11 = piePlot1.getNoDataMessage();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator12 = piePlot1.getLegendLabelToolTipGenerator();
        org.junit.Assert.assertNull(pieDataset10);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNull(pieSectionLabelGenerator12);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.util.TableOrder tableOrder2 = org.jfree.chart.util.TableOrder.BY_COLUMN;
        multiplePiePlot1.setDataExtractOrder(tableOrder2);
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.chart.plot.Plot) multiplePiePlot1);
        org.jfree.chart.title.LegendTitle legendTitle6 = jFreeChart4.getLegend((int) '4');
        jFreeChart4.setBorderVisible(true);
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        piePlot10.setForegroundAlpha(0.0f);
        piePlot10.setStartAngle((double) 100L);
        piePlot10.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset17 = null;
        piePlot10.setDataset(pieDataset17);
        piePlot10.setMaximumLabelWidth((double) (byte) 100);
        java.awt.Stroke stroke22 = piePlot10.getSectionOutlineStroke((java.lang.Comparable) (short) 0);
        org.jfree.data.general.PieDataset pieDataset23 = null;
        org.jfree.chart.plot.PiePlot piePlot24 = new org.jfree.chart.plot.PiePlot(pieDataset23);
        piePlot24.setForegroundAlpha((float) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor32 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean33 = rectangleInsets31.equals((java.lang.Object) rectangleAnchor32);
        double double35 = rectangleInsets31.calculateBottomInset((double) (-1L));
        piePlot24.setSimpleLabelOffset(rectangleInsets31);
        piePlot10.setInsets(rectangleInsets31);
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = piePlot10.getSimpleLabelOffset();
        try {
            jFreeChart4.setTextAntiAlias((java.lang.Object) rectangleInsets38);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: RectangleInsets[t=0.18,l=0.18,b=0.18,r=0.18] incompatible with Text-specific antialiasing enable key");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(tableOrder2);
        org.junit.Assert.assertNull(legendTitle6);
        org.junit.Assert.assertNull(stroke22);
        org.junit.Assert.assertNotNull(rectangleAnchor32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 100.0d + "'", double35 == 100.0d);
        org.junit.Assert.assertNotNull(rectangleInsets38);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        java.awt.Color color2 = java.awt.Color.getColor("RectangleEdge.TOP", (int) (short) 1);
        org.jfree.chart.ChartColor chartColor6 = new org.jfree.chart.ChartColor(15, 192, (int) (short) 10);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.awt.Color color8 = java.awt.Color.GREEN;
        boolean boolean9 = chartChangeEventType7.equals((java.lang.Object) color8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        int int11 = color10.getTransparency();
        java.awt.Color color12 = java.awt.Color.BLACK;
        java.awt.Color color13 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        java.awt.Paint[] paintArray14 = new java.awt.Paint[] { color2, chartColor6, color8, color10, color12, color13 };
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType15 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.awt.Color color16 = java.awt.Color.GREEN;
        boolean boolean17 = chartChangeEventType15.equals((java.lang.Object) color16);
        java.awt.Paint paint22 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder23 = new org.jfree.chart.block.BlockBorder((double) 10, (double) '#', (double) 0L, 0.0d, paint22);
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.Paint[] paintArray25 = new java.awt.Paint[] { color16, paint22, color24 };
        java.awt.Paint[] paintArray26 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray27 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray28 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray29 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier30 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray14, paintArray25, paintArray26, strokeArray27, strokeArray28, shapeArray29);
        java.awt.Stroke stroke31 = defaultDrawingSupplier30.getNextStroke();
        java.awt.Paint paint32 = defaultDrawingSupplier30.getNextFillPaint();
        org.jfree.chart.LegendItemSource legendItemSource33 = null;
        org.jfree.chart.title.LegendTitle legendTitle34 = new org.jfree.chart.title.LegendTitle(legendItemSource33);
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = legendTitle34.getLegendItemGraphicPadding();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor36 = legendTitle34.getLegendItemGraphicLocation();
        boolean boolean37 = defaultDrawingSupplier30.equals((java.lang.Object) rectangleAnchor36);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(chartChangeEventType7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(paintArray14);
        org.junit.Assert.assertNotNull(chartChangeEventType15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(paintArray25);
        org.junit.Assert.assertNotNull(paintArray26);
        org.junit.Assert.assertNotNull(strokeArray27);
        org.junit.Assert.assertNotNull(strokeArray28);
        org.junit.Assert.assertNotNull(shapeArray29);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertNotNull(rectangleAnchor36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("TableOrder.BY_ROW");
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor(192, (-256), (-254));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Green Blue");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 0, (int) (byte) 100, (java.lang.Comparable) 1L, "RectangleEdge.TOP", "RectangleEdge.TOP");
        java.lang.Comparable comparable8 = pieSectionEntity7.getSectionKey();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 1L + "'", comparable8.equals(1L));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj1 = textTitle0.clone();
        java.lang.String str2 = textTitle0.getText();
        java.awt.Graphics2D graphics2D3 = null;
        try {
            org.jfree.chart.util.Size2D size2D4 = textTitle0.arrange(graphics2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        int int3 = defaultKeyedValues2D1.getRowIndex((java.lang.Comparable) (byte) 1);
        try {
            defaultKeyedValues2D1.removeColumn((java.lang.Comparable) 15);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unknown key: 15");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.util.TableOrder tableOrder1 = org.jfree.chart.util.TableOrder.BY_COLUMN;
        multiplePiePlot0.setDataExtractOrder(tableOrder1);
        multiplePiePlot0.setAggregatedItemsKey((java.lang.Comparable) (-1));
        org.jfree.data.category.CategoryDataset categoryDataset5 = multiplePiePlot0.getDataset();
        java.lang.Object obj6 = multiplePiePlot0.clone();
        multiplePiePlot0.setLimit(2.0d);
        org.jfree.chart.JFreeChart jFreeChart9 = multiplePiePlot0.getPieChart();
        org.junit.Assert.assertNotNull(tableOrder1);
        org.junit.Assert.assertNull(categoryDataset5);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(jFreeChart9);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        piePlot1.setShadowPaint((java.awt.Paint) color4);
        piePlot1.setIgnoreZeroValues(true);
        java.awt.Paint paint9 = null;
        piePlot1.setSectionOutlinePaint((java.lang.Comparable) 100.0f, paint9);
        org.jfree.data.general.PieDataset pieDataset11 = piePlot1.getDataset();
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment14 = textTitle13.getTextAlignment();
        textTitle13.setURLText("RectangleEdge.TOP");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment17 = textTitle13.getHorizontalAlignment();
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement21 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer22 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement21);
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.util.Size2D size2D24 = blockContainer22.arrange(graphics2D23);
        blockContainer22.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D30 = blockContainer22.getBounds();
        java.lang.Object obj32 = textTitle19.draw(graphics2D20, rectangle2D30, (java.lang.Object) (short) 0);
        org.jfree.chart.title.TextTitle textTitle34 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment35 = textTitle34.getTextAlignment();
        java.lang.String str36 = horizontalAlignment35.toString();
        textTitle19.setHorizontalAlignment(horizontalAlignment35);
        org.jfree.chart.title.TextTitle textTitle38 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font39 = textTitle38.getFont();
        org.jfree.chart.util.VerticalAlignment verticalAlignment40 = textTitle38.getVerticalAlignment();
        textTitle19.setVerticalAlignment(verticalAlignment40);
        org.jfree.chart.block.ColumnArrangement columnArrangement44 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment17, verticalAlignment40, 0.0d, (double) (-1.0f));
        org.jfree.data.general.PieDataset pieDataset45 = null;
        org.jfree.chart.plot.PiePlot piePlot46 = new org.jfree.chart.plot.PiePlot(pieDataset45);
        piePlot46.setForegroundAlpha(0.0f);
        piePlot46.setStartAngle((double) 100L);
        double double51 = piePlot46.getInteriorGap();
        java.awt.Paint paint52 = piePlot46.getLabelOutlinePaint();
        java.awt.Color color55 = java.awt.Color.getColor("RectangleEdge.TOP", (int) (short) 1);
        org.jfree.chart.ChartColor chartColor59 = new org.jfree.chart.ChartColor(15, 192, (int) (short) 10);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType60 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.awt.Color color61 = java.awt.Color.GREEN;
        boolean boolean62 = chartChangeEventType60.equals((java.lang.Object) color61);
        java.awt.Color color63 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        int int64 = color63.getTransparency();
        java.awt.Color color65 = java.awt.Color.BLACK;
        java.awt.Color color66 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        java.awt.Paint[] paintArray67 = new java.awt.Paint[] { color55, chartColor59, color61, color63, color65, color66 };
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType68 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.awt.Color color69 = java.awt.Color.GREEN;
        boolean boolean70 = chartChangeEventType68.equals((java.lang.Object) color69);
        java.awt.Paint paint75 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder76 = new org.jfree.chart.block.BlockBorder((double) 10, (double) '#', (double) 0L, 0.0d, paint75);
        java.awt.Color color77 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.Paint[] paintArray78 = new java.awt.Paint[] { color69, paint75, color77 };
        java.awt.Paint[] paintArray79 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray80 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray81 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray82 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier83 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray67, paintArray78, paintArray79, strokeArray80, strokeArray81, shapeArray82);
        piePlot46.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier83);
        java.awt.Paint paint85 = defaultDrawingSupplier83.getNextFillPaint();
        java.awt.Stroke stroke86 = defaultDrawingSupplier83.getNextStroke();
        org.jfree.chart.block.FlowArrangement flowArrangement87 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.Block block88 = null;
        java.awt.Stroke stroke89 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        flowArrangement87.add(block88, (java.lang.Object) stroke89);
        boolean boolean91 = defaultDrawingSupplier83.equals((java.lang.Object) flowArrangement87);
        org.jfree.chart.title.LegendTitle legendTitle92 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) columnArrangement44, (org.jfree.chart.block.Arrangement) flowArrangement87);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(pieDataset11);
        org.junit.Assert.assertNotNull(horizontalAlignment14);
        org.junit.Assert.assertNotNull(horizontalAlignment17);
        org.junit.Assert.assertNotNull(size2D24);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNull(obj32);
        org.junit.Assert.assertNotNull(horizontalAlignment35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "HorizontalAlignment.CENTER" + "'", str36.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertNotNull(font39);
        org.junit.Assert.assertNotNull(verticalAlignment40);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.08d + "'", double51 == 0.08d);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertNotNull(chartChangeEventType60);
        org.junit.Assert.assertNotNull(color61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(color63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1 + "'", int64 == 1);
        org.junit.Assert.assertNotNull(color65);
        org.junit.Assert.assertNotNull(color66);
        org.junit.Assert.assertNotNull(paintArray67);
        org.junit.Assert.assertNotNull(chartChangeEventType68);
        org.junit.Assert.assertNotNull(color69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(paint75);
        org.junit.Assert.assertNotNull(color77);
        org.junit.Assert.assertNotNull(paintArray78);
        org.junit.Assert.assertNotNull(paintArray79);
        org.junit.Assert.assertNotNull(strokeArray80);
        org.junit.Assert.assertNotNull(strokeArray81);
        org.junit.Assert.assertNotNull(shapeArray82);
        org.junit.Assert.assertNotNull(paint85);
        org.junit.Assert.assertNotNull(stroke86);
        org.junit.Assert.assertNotNull(stroke89);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.calculateTopOutset((double) 0);
        double double3 = rectangleInsets0.getBottom();
        double double4 = rectangleInsets0.getLeft();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 8.0d + "'", double4 == 8.0d);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("", "TableOrder.BY_ROW", "RectangleEdge.TOP", "RectangleEdge.TOP", "HorizontalAlignment.CENTER");
        java.lang.String str6 = basicProjectInfo5.getName();
        basicProjectInfo5.addOptionalLibrary("");
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean10 = rectangleInsets8.equals((java.lang.Object) rectangleAnchor9);
        double double12 = rectangleInsets8.calculateTopInset(0.0d);
        piePlot1.setInsets(rectangleInsets8);
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        piePlot15.setForegroundAlpha((float) 0);
        boolean boolean18 = piePlot15.getIgnoreZeroValues();
        double double19 = piePlot15.getShadowXOffset();
        java.awt.Stroke stroke20 = piePlot15.getLabelLinkStroke();
        piePlot1.setBaseSectionOutlineStroke(stroke20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        piePlot1.handleClick(255, (int) (short) 0, plotRenderingInfo24);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator26 = piePlot1.getLegendLabelURLGenerator();
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.0d) + "'", double12 == (-1.0d));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 4.0d + "'", double19 == 4.0d);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNull(pieURLGenerator26);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.zoom((double) '#');
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        piePlot7.setForegroundAlpha((float) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean16 = rectangleInsets14.equals((java.lang.Object) rectangleAnchor15);
        double double18 = rectangleInsets14.calculateBottomInset((double) (-1L));
        piePlot7.setSimpleLabelOffset(rectangleInsets14);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle20 = org.jfree.chart.plot.PieLabelLinkStyle.CUBIC_CURVE;
        piePlot7.setLabelLinkStyle(pieLabelLinkStyle20);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier22 = piePlot7.getDrawingSupplier();
        boolean boolean23 = piePlot1.equals((java.lang.Object) piePlot7);
        java.awt.Paint paint24 = piePlot7.getLabelPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator25 = piePlot7.getLegendLabelGenerator();
        java.awt.Paint paint26 = null;
        piePlot7.setLabelOutlinePaint(paint26);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        piePlot7.handleClick((int) (byte) 0, (int) ' ', plotRenderingInfo30);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 100.0d + "'", double18 == 100.0d);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle20);
        org.junit.Assert.assertNotNull(drawingSupplier22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator25);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = textTitle1.getTextAlignment();
        java.lang.String str3 = horizontalAlignment2.toString();
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font5 = textTitle4.getFont();
        org.jfree.chart.util.VerticalAlignment verticalAlignment6 = textTitle4.getVerticalAlignment();
        org.jfree.chart.block.FlowArrangement flowArrangement9 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment2, verticalAlignment6, (double) (short) 0, (double) (short) 1);
        org.jfree.chart.LegendItemSource legendItemSource10 = null;
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle(legendItemSource10);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = legendTitle11.getLegendItemGraphicPadding();
        boolean boolean13 = flowArrangement9.equals((java.lang.Object) legendTitle11);
        boolean boolean14 = legendTitle11.getNotify();
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "HorizontalAlignment.CENTER" + "'", str3.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(verticalAlignment6);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean6 = rectangleInsets4.equals((java.lang.Object) rectangleAnchor5);
        double double8 = rectangleInsets4.calculateTopInset(0.0d);
        double double9 = rectangleInsets4.getLeft();
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 10.0d + "'", double9 == 10.0d);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("", "Multiple Pie Plot", "org.jfree.chart.event.ChartChangeEvent[source=0]", "4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0");
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("");
        java.awt.Shape shape7 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity14 = new org.jfree.chart.entity.PieSectionEntity(shape7, pieDataset8, 0, (int) (byte) 100, (java.lang.Comparable) 1L, "RectangleEdge.TOP", "RectangleEdge.TOP");
        org.jfree.chart.JFreeChart jFreeChart15 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent16 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0, jFreeChart15);
        org.jfree.chart.JFreeChart jFreeChart17 = chartChangeEvent16.getChart();
        org.jfree.chart.JFreeChart jFreeChart18 = null;
        chartChangeEvent16.setChart(jFreeChart18);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot21 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.util.TableOrder tableOrder22 = org.jfree.chart.util.TableOrder.BY_COLUMN;
        multiplePiePlot21.setDataExtractOrder(tableOrder22);
        org.jfree.chart.JFreeChart jFreeChart24 = new org.jfree.chart.JFreeChart("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.chart.plot.Plot) multiplePiePlot21);
        chartChangeEvent16.setChart(jFreeChart24);
        jFreeChart24.setBackgroundImageAlpha((float) 'a');
        textTitle6.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart24);
        java.awt.Shape shape29 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset30 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity36 = new org.jfree.chart.entity.PieSectionEntity(shape29, pieDataset30, 0, (int) (byte) 100, (java.lang.Comparable) 1L, "RectangleEdge.TOP", "RectangleEdge.TOP");
        org.jfree.chart.JFreeChart jFreeChart37 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent38 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0, jFreeChart37);
        org.jfree.chart.JFreeChart jFreeChart39 = chartChangeEvent38.getChart();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType40 = chartChangeEvent38.getType();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent41 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) "Multiple Pie Plot", jFreeChart24, chartChangeEventType40);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent42 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) chartChangeEventType40);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNull(jFreeChart17);
        org.junit.Assert.assertNotNull(tableOrder22);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNull(jFreeChart39);
        org.junit.Assert.assertNotNull(chartChangeEventType40);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        java.awt.Stroke stroke6 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        piePlot1.setLabelOutlineStroke(stroke6);
        double double8 = piePlot1.getLabelLinkMargin();
        java.awt.Paint paint9 = piePlot1.getLabelShadowPaint();
        piePlot1.setStartAngle(35.0d);
        boolean boolean12 = piePlot1.getSectionOutlinesVisible();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.025d + "'", double8 == 0.025d);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 0, (int) (byte) 100, (java.lang.Comparable) 1L, "RectangleEdge.TOP", "RectangleEdge.TOP");
        org.jfree.chart.JFreeChart jFreeChart8 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent9 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0, jFreeChart8);
        org.jfree.chart.JFreeChart jFreeChart10 = chartChangeEvent9.getChart();
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        chartChangeEvent9.setChart(jFreeChart11);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot14 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.util.TableOrder tableOrder15 = org.jfree.chart.util.TableOrder.BY_COLUMN;
        multiplePiePlot14.setDataExtractOrder(tableOrder15);
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.chart.plot.Plot) multiplePiePlot14);
        chartChangeEvent9.setChart(jFreeChart17);
        java.awt.Paint paint19 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        jFreeChart17.setBorderPaint(paint19);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNull(jFreeChart10);
        org.junit.Assert.assertNotNull(tableOrder15);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj1 = null;
        int int2 = objectList0.indexOf(obj1);
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        piePlot5.setForegroundAlpha((float) 0);
        java.awt.Stroke stroke8 = piePlot5.getBaseSectionOutlineStroke();
        piePlot5.setLabelLinkMargin((double) (-256));
        piePlot5.setSectionOutlinesVisible(false);
        org.jfree.data.general.DatasetGroup datasetGroup13 = piePlot5.getDatasetGroup();
        objectList0.set(1, (java.lang.Object) datasetGroup13);
        int int15 = objectList0.size();
        java.lang.Object obj17 = objectList0.get((int) ' ');
        int int18 = objectList0.size();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(datasetGroup13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
        org.junit.Assert.assertNull(obj17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2 + "'", int18 == 2);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        java.lang.Object obj2 = textTitle1.clone();
        java.lang.String str3 = textTitle1.getText();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]" + "'", str3.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setForegroundAlpha(0.0f);
        piePlot3.setStartAngle((double) 100L);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        piePlot3.setLabelOutlineStroke(stroke8);
        piePlot3.setMaximumLabelWidth((-1.0d));
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        piePlot13.setForegroundAlpha(0.0f);
        piePlot13.setStartAngle((double) 100L);
        java.awt.Stroke stroke18 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        piePlot13.setLabelOutlineStroke(stroke18);
        java.awt.Stroke stroke20 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        piePlot13.setBaseSectionOutlineStroke(stroke20);
        piePlot3.setLabelOutlineStroke(stroke20);
        flowArrangement0.add((org.jfree.chart.block.Block) textTitle1, (java.lang.Object) piePlot3);
        java.awt.Color color24 = java.awt.Color.PINK;
        piePlot3.setLabelLinkPaint((java.awt.Paint) color24);
        int int26 = piePlot3.getBackgroundImageAlignment();
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 15 + "'", int26 == 15);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        java.awt.Color color1 = java.awt.Color.GREEN;
        float[] floatArray6 = new float[] { (byte) 1, (short) 0, (short) 100, (short) -1 };
        float[] floatArray7 = color1.getComponents(floatArray6);
        boolean boolean8 = defaultKeyedValues2D0.equals((java.lang.Object) floatArray7);
        int int9 = defaultKeyedValues2D0.getColumnCount();
        int int10 = defaultKeyedValues2D0.getColumnCount();
        try {
            defaultKeyedValues2D0.removeColumn((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        java.awt.Color color0 = java.awt.Color.CYAN;
        int int1 = color0.getTransparency();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Enumeration<java.lang.String> strEnumeration1 = jFreeChartResources0.getKeys();
        java.util.Locale locale2 = jFreeChartResources0.getLocale();
        java.util.Locale locale3 = jFreeChartResources0.getLocale();
        try {
            java.lang.String[] strArray5 = jFreeChartResources0.getStringArray("JFreeChart version RectangleEdge.TOP.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nTableOrder.BY_ROW");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key JFreeChart version RectangleEdge.TOP.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nTableOrder.BY_ROW");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNotNull(strEnumeration1);
        org.junit.Assert.assertNull(locale2);
        org.junit.Assert.assertNull(locale3);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font1 = textTitle0.getFont();
        java.lang.String str2 = textTitle0.getID();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.zoom((double) '#');
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        piePlot7.setForegroundAlpha((float) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean16 = rectangleInsets14.equals((java.lang.Object) rectangleAnchor15);
        double double18 = rectangleInsets14.calculateBottomInset((double) (-1L));
        piePlot7.setSimpleLabelOffset(rectangleInsets14);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle20 = org.jfree.chart.plot.PieLabelLinkStyle.CUBIC_CURVE;
        piePlot7.setLabelLinkStyle(pieLabelLinkStyle20);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier22 = piePlot7.getDrawingSupplier();
        boolean boolean23 = piePlot1.equals((java.lang.Object) piePlot7);
        java.awt.Paint paint24 = piePlot7.getLabelPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator25 = piePlot7.getLegendLabelGenerator();
        java.awt.Paint paint26 = null;
        try {
            piePlot7.setNoDataMessagePaint(paint26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 100.0d + "'", double18 == 100.0d);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle20);
        org.junit.Assert.assertNotNull(drawingSupplier22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator25);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.util.TableOrder tableOrder1 = org.jfree.chart.util.TableOrder.BY_COLUMN;
        multiplePiePlot0.setDataExtractOrder(tableOrder1);
        multiplePiePlot0.setAggregatedItemsKey((java.lang.Comparable) (-1));
        org.jfree.data.category.CategoryDataset categoryDataset5 = multiplePiePlot0.getDataset();
        java.awt.Paint paint6 = multiplePiePlot0.getAggregatedItemsPaint();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent7 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.junit.Assert.assertNotNull(tableOrder1);
        org.junit.Assert.assertNull(categoryDataset5);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        java.lang.String str3 = rectangleEdge2.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge2);
        legendTitle1.setLegendItemGraphicEdge(rectangleEdge2);
        org.jfree.chart.block.BlockContainer blockContainer6 = legendTitle1.getItemContainer();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = null;
        legendTitle1.setLegendItemGraphicLocation(rectangleAnchor7);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = legendTitle1.getLegendItemGraphicLocation();
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleEdge.TOP" + "'", str3.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(blockContainer6);
        org.junit.Assert.assertNull(rectangleAnchor9);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        piePlot1.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        piePlot1.setDataset(pieDataset8);
        piePlot1.setMaximumLabelWidth((double) (byte) 100);
        java.awt.Stroke stroke13 = piePlot1.getSectionOutlineStroke((java.lang.Comparable) (short) 0);
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        piePlot15.setForegroundAlpha((float) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor23 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean24 = rectangleInsets22.equals((java.lang.Object) rectangleAnchor23);
        double double26 = rectangleInsets22.calculateBottomInset((double) (-1L));
        piePlot15.setSimpleLabelOffset(rectangleInsets22);
        piePlot1.setInsets(rectangleInsets22);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = piePlot1.getSimpleLabelOffset();
        piePlot1.setIgnoreZeroValues(false);
        org.jfree.chart.JFreeChart jFreeChart32 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        org.jfree.chart.title.TextTitle textTitle33 = jFreeChart32.getTitle();
        java.awt.Paint paint34 = jFreeChart32.getBorderPaint();
        org.jfree.chart.LegendItemSource legendItemSource35 = null;
        org.jfree.chart.title.LegendTitle legendTitle36 = new org.jfree.chart.title.LegendTitle(legendItemSource35);
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = legendTitle36.getLegendItemGraphicPadding();
        java.awt.Color color38 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        legendTitle36.setBackgroundPaint((java.awt.Paint) color38);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor40 = legendTitle36.getLegendItemGraphicAnchor();
        java.awt.Color color41 = java.awt.Color.green;
        java.awt.Color color42 = color41.darker();
        boolean boolean43 = legendTitle36.equals((java.lang.Object) color42);
        jFreeChart32.addLegend(legendTitle36);
        org.junit.Assert.assertNull(stroke13);
        org.junit.Assert.assertNotNull(rectangleAnchor23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 100.0d + "'", double26 == 100.0d);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNull(textTitle33);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(rectangleAnchor40);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.util.TableOrder tableOrder1 = org.jfree.chart.util.TableOrder.BY_COLUMN;
        multiplePiePlot0.setDataExtractOrder(tableOrder1);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        boolean boolean4 = tableOrder1.equals((java.lang.Object) rectangleEdge3);
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer9 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement8);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.util.Size2D size2D11 = blockContainer9.arrange(graphics2D10);
        blockContainer9.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D17 = blockContainer9.getBounds();
        java.lang.Object obj19 = textTitle6.draw(graphics2D7, rectangle2D17, (java.lang.Object) (short) 0);
        boolean boolean20 = textTitle6.getExpandToFitSpace();
        boolean boolean21 = tableOrder1.equals((java.lang.Object) textTitle6);
        java.awt.Paint paint22 = textTitle6.getBackgroundPaint();
        java.awt.Paint paint23 = textTitle6.getBackgroundPaint();
        textTitle6.setText("");
        org.junit.Assert.assertNotNull(tableOrder1);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(size2D11);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertNull(obj19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(paint22);
        org.junit.Assert.assertNull(paint23);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Enumeration<java.lang.String> strEnumeration1 = jFreeChartResources0.getKeys();
        java.util.Set<java.lang.String> strSet2 = jFreeChartResources0.keySet();
        org.junit.Assert.assertNotNull(strEnumeration1);
        org.junit.Assert.assertNotNull(strSet2);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.awt.Color color1 = java.awt.Color.GREEN;
        boolean boolean2 = chartChangeEventType0.equals((java.lang.Object) color1);
        org.jfree.chart.LegendItemSource legendItemSource3 = null;
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle(legendItemSource3);
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        java.lang.String str6 = rectangleEdge5.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge5);
        legendTitle4.setLegendItemGraphicEdge(rectangleEdge5);
        org.jfree.chart.block.BlockFrame blockFrame9 = legendTitle4.getFrame();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = legendTitle4.getItemLabelPadding();
        double double12 = rectangleInsets10.calculateRightInset(0.0d);
        double double13 = rectangleInsets10.getTop();
        boolean boolean14 = chartChangeEventType0.equals((java.lang.Object) double13);
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "RectangleEdge.TOP" + "'", str6.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(blockFrame9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.0d + "'", double13 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        java.awt.Color color1 = java.awt.Color.GREEN;
        float[] floatArray6 = new float[] { (byte) 1, (short) 0, (short) 100, (short) -1 };
        float[] floatArray7 = color1.getComponents(floatArray6);
        boolean boolean8 = defaultKeyedValues2D0.equals((java.lang.Object) floatArray7);
        int int9 = defaultKeyedValues2D0.getColumnCount();
        int int10 = defaultKeyedValues2D0.getColumnCount();
        java.util.List list11 = defaultKeyedValues2D0.getColumnKeys();
        int int13 = defaultKeyedValues2D0.getColumnIndex((java.lang.Comparable) "hi!");
        int int15 = defaultKeyedValues2D0.getRowIndex((java.lang.Comparable) 0.0d);
        int int16 = defaultKeyedValues2D0.getColumnCount();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        piePlot1.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        piePlot1.setDataset(pieDataset8);
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        piePlot1.removeChangeListener(plotChangeListener10);
        org.jfree.chart.block.FlowArrangement flowArrangement12 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.Block block13 = null;
        java.awt.Stroke stroke14 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        flowArrangement12.add(block13, (java.lang.Object) stroke14);
        piePlot1.setBaseSectionOutlineStroke(stroke14);
        java.awt.Stroke stroke18 = piePlot1.getSectionOutlineStroke((java.lang.Comparable) 100.0f);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNull(stroke18);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setForegroundAlpha((float) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean12 = rectangleInsets10.equals((java.lang.Object) rectangleAnchor11);
        double double14 = rectangleInsets10.calculateBottomInset((double) (-1L));
        piePlot3.setSimpleLabelOffset(rectangleInsets10);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle16 = org.jfree.chart.plot.PieLabelLinkStyle.CUBIC_CURVE;
        piePlot3.setLabelLinkStyle(pieLabelLinkStyle16);
        defaultCategoryDataset0.removeChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot3);
        defaultCategoryDataset0.setValue((java.lang.Number) 10, (java.lang.Comparable) "PieSection: 0, 100(1)", (java.lang.Comparable) "RectangleInsets[t=-1.0,l=10.0,b=100.0,r=1.0]");
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 100.0d + "'", double14 == 100.0d);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle16);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        java.awt.Color color1 = java.awt.Color.GREEN;
        float[] floatArray6 = new float[] { (byte) 1, (short) 0, (short) 100, (short) -1 };
        float[] floatArray7 = color1.getComponents(floatArray6);
        boolean boolean8 = defaultKeyedValues2D0.equals((java.lang.Object) floatArray7);
        int int9 = defaultKeyedValues2D0.getColumnCount();
        int int10 = defaultKeyedValues2D0.getColumnCount();
        defaultKeyedValues2D0.setValue((java.lang.Number) 0, (java.lang.Comparable) "hi!", (java.lang.Comparable) (byte) -1);
        int int16 = defaultKeyedValues2D0.getColumnIndex((java.lang.Comparable) 0.08d);
        try {
            java.lang.Comparable comparable18 = defaultKeyedValues2D0.getRowKey(91);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 91, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int2 = defaultKeyedValues2D1.getRowCount();
        try {
            defaultKeyedValues2D1.removeColumn((java.lang.Comparable) "JFreeChart version RectangleEdge.TOP.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nTableOrder.BY_ROW");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unknown key: JFreeChart version RectangleEdge.TOP.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nTableOrder.BY_ROW");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 0, (int) (byte) 100, (java.lang.Comparable) 1L, "RectangleEdge.TOP", "RectangleEdge.TOP");
        org.jfree.data.general.PieDataset pieDataset8 = null;
        pieSectionEntity7.setDataset(pieDataset8);
        java.lang.String str10 = pieSectionEntity7.toString();
        java.lang.String str11 = pieSectionEntity7.getToolTipText();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "PieSection: 0, 100(1)" + "'", str10.equals("PieSection: 0, 100(1)"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "RectangleEdge.TOP" + "'", str11.equals("RectangleEdge.TOP"));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.util.TableOrder tableOrder1 = org.jfree.chart.util.TableOrder.BY_COLUMN;
        multiplePiePlot0.setDataExtractOrder(tableOrder1);
        multiplePiePlot0.setAggregatedItemsKey((java.lang.Comparable) (-1));
        org.jfree.data.category.CategoryDataset categoryDataset5 = multiplePiePlot0.getDataset();
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("");
        java.awt.Paint paint8 = textTitle7.getBackgroundPaint();
        boolean boolean9 = multiplePiePlot0.equals((java.lang.Object) paint8);
        org.junit.Assert.assertNotNull(tableOrder1);
        org.junit.Assert.assertNull(categoryDataset5);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj1 = null;
        int int2 = objectList0.indexOf(obj1);
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        piePlot5.setForegroundAlpha((float) 0);
        java.awt.Stroke stroke8 = piePlot5.getBaseSectionOutlineStroke();
        piePlot5.setLabelLinkMargin((double) (-256));
        piePlot5.setSectionOutlinesVisible(false);
        org.jfree.data.general.DatasetGroup datasetGroup13 = piePlot5.getDatasetGroup();
        objectList0.set(1, (java.lang.Object) datasetGroup13);
        int int15 = objectList0.size();
        int int16 = objectList0.size();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(datasetGroup13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        java.awt.Color color2 = java.awt.Color.getColor("RectangleEdge.TOP", (int) (short) 1);
        org.jfree.chart.ChartColor chartColor6 = new org.jfree.chart.ChartColor(15, 192, (int) (short) 10);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.awt.Color color8 = java.awt.Color.GREEN;
        boolean boolean9 = chartChangeEventType7.equals((java.lang.Object) color8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        int int11 = color10.getTransparency();
        java.awt.Color color12 = java.awt.Color.BLACK;
        java.awt.Color color13 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        java.awt.Paint[] paintArray14 = new java.awt.Paint[] { color2, chartColor6, color8, color10, color12, color13 };
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType15 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.awt.Color color16 = java.awt.Color.GREEN;
        boolean boolean17 = chartChangeEventType15.equals((java.lang.Object) color16);
        java.awt.Paint paint22 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder23 = new org.jfree.chart.block.BlockBorder((double) 10, (double) '#', (double) 0L, 0.0d, paint22);
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.Paint[] paintArray25 = new java.awt.Paint[] { color16, paint22, color24 };
        java.awt.Paint[] paintArray26 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray27 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray28 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray29 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier30 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray14, paintArray25, paintArray26, strokeArray27, strokeArray28, shapeArray29);
        java.lang.Object obj31 = defaultDrawingSupplier30.clone();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(chartChangeEventType7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(paintArray14);
        org.junit.Assert.assertNotNull(chartChangeEventType15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(paintArray25);
        org.junit.Assert.assertNotNull(paintArray26);
        org.junit.Assert.assertNotNull(strokeArray27);
        org.junit.Assert.assertNotNull(strokeArray28);
        org.junit.Assert.assertNotNull(shapeArray29);
        org.junit.Assert.assertNotNull(obj31);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        java.awt.Stroke stroke6 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        piePlot1.setLabelOutlineStroke(stroke6);
        double double8 = piePlot1.getLabelLinkMargin();
        java.awt.Paint paint9 = piePlot1.getLabelShadowPaint();
        piePlot1.setForegroundAlpha((float) ' ');
        org.jfree.chart.block.ColumnArrangement columnArrangement12 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer13 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement12);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.util.Size2D size2D15 = blockContainer13.arrange(graphics2D14);
        blockContainer13.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D21 = blockContainer13.getBounds();
        boolean boolean22 = blockContainer13.isEmpty();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double25 = rectangleInsets23.calculateTopOutset((double) 0);
        java.lang.String str26 = rectangleInsets23.toString();
        blockContainer13.setPadding(rectangleInsets23);
        double double29 = rectangleInsets23.calculateLeftInset((double) 15);
        piePlot1.setInsets(rectangleInsets23, false);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.025d + "'", double8 == 0.025d);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(size2D15);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 4.0d + "'", double25 == 4.0d);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]" + "'", str26.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 8.0d + "'", double29 == 8.0d);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        java.util.Locale locale1 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("PieSection: 0, 100(true)", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        double double1 = multiplePiePlot0.getLimit();
        java.awt.Paint paint2 = multiplePiePlot0.getAggregatedItemsPaint();
        java.lang.Comparable comparable3 = multiplePiePlot0.getAggregatedItemsKey();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + "Other" + "'", comparable3.equals("Other"));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) 10L, 0.0f, 100.0f);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("", "hi!");
        java.lang.String str3 = contributor2.getName();
        java.lang.String str4 = contributor2.getEmail();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("");
        java.lang.Throwable[] throwableArray2 = unknownKeyException1.getSuppressed();
        java.lang.Throwable[] throwableArray3 = unknownKeyException1.getSuppressed();
        org.jfree.data.UnknownKeyException unknownKeyException5 = new org.jfree.data.UnknownKeyException("");
        java.lang.Throwable[] throwableArray6 = unknownKeyException5.getSuppressed();
        java.lang.Throwable[] throwableArray7 = unknownKeyException5.getSuppressed();
        org.jfree.data.UnknownKeyException unknownKeyException9 = new org.jfree.data.UnknownKeyException("");
        java.lang.Throwable[] throwableArray10 = unknownKeyException9.getSuppressed();
        java.lang.Throwable[] throwableArray11 = unknownKeyException9.getSuppressed();
        unknownKeyException5.addSuppressed((java.lang.Throwable) unknownKeyException9);
        unknownKeyException1.addSuppressed((java.lang.Throwable) unknownKeyException5);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertNotNull(throwableArray11);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.lang.Object obj1 = standardPieSectionLabelGenerator0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.getSectionOutlinesVisible();
        java.awt.Paint paint3 = piePlot1.getShadowPaint();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        java.awt.Color color1 = java.awt.Color.GREEN;
        float[] floatArray6 = new float[] { (byte) 1, (short) 0, (short) 100, (short) -1 };
        float[] floatArray7 = color1.getComponents(floatArray6);
        boolean boolean8 = defaultKeyedValues2D0.equals((java.lang.Object) floatArray7);
        try {
            defaultKeyedValues2D0.removeRow((java.lang.Comparable) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("HorizontalAlignment.LEFT", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setForegroundAlpha((float) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean12 = rectangleInsets10.equals((java.lang.Object) rectangleAnchor11);
        double double14 = rectangleInsets10.calculateBottomInset((double) (-1L));
        piePlot3.setSimpleLabelOffset(rectangleInsets10);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle16 = org.jfree.chart.plot.PieLabelLinkStyle.CUBIC_CURVE;
        piePlot3.setLabelLinkStyle(pieLabelLinkStyle16);
        defaultCategoryDataset0.removeChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot3);
        int int20 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) (-1.0f));
        org.jfree.data.general.PieDataset pieDataset21 = null;
        org.jfree.chart.plot.PiePlot piePlot22 = new org.jfree.chart.plot.PiePlot(pieDataset21);
        piePlot22.setForegroundAlpha(0.0f);
        piePlot22.setStartAngle((double) 100L);
        piePlot22.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset29 = null;
        piePlot22.setDataset(pieDataset29);
        piePlot22.setForegroundAlpha((float) (byte) 0);
        defaultCategoryDataset0.addChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot22);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 100.0d + "'", double14 == 100.0d);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setLabelLinkMargin(4.0d);
        java.awt.Paint paint6 = piePlot1.getShadowPaint();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator7 = piePlot1.getURLGenerator();
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(pieURLGenerator7);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        piePlot1.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        piePlot1.setDataset(pieDataset8);
        org.jfree.data.general.PieDataset pieDataset10 = piePlot1.getDataset();
        java.lang.String str11 = piePlot1.getNoDataMessage();
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        piePlot1.setOutlinePaint((java.awt.Paint) color12);
        java.awt.Shape shape14 = piePlot1.getLegendItemShape();
        org.junit.Assert.assertNull(pieDataset10);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(shape14);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        java.awt.Paint paint1 = lineBorder0.getPaint();
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean10 = rectangleInsets8.equals((java.lang.Object) rectangleAnchor9);
        double double12 = rectangleInsets8.calculateTopInset(0.0d);
        piePlot1.setInsets(rectangleInsets8);
        double double15 = rectangleInsets8.trimWidth((double) 192);
        double double17 = rectangleInsets8.calculateLeftOutset(0.0d);
        double double19 = rectangleInsets8.calculateLeftOutset(0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.0d) + "'", double12 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 181.0d + "'", double15 == 181.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 10.0d + "'", double17 == 10.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 10.0d + "'", double19 == 10.0d);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setForegroundAlpha((float) 0);
        java.awt.Stroke stroke6 = piePlot3.getBaseSectionOutlineStroke();
        piePlot3.setLabelLinkMargin((double) (-256));
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("PieSection: 0, 100(1)", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
        org.jfree.chart.event.ChartProgressListener chartProgressListener11 = null;
        jFreeChart10.removeProgressListener(chartProgressListener11);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = null;
        try {
            java.awt.image.BufferedImage bufferedImage16 = jFreeChart10.createBufferedImage((-1), (int) (byte) 10, chartRenderingInfo15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (-1) and height (10) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(stroke6);
    }
}

