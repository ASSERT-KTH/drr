import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        java.lang.String str3 = standardPieSectionLabelGenerator0.generateSectionLabel(pieDataset1, (java.lang.Comparable) "RectangleInsets[t=-1.0,l=10.0,b=100.0,r=1.0]");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle4 = org.jfree.chart.plot.PieLabelLinkStyle.CUBIC_CURVE;
        boolean boolean5 = standardPieSectionLabelGenerator0.equals((java.lang.Object) pieLabelLinkStyle4);
        java.lang.String str6 = pieLabelLinkStyle4.toString();
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PieLabelLinkStyle.CUBIC_CURVE" + "'", str6.equals("PieLabelLinkStyle.CUBIC_CURVE"));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = textTitle1.getTextAlignment();
        textTitle1.setURLText("RectangleEdge.TOP");
        org.jfree.chart.block.BlockFrame blockFrame5 = textTitle1.getFrame();
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertNotNull(blockFrame5);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 0, (int) (byte) 100, (java.lang.Comparable) 1L, "RectangleEdge.TOP", "RectangleEdge.TOP");
        java.lang.String str8 = pieSectionEntity7.toString();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "PieSection: 0, 100(1)" + "'", str8.equals("PieSection: 0, 100(1)"));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font1 = textTitle0.getFont();
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = textTitle0.getVerticalAlignment();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle0);
        java.lang.Object obj4 = titleChangeEvent3.getSource();
        java.awt.Font font6 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot(pieDataset7);
        piePlot8.setForegroundAlpha((float) 0);
        java.awt.Stroke stroke11 = piePlot8.getBaseSectionOutlineStroke();
        piePlot8.setLabelLinkMargin((double) (-256));
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("PieSection: 0, 100(1)", font6, (org.jfree.chart.plot.Plot) piePlot8, false);
        jFreeChart15.setBorderVisible(false);
        boolean boolean18 = jFreeChart15.isBorderVisible();
        titleChangeEvent3.setChart(jFreeChart15);
        org.jfree.chart.LegendItemSource legendItemSource20 = null;
        org.jfree.chart.title.LegendTitle legendTitle21 = new org.jfree.chart.title.LegendTitle(legendItemSource20);
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        java.lang.String str23 = rectangleEdge22.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge22);
        legendTitle21.setLegendItemGraphicEdge(rectangleEdge22);
        org.jfree.chart.block.BlockFrame blockFrame26 = legendTitle21.getFrame();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = legendTitle21.getItemLabelPadding();
        jFreeChart15.addLegend(legendTitle21);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "RectangleEdge.TOP" + "'", str23.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertNotNull(blockFrame26);
        org.junit.Assert.assertNotNull(rectangleInsets27);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.util.Size2D size2D3 = blockContainer1.arrange(graphics2D2);
        blockContainer1.setHeight((double) 1);
        java.lang.Object obj6 = blockContainer1.clone();
        blockContainer1.clear();
        blockContainer1.clear();
        org.junit.Assert.assertNotNull(size2D3);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        piePlot2.setForegroundAlpha(0.0f);
        piePlot2.setStartAngle((double) 100L);
        piePlot2.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset9 = null;
        piePlot2.setDataset(pieDataset9);
        piePlot2.setMaximumLabelWidth((double) (byte) 100);
        java.awt.Stroke stroke14 = piePlot2.getSectionOutlineStroke((java.lang.Comparable) (short) 0);
        org.jfree.data.general.PieDataset pieDataset15 = null;
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot(pieDataset15);
        piePlot16.setForegroundAlpha((float) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean25 = rectangleInsets23.equals((java.lang.Object) rectangleAnchor24);
        double double27 = rectangleInsets23.calculateBottomInset((double) (-1L));
        piePlot16.setSimpleLabelOffset(rectangleInsets23);
        piePlot2.setInsets(rectangleInsets23);
        java.awt.Color color30 = java.awt.Color.BLUE;
        piePlot2.setLabelLinkPaint((java.awt.Paint) color30);
        java.awt.Font font32 = piePlot2.getLabelFont();
        java.awt.Font font33 = piePlot2.getLabelFont();
        org.jfree.data.general.PieDataset pieDataset34 = null;
        org.jfree.chart.plot.PiePlot piePlot35 = new org.jfree.chart.plot.PiePlot(pieDataset34);
        piePlot35.setForegroundAlpha(0.0f);
        piePlot35.setStartAngle((double) 100L);
        float float40 = piePlot35.getBackgroundAlpha();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator41 = null;
        piePlot35.setLegendLabelURLGenerator(pieURLGenerator41);
        org.jfree.chart.JFreeChart jFreeChart44 = new org.jfree.chart.JFreeChart("RectangleEdge.TOP", font33, (org.jfree.chart.plot.Plot) piePlot35, false);
        org.junit.Assert.assertNull(stroke14);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 100.0d + "'", double27 == 100.0d);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertTrue("'" + float40 + "' != '" + 1.0f + "'", float40 == 1.0f);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = legendTitle1.getLegendItemGraphicPadding();
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        legendTitle1.setBackgroundPaint((java.awt.Paint) color3);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = legendTitle1.getLegendItemGraphicAnchor();
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        piePlot7.setForegroundAlpha((float) 0);
        boolean boolean10 = piePlot7.getIgnoreZeroValues();
        double double11 = piePlot7.getShadowXOffset();
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot7);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = null;
        java.awt.image.BufferedImage bufferedImage16 = jFreeChart12.createBufferedImage((int) 'a', (int) (byte) 100, chartRenderingInfo15);
        jFreeChart12.setNotify(false);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent19 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) legendTitle1, jFreeChart12);
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment23 = textTitle22.getTextAlignment();
        java.lang.String str24 = horizontalAlignment23.toString();
        org.jfree.chart.title.TextTitle textTitle25 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font26 = textTitle25.getFont();
        org.jfree.chart.util.VerticalAlignment verticalAlignment27 = textTitle25.getVerticalAlignment();
        org.jfree.chart.block.FlowArrangement flowArrangement30 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment23, verticalAlignment27, (double) (short) 0, (double) (short) 1);
        org.jfree.chart.LegendItemSource legendItemSource31 = null;
        org.jfree.chart.title.LegendTitle legendTitle32 = new org.jfree.chart.title.LegendTitle(legendItemSource31);
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = legendTitle32.getLegendItemGraphicPadding();
        boolean boolean34 = flowArrangement30.equals((java.lang.Object) legendTitle32);
        try {
            jFreeChart12.addSubtitle((int) (byte) 100, (org.jfree.chart.title.Title) legendTitle32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'index' argument is out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertNotNull(bufferedImage16);
        org.junit.Assert.assertNotNull(horizontalAlignment23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "HorizontalAlignment.CENTER" + "'", str24.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(verticalAlignment27);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        try {
            java.text.AttributedString attributedString3 = standardPieSectionLabelGenerator0.generateAttributedSectionLabel(pieDataset1, (java.lang.Comparable) "4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("", "RectangleInsets[t=-1.0,l=10.0,b=100.0,r=1.0]", "PieLabelLinkStyle.CUBIC_CURVE", "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        java.awt.Stroke stroke6 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        piePlot1.setLabelOutlineStroke(stroke6);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        piePlot1.setBaseSectionOutlineStroke(stroke8);
        java.awt.Paint paint10 = piePlot1.getNoDataMessagePaint();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        piePlot1.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        piePlot1.setDataset(pieDataset8);
        piePlot1.setMaximumLabelWidth((double) (byte) 100);
        java.awt.Stroke stroke13 = piePlot1.getSectionOutlineStroke((java.lang.Comparable) (short) 0);
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        piePlot15.setForegroundAlpha((float) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor23 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean24 = rectangleInsets22.equals((java.lang.Object) rectangleAnchor23);
        double double26 = rectangleInsets22.calculateBottomInset((double) (-1L));
        piePlot15.setSimpleLabelOffset(rectangleInsets22);
        piePlot1.setInsets(rectangleInsets22);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = piePlot1.getSimpleLabelOffset();
        piePlot1.setIgnoreZeroValues(false);
        piePlot1.setIgnoreNullValues(true);
        java.awt.Graphics2D graphics2D34 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor40 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean41 = rectangleInsets39.equals((java.lang.Object) rectangleAnchor40);
        org.jfree.chart.block.ColumnArrangement columnArrangement42 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer43 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement42);
        java.awt.Graphics2D graphics2D44 = null;
        org.jfree.chart.util.Size2D size2D45 = blockContainer43.arrange(graphics2D44);
        blockContainer43.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D51 = blockContainer43.getBounds();
        java.awt.geom.Rectangle2D rectangle2D54 = rectangleInsets39.createInsetRectangle(rectangle2D51, true, false);
        org.jfree.data.general.PieDataset pieDataset55 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity61 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D54, pieDataset55, 15, 0, (java.lang.Comparable) 1, "hi!", "RectangleEdge.TOP");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor62 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.geom.Point2D point2D63 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D54, rectangleAnchor62);
        org.jfree.data.general.PieDataset pieDataset64 = null;
        org.jfree.chart.plot.PiePlot piePlot65 = new org.jfree.chart.plot.PiePlot(pieDataset64);
        piePlot65.setForegroundAlpha(0.0f);
        piePlot65.zoom((double) '#');
        org.jfree.data.general.PieDataset pieDataset70 = null;
        org.jfree.chart.plot.PiePlot piePlot71 = new org.jfree.chart.plot.PiePlot(pieDataset70);
        piePlot71.setForegroundAlpha((float) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets78 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor79 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean80 = rectangleInsets78.equals((java.lang.Object) rectangleAnchor79);
        double double82 = rectangleInsets78.calculateBottomInset((double) (-1L));
        piePlot71.setSimpleLabelOffset(rectangleInsets78);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle84 = org.jfree.chart.plot.PieLabelLinkStyle.CUBIC_CURVE;
        piePlot71.setLabelLinkStyle(pieLabelLinkStyle84);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier86 = piePlot71.getDrawingSupplier();
        boolean boolean87 = piePlot65.equals((java.lang.Object) piePlot71);
        java.awt.Paint paint88 = piePlot71.getLabelPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator89 = piePlot71.getLegendLabelGenerator();
        java.awt.Paint paint90 = null;
        piePlot71.setLabelOutlinePaint(paint90);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo93 = null;
        org.jfree.chart.plot.PiePlotState piePlotState94 = piePlot1.initialise(graphics2D34, rectangle2D54, piePlot71, (java.lang.Integer) 3, plotRenderingInfo93);
        org.junit.Assert.assertNull(stroke13);
        org.junit.Assert.assertNotNull(rectangleAnchor23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 100.0d + "'", double26 == 100.0d);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(rectangleAnchor40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(size2D45);
        org.junit.Assert.assertNotNull(rectangle2D51);
        org.junit.Assert.assertNotNull(rectangle2D54);
        org.junit.Assert.assertNotNull(rectangleAnchor62);
        org.junit.Assert.assertNotNull(point2D63);
        org.junit.Assert.assertNotNull(rectangleAnchor79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 100.0d + "'", double82 == 100.0d);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle84);
        org.junit.Assert.assertNotNull(drawingSupplier86);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertNotNull(paint88);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator89);
        org.junit.Assert.assertNotNull(piePlotState94);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.util.Size2D size2D3 = blockContainer1.arrange(graphics2D2);
        blockContainer1.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D9 = blockContainer1.getBounds();
        org.jfree.chart.entity.ChartEntity chartEntity12 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D9, "Multiple Pie Plot", "");
        org.junit.Assert.assertNotNull(size2D3);
        org.junit.Assert.assertNotNull(rectangle2D9);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        piePlot1.setLabelLinkMargin(0.0d);
        boolean boolean8 = piePlot1.getIgnoreZeroValues();
        org.jfree.chart.block.BlockBorder blockBorder13 = new org.jfree.chart.block.BlockBorder(0.0d, 0.025d, (double) 100, (double) (short) 100);
        boolean boolean14 = piePlot1.equals((java.lang.Object) 0.025d);
        java.awt.Stroke stroke15 = piePlot1.getOutlineStroke();
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle0 = org.jfree.chart.plot.PieLabelLinkStyle.STANDARD;
        java.lang.String str1 = pieLabelLinkStyle0.toString();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "PieLabelLinkStyle.STANDARD" + "'", str1.equals("PieLabelLinkStyle.STANDARD"));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.setLicenceName("RectangleAnchor.BOTTOM_LEFT");
        java.awt.Image image3 = projectInfo0.getLogo();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(image3);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = legendTitle1.getLegendItemGraphicPadding();
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        legendTitle1.setBackgroundPaint((java.awt.Paint) color3);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = legendTitle1.getLegendItemGraphicAnchor();
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot(pieDataset7);
        piePlot8.setForegroundAlpha(0.0f);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        piePlot8.setShadowPaint((java.awt.Paint) color11);
        java.awt.Color color13 = java.awt.Color.getColor("JFreeChart version RectangleEdge.TOP.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nTableOrder.BY_ROW", color11);
        legendTitle1.setItemPaint((java.awt.Paint) color11);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = legendTitle1.getPosition();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(rectangleEdge15);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        piePlot2.setForegroundAlpha(0.0f);
        piePlot2.setStartAngle((double) 100L);
        piePlot2.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset9 = null;
        piePlot2.setDataset(pieDataset9);
        org.jfree.data.general.PieDataset pieDataset11 = piePlot2.getDataset();
        java.lang.String str12 = piePlot2.getNoDataMessage();
        java.awt.Color color13 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        piePlot2.setOutlinePaint((java.awt.Paint) color13);
        boolean boolean15 = unitType0.equals((java.lang.Object) color13);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertNull(pieDataset11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        piePlot1.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        piePlot1.setDataset(pieDataset8);
        piePlot1.setMaximumLabelWidth((double) (byte) 100);
        java.awt.Stroke stroke13 = piePlot1.getSectionOutlineStroke((java.lang.Comparable) (short) 0);
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        piePlot15.setForegroundAlpha((float) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor23 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean24 = rectangleInsets22.equals((java.lang.Object) rectangleAnchor23);
        double double26 = rectangleInsets22.calculateBottomInset((double) (-1L));
        piePlot15.setSimpleLabelOffset(rectangleInsets22);
        piePlot1.setInsets(rectangleInsets22);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = piePlot1.getSimpleLabelOffset();
        piePlot1.setIgnoreZeroValues(false);
        org.jfree.chart.JFreeChart jFreeChart32 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        org.jfree.chart.title.TextTitle textTitle33 = jFreeChart32.getTitle();
        java.awt.Paint paint34 = jFreeChart32.getBorderPaint();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo35 = new org.jfree.chart.ui.BasicProjectInfo();
        java.lang.String str36 = basicProjectInfo35.getCopyright();
        org.jfree.chart.ui.Library[] libraryArray37 = basicProjectInfo35.getLibraries();
        org.jfree.chart.ui.Library[] libraryArray38 = basicProjectInfo35.getOptionalLibraries();
        boolean boolean39 = jFreeChart32.equals((java.lang.Object) basicProjectInfo35);
        org.junit.Assert.assertNull(stroke13);
        org.junit.Assert.assertNotNull(rectangleAnchor23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 100.0d + "'", double26 == 100.0d);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNull(textTitle33);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertNotNull(libraryArray37);
        org.junit.Assert.assertNotNull(libraryArray38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        piePlot1.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        piePlot1.setDataset(pieDataset8);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setShadowXOffset((double) '4');
        piePlot1.setBackgroundImageAlpha(0.0f);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        java.lang.String str3 = rectangleEdge2.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge2);
        legendTitle1.setLegendItemGraphicEdge(rectangleEdge2);
        org.jfree.chart.block.BlockFrame blockFrame6 = legendTitle1.getFrame();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = legendTitle1.getItemLabelPadding();
        java.awt.Font font9 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot(pieDataset10);
        piePlot11.setForegroundAlpha((float) 0);
        java.awt.Stroke stroke14 = piePlot11.getBaseSectionOutlineStroke();
        piePlot11.setLabelLinkMargin((double) (-256));
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("PieSection: 0, 100(1)", font9, (org.jfree.chart.plot.Plot) piePlot11, false);
        jFreeChart18.setBorderVisible(false);
        legendTitle1.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart18);
        org.jfree.chart.event.ChartProgressListener chartProgressListener22 = null;
        jFreeChart18.removeProgressListener(chartProgressListener22);
        jFreeChart18.setTextAntiAlias(true);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset26 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot27 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset26);
        org.jfree.data.general.PieDataset pieDataset28 = null;
        org.jfree.chart.plot.PiePlot piePlot29 = new org.jfree.chart.plot.PiePlot(pieDataset28);
        piePlot29.setForegroundAlpha((float) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor37 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean38 = rectangleInsets36.equals((java.lang.Object) rectangleAnchor37);
        double double40 = rectangleInsets36.calculateBottomInset((double) (-1L));
        piePlot29.setSimpleLabelOffset(rectangleInsets36);
        java.awt.Color color42 = java.awt.Color.DARK_GRAY;
        piePlot29.setBackgroundPaint((java.awt.Paint) color42);
        boolean boolean44 = defaultCategoryDataset26.hasListener((java.util.EventListener) piePlot29);
        piePlot29.zoom((double) (short) 0);
        org.jfree.data.general.DatasetGroup datasetGroup47 = piePlot29.getDatasetGroup();
        java.awt.Stroke stroke48 = piePlot29.getLabelLinkStroke();
        jFreeChart18.setBorderStroke(stroke48);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleEdge.TOP" + "'", str3.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(blockFrame6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(rectangleAnchor37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 100.0d + "'", double40 == 100.0d);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNull(datasetGroup47);
        org.junit.Assert.assertNotNull(stroke48);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = legendTitle1.getLegendItemGraphicPadding();
        double double3 = rectangleInsets2.getBottom();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        java.awt.Stroke stroke6 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        piePlot1.setLabelOutlineStroke(stroke6);
        piePlot1.setMaximumLabelWidth((-1.0d));
        org.jfree.data.general.PieDataset pieDataset10 = piePlot1.getDataset();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle11 = piePlot1.getLabelLinkStyle();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(pieDataset10);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle11);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        java.lang.Object obj2 = legendTitle1.clone();
        org.jfree.chart.block.ColumnArrangement columnArrangement3 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer4 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.util.Size2D size2D6 = blockContainer4.arrange(graphics2D5);
        blockContainer4.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D12 = blockContainer4.getBounds();
        java.util.List list13 = blockContainer4.getBlocks();
        legendTitle1.setWrapper(blockContainer4);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(size2D6);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertNotNull(list13);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font1 = textTitle0.getFont();
        textTitle0.setID("1.2.0-pre");
        java.lang.Object obj4 = textTitle0.clone();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent5 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle0);
        org.jfree.chart.JFreeChart jFreeChart6 = titleChangeEvent5.getChart();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNull(jFreeChart6);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        piePlot1.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        piePlot1.setDataset(pieDataset8);
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        piePlot1.removeChangeListener(plotChangeListener10);
        piePlot1.setExplodePercent((java.lang.Comparable) 181.0d, (double) 15);
        org.jfree.data.general.PieDataset pieDataset16 = null;
        org.jfree.chart.plot.PiePlot piePlot17 = new org.jfree.chart.plot.PiePlot(pieDataset16);
        piePlot17.setForegroundAlpha(0.0f);
        piePlot17.setLabelLinkMargin(4.0d);
        java.awt.Paint paint22 = piePlot17.getShadowPaint();
        piePlot1.setSectionPaint((java.lang.Comparable) 255, paint22);
        org.jfree.data.general.PieDataset pieDataset24 = null;
        org.jfree.chart.plot.PiePlot piePlot25 = new org.jfree.chart.plot.PiePlot(pieDataset24);
        piePlot25.setForegroundAlpha((float) 0);
        boolean boolean28 = piePlot25.getIgnoreZeroValues();
        double double29 = piePlot25.getShadowXOffset();
        org.jfree.chart.JFreeChart jFreeChart30 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot25);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot31 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.util.TableOrder tableOrder32 = org.jfree.chart.util.TableOrder.BY_COLUMN;
        multiplePiePlot31.setDataExtractOrder(tableOrder32);
        java.awt.Font font35 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset36 = null;
        org.jfree.chart.plot.PiePlot piePlot37 = new org.jfree.chart.plot.PiePlot(pieDataset36);
        piePlot37.setForegroundAlpha((float) 0);
        java.awt.Stroke stroke40 = piePlot37.getBaseSectionOutlineStroke();
        piePlot37.setLabelLinkMargin((double) (-256));
        org.jfree.chart.JFreeChart jFreeChart44 = new org.jfree.chart.JFreeChart("PieSection: 0, 100(1)", font35, (org.jfree.chart.plot.Plot) piePlot37, false);
        multiplePiePlot31.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart44);
        boolean boolean46 = jFreeChart30.equals((java.lang.Object) jFreeChart44);
        piePlot1.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart30);
        boolean boolean48 = piePlot1.getIgnoreNullValues();
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 4.0d + "'", double29 == 4.0d);
        org.junit.Assert.assertNotNull(tableOrder32);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha((float) 0);
        java.awt.Stroke stroke4 = piePlot1.getBaseSectionOutlineStroke();
        piePlot1.setLabelLinkMargin((double) (-256));
        double double7 = piePlot1.getLabelGap();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.025d + "'", double7 == 0.025d);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        java.lang.String str1 = basicProjectInfo0.getName();
        basicProjectInfo0.setLicenceName("ChartChangeEventType.DATASET_UPDATED");
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setForegroundAlpha((float) 0);
        java.awt.Stroke stroke6 = piePlot3.getBaseSectionOutlineStroke();
        piePlot3.setLabelLinkMargin((double) (-256));
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("PieSection: 0, 100(1)", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
        jFreeChart10.setBorderVisible(false);
        boolean boolean13 = jFreeChart10.isBorderVisible();
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        piePlot15.setForegroundAlpha(0.0f);
        piePlot15.setStartAngle((double) 100L);
        piePlot15.setForegroundAlpha((float) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement22 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.Block block23 = null;
        java.awt.Stroke stroke24 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        flowArrangement22.add(block23, (java.lang.Object) stroke24);
        piePlot15.setOutlineStroke(stroke24);
        jFreeChart10.setBorderStroke(stroke24);
        java.lang.Object obj28 = jFreeChart10.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = jFreeChart10.getPadding();
        try {
            org.jfree.chart.plot.XYPlot xYPlot30 = jFreeChart10.getXYPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.PiePlot cannot be cast to org.jfree.chart.plot.XYPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertNotNull(rectangleInsets29);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        double double5 = rectangleInsets4.getBottom();
        double double7 = rectangleInsets4.calculateTopOutset((double) (-1));
        java.lang.String str8 = rectangleInsets4.toString();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "RectangleInsets[t=-1.0,l=10.0,b=100.0,r=1.0]" + "'", str8.equals("RectangleInsets[t=-1.0,l=10.0,b=100.0,r=1.0]"));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = legendTitle1.getLegendItemGraphicPadding();
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        legendTitle1.setBackgroundPaint((java.awt.Paint) color3);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = legendTitle1.getLegendItemGraphicAnchor();
        java.awt.Color color6 = java.awt.Color.green;
        java.awt.Color color7 = color6.darker();
        boolean boolean8 = legendTitle1.equals((java.lang.Object) color7);
        org.jfree.chart.block.ColumnArrangement columnArrangement9 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer10 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement9);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.util.Size2D size2D12 = blockContainer10.arrange(graphics2D11);
        blockContainer10.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D18 = blockContainer10.getBounds();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = blockContainer10.getMargin();
        legendTitle1.setWrapper(blockContainer10);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(size2D12);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertNotNull(rectangleInsets19);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        java.awt.Stroke stroke6 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        piePlot1.setLabelOutlineStroke(stroke6);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        piePlot1.setBaseSectionOutlineStroke(stroke8);
        piePlot1.setMaximumLabelWidth((double) (-256));
        boolean boolean12 = piePlot1.getSimpleLabels();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent13 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot1);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj1 = null;
        int int2 = objectList0.indexOf(obj1);
        objectList0.clear();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        piePlot1.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        piePlot1.setDataset(pieDataset8);
        org.jfree.data.general.PieDataset pieDataset10 = piePlot1.getDataset();
        piePlot1.setOutlineVisible(false);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset13 = new org.jfree.data.category.DefaultCategoryDataset();
        java.util.List list14 = defaultCategoryDataset13.getColumnKeys();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent15 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) piePlot1, (org.jfree.data.general.Dataset) defaultCategoryDataset13);
        org.jfree.data.general.PieDataset pieDataset16 = null;
        org.jfree.chart.plot.PiePlot piePlot17 = new org.jfree.chart.plot.PiePlot(pieDataset16);
        piePlot17.setForegroundAlpha((float) 0);
        boolean boolean20 = piePlot17.getIgnoreZeroValues();
        double double21 = piePlot17.getShadowXOffset();
        org.jfree.chart.JFreeChart jFreeChart22 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot17);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo25 = null;
        java.awt.image.BufferedImage bufferedImage26 = jFreeChart22.createBufferedImage((int) 'a', (int) (byte) 100, chartRenderingInfo25);
        java.awt.Image image27 = jFreeChart22.getBackgroundImage();
        org.jfree.chart.title.TextTitle textTitle28 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font29 = textTitle28.getFont();
        org.jfree.chart.util.VerticalAlignment verticalAlignment30 = textTitle28.getVerticalAlignment();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent31 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle28);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType32 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        titleChangeEvent31.setType(chartChangeEventType32);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent34 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) datasetChangeEvent15, jFreeChart22, chartChangeEventType32);
        org.jfree.data.general.Dataset dataset35 = datasetChangeEvent15.getDataset();
        org.junit.Assert.assertNull(pieDataset10);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 4.0d + "'", double21 == 4.0d);
        org.junit.Assert.assertNotNull(bufferedImage26);
        org.junit.Assert.assertNull(image27);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertNotNull(verticalAlignment30);
        org.junit.Assert.assertNotNull(chartChangeEventType32);
        org.junit.Assert.assertNotNull(dataset35);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 0, (int) (byte) 100, (java.lang.Comparable) 1L, "RectangleEdge.TOP", "RectangleEdge.TOP");
        org.jfree.chart.JFreeChart jFreeChart8 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent9 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0, jFreeChart8);
        org.jfree.chart.JFreeChart jFreeChart10 = chartChangeEvent9.getChart();
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        chartChangeEvent9.setChart(jFreeChart11);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot14 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.util.TableOrder tableOrder15 = org.jfree.chart.util.TableOrder.BY_COLUMN;
        multiplePiePlot14.setDataExtractOrder(tableOrder15);
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.chart.plot.Plot) multiplePiePlot14);
        chartChangeEvent9.setChart(jFreeChart17);
        java.awt.Image image19 = jFreeChart17.getBackgroundImage();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNull(jFreeChart10);
        org.junit.Assert.assertNotNull(tableOrder15);
        org.junit.Assert.assertNull(image19);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        java.lang.String str3 = rectangleEdge2.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge2);
        legendTitle1.setLegendItemGraphicEdge(rectangleEdge2);
        java.awt.Paint paint10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder11 = new org.jfree.chart.block.BlockBorder((double) 10, (double) '#', (double) 0L, 0.0d, paint10);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = blockBorder11.getInsets();
        double double14 = rectangleInsets12.calculateLeftOutset(0.025d);
        legendTitle1.setItemLabelPadding(rectangleInsets12);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray16 = legendTitle1.getSources();
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleEdge.TOP" + "'", str3.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 35.0d + "'", double14 == 35.0d);
        org.junit.Assert.assertNotNull(legendItemSourceArray16);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        float float6 = piePlot1.getBackgroundAlpha();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator7 = null;
        piePlot1.setLegendLabelURLGenerator(pieURLGenerator7);
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot(pieDataset10);
        piePlot11.setForegroundAlpha(0.0f);
        piePlot11.setStartAngle((double) 100L);
        piePlot11.setForegroundAlpha((float) (short) 100);
        double double18 = piePlot11.getShadowYOffset();
        java.awt.Stroke stroke19 = piePlot11.getBaseSectionOutlineStroke();
        piePlot1.setSectionOutlineStroke((java.lang.Comparable) 181.0d, stroke19);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 4.0d + "'", double18 == 4.0d);
        org.junit.Assert.assertNotNull(stroke19);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        double double6 = piePlot1.getInteriorGap();
        java.awt.Paint paint7 = piePlot1.getLabelOutlinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = piePlot1.getLabelPadding();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.08d + "'", double6 == 0.08d);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        piePlot1.setForegroundAlpha((float) (short) 100);
        double double8 = piePlot1.getShadowYOffset();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        piePlot1.handleClick(192, 0, plotRenderingInfo11);
        java.awt.Paint paint13 = piePlot1.getBaseSectionOutlinePaint();
        int int14 = piePlot1.getPieIndex();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo15 = new org.jfree.chart.ui.BasicProjectInfo();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo16 = new org.jfree.chart.ui.BasicProjectInfo();
        java.lang.String str17 = basicProjectInfo16.getCopyright();
        basicProjectInfo15.addLibrary((org.jfree.chart.ui.Library) basicProjectInfo16);
        basicProjectInfo16.setName("RectangleEdge.TOP");
        java.awt.Color color21 = java.awt.Color.gray;
        boolean boolean22 = basicProjectInfo16.equals((java.lang.Object) color21);
        int int23 = color21.getBlue();
        piePlot1.setShadowPaint((java.awt.Paint) color21);
        double double25 = piePlot1.getLabelLinkMargin();
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.0d + "'", double8 == 4.0d);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 128 + "'", int23 == 128);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.025d + "'", double25 == 0.025d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 0, (int) (byte) 100, (java.lang.Comparable) 1L, "RectangleEdge.TOP", "RectangleEdge.TOP");
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity14 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset8, (-254), 2, (java.lang.Comparable) "org.jfree.chart.event.ChartChangeEvent[source=0]", "PieSection: 0, 100(1)", "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        java.lang.String str15 = pieSectionEntity14.getToolTipText();
        java.lang.String str16 = pieSectionEntity14.getToolTipText();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PieSection: 0, 100(1)" + "'", str15.equals("PieSection: 0, 100(1)"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "PieSection: 0, 100(1)" + "'", str16.equals("PieSection: 0, 100(1)"));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj1 = null;
        int int2 = objectList0.indexOf(obj1);
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font4 = textTitle3.getFont();
        boolean boolean5 = objectList0.equals((java.lang.Object) font4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha((float) 0);
        boolean boolean4 = piePlot1.getIgnoreZeroValues();
        double double5 = piePlot1.getShadowXOffset();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo9 = null;
        java.awt.image.BufferedImage bufferedImage10 = jFreeChart6.createBufferedImage((int) 'a', (int) (byte) 100, chartRenderingInfo9);
        java.awt.Image image11 = jFreeChart6.getBackgroundImage();
        org.jfree.chart.LegendItemSource legendItemSource12 = null;
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle(legendItemSource12);
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        java.lang.String str15 = rectangleEdge14.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge14);
        legendTitle13.setLegendItemGraphicEdge(rectangleEdge14);
        org.jfree.chart.block.BlockFrame blockFrame18 = legendTitle13.getFrame();
        java.awt.Paint paint23 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder24 = new org.jfree.chart.block.BlockBorder((double) 10, (double) '#', (double) 0L, 0.0d, paint23);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = blockBorder24.getInsets();
        double double27 = rectangleInsets25.calculateLeftOutset(0.025d);
        legendTitle13.setItemLabelPadding(rectangleInsets25);
        jFreeChart6.addSubtitle((org.jfree.chart.title.Title) legendTitle13);
        org.jfree.chart.LegendItemSource legendItemSource30 = null;
        org.jfree.chart.title.LegendTitle legendTitle31 = new org.jfree.chart.title.LegendTitle(legendItemSource30);
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        java.lang.String str33 = rectangleEdge32.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge32);
        legendTitle31.setLegendItemGraphicEdge(rectangleEdge32);
        org.jfree.chart.block.BlockFrame blockFrame36 = legendTitle31.getFrame();
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = legendTitle31.getItemLabelPadding();
        boolean boolean38 = jFreeChart6.equals((java.lang.Object) legendTitle31);
        java.awt.Paint paint39 = legendTitle31.getBackgroundPaint();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(bufferedImage10);
        org.junit.Assert.assertNull(image11);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "RectangleEdge.TOP" + "'", str15.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNotNull(blockFrame18);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 35.0d + "'", double27 == 35.0d);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "RectangleEdge.TOP" + "'", str33.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertNotNull(rectangleEdge34);
        org.junit.Assert.assertNotNull(blockFrame36);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(paint39);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        double double4 = piePlot1.getMaximumExplodePercent();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        boolean boolean2 = flowArrangement0.equals((java.lang.Object) (-1.0d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.util.TableOrder tableOrder2 = org.jfree.chart.util.TableOrder.BY_COLUMN;
        multiplePiePlot1.setDataExtractOrder(tableOrder2);
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.chart.plot.Plot) multiplePiePlot1);
        org.jfree.data.category.CategoryDataset categoryDataset5 = multiplePiePlot1.getDataset();
        double double6 = multiplePiePlot1.getLimit();
        multiplePiePlot1.setAggregatedItemsKey((java.lang.Comparable) 'a');
        org.junit.Assert.assertNotNull(tableOrder2);
        org.junit.Assert.assertNull(categoryDataset5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 0, (int) (byte) 100, (java.lang.Comparable) 1L, "RectangleEdge.TOP", "RectangleEdge.TOP");
        org.jfree.chart.JFreeChart jFreeChart8 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent9 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0, jFreeChart8);
        org.jfree.chart.JFreeChart jFreeChart10 = chartChangeEvent9.getChart();
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        chartChangeEvent9.setChart(jFreeChart11);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot14 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.util.TableOrder tableOrder15 = org.jfree.chart.util.TableOrder.BY_COLUMN;
        multiplePiePlot14.setDataExtractOrder(tableOrder15);
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.chart.plot.Plot) multiplePiePlot14);
        chartChangeEvent9.setChart(jFreeChart17);
        jFreeChart17.setBackgroundImageAlpha((float) 'a');
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double23 = rectangleInsets21.calculateTopOutset((double) 0);
        java.lang.String str24 = rectangleInsets21.toString();
        double double26 = rectangleInsets21.calculateTopOutset((double) '#');
        jFreeChart17.setPadding(rectangleInsets21);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNull(jFreeChart10);
        org.junit.Assert.assertNotNull(tableOrder15);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 4.0d + "'", double23 == 4.0d);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]" + "'", str24.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 4.0d + "'", double26 == 4.0d);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha((float) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean10 = rectangleInsets8.equals((java.lang.Object) rectangleAnchor9);
        double double12 = rectangleInsets8.calculateBottomInset((double) (-1L));
        piePlot1.setSimpleLabelOffset(rectangleInsets8);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle14 = org.jfree.chart.plot.PieLabelLinkStyle.CUBIC_CURVE;
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle14);
        java.lang.String str16 = pieLabelLinkStyle14.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 100.0d + "'", double12 == 100.0d);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "PieLabelLinkStyle.CUBIC_CURVE" + "'", str16.equals("PieLabelLinkStyle.CUBIC_CURVE"));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        piePlot1.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        piePlot1.setDataset(pieDataset8);
        org.jfree.data.general.PieDataset pieDataset10 = piePlot1.getDataset();
        java.lang.String str11 = piePlot1.getNoDataMessage();
        piePlot1.setLabelLinkMargin(89.0d);
        double double14 = piePlot1.getShadowXOffset();
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        piePlot1.setOutlinePaint((java.awt.Paint) color15);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator17 = piePlot1.getLabelGenerator();
        org.junit.Assert.assertNull(pieDataset10);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator17);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        piePlot1.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        piePlot1.setDataset(pieDataset8);
        piePlot1.setMaximumLabelWidth((double) (byte) 100);
        piePlot1.setShadowXOffset((double) (short) 10);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha((float) 0);
        boolean boolean4 = piePlot1.getIgnoreZeroValues();
        double double5 = piePlot1.getShadowXOffset();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot(pieDataset7);
        piePlot8.setForegroundAlpha(0.0f);
        piePlot8.setStartAngle((double) 100L);
        java.awt.Stroke stroke13 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        piePlot8.setLabelOutlineStroke(stroke13);
        double double15 = piePlot8.getLabelLinkMargin();
        java.awt.Paint paint16 = piePlot8.getLabelShadowPaint();
        piePlot8.setStartAngle(35.0d);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent19 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot8);
        jFreeChart6.plotChanged(plotChangeEvent19);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.025d + "'", double15 == 0.025d);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        java.lang.Object obj0 = null;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        piePlot2.setForegroundAlpha(0.0f);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        piePlot2.setShadowPaint((java.awt.Paint) color5);
        piePlot2.setIgnoreZeroValues(true);
        java.awt.Paint paint10 = null;
        piePlot2.setSectionOutlinePaint((java.lang.Comparable) 100.0f, paint10);
        org.jfree.data.general.PieDataset pieDataset12 = piePlot2.getDataset();
        piePlot2.setBackgroundAlpha((float) 192);
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot2);
        try {
            org.jfree.chart.event.ChartChangeEvent chartChangeEvent16 = new org.jfree.chart.event.ChartChangeEvent(obj0, jFreeChart15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(pieDataset12);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.chart.ui.Licences licences0 = org.jfree.chart.ui.Licences.getInstance();
        java.lang.String str1 = licences0.getLGPL();
        java.lang.String str2 = licences0.getGPL();
        org.junit.Assert.assertNotNull(licences0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.chart.PaintMap paintMap0 = new org.jfree.chart.PaintMap();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setForegroundAlpha(0.0f);
        piePlot3.setStartAngle((double) 100L);
        float float8 = piePlot3.getBackgroundAlpha();
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_GREEN;
        piePlot3.setBaseSectionPaint((java.awt.Paint) color9);
        paintMap0.put((java.lang.Comparable) 8.0d, (java.awt.Paint) color9);
        java.awt.Paint paint13 = paintMap0.getPaint((java.lang.Comparable) 1.0E-5d);
        java.awt.Paint paint15 = paintMap0.getPaint((java.lang.Comparable) 10.0d);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 1.0f + "'", float8 == 1.0f);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertNull(paint15);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        piePlot1.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        piePlot1.setDataset(pieDataset8);
        org.jfree.chart.plot.Plot plot10 = piePlot1.getParent();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset11 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) piePlot1, (org.jfree.data.general.Dataset) defaultCategoryDataset11);
        java.lang.Object obj13 = defaultCategoryDataset11.clone();
        int int15 = defaultCategoryDataset11.getRowIndex((java.lang.Comparable) (byte) -1);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot16 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset11);
        org.jfree.data.general.PieDataset pieDataset17 = null;
        org.jfree.chart.plot.PiePlot piePlot18 = new org.jfree.chart.plot.PiePlot(pieDataset17);
        piePlot18.setForegroundAlpha(0.0f);
        piePlot18.setStartAngle((double) 100L);
        double double23 = piePlot18.getInteriorGap();
        piePlot18.setMinimumArcAngleToDraw(0.4d);
        org.jfree.chart.plot.Plot plot26 = piePlot18.getRootPlot();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo27 = new org.jfree.chart.ui.BasicProjectInfo();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo28 = new org.jfree.chart.ui.BasicProjectInfo();
        java.lang.String str29 = basicProjectInfo28.getCopyright();
        basicProjectInfo27.addLibrary((org.jfree.chart.ui.Library) basicProjectInfo28);
        basicProjectInfo28.setName("RectangleEdge.TOP");
        java.awt.Color color33 = java.awt.Color.gray;
        boolean boolean34 = basicProjectInfo28.equals((java.lang.Object) color33);
        int int35 = color33.getBlue();
        piePlot18.setLabelPaint((java.awt.Paint) color33);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator37 = piePlot18.getURLGenerator();
        defaultCategoryDataset11.addChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot18);
        org.junit.Assert.assertNull(plot10);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.08d + "'", double23 == 0.08d);
        org.junit.Assert.assertNotNull(plot26);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 128 + "'", int35 == 128);
        org.junit.Assert.assertNull(pieURLGenerator37);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        piePlot1.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        piePlot1.setDataset(pieDataset8);
        org.jfree.data.general.PieDataset pieDataset10 = piePlot1.getDataset();
        piePlot1.setOutlineVisible(false);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset13 = new org.jfree.data.category.DefaultCategoryDataset();
        java.util.List list14 = defaultCategoryDataset13.getColumnKeys();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent15 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) piePlot1, (org.jfree.data.general.Dataset) defaultCategoryDataset13);
        org.jfree.data.general.PieDataset pieDataset16 = null;
        org.jfree.chart.plot.PiePlot piePlot17 = new org.jfree.chart.plot.PiePlot(pieDataset16);
        piePlot17.setForegroundAlpha((float) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor25 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean26 = rectangleInsets24.equals((java.lang.Object) rectangleAnchor25);
        double double28 = rectangleInsets24.calculateBottomInset((double) (-1L));
        piePlot17.setSimpleLabelOffset(rectangleInsets24);
        java.awt.Stroke stroke30 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        piePlot17.setLabelLinkStroke(stroke30);
        piePlot1.setLabelOutlineStroke(stroke30);
        org.junit.Assert.assertNull(pieDataset10);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(rectangleAnchor25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 100.0d + "'", double28 == 100.0d);
        org.junit.Assert.assertNotNull(stroke30);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha((float) 0);
        boolean boolean4 = piePlot1.getIgnoreZeroValues();
        double double5 = piePlot1.getShadowXOffset();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo9 = null;
        java.awt.image.BufferedImage bufferedImage10 = jFreeChart6.createBufferedImage((int) 'a', (int) (byte) 100, chartRenderingInfo9);
        jFreeChart6.setNotify(false);
        org.jfree.chart.event.ChartChangeListener chartChangeListener13 = null;
        try {
            jFreeChart6.addChangeListener(chartChangeListener13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(bufferedImage10);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha((float) 0);
        boolean boolean4 = piePlot1.getIgnoreZeroValues();
        double double5 = piePlot1.getShadowXOffset();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo9 = null;
        java.awt.image.BufferedImage bufferedImage10 = jFreeChart6.createBufferedImage((int) 'a', (int) (byte) 100, chartRenderingInfo9);
        java.awt.Image image11 = jFreeChart6.getBackgroundImage();
        org.jfree.chart.LegendItemSource legendItemSource12 = null;
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle(legendItemSource12);
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        java.lang.String str15 = rectangleEdge14.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge14);
        legendTitle13.setLegendItemGraphicEdge(rectangleEdge14);
        org.jfree.chart.block.BlockFrame blockFrame18 = legendTitle13.getFrame();
        java.awt.Paint paint23 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder24 = new org.jfree.chart.block.BlockBorder((double) 10, (double) '#', (double) 0L, 0.0d, paint23);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = blockBorder24.getInsets();
        double double27 = rectangleInsets25.calculateLeftOutset(0.025d);
        legendTitle13.setItemLabelPadding(rectangleInsets25);
        jFreeChart6.addSubtitle((org.jfree.chart.title.Title) legendTitle13);
        org.jfree.chart.LegendItemSource legendItemSource30 = null;
        org.jfree.chart.title.LegendTitle legendTitle31 = new org.jfree.chart.title.LegendTitle(legendItemSource30);
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        java.lang.String str33 = rectangleEdge32.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge32);
        legendTitle31.setLegendItemGraphicEdge(rectangleEdge32);
        org.jfree.chart.block.BlockFrame blockFrame36 = legendTitle31.getFrame();
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = legendTitle31.getItemLabelPadding();
        boolean boolean38 = jFreeChart6.equals((java.lang.Object) legendTitle31);
        java.awt.Graphics2D graphics2D39 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint40 = null;
        try {
            org.jfree.chart.util.Size2D size2D41 = legendTitle31.arrange(graphics2D39, rectangleConstraint40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(bufferedImage10);
        org.junit.Assert.assertNull(image11);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "RectangleEdge.TOP" + "'", str15.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNotNull(blockFrame18);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 35.0d + "'", double27 == 35.0d);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "RectangleEdge.TOP" + "'", str33.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertNotNull(rectangleEdge34);
        org.junit.Assert.assertNotNull(blockFrame36);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        java.awt.Color color0 = java.awt.Color.ORANGE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean6 = rectangleInsets4.equals((java.lang.Object) rectangleAnchor5);
        java.lang.String str7 = rectangleAnchor5.toString();
        java.lang.String str8 = rectangleAnchor5.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "RectangleAnchor.CENTER" + "'", str7.equals("RectangleAnchor.CENTER"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "RectangleAnchor.CENTER" + "'", str8.equals("RectangleAnchor.CENTER"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) (byte) 10, (double) 2, (double) 0L, (double) (short) 0);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot5 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.util.TableOrder tableOrder6 = org.jfree.chart.util.TableOrder.BY_COLUMN;
        multiplePiePlot5.setDataExtractOrder(tableOrder6);
        java.awt.Font font9 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot(pieDataset10);
        piePlot11.setForegroundAlpha((float) 0);
        java.awt.Stroke stroke14 = piePlot11.getBaseSectionOutlineStroke();
        piePlot11.setLabelLinkMargin((double) (-256));
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("PieSection: 0, 100(1)", font9, (org.jfree.chart.plot.Plot) piePlot11, false);
        multiplePiePlot5.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart18);
        boolean boolean20 = blockBorder4.equals((java.lang.Object) jFreeChart18);
        org.jfree.chart.title.Title title21 = null;
        try {
            jFreeChart18.addSubtitle(title21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'subtitle' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(tableOrder6);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        piePlot1.setShadowPaint((java.awt.Paint) color4);
        piePlot1.setIgnoreZeroValues(true);
        java.awt.Paint paint9 = null;
        piePlot1.setSectionOutlinePaint((java.lang.Comparable) 100.0f, paint9);
        org.jfree.data.general.PieDataset pieDataset11 = piePlot1.getDataset();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        piePlot1.handleClick((int) '#', (int) ' ', plotRenderingInfo14);
        org.jfree.data.general.PieDataset pieDataset16 = null;
        org.jfree.chart.plot.PiePlot piePlot17 = new org.jfree.chart.plot.PiePlot(pieDataset16);
        piePlot17.setForegroundAlpha((float) 0);
        boolean boolean20 = piePlot17.getIgnoreZeroValues();
        double double21 = piePlot17.getShadowXOffset();
        org.jfree.chart.JFreeChart jFreeChart22 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot17);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot23 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.util.TableOrder tableOrder24 = org.jfree.chart.util.TableOrder.BY_COLUMN;
        multiplePiePlot23.setDataExtractOrder(tableOrder24);
        java.awt.Font font27 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset28 = null;
        org.jfree.chart.plot.PiePlot piePlot29 = new org.jfree.chart.plot.PiePlot(pieDataset28);
        piePlot29.setForegroundAlpha((float) 0);
        java.awt.Stroke stroke32 = piePlot29.getBaseSectionOutlineStroke();
        piePlot29.setLabelLinkMargin((double) (-256));
        org.jfree.chart.JFreeChart jFreeChart36 = new org.jfree.chart.JFreeChart("PieSection: 0, 100(1)", font27, (org.jfree.chart.plot.Plot) piePlot29, false);
        multiplePiePlot23.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart36);
        boolean boolean38 = jFreeChart22.equals((java.lang.Object) jFreeChart36);
        java.awt.Paint paint39 = jFreeChart22.getBorderPaint();
        piePlot1.setShadowPaint(paint39);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(pieDataset11);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 4.0d + "'", double21 == 4.0d);
        org.junit.Assert.assertNotNull(tableOrder24);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(paint39);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.block.BlockBorder blockBorder2 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color1);
        multiplePiePlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.ui.Contributor contributor6 = new org.jfree.chart.ui.Contributor("RectangleEdge.TOP", "RectangleEdge.TOP");
        java.lang.String str7 = contributor6.getName();
        boolean boolean8 = multiplePiePlot0.equals((java.lang.Object) contributor6);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        jFreeChart9.setTextAntiAlias(false);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "RectangleEdge.TOP" + "'", str7.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        java.awt.Paint paint4 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder((double) 10, (double) '#', (double) 0L, 0.0d, paint4);
        java.awt.Color color10 = java.awt.Color.LIGHT_GRAY;
        int int11 = color10.getGreen();
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder(10.0d, (double) 0L, (double) 0, (double) (byte) -1, (java.awt.Paint) color10);
        java.awt.Paint paint13 = blockBorder12.getPaint();
        boolean boolean14 = blockBorder5.equals((java.lang.Object) paint13);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 192 + "'", int11 == 192);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.util.TableOrder tableOrder2 = org.jfree.chart.util.TableOrder.BY_COLUMN;
        multiplePiePlot1.setDataExtractOrder(tableOrder2);
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.chart.plot.Plot) multiplePiePlot1);
        multiplePiePlot1.setForegroundAlpha((float) 15);
        java.awt.Font font8 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        piePlot10.setForegroundAlpha((float) 0);
        java.awt.Stroke stroke13 = piePlot10.getBaseSectionOutlineStroke();
        piePlot10.setLabelLinkMargin((double) (-256));
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("PieSection: 0, 100(1)", font8, (org.jfree.chart.plot.Plot) piePlot10, false);
        jFreeChart17.setBorderVisible(false);
        org.jfree.chart.plot.Plot plot20 = jFreeChart17.getPlot();
        multiplePiePlot1.setPieChart(jFreeChart17);
        org.junit.Assert.assertNotNull(tableOrder2);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(plot20);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.util.Size2D size2D3 = blockContainer1.arrange(graphics2D2);
        blockContainer1.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D9 = blockContainer1.getBounds();
        blockContainer1.clear();
        org.jfree.chart.block.Arrangement arrangement11 = blockContainer1.getArrangement();
        org.junit.Assert.assertNotNull(size2D3);
        org.junit.Assert.assertNotNull(rectangle2D9);
        org.junit.Assert.assertNotNull(arrangement11);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        piePlot1.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        piePlot1.setDataset(pieDataset8);
        piePlot1.setMaximumLabelWidth((double) (byte) 100);
        java.awt.Stroke stroke13 = piePlot1.getSectionOutlineStroke((java.lang.Comparable) (short) 0);
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        piePlot15.setForegroundAlpha((float) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor23 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean24 = rectangleInsets22.equals((java.lang.Object) rectangleAnchor23);
        double double26 = rectangleInsets22.calculateBottomInset((double) (-1L));
        piePlot15.setSimpleLabelOffset(rectangleInsets22);
        piePlot1.setInsets(rectangleInsets22);
        java.awt.Color color29 = java.awt.Color.BLUE;
        piePlot1.setLabelLinkPaint((java.awt.Paint) color29);
        boolean boolean31 = piePlot1.isOutlineVisible();
        org.junit.Assert.assertNull(stroke13);
        org.junit.Assert.assertNotNull(rectangleAnchor23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 100.0d + "'", double26 == 100.0d);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        piePlot1.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        piePlot1.setDataset(pieDataset8);
        org.jfree.data.general.PieDataset pieDataset10 = piePlot1.getDataset();
        piePlot1.setOutlineVisible(false);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset13 = new org.jfree.data.category.DefaultCategoryDataset();
        java.util.List list14 = defaultCategoryDataset13.getColumnKeys();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent15 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) piePlot1, (org.jfree.data.general.Dataset) defaultCategoryDataset13);
        java.lang.Object obj16 = defaultCategoryDataset13.clone();
        org.junit.Assert.assertNull(pieDataset10);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(obj16);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha((float) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean10 = rectangleInsets8.equals((java.lang.Object) rectangleAnchor9);
        double double12 = rectangleInsets8.calculateBottomInset((double) (-1L));
        piePlot1.setSimpleLabelOffset(rectangleInsets8);
        java.awt.Paint paint14 = piePlot1.getLabelOutlinePaint();
        org.jfree.data.general.DatasetGroup datasetGroup15 = piePlot1.getDatasetGroup();
        java.lang.String str16 = piePlot1.getNoDataMessage();
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 100.0d + "'", double12 == 100.0d);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(datasetGroup15);
        org.junit.Assert.assertNull(str16);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.block.BlockBorder blockBorder2 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color1);
        multiplePiePlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.util.TableOrder tableOrder4 = org.jfree.chart.util.TableOrder.BY_ROW;
        multiplePiePlot0.setDataExtractOrder(tableOrder4);
        double double6 = multiplePiePlot0.getLimit();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = multiplePiePlot0.getLegendItems();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(tableOrder4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(legendItemCollection7);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = textTitle1.getTextAlignment();
        textTitle1.setURLText("RectangleEdge.TOP");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = textTitle1.getHorizontalAlignment();
        java.lang.Object obj6 = textTitle1.clone();
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertNotNull(horizontalAlignment5);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Comparable comparable1 = null;
        try {
            int int2 = defaultCategoryDataset0.getColumnIndex(comparable1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        piePlot1.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        piePlot1.setDataset(pieDataset8);
        piePlot1.setMaximumLabelWidth((double) (byte) 100);
        org.jfree.data.general.PieDataset pieDataset12 = piePlot1.getDataset();
        double double13 = piePlot1.getLabelLinkMargin();
        boolean boolean14 = piePlot1.getSimpleLabels();
        org.junit.Assert.assertNull(pieDataset12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setForegroundAlpha(0.0f);
        piePlot3.setStartAngle((double) 100L);
        piePlot3.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset10 = null;
        piePlot3.setDataset(pieDataset10);
        org.jfree.data.general.PieDataset pieDataset12 = piePlot3.getDataset();
        java.lang.String str13 = piePlot3.getNoDataMessage();
        piePlot3.setLabelLinkMargin((double) 0.5f);
        java.awt.Paint paint16 = piePlot3.getNoDataMessagePaint();
        java.awt.Color color17 = java.awt.Color.BLACK;
        piePlot3.setBaseSectionOutlinePaint((java.awt.Paint) color17);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.color.ColorSpace colorSpace20 = color19.getColorSpace();
        java.awt.Color color21 = java.awt.Color.GREEN;
        float[] floatArray26 = new float[] { (byte) 1, (short) 0, (short) 100, (short) -1 };
        float[] floatArray27 = color21.getComponents(floatArray26);
        float[] floatArray28 = color17.getComponents(colorSpace20, floatArray27);
        float[] floatArray29 = null;
        float[] floatArray30 = color1.getColorComponents(colorSpace20, floatArray29);
        org.jfree.data.general.PieDataset pieDataset31 = null;
        org.jfree.chart.plot.PiePlot piePlot32 = new org.jfree.chart.plot.PiePlot(pieDataset31);
        piePlot32.setForegroundAlpha(0.0f);
        piePlot32.setStartAngle((double) 100L);
        double double37 = piePlot32.getInteriorGap();
        piePlot32.setMinimumArcAngleToDraw(0.4d);
        org.jfree.chart.plot.Plot plot40 = piePlot32.getRootPlot();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo41 = new org.jfree.chart.ui.BasicProjectInfo();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo42 = new org.jfree.chart.ui.BasicProjectInfo();
        java.lang.String str43 = basicProjectInfo42.getCopyright();
        basicProjectInfo41.addLibrary((org.jfree.chart.ui.Library) basicProjectInfo42);
        basicProjectInfo42.setName("RectangleEdge.TOP");
        java.awt.Color color47 = java.awt.Color.gray;
        boolean boolean48 = basicProjectInfo42.equals((java.lang.Object) color47);
        int int49 = color47.getBlue();
        piePlot32.setLabelPaint((java.awt.Paint) color47);
        java.awt.Color color54 = java.awt.Color.GREEN;
        float[] floatArray59 = new float[] { (byte) 1, (short) 0, (short) 100, (short) -1 };
        float[] floatArray60 = color54.getComponents(floatArray59);
        float[] floatArray61 = java.awt.Color.RGBtoHSB(10, (-262450), 15, floatArray60);
        float[] floatArray62 = color47.getColorComponents(floatArray60);
        float[] floatArray63 = color0.getColorComponents(colorSpace20, floatArray62);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNull(pieDataset12);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(colorSpace20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(floatArray26);
        org.junit.Assert.assertNotNull(floatArray27);
        org.junit.Assert.assertNotNull(floatArray28);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.08d + "'", double37 == 0.08d);
        org.junit.Assert.assertNotNull(plot40);
        org.junit.Assert.assertNull(str43);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 128 + "'", int49 == 128);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertNotNull(floatArray59);
        org.junit.Assert.assertNotNull(floatArray60);
        org.junit.Assert.assertNotNull(floatArray61);
        org.junit.Assert.assertNotNull(floatArray62);
        org.junit.Assert.assertNotNull(floatArray63);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement3 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer4 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.util.Size2D size2D6 = blockContainer4.arrange(graphics2D5);
        blockContainer4.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D12 = blockContainer4.getBounds();
        java.lang.Object obj14 = textTitle1.draw(graphics2D2, rectangle2D12, (java.lang.Object) (short) 0);
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment17 = textTitle16.getTextAlignment();
        java.lang.String str18 = horizontalAlignment17.toString();
        textTitle1.setHorizontalAlignment(horizontalAlignment17);
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font21 = textTitle20.getFont();
        org.jfree.chart.util.VerticalAlignment verticalAlignment22 = textTitle20.getVerticalAlignment();
        textTitle1.setVerticalAlignment(verticalAlignment22);
        textTitle1.setURLText("Rotation.ANTICLOCKWISE");
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = textTitle1.getMargin();
        double double27 = textTitle1.getWidth();
        org.junit.Assert.assertNotNull(size2D6);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertNull(obj14);
        org.junit.Assert.assertNotNull(horizontalAlignment17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "HorizontalAlignment.CENTER" + "'", str18.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(verticalAlignment22);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean10 = rectangleInsets8.equals((java.lang.Object) rectangleAnchor9);
        double double12 = rectangleInsets8.calculateTopInset(0.0d);
        piePlot1.setInsets(rectangleInsets8);
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        piePlot15.setForegroundAlpha((float) 0);
        boolean boolean18 = piePlot15.getIgnoreZeroValues();
        double double19 = piePlot15.getShadowXOffset();
        java.awt.Stroke stroke20 = piePlot15.getLabelLinkStroke();
        piePlot1.setBaseSectionOutlineStroke(stroke20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        piePlot1.handleClick(255, (int) (short) 0, plotRenderingInfo24);
        org.jfree.data.general.PieDataset pieDataset26 = null;
        org.jfree.chart.plot.PiePlot piePlot27 = new org.jfree.chart.plot.PiePlot(pieDataset26);
        piePlot27.setForegroundAlpha(0.0f);
        piePlot27.setStartAngle((double) 100L);
        double double32 = piePlot27.getInteriorGap();
        java.awt.Paint paint33 = piePlot27.getLabelOutlinePaint();
        java.awt.Color color36 = java.awt.Color.getColor("RectangleEdge.TOP", (int) (short) 1);
        org.jfree.chart.ChartColor chartColor40 = new org.jfree.chart.ChartColor(15, 192, (int) (short) 10);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType41 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.awt.Color color42 = java.awt.Color.GREEN;
        boolean boolean43 = chartChangeEventType41.equals((java.lang.Object) color42);
        java.awt.Color color44 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        int int45 = color44.getTransparency();
        java.awt.Color color46 = java.awt.Color.BLACK;
        java.awt.Color color47 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        java.awt.Paint[] paintArray48 = new java.awt.Paint[] { color36, chartColor40, color42, color44, color46, color47 };
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType49 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.awt.Color color50 = java.awt.Color.GREEN;
        boolean boolean51 = chartChangeEventType49.equals((java.lang.Object) color50);
        java.awt.Paint paint56 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder57 = new org.jfree.chart.block.BlockBorder((double) 10, (double) '#', (double) 0L, 0.0d, paint56);
        java.awt.Color color58 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.Paint[] paintArray59 = new java.awt.Paint[] { color50, paint56, color58 };
        java.awt.Paint[] paintArray60 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray61 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray62 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray63 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier64 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray48, paintArray59, paintArray60, strokeArray61, strokeArray62, shapeArray63);
        piePlot27.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier64);
        java.awt.Paint paint66 = defaultDrawingSupplier64.getNextFillPaint();
        java.awt.Stroke stroke67 = defaultDrawingSupplier64.getNextStroke();
        piePlot1.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier64);
        try {
            java.awt.Shape shape69 = defaultDrawingSupplier64.getNextShape();
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.0d) + "'", double12 == (-1.0d));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 4.0d + "'", double19 == 4.0d);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.08d + "'", double32 == 0.08d);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(chartChangeEventType41);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(paintArray48);
        org.junit.Assert.assertNotNull(chartChangeEventType49);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(paint56);
        org.junit.Assert.assertNotNull(color58);
        org.junit.Assert.assertNotNull(paintArray59);
        org.junit.Assert.assertNotNull(paintArray60);
        org.junit.Assert.assertNotNull(strokeArray61);
        org.junit.Assert.assertNotNull(strokeArray62);
        org.junit.Assert.assertNotNull(shapeArray63);
        org.junit.Assert.assertNotNull(paint66);
        org.junit.Assert.assertNotNull(stroke67);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.ANTICLOCKWISE;
        java.lang.String str1 = rotation0.toString();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = textTitle3.getTextAlignment();
        boolean boolean5 = rotation0.equals((java.lang.Object) horizontalAlignment4);
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("");
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        textTitle7.setBackgroundPaint((java.awt.Paint) color8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        java.awt.Color color11 = color10.brighter();
        textTitle7.setPaint((java.awt.Paint) color11);
        boolean boolean13 = rotation0.equals((java.lang.Object) textTitle7);
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font15 = textTitle14.getFont();
        org.jfree.chart.util.VerticalAlignment verticalAlignment16 = textTitle14.getVerticalAlignment();
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D19 = new org.jfree.data.DefaultKeyedValues2D();
        java.awt.Color color20 = java.awt.Color.GREEN;
        float[] floatArray25 = new float[] { (byte) 1, (short) 0, (short) 100, (short) -1 };
        float[] floatArray26 = color20.getComponents(floatArray25);
        boolean boolean27 = defaultKeyedValues2D19.equals((java.lang.Object) floatArray26);
        int int28 = defaultKeyedValues2D19.getColumnCount();
        int int29 = defaultKeyedValues2D19.getColumnCount();
        java.util.List list30 = defaultKeyedValues2D19.getColumnKeys();
        java.lang.Number number31 = null;
        defaultKeyedValues2D19.setValue(number31, (java.lang.Comparable) 192, (java.lang.Comparable) 1);
        java.lang.Object obj35 = textTitle14.draw(graphics2D17, rectangle2D18, (java.lang.Object) 192);
        boolean boolean36 = rotation0.equals(obj35);
        java.lang.String str37 = rotation0.toString();
        org.junit.Assert.assertNotNull(rotation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Rotation.ANTICLOCKWISE" + "'", str1.equals("Rotation.ANTICLOCKWISE"));
        org.junit.Assert.assertNotNull(horizontalAlignment4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(verticalAlignment16);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(floatArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(list30);
        org.junit.Assert.assertNull(obj35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "Rotation.ANTICLOCKWISE" + "'", str37.equals("Rotation.ANTICLOCKWISE"));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        float float6 = piePlot1.getBackgroundAlpha();
        piePlot1.setShadowYOffset((double) 100.0f);
        java.awt.Color color9 = java.awt.Color.magenta;
        piePlot1.setBaseSectionOutlinePaint((java.awt.Paint) color9);
        double double11 = piePlot1.getShadowYOffset();
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 100.0d + "'", double11 == 100.0d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("", "UnitType.RELATIVE", "4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0", "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        java.awt.Shape shape6 = piePlot1.getLegendItemShape();
        java.awt.Font font7 = piePlot1.getLabelFont();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(font7);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        java.lang.Object obj2 = legendTitle1.clone();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        piePlot4.setForegroundAlpha(0.0f);
        piePlot4.setStartAngle((double) 100L);
        piePlot4.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset11 = null;
        piePlot4.setDataset(pieDataset11);
        piePlot4.setMaximumLabelWidth((double) (byte) 100);
        java.awt.Stroke stroke16 = piePlot4.getSectionOutlineStroke((java.lang.Comparable) (short) 0);
        org.jfree.data.general.PieDataset pieDataset17 = null;
        org.jfree.chart.plot.PiePlot piePlot18 = new org.jfree.chart.plot.PiePlot(pieDataset17);
        piePlot18.setForegroundAlpha(0.0f);
        piePlot18.setStartAngle((double) 100L);
        java.awt.Shape shape23 = piePlot18.getLegendItemShape();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent24 = null;
        piePlot18.axisChanged(axisChangeEvent24);
        java.awt.Color color27 = java.awt.Color.red;
        piePlot18.setSectionPaint((java.lang.Comparable) 90.0d, (java.awt.Paint) color27);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray29 = new org.jfree.chart.LegendItemSource[] { piePlot4, piePlot18 };
        legendTitle1.setSources(legendItemSourceArray29);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = legendTitle1.getItemLabelPadding();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNull(stroke16);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(legendItemSourceArray29);
        org.junit.Assert.assertNotNull(rectangleInsets31);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        java.lang.Object obj2 = legendTitle1.clone();
        java.awt.Paint paint3 = legendTitle1.getItemPaint();
        boolean boolean5 = legendTitle1.equals((java.lang.Object) '4');
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement3 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer4 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.util.Size2D size2D6 = blockContainer4.arrange(graphics2D5);
        blockContainer4.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D12 = blockContainer4.getBounds();
        java.lang.Object obj14 = textTitle1.draw(graphics2D2, rectangle2D12, (java.lang.Object) (short) 0);
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment17 = textTitle16.getTextAlignment();
        java.lang.String str18 = horizontalAlignment17.toString();
        textTitle1.setHorizontalAlignment(horizontalAlignment17);
        boolean boolean20 = textTitle1.getNotify();
        org.junit.Assert.assertNotNull(size2D6);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertNull(obj14);
        org.junit.Assert.assertNotNull(horizontalAlignment17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "HorizontalAlignment.CENTER" + "'", str18.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font1 = textTitle0.getFont();
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = textTitle0.getVerticalAlignment();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle0);
        java.lang.Object obj4 = titleChangeEvent3.getSource();
        java.awt.Font font6 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot(pieDataset7);
        piePlot8.setForegroundAlpha((float) 0);
        java.awt.Stroke stroke11 = piePlot8.getBaseSectionOutlineStroke();
        piePlot8.setLabelLinkMargin((double) (-256));
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("PieSection: 0, 100(1)", font6, (org.jfree.chart.plot.Plot) piePlot8, false);
        jFreeChart15.setBorderVisible(false);
        boolean boolean18 = jFreeChart15.isBorderVisible();
        titleChangeEvent3.setChart(jFreeChart15);
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font21 = textTitle20.getFont();
        org.jfree.chart.util.VerticalAlignment verticalAlignment22 = textTitle20.getVerticalAlignment();
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D25 = new org.jfree.data.DefaultKeyedValues2D();
        java.awt.Color color26 = java.awt.Color.GREEN;
        float[] floatArray31 = new float[] { (byte) 1, (short) 0, (short) 100, (short) -1 };
        float[] floatArray32 = color26.getComponents(floatArray31);
        boolean boolean33 = defaultKeyedValues2D25.equals((java.lang.Object) floatArray32);
        int int34 = defaultKeyedValues2D25.getColumnCount();
        int int35 = defaultKeyedValues2D25.getColumnCount();
        java.util.List list36 = defaultKeyedValues2D25.getColumnKeys();
        java.lang.Number number37 = null;
        defaultKeyedValues2D25.setValue(number37, (java.lang.Comparable) 192, (java.lang.Comparable) 1);
        java.lang.Object obj41 = textTitle20.draw(graphics2D23, rectangle2D24, (java.lang.Object) 192);
        jFreeChart15.setTitle(textTitle20);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(verticalAlignment22);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(list36);
        org.junit.Assert.assertNull(obj41);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        piePlot1.setForegroundAlpha((float) (short) 100);
        double double8 = piePlot1.getShadowYOffset();
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        piePlot10.setForegroundAlpha(0.0f);
        piePlot10.setStartAngle((double) 100L);
        piePlot10.setForegroundAlpha((float) (short) 100);
        double double17 = piePlot10.getShadowYOffset();
        piePlot1.setParent((org.jfree.chart.plot.Plot) piePlot10);
        float float19 = piePlot10.getBackgroundAlpha();
        org.jfree.data.general.PieDataset pieDataset20 = null;
        org.jfree.chart.plot.PiePlot piePlot21 = new org.jfree.chart.plot.PiePlot(pieDataset20);
        piePlot21.setForegroundAlpha((float) 0);
        boolean boolean24 = piePlot21.getIgnoreZeroValues();
        double double25 = piePlot21.getShadowXOffset();
        java.awt.Stroke stroke26 = piePlot21.getLabelLinkStroke();
        java.awt.Paint paint27 = piePlot21.getBaseSectionPaint();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle28 = org.jfree.chart.plot.PieLabelLinkStyle.CUBIC_CURVE;
        piePlot21.setLabelLinkStyle(pieLabelLinkStyle28);
        piePlot10.setLabelLinkStyle(pieLabelLinkStyle28);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.0d + "'", double8 == 4.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 4.0d + "'", double17 == 4.0d);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 1.0f + "'", float19 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 4.0d + "'", double25 == 4.0d);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle28);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setForegroundAlpha((float) 0);
        java.awt.Stroke stroke6 = piePlot3.getBaseSectionOutlineStroke();
        piePlot3.setLabelLinkMargin((double) (-256));
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("PieSection: 0, 100(1)", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
        jFreeChart10.setBorderVisible(false);
        boolean boolean13 = jFreeChart10.isBorderVisible();
        jFreeChart10.setBackgroundImageAlpha(0.0f);
        org.jfree.data.general.PieDataset pieDataset16 = null;
        org.jfree.chart.plot.PiePlot piePlot17 = new org.jfree.chart.plot.PiePlot(pieDataset16);
        piePlot17.setForegroundAlpha(0.0f);
        piePlot17.setStartAngle((double) 100L);
        piePlot17.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset24 = null;
        piePlot17.setDataset(pieDataset24);
        org.jfree.data.general.PieDataset pieDataset26 = piePlot17.getDataset();
        java.lang.String str27 = piePlot17.getNoDataMessage();
        piePlot17.setLabelLinkMargin((double) 0.5f);
        java.awt.Paint paint30 = piePlot17.getNoDataMessagePaint();
        java.awt.Color color31 = java.awt.Color.BLACK;
        piePlot17.setBaseSectionOutlinePaint((java.awt.Paint) color31);
        java.awt.Color color33 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.color.ColorSpace colorSpace34 = color33.getColorSpace();
        java.awt.Color color35 = java.awt.Color.GREEN;
        float[] floatArray40 = new float[] { (byte) 1, (short) 0, (short) 100, (short) -1 };
        float[] floatArray41 = color35.getComponents(floatArray40);
        float[] floatArray42 = color31.getComponents(colorSpace34, floatArray41);
        java.awt.color.ColorSpace colorSpace43 = color31.getColorSpace();
        boolean boolean44 = jFreeChart10.equals((java.lang.Object) color31);
        java.awt.Paint paint45 = jFreeChart10.getBorderPaint();
        java.awt.Graphics2D graphics2D46 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = new org.jfree.chart.util.RectangleInsets();
        org.jfree.data.general.PieDataset pieDataset48 = null;
        org.jfree.chart.plot.PiePlot piePlot49 = new org.jfree.chart.plot.PiePlot(pieDataset48);
        piePlot49.setForegroundAlpha(0.0f);
        piePlot49.setStartAngle((double) 100L);
        piePlot49.setForegroundAlpha((float) (short) 100);
        double double56 = piePlot49.getShadowYOffset();
        java.awt.Stroke stroke57 = piePlot49.getBaseSectionOutlineStroke();
        java.awt.Graphics2D graphics2D58 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement59 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer60 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement59);
        java.awt.Graphics2D graphics2D61 = null;
        org.jfree.chart.util.Size2D size2D62 = blockContainer60.arrange(graphics2D61);
        java.lang.Object obj63 = null;
        boolean boolean64 = blockContainer60.equals(obj63);
        java.lang.Class<?> wildcardClass65 = blockContainer60.getClass();
        java.awt.geom.Rectangle2D rectangle2D66 = blockContainer60.getBounds();
        org.jfree.chart.entity.ChartEntity chartEntity68 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D66, "JFreeChart version RectangleAnchor.BOTTOM_LEFT.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nTableOrder.BY_ROW");
        piePlot49.drawBackgroundImage(graphics2D58, rectangle2D66);
        java.awt.geom.Rectangle2D rectangle2D72 = rectangleInsets47.createOutsetRectangle(rectangle2D66, true, true);
        try {
            jFreeChart10.draw(graphics2D46, rectangle2D66);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(pieDataset26);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(colorSpace34);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(floatArray40);
        org.junit.Assert.assertNotNull(floatArray41);
        org.junit.Assert.assertNotNull(floatArray42);
        org.junit.Assert.assertNotNull(colorSpace43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 4.0d + "'", double56 == 4.0d);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertNotNull(size2D62);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(wildcardClass65);
        org.junit.Assert.assertNotNull(rectangle2D66);
        org.junit.Assert.assertNotNull(rectangle2D72);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        java.awt.Color color1 = java.awt.Color.GREEN;
        float[] floatArray6 = new float[] { (byte) 1, (short) 0, (short) 100, (short) -1 };
        float[] floatArray7 = color1.getComponents(floatArray6);
        boolean boolean8 = defaultKeyedValues2D0.equals((java.lang.Object) floatArray7);
        defaultKeyedValues2D0.clear();
        java.awt.Paint paint10 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        boolean boolean11 = defaultKeyedValues2D0.equals((java.lang.Object) paint10);
        try {
            defaultKeyedValues2D0.removeColumn((java.lang.Comparable) 90.0d);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unknown key: 90.0");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("", "TableOrder.BY_ROW", "RectangleEdge.TOP", "RectangleEdge.TOP", "HorizontalAlignment.CENTER");
        java.lang.String str6 = basicProjectInfo5.getLicenceName();
        java.lang.String str7 = basicProjectInfo5.getName();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "HorizontalAlignment.CENTER" + "'", str6.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        piePlot1.setLabelLinkMargin(0.0d);
        boolean boolean8 = piePlot1.isCircular();
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        piePlot1.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        piePlot1.setDataset(pieDataset8);
        org.jfree.data.general.PieDataset pieDataset10 = piePlot1.getDataset();
        java.lang.String str11 = piePlot1.getNoDataMessage();
        piePlot1.setLabelLinkMargin((double) 0.5f);
        java.awt.Paint paint14 = piePlot1.getNoDataMessagePaint();
        double double15 = piePlot1.getLabelGap();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot16 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.util.TableOrder tableOrder17 = org.jfree.chart.util.TableOrder.BY_COLUMN;
        multiplePiePlot16.setDataExtractOrder(tableOrder17);
        multiplePiePlot16.setAggregatedItemsKey((java.lang.Comparable) (-1));
        org.jfree.data.category.CategoryDataset categoryDataset21 = multiplePiePlot16.getDataset();
        java.lang.Object obj22 = multiplePiePlot16.clone();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset23 = new org.jfree.data.category.DefaultCategoryDataset();
        multiplePiePlot16.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset23);
        double double25 = multiplePiePlot16.getLimit();
        org.jfree.data.general.PieDataset pieDataset26 = null;
        org.jfree.chart.plot.PiePlot piePlot27 = new org.jfree.chart.plot.PiePlot(pieDataset26);
        piePlot27.setForegroundAlpha(0.0f);
        piePlot27.setStartAngle((double) 100L);
        piePlot27.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset34 = null;
        piePlot27.setDataset(pieDataset34);
        piePlot27.setMaximumLabelWidth((double) (byte) 100);
        java.awt.Stroke stroke39 = piePlot27.getSectionOutlineStroke((java.lang.Comparable) (short) 0);
        org.jfree.data.general.PieDataset pieDataset40 = null;
        org.jfree.chart.plot.PiePlot piePlot41 = new org.jfree.chart.plot.PiePlot(pieDataset40);
        piePlot41.setForegroundAlpha((float) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor49 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean50 = rectangleInsets48.equals((java.lang.Object) rectangleAnchor49);
        double double52 = rectangleInsets48.calculateBottomInset((double) (-1L));
        piePlot41.setSimpleLabelOffset(rectangleInsets48);
        piePlot27.setInsets(rectangleInsets48);
        java.awt.Color color55 = java.awt.Color.BLUE;
        piePlot27.setLabelLinkPaint((java.awt.Paint) color55);
        java.awt.Font font57 = piePlot27.getLabelFont();
        java.awt.Font font58 = piePlot27.getLabelFont();
        multiplePiePlot16.setNoDataMessageFont(font58);
        piePlot1.setNoDataMessageFont(font58);
        java.awt.Paint paint62 = piePlot1.getSectionOutlinePaint((java.lang.Comparable) (-7904));
        org.junit.Assert.assertNull(pieDataset10);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.025d + "'", double15 == 0.025d);
        org.junit.Assert.assertNotNull(tableOrder17);
        org.junit.Assert.assertNull(categoryDataset21);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNull(stroke39);
        org.junit.Assert.assertNotNull(rectangleAnchor49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 100.0d + "'", double52 == 100.0d);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertNotNull(font57);
        org.junit.Assert.assertNotNull(font58);
        org.junit.Assert.assertNull(paint62);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity9 = new org.jfree.chart.entity.PieSectionEntity(shape2, pieDataset3, 0, (int) (byte) 100, (java.lang.Comparable) 1L, "RectangleEdge.TOP", "RectangleEdge.TOP");
        org.jfree.chart.JFreeChart jFreeChart10 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent11 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0, jFreeChart10);
        org.jfree.chart.JFreeChart jFreeChart12 = chartChangeEvent11.getChart();
        org.jfree.chart.JFreeChart jFreeChart13 = null;
        chartChangeEvent11.setChart(jFreeChart13);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot16 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.util.TableOrder tableOrder17 = org.jfree.chart.util.TableOrder.BY_COLUMN;
        multiplePiePlot16.setDataExtractOrder(tableOrder17);
        org.jfree.chart.JFreeChart jFreeChart19 = new org.jfree.chart.JFreeChart("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.chart.plot.Plot) multiplePiePlot16);
        chartChangeEvent11.setChart(jFreeChart19);
        jFreeChart19.setBackgroundImageAlpha((float) 'a');
        textTitle1.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart19);
        jFreeChart19.clearSubtitles();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(jFreeChart12);
        org.junit.Assert.assertNotNull(tableOrder17);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 0, (int) (byte) 100, (java.lang.Comparable) 1L, "RectangleEdge.TOP", "RectangleEdge.TOP");
        org.jfree.data.general.PieDataset pieDataset8 = null;
        pieSectionEntity7.setDataset(pieDataset8);
        java.lang.String str10 = pieSectionEntity7.toString();
        java.lang.Comparable comparable11 = pieSectionEntity7.getSectionKey();
        pieSectionEntity7.setPieIndex(0);
        pieSectionEntity7.setPieIndex(192);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "PieSection: 0, 100(1)" + "'", str10.equals("PieSection: 0, 100(1)"));
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + 1L + "'", comparable11.equals(1L));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double2 = rectangleInsets0.extendWidth(0.0d);
        double double4 = rectangleInsets0.calculateBottomOutset((double) (byte) 10);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0d + "'", double2 == 2.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        java.awt.Stroke stroke2 = strokeMap0.getStroke((java.lang.Comparable) 4.0d);
        org.jfree.chart.block.ColumnArrangement columnArrangement3 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer4 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.util.Size2D size2D6 = blockContainer4.arrange(graphics2D5);
        java.lang.Object obj7 = null;
        boolean boolean8 = blockContainer4.equals(obj7);
        java.lang.Class<?> wildcardClass9 = blockContainer4.getClass();
        java.awt.Paint paint14 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder15 = new org.jfree.chart.block.BlockBorder((double) 10, (double) '#', (double) 0L, 0.0d, paint14);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = blockBorder15.getInsets();
        blockContainer4.setFrame((org.jfree.chart.block.BlockFrame) blockBorder15);
        boolean boolean18 = strokeMap0.equals((java.lang.Object) blockContainer4);
        org.jfree.data.general.PieDataset pieDataset19 = null;
        org.jfree.chart.plot.PiePlot piePlot20 = new org.jfree.chart.plot.PiePlot(pieDataset19);
        piePlot20.setForegroundAlpha(0.0f);
        piePlot20.setStartAngle((double) 100L);
        java.awt.Shape shape25 = piePlot20.getLegendItemShape();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent26 = null;
        piePlot20.axisChanged(axisChangeEvent26);
        boolean boolean28 = strokeMap0.equals((java.lang.Object) piePlot20);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double31 = rectangleInsets29.calculateTopOutset((double) 0);
        java.lang.String str32 = rectangleInsets29.toString();
        double double34 = rectangleInsets29.calculateTopOutset((double) '#');
        piePlot20.setLabelPadding(rectangleInsets29);
        double double36 = rectangleInsets29.getBottom();
        org.junit.Assert.assertNull(stroke2);
        org.junit.Assert.assertNotNull(size2D6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 4.0d + "'", double31 == 4.0d);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]" + "'", str32.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 4.0d + "'", double34 == 4.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 4.0d + "'", double36 == 4.0d);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.util.TableOrder tableOrder2 = org.jfree.chart.util.TableOrder.BY_COLUMN;
        multiplePiePlot1.setDataExtractOrder(tableOrder2);
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.chart.plot.Plot) multiplePiePlot1);
        jFreeChart4.setBorderVisible(true);
        org.junit.Assert.assertNotNull(tableOrder2);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        java.lang.String str1 = unitType0.toString();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = new org.jfree.chart.util.RectangleInsets();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        piePlot4.setForegroundAlpha(0.0f);
        piePlot4.setStartAngle((double) 100L);
        piePlot4.setForegroundAlpha((float) (short) 100);
        double double11 = piePlot4.getShadowYOffset();
        java.awt.Stroke stroke12 = piePlot4.getBaseSectionOutlineStroke();
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement14 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer15 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement14);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.util.Size2D size2D17 = blockContainer15.arrange(graphics2D16);
        java.lang.Object obj18 = null;
        boolean boolean19 = blockContainer15.equals(obj18);
        java.lang.Class<?> wildcardClass20 = blockContainer15.getClass();
        java.awt.geom.Rectangle2D rectangle2D21 = blockContainer15.getBounds();
        org.jfree.chart.entity.ChartEntity chartEntity23 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D21, "JFreeChart version RectangleAnchor.BOTTOM_LEFT.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nTableOrder.BY_ROW");
        piePlot4.drawBackgroundImage(graphics2D13, rectangle2D21);
        java.awt.geom.Rectangle2D rectangle2D27 = rectangleInsets2.createOutsetRectangle(rectangle2D21, true, true);
        boolean boolean28 = unitType0.equals((java.lang.Object) rectangle2D21);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UnitType.RELATIVE" + "'", str1.equals("UnitType.RELATIVE"));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(size2D17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        piePlot1.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        piePlot1.setDataset(pieDataset8);
        org.jfree.data.general.PieDataset pieDataset10 = piePlot1.getDataset();
        java.lang.String str11 = piePlot1.getNoDataMessage();
        piePlot1.setLabelLinkMargin(89.0d);
        double double14 = piePlot1.getShadowXOffset();
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor16 = new org.jfree.chart.plot.PieLabelDistributor((int) '4');
        pieLabelDistributor16.distributeLabels((double) 2, 100.0d);
        pieLabelDistributor16.sort();
        piePlot1.setLabelDistributor((org.jfree.chart.plot.AbstractPieLabelDistributor) pieLabelDistributor16);
        int int22 = pieLabelDistributor16.getItemCount();
        pieLabelDistributor16.sort();
        org.junit.Assert.assertNull(pieDataset10);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        piePlot1.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        piePlot1.setDataset(pieDataset8);
        org.jfree.chart.plot.Plot plot10 = piePlot1.getParent();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset11 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) piePlot1, (org.jfree.data.general.Dataset) defaultCategoryDataset11);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        piePlot14.setForegroundAlpha(0.0f);
        piePlot14.setStartAngle((double) 100L);
        java.awt.Shape shape19 = piePlot14.getLegendItemShape();
        boolean boolean20 = defaultCategoryDataset11.hasListener((java.util.EventListener) piePlot14);
        org.junit.Assert.assertNull(plot10);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha((float) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean10 = rectangleInsets8.equals((java.lang.Object) rectangleAnchor9);
        double double12 = rectangleInsets8.calculateBottomInset((double) (-1L));
        piePlot1.setSimpleLabelOffset(rectangleInsets8);
        java.lang.String str14 = piePlot1.getNoDataMessage();
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 100.0d + "'", double12 == 100.0d);
        org.junit.Assert.assertNull(str14);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) 0L, 90.0d, 0.0d, (double) 10L);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        piePlot1.setForegroundAlpha((float) (short) 100);
        double double8 = piePlot1.getShadowYOffset();
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        piePlot10.setForegroundAlpha(0.0f);
        piePlot10.setStartAngle((double) 100L);
        piePlot10.setForegroundAlpha((float) (short) 100);
        double double17 = piePlot10.getShadowYOffset();
        piePlot1.setParent((org.jfree.chart.plot.Plot) piePlot10);
        float float19 = piePlot10.getBackgroundAlpha();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator20 = piePlot10.getLegendLabelURLGenerator();
        boolean boolean21 = piePlot10.getIgnoreZeroValues();
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.LegendItemSource legendItemSource23 = null;
        org.jfree.chart.title.LegendTitle legendTitle24 = new org.jfree.chart.title.LegendTitle(legendItemSource23);
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        java.lang.String str26 = rectangleEdge25.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge25);
        legendTitle24.setLegendItemGraphicEdge(rectangleEdge25);
        org.jfree.chart.block.BlockFrame blockFrame29 = legendTitle24.getFrame();
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = legendTitle24.getItemLabelPadding();
        java.awt.Font font32 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset33 = null;
        org.jfree.chart.plot.PiePlot piePlot34 = new org.jfree.chart.plot.PiePlot(pieDataset33);
        piePlot34.setForegroundAlpha((float) 0);
        java.awt.Stroke stroke37 = piePlot34.getBaseSectionOutlineStroke();
        piePlot34.setLabelLinkMargin((double) (-256));
        org.jfree.chart.JFreeChart jFreeChart41 = new org.jfree.chart.JFreeChart("PieSection: 0, 100(1)", font32, (org.jfree.chart.plot.Plot) piePlot34, false);
        double double42 = piePlot34.getInteriorGap();
        java.awt.Graphics2D graphics2D43 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment44 = org.jfree.chart.util.VerticalAlignment.CENTER;
        java.awt.Shape shape45 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset46 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity52 = new org.jfree.chart.entity.PieSectionEntity(shape45, pieDataset46, 0, (int) (byte) 100, (java.lang.Comparable) 1L, "RectangleEdge.TOP", "RectangleEdge.TOP");
        pieSectionEntity52.setSectionKey((java.lang.Comparable) 0L);
        boolean boolean55 = verticalAlignment44.equals((java.lang.Object) pieSectionEntity52);
        java.awt.Shape shape56 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset57 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity63 = new org.jfree.chart.entity.PieSectionEntity(shape56, pieDataset57, 0, (int) (byte) 100, (java.lang.Comparable) 1L, "RectangleEdge.TOP", "RectangleEdge.TOP");
        pieSectionEntity63.setSectionKey((java.lang.Comparable) 0L);
        boolean boolean67 = pieSectionEntity63.equals((java.lang.Object) "hi!");
        org.jfree.chart.title.TextTitle textTitle69 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D70 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement71 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer72 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement71);
        java.awt.Graphics2D graphics2D73 = null;
        org.jfree.chart.util.Size2D size2D74 = blockContainer72.arrange(graphics2D73);
        blockContainer72.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D80 = blockContainer72.getBounds();
        java.lang.Object obj82 = textTitle69.draw(graphics2D70, rectangle2D80, (java.lang.Object) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor83 = null;
        java.awt.geom.Point2D point2D84 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D80, rectangleAnchor83);
        pieSectionEntity63.setArea((java.awt.Shape) rectangle2D80);
        pieSectionEntity52.setArea((java.awt.Shape) rectangle2D80);
        piePlot34.drawBackgroundImage(graphics2D43, rectangle2D80);
        org.jfree.chart.entity.ChartEntity chartEntity89 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D80, "RectangleAnchor.BOTTOM_LEFT");
        java.awt.geom.Rectangle2D rectangle2D90 = rectangleInsets30.createInsetRectangle(rectangle2D80);
        try {
            piePlot10.drawBackground(graphics2D22, rectangle2D80);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.0d + "'", double8 == 4.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 4.0d + "'", double17 == 4.0d);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 1.0f + "'", float19 == 1.0f);
        org.junit.Assert.assertNull(pieURLGenerator20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(rectangleEdge25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "RectangleEdge.TOP" + "'", str26.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertNotNull(blockFrame29);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.08d + "'", double42 == 0.08d);
        org.junit.Assert.assertNotNull(verticalAlignment44);
        org.junit.Assert.assertNotNull(shape45);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(shape56);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(size2D74);
        org.junit.Assert.assertNotNull(rectangle2D80);
        org.junit.Assert.assertNull(obj82);
        org.junit.Assert.assertNotNull(point2D84);
        org.junit.Assert.assertNotNull(rectangle2D90);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        piePlot1.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        piePlot1.setDataset(pieDataset8);
        org.jfree.chart.plot.Plot plot10 = piePlot1.getParent();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset11 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) piePlot1, (org.jfree.data.general.Dataset) defaultCategoryDataset11);
        java.lang.Object obj13 = defaultCategoryDataset11.clone();
        int int15 = defaultCategoryDataset11.getRowIndex((java.lang.Comparable) (byte) -1);
        int int17 = defaultCategoryDataset11.getRowIndex((java.lang.Comparable) "{0}");
        try {
            defaultCategoryDataset11.removeColumn(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(plot10);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        double double6 = piePlot1.getInteriorGap();
        java.awt.Paint paint7 = piePlot1.getLabelOutlinePaint();
        java.awt.Color color10 = java.awt.Color.getColor("RectangleEdge.TOP", (int) (short) 1);
        org.jfree.chart.ChartColor chartColor14 = new org.jfree.chart.ChartColor(15, 192, (int) (short) 10);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType15 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.awt.Color color16 = java.awt.Color.GREEN;
        boolean boolean17 = chartChangeEventType15.equals((java.lang.Object) color16);
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        int int19 = color18.getTransparency();
        java.awt.Color color20 = java.awt.Color.BLACK;
        java.awt.Color color21 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        java.awt.Paint[] paintArray22 = new java.awt.Paint[] { color10, chartColor14, color16, color18, color20, color21 };
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType23 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.awt.Color color24 = java.awt.Color.GREEN;
        boolean boolean25 = chartChangeEventType23.equals((java.lang.Object) color24);
        java.awt.Paint paint30 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder31 = new org.jfree.chart.block.BlockBorder((double) 10, (double) '#', (double) 0L, 0.0d, paint30);
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.Paint[] paintArray33 = new java.awt.Paint[] { color24, paint30, color32 };
        java.awt.Paint[] paintArray34 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray35 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray36 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray37 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier38 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray22, paintArray33, paintArray34, strokeArray35, strokeArray36, shapeArray37);
        piePlot1.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier38);
        java.awt.Paint paint40 = defaultDrawingSupplier38.getNextFillPaint();
        java.awt.Paint paint41 = defaultDrawingSupplier38.getNextPaint();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.08d + "'", double6 == 0.08d);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(chartChangeEventType15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(paintArray22);
        org.junit.Assert.assertNotNull(chartChangeEventType23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(paintArray33);
        org.junit.Assert.assertNotNull(paintArray34);
        org.junit.Assert.assertNotNull(strokeArray35);
        org.junit.Assert.assertNotNull(strokeArray36);
        org.junit.Assert.assertNotNull(shapeArray37);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(paint41);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.util.TableOrder tableOrder1 = org.jfree.chart.util.TableOrder.BY_COLUMN;
        multiplePiePlot0.setDataExtractOrder(tableOrder1);
        multiplePiePlot0.setAggregatedItemsKey((java.lang.Comparable) (-1));
        org.jfree.data.category.CategoryDataset categoryDataset5 = multiplePiePlot0.getDataset();
        java.lang.Object obj6 = multiplePiePlot0.clone();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset7 = new org.jfree.data.category.DefaultCategoryDataset();
        multiplePiePlot0.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset7);
        double double9 = multiplePiePlot0.getLimit();
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot(pieDataset10);
        piePlot11.setForegroundAlpha(0.0f);
        piePlot11.setStartAngle((double) 100L);
        piePlot11.setLabelLinkMargin(0.0d);
        boolean boolean18 = piePlot11.getIgnoreZeroValues();
        org.jfree.chart.block.BlockBorder blockBorder23 = new org.jfree.chart.block.BlockBorder(0.0d, 0.025d, (double) 100, (double) (short) 100);
        boolean boolean24 = piePlot11.equals((java.lang.Object) 0.025d);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator25 = piePlot11.getURLGenerator();
        java.awt.Paint paint26 = piePlot11.getShadowPaint();
        multiplePiePlot0.setAggregatedItemsPaint(paint26);
        org.jfree.chart.JFreeChart jFreeChart28 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.chart.title.TextTitle textTitle31 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D32 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement33 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer34 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement33);
        java.awt.Graphics2D graphics2D35 = null;
        org.jfree.chart.util.Size2D size2D36 = blockContainer34.arrange(graphics2D35);
        blockContainer34.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D42 = blockContainer34.getBounds();
        java.lang.Object obj44 = textTitle31.draw(graphics2D32, rectangle2D42, (java.lang.Object) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor45 = null;
        java.awt.geom.Point2D point2D46 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D42, rectangleAnchor45);
        try {
            jFreeChart28.draw(graphics2D29, rectangle2D42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(tableOrder1);
        org.junit.Assert.assertNull(categoryDataset5);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(pieURLGenerator25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(size2D36);
        org.junit.Assert.assertNotNull(rectangle2D42);
        org.junit.Assert.assertNull(obj44);
        org.junit.Assert.assertNotNull(point2D46);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        piePlot1.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        piePlot1.setDataset(pieDataset8);
        piePlot1.setMaximumLabelWidth((double) (byte) 100);
        java.awt.Stroke stroke13 = piePlot1.getSectionOutlineStroke((java.lang.Comparable) (short) 0);
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        piePlot15.setForegroundAlpha((float) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor23 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean24 = rectangleInsets22.equals((java.lang.Object) rectangleAnchor23);
        double double26 = rectangleInsets22.calculateBottomInset((double) (-1L));
        piePlot15.setSimpleLabelOffset(rectangleInsets22);
        piePlot1.setInsets(rectangleInsets22);
        java.awt.Paint paint30 = piePlot1.getSectionPaint((java.lang.Comparable) "JFreeChart version RectangleEdge.TOP.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nTableOrder.BY_ROW");
        java.awt.Paint paint31 = piePlot1.getBaseSectionPaint();
        org.junit.Assert.assertNull(stroke13);
        org.junit.Assert.assertNotNull(rectangleAnchor23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 100.0d + "'", double26 == 100.0d);
        org.junit.Assert.assertNull(paint30);
        org.junit.Assert.assertNotNull(paint31);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = textTitle1.getTextAlignment();
        java.lang.String str3 = horizontalAlignment2.toString();
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font5 = textTitle4.getFont();
        org.jfree.chart.util.VerticalAlignment verticalAlignment6 = textTitle4.getVerticalAlignment();
        org.jfree.chart.block.FlowArrangement flowArrangement9 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment2, verticalAlignment6, (double) (short) 0, (double) (short) 1);
        org.jfree.chart.LegendItemSource legendItemSource10 = null;
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle(legendItemSource10);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = legendTitle11.getLegendItemGraphicPadding();
        boolean boolean13 = flowArrangement9.equals((java.lang.Object) legendTitle11);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = legendTitle11.getItemLabelPadding();
        java.awt.Font font15 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        legendTitle11.setItemFont(font15);
        org.jfree.chart.block.ColumnArrangement columnArrangement17 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer18 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement17);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.util.Size2D size2D20 = blockContainer18.arrange(graphics2D19);
        blockContainer18.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        legendTitle11.setWrapper(blockContainer18);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "HorizontalAlignment.CENTER" + "'", str3.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(verticalAlignment6);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(size2D20);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        piePlot2.setForegroundAlpha((float) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean11 = rectangleInsets9.equals((java.lang.Object) rectangleAnchor10);
        double double13 = rectangleInsets9.calculateBottomInset((double) (-1L));
        piePlot2.setSimpleLabelOffset(rectangleInsets9);
        java.awt.Color color15 = java.awt.Color.DARK_GRAY;
        piePlot2.setBackgroundPaint((java.awt.Paint) color15);
        boolean boolean17 = chartChangeEventType0.equals((java.lang.Object) piePlot2);
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertNotNull(rectangleAnchor10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 100.0d + "'", double13 == 100.0d);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        piePlot1.setLabelLinkMargin(0.0d);
        boolean boolean8 = piePlot1.getIgnoreZeroValues();
        org.jfree.chart.plot.Plot plot9 = piePlot1.getParent();
        java.awt.Paint paint10 = piePlot1.getBaseSectionOutlinePaint();
        piePlot1.setShadowXOffset((double) 10);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(plot9);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 0, (int) (byte) 100, (java.lang.Comparable) 1L, "RectangleEdge.TOP", "RectangleEdge.TOP");
        org.jfree.data.UnknownKeyException unknownKeyException9 = new org.jfree.data.UnknownKeyException("");
        boolean boolean10 = pieSectionEntity7.equals((java.lang.Object) "");
        java.lang.Comparable comparable11 = pieSectionEntity7.getSectionKey();
        java.lang.String str12 = pieSectionEntity7.toString();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + 1L + "'", comparable11.equals(1L));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "PieSection: 0, 100(1)" + "'", str12.equals("PieSection: 0, 100(1)"));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        piePlot1.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        piePlot1.setDataset(pieDataset8);
        org.jfree.chart.plot.Plot plot10 = piePlot1.getParent();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset11 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) piePlot1, (org.jfree.data.general.Dataset) defaultCategoryDataset11);
        java.lang.Object obj13 = defaultCategoryDataset11.clone();
        int int15 = defaultCategoryDataset11.getColumnIndex((java.lang.Comparable) 1.0f);
        org.junit.Assert.assertNull(plot10);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        piePlot1.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        piePlot1.setDataset(pieDataset8);
        org.jfree.chart.plot.Plot plot10 = piePlot1.getParent();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset11 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) piePlot1, (org.jfree.data.general.Dataset) defaultCategoryDataset11);
        java.lang.Object obj13 = defaultCategoryDataset11.clone();
        int int15 = defaultCategoryDataset11.getRowIndex((java.lang.Comparable) (byte) -1);
        int int17 = defaultCategoryDataset11.getRowIndex((java.lang.Comparable) "{0}");
        java.awt.Shape shape18 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset19 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity25 = new org.jfree.chart.entity.PieSectionEntity(shape18, pieDataset19, 0, (int) (byte) 100, (java.lang.Comparable) 1L, "RectangleEdge.TOP", "RectangleEdge.TOP");
        org.jfree.data.UnknownKeyException unknownKeyException27 = new org.jfree.data.UnknownKeyException("");
        boolean boolean28 = pieSectionEntity25.equals((java.lang.Object) "");
        java.lang.Comparable comparable29 = pieSectionEntity25.getSectionKey();
        boolean boolean30 = defaultCategoryDataset11.equals((java.lang.Object) comparable29);
        org.junit.Assert.assertNull(plot10);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + comparable29 + "' != '" + 1L + "'", comparable29.equals(1L));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        java.awt.Stroke stroke2 = strokeMap0.getStroke((java.lang.Comparable) 4.0d);
        org.jfree.chart.block.ColumnArrangement columnArrangement3 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer4 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.util.Size2D size2D6 = blockContainer4.arrange(graphics2D5);
        java.lang.Object obj7 = null;
        boolean boolean8 = blockContainer4.equals(obj7);
        java.lang.Class<?> wildcardClass9 = blockContainer4.getClass();
        java.awt.Paint paint14 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder15 = new org.jfree.chart.block.BlockBorder((double) 10, (double) '#', (double) 0L, 0.0d, paint14);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = blockBorder15.getInsets();
        blockContainer4.setFrame((org.jfree.chart.block.BlockFrame) blockBorder15);
        boolean boolean18 = strokeMap0.equals((java.lang.Object) blockContainer4);
        org.jfree.data.general.PieDataset pieDataset20 = null;
        org.jfree.chart.plot.PiePlot piePlot21 = new org.jfree.chart.plot.PiePlot(pieDataset20);
        piePlot21.setForegroundAlpha(0.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor29 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean30 = rectangleInsets28.equals((java.lang.Object) rectangleAnchor29);
        double double32 = rectangleInsets28.calculateTopInset(0.0d);
        piePlot21.setInsets(rectangleInsets28);
        org.jfree.data.general.PieDataset pieDataset34 = null;
        org.jfree.chart.plot.PiePlot piePlot35 = new org.jfree.chart.plot.PiePlot(pieDataset34);
        piePlot35.setForegroundAlpha((float) 0);
        boolean boolean38 = piePlot35.getIgnoreZeroValues();
        double double39 = piePlot35.getShadowXOffset();
        java.awt.Stroke stroke40 = piePlot35.getLabelLinkStroke();
        piePlot21.setBaseSectionOutlineStroke(stroke40);
        strokeMap0.put((java.lang.Comparable) 15, stroke40);
        java.lang.Comparable comparable43 = null;
        try {
            java.awt.Stroke stroke44 = strokeMap0.getStroke(comparable43);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(stroke2);
        org.junit.Assert.assertNotNull(size2D6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + (-1.0d) + "'", double32 == (-1.0d));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 4.0d + "'", double39 == 4.0d);
        org.junit.Assert.assertNotNull(stroke40);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        textTitle1.setBackgroundPaint((java.awt.Paint) color2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        java.awt.Color color5 = color4.brighter();
        textTitle1.setPaint((java.awt.Paint) color5);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer9 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement8);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.util.Size2D size2D11 = blockContainer9.arrange(graphics2D10);
        java.lang.Object obj12 = null;
        boolean boolean13 = blockContainer9.equals(obj12);
        java.lang.Class<?> wildcardClass14 = blockContainer9.getClass();
        java.awt.geom.Rectangle2D rectangle2D15 = blockContainer9.getBounds();
        org.jfree.data.general.PieDataset pieDataset16 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity22 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D15, pieDataset16, (int) ' ', (-254), (java.lang.Comparable) 89.0d, "org.jfree.chart.event.ChartChangeEvent[source=0]", "");
        textTitle1.draw(graphics2D7, rectangle2D15);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(size2D11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(rectangle2D15);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        piePlot1.setForegroundAlpha((float) (short) 100);
        double double8 = piePlot1.getShadowYOffset();
        org.jfree.data.general.PieDataset pieDataset9 = null;
        piePlot1.setDataset(pieDataset9);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.0d + "'", double8 == 4.0d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        java.awt.Stroke stroke6 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        piePlot1.setLabelOutlineStroke(stroke6);
        double double8 = piePlot1.getLabelLinkMargin();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator9 = piePlot1.getLabelGenerator();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.025d + "'", double8 == 0.025d);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator9);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) 100L, (float) (byte) 0, (float) 255);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        try {
            java.awt.Color color1 = java.awt.Color.decode("1.2.0-pre");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1.2.0-pre\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        java.lang.Object obj2 = legendTitle1.clone();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        piePlot4.setForegroundAlpha(0.0f);
        piePlot4.setStartAngle((double) 100L);
        piePlot4.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset11 = null;
        piePlot4.setDataset(pieDataset11);
        piePlot4.setMaximumLabelWidth((double) (byte) 100);
        java.awt.Stroke stroke16 = piePlot4.getSectionOutlineStroke((java.lang.Comparable) (short) 0);
        org.jfree.data.general.PieDataset pieDataset17 = null;
        org.jfree.chart.plot.PiePlot piePlot18 = new org.jfree.chart.plot.PiePlot(pieDataset17);
        piePlot18.setForegroundAlpha(0.0f);
        piePlot18.setStartAngle((double) 100L);
        java.awt.Shape shape23 = piePlot18.getLegendItemShape();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent24 = null;
        piePlot18.axisChanged(axisChangeEvent24);
        java.awt.Color color27 = java.awt.Color.red;
        piePlot18.setSectionPaint((java.lang.Comparable) 90.0d, (java.awt.Paint) color27);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray29 = new org.jfree.chart.LegendItemSource[] { piePlot4, piePlot18 };
        legendTitle1.setSources(legendItemSourceArray29);
        org.jfree.chart.title.TextTitle textTitle32 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        java.awt.Paint paint33 = textTitle32.getBackgroundPaint();
        boolean boolean34 = legendTitle1.equals((java.lang.Object) textTitle32);
        java.awt.geom.Rectangle2D rectangle2D35 = legendTitle1.getBounds();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNull(stroke16);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(legendItemSourceArray29);
        org.junit.Assert.assertNull(paint33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(rectangle2D35);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha((float) 0);
        boolean boolean4 = piePlot1.getIgnoreZeroValues();
        double double5 = piePlot1.getShadowXOffset();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot7 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.util.TableOrder tableOrder8 = org.jfree.chart.util.TableOrder.BY_COLUMN;
        multiplePiePlot7.setDataExtractOrder(tableOrder8);
        java.awt.Font font11 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        piePlot13.setForegroundAlpha((float) 0);
        java.awt.Stroke stroke16 = piePlot13.getBaseSectionOutlineStroke();
        piePlot13.setLabelLinkMargin((double) (-256));
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("PieSection: 0, 100(1)", font11, (org.jfree.chart.plot.Plot) piePlot13, false);
        multiplePiePlot7.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart20);
        boolean boolean22 = jFreeChart6.equals((java.lang.Object) jFreeChart20);
        java.awt.Paint paint23 = jFreeChart6.getBorderPaint();
        jFreeChart6.removeLegend();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(tableOrder8);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(paint23);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = legendTitle1.getLegendItemGraphicPadding();
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        legendTitle1.setBackgroundPaint((java.awt.Paint) color3);
        org.jfree.chart.block.BlockContainer blockContainer5 = legendTitle1.getItemContainer();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(blockContainer5);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) '4');
        pieLabelDistributor1.sort();
        pieLabelDistributor1.clear();
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        java.lang.String str3 = standardPieSectionLabelGenerator0.generateSectionLabel(pieDataset1, (java.lang.Comparable) 79.0d);
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        java.lang.String str3 = standardPieSectionLabelGenerator0.generateSectionLabel(pieDataset1, (java.lang.Comparable) "RectangleInsets[t=-1.0,l=10.0,b=100.0,r=1.0]");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle4 = org.jfree.chart.plot.PieLabelLinkStyle.CUBIC_CURVE;
        boolean boolean5 = standardPieSectionLabelGenerator0.equals((java.lang.Object) pieLabelLinkStyle4);
        java.lang.Object obj6 = standardPieSectionLabelGenerator0.clone();
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("RectangleEdge.TOP", "RectangleEdge.TOP");
        java.lang.String str3 = contributor2.getEmail();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleEdge.TOP" + "'", str3.equals("RectangleEdge.TOP"));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement3 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer4 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.util.Size2D size2D6 = blockContainer4.arrange(graphics2D5);
        blockContainer4.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D12 = blockContainer4.getBounds();
        java.lang.Object obj14 = textTitle1.draw(graphics2D2, rectangle2D12, (java.lang.Object) (short) 0);
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment17 = textTitle16.getTextAlignment();
        java.lang.String str18 = horizontalAlignment17.toString();
        textTitle1.setHorizontalAlignment(horizontalAlignment17);
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font21 = textTitle20.getFont();
        org.jfree.chart.util.VerticalAlignment verticalAlignment22 = textTitle20.getVerticalAlignment();
        textTitle1.setVerticalAlignment(verticalAlignment22);
        textTitle1.setURLText("Rotation.ANTICLOCKWISE");
        org.jfree.chart.title.TextTitle textTitle27 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment28 = textTitle27.getTextAlignment();
        textTitle1.setHorizontalAlignment(horizontalAlignment28);
        org.jfree.chart.util.VerticalAlignment verticalAlignment30 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement33 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment28, verticalAlignment30, (double) 'a', (double) (short) 10);
        org.junit.Assert.assertNotNull(size2D6);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertNull(obj14);
        org.junit.Assert.assertNotNull(horizontalAlignment17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "HorizontalAlignment.CENTER" + "'", str18.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(verticalAlignment22);
        org.junit.Assert.assertNotNull(horizontalAlignment28);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 0, (int) (byte) 100, (java.lang.Comparable) 1L, "RectangleEdge.TOP", "RectangleEdge.TOP");
        java.lang.String str8 = pieSectionEntity7.getURLText();
        pieSectionEntity7.setPieIndex((int) (short) 1);
        java.lang.Comparable comparable11 = pieSectionEntity7.getSectionKey();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "RectangleEdge.TOP" + "'", str8.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + 1L + "'", comparable11.equals(1L));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        textTitle1.setBackgroundPaint((java.awt.Paint) color2);
        textTitle1.setURLText("Rotation.ANTICLOCKWISE");
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement7 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer8 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement7);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.util.Size2D size2D10 = blockContainer8.arrange(graphics2D9);
        blockContainer8.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D16 = blockContainer8.getBounds();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        org.jfree.data.general.PieDataset pieDataset19 = null;
        org.jfree.chart.plot.PiePlot piePlot20 = new org.jfree.chart.plot.PiePlot(pieDataset19);
        piePlot20.setForegroundAlpha(0.0f);
        piePlot20.setLabelLinkMargin(4.0d);
        java.awt.Paint paint25 = piePlot20.getShadowPaint();
        java.lang.Object obj26 = textTitle1.draw(graphics2D6, rectangle2D16, (java.lang.Object) piePlot20);
        java.awt.Stroke stroke28 = piePlot20.getSectionOutlineStroke((java.lang.Comparable) "PieSection: 0, 100(1)");
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(size2D10);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(rectangleAnchor17);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(obj26);
        org.junit.Assert.assertNull(stroke28);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Enumeration<java.lang.String> strEnumeration1 = jFreeChartResources0.getKeys();
        java.util.Locale locale2 = jFreeChartResources0.getLocale();
        java.util.Locale locale3 = jFreeChartResources0.getLocale();
        java.lang.Object obj5 = jFreeChartResources0.handleGetObject("HorizontalAlignment.CENTER");
        org.junit.Assert.assertNotNull(strEnumeration1);
        org.junit.Assert.assertNull(locale2);
        org.junit.Assert.assertNull(locale3);
        org.junit.Assert.assertNull(obj5);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("HorizontalAlignment.LEFT");
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        java.awt.Color color1 = java.awt.Color.GREEN;
        float[] floatArray6 = new float[] { (byte) 1, (short) 0, (short) 100, (short) -1 };
        float[] floatArray7 = color1.getComponents(floatArray6);
        boolean boolean8 = defaultKeyedValues2D0.equals((java.lang.Object) floatArray7);
        int int9 = defaultKeyedValues2D0.getColumnCount();
        int int10 = defaultKeyedValues2D0.getColumnCount();
        java.util.List list11 = defaultKeyedValues2D0.getColumnKeys();
        int int13 = defaultKeyedValues2D0.getColumnIndex((java.lang.Comparable) "hi!");
        java.lang.Number number14 = null;
        defaultKeyedValues2D0.addValue(number14, (java.lang.Comparable) 0.5f, (java.lang.Comparable) "Multiple Pie Plot");
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.zoom((double) '#');
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        piePlot7.setForegroundAlpha((float) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean16 = rectangleInsets14.equals((java.lang.Object) rectangleAnchor15);
        double double18 = rectangleInsets14.calculateBottomInset((double) (-1L));
        piePlot7.setSimpleLabelOffset(rectangleInsets14);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle20 = org.jfree.chart.plot.PieLabelLinkStyle.CUBIC_CURVE;
        piePlot7.setLabelLinkStyle(pieLabelLinkStyle20);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier22 = piePlot7.getDrawingSupplier();
        boolean boolean23 = piePlot1.equals((java.lang.Object) piePlot7);
        java.awt.Paint paint24 = piePlot7.getLabelPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator25 = piePlot7.getLegendLabelGenerator();
        java.awt.Paint paint26 = null;
        piePlot7.setLabelOutlinePaint(paint26);
        java.awt.Paint paint32 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder33 = new org.jfree.chart.block.BlockBorder((double) 10, (double) '#', (double) 0L, 0.0d, paint32);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = blockBorder33.getInsets();
        piePlot7.setInsets(rectangleInsets34);
        java.lang.Object obj36 = piePlot7.clone();
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 100.0d + "'", double18 == 100.0d);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle20);
        org.junit.Assert.assertNotNull(drawingSupplier22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator25);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertNotNull(obj36);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        java.awt.Stroke stroke6 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        piePlot1.setLabelOutlineStroke(stroke6);
        piePlot1.setShadowYOffset((double) (byte) 0);
        java.awt.Paint paint10 = piePlot1.getLabelLinkPaint();
        org.jfree.chart.title.TextTitle textTitle12 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment13 = textTitle12.getTextAlignment();
        java.lang.String str14 = horizontalAlignment13.toString();
        org.jfree.chart.title.TextTitle textTitle15 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font16 = textTitle15.getFont();
        org.jfree.chart.util.VerticalAlignment verticalAlignment17 = textTitle15.getVerticalAlignment();
        org.jfree.chart.block.FlowArrangement flowArrangement20 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment13, verticalAlignment17, (double) (short) 0, (double) (short) 1);
        org.jfree.chart.LegendItemSource legendItemSource21 = null;
        org.jfree.chart.title.LegendTitle legendTitle22 = new org.jfree.chart.title.LegendTitle(legendItemSource21);
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = legendTitle22.getLegendItemGraphicPadding();
        boolean boolean24 = flowArrangement20.equals((java.lang.Object) legendTitle22);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = legendTitle22.getItemLabelPadding();
        piePlot1.setInsets(rectangleInsets25, false);
        piePlot1.setIgnoreNullValues(true);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(horizontalAlignment13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "HorizontalAlignment.CENTER" + "'", str14.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(verticalAlignment17);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(rectangleInsets25);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setForegroundAlpha((float) 0);
        java.awt.Stroke stroke6 = piePlot3.getBaseSectionOutlineStroke();
        piePlot3.setLabelLinkMargin((double) (-256));
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("PieSection: 0, 100(1)", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
        jFreeChart10.setBorderVisible(false);
        org.jfree.chart.plot.Plot plot13 = jFreeChart10.getPlot();
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        piePlot15.setForegroundAlpha(0.0f);
        piePlot15.setStartAngle((double) 100L);
        piePlot15.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset22 = null;
        piePlot15.setDataset(pieDataset22);
        org.jfree.chart.plot.Plot plot24 = piePlot15.getParent();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset25 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent26 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) piePlot15, (org.jfree.data.general.Dataset) defaultCategoryDataset25);
        java.lang.Object obj27 = datasetChangeEvent26.getSource();
        plot13.datasetChanged(datasetChangeEvent26);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(plot13);
        org.junit.Assert.assertNull(plot24);
        org.junit.Assert.assertNotNull(obj27);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha((float) 0);
        boolean boolean4 = piePlot1.getIgnoreZeroValues();
        double double5 = piePlot1.getShadowXOffset();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        jFreeChart6.removeLegend();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.util.TableOrder tableOrder1 = org.jfree.chart.util.TableOrder.BY_COLUMN;
        multiplePiePlot0.setDataExtractOrder(tableOrder1);
        multiplePiePlot0.setAggregatedItemsKey((java.lang.Comparable) (-1));
        org.jfree.data.category.CategoryDataset categoryDataset5 = multiplePiePlot0.getDataset();
        java.lang.Object obj6 = multiplePiePlot0.clone();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset7 = new org.jfree.data.category.DefaultCategoryDataset();
        multiplePiePlot0.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset7);
        try {
            defaultCategoryDataset7.removeColumn((java.lang.Comparable) (-16.0d));
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unknown key: -16.0");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(tableOrder1);
        org.junit.Assert.assertNull(categoryDataset5);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        piePlot1.setLabelLinkMargin(0.0d);
        boolean boolean8 = piePlot1.getIgnoreZeroValues();
        try {
            piePlot1.setBackgroundImageAlpha((float) 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        java.awt.Color color1 = java.awt.Color.GREEN;
        float[] floatArray6 = new float[] { (byte) 1, (short) 0, (short) 100, (short) -1 };
        float[] floatArray7 = color1.getComponents(floatArray6);
        boolean boolean8 = defaultKeyedValues2D0.equals((java.lang.Object) floatArray7);
        int int9 = defaultKeyedValues2D0.getColumnCount();
        int int10 = defaultKeyedValues2D0.getColumnCount();
        java.util.List list11 = defaultKeyedValues2D0.getColumnKeys();
        int int13 = defaultKeyedValues2D0.getColumnIndex((java.lang.Comparable) "hi!");
        int int15 = defaultKeyedValues2D0.getRowIndex((java.lang.Comparable) 0.0d);
        try {
            java.lang.Comparable comparable17 = defaultKeyedValues2D0.getRowKey((-256));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.util.Size2D size2D3 = blockContainer1.arrange(graphics2D2);
        java.lang.Object obj4 = null;
        boolean boolean5 = blockContainer1.equals(obj4);
        java.lang.Class<?> wildcardClass6 = blockContainer1.getClass();
        java.awt.Paint paint11 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder((double) 10, (double) '#', (double) 0L, 0.0d, paint11);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = blockBorder12.getInsets();
        blockContainer1.setFrame((org.jfree.chart.block.BlockFrame) blockBorder12);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = blockBorder12.getInsets();
        org.junit.Assert.assertNotNull(size2D3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(rectangleInsets15);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        int int1 = color0.getRGB();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-8355585) + "'", int1 == (-8355585));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        piePlot1.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        piePlot1.setDataset(pieDataset8);
        org.jfree.data.general.PieDataset pieDataset10 = piePlot1.getDataset();
        piePlot1.setOutlineVisible(false);
        java.awt.Stroke stroke13 = piePlot1.getLabelOutlineStroke();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle14 = piePlot1.getLabelLinkStyle();
        piePlot1.setIgnoreNullValues(true);
        org.junit.Assert.assertNull(pieDataset10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle14);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        java.lang.String str1 = basicProjectInfo0.getCopyright();
        org.jfree.chart.ui.Library[] libraryArray2 = basicProjectInfo0.getLibraries();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo3 = new org.jfree.chart.ui.BasicProjectInfo();
        java.lang.String str4 = basicProjectInfo3.getName();
        basicProjectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo3);
        basicProjectInfo3.setInfo("RectangleInsets[t=-1.0,l=10.0,b=100.0,r=1.0]");
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(libraryArray2);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        textTitle1.setBackgroundPaint((java.awt.Paint) color2);
        java.awt.Color color4 = java.awt.Color.GREEN;
        java.awt.Color color5 = java.awt.Color.GREEN;
        float[] floatArray10 = new float[] { (byte) 1, (short) 0, (short) 100, (short) -1 };
        float[] floatArray11 = color5.getComponents(floatArray10);
        float[] floatArray12 = color4.getRGBColorComponents(floatArray11);
        textTitle1.setPaint((java.awt.Paint) color4);
        java.lang.String str14 = textTitle1.getText();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setForegroundAlpha((float) 0);
        java.awt.Stroke stroke6 = piePlot3.getBaseSectionOutlineStroke();
        piePlot3.setLabelLinkMargin((double) (-256));
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("PieSection: 0, 100(1)", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
        double double11 = piePlot3.getInteriorGap();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment13 = org.jfree.chart.util.VerticalAlignment.CENTER;
        java.awt.Shape shape14 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset15 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity21 = new org.jfree.chart.entity.PieSectionEntity(shape14, pieDataset15, 0, (int) (byte) 100, (java.lang.Comparable) 1L, "RectangleEdge.TOP", "RectangleEdge.TOP");
        pieSectionEntity21.setSectionKey((java.lang.Comparable) 0L);
        boolean boolean24 = verticalAlignment13.equals((java.lang.Object) pieSectionEntity21);
        java.awt.Shape shape25 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset26 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity32 = new org.jfree.chart.entity.PieSectionEntity(shape25, pieDataset26, 0, (int) (byte) 100, (java.lang.Comparable) 1L, "RectangleEdge.TOP", "RectangleEdge.TOP");
        pieSectionEntity32.setSectionKey((java.lang.Comparable) 0L);
        boolean boolean36 = pieSectionEntity32.equals((java.lang.Object) "hi!");
        org.jfree.chart.title.TextTitle textTitle38 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D39 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement40 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer41 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement40);
        java.awt.Graphics2D graphics2D42 = null;
        org.jfree.chart.util.Size2D size2D43 = blockContainer41.arrange(graphics2D42);
        blockContainer41.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D49 = blockContainer41.getBounds();
        java.lang.Object obj51 = textTitle38.draw(graphics2D39, rectangle2D49, (java.lang.Object) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor52 = null;
        java.awt.geom.Point2D point2D53 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D49, rectangleAnchor52);
        pieSectionEntity32.setArea((java.awt.Shape) rectangle2D49);
        pieSectionEntity21.setArea((java.awt.Shape) rectangle2D49);
        piePlot3.drawBackgroundImage(graphics2D12, rectangle2D49);
        org.jfree.chart.entity.ChartEntity chartEntity58 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D49, "RectangleAnchor.BOTTOM_LEFT");
        java.lang.String str59 = chartEntity58.toString();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.08d + "'", double11 == 0.08d);
        org.junit.Assert.assertNotNull(verticalAlignment13);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(size2D43);
        org.junit.Assert.assertNotNull(rectangle2D49);
        org.junit.Assert.assertNull(obj51);
        org.junit.Assert.assertNotNull(point2D53);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "ChartEntity: tooltip = RectangleAnchor.BOTTOM_LEFT" + "'", str59.equals("ChartEntity: tooltip = RectangleAnchor.BOTTOM_LEFT"));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha((float) 0);
        boolean boolean4 = piePlot1.getIgnoreZeroValues();
        double double5 = piePlot1.getShadowXOffset();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot7 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.util.TableOrder tableOrder8 = org.jfree.chart.util.TableOrder.BY_COLUMN;
        multiplePiePlot7.setDataExtractOrder(tableOrder8);
        java.awt.Font font11 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        piePlot13.setForegroundAlpha((float) 0);
        java.awt.Stroke stroke16 = piePlot13.getBaseSectionOutlineStroke();
        piePlot13.setLabelLinkMargin((double) (-256));
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("PieSection: 0, 100(1)", font11, (org.jfree.chart.plot.Plot) piePlot13, false);
        multiplePiePlot7.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart20);
        boolean boolean22 = jFreeChart6.equals((java.lang.Object) jFreeChart20);
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.title.TextTitle textTitle25 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.title.TextTitle textTitle27 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement29 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer30 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement29);
        java.awt.Graphics2D graphics2D31 = null;
        org.jfree.chart.util.Size2D size2D32 = blockContainer30.arrange(graphics2D31);
        blockContainer30.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D38 = blockContainer30.getBounds();
        java.lang.Object obj40 = textTitle27.draw(graphics2D28, rectangle2D38, (java.lang.Object) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor41 = null;
        java.awt.geom.Point2D point2D42 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D38, rectangleAnchor41);
        textTitle25.setBounds(rectangle2D38);
        java.awt.geom.Rectangle2D rectangle2D46 = rectangleInsets24.createOutsetRectangle(rectangle2D38, false, true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo47 = null;
        try {
            jFreeChart20.draw(graphics2D23, rectangle2D46, chartRenderingInfo47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(tableOrder8);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(size2D32);
        org.junit.Assert.assertNotNull(rectangle2D38);
        org.junit.Assert.assertNull(obj40);
        org.junit.Assert.assertNotNull(point2D42);
        org.junit.Assert.assertNotNull(rectangle2D46);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setForegroundAlpha((float) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean12 = rectangleInsets10.equals((java.lang.Object) rectangleAnchor11);
        double double14 = rectangleInsets10.calculateBottomInset((double) (-1L));
        piePlot3.setSimpleLabelOffset(rectangleInsets10);
        java.awt.Color color16 = java.awt.Color.DARK_GRAY;
        piePlot3.setBackgroundPaint((java.awt.Paint) color16);
        boolean boolean18 = defaultCategoryDataset0.hasListener((java.util.EventListener) piePlot3);
        piePlot3.zoom((double) (short) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = piePlot3.getLabelPadding();
        float float22 = piePlot3.getBackgroundImageAlpha();
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 100.0d + "'", double14 == 100.0d);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 0.5f + "'", float22 == 0.5f);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        piePlot1.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        piePlot1.setDataset(pieDataset8);
        piePlot1.setMaximumLabelWidth((double) (byte) 100);
        java.awt.Stroke stroke13 = piePlot1.getSectionOutlineStroke((java.lang.Comparable) (short) 0);
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        piePlot15.setForegroundAlpha((float) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor23 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean24 = rectangleInsets22.equals((java.lang.Object) rectangleAnchor23);
        double double26 = rectangleInsets22.calculateBottomInset((double) (-1L));
        piePlot15.setSimpleLabelOffset(rectangleInsets22);
        piePlot1.setInsets(rectangleInsets22);
        java.awt.Paint paint30 = piePlot1.getSectionPaint((java.lang.Comparable) "JFreeChart version RectangleEdge.TOP.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nTableOrder.BY_ROW");
        java.awt.Paint paint31 = piePlot1.getBaseSectionOutlinePaint();
        org.junit.Assert.assertNull(stroke13);
        org.junit.Assert.assertNotNull(rectangleAnchor23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 100.0d + "'", double26 == 100.0d);
        org.junit.Assert.assertNull(paint30);
        org.junit.Assert.assertNotNull(paint31);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        double double6 = piePlot1.getInteriorGap();
        piePlot1.setMinimumArcAngleToDraw(0.4d);
        org.jfree.chart.plot.Plot plot9 = piePlot1.getRootPlot();
        java.awt.Paint paint10 = piePlot1.getLabelShadowPaint();
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor12 = new org.jfree.chart.plot.PieLabelDistributor((int) '4');
        pieLabelDistributor12.distributeLabels((double) 2, 100.0d);
        pieLabelDistributor12.sort();
        piePlot1.setLabelDistributor((org.jfree.chart.plot.AbstractPieLabelDistributor) pieLabelDistributor12);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.08d + "'", double6 == 0.08d);
        org.junit.Assert.assertNotNull(plot9);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        java.awt.Shape shape6 = piePlot1.getLegendItemShape();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        java.awt.Color color10 = java.awt.Color.red;
        piePlot1.setSectionPaint((java.lang.Comparable) 90.0d, (java.awt.Paint) color10);
        java.awt.Image image12 = piePlot1.getBackgroundImage();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNull(image12);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        java.awt.Color color2 = java.awt.Color.getColor("RectangleEdge.TOP", (int) (short) 1);
        org.jfree.chart.ChartColor chartColor6 = new org.jfree.chart.ChartColor(15, 192, (int) (short) 10);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.awt.Color color8 = java.awt.Color.GREEN;
        boolean boolean9 = chartChangeEventType7.equals((java.lang.Object) color8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        int int11 = color10.getTransparency();
        java.awt.Color color12 = java.awt.Color.BLACK;
        java.awt.Color color13 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        java.awt.Paint[] paintArray14 = new java.awt.Paint[] { color2, chartColor6, color8, color10, color12, color13 };
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType15 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.awt.Color color16 = java.awt.Color.GREEN;
        boolean boolean17 = chartChangeEventType15.equals((java.lang.Object) color16);
        java.awt.Paint paint22 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder23 = new org.jfree.chart.block.BlockBorder((double) 10, (double) '#', (double) 0L, 0.0d, paint22);
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.Paint[] paintArray25 = new java.awt.Paint[] { color16, paint22, color24 };
        java.awt.Paint[] paintArray26 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray27 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray28 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray29 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier30 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray14, paintArray25, paintArray26, strokeArray27, strokeArray28, shapeArray29);
        java.awt.Stroke stroke31 = defaultDrawingSupplier30.getNextStroke();
        java.awt.Paint paint32 = defaultDrawingSupplier30.getNextFillPaint();
        java.awt.Paint paint33 = defaultDrawingSupplier30.getNextPaint();
        java.lang.Object obj34 = defaultDrawingSupplier30.clone();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(chartChangeEventType7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(paintArray14);
        org.junit.Assert.assertNotNull(chartChangeEventType15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(paintArray25);
        org.junit.Assert.assertNotNull(paintArray26);
        org.junit.Assert.assertNotNull(strokeArray27);
        org.junit.Assert.assertNotNull(strokeArray28);
        org.junit.Assert.assertNotNull(shapeArray29);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(obj34);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        piePlot1.setLabelLinkMargin(0.0d);
        boolean boolean8 = piePlot1.getIgnoreZeroValues();
        org.jfree.chart.block.BlockBorder blockBorder13 = new org.jfree.chart.block.BlockBorder(0.0d, 0.025d, (double) 100, (double) (short) 100);
        boolean boolean14 = piePlot1.equals((java.lang.Object) 0.025d);
        piePlot1.setNoDataMessage("JFreeChart version RectangleEdge.TOP.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nTableOrder.BY_ROW");
        piePlot1.zoom(0.0d);
        org.jfree.chart.title.LegendTitle legendTitle19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.block.BlockBorder blockBorder2 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color1);
        multiplePiePlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.util.TableOrder tableOrder4 = org.jfree.chart.util.TableOrder.BY_ROW;
        multiplePiePlot0.setDataExtractOrder(tableOrder4);
        double double6 = multiplePiePlot0.getLimit();
        java.awt.Stroke stroke7 = multiplePiePlot0.getOutlineStroke();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(tableOrder4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity9 = new org.jfree.chart.entity.PieSectionEntity(shape2, pieDataset3, 0, (int) (byte) 100, (java.lang.Comparable) 1L, "RectangleEdge.TOP", "RectangleEdge.TOP");
        org.jfree.chart.JFreeChart jFreeChart10 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent11 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0, jFreeChart10);
        org.jfree.chart.JFreeChart jFreeChart12 = chartChangeEvent11.getChart();
        org.jfree.chart.JFreeChart jFreeChart13 = null;
        chartChangeEvent11.setChart(jFreeChart13);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot16 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.util.TableOrder tableOrder17 = org.jfree.chart.util.TableOrder.BY_COLUMN;
        multiplePiePlot16.setDataExtractOrder(tableOrder17);
        org.jfree.chart.JFreeChart jFreeChart19 = new org.jfree.chart.JFreeChart("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.chart.plot.Plot) multiplePiePlot16);
        chartChangeEvent11.setChart(jFreeChart19);
        jFreeChart19.setBackgroundImageAlpha((float) 'a');
        textTitle1.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart19);
        boolean boolean24 = textTitle1.getExpandToFitSpace();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(jFreeChart12);
        org.junit.Assert.assertNotNull(tableOrder17);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = textTitle1.getTextAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment3 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment2, verticalAlignment3, (double) 'a', (double) 0L);
        org.jfree.chart.block.ColumnArrangement columnArrangement7 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer8 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement7);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.util.Size2D size2D10 = blockContainer8.arrange(graphics2D9);
        blockContainer8.setHeight((double) 1);
        java.lang.Object obj13 = blockContainer8.clone();
        blockContainer8.clear();
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = null;
        try {
            org.jfree.chart.util.Size2D size2D17 = flowArrangement6.arrange(blockContainer8, graphics2D15, rectangleConstraint16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertNotNull(verticalAlignment3);
        org.junit.Assert.assertNotNull(size2D10);
        org.junit.Assert.assertNotNull(obj13);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha((float) 0);
        boolean boolean4 = piePlot1.getIgnoreZeroValues();
        double double5 = piePlot1.getShadowXOffset();
        java.awt.Stroke stroke6 = piePlot1.getLabelLinkStroke();
        java.awt.Paint paint7 = piePlot1.getBaseSectionPaint();
        org.jfree.chart.util.Rotation rotation8 = piePlot1.getDirection();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean15 = rectangleInsets13.equals((java.lang.Object) rectangleAnchor14);
        double double17 = rectangleInsets13.calculateTopInset(0.0d);
        boolean boolean18 = piePlot1.equals((java.lang.Object) double17);
        java.awt.Paint paint19 = piePlot1.getLabelShadowPaint();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator20 = piePlot1.getToolTipGenerator();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(rotation8);
        org.junit.Assert.assertNotNull(rectangleAnchor14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-1.0d) + "'", double17 == (-1.0d));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNull(pieToolTipGenerator20);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font1 = textTitle0.getFont();
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = textTitle0.getVerticalAlignment();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle0);
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity11 = new org.jfree.chart.entity.PieSectionEntity(shape4, pieDataset5, 0, (int) (byte) 100, (java.lang.Comparable) 1L, "RectangleEdge.TOP", "RectangleEdge.TOP");
        org.jfree.data.UnknownKeyException unknownKeyException13 = new org.jfree.data.UnknownKeyException("");
        boolean boolean14 = pieSectionEntity11.equals((java.lang.Object) "");
        java.lang.String str15 = pieSectionEntity11.toString();
        boolean boolean16 = textTitle0.equals((java.lang.Object) pieSectionEntity11);
        textTitle0.setText("RectangleAnchor.CENTER");
        org.jfree.chart.block.ColumnArrangement columnArrangement19 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer20 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement19);
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.util.Size2D size2D22 = blockContainer20.arrange(graphics2D21);
        blockContainer20.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D28 = blockContainer20.getBounds();
        boolean boolean29 = blockContainer20.isEmpty();
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double32 = rectangleInsets30.calculateTopOutset((double) 0);
        java.lang.String str33 = rectangleInsets30.toString();
        blockContainer20.setPadding(rectangleInsets30);
        textTitle0.setMargin(rectangleInsets30);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PieSection: 0, 100(1)" + "'", str15.equals("PieSection: 0, 100(1)"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(size2D22);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 4.0d + "'", double32 == 4.0d);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]" + "'", str33.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.util.Size2D size2D3 = blockContainer1.arrange(graphics2D2);
        java.lang.Object obj4 = null;
        boolean boolean5 = blockContainer1.equals(obj4);
        java.lang.Class<?> wildcardClass6 = blockContainer1.getClass();
        blockContainer1.setID("JFreeChart version RectangleEdge.TOP.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nTableOrder.BY_ROW");
        java.util.List list9 = blockContainer1.getBlocks();
        blockContainer1.clear();
        org.junit.Assert.assertNotNull(size2D3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(list9);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj1 = null;
        int int2 = objectList0.indexOf(obj1);
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        piePlot5.setForegroundAlpha((float) 0);
        java.awt.Stroke stroke8 = piePlot5.getBaseSectionOutlineStroke();
        piePlot5.setLabelLinkMargin((double) (-256));
        piePlot5.setSectionOutlinesVisible(false);
        org.jfree.data.general.DatasetGroup datasetGroup13 = piePlot5.getDatasetGroup();
        objectList0.set(1, (java.lang.Object) datasetGroup13);
        int int15 = objectList0.size();
        java.lang.Object obj17 = objectList0.get((int) ' ');
        objectList0.clear();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(datasetGroup13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
        org.junit.Assert.assertNull(obj17);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.zoom((double) '#');
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        piePlot7.setForegroundAlpha((float) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean16 = rectangleInsets14.equals((java.lang.Object) rectangleAnchor15);
        double double18 = rectangleInsets14.calculateBottomInset((double) (-1L));
        piePlot7.setSimpleLabelOffset(rectangleInsets14);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle20 = org.jfree.chart.plot.PieLabelLinkStyle.CUBIC_CURVE;
        piePlot7.setLabelLinkStyle(pieLabelLinkStyle20);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier22 = piePlot7.getDrawingSupplier();
        boolean boolean23 = piePlot1.equals((java.lang.Object) piePlot7);
        org.jfree.chart.LegendItemSource legendItemSource24 = null;
        org.jfree.chart.title.LegendTitle legendTitle25 = new org.jfree.chart.title.LegendTitle(legendItemSource24);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = legendTitle25.getLegendItemGraphicPadding();
        piePlot7.setSimpleLabelOffset(rectangleInsets26);
        java.awt.Graphics2D graphics2D28 = null;
        java.awt.Shape shape29 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset30 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity36 = new org.jfree.chart.entity.PieSectionEntity(shape29, pieDataset30, 0, (int) (byte) 100, (java.lang.Comparable) 1L, "RectangleEdge.TOP", "RectangleEdge.TOP");
        pieSectionEntity36.setSectionKey((java.lang.Comparable) 0L);
        boolean boolean40 = pieSectionEntity36.equals((java.lang.Object) "hi!");
        org.jfree.chart.title.TextTitle textTitle42 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D43 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement44 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer45 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement44);
        java.awt.Graphics2D graphics2D46 = null;
        org.jfree.chart.util.Size2D size2D47 = blockContainer45.arrange(graphics2D46);
        blockContainer45.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D53 = blockContainer45.getBounds();
        java.lang.Object obj55 = textTitle42.draw(graphics2D43, rectangle2D53, (java.lang.Object) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor56 = null;
        java.awt.geom.Point2D point2D57 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D53, rectangleAnchor56);
        pieSectionEntity36.setArea((java.awt.Shape) rectangle2D53);
        piePlot7.drawBackgroundImage(graphics2D28, rectangle2D53);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor60 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.Shape shape61 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset62 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity68 = new org.jfree.chart.entity.PieSectionEntity(shape61, pieDataset62, 0, (int) (byte) 100, (java.lang.Comparable) 1L, "RectangleEdge.TOP", "RectangleEdge.TOP");
        org.jfree.data.UnknownKeyException unknownKeyException70 = new org.jfree.data.UnknownKeyException("");
        boolean boolean71 = pieSectionEntity68.equals((java.lang.Object) "");
        boolean boolean72 = rectangleAnchor60.equals((java.lang.Object) "");
        java.awt.geom.Point2D point2D73 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D53, rectangleAnchor60);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 100.0d + "'", double18 == 100.0d);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle20);
        org.junit.Assert.assertNotNull(drawingSupplier22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(size2D47);
        org.junit.Assert.assertNotNull(rectangle2D53);
        org.junit.Assert.assertNull(obj55);
        org.junit.Assert.assertNotNull(point2D57);
        org.junit.Assert.assertNotNull(rectangleAnchor60);
        org.junit.Assert.assertNotNull(shape61);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(point2D73);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setForegroundAlpha((float) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean12 = rectangleInsets10.equals((java.lang.Object) rectangleAnchor11);
        double double14 = rectangleInsets10.calculateBottomInset((double) (-1L));
        piePlot3.setSimpleLabelOffset(rectangleInsets10);
        java.awt.Color color16 = java.awt.Color.DARK_GRAY;
        piePlot3.setBackgroundPaint((java.awt.Paint) color16);
        boolean boolean18 = defaultCategoryDataset0.hasListener((java.util.EventListener) piePlot3);
        java.awt.Paint paint19 = piePlot3.getBaseSectionOutlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        piePlot3.handleClick(10, (-254), plotRenderingInfo22);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 100.0d + "'", double14 == 100.0d);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.util.TableOrder tableOrder3 = org.jfree.chart.util.TableOrder.BY_COLUMN;
        multiplePiePlot2.setDataExtractOrder(tableOrder3);
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.chart.plot.Plot) multiplePiePlot2);
        int int6 = jFreeChart5.getSubtitleCount();
        boolean boolean7 = color0.equals((java.lang.Object) jFreeChart5);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(tableOrder3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setExplodePercent((java.lang.Comparable) 10L, (double) (short) 1);
        java.lang.String str7 = piePlot1.getPlotType();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Pie Plot" + "'", str7.equals("Pie Plot"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = org.jfree.chart.util.VerticalAlignment.TOP;
        legendTitle1.setVerticalAlignment(verticalAlignment2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = legendTitle1.getItemLabelPadding();
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setForegroundAlpha((float) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean12 = rectangleInsets10.equals((java.lang.Object) rectangleAnchor11);
        double double14 = rectangleInsets10.calculateBottomInset((double) (-1L));
        piePlot3.setSimpleLabelOffset(rectangleInsets10);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle16 = org.jfree.chart.plot.PieLabelLinkStyle.CUBIC_CURVE;
        piePlot3.setLabelLinkStyle(pieLabelLinkStyle16);
        defaultCategoryDataset0.removeChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot3);
        defaultCategoryDataset0.clear();
        try {
            java.lang.Comparable comparable21 = defaultCategoryDataset0.getRowKey((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 100.0d + "'", double14 == 100.0d);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle16);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.UnitType unitType5 = rectangleInsets4.getUnitType();
        double double6 = rectangleInsets4.getBottom();
        org.junit.Assert.assertNotNull(unitType5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        piePlot1.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        piePlot1.setDataset(pieDataset8);
        org.jfree.data.general.PieDataset pieDataset10 = piePlot1.getDataset();
        piePlot1.setOutlineVisible(false);
        java.awt.Stroke stroke13 = piePlot1.getLabelOutlineStroke();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle14 = piePlot1.getLabelLinkStyle();
        double double15 = piePlot1.getStartAngle();
        org.junit.Assert.assertNull(pieDataset10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 100.0d + "'", double15 == 100.0d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("UnitType.RELATIVE", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo1 = new org.jfree.chart.ui.BasicProjectInfo();
        java.lang.String str2 = basicProjectInfo1.getCopyright();
        basicProjectInfo0.addLibrary((org.jfree.chart.ui.Library) basicProjectInfo1);
        basicProjectInfo0.setInfo("HorizontalAlignment.LEFT");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 0, (int) (byte) 100, (java.lang.Comparable) 1L, "RectangleEdge.TOP", "RectangleEdge.TOP");
        pieSectionEntity7.setSectionKey((java.lang.Comparable) 0L);
        boolean boolean11 = pieSectionEntity7.equals((java.lang.Object) "hi!");
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement15 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer16 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement15);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.util.Size2D size2D18 = blockContainer16.arrange(graphics2D17);
        blockContainer16.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D24 = blockContainer16.getBounds();
        java.lang.Object obj26 = textTitle13.draw(graphics2D14, rectangle2D24, (java.lang.Object) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor27 = null;
        java.awt.geom.Point2D point2D28 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D24, rectangleAnchor27);
        pieSectionEntity7.setArea((java.awt.Shape) rectangle2D24);
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        double double31 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D24, rectangleEdge30);
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        boolean boolean33 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge32);
        double double34 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D24, rectangleEdge32);
        boolean boolean35 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge32);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(size2D18);
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertNull(obj26);
        org.junit.Assert.assertNotNull(point2D28);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            lineBorder0.draw(graphics2D1, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        textTitle1.setURLText("JFreeChart version RectangleEdge.TOP.\n1.2.0-pre.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nTableOrder.BY_ROW");
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        float float6 = piePlot1.getBackgroundAlpha();
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_GREEN;
        piePlot1.setBaseSectionPaint((java.awt.Paint) color7);
        piePlot1.setShadowXOffset((double) 1.0f);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent11 = null;
        piePlot1.axisChanged(axisChangeEvent11);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        java.awt.Color color0 = java.awt.Color.MAGENTA;
        java.awt.Color color1 = java.awt.Color.green;
        java.awt.Color color2 = color1.darker();
        java.awt.Color color3 = java.awt.Color.PINK;
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D4 = new org.jfree.data.DefaultKeyedValues2D();
        java.awt.Color color5 = java.awt.Color.GREEN;
        float[] floatArray10 = new float[] { (byte) 1, (short) 0, (short) 100, (short) -1 };
        float[] floatArray11 = color5.getComponents(floatArray10);
        boolean boolean12 = defaultKeyedValues2D4.equals((java.lang.Object) floatArray11);
        float[] floatArray13 = color3.getColorComponents(floatArray11);
        float[] floatArray14 = color1.getRGBColorComponents(floatArray13);
        float[] floatArray15 = color0.getColorComponents(floatArray14);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(floatArray15);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        java.awt.Stroke stroke6 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        piePlot1.setLabelOutlineStroke(stroke6);
        piePlot1.setLabelLinksVisible(false);
        org.jfree.data.general.PieDataset pieDataset10 = piePlot1.getDataset();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator11 = null;
        piePlot1.setToolTipGenerator(pieToolTipGenerator11);
        boolean boolean13 = piePlot1.getSectionOutlinesVisible();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(pieDataset10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean10 = rectangleInsets8.equals((java.lang.Object) rectangleAnchor9);
        double double12 = rectangleInsets8.calculateTopInset(0.0d);
        piePlot1.setInsets(rectangleInsets8);
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        piePlot15.setForegroundAlpha((float) 0);
        boolean boolean18 = piePlot15.getIgnoreZeroValues();
        double double19 = piePlot15.getShadowXOffset();
        java.awt.Stroke stroke20 = piePlot15.getLabelLinkStroke();
        piePlot1.setBaseSectionOutlineStroke(stroke20);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = piePlot1.getInsets();
        piePlot1.setLabelLinksVisible(true);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.0d) + "'", double12 == (-1.0d));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 4.0d + "'", double19 == 4.0d);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(rectangleInsets22);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha((float) 0);
        boolean boolean4 = piePlot1.getIgnoreZeroValues();
        double double5 = piePlot1.getShadowXOffset();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo9 = null;
        java.awt.image.BufferedImage bufferedImage10 = jFreeChart6.createBufferedImage((int) 'a', (int) (byte) 100, chartRenderingInfo9);
        java.awt.Image image11 = jFreeChart6.getBackgroundImage();
        org.jfree.chart.LegendItemSource legendItemSource12 = null;
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle(legendItemSource12);
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        java.lang.String str15 = rectangleEdge14.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge14);
        legendTitle13.setLegendItemGraphicEdge(rectangleEdge14);
        org.jfree.chart.block.BlockFrame blockFrame18 = legendTitle13.getFrame();
        java.awt.Paint paint23 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder24 = new org.jfree.chart.block.BlockBorder((double) 10, (double) '#', (double) 0L, 0.0d, paint23);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = blockBorder24.getInsets();
        double double27 = rectangleInsets25.calculateLeftOutset(0.025d);
        legendTitle13.setItemLabelPadding(rectangleInsets25);
        jFreeChart6.addSubtitle((org.jfree.chart.title.Title) legendTitle13);
        float float30 = jFreeChart6.getBackgroundImageAlpha();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(bufferedImage10);
        org.junit.Assert.assertNull(image11);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "RectangleEdge.TOP" + "'", str15.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNotNull(blockFrame18);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 35.0d + "'", double27 == 35.0d);
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 0.5f + "'", float30 == 0.5f);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.lang.Object obj1 = null;
        boolean boolean2 = standardPieSectionLabelGenerator0.equals(obj1);
        java.text.NumberFormat numberFormat3 = standardPieSectionLabelGenerator0.getPercentFormat();
        java.text.NumberFormat numberFormat4 = standardPieSectionLabelGenerator0.getPercentFormat();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(numberFormat3);
        org.junit.Assert.assertNotNull(numberFormat4);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        java.awt.Stroke stroke2 = strokeMap0.getStroke((java.lang.Comparable) 4.0d);
        org.jfree.chart.block.ColumnArrangement columnArrangement3 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer4 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.util.Size2D size2D6 = blockContainer4.arrange(graphics2D5);
        java.lang.Object obj7 = null;
        boolean boolean8 = blockContainer4.equals(obj7);
        java.lang.Class<?> wildcardClass9 = blockContainer4.getClass();
        java.awt.Paint paint14 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder15 = new org.jfree.chart.block.BlockBorder((double) 10, (double) '#', (double) 0L, 0.0d, paint14);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = blockBorder15.getInsets();
        blockContainer4.setFrame((org.jfree.chart.block.BlockFrame) blockBorder15);
        boolean boolean18 = strokeMap0.equals((java.lang.Object) blockContainer4);
        org.jfree.data.general.PieDataset pieDataset19 = null;
        org.jfree.chart.plot.PiePlot piePlot20 = new org.jfree.chart.plot.PiePlot(pieDataset19);
        piePlot20.setForegroundAlpha(0.0f);
        piePlot20.setStartAngle((double) 100L);
        java.awt.Shape shape25 = piePlot20.getLegendItemShape();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent26 = null;
        piePlot20.axisChanged(axisChangeEvent26);
        boolean boolean28 = strokeMap0.equals((java.lang.Object) piePlot20);
        boolean boolean30 = strokeMap0.containsKey((java.lang.Comparable) (-4325426));
        org.junit.Assert.assertNull(stroke2);
        org.junit.Assert.assertNotNull(size2D6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = legendTitle1.getLegendItemGraphicPadding();
        double double4 = rectangleInsets2.calculateLeftInset(0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 2.0d + "'", double4 == 2.0d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setForegroundAlpha((float) 0);
        java.awt.Stroke stroke6 = piePlot3.getBaseSectionOutlineStroke();
        piePlot3.setLabelLinkMargin((double) (-256));
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("PieSection: 0, 100(1)", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
        java.awt.Image image11 = jFreeChart10.getBackgroundImage();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        piePlot13.setForegroundAlpha(0.0f);
        piePlot13.setStartAngle((double) 100L);
        piePlot13.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset20 = null;
        piePlot13.setDataset(pieDataset20);
        piePlot13.setMaximumLabelWidth((double) (byte) 100);
        java.awt.Stroke stroke25 = piePlot13.getSectionOutlineStroke((java.lang.Comparable) (short) 0);
        org.jfree.data.general.PieDataset pieDataset26 = null;
        org.jfree.chart.plot.PiePlot piePlot27 = new org.jfree.chart.plot.PiePlot(pieDataset26);
        piePlot27.setForegroundAlpha((float) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor35 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean36 = rectangleInsets34.equals((java.lang.Object) rectangleAnchor35);
        double double38 = rectangleInsets34.calculateBottomInset((double) (-1L));
        piePlot27.setSimpleLabelOffset(rectangleInsets34);
        piePlot13.setInsets(rectangleInsets34);
        jFreeChart10.setPadding(rectangleInsets34);
        jFreeChart10.setTitle("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        java.awt.Graphics2D graphics2D44 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets49 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor50 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean51 = rectangleInsets49.equals((java.lang.Object) rectangleAnchor50);
        org.jfree.chart.block.ColumnArrangement columnArrangement52 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer53 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement52);
        java.awt.Graphics2D graphics2D54 = null;
        org.jfree.chart.util.Size2D size2D55 = blockContainer53.arrange(graphics2D54);
        blockContainer53.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D61 = blockContainer53.getBounds();
        java.awt.geom.Rectangle2D rectangle2D64 = rectangleInsets49.createInsetRectangle(rectangle2D61, true, false);
        org.jfree.data.general.PieDataset pieDataset65 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity71 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D64, pieDataset65, 15, 0, (java.lang.Comparable) 1, "hi!", "RectangleEdge.TOP");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor72 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.geom.Point2D point2D73 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D64, rectangleAnchor72);
        try {
            jFreeChart10.draw(graphics2D44, rectangle2D64);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(image11);
        org.junit.Assert.assertNull(stroke25);
        org.junit.Assert.assertNotNull(rectangleAnchor35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 100.0d + "'", double38 == 100.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(size2D55);
        org.junit.Assert.assertNotNull(rectangle2D61);
        org.junit.Assert.assertNotNull(rectangle2D64);
        org.junit.Assert.assertNotNull(rectangleAnchor72);
        org.junit.Assert.assertNotNull(point2D73);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("JFreeChart version RectangleEdge.TOP.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nTableOrder.BY_ROW");
        java.lang.String str2 = textTitle1.getURLText();
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        java.lang.String str3 = rectangleEdge2.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge2);
        legendTitle1.setLegendItemGraphicEdge(rectangleEdge2);
        org.jfree.chart.block.BlockFrame blockFrame6 = legendTitle1.getFrame();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = legendTitle1.getItemLabelPadding();
        java.awt.Color color10 = java.awt.Color.getColor("TableOrder.BY_ROW", (int) (byte) 1);
        org.jfree.chart.block.BlockBorder blockBorder11 = new org.jfree.chart.block.BlockBorder(rectangleInsets7, (java.awt.Paint) color10);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = blockBorder11.getInsets();
        double double14 = rectangleInsets12.calculateBottomInset(1.0E-5d);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleEdge.TOP" + "'", str3.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(blockFrame6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 2.0d + "'", double14 == 2.0d);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        piePlot1.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        piePlot1.setDataset(pieDataset8);
        org.jfree.chart.plot.Plot plot10 = piePlot1.getParent();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset11 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) piePlot1, (org.jfree.data.general.Dataset) defaultCategoryDataset11);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset13 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot14 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset13);
        org.jfree.data.general.PieDataset pieDataset15 = null;
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot(pieDataset15);
        piePlot16.setForegroundAlpha((float) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean25 = rectangleInsets23.equals((java.lang.Object) rectangleAnchor24);
        double double27 = rectangleInsets23.calculateBottomInset((double) (-1L));
        piePlot16.setSimpleLabelOffset(rectangleInsets23);
        java.awt.Color color29 = java.awt.Color.DARK_GRAY;
        piePlot16.setBackgroundPaint((java.awt.Paint) color29);
        boolean boolean31 = defaultCategoryDataset13.hasListener((java.util.EventListener) piePlot16);
        piePlot16.zoom((double) (short) 0);
        org.jfree.data.general.DatasetGroup datasetGroup34 = piePlot16.getDatasetGroup();
        defaultCategoryDataset11.addChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot16);
        org.junit.Assert.assertNull(plot10);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 100.0d + "'", double27 == 100.0d);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNull(datasetGroup34);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.extendHeight(0.0d);
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity10 = new org.jfree.chart.entity.PieSectionEntity(shape3, pieDataset4, 0, (int) (byte) 100, (java.lang.Comparable) 1L, "RectangleEdge.TOP", "RectangleEdge.TOP");
        pieSectionEntity10.setSectionKey((java.lang.Comparable) 0L);
        boolean boolean14 = pieSectionEntity10.equals((java.lang.Object) "hi!");
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement18 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer19 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement18);
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.util.Size2D size2D21 = blockContainer19.arrange(graphics2D20);
        blockContainer19.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D27 = blockContainer19.getBounds();
        java.lang.Object obj29 = textTitle16.draw(graphics2D17, rectangle2D27, (java.lang.Object) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor30 = null;
        java.awt.geom.Point2D point2D31 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D27, rectangleAnchor30);
        pieSectionEntity10.setArea((java.awt.Shape) rectangle2D27);
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        double double34 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D27, rectangleEdge33);
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        boolean boolean36 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge35);
        double double37 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D27, rectangleEdge35);
        org.jfree.chart.entity.ChartEntity chartEntity40 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D27, "hi!", "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        java.awt.geom.Rectangle2D rectangle2D41 = rectangleInsets0.createOutsetRectangle(rectangle2D27);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(size2D21);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertNull(obj29);
        org.junit.Assert.assertNotNull(point2D31);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D41);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        piePlot2.setForegroundAlpha((float) 0);
        boolean boolean5 = piePlot2.getIgnoreZeroValues();
        double double6 = piePlot2.getShadowXOffset();
        java.awt.Stroke stroke7 = piePlot2.getLabelLinkStroke();
        java.awt.Paint paint8 = piePlot2.getBaseSectionPaint();
        java.awt.Paint paint9 = piePlot2.getLabelPaint();
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot(pieDataset10);
        piePlot11.setForegroundAlpha(0.0f);
        piePlot11.zoom((double) '#');
        org.jfree.data.general.PieDataset pieDataset16 = null;
        org.jfree.chart.plot.PiePlot piePlot17 = new org.jfree.chart.plot.PiePlot(pieDataset16);
        piePlot17.setForegroundAlpha((float) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor25 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean26 = rectangleInsets24.equals((java.lang.Object) rectangleAnchor25);
        double double28 = rectangleInsets24.calculateBottomInset((double) (-1L));
        piePlot17.setSimpleLabelOffset(rectangleInsets24);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle30 = org.jfree.chart.plot.PieLabelLinkStyle.CUBIC_CURVE;
        piePlot17.setLabelLinkStyle(pieLabelLinkStyle30);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier32 = piePlot17.getDrawingSupplier();
        boolean boolean33 = piePlot11.equals((java.lang.Object) piePlot17);
        org.jfree.chart.LegendItemSource legendItemSource34 = null;
        org.jfree.chart.title.LegendTitle legendTitle35 = new org.jfree.chart.title.LegendTitle(legendItemSource34);
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = legendTitle35.getLegendItemGraphicPadding();
        piePlot17.setSimpleLabelOffset(rectangleInsets36);
        boolean boolean38 = piePlot2.equals((java.lang.Object) rectangleInsets36);
        boolean boolean39 = chartChangeEventType0.equals((java.lang.Object) piePlot2);
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(rectangleAnchor25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 100.0d + "'", double28 == 100.0d);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle30);
        org.junit.Assert.assertNotNull(drawingSupplier32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        java.awt.Color color4 = java.awt.Color.GREEN;
        float[] floatArray9 = new float[] { (byte) 1, (short) 0, (short) 100, (short) -1 };
        float[] floatArray10 = color4.getComponents(floatArray9);
        org.jfree.chart.block.BlockBorder blockBorder11 = new org.jfree.chart.block.BlockBorder((double) 1L, 0.0d, (double) 1, 0.0d, (java.awt.Paint) color4);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 0, (int) (byte) 100, (java.lang.Comparable) 1L, "RectangleEdge.TOP", "RectangleEdge.TOP");
        org.jfree.data.general.PieDataset pieDataset8 = null;
        pieSectionEntity7.setDataset(pieDataset8);
        org.jfree.chart.LegendItemSource legendItemSource10 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement11 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.ColumnArrangement columnArrangement12 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle(legendItemSource10, (org.jfree.chart.block.Arrangement) columnArrangement11, (org.jfree.chart.block.Arrangement) columnArrangement12);
        columnArrangement11.clear();
        boolean boolean15 = pieSectionEntity7.equals((java.lang.Object) columnArrangement11);
        org.jfree.chart.LegendItemSource legendItemSource16 = null;
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle(legendItemSource16);
        boolean boolean18 = columnArrangement11.equals((java.lang.Object) legendTitle17);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        piePlot1.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        piePlot1.setDataset(pieDataset8);
        piePlot1.setMaximumLabelWidth((double) (byte) 100);
        java.awt.Stroke stroke13 = piePlot1.getSectionOutlineStroke((java.lang.Comparable) (short) 0);
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        piePlot15.setForegroundAlpha((float) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor23 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean24 = rectangleInsets22.equals((java.lang.Object) rectangleAnchor23);
        double double26 = rectangleInsets22.calculateBottomInset((double) (-1L));
        piePlot15.setSimpleLabelOffset(rectangleInsets22);
        piePlot1.setInsets(rectangleInsets22);
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor34 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean35 = rectangleInsets33.equals((java.lang.Object) rectangleAnchor34);
        org.jfree.chart.block.ColumnArrangement columnArrangement36 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer37 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement36);
        java.awt.Graphics2D graphics2D38 = null;
        org.jfree.chart.util.Size2D size2D39 = blockContainer37.arrange(graphics2D38);
        blockContainer37.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D45 = blockContainer37.getBounds();
        java.awt.geom.Rectangle2D rectangle2D48 = rectangleInsets33.createInsetRectangle(rectangle2D45, true, false);
        piePlot1.setLegendItemShape((java.awt.Shape) rectangle2D48);
        java.awt.Paint paint50 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        piePlot1.setNoDataMessagePaint(paint50);
        org.junit.Assert.assertNull(stroke13);
        org.junit.Assert.assertNotNull(rectangleAnchor23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 100.0d + "'", double26 == 100.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(size2D39);
        org.junit.Assert.assertNotNull(rectangle2D45);
        org.junit.Assert.assertNotNull(rectangle2D48);
        org.junit.Assert.assertNotNull(paint50);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setForegroundAlpha((float) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean12 = rectangleInsets10.equals((java.lang.Object) rectangleAnchor11);
        double double14 = rectangleInsets10.calculateBottomInset((double) (-1L));
        piePlot3.setSimpleLabelOffset(rectangleInsets10);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle16 = org.jfree.chart.plot.PieLabelLinkStyle.CUBIC_CURVE;
        piePlot3.setLabelLinkStyle(pieLabelLinkStyle16);
        defaultCategoryDataset0.removeChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot3);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot19 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 100.0d + "'", double14 == 100.0d);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle16);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        piePlot1.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        piePlot1.setDataset(pieDataset8);
        org.jfree.data.general.PieDataset pieDataset10 = piePlot1.getDataset();
        piePlot1.setOutlineVisible(false);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset13 = new org.jfree.data.category.DefaultCategoryDataset();
        java.util.List list14 = defaultCategoryDataset13.getColumnKeys();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent15 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) piePlot1, (org.jfree.data.general.Dataset) defaultCategoryDataset13);
        defaultCategoryDataset13.addValue((java.lang.Number) 100L, (java.lang.Comparable) 0.0f, (java.lang.Comparable) "ChartChangeEventType.DATASET_UPDATED");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot20 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset13);
        org.junit.Assert.assertNull(pieDataset10);
        org.junit.Assert.assertNotNull(list14);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 0, (int) (byte) 100, (java.lang.Comparable) 1L, "RectangleEdge.TOP", "RectangleEdge.TOP");
        pieSectionEntity7.setSectionKey((java.lang.Comparable) true);
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment12 = textTitle11.getTextAlignment();
        textTitle11.setURLText("RectangleEdge.TOP");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = textTitle11.getHorizontalAlignment();
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement19 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer20 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement19);
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.util.Size2D size2D22 = blockContainer20.arrange(graphics2D21);
        blockContainer20.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D28 = blockContainer20.getBounds();
        java.lang.Object obj30 = textTitle17.draw(graphics2D18, rectangle2D28, (java.lang.Object) (short) 0);
        org.jfree.chart.title.TextTitle textTitle32 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment33 = textTitle32.getTextAlignment();
        java.lang.String str34 = horizontalAlignment33.toString();
        textTitle17.setHorizontalAlignment(horizontalAlignment33);
        org.jfree.chart.title.TextTitle textTitle36 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font37 = textTitle36.getFont();
        org.jfree.chart.util.VerticalAlignment verticalAlignment38 = textTitle36.getVerticalAlignment();
        textTitle17.setVerticalAlignment(verticalAlignment38);
        org.jfree.chart.block.ColumnArrangement columnArrangement42 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment15, verticalAlignment38, 0.0d, (double) (-1.0f));
        boolean boolean43 = pieSectionEntity7.equals((java.lang.Object) verticalAlignment38);
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator44 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator45 = null;
        try {
            java.lang.String str46 = pieSectionEntity7.getImageMapAreaTag(toolTipTagFragmentGenerator44, uRLTagFragmentGenerator45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(horizontalAlignment12);
        org.junit.Assert.assertNotNull(horizontalAlignment15);
        org.junit.Assert.assertNotNull(size2D22);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertNull(obj30);
        org.junit.Assert.assertNotNull(horizontalAlignment33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "HorizontalAlignment.CENTER" + "'", str34.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNotNull(verticalAlignment38);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.lang.String str1 = standardPieSectionLabelGenerator0.getLabelFormat();
        java.text.AttributedString attributedString3 = null;
        standardPieSectionLabelGenerator0.setAttributedLabel(0, attributedString3);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{0}" + "'", str1.equals("{0}"));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.util.VerticalAlignment.TOP;
        legendTitle3.setVerticalAlignment(verticalAlignment4);
        java.awt.geom.Rectangle2D rectangle2D6 = legendTitle3.getBounds();
        blockContainer1.add((org.jfree.chart.block.Block) legendTitle3);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(rectangle2D6);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        java.awt.Stroke stroke2 = strokeMap0.getStroke((java.lang.Comparable) 4.0d);
        strokeMap0.clear();
        java.lang.Comparable comparable4 = null;
        try {
            boolean boolean5 = strokeMap0.containsKey(comparable4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(stroke2);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean10 = rectangleInsets8.equals((java.lang.Object) rectangleAnchor9);
        double double12 = rectangleInsets8.calculateTopInset(0.0d);
        piePlot1.setInsets(rectangleInsets8);
        double double15 = rectangleInsets8.trimWidth((double) 192);
        double double17 = rectangleInsets8.calculateTopOutset(1.0E-5d);
        double double18 = rectangleInsets8.getRight();
        double double19 = rectangleInsets8.getRight();
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.0d) + "'", double12 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 181.0d + "'", double15 == 181.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-1.0d) + "'", double17 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setForegroundAlpha((float) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean12 = rectangleInsets10.equals((java.lang.Object) rectangleAnchor11);
        double double14 = rectangleInsets10.calculateBottomInset((double) (-1L));
        piePlot3.setSimpleLabelOffset(rectangleInsets10);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle16 = org.jfree.chart.plot.PieLabelLinkStyle.CUBIC_CURVE;
        piePlot3.setLabelLinkStyle(pieLabelLinkStyle16);
        defaultCategoryDataset0.removeChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot3);
        int int20 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) (-1.0f));
        try {
            java.lang.Comparable comparable22 = defaultCategoryDataset0.getRowKey((-254));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 100.0d + "'", double14 == 100.0d);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setForegroundAlpha((float) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean12 = rectangleInsets10.equals((java.lang.Object) rectangleAnchor11);
        double double14 = rectangleInsets10.calculateBottomInset((double) (-1L));
        piePlot3.setSimpleLabelOffset(rectangleInsets10);
        java.awt.Color color16 = java.awt.Color.DARK_GRAY;
        piePlot3.setBackgroundPaint((java.awt.Paint) color16);
        boolean boolean18 = defaultCategoryDataset0.hasListener((java.util.EventListener) piePlot3);
        int int19 = defaultCategoryDataset0.getColumnCount();
        try {
            java.lang.Comparable comparable21 = defaultCategoryDataset0.getRowKey((-256));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 100.0d + "'", double14 == 100.0d);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = textTitle1.getTextAlignment();
        textTitle1.setURLText("RectangleEdge.TOP");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = textTitle1.getHorizontalAlignment();
        java.lang.String str6 = textTitle1.getURLText();
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertNotNull(horizontalAlignment5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "RectangleEdge.TOP" + "'", str6.equals("RectangleEdge.TOP"));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        java.awt.Color color1 = color0.brighter();
        java.awt.Color color2 = color0.darker();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = org.jfree.chart.util.RectangleEdge.LEFT;
        boolean boolean4 = color0.equals((java.lang.Object) rectangleEdge3);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        java.lang.String str1 = basicProjectInfo0.getName();
        org.jfree.chart.ui.Library[] libraryArray2 = basicProjectInfo0.getLibraries();
        java.lang.String str3 = basicProjectInfo0.getCopyright();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(libraryArray2);
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font1 = textTitle0.getFont();
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = textTitle0.getVerticalAlignment();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle0);
        java.lang.Object obj4 = titleChangeEvent3.getSource();
        java.awt.Font font6 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot(pieDataset7);
        piePlot8.setForegroundAlpha((float) 0);
        java.awt.Stroke stroke11 = piePlot8.getBaseSectionOutlineStroke();
        piePlot8.setLabelLinkMargin((double) (-256));
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("PieSection: 0, 100(1)", font6, (org.jfree.chart.plot.Plot) piePlot8, false);
        jFreeChart15.setBorderVisible(false);
        boolean boolean18 = jFreeChart15.isBorderVisible();
        titleChangeEvent3.setChart(jFreeChart15);
        org.jfree.chart.title.TextTitle textTitle20 = null;
        jFreeChart15.setTitle(textTitle20);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        java.awt.Stroke stroke6 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        piePlot1.setLabelOutlineStroke(stroke6);
        piePlot1.setMaximumLabelWidth((-1.0d));
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot(pieDataset10);
        piePlot11.setForegroundAlpha(0.0f);
        piePlot11.setStartAngle((double) 100L);
        java.awt.Stroke stroke16 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        piePlot11.setLabelOutlineStroke(stroke16);
        java.awt.Stroke stroke18 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        piePlot11.setBaseSectionOutlineStroke(stroke18);
        piePlot1.setLabelOutlineStroke(stroke18);
        double double21 = piePlot1.getMaximumExplodePercent();
        org.jfree.data.general.PieDataset pieDataset22 = null;
        org.jfree.chart.plot.PiePlot piePlot23 = new org.jfree.chart.plot.PiePlot(pieDataset22);
        piePlot23.setForegroundAlpha(0.0f);
        piePlot23.setStartAngle((double) 100L);
        piePlot23.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset30 = null;
        piePlot23.setDataset(pieDataset30);
        piePlot23.setMaximumLabelWidth((double) (byte) 100);
        org.jfree.data.general.PieDataset pieDataset34 = piePlot23.getDataset();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent35 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot23);
        piePlot1.notifyListeners(plotChangeEvent35);
        org.jfree.chart.plot.Plot plot37 = plotChangeEvent35.getPlot();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNull(pieDataset34);
        org.junit.Assert.assertNotNull(plot37);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Enumeration<java.lang.String> strEnumeration1 = jFreeChartResources0.getKeys();
        java.util.Locale locale2 = jFreeChartResources0.getLocale();
        java.util.Locale locale3 = jFreeChartResources0.getLocale();
        java.util.Locale locale4 = jFreeChartResources0.getLocale();
        org.junit.Assert.assertNotNull(strEnumeration1);
        org.junit.Assert.assertNull(locale2);
        org.junit.Assert.assertNull(locale3);
        org.junit.Assert.assertNull(locale4);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.util.Size2D size2D3 = blockContainer1.arrange(graphics2D2);
        java.lang.Object obj4 = null;
        boolean boolean5 = blockContainer1.equals(obj4);
        java.lang.Class<?> wildcardClass6 = blockContainer1.getClass();
        blockContainer1.setID("JFreeChart version RectangleEdge.TOP.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nTableOrder.BY_ROW");
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font10 = textTitle9.getFont();
        org.jfree.chart.util.VerticalAlignment verticalAlignment11 = textTitle9.getVerticalAlignment();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent12 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle9);
        java.awt.Shape shape13 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity20 = new org.jfree.chart.entity.PieSectionEntity(shape13, pieDataset14, 0, (int) (byte) 100, (java.lang.Comparable) 1L, "RectangleEdge.TOP", "RectangleEdge.TOP");
        org.jfree.data.UnknownKeyException unknownKeyException22 = new org.jfree.data.UnknownKeyException("");
        boolean boolean23 = pieSectionEntity20.equals((java.lang.Object) "");
        java.lang.String str24 = pieSectionEntity20.toString();
        boolean boolean25 = textTitle9.equals((java.lang.Object) pieSectionEntity20);
        blockContainer1.add((org.jfree.chart.block.Block) textTitle9);
        org.junit.Assert.assertNotNull(size2D3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(verticalAlignment11);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "PieSection: 0, 100(1)" + "'", str24.equals("PieSection: 0, 100(1)"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha((float) 0);
        boolean boolean4 = piePlot1.getIgnoreZeroValues();
        double double5 = piePlot1.getShadowXOffset();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo9 = null;
        java.awt.image.BufferedImage bufferedImage10 = jFreeChart6.createBufferedImage((int) 'a', (int) (byte) 100, chartRenderingInfo9);
        java.awt.Image image11 = jFreeChart6.getBackgroundImage();
        org.jfree.chart.title.LegendTitle legendTitle13 = jFreeChart6.getLegend((-262450));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(bufferedImage10);
        org.junit.Assert.assertNull(image11);
        org.junit.Assert.assertNull(legendTitle13);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        java.awt.Color color0 = java.awt.Color.orange;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha((float) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean10 = rectangleInsets8.equals((java.lang.Object) rectangleAnchor9);
        double double12 = rectangleInsets8.calculateBottomInset((double) (-1L));
        piePlot1.setSimpleLabelOffset(rectangleInsets8);
        java.awt.Color color14 = java.awt.Color.DARK_GRAY;
        piePlot1.setBackgroundPaint((java.awt.Paint) color14);
        org.jfree.chart.util.Rotation rotation16 = piePlot1.getDirection();
        java.lang.String str17 = rotation16.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 100.0d + "'", double12 == 100.0d);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(rotation16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Rotation.CLOCKWISE" + "'", str17.equals("Rotation.CLOCKWISE"));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        java.awt.Stroke stroke6 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        piePlot1.setLabelOutlineStroke(stroke6);
        double double8 = piePlot1.getLabelLinkMargin();
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.Shape shape11 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity18 = new org.jfree.chart.entity.PieSectionEntity(shape11, pieDataset12, 0, (int) (byte) 100, (java.lang.Comparable) 1L, "RectangleEdge.TOP", "RectangleEdge.TOP");
        pieSectionEntity18.setSectionKey((java.lang.Comparable) 0L);
        boolean boolean22 = pieSectionEntity18.equals((java.lang.Object) "hi!");
        org.jfree.chart.title.TextTitle textTitle24 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement26 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer27 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement26);
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.util.Size2D size2D29 = blockContainer27.arrange(graphics2D28);
        blockContainer27.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D35 = blockContainer27.getBounds();
        java.lang.Object obj37 = textTitle24.draw(graphics2D25, rectangle2D35, (java.lang.Object) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor38 = null;
        java.awt.geom.Point2D point2D39 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D35, rectangleAnchor38);
        pieSectionEntity18.setArea((java.awt.Shape) rectangle2D35);
        java.lang.Object obj41 = null;
        try {
            java.lang.Object obj42 = legendTitle9.draw(graphics2D10, rectangle2D35, obj41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.025d + "'", double8 == 0.025d);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(size2D29);
        org.junit.Assert.assertNotNull(rectangle2D35);
        org.junit.Assert.assertNull(obj37);
        org.junit.Assert.assertNotNull(point2D39);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setForegroundAlpha(0.0f);
        piePlot3.setStartAngle((double) 100L);
        piePlot3.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset10 = null;
        piePlot3.setDataset(pieDataset10);
        org.jfree.chart.plot.Plot plot12 = piePlot3.getParent();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset13 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent14 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) piePlot3, (org.jfree.data.general.Dataset) defaultCategoryDataset13);
        java.lang.Object obj15 = defaultCategoryDataset13.clone();
        int int16 = defaultCategoryDataset13.getColumnCount();
        int int18 = defaultCategoryDataset13.getRowIndex((java.lang.Comparable) "HorizontalAlignment.LEFT");
        java.lang.Object obj19 = defaultCategoryDataset13.clone();
        multiplePiePlot1.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset13);
        org.junit.Assert.assertNull(plot12);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(obj19);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        java.awt.Stroke stroke2 = strokeMap0.getStroke((java.lang.Comparable) 4.0d);
        org.jfree.chart.block.ColumnArrangement columnArrangement3 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer4 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.util.Size2D size2D6 = blockContainer4.arrange(graphics2D5);
        java.lang.Object obj7 = null;
        boolean boolean8 = blockContainer4.equals(obj7);
        java.lang.Class<?> wildcardClass9 = blockContainer4.getClass();
        java.awt.Paint paint14 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder15 = new org.jfree.chart.block.BlockBorder((double) 10, (double) '#', (double) 0L, 0.0d, paint14);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = blockBorder15.getInsets();
        blockContainer4.setFrame((org.jfree.chart.block.BlockFrame) blockBorder15);
        boolean boolean18 = strokeMap0.equals((java.lang.Object) blockContainer4);
        strokeMap0.clear();
        java.awt.Shape shape20 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset21 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity27 = new org.jfree.chart.entity.PieSectionEntity(shape20, pieDataset21, 0, (int) (byte) 100, (java.lang.Comparable) 1L, "RectangleEdge.TOP", "RectangleEdge.TOP");
        org.jfree.data.general.PieDataset pieDataset28 = null;
        pieSectionEntity27.setDataset(pieDataset28);
        java.lang.String str30 = pieSectionEntity27.toString();
        java.awt.Shape shape31 = pieSectionEntity27.getArea();
        boolean boolean32 = strokeMap0.equals((java.lang.Object) pieSectionEntity27);
        org.junit.Assert.assertNull(stroke2);
        org.junit.Assert.assertNotNull(size2D6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "PieSection: 0, 100(1)" + "'", str30.equals("PieSection: 0, 100(1)"));
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        piePlot1.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        piePlot1.setDataset(pieDataset8);
        org.jfree.data.general.PieDataset pieDataset10 = piePlot1.getDataset();
        java.lang.String str11 = piePlot1.getNoDataMessage();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        piePlot1.setLabelLinkPaint((java.awt.Paint) color12);
        org.junit.Assert.assertNull(pieDataset10);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(color12);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = textTitle1.getTextAlignment();
        textTitle1.setToolTipText("http://www.jfree.org/jfreechart/index.html");
        textTitle1.setHeight(0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        java.lang.String str3 = standardPieSectionLabelGenerator0.generateSectionLabel(pieDataset1, (java.lang.Comparable) "RectangleInsets[t=-1.0,l=10.0,b=100.0,r=1.0]");
        java.lang.Object obj4 = standardPieSectionLabelGenerator0.clone();
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        double double1 = multiplePiePlot0.getLimit();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent2 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = plotChangeEvent2.getType();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(chartChangeEventType3);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        piePlot1.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        piePlot1.setDataset(pieDataset8);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setShadowXOffset((double) '4');
        piePlot1.setLabelLinkMargin(0.0d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setForegroundAlpha((float) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean12 = rectangleInsets10.equals((java.lang.Object) rectangleAnchor11);
        double double14 = rectangleInsets10.calculateBottomInset((double) (-1L));
        piePlot3.setSimpleLabelOffset(rectangleInsets10);
        java.awt.Color color16 = java.awt.Color.DARK_GRAY;
        piePlot3.setBackgroundPaint((java.awt.Paint) color16);
        boolean boolean18 = defaultCategoryDataset0.hasListener((java.util.EventListener) piePlot3);
        java.awt.Paint paint19 = piePlot3.getBaseSectionOutlinePaint();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment20 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle("");
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        textTitle22.setBackgroundPaint((java.awt.Paint) color23);
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        java.awt.Color color26 = color25.brighter();
        textTitle22.setPaint((java.awt.Paint) color26);
        org.jfree.chart.util.VerticalAlignment verticalAlignment28 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        textTitle22.setVerticalAlignment(verticalAlignment28);
        org.jfree.chart.block.FlowArrangement flowArrangement32 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment20, verticalAlignment28, (double) (-1), 10.0d);
        org.jfree.chart.title.TextTitle textTitle34 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment35 = textTitle34.getTextAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment36 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.FlowArrangement flowArrangement39 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment35, verticalAlignment36, (double) 'a', (double) 0L);
        org.jfree.chart.title.LegendTitle legendTitle40 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot3, (org.jfree.chart.block.Arrangement) flowArrangement32, (org.jfree.chart.block.Arrangement) flowArrangement39);
        java.awt.Color color41 = org.jfree.chart.ChartColor.DARK_GREEN;
        boolean boolean42 = piePlot3.equals((java.lang.Object) color41);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 100.0d + "'", double14 == 100.0d);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(horizontalAlignment20);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(verticalAlignment28);
        org.junit.Assert.assertNotNull(horizontalAlignment35);
        org.junit.Assert.assertNotNull(verticalAlignment36);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        java.awt.Color color1 = java.awt.Color.GREEN;
        float[] floatArray6 = new float[] { (byte) 1, (short) 0, (short) 100, (short) -1 };
        float[] floatArray7 = color1.getComponents(floatArray6);
        boolean boolean8 = unitType0.equals((java.lang.Object) color1);
        java.awt.Stroke[] strokeArray9 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        boolean boolean10 = unitType0.equals((java.lang.Object) strokeArray9);
        java.lang.String str11 = unitType0.toString();
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(strokeArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "UnitType.ABSOLUTE" + "'", str11.equals("UnitType.ABSOLUTE"));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        float[] floatArray1 = null;
        float[] floatArray2 = color0.getComponents(floatArray1);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray2);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha((float) 0);
        boolean boolean4 = piePlot1.getIgnoreZeroValues();
        double double5 = piePlot1.getShadowXOffset();
        java.awt.Stroke stroke6 = piePlot1.getLabelLinkStroke();
        java.awt.Paint paint7 = piePlot1.getBaseSectionPaint();
        java.awt.Paint paint8 = piePlot1.getLabelPaint();
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        piePlot10.setForegroundAlpha(0.0f);
        piePlot10.zoom((double) '#');
        org.jfree.data.general.PieDataset pieDataset15 = null;
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot(pieDataset15);
        piePlot16.setForegroundAlpha((float) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean25 = rectangleInsets23.equals((java.lang.Object) rectangleAnchor24);
        double double27 = rectangleInsets23.calculateBottomInset((double) (-1L));
        piePlot16.setSimpleLabelOffset(rectangleInsets23);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle29 = org.jfree.chart.plot.PieLabelLinkStyle.CUBIC_CURVE;
        piePlot16.setLabelLinkStyle(pieLabelLinkStyle29);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier31 = piePlot16.getDrawingSupplier();
        boolean boolean32 = piePlot10.equals((java.lang.Object) piePlot16);
        org.jfree.chart.LegendItemSource legendItemSource33 = null;
        org.jfree.chart.title.LegendTitle legendTitle34 = new org.jfree.chart.title.LegendTitle(legendItemSource33);
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = legendTitle34.getLegendItemGraphicPadding();
        piePlot16.setSimpleLabelOffset(rectangleInsets35);
        boolean boolean37 = piePlot1.equals((java.lang.Object) rectangleInsets35);
        org.jfree.data.general.PieDataset pieDataset38 = null;
        org.jfree.chart.plot.PiePlot piePlot39 = new org.jfree.chart.plot.PiePlot(pieDataset38);
        piePlot39.setForegroundAlpha(0.0f);
        piePlot39.setStartAngle((double) 100L);
        piePlot39.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset46 = null;
        piePlot39.setDataset(pieDataset46);
        org.jfree.data.general.PieDataset pieDataset48 = piePlot39.getDataset();
        piePlot39.setOutlineVisible(false);
        boolean boolean51 = piePlot1.equals((java.lang.Object) piePlot39);
        org.jfree.data.general.PieDataset pieDataset52 = piePlot1.getDataset();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 100.0d + "'", double27 == 100.0d);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle29);
        org.junit.Assert.assertNotNull(drawingSupplier31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNull(pieDataset48);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNull(pieDataset52);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        java.lang.String str3 = standardPieSectionLabelGenerator0.generateSectionLabel(pieDataset1, (java.lang.Comparable) "RectangleInsets[t=-1.0,l=10.0,b=100.0,r=1.0]");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle4 = org.jfree.chart.plot.PieLabelLinkStyle.CUBIC_CURVE;
        boolean boolean5 = standardPieSectionLabelGenerator0.equals((java.lang.Object) pieLabelLinkStyle4);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator6 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset7 = null;
        java.lang.String str9 = standardPieSectionLabelGenerator6.generateSectionLabel(pieDataset7, (java.lang.Comparable) "RectangleInsets[t=-1.0,l=10.0,b=100.0,r=1.0]");
        java.text.NumberFormat numberFormat10 = standardPieSectionLabelGenerator6.getNumberFormat();
        boolean boolean11 = standardPieSectionLabelGenerator0.equals((java.lang.Object) standardPieSectionLabelGenerator6);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(numberFormat10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha((float) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean10 = rectangleInsets8.equals((java.lang.Object) rectangleAnchor9);
        double double12 = rectangleInsets8.calculateBottomInset((double) (-1L));
        piePlot1.setSimpleLabelOffset(rectangleInsets8);
        double double15 = rectangleInsets8.trimWidth(90.0d);
        double double17 = rectangleInsets8.extendWidth((double) 'a');
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 100.0d + "'", double12 == 100.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 79.0d + "'", double15 == 79.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 108.0d + "'", double17 == 108.0d);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke1 = lineBorder0.getStroke();
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        piePlot1.setForegroundAlpha((float) (short) 100);
        double double8 = piePlot1.getShadowYOffset();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        piePlot1.handleClick(192, 0, plotRenderingInfo11);
        java.awt.Paint paint13 = piePlot1.getBaseSectionOutlinePaint();
        java.lang.String str14 = piePlot1.getPlotType();
        piePlot1.setBackgroundAlpha((float) '4');
        try {
            piePlot1.setInteriorGap((double) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid 'percent' (1.0) argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.0d + "'", double8 == 4.0d);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Pie Plot" + "'", str14.equals("Pie Plot"));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setForegroundAlpha((float) 0);
        java.awt.Stroke stroke6 = piePlot3.getBaseSectionOutlineStroke();
        piePlot3.setLabelLinkMargin((double) (-256));
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("PieSection: 0, 100(1)", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
        jFreeChart10.setBorderVisible(false);
        boolean boolean13 = jFreeChart10.isBorderVisible();
        jFreeChart10.setBackgroundImageAlpha(0.0f);
        org.jfree.data.general.PieDataset pieDataset16 = null;
        org.jfree.chart.plot.PiePlot piePlot17 = new org.jfree.chart.plot.PiePlot(pieDataset16);
        piePlot17.setForegroundAlpha(0.0f);
        piePlot17.setStartAngle((double) 100L);
        piePlot17.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset24 = null;
        piePlot17.setDataset(pieDataset24);
        org.jfree.data.general.PieDataset pieDataset26 = piePlot17.getDataset();
        java.lang.String str27 = piePlot17.getNoDataMessage();
        piePlot17.setLabelLinkMargin((double) 0.5f);
        java.awt.Paint paint30 = piePlot17.getNoDataMessagePaint();
        java.awt.Color color31 = java.awt.Color.BLACK;
        piePlot17.setBaseSectionOutlinePaint((java.awt.Paint) color31);
        java.awt.Color color33 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.color.ColorSpace colorSpace34 = color33.getColorSpace();
        java.awt.Color color35 = java.awt.Color.GREEN;
        float[] floatArray40 = new float[] { (byte) 1, (short) 0, (short) 100, (short) -1 };
        float[] floatArray41 = color35.getComponents(floatArray40);
        float[] floatArray42 = color31.getComponents(colorSpace34, floatArray41);
        java.awt.color.ColorSpace colorSpace43 = color31.getColorSpace();
        boolean boolean44 = jFreeChart10.equals((java.lang.Object) color31);
        java.awt.Paint paint45 = jFreeChart10.getBorderPaint();
        org.jfree.chart.title.TextTitle textTitle46 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font47 = textTitle46.getFont();
        org.jfree.chart.util.VerticalAlignment verticalAlignment48 = textTitle46.getVerticalAlignment();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent49 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle46);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType50 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        titleChangeEvent49.setType(chartChangeEventType50);
        org.jfree.chart.title.Title title52 = titleChangeEvent49.getTitle();
        jFreeChart10.titleChanged(titleChangeEvent49);
        jFreeChart10.clearSubtitles();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(pieDataset26);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(colorSpace34);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(floatArray40);
        org.junit.Assert.assertNotNull(floatArray41);
        org.junit.Assert.assertNotNull(floatArray42);
        org.junit.Assert.assertNotNull(colorSpace43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertNotNull(font47);
        org.junit.Assert.assertNotNull(verticalAlignment48);
        org.junit.Assert.assertNotNull(chartChangeEventType50);
        org.junit.Assert.assertNotNull(title52);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.util.Size2D size2D3 = blockContainer1.arrange(graphics2D2);
        blockContainer1.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D9 = blockContainer1.getBounds();
        boolean boolean10 = blockContainer1.isEmpty();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double13 = rectangleInsets11.calculateTopOutset((double) 0);
        java.lang.String str14 = rectangleInsets11.toString();
        blockContainer1.setPadding(rectangleInsets11);
        double double17 = rectangleInsets11.trimHeight((double) 'a');
        java.lang.String str18 = rectangleInsets11.toString();
        org.junit.Assert.assertNotNull(size2D3);
        org.junit.Assert.assertNotNull(rectangle2D9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 4.0d + "'", double13 == 4.0d);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]" + "'", str14.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 89.0d + "'", double17 == 89.0d);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]" + "'", str18.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        piePlot1.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        piePlot1.setDataset(pieDataset8);
        org.jfree.data.general.PieDataset pieDataset10 = piePlot1.getDataset();
        java.lang.String str11 = piePlot1.getNoDataMessage();
        piePlot1.setLabelLinkMargin((double) 0.5f);
        java.awt.Paint paint14 = piePlot1.getNoDataMessagePaint();
        double double15 = piePlot1.getLabelGap();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot16 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.util.TableOrder tableOrder17 = org.jfree.chart.util.TableOrder.BY_COLUMN;
        multiplePiePlot16.setDataExtractOrder(tableOrder17);
        multiplePiePlot16.setAggregatedItemsKey((java.lang.Comparable) (-1));
        org.jfree.data.category.CategoryDataset categoryDataset21 = multiplePiePlot16.getDataset();
        java.lang.Object obj22 = multiplePiePlot16.clone();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset23 = new org.jfree.data.category.DefaultCategoryDataset();
        multiplePiePlot16.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset23);
        double double25 = multiplePiePlot16.getLimit();
        org.jfree.data.general.PieDataset pieDataset26 = null;
        org.jfree.chart.plot.PiePlot piePlot27 = new org.jfree.chart.plot.PiePlot(pieDataset26);
        piePlot27.setForegroundAlpha(0.0f);
        piePlot27.setStartAngle((double) 100L);
        piePlot27.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset34 = null;
        piePlot27.setDataset(pieDataset34);
        piePlot27.setMaximumLabelWidth((double) (byte) 100);
        java.awt.Stroke stroke39 = piePlot27.getSectionOutlineStroke((java.lang.Comparable) (short) 0);
        org.jfree.data.general.PieDataset pieDataset40 = null;
        org.jfree.chart.plot.PiePlot piePlot41 = new org.jfree.chart.plot.PiePlot(pieDataset40);
        piePlot41.setForegroundAlpha((float) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor49 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean50 = rectangleInsets48.equals((java.lang.Object) rectangleAnchor49);
        double double52 = rectangleInsets48.calculateBottomInset((double) (-1L));
        piePlot41.setSimpleLabelOffset(rectangleInsets48);
        piePlot27.setInsets(rectangleInsets48);
        java.awt.Color color55 = java.awt.Color.BLUE;
        piePlot27.setLabelLinkPaint((java.awt.Paint) color55);
        java.awt.Font font57 = piePlot27.getLabelFont();
        java.awt.Font font58 = piePlot27.getLabelFont();
        multiplePiePlot16.setNoDataMessageFont(font58);
        piePlot1.setNoDataMessageFont(font58);
        double double61 = piePlot1.getLabelLinkMargin();
        org.junit.Assert.assertNull(pieDataset10);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.025d + "'", double15 == 0.025d);
        org.junit.Assert.assertNotNull(tableOrder17);
        org.junit.Assert.assertNull(categoryDataset21);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNull(stroke39);
        org.junit.Assert.assertNotNull(rectangleAnchor49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 100.0d + "'", double52 == 100.0d);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertNotNull(font57);
        org.junit.Assert.assertNotNull(font58);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.5d + "'", double61 == 0.5d);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        double double6 = piePlot1.getInteriorGap();
        java.awt.Stroke stroke7 = piePlot1.getBaseSectionOutlineStroke();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset8 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot9 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset8);
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot(pieDataset10);
        piePlot11.setForegroundAlpha((float) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor19 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean20 = rectangleInsets18.equals((java.lang.Object) rectangleAnchor19);
        double double22 = rectangleInsets18.calculateBottomInset((double) (-1L));
        piePlot11.setSimpleLabelOffset(rectangleInsets18);
        java.awt.Color color24 = java.awt.Color.DARK_GRAY;
        piePlot11.setBackgroundPaint((java.awt.Paint) color24);
        boolean boolean26 = defaultCategoryDataset8.hasListener((java.util.EventListener) piePlot11);
        piePlot11.zoom((double) (short) 0);
        org.jfree.data.general.DatasetGroup datasetGroup29 = piePlot11.getDatasetGroup();
        java.awt.Stroke stroke30 = piePlot11.getLabelLinkStroke();
        piePlot1.setLabelLinkStroke(stroke30);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.08d + "'", double6 == 0.08d);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(rectangleAnchor19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 100.0d + "'", double22 == 100.0d);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(datasetGroup29);
        org.junit.Assert.assertNotNull(stroke30);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Set<java.lang.String> strSet1 = jFreeChartResources0.keySet();
        org.junit.Assert.assertNotNull(strSet1);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        java.awt.Stroke stroke2 = strokeMap0.getStroke((java.lang.Comparable) 4.0d);
        org.jfree.chart.block.ColumnArrangement columnArrangement3 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer4 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.util.Size2D size2D6 = blockContainer4.arrange(graphics2D5);
        java.lang.Object obj7 = null;
        boolean boolean8 = blockContainer4.equals(obj7);
        java.lang.Class<?> wildcardClass9 = blockContainer4.getClass();
        java.awt.Paint paint14 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder15 = new org.jfree.chart.block.BlockBorder((double) 10, (double) '#', (double) 0L, 0.0d, paint14);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = blockBorder15.getInsets();
        blockContainer4.setFrame((org.jfree.chart.block.BlockFrame) blockBorder15);
        boolean boolean18 = strokeMap0.equals((java.lang.Object) blockContainer4);
        org.jfree.data.general.PieDataset pieDataset20 = null;
        org.jfree.chart.plot.PiePlot piePlot21 = new org.jfree.chart.plot.PiePlot(pieDataset20);
        piePlot21.setForegroundAlpha(0.0f);
        piePlot21.setStartAngle((double) 100L);
        piePlot21.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset28 = null;
        piePlot21.setDataset(pieDataset28);
        org.jfree.data.general.PieDataset pieDataset30 = piePlot21.getDataset();
        piePlot21.setOutlineVisible(false);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset33 = new org.jfree.data.category.DefaultCategoryDataset();
        java.util.List list34 = defaultCategoryDataset33.getColumnKeys();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent35 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) piePlot21, (org.jfree.data.general.Dataset) defaultCategoryDataset33);
        java.awt.Stroke stroke36 = piePlot21.getLabelOutlineStroke();
        strokeMap0.put((java.lang.Comparable) (byte) 1, stroke36);
        java.lang.Object obj38 = strokeMap0.clone();
        try {
            java.awt.Stroke stroke40 = strokeMap0.getStroke((java.lang.Comparable) "JFreeChart version RectangleEdge.TOP.\n1.2.0-pre.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nPieSection: 0, 100(1)");
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Byte cannot be cast to java.lang.String");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNull(stroke2);
        org.junit.Assert.assertNotNull(size2D6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(pieDataset30);
        org.junit.Assert.assertNotNull(list34);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(obj38);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        piePlot1.setLabelLinkMargin(0.0d);
        boolean boolean8 = piePlot1.getIgnoreZeroValues();
        org.jfree.chart.block.BlockBorder blockBorder13 = new org.jfree.chart.block.BlockBorder(0.0d, 0.025d, (double) 100, (double) (short) 100);
        boolean boolean14 = piePlot1.equals((java.lang.Object) 0.025d);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator15 = piePlot1.getURLGenerator();
        java.awt.Paint paint16 = piePlot1.getShadowPaint();
        java.awt.Shape shape17 = null;
        try {
            piePlot1.setLegendItemShape(shape17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'shape' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(pieURLGenerator15);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) '4');
        pieLabelDistributor1.distributeLabels((double) 2, 100.0d);
        pieLabelDistributor1.sort();
        try {
            org.jfree.chart.plot.PieLabelRecord pieLabelRecord7 = pieLabelDistributor1.getPieLabelRecord(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.data.general.DatasetGroup datasetGroup0 = new org.jfree.data.general.DatasetGroup();
        java.lang.Object obj1 = datasetGroup0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity9 = new org.jfree.chart.entity.PieSectionEntity(shape2, pieDataset3, 0, (int) (byte) 100, (java.lang.Comparable) 1L, "RectangleEdge.TOP", "RectangleEdge.TOP");
        org.jfree.chart.JFreeChart jFreeChart10 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent11 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0, jFreeChart10);
        org.jfree.chart.JFreeChart jFreeChart12 = chartChangeEvent11.getChart();
        org.jfree.chart.JFreeChart jFreeChart13 = null;
        chartChangeEvent11.setChart(jFreeChart13);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot16 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.util.TableOrder tableOrder17 = org.jfree.chart.util.TableOrder.BY_COLUMN;
        multiplePiePlot16.setDataExtractOrder(tableOrder17);
        org.jfree.chart.JFreeChart jFreeChart19 = new org.jfree.chart.JFreeChart("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.chart.plot.Plot) multiplePiePlot16);
        chartChangeEvent11.setChart(jFreeChart19);
        jFreeChart19.setBackgroundImageAlpha((float) 'a');
        textTitle1.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart19);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = textTitle1.getPosition();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(jFreeChart12);
        org.junit.Assert.assertNotNull(tableOrder17);
        org.junit.Assert.assertNotNull(rectangleEdge24);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.lang.String str1 = standardPieSectionLabelGenerator0.getLabelFormat();
        java.text.NumberFormat numberFormat2 = standardPieSectionLabelGenerator0.getPercentFormat();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{0}" + "'", str1.equals("{0}"));
        org.junit.Assert.assertNotNull(numberFormat2);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setForegroundAlpha((float) 0);
        java.awt.Stroke stroke6 = piePlot3.getBaseSectionOutlineStroke();
        piePlot3.setLabelLinkMargin((double) (-256));
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("PieSection: 0, 100(1)", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = null;
        java.awt.image.BufferedImage bufferedImage16 = jFreeChart10.createBufferedImage((int) (byte) 100, 128, (double) 1L, 90.0d, chartRenderingInfo15);
        jFreeChart10.removeLegend();
        jFreeChart10.setTextAntiAlias(true);
        org.jfree.chart.LegendItemSource legendItemSource20 = null;
        org.jfree.chart.title.LegendTitle legendTitle21 = new org.jfree.chart.title.LegendTitle(legendItemSource20);
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        java.lang.String str23 = rectangleEdge22.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge22);
        legendTitle21.setLegendItemGraphicEdge(rectangleEdge22);
        org.jfree.chart.block.BlockFrame blockFrame26 = legendTitle21.getFrame();
        java.awt.Paint paint31 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder32 = new org.jfree.chart.block.BlockBorder((double) 10, (double) '#', (double) 0L, 0.0d, paint31);
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = blockBorder32.getInsets();
        double double35 = rectangleInsets33.calculateLeftOutset(0.025d);
        legendTitle21.setItemLabelPadding(rectangleInsets33);
        jFreeChart10.addLegend(legendTitle21);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot38 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Color color39 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.block.BlockBorder blockBorder40 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color39);
        multiplePiePlot38.setNoDataMessagePaint((java.awt.Paint) color39);
        org.jfree.chart.util.TableOrder tableOrder42 = org.jfree.chart.util.TableOrder.BY_ROW;
        multiplePiePlot38.setDataExtractOrder(tableOrder42);
        double double44 = multiplePiePlot38.getLimit();
        multiplePiePlot38.setLimit((double) 1);
        org.jfree.data.category.CategoryDataset categoryDataset47 = multiplePiePlot38.getDataset();
        java.awt.Paint paint48 = multiplePiePlot38.getAggregatedItemsPaint();
        legendTitle21.setBackgroundPaint(paint48);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(bufferedImage16);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "RectangleEdge.TOP" + "'", str23.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertNotNull(blockFrame26);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 35.0d + "'", double35 == 35.0d);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(tableOrder42);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset47);
        org.junit.Assert.assertNotNull(paint48);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setForegroundAlpha((float) 0);
        java.awt.Stroke stroke6 = piePlot3.getBaseSectionOutlineStroke();
        piePlot3.setLabelLinkMargin((double) (-256));
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("PieSection: 0, 100(1)", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
        org.jfree.chart.event.ChartProgressListener chartProgressListener11 = null;
        jFreeChart10.removeProgressListener(chartProgressListener11);
        java.awt.Image image13 = jFreeChart10.getBackgroundImage();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(image13);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.block.BlockBorder blockBorder2 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color1);
        multiplePiePlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.util.TableOrder tableOrder4 = org.jfree.chart.util.TableOrder.BY_ROW;
        multiplePiePlot0.setDataExtractOrder(tableOrder4);
        double double6 = multiplePiePlot0.getLimit();
        multiplePiePlot0.setLimit((double) 1);
        boolean boolean10 = multiplePiePlot0.equals((java.lang.Object) "RectangleEdge.TOP");
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(tableOrder4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("1.2.0-pre");
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        java.lang.String str5 = rectangleEdge4.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge4);
        legendTitle3.setLegendItemGraphicEdge(rectangleEdge4);
        org.jfree.chart.block.BlockFrame blockFrame8 = legendTitle3.getFrame();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = legendTitle3.getItemLabelPadding();
        java.awt.Color color12 = java.awt.Color.getColor("TableOrder.BY_ROW", (int) (byte) 1);
        org.jfree.chart.block.BlockBorder blockBorder13 = new org.jfree.chart.block.BlockBorder(rectangleInsets9, (java.awt.Paint) color12);
        textTitle1.setFrame((org.jfree.chart.block.BlockFrame) blockBorder13);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = blockBorder13.getInsets();
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "RectangleEdge.TOP" + "'", str5.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(blockFrame8);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(rectangleInsets15);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.chart.PaintMap paintMap0 = new org.jfree.chart.PaintMap();
        paintMap0.clear();
        boolean boolean3 = paintMap0.containsKey((java.lang.Comparable) 255);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.chart.PaintMap paintMap0 = new org.jfree.chart.PaintMap();
        java.awt.Paint paint2 = paintMap0.getPaint((java.lang.Comparable) (short) 10);
        boolean boolean4 = paintMap0.containsKey((java.lang.Comparable) 10.0d);
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.util.Size2D size2D3 = blockContainer1.arrange(graphics2D2);
        blockContainer1.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        org.jfree.chart.block.ColumnArrangement columnArrangement9 = new org.jfree.chart.block.ColumnArrangement();
        blockContainer1.setArrangement((org.jfree.chart.block.Arrangement) columnArrangement9);
        columnArrangement9.clear();
        columnArrangement9.clear();
        org.jfree.chart.block.Block block13 = null;
        org.jfree.chart.LegendItemSource legendItemSource14 = null;
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle(legendItemSource14);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = legendTitle15.getLegendItemGraphicPadding();
        columnArrangement9.add(block13, (java.lang.Object) legendTitle15);
        org.jfree.data.general.PieDataset pieDataset18 = null;
        org.jfree.chart.plot.PiePlot piePlot19 = new org.jfree.chart.plot.PiePlot(pieDataset18);
        piePlot19.setForegroundAlpha(0.0f);
        piePlot19.setStartAngle((double) 100L);
        piePlot19.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset26 = null;
        piePlot19.setDataset(pieDataset26);
        org.jfree.chart.event.PlotChangeListener plotChangeListener28 = null;
        piePlot19.removeChangeListener(plotChangeListener28);
        org.jfree.chart.block.FlowArrangement flowArrangement30 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.Block block31 = null;
        java.awt.Stroke stroke32 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        flowArrangement30.add(block31, (java.lang.Object) stroke32);
        piePlot19.setBaseSectionOutlineStroke(stroke32);
        piePlot19.setSimpleLabels(true);
        boolean boolean37 = columnArrangement9.equals((java.lang.Object) piePlot19);
        org.junit.Assert.assertNotNull(size2D3);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("VerticalAlignment.CENTER");
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = org.jfree.chart.util.VerticalAlignment.TOP;
        legendTitle1.setVerticalAlignment(verticalAlignment2);
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        piePlot7.setForegroundAlpha((float) 0);
        java.awt.Stroke stroke10 = piePlot7.getBaseSectionOutlineStroke();
        piePlot7.setLabelLinkMargin((double) (-256));
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("PieSection: 0, 100(1)", font5, (org.jfree.chart.plot.Plot) piePlot7, false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo19 = null;
        java.awt.image.BufferedImage bufferedImage20 = jFreeChart14.createBufferedImage((int) (byte) 100, 128, (double) 1L, 90.0d, chartRenderingInfo19);
        legendTitle1.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart14);
        org.jfree.chart.block.BlockContainer blockContainer22 = legendTitle1.getItemContainer();
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(bufferedImage20);
        org.junit.Assert.assertNotNull(blockContainer22);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Enumeration<java.lang.String> strEnumeration1 = jFreeChartResources0.getKeys();
        try {
            java.lang.Object obj3 = jFreeChartResources0.getObject("http://www.jfree.org/jfreechart/index.html");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key http://www.jfree.org/jfreechart/index.html");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNotNull(strEnumeration1);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.image.ColorModel colorModel1 = null;
        java.awt.Rectangle rectangle2 = null;
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement6 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer7 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.util.Size2D size2D9 = blockContainer7.arrange(graphics2D8);
        blockContainer7.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D15 = blockContainer7.getBounds();
        java.lang.Object obj17 = textTitle4.draw(graphics2D5, rectangle2D15, (java.lang.Object) (short) 0);
        java.awt.geom.AffineTransform affineTransform18 = null;
        java.awt.RenderingHints renderingHints19 = null;
        java.awt.PaintContext paintContext20 = color0.createContext(colorModel1, rectangle2, rectangle2D15, affineTransform18, renderingHints19);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(size2D9);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertNull(obj17);
        org.junit.Assert.assertNotNull(paintContext20);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        piePlot1.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        piePlot1.setDataset(pieDataset8);
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        piePlot1.removeChangeListener(plotChangeListener10);
        piePlot1.setExplodePercent((java.lang.Comparable) 181.0d, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = piePlot1.getLabelPadding();
        org.junit.Assert.assertNotNull(rectangleInsets15);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = legendTitle1.getLegendItemGraphicPadding();
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        legendTitle1.setBackgroundPaint((java.awt.Paint) color3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = legendTitle1.getLegendItemGraphicPadding();
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font7 = textTitle6.getFont();
        org.jfree.chart.util.VerticalAlignment verticalAlignment8 = textTitle6.getVerticalAlignment();
        boolean boolean9 = textTitle6.getNotify();
        textTitle6.setMargin((double) (-4325426), 0.0d, 0.0d, (double) (byte) 10);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        double double20 = rectangleInsets19.getBottom();
        double double22 = rectangleInsets19.calculateTopOutset((double) (-1));
        textTitle6.setPadding(rectangleInsets19);
        double double25 = rectangleInsets19.trimWidth((double) (short) 100);
        double double26 = rectangleInsets19.getRight();
        legendTitle1.setItemLabelPadding(rectangleInsets19);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(verticalAlignment8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 100.0d + "'", double20 == 100.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + (-1.0d) + "'", double22 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 89.0d + "'", double25 == 89.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0d + "'", double26 == 1.0d);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.util.TableOrder tableOrder2 = org.jfree.chart.util.TableOrder.BY_COLUMN;
        multiplePiePlot1.setDataExtractOrder(tableOrder2);
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (org.jfree.chart.plot.Plot) multiplePiePlot1);
        org.jfree.chart.title.Title title5 = null;
        jFreeChart4.removeSubtitle(title5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double9 = rectangleInsets7.calculateTopOutset((double) 0);
        java.lang.String str10 = rectangleInsets7.toString();
        double double12 = rectangleInsets7.calculateTopOutset((double) '#');
        double double14 = rectangleInsets7.trimWidth(0.0d);
        double double16 = rectangleInsets7.calculateLeftInset((double) ' ');
        jFreeChart4.setPadding(rectangleInsets7);
        org.junit.Assert.assertNotNull(tableOrder2);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 4.0d + "'", double9 == 4.0d);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]" + "'", str10.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 4.0d + "'", double12 == 4.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-16.0d) + "'", double14 == (-16.0d));
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 8.0d + "'", double16 == 8.0d);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.util.Size2D size2D3 = blockContainer1.arrange(graphics2D2);
        blockContainer1.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D9 = blockContainer1.getBounds();
        boolean boolean10 = blockContainer1.isEmpty();
        java.lang.String str11 = blockContainer1.getID();
        double double12 = blockContainer1.getHeight();
        org.junit.Assert.assertNotNull(size2D3);
        org.junit.Assert.assertNotNull(rectangle2D9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean10 = rectangleInsets8.equals((java.lang.Object) rectangleAnchor9);
        double double12 = rectangleInsets8.calculateTopInset(0.0d);
        piePlot1.setInsets(rectangleInsets8);
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        piePlot15.setForegroundAlpha((float) 0);
        boolean boolean18 = piePlot15.getIgnoreZeroValues();
        double double19 = piePlot15.getShadowXOffset();
        java.awt.Stroke stroke20 = piePlot15.getLabelLinkStroke();
        piePlot1.setBaseSectionOutlineStroke(stroke20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        piePlot1.handleClick(255, (int) (short) 0, plotRenderingInfo24);
        java.awt.Paint paint26 = piePlot1.getLabelPaint();
        piePlot1.setLabelGap(2.0d);
        double double29 = piePlot1.getMaximumExplodePercent();
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.0d) + "'", double12 == (-1.0d));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 4.0d + "'", double19 == 4.0d);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha((float) 0);
        boolean boolean4 = piePlot1.getIgnoreZeroValues();
        double double5 = piePlot1.getShadowXOffset();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot7 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.util.TableOrder tableOrder8 = org.jfree.chart.util.TableOrder.BY_COLUMN;
        multiplePiePlot7.setDataExtractOrder(tableOrder8);
        java.awt.Font font11 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        piePlot13.setForegroundAlpha((float) 0);
        java.awt.Stroke stroke16 = piePlot13.getBaseSectionOutlineStroke();
        piePlot13.setLabelLinkMargin((double) (-256));
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("PieSection: 0, 100(1)", font11, (org.jfree.chart.plot.Plot) piePlot13, false);
        multiplePiePlot7.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart20);
        boolean boolean22 = jFreeChart6.equals((java.lang.Object) jFreeChart20);
        java.awt.Paint paint23 = jFreeChart6.getBackgroundPaint();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(tableOrder8);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(paint23);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha((float) 0);
        java.awt.Stroke stroke4 = piePlot1.getBaseSectionOutlineStroke();
        piePlot1.setLabelLinkMargin((double) (-256));
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator7 = piePlot1.getToolTipGenerator();
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.Font font10 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        piePlot12.setForegroundAlpha((float) 0);
        java.awt.Stroke stroke15 = piePlot12.getBaseSectionOutlineStroke();
        piePlot12.setLabelLinkMargin((double) (-256));
        org.jfree.chart.JFreeChart jFreeChart19 = new org.jfree.chart.JFreeChart("PieSection: 0, 100(1)", font10, (org.jfree.chart.plot.Plot) piePlot12, false);
        double double20 = piePlot12.getInteriorGap();
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment22 = org.jfree.chart.util.VerticalAlignment.CENTER;
        java.awt.Shape shape23 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset24 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity30 = new org.jfree.chart.entity.PieSectionEntity(shape23, pieDataset24, 0, (int) (byte) 100, (java.lang.Comparable) 1L, "RectangleEdge.TOP", "RectangleEdge.TOP");
        pieSectionEntity30.setSectionKey((java.lang.Comparable) 0L);
        boolean boolean33 = verticalAlignment22.equals((java.lang.Object) pieSectionEntity30);
        java.awt.Shape shape34 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset35 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity41 = new org.jfree.chart.entity.PieSectionEntity(shape34, pieDataset35, 0, (int) (byte) 100, (java.lang.Comparable) 1L, "RectangleEdge.TOP", "RectangleEdge.TOP");
        pieSectionEntity41.setSectionKey((java.lang.Comparable) 0L);
        boolean boolean45 = pieSectionEntity41.equals((java.lang.Object) "hi!");
        org.jfree.chart.title.TextTitle textTitle47 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D48 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement49 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer50 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement49);
        java.awt.Graphics2D graphics2D51 = null;
        org.jfree.chart.util.Size2D size2D52 = blockContainer50.arrange(graphics2D51);
        blockContainer50.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D58 = blockContainer50.getBounds();
        java.lang.Object obj60 = textTitle47.draw(graphics2D48, rectangle2D58, (java.lang.Object) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor61 = null;
        java.awt.geom.Point2D point2D62 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D58, rectangleAnchor61);
        pieSectionEntity41.setArea((java.awt.Shape) rectangle2D58);
        pieSectionEntity30.setArea((java.awt.Shape) rectangle2D58);
        piePlot12.drawBackgroundImage(graphics2D21, rectangle2D58);
        try {
            piePlot1.drawBackground(graphics2D8, rectangle2D58);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(pieToolTipGenerator7);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.08d + "'", double20 == 0.08d);
        org.junit.Assert.assertNotNull(verticalAlignment22);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(size2D52);
        org.junit.Assert.assertNotNull(rectangle2D58);
        org.junit.Assert.assertNull(obj60);
        org.junit.Assert.assertNotNull(point2D62);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        java.awt.Color color1 = java.awt.Color.GREEN;
        float[] floatArray6 = new float[] { (byte) 1, (short) 0, (short) 100, (short) -1 };
        float[] floatArray7 = color1.getComponents(floatArray6);
        boolean boolean8 = defaultKeyedValues2D0.equals((java.lang.Object) floatArray7);
        int int9 = defaultKeyedValues2D0.getColumnCount();
        int int10 = defaultKeyedValues2D0.getColumnCount();
        defaultKeyedValues2D0.setValue((java.lang.Number) 0, (java.lang.Comparable) "hi!", (java.lang.Comparable) (byte) -1);
        int int16 = defaultKeyedValues2D0.getColumnIndex((java.lang.Comparable) 0.08d);
        int int18 = defaultKeyedValues2D0.getColumnIndex((java.lang.Comparable) "JFreeChart version RectangleEdge.TOP.\nMultiple Pie Plot.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nTableOrder.BY_ROW");
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) '4');
        try {
            org.jfree.chart.plot.PieLabelRecord pieLabelRecord3 = pieLabelDistributor1.getPieLabelRecord(91);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 91, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        double double5 = rectangleInsets4.getBottom();
        double double7 = rectangleInsets4.calculateRightOutset(0.0d);
        double double9 = rectangleInsets4.extendHeight(79.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 178.0d + "'", double9 == 178.0d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setForegroundAlpha((float) 0);
        java.awt.Stroke stroke6 = piePlot3.getBaseSectionOutlineStroke();
        piePlot3.setLabelLinkMargin((double) (-256));
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("PieSection: 0, 100(1)", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
        jFreeChart10.setBorderVisible(false);
        jFreeChart10.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle("");
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        textTitle16.setBackgroundPaint((java.awt.Paint) color17);
        textTitle16.setURLText("Rotation.ANTICLOCKWISE");
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement22 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer23 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement22);
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.util.Size2D size2D25 = blockContainer23.arrange(graphics2D24);
        blockContainer23.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D31 = blockContainer23.getBounds();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor32 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.awt.geom.Point2D point2D33 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D31, rectangleAnchor32);
        org.jfree.data.general.PieDataset pieDataset34 = null;
        org.jfree.chart.plot.PiePlot piePlot35 = new org.jfree.chart.plot.PiePlot(pieDataset34);
        piePlot35.setForegroundAlpha(0.0f);
        piePlot35.setLabelLinkMargin(4.0d);
        java.awt.Paint paint40 = piePlot35.getShadowPaint();
        java.lang.Object obj41 = textTitle16.draw(graphics2D21, rectangle2D31, (java.lang.Object) piePlot35);
        boolean boolean42 = jFreeChart10.equals((java.lang.Object) graphics2D21);
        org.jfree.chart.title.TextTitle textTitle43 = jFreeChart10.getTitle();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(size2D25);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertNotNull(rectangleAnchor32);
        org.junit.Assert.assertNotNull(point2D33);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNull(obj41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(textTitle43);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement3 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer4 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.util.Size2D size2D6 = blockContainer4.arrange(graphics2D5);
        blockContainer4.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D12 = blockContainer4.getBounds();
        java.lang.Object obj14 = textTitle1.draw(graphics2D2, rectangle2D12, (java.lang.Object) (short) 0);
        java.awt.Graphics2D graphics2D15 = null;
        try {
            org.jfree.chart.util.Size2D size2D16 = textTitle1.arrange(graphics2D15);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(size2D6);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertNull(obj14);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        float float6 = piePlot1.getBackgroundAlpha();
        piePlot1.setShadowYOffset((double) 100.0f);
        java.awt.Color color9 = java.awt.Color.magenta;
        piePlot1.setBaseSectionOutlinePaint((java.awt.Paint) color9);
        int int11 = color9.getBlue();
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 255 + "'", int11 == 255);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font1 = textTitle0.getFont();
        textTitle0.setID("1.2.0-pre");
        java.lang.Object obj4 = textTitle0.clone();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = textTitle0.getHorizontalAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment6 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.FlowArrangement flowArrangement9 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment5, verticalAlignment6, (double) 15, 0.5d);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(horizontalAlignment5);
        org.junit.Assert.assertNotNull(verticalAlignment6);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        piePlot1.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        piePlot1.setDataset(pieDataset8);
        piePlot1.setMaximumLabelWidth((double) (byte) 100);
        java.awt.Stroke stroke13 = piePlot1.getSectionOutlineStroke((java.lang.Comparable) (short) 0);
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        piePlot15.setForegroundAlpha((float) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor23 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean24 = rectangleInsets22.equals((java.lang.Object) rectangleAnchor23);
        double double26 = rectangleInsets22.calculateBottomInset((double) (-1L));
        piePlot15.setSimpleLabelOffset(rectangleInsets22);
        piePlot1.setInsets(rectangleInsets22);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = piePlot1.getSimpleLabelOffset();
        int int30 = piePlot1.getBackgroundImageAlignment();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent31 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) int30);
        org.junit.Assert.assertNull(stroke13);
        org.junit.Assert.assertNotNull(rectangleAnchor23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 100.0d + "'", double26 == 100.0d);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 15 + "'", int30 == 15);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font1 = textTitle0.getFont();
        textTitle0.setID("1.2.0-pre");
        java.lang.Object obj4 = textTitle0.clone();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent5 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle0);
        org.jfree.chart.title.Title title6 = titleChangeEvent5.getTitle();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(title6);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder(89.0d, 108.0d, 0.0d, (double) (byte) 1, (java.awt.Paint) color4);
        java.awt.Color color6 = color4.darker();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color6);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        java.lang.String str3 = rectangleEdge2.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge2);
        legendTitle1.setLegendItemGraphicEdge(rectangleEdge2);
        org.jfree.chart.block.BlockFrame blockFrame6 = legendTitle1.getFrame();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = legendTitle1.getItemLabelPadding();
        double double9 = rectangleInsets7.calculateRightInset(0.0d);
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot(pieDataset10);
        piePlot11.setForegroundAlpha((float) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor19 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean20 = rectangleInsets18.equals((java.lang.Object) rectangleAnchor19);
        double double22 = rectangleInsets18.calculateBottomInset((double) (-1L));
        piePlot11.setSimpleLabelOffset(rectangleInsets18);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle24 = org.jfree.chart.plot.PieLabelLinkStyle.CUBIC_CURVE;
        piePlot11.setLabelLinkStyle(pieLabelLinkStyle24);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier26 = piePlot11.getDrawingSupplier();
        java.lang.Class<?> wildcardClass27 = drawingSupplier26.getClass();
        boolean boolean28 = rectangleInsets7.equals((java.lang.Object) drawingSupplier26);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleEdge.TOP" + "'", str3.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(blockFrame6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 100.0d + "'", double22 == 100.0d);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle24);
        org.junit.Assert.assertNotNull(drawingSupplier26);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha((float) 0);
        java.awt.Stroke stroke4 = piePlot1.getBaseSectionOutlineStroke();
        piePlot1.setLabelLinkMargin((double) (-256));
        piePlot1.setSectionOutlinesVisible(false);
        org.jfree.data.general.DatasetGroup datasetGroup9 = piePlot1.getDatasetGroup();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = piePlot1.getInsets();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        double double16 = rectangleInsets15.getBottom();
        double double18 = rectangleInsets15.calculateTopOutset((double) (-1));
        piePlot1.setInsets(rectangleInsets15);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(datasetGroup9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 100.0d + "'", double16 == 100.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + (-1.0d) + "'", double18 == (-1.0d));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha((float) 0);
        boolean boolean4 = piePlot1.getIgnoreZeroValues();
        double double5 = piePlot1.getShadowXOffset();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo9 = null;
        java.awt.image.BufferedImage bufferedImage10 = jFreeChart6.createBufferedImage((int) 'a', (int) (byte) 100, chartRenderingInfo9);
        java.awt.Paint paint11 = jFreeChart6.getBackgroundPaint();
        int int12 = jFreeChart6.getSubtitleCount();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = null;
        try {
            jFreeChart6.handleClick(91, 2, chartRenderingInfo15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(bufferedImage10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        piePlot1.setForegroundAlpha((float) (short) 100);
        double double8 = piePlot1.getShadowYOffset();
        java.awt.Stroke stroke9 = piePlot1.getBaseSectionOutlineStroke();
        boolean boolean10 = piePlot1.getIgnoreNullValues();
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.0d + "'", double8 == 4.0d);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        piePlot4.setForegroundAlpha((float) 0);
        boolean boolean7 = piePlot4.getIgnoreZeroValues();
        double double8 = piePlot4.getShadowXOffset();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot4);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo12 = null;
        java.awt.image.BufferedImage bufferedImage13 = jFreeChart9.createBufferedImage((int) 'a', (int) (byte) 100, chartRenderingInfo12);
        org.jfree.chart.ui.ProjectInfo projectInfo17 = new org.jfree.chart.ui.ProjectInfo("HorizontalAlignment.LEFT", "HorizontalAlignment.CENTER", "PieSection: 0, 100(true)", (java.awt.Image) bufferedImage13, "JFreeChart version RectangleEdge.TOP.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nTableOrder.BY_ROW", "", "");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.0d + "'", double8 == 4.0d);
        org.junit.Assert.assertNotNull(bufferedImage13);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        piePlot1.setShadowPaint((java.awt.Paint) color4);
        piePlot1.setIgnoreZeroValues(true);
        java.awt.Paint paint9 = null;
        piePlot1.setSectionOutlinePaint((java.lang.Comparable) 100.0f, paint9);
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor12 = new org.jfree.chart.plot.PieLabelDistributor((int) '4');
        pieLabelDistributor12.distributeLabels((double) 2, 100.0d);
        piePlot1.setLabelDistributor((org.jfree.chart.plot.AbstractPieLabelDistributor) pieLabelDistributor12);
        java.awt.Shape shape17 = piePlot1.getLegendItemShape();
        double double18 = piePlot1.getMaximumLabelWidth();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.14d + "'", double18 == 0.14d);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        java.lang.String str1 = basicProjectInfo0.getName();
        java.lang.String str2 = basicProjectInfo0.getVersion();
        java.lang.String str3 = basicProjectInfo0.getLicenceName();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        piePlot1.setForegroundAlpha((float) (short) 100);
        double double8 = piePlot1.getShadowYOffset();
        java.awt.Stroke stroke10 = piePlot1.getSectionOutlineStroke((java.lang.Comparable) (-16.0d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.0d + "'", double8 == 4.0d);
        org.junit.Assert.assertNull(stroke10);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("UnitType.ABSOLUTE");
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement6 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer7 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.util.Size2D size2D9 = blockContainer7.arrange(graphics2D8);
        blockContainer7.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D15 = blockContainer7.getBounds();
        java.lang.Object obj17 = textTitle4.draw(graphics2D5, rectangle2D15, (java.lang.Object) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor18 = null;
        java.awt.geom.Point2D point2D19 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D15, rectangleAnchor18);
        textTitle2.setBounds(rectangle2D15);
        textTitle2.setToolTipText("HorizontalAlignment.CENTER");
        boolean boolean23 = standardPieSectionLabelGenerator1.equals((java.lang.Object) "HorizontalAlignment.CENTER");
        org.junit.Assert.assertNotNull(size2D9);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertNull(obj17);
        org.junit.Assert.assertNotNull(point2D19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font1 = textTitle0.getFont();
        textTitle0.setID("1.2.0-pre");
        java.lang.String str4 = textTitle0.getURLText();
        textTitle0.setExpandToFitSpace(false);
        java.awt.Font font8 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        piePlot10.setForegroundAlpha((float) 0);
        java.awt.Stroke stroke13 = piePlot10.getBaseSectionOutlineStroke();
        piePlot10.setLabelLinkMargin((double) (-256));
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("PieSection: 0, 100(1)", font8, (org.jfree.chart.plot.Plot) piePlot10, false);
        jFreeChart17.setBorderVisible(false);
        boolean boolean20 = jFreeChart17.isBorderVisible();
        org.jfree.chart.event.ChartProgressListener chartProgressListener21 = null;
        jFreeChart17.addProgressListener(chartProgressListener21);
        textTitle0.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart17);
        java.awt.geom.Rectangle2D rectangle2D24 = textTitle0.getBounds();
        org.jfree.chart.entity.ChartEntity chartEntity26 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D24, "JFreeChart version RectangleEdge.TOP.\n1.2.0-pre.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nPieSection: 0, 100(1)");
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(rectangle2D24);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setForegroundAlpha((float) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean12 = rectangleInsets10.equals((java.lang.Object) rectangleAnchor11);
        double double14 = rectangleInsets10.calculateBottomInset((double) (-1L));
        piePlot3.setSimpleLabelOffset(rectangleInsets10);
        java.awt.Color color16 = java.awt.Color.DARK_GRAY;
        piePlot3.setBackgroundPaint((java.awt.Paint) color16);
        boolean boolean18 = defaultCategoryDataset0.hasListener((java.util.EventListener) piePlot3);
        java.awt.Paint paint19 = piePlot3.getBaseSectionOutlinePaint();
        java.lang.String str20 = piePlot3.getPlotType();
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 100.0d + "'", double14 == 100.0d);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Pie Plot" + "'", str20.equals("Pie Plot"));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        piePlot1.setShadowPaint((java.awt.Paint) color4);
        piePlot1.setIgnoreZeroValues(true);
        java.awt.Paint paint9 = null;
        piePlot1.setSectionOutlinePaint((java.lang.Comparable) 100.0f, paint9);
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor12 = new org.jfree.chart.plot.PieLabelDistributor((int) '4');
        pieLabelDistributor12.distributeLabels((double) 2, 100.0d);
        piePlot1.setLabelDistributor((org.jfree.chart.plot.AbstractPieLabelDistributor) pieLabelDistributor12);
        pieLabelDistributor12.distributeLabels((double) 91, 0.0d);
        pieLabelDistributor12.distributeLabels((double) 0, (double) 1L);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.ANTICLOCKWISE;
        double double1 = rotation0.getFactor();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        java.lang.String str3 = rectangleEdge2.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge2);
        boolean boolean5 = rotation0.equals((java.lang.Object) rectangleEdge2);
        org.junit.Assert.assertNotNull(rotation0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleEdge.TOP" + "'", str3.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        try {
            defaultKeyedValues2D0.removeRow((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor(3, 91, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Blue");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.util.Size2D size2D3 = blockContainer1.arrange(graphics2D2);
        java.lang.Object obj4 = null;
        boolean boolean5 = blockContainer1.equals(obj4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = null;
        try {
            org.jfree.chart.util.Size2D size2D8 = blockContainer1.arrange(graphics2D6, rectangleConstraint7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(size2D3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("");
        java.lang.Throwable[] throwableArray2 = unknownKeyException1.getSuppressed();
        java.lang.Throwable[] throwableArray3 = unknownKeyException1.getSuppressed();
        org.jfree.data.UnknownKeyException unknownKeyException5 = new org.jfree.data.UnknownKeyException("");
        java.lang.Throwable[] throwableArray6 = unknownKeyException5.getSuppressed();
        java.lang.Throwable[] throwableArray7 = unknownKeyException5.getSuppressed();
        unknownKeyException1.addSuppressed((java.lang.Throwable) unknownKeyException5);
        org.jfree.data.UnknownKeyException unknownKeyException10 = new org.jfree.data.UnknownKeyException("");
        java.lang.Throwable[] throwableArray11 = unknownKeyException10.getSuppressed();
        java.lang.Throwable[] throwableArray12 = unknownKeyException10.getSuppressed();
        unknownKeyException1.addSuppressed((java.lang.Throwable) unknownKeyException10);
        org.jfree.data.UnknownKeyException unknownKeyException15 = new org.jfree.data.UnknownKeyException("");
        java.lang.Throwable[] throwableArray16 = unknownKeyException15.getSuppressed();
        java.lang.Throwable[] throwableArray17 = unknownKeyException15.getSuppressed();
        unknownKeyException10.addSuppressed((java.lang.Throwable) unknownKeyException15);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertNotNull(throwableArray17);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.block.BlockBorder blockBorder2 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color1);
        multiplePiePlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.util.TableOrder tableOrder4 = org.jfree.chart.util.TableOrder.BY_ROW;
        multiplePiePlot0.setDataExtractOrder(tableOrder4);
        double double6 = multiplePiePlot0.getLimit();
        multiplePiePlot0.setLimit((double) 1);
        java.lang.String str9 = multiplePiePlot0.getPlotType();
        multiplePiePlot0.setAggregatedItemsKey((java.lang.Comparable) 1L);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(tableOrder4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Multiple Pie Plot" + "'", str9.equals("Multiple Pie Plot"));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        java.awt.Color color1 = java.awt.Color.GREEN;
        float[] floatArray6 = new float[] { (byte) 1, (short) 0, (short) 100, (short) -1 };
        float[] floatArray7 = color1.getComponents(floatArray6);
        boolean boolean8 = defaultKeyedValues2D0.equals((java.lang.Object) floatArray7);
        defaultKeyedValues2D0.clear();
        java.awt.Paint paint10 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        boolean boolean11 = defaultKeyedValues2D0.equals((java.lang.Object) paint10);
        try {
            defaultKeyedValues2D0.removeRow((java.lang.Comparable) 35.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        java.awt.Paint paint1 = blockBorder0.getPaint();
        org.junit.Assert.assertNotNull(blockBorder0);
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("Other", font1);
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font1 = textTitle0.getFont();
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = textTitle0.getVerticalAlignment();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle0);
        java.lang.Object obj4 = titleChangeEvent3.getSource();
        java.awt.Font font6 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot(pieDataset7);
        piePlot8.setForegroundAlpha((float) 0);
        java.awt.Stroke stroke11 = piePlot8.getBaseSectionOutlineStroke();
        piePlot8.setLabelLinkMargin((double) (-256));
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("PieSection: 0, 100(1)", font6, (org.jfree.chart.plot.Plot) piePlot8, false);
        jFreeChart15.setBorderVisible(false);
        boolean boolean18 = jFreeChart15.isBorderVisible();
        titleChangeEvent3.setChart(jFreeChart15);
        org.jfree.chart.title.TextTitle textTitle20 = jFreeChart15.getTitle();
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font22 = textTitle21.getFont();
        org.jfree.chart.util.VerticalAlignment verticalAlignment23 = textTitle21.getVerticalAlignment();
        java.awt.Paint paint24 = textTitle21.getPaint();
        try {
            jFreeChart15.setTextAntiAlias((java.lang.Object) textTitle21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: org.jfree.chart.title.TextTitle@e469b5e1 incompatible with Text-specific antialiasing enable key");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(textTitle20);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(verticalAlignment23);
        org.junit.Assert.assertNotNull(paint24);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        piePlot1.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        piePlot1.setDataset(pieDataset8);
        org.jfree.chart.plot.Plot plot10 = piePlot1.getParent();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset11 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) piePlot1, (org.jfree.data.general.Dataset) defaultCategoryDataset11);
        java.lang.Object obj13 = defaultCategoryDataset11.clone();
        int int14 = defaultCategoryDataset11.getColumnCount();
        int int16 = defaultCategoryDataset11.getRowIndex((java.lang.Comparable) "HorizontalAlignment.LEFT");
        try {
            java.lang.Comparable comparable18 = defaultCategoryDataset11.getColumnKey((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(plot10);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha((float) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean10 = rectangleInsets8.equals((java.lang.Object) rectangleAnchor9);
        double double12 = rectangleInsets8.calculateBottomInset((double) (-1L));
        piePlot1.setSimpleLabelOffset(rectangleInsets8);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        piePlot1.setLabelLinkStroke(stroke14);
        piePlot1.setCircular(true, true);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 100.0d + "'", double12 == 100.0d);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setForegroundAlpha((float) 0);
        java.awt.Stroke stroke6 = piePlot3.getBaseSectionOutlineStroke();
        piePlot3.setLabelLinkMargin((double) (-256));
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("PieSection: 0, 100(1)", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
        jFreeChart10.setBorderVisible(false);
        boolean boolean13 = jFreeChart10.isBorderVisible();
        jFreeChart10.setBackgroundImageAlpha(0.0f);
        org.jfree.data.general.PieDataset pieDataset16 = null;
        org.jfree.chart.plot.PiePlot piePlot17 = new org.jfree.chart.plot.PiePlot(pieDataset16);
        piePlot17.setForegroundAlpha(0.0f);
        piePlot17.setStartAngle((double) 100L);
        piePlot17.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset24 = null;
        piePlot17.setDataset(pieDataset24);
        org.jfree.data.general.PieDataset pieDataset26 = piePlot17.getDataset();
        java.lang.String str27 = piePlot17.getNoDataMessage();
        piePlot17.setLabelLinkMargin((double) 0.5f);
        java.awt.Paint paint30 = piePlot17.getNoDataMessagePaint();
        java.awt.Color color31 = java.awt.Color.BLACK;
        piePlot17.setBaseSectionOutlinePaint((java.awt.Paint) color31);
        java.awt.Color color33 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.color.ColorSpace colorSpace34 = color33.getColorSpace();
        java.awt.Color color35 = java.awt.Color.GREEN;
        float[] floatArray40 = new float[] { (byte) 1, (short) 0, (short) 100, (short) -1 };
        float[] floatArray41 = color35.getComponents(floatArray40);
        float[] floatArray42 = color31.getComponents(colorSpace34, floatArray41);
        java.awt.color.ColorSpace colorSpace43 = color31.getColorSpace();
        boolean boolean44 = jFreeChart10.equals((java.lang.Object) color31);
        java.awt.Paint paint45 = jFreeChart10.getBorderPaint();
        org.jfree.chart.title.TextTitle textTitle46 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font47 = textTitle46.getFont();
        org.jfree.chart.util.VerticalAlignment verticalAlignment48 = textTitle46.getVerticalAlignment();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent49 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle46);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType50 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        titleChangeEvent49.setType(chartChangeEventType50);
        org.jfree.chart.title.Title title52 = titleChangeEvent49.getTitle();
        jFreeChart10.titleChanged(titleChangeEvent49);
        java.lang.Object obj54 = titleChangeEvent49.getSource();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(pieDataset26);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(colorSpace34);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(floatArray40);
        org.junit.Assert.assertNotNull(floatArray41);
        org.junit.Assert.assertNotNull(floatArray42);
        org.junit.Assert.assertNotNull(colorSpace43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertNotNull(font47);
        org.junit.Assert.assertNotNull(verticalAlignment48);
        org.junit.Assert.assertNotNull(chartChangeEventType50);
        org.junit.Assert.assertNotNull(title52);
        org.junit.Assert.assertNotNull(obj54);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        java.awt.Color color3 = java.awt.Color.green;
        java.awt.Color color4 = color3.darker();
        java.awt.Color color5 = java.awt.Color.PINK;
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D6 = new org.jfree.data.DefaultKeyedValues2D();
        java.awt.Color color7 = java.awt.Color.GREEN;
        float[] floatArray12 = new float[] { (byte) 1, (short) 0, (short) 100, (short) -1 };
        float[] floatArray13 = color7.getComponents(floatArray12);
        boolean boolean14 = defaultKeyedValues2D6.equals((java.lang.Object) floatArray13);
        float[] floatArray15 = color5.getColorComponents(floatArray13);
        float[] floatArray16 = color3.getRGBColorComponents(floatArray15);
        float[] floatArray17 = java.awt.Color.RGBtoHSB(0, (int) (short) 100, (int) (byte) 10, floatArray15);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        textTitle1.setBackgroundPaint((java.awt.Paint) color2);
        java.awt.Font font4 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        textTitle1.setFont(font4);
        double double6 = textTitle1.getContentYOffset();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        java.lang.String str3 = rectangleEdge2.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge2);
        legendTitle1.setLegendItemGraphicEdge(rectangleEdge2);
        org.jfree.chart.block.BlockFrame blockFrame6 = legendTitle1.getFrame();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = legendTitle1.getItemLabelPadding();
        java.awt.Color color10 = java.awt.Color.getColor("TableOrder.BY_ROW", (int) (byte) 1);
        org.jfree.chart.block.BlockBorder blockBorder11 = new org.jfree.chart.block.BlockBorder(rectangleInsets7, (java.awt.Paint) color10);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = blockBorder11.getInsets();
        org.jfree.chart.util.UnitType unitType13 = rectangleInsets12.getUnitType();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = new org.jfree.chart.util.RectangleInsets(unitType13, 0.14d, 108.0d, (double) (-7904), (double) (-1L));
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleEdge.TOP" + "'", str3.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(blockFrame6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(unitType13);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.LegendItemSource[] legendItemSourceArray3 = legendTitle1.getSources();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(legendItemSourceArray3);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font1 = textTitle0.getFont();
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = textTitle0.getVerticalAlignment();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle0);
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity11 = new org.jfree.chart.entity.PieSectionEntity(shape4, pieDataset5, 0, (int) (byte) 100, (java.lang.Comparable) 1L, "RectangleEdge.TOP", "RectangleEdge.TOP");
        org.jfree.data.UnknownKeyException unknownKeyException13 = new org.jfree.data.UnknownKeyException("");
        boolean boolean14 = pieSectionEntity11.equals((java.lang.Object) "");
        java.lang.String str15 = pieSectionEntity11.toString();
        boolean boolean16 = textTitle0.equals((java.lang.Object) pieSectionEntity11);
        double double17 = textTitle0.getHeight();
        org.jfree.data.general.PieDataset pieDataset18 = null;
        org.jfree.chart.plot.PiePlot piePlot19 = new org.jfree.chart.plot.PiePlot(pieDataset18);
        piePlot19.setForegroundAlpha(0.0f);
        piePlot19.setStartAngle((double) 100L);
        piePlot19.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset26 = null;
        piePlot19.setDataset(pieDataset26);
        org.jfree.data.general.PieDataset pieDataset28 = piePlot19.getDataset();
        java.lang.String str29 = piePlot19.getNoDataMessage();
        piePlot19.setLabelLinkMargin((double) 0.5f);
        java.awt.Paint paint32 = piePlot19.getNoDataMessagePaint();
        java.awt.Color color33 = java.awt.Color.BLACK;
        piePlot19.setBaseSectionOutlinePaint((java.awt.Paint) color33);
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = piePlot19.getInsets();
        textTitle0.setPadding(rectangleInsets35);
        java.awt.Shape shape37 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset38 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity44 = new org.jfree.chart.entity.PieSectionEntity(shape37, pieDataset38, 0, (int) (byte) 100, (java.lang.Comparable) 1L, "RectangleEdge.TOP", "RectangleEdge.TOP");
        org.jfree.data.UnknownKeyException unknownKeyException46 = new org.jfree.data.UnknownKeyException("");
        boolean boolean47 = pieSectionEntity44.equals((java.lang.Object) "");
        java.lang.String str48 = pieSectionEntity44.toString();
        pieSectionEntity44.setToolTipText("JFreeChart version RectangleEdge.TOP.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nTableOrder.BY_ROW");
        pieSectionEntity44.setPieIndex((-1));
        int int53 = pieSectionEntity44.getPieIndex();
        boolean boolean54 = textTitle0.equals((java.lang.Object) pieSectionEntity44);
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator55 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator56 = null;
        try {
            java.lang.String str57 = pieSectionEntity44.getImageMapAreaTag(toolTipTagFragmentGenerator55, uRLTagFragmentGenerator56);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PieSection: 0, 100(1)" + "'", str15.equals("PieSection: 0, 100(1)"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNull(pieDataset28);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertNotNull(shape37);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "PieSection: 0, 100(1)" + "'", str48.equals("PieSection: 0, 100(1)"));
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-1) + "'", int53 == (-1));
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        piePlot1.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        piePlot1.setDataset(pieDataset8);
        org.jfree.chart.plot.Plot plot10 = piePlot1.getParent();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset11 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) piePlot1, (org.jfree.data.general.Dataset) defaultCategoryDataset11);
        java.lang.Object obj13 = defaultCategoryDataset11.clone();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot14 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset11);
        defaultCategoryDataset11.setValue((double) (short) 10, (java.lang.Comparable) 255, (java.lang.Comparable) (short) 1);
        org.junit.Assert.assertNull(plot10);
        org.junit.Assert.assertNotNull(obj13);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setForegroundAlpha((float) 0);
        java.awt.Stroke stroke6 = piePlot3.getBaseSectionOutlineStroke();
        piePlot3.setLabelLinkMargin((double) (-256));
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("PieSection: 0, 100(1)", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = null;
        java.awt.image.BufferedImage bufferedImage16 = jFreeChart10.createBufferedImage((int) (byte) 100, 128, (double) 1L, 90.0d, chartRenderingInfo15);
        jFreeChart10.removeLegend();
        jFreeChart10.setTextAntiAlias(true);
        org.jfree.chart.LegendItemSource legendItemSource20 = null;
        org.jfree.chart.title.LegendTitle legendTitle21 = new org.jfree.chart.title.LegendTitle(legendItemSource20);
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        java.lang.String str23 = rectangleEdge22.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge22);
        legendTitle21.setLegendItemGraphicEdge(rectangleEdge22);
        org.jfree.chart.block.BlockFrame blockFrame26 = legendTitle21.getFrame();
        java.awt.Paint paint31 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder32 = new org.jfree.chart.block.BlockBorder((double) 10, (double) '#', (double) 0L, 0.0d, paint31);
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = blockBorder32.getInsets();
        double double35 = rectangleInsets33.calculateLeftOutset(0.025d);
        legendTitle21.setItemLabelPadding(rectangleInsets33);
        jFreeChart10.addLegend(legendTitle21);
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = legendTitle21.getItemLabelPadding();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(bufferedImage16);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "RectangleEdge.TOP" + "'", str23.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertNotNull(blockFrame26);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 35.0d + "'", double35 == 35.0d);
        org.junit.Assert.assertNotNull(rectangleInsets38);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.Color color1 = color0.darker();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset2 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset2);
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        piePlot5.setForegroundAlpha((float) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean14 = rectangleInsets12.equals((java.lang.Object) rectangleAnchor13);
        double double16 = rectangleInsets12.calculateBottomInset((double) (-1L));
        piePlot5.setSimpleLabelOffset(rectangleInsets12);
        java.awt.Color color18 = java.awt.Color.DARK_GRAY;
        piePlot5.setBackgroundPaint((java.awt.Paint) color18);
        boolean boolean20 = defaultCategoryDataset2.hasListener((java.util.EventListener) piePlot5);
        piePlot5.zoom((double) (short) 0);
        org.jfree.data.general.DatasetGroup datasetGroup23 = piePlot5.getDatasetGroup();
        java.awt.Stroke stroke24 = piePlot5.getLabelLinkStroke();
        org.jfree.chart.block.ColumnArrangement columnArrangement25 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer26 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement25);
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.chart.util.Size2D size2D28 = blockContainer26.arrange(graphics2D27);
        blockContainer26.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D34 = blockContainer26.getBounds();
        boolean boolean35 = blockContainer26.isEmpty();
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double38 = rectangleInsets36.calculateTopOutset((double) 0);
        java.lang.String str39 = rectangleInsets36.toString();
        blockContainer26.setPadding(rectangleInsets36);
        double double42 = rectangleInsets36.calculateLeftInset((double) 15);
        org.jfree.chart.block.LineBorder lineBorder43 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color1, stroke24, rectangleInsets36);
        java.awt.Stroke stroke44 = lineBorder43.getStroke();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(rectangleAnchor13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 100.0d + "'", double16 == 100.0d);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(datasetGroup23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(size2D28);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 4.0d + "'", double38 == 4.0d);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]" + "'", str39.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 8.0d + "'", double42 == 8.0d);
        org.junit.Assert.assertNotNull(stroke44);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj1 = null;
        int int2 = objectList0.indexOf(obj1);
        java.awt.Color color5 = java.awt.Color.getColor("PieSection: 0, 100(1)", (int) (short) -1);
        int int6 = objectList0.indexOf((java.lang.Object) color5);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        java.lang.Object obj2 = textTitle1.clone();
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("");
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        textTitle4.setBackgroundPaint((java.awt.Paint) color5);
        java.awt.Font font7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        textTitle4.setFont(font7);
        textTitle1.setFont(font7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.chart.block.BlockBorder blockBorder11 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color10);
        textTitle1.setFrame((org.jfree.chart.block.BlockFrame) blockBorder11);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font1 = textTitle0.getFont();
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = textTitle0.getVerticalAlignment();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle0);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType4 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        titleChangeEvent3.setType(chartChangeEventType4);
        org.jfree.chart.title.Title title6 = titleChangeEvent3.getTitle();
        java.lang.Object obj7 = titleChangeEvent3.getSource();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertNotNull(chartChangeEventType4);
        org.junit.Assert.assertNotNull(title6);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        textTitle1.setBackgroundPaint((java.awt.Paint) color2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        java.awt.Color color5 = color4.brighter();
        textTitle1.setPaint((java.awt.Paint) color5);
        textTitle1.setURLText("JFreeChart version RectangleEdge.TOP.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nTableOrder.BY_ROW");
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setForegroundAlpha(0.0f);
        piePlot3.setStartAngle((double) 100L);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        piePlot3.setLabelOutlineStroke(stroke8);
        piePlot3.setMaximumLabelWidth((-1.0d));
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        piePlot13.setForegroundAlpha(0.0f);
        piePlot13.setStartAngle((double) 100L);
        java.awt.Stroke stroke18 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        piePlot13.setLabelOutlineStroke(stroke18);
        java.awt.Stroke stroke20 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        piePlot13.setBaseSectionOutlineStroke(stroke20);
        piePlot3.setLabelOutlineStroke(stroke20);
        flowArrangement0.add((org.jfree.chart.block.Block) textTitle1, (java.lang.Object) piePlot3);
        java.awt.Paint paint25 = piePlot3.getSectionPaint((java.lang.Comparable) (short) 1);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNull(paint25);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.util.Size2D size2D3 = blockContainer1.arrange(graphics2D2);
        java.lang.Object obj4 = null;
        boolean boolean5 = blockContainer1.equals(obj4);
        boolean boolean6 = blockContainer1.isEmpty();
        blockContainer1.setID("RectangleEdge.TOP");
        org.junit.Assert.assertNotNull(size2D3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        org.jfree.data.UnknownKeyException unknownKeyException2 = new org.jfree.data.UnknownKeyException("");
        java.lang.Throwable[] throwableArray3 = unknownKeyException2.getSuppressed();
        java.lang.Throwable[] throwableArray4 = unknownKeyException2.getSuppressed();
        org.jfree.data.UnknownKeyException unknownKeyException6 = new org.jfree.data.UnknownKeyException("");
        java.lang.Throwable[] throwableArray7 = unknownKeyException6.getSuppressed();
        java.lang.Throwable[] throwableArray8 = unknownKeyException6.getSuppressed();
        unknownKeyException2.addSuppressed((java.lang.Throwable) unknownKeyException6);
        org.jfree.data.UnknownKeyException unknownKeyException11 = new org.jfree.data.UnknownKeyException("");
        java.lang.Throwable[] throwableArray12 = unknownKeyException11.getSuppressed();
        java.lang.Throwable[] throwableArray13 = unknownKeyException11.getSuppressed();
        unknownKeyException2.addSuppressed((java.lang.Throwable) unknownKeyException11);
        java.lang.Throwable[] throwableArray15 = unknownKeyException11.getSuppressed();
        boolean boolean16 = defaultDrawingSupplier0.equals((java.lang.Object) throwableArray15);
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        java.awt.Shape shape6 = piePlot1.getLegendItemShape();
        piePlot1.setStartAngle((-256.0d));
        double double9 = piePlot1.getStartAngle();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-256.0d) + "'", double9 == (-256.0d));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) '4');
        pieLabelDistributor1.clear();
        org.jfree.chart.plot.PieLabelRecord pieLabelRecord3 = null;
        try {
            pieLabelDistributor1.addPieLabelRecord(pieLabelRecord3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'record' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement3 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer4 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.util.Size2D size2D6 = blockContainer4.arrange(graphics2D5);
        blockContainer4.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D12 = blockContainer4.getBounds();
        java.lang.Object obj14 = textTitle1.draw(graphics2D2, rectangle2D12, (java.lang.Object) (short) 0);
        java.awt.Paint paint15 = textTitle1.getBackgroundPaint();
        textTitle1.setURLText("JFreeChart version RectangleEdge.TOP.\n1.2.0-pre.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nPieSection: 0, 100(1)");
        org.jfree.data.general.PieDataset pieDataset18 = null;
        org.jfree.chart.plot.PiePlot piePlot19 = new org.jfree.chart.plot.PiePlot(pieDataset18);
        piePlot19.setForegroundAlpha((float) 0);
        boolean boolean22 = piePlot19.getIgnoreZeroValues();
        double double23 = piePlot19.getShadowXOffset();
        org.jfree.chart.JFreeChart jFreeChart24 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot19);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot25 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.util.TableOrder tableOrder26 = org.jfree.chart.util.TableOrder.BY_COLUMN;
        multiplePiePlot25.setDataExtractOrder(tableOrder26);
        java.awt.Font font29 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset30 = null;
        org.jfree.chart.plot.PiePlot piePlot31 = new org.jfree.chart.plot.PiePlot(pieDataset30);
        piePlot31.setForegroundAlpha((float) 0);
        java.awt.Stroke stroke34 = piePlot31.getBaseSectionOutlineStroke();
        piePlot31.setLabelLinkMargin((double) (-256));
        org.jfree.chart.JFreeChart jFreeChart38 = new org.jfree.chart.JFreeChart("PieSection: 0, 100(1)", font29, (org.jfree.chart.plot.Plot) piePlot31, false);
        multiplePiePlot25.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart38);
        boolean boolean40 = jFreeChart24.equals((java.lang.Object) jFreeChart38);
        jFreeChart38.setAntiAlias(false);
        textTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart38);
        org.junit.Assert.assertNotNull(size2D6);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertNull(obj14);
        org.junit.Assert.assertNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 4.0d + "'", double23 == 4.0d);
        org.junit.Assert.assertNotNull(tableOrder26);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        piePlot1.setShadowPaint((java.awt.Paint) color4);
        piePlot1.setIgnoreZeroValues(true);
        java.awt.Paint paint9 = null;
        piePlot1.setSectionOutlinePaint((java.lang.Comparable) 100.0f, paint9);
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor12 = new org.jfree.chart.plot.PieLabelDistributor((int) '4');
        pieLabelDistributor12.distributeLabels((double) 2, 100.0d);
        piePlot1.setLabelDistributor((org.jfree.chart.plot.AbstractPieLabelDistributor) pieLabelDistributor12);
        double double17 = piePlot1.getLabelLinkMargin();
        java.awt.Paint paint19 = piePlot1.getSectionOutlinePaint((java.lang.Comparable) 0.0d);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.025d + "'", double17 == 0.025d);
        org.junit.Assert.assertNull(paint19);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha((float) 0);
        boolean boolean4 = piePlot1.getIgnoreZeroValues();
        boolean boolean5 = piePlot1.getIgnoreNullValues();
        java.awt.Font font7 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        piePlot9.setForegroundAlpha((float) 0);
        java.awt.Stroke stroke12 = piePlot9.getBaseSectionOutlineStroke();
        piePlot9.setLabelLinkMargin((double) (-256));
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart("PieSection: 0, 100(1)", font7, (org.jfree.chart.plot.Plot) piePlot9, false);
        org.jfree.chart.event.ChartProgressListener chartProgressListener17 = null;
        jFreeChart16.removeProgressListener(chartProgressListener17);
        piePlot1.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart16);
        jFreeChart16.setBackgroundImageAlpha((float) 15);
        org.jfree.data.general.PieDataset pieDataset22 = null;
        org.jfree.chart.plot.PiePlot piePlot23 = new org.jfree.chart.plot.PiePlot(pieDataset22);
        piePlot23.setForegroundAlpha(0.0f);
        piePlot23.setStartAngle((double) 100L);
        double double28 = piePlot23.getInteriorGap();
        piePlot23.setMinimumArcAngleToDraw(0.4d);
        org.jfree.chart.plot.Plot plot31 = piePlot23.getRootPlot();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo32 = new org.jfree.chart.ui.BasicProjectInfo();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo33 = new org.jfree.chart.ui.BasicProjectInfo();
        java.lang.String str34 = basicProjectInfo33.getCopyright();
        basicProjectInfo32.addLibrary((org.jfree.chart.ui.Library) basicProjectInfo33);
        basicProjectInfo33.setName("RectangleEdge.TOP");
        java.awt.Color color38 = java.awt.Color.gray;
        boolean boolean39 = basicProjectInfo33.equals((java.lang.Object) color38);
        int int40 = color38.getBlue();
        piePlot23.setLabelPaint((java.awt.Paint) color38);
        jFreeChart16.setBorderPaint((java.awt.Paint) color38);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.08d + "'", double28 == 0.08d);
        org.junit.Assert.assertNotNull(plot31);
        org.junit.Assert.assertNull(str34);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 128 + "'", int40 == 128);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        java.lang.String str3 = rectangleEdge2.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge2);
        legendTitle1.setLegendItemGraphicEdge(rectangleEdge2);
        org.jfree.chart.block.BlockFrame blockFrame6 = legendTitle1.getFrame();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = legendTitle1.getItemLabelPadding();
        java.awt.Font font9 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot(pieDataset10);
        piePlot11.setForegroundAlpha((float) 0);
        java.awt.Stroke stroke14 = piePlot11.getBaseSectionOutlineStroke();
        piePlot11.setLabelLinkMargin((double) (-256));
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("PieSection: 0, 100(1)", font9, (org.jfree.chart.plot.Plot) piePlot11, false);
        jFreeChart18.setBorderVisible(false);
        legendTitle1.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart18);
        org.jfree.chart.event.ChartChangeListener chartChangeListener22 = null;
        try {
            jFreeChart18.addChangeListener(chartChangeListener22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleEdge.TOP" + "'", str3.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(blockFrame6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setForegroundAlpha((float) 0);
        java.awt.Stroke stroke6 = piePlot3.getBaseSectionOutlineStroke();
        piePlot3.setLabelLinkMargin((double) (-256));
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("PieSection: 0, 100(1)", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
        java.awt.Image image11 = jFreeChart10.getBackgroundImage();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        piePlot13.setForegroundAlpha(0.0f);
        piePlot13.setStartAngle((double) 100L);
        piePlot13.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset20 = null;
        piePlot13.setDataset(pieDataset20);
        piePlot13.setMaximumLabelWidth((double) (byte) 100);
        java.awt.Stroke stroke25 = piePlot13.getSectionOutlineStroke((java.lang.Comparable) (short) 0);
        org.jfree.data.general.PieDataset pieDataset26 = null;
        org.jfree.chart.plot.PiePlot piePlot27 = new org.jfree.chart.plot.PiePlot(pieDataset26);
        piePlot27.setForegroundAlpha((float) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor35 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean36 = rectangleInsets34.equals((java.lang.Object) rectangleAnchor35);
        double double38 = rectangleInsets34.calculateBottomInset((double) (-1L));
        piePlot27.setSimpleLabelOffset(rectangleInsets34);
        piePlot13.setInsets(rectangleInsets34);
        jFreeChart10.setPadding(rectangleInsets34);
        org.jfree.data.general.PieDataset pieDataset42 = null;
        org.jfree.chart.plot.PiePlot piePlot43 = new org.jfree.chart.plot.PiePlot(pieDataset42);
        piePlot43.setForegroundAlpha(0.0f);
        piePlot43.zoom((double) '#');
        org.jfree.data.general.PieDataset pieDataset48 = null;
        org.jfree.chart.plot.PiePlot piePlot49 = new org.jfree.chart.plot.PiePlot(pieDataset48);
        piePlot49.setForegroundAlpha((float) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets56 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor57 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean58 = rectangleInsets56.equals((java.lang.Object) rectangleAnchor57);
        double double60 = rectangleInsets56.calculateBottomInset((double) (-1L));
        piePlot49.setSimpleLabelOffset(rectangleInsets56);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle62 = org.jfree.chart.plot.PieLabelLinkStyle.CUBIC_CURVE;
        piePlot49.setLabelLinkStyle(pieLabelLinkStyle62);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier64 = piePlot49.getDrawingSupplier();
        boolean boolean65 = piePlot43.equals((java.lang.Object) piePlot49);
        org.jfree.chart.LegendItemSource legendItemSource66 = null;
        org.jfree.chart.title.LegendTitle legendTitle67 = new org.jfree.chart.title.LegendTitle(legendItemSource66);
        org.jfree.chart.util.RectangleInsets rectangleInsets68 = legendTitle67.getLegendItemGraphicPadding();
        piePlot49.setSimpleLabelOffset(rectangleInsets68);
        double double71 = rectangleInsets68.calculateBottomInset((double) 100.0f);
        org.jfree.chart.block.ColumnArrangement columnArrangement72 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer73 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement72);
        java.awt.Graphics2D graphics2D74 = null;
        org.jfree.chart.util.Size2D size2D75 = blockContainer73.arrange(graphics2D74);
        blockContainer73.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D81 = blockContainer73.getBounds();
        java.awt.geom.Rectangle2D rectangle2D84 = rectangleInsets68.createInsetRectangle(rectangle2D81, true, false);
        java.awt.geom.Rectangle2D rectangle2D85 = rectangleInsets34.createOutsetRectangle(rectangle2D81);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(image11);
        org.junit.Assert.assertNull(stroke25);
        org.junit.Assert.assertNotNull(rectangleAnchor35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 100.0d + "'", double38 == 100.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 100.0d + "'", double60 == 100.0d);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle62);
        org.junit.Assert.assertNotNull(drawingSupplier64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(rectangleInsets68);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 2.0d + "'", double71 == 2.0d);
        org.junit.Assert.assertNotNull(size2D75);
        org.junit.Assert.assertNotNull(rectangle2D81);
        org.junit.Assert.assertNotNull(rectangle2D84);
        org.junit.Assert.assertNotNull(rectangle2D85);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.util.TableOrder tableOrder1 = org.jfree.chart.util.TableOrder.BY_COLUMN;
        multiplePiePlot0.setDataExtractOrder(tableOrder1);
        multiplePiePlot0.setAggregatedItemsKey((java.lang.Comparable) (-1));
        org.jfree.data.category.CategoryDataset categoryDataset5 = multiplePiePlot0.getDataset();
        java.lang.Object obj6 = multiplePiePlot0.clone();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset7 = new org.jfree.data.category.DefaultCategoryDataset();
        multiplePiePlot0.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset7);
        double double9 = multiplePiePlot0.getLimit();
        java.lang.String str10 = multiplePiePlot0.getPlotType();
        org.jfree.chart.util.TableOrder tableOrder11 = null;
        try {
            multiplePiePlot0.setDataExtractOrder(tableOrder11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(tableOrder1);
        org.junit.Assert.assertNull(categoryDataset5);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Multiple Pie Plot" + "'", str10.equals("Multiple Pie Plot"));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Enumeration<java.lang.String> strEnumeration1 = jFreeChartResources0.getKeys();
        java.lang.Object[][] objArray2 = jFreeChartResources0.getContents();
        org.junit.Assert.assertNotNull(strEnumeration1);
        org.junit.Assert.assertNotNull(objArray2);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        piePlot1.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        piePlot1.setDataset(pieDataset8);
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        piePlot1.removeChangeListener(plotChangeListener10);
        piePlot1.setExplodePercent((java.lang.Comparable) 181.0d, (double) 15);
        org.jfree.data.general.PieDataset pieDataset16 = null;
        org.jfree.chart.plot.PiePlot piePlot17 = new org.jfree.chart.plot.PiePlot(pieDataset16);
        piePlot17.setForegroundAlpha(0.0f);
        piePlot17.setLabelLinkMargin(4.0d);
        java.awt.Paint paint22 = piePlot17.getShadowPaint();
        piePlot1.setSectionPaint((java.lang.Comparable) 255, paint22);
        org.jfree.data.general.PieDataset pieDataset24 = null;
        org.jfree.chart.plot.PiePlot piePlot25 = new org.jfree.chart.plot.PiePlot(pieDataset24);
        piePlot25.setForegroundAlpha((float) 0);
        boolean boolean28 = piePlot25.getIgnoreZeroValues();
        double double29 = piePlot25.getShadowXOffset();
        org.jfree.chart.JFreeChart jFreeChart30 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot25);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot31 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.util.TableOrder tableOrder32 = org.jfree.chart.util.TableOrder.BY_COLUMN;
        multiplePiePlot31.setDataExtractOrder(tableOrder32);
        java.awt.Font font35 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset36 = null;
        org.jfree.chart.plot.PiePlot piePlot37 = new org.jfree.chart.plot.PiePlot(pieDataset36);
        piePlot37.setForegroundAlpha((float) 0);
        java.awt.Stroke stroke40 = piePlot37.getBaseSectionOutlineStroke();
        piePlot37.setLabelLinkMargin((double) (-256));
        org.jfree.chart.JFreeChart jFreeChart44 = new org.jfree.chart.JFreeChart("PieSection: 0, 100(1)", font35, (org.jfree.chart.plot.Plot) piePlot37, false);
        multiplePiePlot31.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart44);
        boolean boolean46 = jFreeChart30.equals((java.lang.Object) jFreeChart44);
        piePlot1.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart30);
        try {
            piePlot1.setInteriorGap((double) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid 'percent' (97.0) argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 4.0d + "'", double29 == 4.0d);
        org.junit.Assert.assertNotNull(tableOrder32);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha((float) 0);
        boolean boolean4 = piePlot1.getIgnoreZeroValues();
        boolean boolean5 = piePlot1.getIgnoreNullValues();
        java.awt.Font font7 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        piePlot9.setForegroundAlpha((float) 0);
        java.awt.Stroke stroke12 = piePlot9.getBaseSectionOutlineStroke();
        piePlot9.setLabelLinkMargin((double) (-256));
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart("PieSection: 0, 100(1)", font7, (org.jfree.chart.plot.Plot) piePlot9, false);
        org.jfree.chart.event.ChartProgressListener chartProgressListener17 = null;
        jFreeChart16.removeProgressListener(chartProgressListener17);
        piePlot1.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart16);
        java.awt.Image image20 = jFreeChart16.getBackgroundImage();
        java.lang.Object obj21 = jFreeChart16.clone();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNull(image20);
        org.junit.Assert.assertNotNull(obj21);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setForegroundAlpha((float) 0);
        java.awt.Stroke stroke6 = piePlot3.getBaseSectionOutlineStroke();
        piePlot3.setLabelLinkMargin((double) (-256));
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("PieSection: 0, 100(1)", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
        jFreeChart10.setBorderVisible(false);
        boolean boolean13 = jFreeChart10.isBorderVisible();
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        piePlot15.setForegroundAlpha(0.0f);
        piePlot15.setStartAngle((double) 100L);
        piePlot15.setForegroundAlpha((float) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement22 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.Block block23 = null;
        java.awt.Stroke stroke24 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        flowArrangement22.add(block23, (java.lang.Object) stroke24);
        piePlot15.setOutlineStroke(stroke24);
        jFreeChart10.setBorderStroke(stroke24);
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement29 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer30 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement29);
        java.awt.Graphics2D graphics2D31 = null;
        org.jfree.chart.util.Size2D size2D32 = blockContainer30.arrange(graphics2D31);
        java.lang.Object obj33 = null;
        boolean boolean34 = blockContainer30.equals(obj33);
        java.lang.Class<?> wildcardClass35 = blockContainer30.getClass();
        java.awt.geom.Rectangle2D rectangle2D36 = blockContainer30.getBounds();
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor42 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean43 = rectangleInsets41.equals((java.lang.Object) rectangleAnchor42);
        org.jfree.chart.block.ColumnArrangement columnArrangement44 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer45 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement44);
        java.awt.Graphics2D graphics2D46 = null;
        org.jfree.chart.util.Size2D size2D47 = blockContainer45.arrange(graphics2D46);
        blockContainer45.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D53 = blockContainer45.getBounds();
        java.awt.geom.Rectangle2D rectangle2D56 = rectangleInsets41.createInsetRectangle(rectangle2D53, true, false);
        org.jfree.data.general.PieDataset pieDataset57 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity63 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D56, pieDataset57, 15, 0, (java.lang.Comparable) 1, "hi!", "RectangleEdge.TOP");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor64 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.geom.Point2D point2D65 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D56, rectangleAnchor64);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo66 = null;
        try {
            jFreeChart10.draw(graphics2D28, rectangle2D36, point2D65, chartRenderingInfo66);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(size2D32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertNotNull(rectangle2D36);
        org.junit.Assert.assertNotNull(rectangleAnchor42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(size2D47);
        org.junit.Assert.assertNotNull(rectangle2D53);
        org.junit.Assert.assertNotNull(rectangle2D56);
        org.junit.Assert.assertNotNull(rectangleAnchor64);
        org.junit.Assert.assertNotNull(point2D65);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        piePlot1.setShadowPaint((java.awt.Paint) color4);
        piePlot1.setIgnoreZeroValues(true);
        java.awt.Paint paint9 = null;
        piePlot1.setSectionOutlinePaint((java.lang.Comparable) 100.0f, paint9);
        org.jfree.data.general.PieDataset pieDataset11 = piePlot1.getDataset();
        piePlot1.setBackgroundAlpha((float) 192);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        org.jfree.chart.plot.Plot plot15 = jFreeChart14.getPlot();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(pieDataset11);
        org.junit.Assert.assertNotNull(plot15);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha((float) 0);
        java.awt.Stroke stroke4 = piePlot1.getBaseSectionOutlineStroke();
        piePlot1.setLabelLinkMargin((double) (-256));
        piePlot1.setSectionOutlinesVisible(false);
        org.jfree.data.general.DatasetGroup datasetGroup9 = piePlot1.getDatasetGroup();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = piePlot1.getLegendItems();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(datasetGroup9);
        org.junit.Assert.assertNotNull(legendItemCollection10);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) (byte) 10, (double) 100, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean6 = rectangleInsets4.equals((java.lang.Object) rectangleAnchor5);
        double double8 = rectangleInsets4.calculateTopInset(0.0d);
        org.jfree.chart.block.ColumnArrangement columnArrangement9 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer10 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement9);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.util.Size2D size2D12 = blockContainer10.arrange(graphics2D11);
        blockContainer10.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D18 = blockContainer10.getBounds();
        java.awt.geom.Rectangle2D rectangle2D19 = rectangleInsets4.createInsetRectangle(rectangle2D18);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
        org.junit.Assert.assertNotNull(size2D12);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertNotNull(rectangle2D19);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = org.jfree.chart.util.VerticalAlignment.TOP;
        legendTitle1.setVerticalAlignment(verticalAlignment2);
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        piePlot7.setForegroundAlpha((float) 0);
        java.awt.Stroke stroke10 = piePlot7.getBaseSectionOutlineStroke();
        piePlot7.setLabelLinkMargin((double) (-256));
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("PieSection: 0, 100(1)", font5, (org.jfree.chart.plot.Plot) piePlot7, false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo19 = null;
        java.awt.image.BufferedImage bufferedImage20 = jFreeChart14.createBufferedImage((int) (byte) 100, 128, (double) 1L, 90.0d, chartRenderingInfo19);
        legendTitle1.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart14);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray22 = legendTitle1.getSources();
        java.awt.Graphics2D graphics2D23 = null;
        try {
            org.jfree.chart.util.Size2D size2D24 = legendTitle1.arrange(graphics2D23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(bufferedImage20);
        org.junit.Assert.assertNotNull(legendItemSourceArray22);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        piePlot1.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        piePlot1.setDataset(pieDataset8);
        org.jfree.data.general.PieDataset pieDataset10 = piePlot1.getDataset();
        piePlot1.setOutlineVisible(false);
        java.awt.Stroke stroke13 = piePlot1.getLabelOutlineStroke();
        org.jfree.chart.title.TextTitle textTitle15 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement17 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer18 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement17);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.util.Size2D size2D20 = blockContainer18.arrange(graphics2D19);
        blockContainer18.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D26 = blockContainer18.getBounds();
        java.lang.Object obj28 = textTitle15.draw(graphics2D16, rectangle2D26, (java.lang.Object) (short) 0);
        textTitle15.setPadding(0.0d, (double) (short) 1, (double) (short) 0, (double) (-256));
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = textTitle15.getPadding();
        piePlot1.setInsets(rectangleInsets34);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle36 = piePlot1.getLabelLinkStyle();
        org.junit.Assert.assertNull(pieDataset10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(size2D20);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertNull(obj28);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle36);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setForegroundAlpha((float) 0);
        java.awt.Stroke stroke6 = piePlot3.getBaseSectionOutlineStroke();
        piePlot3.setLabelLinkMargin((double) (-256));
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("PieSection: 0, 100(1)", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
        jFreeChart10.setBorderVisible(false);
        boolean boolean13 = jFreeChart10.isBorderVisible();
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        piePlot15.setForegroundAlpha(0.0f);
        piePlot15.setStartAngle((double) 100L);
        piePlot15.setForegroundAlpha((float) (short) 100);
        org.jfree.chart.block.FlowArrangement flowArrangement22 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.Block block23 = null;
        java.awt.Stroke stroke24 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        flowArrangement22.add(block23, (java.lang.Object) stroke24);
        piePlot15.setOutlineStroke(stroke24);
        jFreeChart10.setBorderStroke(stroke24);
        java.awt.Graphics2D graphics2D28 = null;
        java.awt.Font font30 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset31 = null;
        org.jfree.chart.plot.PiePlot piePlot32 = new org.jfree.chart.plot.PiePlot(pieDataset31);
        piePlot32.setForegroundAlpha((float) 0);
        java.awt.Stroke stroke35 = piePlot32.getBaseSectionOutlineStroke();
        piePlot32.setLabelLinkMargin((double) (-256));
        org.jfree.chart.JFreeChart jFreeChart39 = new org.jfree.chart.JFreeChart("PieSection: 0, 100(1)", font30, (org.jfree.chart.plot.Plot) piePlot32, false);
        double double40 = piePlot32.getInteriorGap();
        java.awt.Graphics2D graphics2D41 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment42 = org.jfree.chart.util.VerticalAlignment.CENTER;
        java.awt.Shape shape43 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset44 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity50 = new org.jfree.chart.entity.PieSectionEntity(shape43, pieDataset44, 0, (int) (byte) 100, (java.lang.Comparable) 1L, "RectangleEdge.TOP", "RectangleEdge.TOP");
        pieSectionEntity50.setSectionKey((java.lang.Comparable) 0L);
        boolean boolean53 = verticalAlignment42.equals((java.lang.Object) pieSectionEntity50);
        java.awt.Shape shape54 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset55 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity61 = new org.jfree.chart.entity.PieSectionEntity(shape54, pieDataset55, 0, (int) (byte) 100, (java.lang.Comparable) 1L, "RectangleEdge.TOP", "RectangleEdge.TOP");
        pieSectionEntity61.setSectionKey((java.lang.Comparable) 0L);
        boolean boolean65 = pieSectionEntity61.equals((java.lang.Object) "hi!");
        org.jfree.chart.title.TextTitle textTitle67 = new org.jfree.chart.title.TextTitle("");
        java.awt.Graphics2D graphics2D68 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement69 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer70 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement69);
        java.awt.Graphics2D graphics2D71 = null;
        org.jfree.chart.util.Size2D size2D72 = blockContainer70.arrange(graphics2D71);
        blockContainer70.setMargin(0.0d, (double) (short) 1, (double) 2, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D78 = blockContainer70.getBounds();
        java.lang.Object obj80 = textTitle67.draw(graphics2D68, rectangle2D78, (java.lang.Object) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor81 = null;
        java.awt.geom.Point2D point2D82 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D78, rectangleAnchor81);
        pieSectionEntity61.setArea((java.awt.Shape) rectangle2D78);
        pieSectionEntity50.setArea((java.awt.Shape) rectangle2D78);
        piePlot32.drawBackgroundImage(graphics2D41, rectangle2D78);
        java.awt.geom.Rectangle2D rectangle2D86 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor87 = null;
        java.awt.geom.Point2D point2D88 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D86, rectangleAnchor87);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo89 = null;
        try {
            jFreeChart10.draw(graphics2D28, rectangle2D78, point2D88, chartRenderingInfo89);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.08d + "'", double40 == 0.08d);
        org.junit.Assert.assertNotNull(verticalAlignment42);
        org.junit.Assert.assertNotNull(shape43);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(shape54);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(size2D72);
        org.junit.Assert.assertNotNull(rectangle2D78);
        org.junit.Assert.assertNull(obj80);
        org.junit.Assert.assertNotNull(point2D82);
        org.junit.Assert.assertNotNull(point2D88);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        java.lang.String str3 = rectangleEdge2.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge2);
        legendTitle1.setLegendItemGraphicEdge(rectangleEdge2);
        org.jfree.chart.block.BlockFrame blockFrame6 = legendTitle1.getFrame();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = legendTitle1.getItemLabelPadding();
        java.awt.Font font9 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot(pieDataset10);
        piePlot11.setForegroundAlpha((float) 0);
        java.awt.Stroke stroke14 = piePlot11.getBaseSectionOutlineStroke();
        piePlot11.setLabelLinkMargin((double) (-256));
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("PieSection: 0, 100(1)", font9, (org.jfree.chart.plot.Plot) piePlot11, false);
        jFreeChart18.setBorderVisible(false);
        legendTitle1.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart18);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent22 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleEdge.TOP" + "'", str3.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(blockFrame6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("Other");
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        boolean boolean3 = datasetGroup1.equals((java.lang.Object) verticalAlignment2);
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setStartAngle((double) 100L);
        piePlot1.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        piePlot1.setDataset(pieDataset8);
        org.jfree.data.general.PieDataset pieDataset10 = piePlot1.getDataset();
        piePlot1.setOutlineVisible(false);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset13 = new org.jfree.data.category.DefaultCategoryDataset();
        java.util.List list14 = defaultCategoryDataset13.getColumnKeys();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent15 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) piePlot1, (org.jfree.data.general.Dataset) defaultCategoryDataset13);
        defaultCategoryDataset13.addValue((java.lang.Number) 100L, (java.lang.Comparable) 0.0f, (java.lang.Comparable) "ChartChangeEventType.DATASET_UPDATED");
        org.jfree.data.general.PieDataset pieDataset20 = null;
        org.jfree.chart.plot.PiePlot piePlot21 = new org.jfree.chart.plot.PiePlot(pieDataset20);
        piePlot21.setForegroundAlpha(0.0f);
        piePlot21.setStartAngle((double) 100L);
        piePlot21.setLabelLinkMargin(0.0d);
        org.jfree.data.general.PieDataset pieDataset28 = null;
        piePlot21.setDataset(pieDataset28);
        org.jfree.data.general.PieDataset pieDataset30 = piePlot21.getDataset();
        java.lang.String str31 = piePlot21.getNoDataMessage();
        piePlot21.setLabelLinkMargin((double) 0.5f);
        java.awt.Paint paint34 = piePlot21.getNoDataMessagePaint();
        java.awt.Color color35 = java.awt.Color.BLACK;
        piePlot21.setBaseSectionOutlinePaint((java.awt.Paint) color35);
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = piePlot21.getInsets();
        boolean boolean38 = defaultCategoryDataset13.equals((java.lang.Object) rectangleInsets37);
        org.junit.Assert.assertNull(pieDataset10);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNull(pieDataset30);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (byte) 0, 255);
    }
}

