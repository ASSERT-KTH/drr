import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_CATEGORY_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) (byte) -1, (int) (byte) -1, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Red Green");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        java.awt.Shape shape4 = null;
        java.awt.Stroke stroke5 = null;
        java.awt.Color color6 = java.awt.Color.gray;
        try {
            org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("", "hi!", "", "hi!", shape4, stroke5, (java.awt.Paint) color6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'lineStroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color6);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE6;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE1;
        java.lang.String str1 = itemLabelAnchor0.toString();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ItemLabelAnchor.OUTSIDE1" + "'", str1.equals("ItemLabelAnchor.OUTSIDE1"));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        java.awt.Font font0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        int int1 = color0.getGreen();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 128 + "'", int1 == 128);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.color.ColorSpace colorSpace1 = null;
        float[] floatArray2 = null;
        try {
            float[] floatArray3 = color0.getColorComponents(colorSpace1, floatArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        try {
            categoryPlot0.mapDatasetToRangeAxis((int) (byte) -1, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'index' >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        try {
            org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_DOMAIN_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.jfree.chart.renderer.category.BarPainter barPainter0 = null;
        try {
            org.jfree.chart.renderer.category.BarRenderer.setDefaultBarPainter(barPainter0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'painter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("ItemLabelAnchor.OUTSIDE1", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation3 = null;
        try {
            boolean boolean5 = categoryPlot0.removeAnnotation(categoryAnnotation3, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        categoryPlot0.setDomainCrosshairColumnKey((java.lang.Comparable) (short) -1, true);
        org.jfree.chart.util.Layer layer9 = null;
        java.util.Collection collection10 = categoryPlot0.getRangeMarkers((int) (short) 0, layer9);
        try {
            categoryPlot0.zoom((double) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNull(collection10);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        categoryPlot0.setDomainCrosshairColumnKey((java.lang.Comparable) (short) -1, true);
        org.jfree.chart.util.Layer layer9 = null;
        java.util.Collection collection10 = categoryPlot0.getRangeMarkers((int) (short) 0, layer9);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot11.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis14 = categoryPlot11.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        categoryPlot11.zoomDomainAxes((double) 10.0f, plotRenderingInfo16, point2D17, false);
        java.lang.Comparable comparable20 = categoryPlot11.getDomainCrosshairColumnKey();
        boolean boolean21 = categoryPlot11.isRangeCrosshairLockedOnData();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = categoryPlot11.getAxisOffset();
        double double23 = rectangleInsets22.getLeft();
        categoryPlot0.setAxisOffset(rectangleInsets22);
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D26 = rectangleInsets22.createOutsetRectangle(rectangle2D25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNull(collection10);
        org.junit.Assert.assertNull(valueAxis14);
        org.junit.Assert.assertNull(comparable20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 4.0d + "'", double23 == 4.0d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder5 = categoryPlot0.getRowRenderingOrder();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        try {
            categoryPlot0.handleClick((int) (byte) 0, (int) (short) 10, plotRenderingInfo8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(sortOrder5);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        renderAttributes0.setDefaultFillPaint((java.awt.Paint) color1);
        java.awt.Stroke stroke3 = null;
        try {
            renderAttributes0.setDefaultOutlineStroke(stroke3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("hi!", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        java.awt.Shape shape4 = null;
        java.awt.Paint paint5 = null;
        try {
            org.jfree.chart.LegendItem legendItem6 = new org.jfree.chart.LegendItem("", "hi!", "SortOrder.ASCENDING", "ItemLabelAnchor.OUTSIDE1", shape4, paint5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'fillPaint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.DEFAULT_ITEM_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE8;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE3;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        categoryPlot0.setDomainCrosshairColumnKey((java.lang.Comparable) (short) -1, true);
        org.jfree.chart.util.Layer layer9 = null;
        java.util.Collection collection10 = categoryPlot0.getRangeMarkers((int) (short) 0, layer9);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot11.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis14 = categoryPlot11.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        categoryPlot11.zoomDomainAxes((double) 10.0f, plotRenderingInfo16, point2D17, false);
        java.lang.Comparable comparable20 = categoryPlot11.getDomainCrosshairColumnKey();
        boolean boolean21 = categoryPlot11.isRangeCrosshairLockedOnData();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = categoryPlot11.getAxisOffset();
        double double23 = rectangleInsets22.getLeft();
        categoryPlot0.setAxisOffset(rectangleInsets22);
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        try {
            rectangleInsets22.trim(rectangle2D25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNull(collection10);
        org.junit.Assert.assertNull(valueAxis14);
        org.junit.Assert.assertNull(comparable20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 4.0d + "'", double23 == 4.0d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        java.lang.Comparable comparable9 = categoryPlot0.getDomainCrosshairColumnKey();
        boolean boolean10 = categoryPlot0.isRangeCrosshairLockedOnData();
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        try {
            categoryPlot0.setDataset((int) (short) -1, categoryDataset12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNull(comparable9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.chart.renderer.category.BarRenderer.setDefaultShadowsVisible(false);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        renderAttributes0.setDefaultFillPaint((java.awt.Paint) color1);
        java.awt.Shape shape5 = renderAttributes0.getItemShape((int) (byte) 100, (int) 'a');
        renderAttributes0.setDefaultCreateEntity((java.lang.Boolean) false);
        java.awt.Shape shape8 = null;
        try {
            renderAttributes0.setDefaultShape(shape8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'shape' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNull(shape5);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairLockedOnData(false);
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) (short) 10);
        categoryPlot0.setAnchorValue((double) (short) 10, false);
        boolean boolean8 = categoryPlot0.isDomainPannable();
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.ASCENDING;
        java.lang.String str1 = sortOrder0.toString();
        java.lang.String str2 = sortOrder0.toString();
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SortOrder.ASCENDING" + "'", str1.equals("SortOrder.ASCENDING"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SortOrder.ASCENDING" + "'", str2.equals("SortOrder.ASCENDING"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent9 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot0);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis13 = categoryPlot10.getRangeAxis();
        int int14 = categoryPlot10.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder15 = categoryPlot10.getRowRenderingOrder();
        java.awt.Stroke stroke16 = categoryPlot10.getRangeZeroBaselineStroke();
        categoryPlot0.setOutlineStroke(stroke16);
        org.jfree.chart.plot.Marker marker19 = null;
        org.jfree.chart.util.Layer layer20 = null;
        boolean boolean21 = categoryPlot0.removeDomainMarker(15, marker19, layer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        try {
            int int23 = categoryPlot0.getDomainAxisIndex(categoryAxis22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNull(valueAxis13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 15 + "'", int14 == 15);
        org.junit.Assert.assertNotNull(sortOrder15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        categoryPlot0.setDomainCrosshairColumnKey((java.lang.Comparable) (short) -1, true);
        org.jfree.chart.util.Layer layer9 = null;
        java.util.Collection collection10 = categoryPlot0.getRangeMarkers((int) (short) 0, layer9);
        categoryPlot0.setRangeCrosshairLockedOnData(false);
        java.lang.Comparable comparable13 = categoryPlot0.getDomainCrosshairColumnKey();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        try {
            int int15 = categoryPlot0.getRangeAxisIndex(valueAxis14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNull(collection10);
        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + (short) -1 + "'", comparable13.equals((short) -1));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairLockedOnData(false);
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) (short) 10);
        java.awt.Stroke stroke5 = null;
        try {
            categoryPlot0.setRangeZeroBaselineStroke(stroke5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        java.lang.Comparable comparable9 = categoryPlot0.getDomainCrosshairColumnKey();
        boolean boolean10 = categoryPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = categoryPlot0.getAxisOffset();
        double double12 = rectangleInsets11.getLeft();
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D14 = rectangleInsets11.createInsetRectangle(rectangle2D13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNull(comparable9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 4.0d + "'", double12 == 4.0d);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder5 = categoryPlot0.getRowRenderingOrder();
        java.awt.Stroke stroke6 = categoryPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.plot.Plot plot7 = categoryPlot0.getRootPlot();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(sortOrder5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(plot7);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Stroke stroke5 = null;
        java.awt.Color color7 = java.awt.Color.gray;
        org.jfree.chart.LegendItem legendItem8 = new org.jfree.chart.LegendItem("ItemLabelAnchor.OUTSIDE1", (java.awt.Paint) color7);
        try {
            org.jfree.chart.LegendItem legendItem9 = new org.jfree.chart.LegendItem("ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", "", "ItemLabelAnchor.OUTSIDE1", shape4, stroke5, (java.awt.Paint) color7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'lineStroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        categoryPlot0.setDomainCrosshairColumnKey((java.lang.Comparable) (short) -1, true);
        org.jfree.chart.util.Layer layer9 = null;
        java.util.Collection collection10 = categoryPlot0.getRangeMarkers((int) (short) 0, layer9);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot11.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis14 = categoryPlot11.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        categoryPlot11.zoomDomainAxes((double) 10.0f, plotRenderingInfo16, point2D17, false);
        java.lang.Comparable comparable20 = categoryPlot11.getDomainCrosshairColumnKey();
        boolean boolean21 = categoryPlot11.isRangeCrosshairLockedOnData();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = categoryPlot11.getAxisOffset();
        double double23 = rectangleInsets22.getLeft();
        categoryPlot0.setAxisOffset(rectangleInsets22);
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D28 = rectangleInsets22.createInsetRectangle(rectangle2D25, true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNull(collection10);
        org.junit.Assert.assertNull(valueAxis14);
        org.junit.Assert.assertNull(comparable20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 4.0d + "'", double23 == 4.0d);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        java.awt.Shape shape0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        try {
            org.jfree.chart.entity.CategoryItemEntity categoryItemEntity6 = new org.jfree.chart.entity.CategoryItemEntity(shape0, "SortOrder.ASCENDING", "hi!", categoryDataset3, (java.lang.Comparable) (byte) 1, (java.lang.Comparable) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE4;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE5;
        java.awt.Color color1 = java.awt.Color.white;
        boolean boolean2 = itemLabelAnchor0.equals((java.lang.Object) color1);
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor3);
        double double5 = itemLabelPosition4.getAngle();
        double double6 = itemLabelPosition4.getAngle();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor9 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis13 = categoryPlot10.getRangeAxis();
        int int14 = categoryPlot10.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder15 = categoryPlot10.getRowRenderingOrder();
        java.awt.Stroke stroke16 = categoryPlot10.getRangeZeroBaselineStroke();
        categoryPlot0.setRangeMinorGridlineStroke(stroke16);
        org.jfree.chart.axis.ValueAxis valueAxis19 = categoryPlot0.getRangeAxis(1);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation20 = null;
        try {
            boolean boolean21 = categoryPlot0.removeAnnotation(categoryAnnotation20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(categoryAnchor9);
        org.junit.Assert.assertNull(valueAxis13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 15 + "'", int14 == 15);
        org.junit.Assert.assertNotNull(sortOrder15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNull(valueAxis19);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Color color5 = java.awt.Color.WHITE;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot6.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis9 = categoryPlot6.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot6.zoomDomainAxes((double) 10.0f, plotRenderingInfo11, point2D12, false);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent15 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot6);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot16.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis19 = categoryPlot16.getRangeAxis();
        int int20 = categoryPlot16.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder21 = categoryPlot16.getRowRenderingOrder();
        java.awt.Stroke stroke22 = categoryPlot16.getRangeZeroBaselineStroke();
        categoryPlot6.setOutlineStroke(stroke22);
        java.awt.Paint paint24 = null;
        try {
            org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem(attributedString0, "", "SortOrder.ASCENDING", "ItemLabelAnchor.OUTSIDE1", shape4, (java.awt.Paint) color5, stroke22, paint24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertNull(valueAxis19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 15 + "'", int20 == 15);
        org.junit.Assert.assertNotNull(sortOrder21);
        org.junit.Assert.assertNotNull(stroke22);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        java.lang.Comparable comparable9 = categoryPlot0.getDomainCrosshairColumnKey();
        boolean boolean10 = categoryPlot0.isRangeCrosshairLockedOnData();
        categoryPlot0.setCrosshairDatasetIndex((int) (byte) 10, false);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation14 = null;
        try {
            categoryPlot0.addAnnotation(categoryAnnotation14, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNull(comparable9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot0.setRangeAxisLocation(axisLocation1, true);
        org.jfree.chart.plot.PlotOrientation plotOrientation4 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge5 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation1, plotOrientation4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation1);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        renderAttributes0.setDefaultFillPaint((java.awt.Paint) color1);
        java.awt.Shape shape5 = renderAttributes0.getItemShape((int) (byte) 100, (int) 'a');
        renderAttributes0.setDefaultCreateEntity((java.lang.Boolean) false);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot9.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis12 = categoryPlot9.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot9.zoomDomainAxes((double) 10.0f, plotRenderingInfo14, point2D15, false);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent18 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot9);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot19.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis22 = categoryPlot19.getRangeAxis();
        int int23 = categoryPlot19.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder24 = categoryPlot19.getRowRenderingOrder();
        java.awt.Stroke stroke25 = categoryPlot19.getRangeZeroBaselineStroke();
        categoryPlot9.setOutlineStroke(stroke25);
        try {
            renderAttributes0.setSeriesOutlineStroke((int) (byte) 0, stroke25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNull(shape5);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNull(valueAxis22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 15 + "'", int23 == 15);
        org.junit.Assert.assertNotNull(sortOrder24);
        org.junit.Assert.assertNotNull(stroke25);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        java.lang.Comparable comparable9 = categoryPlot0.getDomainCrosshairColumnKey();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation10 = null;
        try {
            boolean boolean11 = categoryPlot0.removeAnnotation(categoryAnnotation10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNull(comparable9);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent9 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot0);
        boolean boolean10 = categoryPlot0.isNotify();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE5;
        java.awt.Color color1 = java.awt.Color.white;
        boolean boolean2 = itemLabelAnchor0.equals((java.lang.Object) color1);
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor3);
        org.jfree.chart.text.TextAnchor textAnchor5 = itemLabelPosition4.getRotationAnchor();
        org.jfree.chart.text.TextAnchor textAnchor6 = itemLabelPosition4.getRotationAnchor();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder5 = categoryPlot0.getRowRenderingOrder();
        java.awt.Stroke stroke6 = categoryPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = categoryPlot0.getInsets();
        categoryPlot0.setRangeZeroBaselineVisible(true);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(sortOrder5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairLockedOnData(false);
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) (short) 10);
        org.jfree.chart.plot.Marker marker6 = null;
        org.jfree.chart.util.Layer layer7 = null;
        try {
            boolean boolean9 = categoryPlot0.removeRangeMarker((int) (short) 100, marker6, layer7, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        renderAttributes0.setDefaultFillPaint((java.awt.Paint) color1);
        java.awt.Shape shape5 = renderAttributes0.getItemShape((int) (byte) 100, (int) 'a');
        java.awt.Shape shape7 = null;
        renderAttributes0.setSeriesShape((int) (byte) 1, shape7);
        java.awt.Font font10 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        try {
            renderAttributes0.setSeriesLabelFont(15, font10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNull(shape5);
        org.junit.Assert.assertNotNull(font10);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge();
        int int4 = categoryPlot0.getWeight();
        java.util.List list5 = categoryPlot0.getAnnotations();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot7.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = categoryPlot7.getDomainAxisEdge();
        int int11 = categoryPlot7.getWeight();
        java.util.List list12 = categoryPlot7.getAnnotations();
        try {
            categoryPlot0.mapDatasetToRangeAxes(0, list12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Empty list not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(list12);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE11;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isRangeGridlinesVisible();
        java.awt.Stroke stroke2 = null;
        try {
            categoryPlot0.setRangeMinorGridlineStroke(stroke2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity(shape4, "ChartChangeEventType.GENERAL", "");
        java.awt.Stroke stroke8 = null;
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        try {
            org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("SortOrder.ASCENDING", "ChartChangeEventType.GENERAL", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", shape4, stroke8, (java.awt.Paint) color9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'lineStroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge();
        org.jfree.chart.axis.AxisLocation axisLocation4 = categoryPlot0.getDomainAxisLocation();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        categoryPlot0.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        categoryPlot0.setDataset(categoryDataset8);
        java.awt.Stroke stroke10 = null;
        try {
            categoryPlot0.setRangeMinorGridlineStroke(stroke10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(axisLocation4);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        java.awt.Color color3 = java.awt.Color.getHSBColor(0.0f, (float) 100, (-1.0f));
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        java.awt.Color color0 = java.awt.Color.LIGHT_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot0.zoomRangeAxes(4.0d, plotRenderingInfo6, point2D7);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor9 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis13 = categoryPlot10.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Point2D point2D16 = null;
        categoryPlot10.zoomDomainAxes((double) 10.0f, plotRenderingInfo15, point2D16, false);
        boolean boolean19 = categoryPlot10.isRangeCrosshairVisible();
        java.awt.Stroke stroke20 = categoryPlot10.getRangeCrosshairStroke();
        boolean boolean21 = categoryAnchor9.equals((java.lang.Object) categoryPlot10);
        java.awt.Graphics2D graphics2D22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        try {
            categoryPlot10.drawOutline(graphics2D22, rectangle2D23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(categoryAnchor9);
        org.junit.Assert.assertNull(valueAxis13);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE5;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        java.awt.Color color1 = java.awt.Color.getColor("ItemLabelAnchor.OUTSIDE1");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        categoryPlot0.setDomainGridlinesVisible(false);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation5 = null;
        try {
            boolean boolean6 = categoryPlot0.removeAnnotation(categoryAnnotation5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        boolean boolean2 = datasetRenderingOrder0.equals((java.lang.Object) textAnchor1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        java.lang.Double double0 = org.jfree.chart.renderer.AbstractRenderer.ZERO;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.0d + "'", double0.equals(0.0d));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("ChartChangeEventType.GENERAL", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge();
        org.jfree.chart.axis.AxisLocation axisLocation4 = categoryPlot0.getDomainAxisLocation();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        categoryPlot0.drawBackgroundImage(graphics2D5, rectangle2D6);
        categoryPlot0.setRangePannable(false);
        categoryPlot0.setDrawSharedDomainAxis(false);
        org.jfree.data.general.DatasetGroup datasetGroup12 = categoryPlot0.getDatasetGroup();
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNull(datasetGroup12);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        java.awt.Shape shape4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        int int9 = categoryPlot5.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot5.getRowRenderingOrder();
        java.awt.Stroke stroke11 = categoryPlot5.getRangeZeroBaselineStroke();
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("", "", "hi!", "", shape4, stroke11, paint12);
        legendItem13.setDescription("");
        int int16 = legendItem13.getDatasetIndex();
        legendItem13.setToolTipText("SortOrder.ASCENDING");
        legendItem13.setLineVisible(false);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE1;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        java.lang.Comparable comparable9 = categoryPlot0.getDomainCrosshairColumnKey();
        boolean boolean10 = categoryPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = categoryPlot0.getAxisOffset();
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Point2D point2D14 = null;
        org.jfree.chart.plot.PlotState plotState15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        try {
            categoryPlot0.draw(graphics2D12, rectangle2D13, point2D14, plotState15, plotRenderingInfo16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNull(comparable9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(rectangleInsets11);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        categoryPlot0.setDomainCrosshairColumnKey((java.lang.Comparable) (short) -1, true);
        org.jfree.chart.util.Layer layer9 = null;
        java.util.Collection collection10 = categoryPlot0.getRangeMarkers((int) (short) 0, layer9);
        categoryPlot0.setRangeMinorGridlinesVisible(true);
        java.lang.String str13 = categoryPlot0.getNoDataMessage();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation14 = null;
        try {
            categoryPlot0.addAnnotation(categoryAnnotation14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNull(collection10);
        org.junit.Assert.assertNull(str13);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        java.lang.Comparable comparable9 = categoryPlot0.getDomainCrosshairColumnKey();
        boolean boolean10 = categoryPlot0.isRangeCrosshairLockedOnData();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        categoryPlot0.setDomainCrosshairPaint((java.awt.Paint) color11);
        java.awt.Shape shape17 = null;
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem19 = new org.jfree.chart.LegendItem("", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", shape17, (java.awt.Paint) color18);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color18);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        categoryPlot0.panRangeAxes((double) 255, plotRenderingInfo22, point2D23);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot26.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = categoryPlot26.getDomainAxisEdge();
        int int30 = categoryPlot26.getWeight();
        java.util.List list31 = categoryPlot26.getAnnotations();
        try {
            categoryPlot0.mapDatasetToDomainAxes((int) (byte) 100, list31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Empty list not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNull(comparable9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(list31);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder5 = categoryPlot0.getRowRenderingOrder();
        java.awt.Stroke stroke6 = categoryPlot0.getRangeZeroBaselineStroke();
        categoryPlot0.setRangeGridlinesVisible(false);
        categoryPlot0.setDrawSharedDomainAxis(true);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(sortOrder5);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder5 = categoryPlot0.getRowRenderingOrder();
        java.awt.Stroke stroke6 = categoryPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        int int8 = categoryPlot0.getIndexOf(categoryItemRenderer7);
        org.jfree.chart.axis.ValueAxis valueAxis10 = categoryPlot0.getRangeAxisForDataset(255);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(sortOrder5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNull(valueAxis10);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.junit.Assert.assertNotNull(sortOrder0);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        java.awt.Color color0 = java.awt.Color.yellow;
        java.awt.color.ColorSpace colorSpace1 = color0.getColorSpace();
        int int2 = color0.getTransparency();
        float[] floatArray5 = new float[] { (byte) 1, 0.0f };
        try {
            float[] floatArray6 = color0.getColorComponents(floatArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(colorSpace1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(floatArray5);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean6 = categoryPlot5.isRangeGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = categoryPlot5.getRangeAxisEdge((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot9.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis12 = categoryPlot9.getRangeAxis();
        int int13 = categoryPlot9.getBackgroundImageAlignment();
        categoryPlot9.setDomainCrosshairColumnKey((java.lang.Comparable) (short) -1, true);
        java.awt.Stroke stroke17 = categoryPlot9.getDomainGridlineStroke();
        categoryPlot5.setRangeMinorGridlineStroke(stroke17);
        try {
            lineAndShapeRenderer2.setSeriesOutlineStroke((-1), stroke17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 15 + "'", int13 == 15);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Shape shape9 = lineAndShapeRenderer2.getItemShape((int) (short) 10, 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot11.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis14 = categoryPlot11.getRangeAxis();
        int int15 = categoryPlot11.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder16 = categoryPlot11.getRowRenderingOrder();
        java.awt.Stroke stroke17 = categoryPlot11.getRangeZeroBaselineStroke();
        try {
            lineAndShapeRenderer2.setSeriesOutlineStroke((int) (short) -1, stroke17, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNull(valueAxis14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 15 + "'", int15 == 15);
        org.junit.Assert.assertNotNull(sortOrder16);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Paint paint5 = lineAndShapeRenderer2.getSeriesPaint(15);
        double double6 = lineAndShapeRenderer2.getItemLabelAnchorOffset();
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = null;
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState12 = lineAndShapeRenderer2.initialise(graphics2D7, rectangle2D8, categoryPlot9, categoryDataset10, plotRenderingInfo11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.0d + "'", double6 == 2.0d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = lineAndShapeRenderer2.getBasePositiveItemLabelPosition();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        try {
            lineAndShapeRenderer2.setSeriesToolTipGenerator((-16728064), categoryToolTipGenerator5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition3);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.BAR_OUTLINE_WIDTH_THRESHOLD;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.0d + "'", double0 == 3.0d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder5 = categoryPlot0.getRowRenderingOrder();
        java.awt.Stroke stroke6 = categoryPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent7 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent7);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot9.setRangeAxisLocation(axisLocation10, true);
        categoryPlot0.setDomainAxisLocation(axisLocation10);
        categoryPlot0.setCrosshairDatasetIndex((int) (short) 1);
        org.jfree.data.category.CategoryDataset categoryDataset16 = categoryPlot0.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = categoryPlot0.getAxisOffset();
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        try {
            rectangleInsets17.trim(rectangle2D18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(sortOrder5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNull(categoryDataset16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_HORIZONTAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
        java.lang.String str2 = gradientPaintTransformType0.toString();
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GradientPaintTransformType.CENTER_HORIZONTAL" + "'", str2.equals("GradientPaintTransformType.CENTER_HORIZONTAL"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        java.awt.Color color0 = java.awt.Color.yellow;
        int int1 = color0.getTransparency();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE10;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis4 = categoryPlot1.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot1.zoomDomainAxes((double) 10.0f, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor10 = categoryPlot1.getDomainGridlinePosition();
        boolean boolean11 = itemLabelAnchor0.equals((java.lang.Object) categoryAnchor10);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot12.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis15 = categoryPlot12.getRangeAxis();
        int int16 = categoryPlot12.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder17 = categoryPlot12.getRowRenderingOrder();
        categoryPlot12.setWeight((int) (short) 100);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder20 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        categoryPlot12.setDatasetRenderingOrder(datasetRenderingOrder20);
        boolean boolean22 = categoryAnchor10.equals((java.lang.Object) categoryPlot12);
        boolean boolean23 = categoryPlot12.isDomainZoomable();
        org.jfree.chart.axis.AxisSpace axisSpace24 = null;
        categoryPlot12.setFixedDomainAxisSpace(axisSpace24, true);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertNotNull(categoryAnchor10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(valueAxis15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 15 + "'", int16 == 15);
        org.junit.Assert.assertNotNull(sortOrder17);
        org.junit.Assert.assertNotNull(datasetRenderingOrder20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder5 = categoryPlot0.getRowRenderingOrder();
        java.awt.Stroke stroke6 = categoryPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = categoryPlot0.getInsets();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType9 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType10 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D11 = rectangleInsets7.createAdjustedRectangle(rectangle2D8, lengthAdjustmentType9, lengthAdjustmentType10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(sortOrder5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = lineAndShapeRenderer2.getPlot();
        org.junit.Assert.assertNull(categoryPlot3);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABELS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder5 = categoryPlot0.getRowRenderingOrder();
        java.awt.Stroke stroke6 = categoryPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent7 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent7);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot9.setRangeAxisLocation(axisLocation10, true);
        categoryPlot0.setDomainAxisLocation(axisLocation10);
        categoryPlot0.setCrosshairDatasetIndex((int) (short) 1);
        org.jfree.data.category.CategoryDataset categoryDataset16 = categoryPlot0.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = categoryPlot0.getAxisOffset();
        categoryPlot0.setOutlineVisible(true);
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = null;
        try {
            categoryPlot0.addDomainMarker(categoryMarker20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(sortOrder5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNull(categoryDataset16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Shape shape11 = null;
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", shape11, (java.awt.Paint) color12);
        int int14 = color12.getBlue();
        lineAndShapeRenderer2.setSeriesItemLabelPaint((int) (byte) 1, (java.awt.Paint) color12);
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot18.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis21 = categoryPlot18.getRangeAxis();
        int int22 = categoryPlot18.getBackgroundImageAlignment();
        categoryPlot18.setDomainCrosshairColumnKey((java.lang.Comparable) (short) -1, true);
        org.jfree.chart.util.Layer layer27 = null;
        java.util.Collection collection28 = categoryPlot18.getRangeMarkers((int) (short) 0, layer27);
        categoryPlot18.setRangeMinorGridlinesVisible(true);
        java.lang.String str31 = categoryPlot18.getNoDataMessage();
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = null;
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.data.category.CategoryDataset categoryDataset34 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState38 = null;
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D40 = lineAndShapeRenderer2.createHotSpotBounds(graphics2D16, rectangle2D17, categoryPlot18, categoryAxis32, valueAxis33, categoryDataset34, (int) 'a', (int) '#', true, categoryItemRendererState38, rectangle2D39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 128 + "'", int14 == 128);
        org.junit.Assert.assertNull(valueAxis21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 15 + "'", int22 == 15);
        org.junit.Assert.assertNull(collection28);
        org.junit.Assert.assertNull(str31);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        java.awt.Shape shape4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        int int9 = categoryPlot5.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot5.getRowRenderingOrder();
        java.awt.Stroke stroke11 = categoryPlot5.getRangeZeroBaselineStroke();
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("", "", "hi!", "", shape4, stroke11, paint12);
        legendItem13.setDescription("");
        int int16 = legendItem13.getDatasetIndex();
        legendItem13.setToolTipText("SortOrder.ASCENDING");
        boolean boolean19 = legendItem13.isShapeOutlineVisible();
        boolean boolean20 = legendItem13.isShapeFilled();
        legendItem13.setSeriesIndex(100);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent9 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot0);
        org.jfree.chart.plot.Plot plot10 = plotChangeEvent9.getPlot();
        boolean boolean11 = plot10.isNotify();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(plot10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        renderAttributes0.setDefaultFillPaint((java.awt.Paint) color1);
        java.awt.Shape shape5 = renderAttributes0.getItemShape((int) (byte) 100, (int) 'a');
        java.awt.Shape shape7 = null;
        renderAttributes0.setSeriesShape((int) (byte) 1, shape7);
        java.awt.Font font9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        renderAttributes0.setDefaultLabelFont(font9);
        java.awt.Stroke stroke13 = renderAttributes0.getItemStroke((-1), (int) (short) 1);
        try {
            java.lang.Boolean boolean16 = renderAttributes0.getCreateEntity((int) (short) 0, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNull(shape5);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNull(stroke13);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.geom.Point2D point2D6 = null;
        org.jfree.chart.plot.PlotState plotState7 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        try {
            categoryPlot0.draw(graphics2D4, rectangle2D5, point2D6, plotState7, plotRenderingInfo8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        renderAttributes0.setDefaultFillPaint((java.awt.Paint) color1);
        java.awt.Shape shape5 = renderAttributes0.getItemShape((int) (byte) 100, (int) 'a');
        java.awt.Shape shape7 = null;
        renderAttributes0.setSeriesShape((int) (byte) 1, shape7);
        java.awt.Font font9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        renderAttributes0.setDefaultLabelFont(font9);
        try {
            java.awt.Stroke stroke12 = renderAttributes0.getSeriesOutlineStroke((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNull(shape5);
        org.junit.Assert.assertNotNull(font9);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot0.setRangeAxisLocation(axisLocation1, true);
        java.lang.String str4 = axisLocation1.toString();
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "AxisLocation.BOTTOM_OR_LEFT" + "'", str4.equals("AxisLocation.BOTTOM_OR_LEFT"));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Shape shape9 = lineAndShapeRenderer2.getItemShape((int) (short) 10, 100, true);
        lineAndShapeRenderer2.setBaseSeriesVisible(false);
        java.awt.Shape shape12 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity15 = new org.jfree.chart.entity.ChartEntity(shape12, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape16 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity19 = new org.jfree.chart.entity.ChartEntity(shape16, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape20 = chartEntity19.getArea();
        chartEntity15.setArea(shape20);
        lineAndShapeRenderer2.setBaseShape(shape20, true);
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot25.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis28 = categoryPlot25.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        java.awt.geom.Point2D point2D31 = null;
        categoryPlot25.zoomDomainAxes((double) 10.0f, plotRenderingInfo30, point2D31, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor34 = categoryPlot25.getDomainGridlinePosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot35.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis38 = categoryPlot35.getRangeAxis();
        int int39 = categoryPlot35.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder40 = categoryPlot35.getRowRenderingOrder();
        categoryPlot25.setRowRenderingOrder(sortOrder40);
        org.jfree.chart.axis.ValueAxis valueAxis42 = null;
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.renderer.RenderAttributes renderAttributes45 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color46 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        renderAttributes45.setDefaultFillPaint((java.awt.Paint) color46);
        java.awt.Shape shape50 = renderAttributes45.getItemShape((int) (byte) 100, (int) 'a');
        java.awt.Shape shape52 = null;
        renderAttributes45.setSeriesShape((int) (byte) 1, shape52);
        java.awt.Paint paint54 = renderAttributes45.getDefaultFillPaint();
        java.awt.Stroke stroke55 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        try {
            lineAndShapeRenderer2.drawRangeLine(graphics2D24, categoryPlot25, valueAxis42, rectangle2D43, 0.05d, paint54, stroke55);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNull(valueAxis28);
        org.junit.Assert.assertNotNull(categoryAnchor34);
        org.junit.Assert.assertNull(valueAxis38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 15 + "'", int39 == 15);
        org.junit.Assert.assertNotNull(sortOrder40);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNull(shape50);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertNotNull(stroke55);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor9 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis13 = categoryPlot10.getRangeAxis();
        int int14 = categoryPlot10.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder15 = categoryPlot10.getRowRenderingOrder();
        java.awt.Stroke stroke16 = categoryPlot10.getRangeZeroBaselineStroke();
        categoryPlot0.setRangeMinorGridlineStroke(stroke16);
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = categoryPlot0.getDomainAxis(100);
        boolean boolean20 = categoryPlot0.isNotify();
        org.jfree.chart.plot.Marker marker22 = null;
        org.jfree.chart.util.Layer layer23 = null;
        try {
            categoryPlot0.addRangeMarker(128, marker22, layer23, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(categoryAnchor9);
        org.junit.Assert.assertNull(valueAxis13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 15 + "'", int14 == 15);
        org.junit.Assert.assertNotNull(sortOrder15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNull(categoryAxis19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        java.awt.Shape shape4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        int int9 = categoryPlot5.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot5.getRowRenderingOrder();
        java.awt.Stroke stroke11 = categoryPlot5.getRangeZeroBaselineStroke();
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("", "", "hi!", "", shape4, stroke11, paint12);
        legendItem13.setSeriesKey((java.lang.Comparable) 0.0d);
        java.awt.Shape shape16 = legendItem13.getLine();
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(shape16);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder5 = categoryPlot0.getRowRenderingOrder();
        java.awt.Stroke stroke6 = categoryPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        int int8 = categoryPlot0.getIndexOf(categoryItemRenderer7);
        int int9 = categoryPlot0.getCrosshairDatasetIndex();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(sortOrder5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape0, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape4 = chartEntity3.getArea();
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape4);
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot7.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis10 = categoryPlot7.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot7.zoomDomainAxes((double) 10.0f, plotRenderingInfo12, point2D13, false);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent16 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot7);
        org.jfree.chart.JFreeChart jFreeChart17 = null;
        plotChangeEvent16.setChart(jFreeChart17);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType19 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        plotChangeEvent16.setType(chartChangeEventType19);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent21 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) chartEntity5, jFreeChart6, chartChangeEventType19);
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator22 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator23 = null;
        java.lang.String str24 = chartEntity5.getImageMapAreaTag(toolTipTagFragmentGenerator22, uRLTagFragmentGenerator23);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertNotNull(chartChangeEventType19);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        java.awt.Color color0 = java.awt.Color.BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape0, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape4 = chartEntity3.getArea();
        java.lang.Object obj5 = chartEntity3.clone();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity(shape4, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape8 = chartEntity7.getArea();
        org.jfree.chart.entity.ChartEntity chartEntity9 = new org.jfree.chart.entity.ChartEntity(shape8);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer12 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke13 = lineAndShapeRenderer12.getBaseStroke();
        java.awt.Stroke stroke15 = lineAndShapeRenderer12.lookupSeriesStroke(10);
        java.awt.Paint paint16 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        lineAndShapeRenderer12.setBaseOutlinePaint(paint16);
        org.jfree.chart.renderer.RenderAttributes renderAttributes22 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        renderAttributes22.setDefaultFillPaint((java.awt.Paint) color23);
        java.awt.Shape shape27 = renderAttributes22.getItemShape((int) (byte) 100, (int) 'a');
        java.awt.Shape shape28 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        renderAttributes22.setDefaultShape(shape28);
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot30.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis33 = categoryPlot30.getRangeAxis();
        int int34 = categoryPlot30.getBackgroundImageAlignment();
        categoryPlot30.setDomainCrosshairColumnKey((java.lang.Comparable) (short) -1, true);
        java.awt.Stroke stroke38 = categoryPlot30.getDomainGridlineStroke();
        java.awt.Color color39 = java.awt.Color.MAGENTA;
        org.jfree.chart.LegendItem legendItem40 = new org.jfree.chart.LegendItem("hi!", "AxisLocation.BOTTOM_OR_LEFT", "AxisLocation.BOTTOM_OR_LEFT", "ChartChangeEventType.GENERAL", shape28, stroke38, (java.awt.Paint) color39);
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot41.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis44 = categoryPlot41.getRangeAxis();
        java.awt.Paint paint45 = categoryPlot41.getDomainGridlinePaint();
        try {
            org.jfree.chart.LegendItem legendItem46 = new org.jfree.chart.LegendItem(attributedString0, "SortOrder.ASCENDING", "", "ItemLabelAnchor.OUTSIDE1", shape8, paint16, stroke38, paint45);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNull(shape27);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNull(valueAxis33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 15 + "'", int34 == 15);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNull(valueAxis44);
        org.junit.Assert.assertNotNull(paint45);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        java.lang.Comparable comparable9 = categoryPlot0.getDomainCrosshairColumnKey();
        boolean boolean10 = categoryPlot0.isRangeCrosshairLockedOnData();
        boolean boolean11 = categoryPlot0.isRangeZoomable();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNull(comparable9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE6;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        java.lang.String str0 = org.jfree.chart.labels.StandardCategorySeriesLabelGenerator.DEFAULT_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        java.awt.Color color0 = java.awt.Color.MAGENTA;
        java.awt.color.ColorSpace colorSpace1 = color0.getColorSpace();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(colorSpace1);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder5 = categoryPlot0.getRowRenderingOrder();
        java.awt.Stroke stroke6 = categoryPlot0.getRangeZeroBaselineStroke();
        int int7 = categoryPlot0.getCrosshairDatasetIndex();
        categoryPlot0.setCrosshairDatasetIndex((int) (short) 10);
        categoryPlot0.setCrosshairDatasetIndex((int) (short) 10, false);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(sortOrder5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape0, "ChartChangeEventType.GENERAL", "");
        chartEntity3.setToolTipText("");
        java.awt.Shape shape6 = null;
        try {
            chartEntity3.setArea(shape6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        java.lang.Comparable comparable9 = categoryPlot0.getDomainCrosshairColumnKey();
        boolean boolean10 = categoryPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = categoryPlot0.getAxisOffset();
        boolean boolean12 = categoryPlot0.isSubplot();
        categoryPlot0.mapDatasetToDomainAxis((int) '4', 1);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        try {
            int int17 = categoryPlot0.getRangeAxisIndex(valueAxis16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNull(comparable9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder5 = categoryPlot0.getRowRenderingOrder();
        java.awt.Stroke stroke6 = categoryPlot0.getRangeZeroBaselineStroke();
        categoryPlot0.setAnchorValue((double) (-1), true);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation12 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot11.setRangeAxisLocation(axisLocation12, true);
        java.util.List list15 = categoryPlot11.getAnnotations();
        try {
            categoryPlot0.mapDatasetToDomainAxes((int) (byte) 0, list15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Empty list not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(sortOrder5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(list15);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot0.setRangeAxisLocation(axisLocation1, true);
        java.util.List list4 = categoryPlot0.getAnnotations();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        categoryPlot0.setDomainAxis((int) (byte) 0, categoryAxis6, false);
        java.awt.Paint paint9 = null;
        try {
            categoryPlot0.setNoDataMessagePaint(paint9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNotNull(list4);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape0, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape4 = chartEntity3.getArea();
        java.lang.String str5 = chartEntity3.getShapeType();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "rect" + "'", str5.equals("rect"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder5 = categoryPlot0.getRowRenderingOrder();
        java.awt.Stroke stroke6 = categoryPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent7 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent7);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot9.setRangeAxisLocation(axisLocation10, true);
        categoryPlot0.setDomainAxisLocation(axisLocation10);
        categoryPlot0.setCrosshairDatasetIndex((int) (short) 1);
        java.awt.Image image16 = categoryPlot0.getBackgroundImage();
        categoryPlot0.setCrosshairDatasetIndex((int) (byte) -1, true);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(sortOrder5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNull(image16);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        java.awt.Shape shape4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        int int9 = categoryPlot5.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot5.getRowRenderingOrder();
        java.awt.Stroke stroke11 = categoryPlot5.getRangeZeroBaselineStroke();
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("", "", "hi!", "", shape4, stroke11, paint12);
        legendItem13.setSeriesKey((java.lang.Comparable) 0.0d);
        legendItem13.setSeriesKey((java.lang.Comparable) "ItemLabelAnchor.OUTSIDE1");
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Paint paint6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        lineAndShapeRenderer2.setBaseOutlinePaint(paint6);
        boolean boolean8 = lineAndShapeRenderer2.getBaseShapesFilled();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        java.awt.Color color0 = java.awt.Color.orange;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset0 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = null;
        try {
            abstractCategoryDataset0.setGroup(datasetGroup1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'group' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor9 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.plot.Marker marker10 = null;
        try {
            boolean boolean11 = categoryPlot0.removeRangeMarker(marker10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(categoryAnchor9);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Shape shape9 = lineAndShapeRenderer2.getItemShape((int) (short) 10, 100, true);
        boolean boolean13 = lineAndShapeRenderer2.getItemCreateEntity(0, (int) 'a', true);
        java.awt.Font font15 = lineAndShapeRenderer2.lookupLegendTextFont((int) (byte) 10);
        boolean boolean16 = lineAndShapeRenderer2.getDrawOutlines();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNull(font15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke7 = lineAndShapeRenderer6.getBaseStroke();
        java.awt.Stroke stroke9 = lineAndShapeRenderer6.lookupSeriesStroke(10);
        java.awt.Shape shape13 = lineAndShapeRenderer6.getItemShape((int) (short) 10, 100, true);
        java.awt.Paint paint14 = null;
        java.awt.Stroke stroke15 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color18 = java.awt.Color.getColor("rect", (int) (short) 0);
        try {
            org.jfree.chart.LegendItem legendItem19 = new org.jfree.chart.LegendItem("ChartChangeEventType.GENERAL", "SortOrder.ASCENDING", "GradientPaintTransformType.CENTER_HORIZONTAL", "", shape13, paint14, stroke15, (java.awt.Paint) color18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'fillPaint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(color18);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.data.SelectableValue selectableValue1 = new org.jfree.data.SelectableValue((java.lang.Number) 1L);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        int int1 = color0.getRed();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 64 + "'", int1 == 64);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation6 = null;
        try {
            lineAndShapeRenderer2.addAnnotation(categoryAnnotation6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Shape shape9 = lineAndShapeRenderer2.getItemShape((int) (short) 10, 100, true);
        java.awt.Paint paint11 = lineAndShapeRenderer2.getSeriesFillPaint((int) (short) 10);
        java.awt.Shape shape12 = lineAndShapeRenderer2.getBaseLegendShape();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNull(shape12);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        java.lang.Comparable comparable9 = categoryPlot0.getDomainCrosshairColumnKey();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        categoryPlot0.setDataset(categoryDataset10);
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) '4', false);
        boolean boolean15 = categoryPlot0.isRangeZeroBaselineVisible();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNull(comparable9);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder5 = categoryPlot0.getRowRenderingOrder();
        java.awt.Stroke stroke6 = categoryPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = categoryPlot0.getInsets();
        java.lang.Object obj8 = categoryPlot0.clone();
        java.awt.Paint paint9 = categoryPlot0.getRangeGridlinePaint();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(sortOrder5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge();
        int int4 = categoryPlot0.getWeight();
        java.lang.Comparable comparable5 = categoryPlot0.getDomainCrosshairColumnKey();
        boolean boolean6 = categoryPlot0.canSelectByRegion();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        try {
            int int8 = categoryPlot0.getRangeAxisIndex(valueAxis7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNull(comparable5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Paint paint5 = lineAndShapeRenderer2.getSeriesPaint(15);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = lineAndShapeRenderer2.getSeriesNegativeItemLabelPosition(255);
        int int8 = lineAndShapeRenderer2.getDefaultEntityRadius();
        java.awt.Stroke stroke9 = lineAndShapeRenderer2.getBaseOutlineStroke();
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot12.setRangeAxisLocation(axisLocation13, true);
        java.lang.Comparable comparable16 = categoryPlot12.getDomainCrosshairColumnKey();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke20 = lineAndShapeRenderer19.getBaseStroke();
        org.jfree.chart.LegendItemCollection legendItemCollection21 = lineAndShapeRenderer19.getLegendItems();
        categoryPlot12.setFixedLegendItems(legendItemCollection21);
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState25 = lineAndShapeRenderer2.initialise(graphics2D10, rectangle2D11, categoryPlot12, categoryDataset23, plotRenderingInfo24);
        boolean boolean26 = lineAndShapeRenderer2.getBaseShapesVisible();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNull(comparable16);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(legendItemCollection21);
        org.junit.Assert.assertNotNull(categoryItemRendererState25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent9 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot0);
        org.jfree.chart.JFreeChart jFreeChart10 = null;
        plotChangeEvent9.setChart(jFreeChart10);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        plotChangeEvent9.setType(chartChangeEventType12);
        org.jfree.chart.plot.Plot plot14 = plotChangeEvent9.getPlot();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(chartChangeEventType12);
        org.junit.Assert.assertNotNull(plot14);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier4 = categoryPlot0.getDrawingSupplier();
        java.awt.Stroke stroke5 = categoryPlot0.getOutlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot0.setRangeAxisLocation((int) (byte) 10, axisLocation7);
        int int9 = categoryPlot0.getCrosshairDatasetIndex();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(drawingSupplier4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        lineAndShapeRenderer2.setBaseSeriesVisibleInLegend(false, true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer12 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke13 = lineAndShapeRenderer12.getBaseStroke();
        java.awt.Paint paint15 = lineAndShapeRenderer12.getSeriesPaint(15);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = lineAndShapeRenderer12.getSeriesNegativeItemLabelPosition(255);
        lineAndShapeRenderer2.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition17);
        try {
            lineAndShapeRenderer2.setItemMargin(3.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 0.0 <= margin < 1.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNull(paint15);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent9 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot0);
        org.jfree.chart.plot.Plot plot10 = plotChangeEvent9.getPlot();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType11 = plotChangeEvent9.getType();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(plot10);
        org.junit.Assert.assertNotNull(chartChangeEventType11);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge();
        int int4 = categoryPlot0.getWeight();
        java.util.List list5 = categoryPlot0.getAnnotations();
        java.awt.Color color6 = java.awt.Color.WHITE;
        categoryPlot0.setOutlinePaint((java.awt.Paint) color6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot9.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = categoryPlot9.getDomainAxisEdge();
        int int13 = categoryPlot9.getWeight();
        java.util.List list14 = categoryPlot9.getAnnotations();
        try {
            categoryPlot0.mapDatasetToDomainAxes(0, list14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Empty list not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(list14);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape4 = null;
        java.awt.Stroke stroke5 = null;
        org.jfree.chart.renderer.RenderAttributes renderAttributes10 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        renderAttributes10.setDefaultFillPaint((java.awt.Paint) color11);
        java.awt.Shape shape15 = renderAttributes10.getItemShape((int) (byte) 100, (int) 'a');
        java.awt.Shape shape16 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        renderAttributes10.setDefaultShape(shape16);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot18.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis21 = categoryPlot18.getRangeAxis();
        int int22 = categoryPlot18.getBackgroundImageAlignment();
        categoryPlot18.setDomainCrosshairColumnKey((java.lang.Comparable) (short) -1, true);
        java.awt.Stroke stroke26 = categoryPlot18.getDomainGridlineStroke();
        java.awt.Color color27 = java.awt.Color.MAGENTA;
        org.jfree.chart.LegendItem legendItem28 = new org.jfree.chart.LegendItem("hi!", "AxisLocation.BOTTOM_OR_LEFT", "AxisLocation.BOTTOM_OR_LEFT", "ChartChangeEventType.GENERAL", shape16, stroke26, (java.awt.Paint) color27);
        try {
            org.jfree.chart.LegendItem legendItem29 = new org.jfree.chart.LegendItem(attributedString0, "", "SortOrder.ASCENDING", "SortOrder.ASCENDING", shape4, stroke5, (java.awt.Paint) color27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(shape15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNull(valueAxis21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 15 + "'", int22 == 15);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(color27);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Shape shape11 = null;
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", shape11, (java.awt.Paint) color12);
        int int14 = color12.getBlue();
        lineAndShapeRenderer2.setSeriesItemLabelPaint((int) (byte) 1, (java.awt.Paint) color12);
        org.jfree.chart.renderer.RenderAttributes renderAttributes21 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        renderAttributes21.setDefaultFillPaint((java.awt.Paint) color22);
        java.awt.Shape shape26 = renderAttributes21.getItemShape((int) (byte) 100, (int) 'a');
        java.awt.Shape shape27 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        renderAttributes21.setDefaultShape(shape27);
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot29.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis32 = categoryPlot29.getRangeAxis();
        int int33 = categoryPlot29.getBackgroundImageAlignment();
        categoryPlot29.setDomainCrosshairColumnKey((java.lang.Comparable) (short) -1, true);
        java.awt.Stroke stroke37 = categoryPlot29.getDomainGridlineStroke();
        java.awt.Color color38 = java.awt.Color.MAGENTA;
        org.jfree.chart.LegendItem legendItem39 = new org.jfree.chart.LegendItem("hi!", "AxisLocation.BOTTOM_OR_LEFT", "AxisLocation.BOTTOM_OR_LEFT", "ChartChangeEventType.GENERAL", shape27, stroke37, (java.awt.Paint) color38);
        try {
            lineAndShapeRenderer2.setSeriesOutlineStroke((-16728064), stroke37, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 128 + "'", int14 == 128);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNull(shape26);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNull(valueAxis32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 15 + "'", int33 == 15);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(color38);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder5 = categoryPlot0.getRowRenderingOrder();
        java.awt.Stroke stroke6 = categoryPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = categoryPlot0.getInsets();
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent9 = null;
        categoryPlot0.axisChanged(axisChangeEvent9);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(sortOrder5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(axisLocation8);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        int int1 = color0.getRGB();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-128) + "'", int1 == (-128));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        java.awt.Paint paint4 = categoryPlot0.getDomainGridlinePaint();
        boolean boolean5 = categoryPlot0.isDomainCrosshairVisible();
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        try {
            categoryPlot0.drawOutline(graphics2D6, rectangle2D7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isRangeGridlinesVisible();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder2 = categoryPlot0.getDatasetRenderingOrder();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean4 = categoryPlot3.isRangeGridlinesVisible();
        categoryPlot3.clearDomainAxes();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        categoryPlot3.setOutlinePaint((java.awt.Paint) color6);
        categoryPlot0.setRangeMinorGridlinePaint((java.awt.Paint) color6);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(color6);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isRangeGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getRangeAxisEdge((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot4.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis7 = categoryPlot4.getRangeAxis();
        int int8 = categoryPlot4.getBackgroundImageAlignment();
        categoryPlot4.setDomainCrosshairColumnKey((java.lang.Comparable) (short) -1, true);
        java.awt.Stroke stroke12 = categoryPlot4.getDomainGridlineStroke();
        categoryPlot0.setRangeMinorGridlineStroke(stroke12);
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = null;
        try {
            categoryPlot0.addDomainMarker(categoryMarker14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 15 + "'", int8 == 15);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset0 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.category.CategoryDatasetSelectionState categoryDatasetSelectionState1 = null;
        abstractCategoryDataset0.setSelectionState(categoryDatasetSelectionState1);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot3.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot3.zoomDomainAxes((double) 10.0f, plotRenderingInfo8, point2D9, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor12 = categoryPlot3.getDomainGridlinePosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot13.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis16 = categoryPlot13.getRangeAxis();
        int int17 = categoryPlot13.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder18 = categoryPlot13.getRowRenderingOrder();
        java.awt.Stroke stroke19 = categoryPlot13.getRangeZeroBaselineStroke();
        categoryPlot3.setRangeMinorGridlineStroke(stroke19);
        org.jfree.chart.axis.ValueAxis valueAxis22 = categoryPlot3.getRangeAxis(1);
        boolean boolean23 = abstractCategoryDataset0.hasListener((java.util.EventListener) categoryPlot3);
        org.jfree.data.category.CategoryDatasetSelectionState categoryDatasetSelectionState24 = null;
        abstractCategoryDataset0.setSelectionState(categoryDatasetSelectionState24);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(categoryAnchor12);
        org.junit.Assert.assertNull(valueAxis16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 15 + "'", int17 == 15);
        org.junit.Assert.assertNotNull(sortOrder18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(valueAxis22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier4 = categoryPlot0.getDrawingSupplier();
        java.awt.Paint paint5 = categoryPlot0.getOutlinePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot6.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis9 = categoryPlot6.getRangeAxis();
        int int10 = categoryPlot6.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder11 = categoryPlot6.getRowRenderingOrder();
        java.awt.Stroke stroke12 = categoryPlot6.getRangeZeroBaselineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
        categoryPlot6.rendererChanged(rendererChangeEvent13);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot15.setRangeAxisLocation(axisLocation16, true);
        categoryPlot6.setDomainAxisLocation(axisLocation16);
        categoryPlot6.setCrosshairDatasetIndex((int) (short) 1);
        org.jfree.data.category.CategoryDataset categoryDataset22 = categoryPlot6.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = categoryPlot6.getAxisOffset();
        categoryPlot0.setAxisOffset(rectangleInsets23);
        double double26 = rectangleInsets23.calculateLeftInset((double) 3);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(drawingSupplier4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 15 + "'", int10 == 15);
        org.junit.Assert.assertNotNull(sortOrder11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNull(categoryDataset22);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 4.0d + "'", double26 == 4.0d);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        java.lang.Number number0 = null;
        org.jfree.data.SelectableValue selectableValue1 = new org.jfree.data.SelectableValue(number0);
        selectableValue1.setSelected(true);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets(0.2d, (double) 1.0f, (double) 10L, (double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType6 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType7 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D8 = rectangleInsets4.createAdjustedRectangle(rectangle2D5, lengthAdjustmentType6, lengthAdjustmentType7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        renderAttributes0.setDefaultFillPaint((java.awt.Paint) color1);
        java.awt.Shape shape5 = renderAttributes0.getItemShape((int) (byte) 100, (int) 'a');
        java.awt.Shape shape7 = null;
        renderAttributes0.setSeriesShape((int) (byte) 1, shape7);
        java.awt.Paint paint11 = renderAttributes0.getItemOutlinePaint(15, (int) (short) 100);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNull(shape5);
        org.junit.Assert.assertNull(paint11);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape0, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape4 = chartEntity3.getArea();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot5.zoomDomainAxes((double) 10.0f, plotRenderingInfo10, point2D11, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor14 = categoryPlot5.getDomainGridlinePosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot15.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis18 = categoryPlot15.getRangeAxis();
        int int19 = categoryPlot15.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder20 = categoryPlot15.getRowRenderingOrder();
        java.awt.Stroke stroke21 = categoryPlot15.getRangeZeroBaselineStroke();
        categoryPlot5.setRangeMinorGridlineStroke(stroke21);
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = categoryPlot5.getDomainAxis(100);
        boolean boolean25 = categoryPlot5.isNotify();
        org.jfree.chart.entity.PlotEntity plotEntity27 = new org.jfree.chart.entity.PlotEntity(shape4, (org.jfree.chart.plot.Plot) categoryPlot5, "ItemLabelAnchor.OUTSIDE1");
        boolean boolean28 = categoryPlot5.isRangeZoomable();
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryPlot5.setRangeCrosshairPaint((java.awt.Paint) color29);
        org.jfree.chart.plot.Marker marker31 = null;
        try {
            categoryPlot5.addRangeMarker(marker31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertNotNull(categoryAnchor14);
        org.junit.Assert.assertNull(valueAxis18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 15 + "'", int19 == 15);
        org.junit.Assert.assertNotNull(sortOrder20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNull(categoryAxis24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(color29);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.awt.GradientPaint gradientPaint1 = null;
        java.awt.Shape shape6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot7.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis10 = categoryPlot7.getRangeAxis();
        int int11 = categoryPlot7.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder12 = categoryPlot7.getRowRenderingOrder();
        java.awt.Stroke stroke13 = categoryPlot7.getRangeZeroBaselineStroke();
        java.awt.Paint paint14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("", "", "hi!", "", shape6, stroke13, paint14);
        legendItem15.setSeriesIndex((int) (byte) 10);
        java.awt.Shape shape18 = legendItem15.getShape();
        try {
            java.awt.GradientPaint gradientPaint19 = standardGradientPaintTransformer0.transform(gradientPaint1, shape18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 15 + "'", int11 == 15);
        org.junit.Assert.assertNotNull(sortOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(shape18);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        try {
            defaultCategoryDataset0.setSelected(0, (-128), false);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.clearSeriesStrokes(true);
        java.lang.Boolean boolean4 = lineAndShapeRenderer0.getSeriesVisibleInLegend(3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        try {
            lineAndShapeRenderer0.drawOutline(graphics2D5, categoryPlot6, rectangle2D7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(boolean4);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge();
        org.jfree.chart.axis.AxisLocation axisLocation4 = categoryPlot0.getDomainAxisLocation();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        categoryPlot0.drawBackgroundImage(graphics2D5, rectangle2D6);
        categoryPlot0.setRangePannable(false);
        categoryPlot0.setDrawSharedDomainAxis(false);
        org.jfree.chart.plot.Marker marker13 = null;
        org.jfree.chart.util.Layer layer14 = null;
        try {
            categoryPlot0.addRangeMarker((int) (byte) 10, marker13, layer14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(axisLocation4);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier4 = categoryPlot0.getDrawingSupplier();
        java.awt.Stroke stroke5 = categoryPlot0.getOutlineStroke();
        org.jfree.chart.plot.Plot plot6 = categoryPlot0.getParent();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier7 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint8 = defaultDrawingSupplier7.getNextOutlinePaint();
        try {
            plot6.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(drawingSupplier4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNull(plot6);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder4 = categoryPlot0.getDatasetRenderingOrder();
        java.lang.String str5 = datasetRenderingOrder4.toString();
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(datasetRenderingOrder4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "DatasetRenderingOrder.REVERSE" + "'", str5.equals("DatasetRenderingOrder.REVERSE"));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isRangeGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getRangeAxisEdge((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot4.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis7 = categoryPlot4.getRangeAxis();
        int int8 = categoryPlot4.getBackgroundImageAlignment();
        categoryPlot4.setDomainCrosshairColumnKey((java.lang.Comparable) (short) -1, true);
        java.awt.Stroke stroke12 = categoryPlot4.getDomainGridlineStroke();
        categoryPlot0.setRangeMinorGridlineStroke(stroke12);
        categoryPlot0.setNotify(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 15 + "'", int8 == 15);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Paint paint5 = lineAndShapeRenderer2.getSeriesPaint(15);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = lineAndShapeRenderer2.getSeriesNegativeItemLabelPosition(255);
        int int8 = lineAndShapeRenderer2.getDefaultEntityRadius();
        java.awt.Stroke stroke9 = lineAndShapeRenderer2.getBaseOutlineStroke();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator11 = lineAndShapeRenderer2.getSeriesToolTipGenerator(128);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset18 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer24 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke25 = lineAndShapeRenderer24.getBaseStroke();
        java.awt.Paint paint27 = lineAndShapeRenderer24.getSeriesPaint(15);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition29 = lineAndShapeRenderer24.getSeriesNegativeItemLabelPosition(255);
        int int30 = lineAndShapeRenderer24.getDefaultEntityRadius();
        java.awt.Stroke stroke31 = lineAndShapeRenderer24.getBaseOutlineStroke();
        java.awt.Graphics2D graphics2D32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation35 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot34.setRangeAxisLocation(axisLocation35, true);
        java.lang.Comparable comparable38 = categoryPlot34.getDomainCrosshairColumnKey();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer41 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke42 = lineAndShapeRenderer41.getBaseStroke();
        org.jfree.chart.LegendItemCollection legendItemCollection43 = lineAndShapeRenderer41.getLegendItems();
        categoryPlot34.setFixedLegendItems(legendItemCollection43);
        org.jfree.data.category.CategoryDataset categoryDataset45 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo46 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState47 = lineAndShapeRenderer24.initialise(graphics2D32, rectangle2D33, categoryPlot34, categoryDataset45, plotRenderingInfo46);
        try {
            java.awt.Shape shape48 = lineAndShapeRenderer2.createHotSpotShape(graphics2D12, rectangle2D13, categoryPlot14, categoryAxis16, valueAxis17, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset18, (-128), (int) (short) 0, true, categoryItemRendererState47);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNull(categoryToolTipGenerator11);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNull(paint27);
        org.junit.Assert.assertNotNull(itemLabelPosition29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 3 + "'", int30 == 3);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertNull(comparable38);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(legendItemCollection43);
        org.junit.Assert.assertNotNull(categoryItemRendererState47);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        categoryPlot0.setDomainCrosshairColumnKey((java.lang.Comparable) (short) -1, true);
        org.jfree.chart.util.Layer layer9 = null;
        java.util.Collection collection10 = categoryPlot0.getRangeMarkers((int) (short) 0, layer9);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot11.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis14 = categoryPlot11.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        categoryPlot11.zoomDomainAxes((double) 10.0f, plotRenderingInfo16, point2D17, false);
        java.lang.Comparable comparable20 = categoryPlot11.getDomainCrosshairColumnKey();
        boolean boolean21 = categoryPlot11.isRangeCrosshairLockedOnData();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = categoryPlot11.getAxisOffset();
        double double23 = rectangleInsets22.getLeft();
        categoryPlot0.setAxisOffset(rectangleInsets22);
        double double26 = rectangleInsets22.calculateRightOutset((double) (byte) 1);
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D30 = rectangleInsets22.createInsetRectangle(rectangle2D27, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNull(collection10);
        org.junit.Assert.assertNull(valueAxis14);
        org.junit.Assert.assertNull(comparable20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 4.0d + "'", double23 == 4.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 4.0d + "'", double26 == 4.0d);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Paint paint5 = lineAndShapeRenderer2.getSeriesPaint(15);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = lineAndShapeRenderer2.getSeriesNegativeItemLabelPosition(255);
        int int8 = lineAndShapeRenderer2.getDefaultEntityRadius();
        java.awt.Stroke stroke9 = lineAndShapeRenderer2.getBaseOutlineStroke();
        java.awt.Shape shape11 = lineAndShapeRenderer2.getSeriesShape(15);
        boolean boolean12 = lineAndShapeRenderer2.getDataBoundsIncludesVisibleSeriesOnly();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNull(shape11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder5 = categoryPlot0.getRowRenderingOrder();
        java.awt.Stroke stroke6 = categoryPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = categoryPlot0.getInsets();
        categoryPlot0.setCrosshairDatasetIndex(64, false);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(sortOrder5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj1 = standardGradientPaintTransformer0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        int int9 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        try {
            categoryPlot0.addDomainMarker((int) '4', categoryMarker11, layer12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryPlot0.getAxisOffset();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D7 = rectangleInsets3.createInsetRectangle(rectangle2D4, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets3);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        java.lang.Comparable comparable9 = categoryPlot0.getDomainCrosshairColumnKey();
        boolean boolean10 = categoryPlot0.isRangeCrosshairLockedOnData();
        categoryPlot0.setCrosshairDatasetIndex((int) (byte) 10, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = categoryPlot0.getInsets();
        org.jfree.chart.plot.Marker marker15 = null;
        org.jfree.chart.util.Layer layer16 = null;
        try {
            categoryPlot0.addRangeMarker(marker15, layer16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNull(comparable9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(rectangleInsets14);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        java.awt.Shape shape4 = null;
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem6 = new org.jfree.chart.LegendItem("", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", shape4, (java.awt.Paint) color5);
        java.awt.Paint paint7 = legendItem6.getLabelPaint();
        legendItem6.setToolTipText("AxisLocation.BOTTOM_OR_LEFT");
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(paint7);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        java.awt.Color color1 = java.awt.Color.getColor("ChartChangeEventType.GENERAL");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        categoryPlot0.setDomainCrosshairColumnKey((java.lang.Comparable) (short) -1, true);
        org.jfree.chart.plot.Marker marker9 = null;
        org.jfree.chart.util.Layer layer10 = null;
        try {
            categoryPlot0.addRangeMarker((int) (short) 100, marker9, layer10, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot4.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis7 = categoryPlot4.getRangeAxis();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot4.getDrawingSupplier();
        org.jfree.data.category.CategoryDataset categoryDataset9 = categoryPlot4.getDataset();
        boolean boolean10 = lineAndShapeRenderer2.hasListener((java.util.EventListener) categoryPlot4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        try {
            categoryPlot4.handleClick((-16728064), (int) (byte) 10, plotRenderingInfo13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNull(categoryDataset9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent9 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot0);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis13 = categoryPlot10.getRangeAxis();
        int int14 = categoryPlot10.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder15 = categoryPlot10.getRowRenderingOrder();
        java.awt.Stroke stroke16 = categoryPlot10.getRangeZeroBaselineStroke();
        categoryPlot0.setOutlineStroke(stroke16);
        categoryPlot0.setRangeCrosshairVisible(false);
        java.util.List list21 = null;
        try {
            categoryPlot0.mapDatasetToDomainAxes((int) (short) 0, list21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNull(valueAxis13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 15 + "'", int14 == 15);
        org.junit.Assert.assertNotNull(sortOrder15);
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        java.awt.Shape shape4 = null;
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem6 = new org.jfree.chart.LegendItem("", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", shape4, (java.awt.Paint) color5);
        java.awt.Shape shape7 = legendItem6.getShape();
        java.awt.Paint paint8 = legendItem6.getLinePaint();
        java.awt.Paint paint9 = legendItem6.getLinePaint();
        java.lang.Object obj10 = null;
        boolean boolean11 = legendItem6.equals(obj10);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(shape7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier4 = categoryPlot0.getDrawingSupplier();
        java.awt.Paint paint5 = categoryPlot0.getOutlinePaint();
        java.awt.Stroke stroke6 = categoryPlot0.getRangeGridlineStroke();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(drawingSupplier4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isRangeGridlinesVisible();
        categoryPlot0.clearDomainAxes();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        categoryPlot0.setOutlinePaint((java.awt.Paint) color3);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke9 = lineAndShapeRenderer8.getBaseStroke();
        java.awt.Stroke stroke11 = lineAndShapeRenderer8.lookupSeriesStroke(10);
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        lineAndShapeRenderer8.setBaseOutlinePaint(paint12);
        categoryPlot0.setRenderer(2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer8, false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity(shape4, "ChartChangeEventType.GENERAL", "");
        java.awt.Color color8 = java.awt.Color.PINK;
        java.awt.Stroke stroke9 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.renderer.RenderAttributes renderAttributes11 = new org.jfree.chart.renderer.RenderAttributes(true);
        java.awt.Color color13 = java.awt.Color.magenta;
        renderAttributes11.setSeriesOutlinePaint(128, (java.awt.Paint) color13);
        try {
            org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem(attributedString0, "AxisLocation.BOTTOM_OR_LEFT", "AxisLocation.BOTTOM_OR_LEFT", "rect", shape4, (java.awt.Paint) color8, stroke9, (java.awt.Paint) color13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color13);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Shape shape9 = lineAndShapeRenderer2.getItemShape((int) (short) 10, 100, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator13 = lineAndShapeRenderer2.getItemLabelGenerator((int) 'a', 0, false);
        lineAndShapeRenderer2.setSeriesLinesVisible((int) (short) 100, (java.lang.Boolean) true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator18 = null;
        try {
            lineAndShapeRenderer2.setSeriesURLGenerator((-1), categoryURLGenerator18, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNull(categoryItemLabelGenerator13);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis4 = categoryPlot1.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot1.zoomDomainAxes((double) 10.0f, plotRenderingInfo6, point2D7, false);
        java.lang.Comparable comparable10 = categoryPlot1.getDomainCrosshairColumnKey();
        boolean boolean11 = categoryPlot1.isRangeCrosshairLockedOnData();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        categoryPlot1.setDomainCrosshairPaint((java.awt.Paint) color12);
        java.awt.Color color14 = java.awt.Color.getColor("ItemLabelAnchor.OUTSIDE1", color12);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertNull(comparable10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color14);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot0.setRangeAxisLocation(axisLocation1, true);
        java.lang.Comparable comparable4 = categoryPlot0.getDomainCrosshairColumnKey();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke8 = lineAndShapeRenderer7.getBaseStroke();
        org.jfree.chart.LegendItemCollection legendItemCollection9 = lineAndShapeRenderer7.getLegendItems();
        categoryPlot0.setFixedLegendItems(legendItemCollection9);
        java.awt.Shape shape15 = null;
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", shape15, (java.awt.Paint) color16);
        java.awt.Shape shape18 = legendItem17.getShape();
        java.awt.Paint paint19 = legendItem17.getLinePaint();
        legendItemCollection9.add(legendItem17);
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot21.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis24 = categoryPlot21.getRangeAxis();
        int int25 = categoryPlot21.getBackgroundImageAlignment();
        categoryPlot21.setDomainCrosshairColumnKey((java.lang.Comparable) (short) -1, true);
        java.awt.Stroke stroke29 = categoryPlot21.getDomainGridlineStroke();
        legendItem17.setOutlineStroke(stroke29);
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNull(comparable4);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(legendItemCollection9);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(shape18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNull(valueAxis24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 15 + "'", int25 == 15);
        org.junit.Assert.assertNotNull(stroke29);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        int int9 = categoryPlot5.getBackgroundImageAlignment();
        categoryPlot5.setDomainCrosshairColumnKey((java.lang.Comparable) (short) -1, true);
        org.jfree.chart.util.Layer layer14 = null;
        java.util.Collection collection15 = categoryPlot5.getRangeMarkers((int) (short) 0, layer14);
        categoryPlot5.setRangeMinorGridlinesVisible(true);
        java.lang.String str18 = categoryPlot5.getNoDataMessage();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot19.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis22 = categoryPlot19.getRangeAxis();
        int int23 = categoryPlot19.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder24 = categoryPlot19.getRowRenderingOrder();
        categoryPlot19.setWeight((int) (short) 100);
        boolean boolean27 = categoryPlot19.isDomainCrosshairVisible();
        org.jfree.chart.util.ShadowGenerator shadowGenerator28 = categoryPlot19.getShadowGenerator();
        categoryPlot5.setShadowGenerator(shadowGenerator28);
        categoryPlot4.setShadowGenerator(shadowGenerator28);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNull(valueAxis22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 15 + "'", int23 == 15);
        org.junit.Assert.assertNotNull(sortOrder24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(shadowGenerator28);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder5 = categoryPlot0.getRowRenderingOrder();
        categoryPlot0.setWeight((int) (short) 100);
        int int8 = categoryPlot0.getDomainAxisCount();
        boolean boolean9 = categoryPlot0.isDomainCrosshairVisible();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(sortOrder5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor9 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis13 = categoryPlot10.getRangeAxis();
        int int14 = categoryPlot10.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder15 = categoryPlot10.getRowRenderingOrder();
        java.awt.Stroke stroke16 = categoryPlot10.getRangeZeroBaselineStroke();
        categoryPlot0.setRangeMinorGridlineStroke(stroke16);
        org.jfree.chart.axis.AxisSpace axisSpace18 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace18);
        int int20 = categoryPlot0.getRendererCount();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(categoryAnchor9);
        org.junit.Assert.assertNull(valueAxis13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 15 + "'", int14 == 15);
        org.junit.Assert.assertNotNull(sortOrder15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot3.getRangeAxis();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier7 = categoryPlot3.getDrawingSupplier();
        org.jfree.data.category.CategoryDataset categoryDataset8 = categoryPlot3.getDataset();
        org.jfree.chart.renderer.RenderAttributes renderAttributes9 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        renderAttributes9.setDefaultFillPaint((java.awt.Paint) color10);
        categoryPlot3.setBackgroundPaint((java.awt.Paint) color10);
        lineAndShapeRenderer2.setPlot(categoryPlot3);
        org.jfree.chart.event.RendererChangeListener rendererChangeListener14 = null;
        try {
            lineAndShapeRenderer2.addChangeListener(rendererChangeListener14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(drawingSupplier7);
        org.junit.Assert.assertNull(categoryDataset8);
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        java.awt.Color color0 = java.awt.Color.YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        renderAttributes0.setDefaultFillPaint((java.awt.Paint) color1);
        java.awt.Shape shape5 = renderAttributes0.getItemShape((int) (byte) 100, (int) 'a');
        java.awt.Shape shape7 = renderAttributes0.getSeriesShape((int) (short) -1);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNull(shape5);
        org.junit.Assert.assertNull(shape7);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent9 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot0);
        org.jfree.chart.plot.Marker marker10 = null;
        org.jfree.chart.util.Layer layer11 = null;
        boolean boolean12 = categoryPlot0.removeDomainMarker(marker10, layer11);
        org.jfree.chart.axis.AxisSpace axisSpace13 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace13, false);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        java.awt.Shape shape4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        int int9 = categoryPlot5.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot5.getRowRenderingOrder();
        java.awt.Stroke stroke11 = categoryPlot5.getRangeZeroBaselineStroke();
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("", "", "hi!", "", shape4, stroke11, paint12);
        legendItem13.setDescription("");
        int int16 = legendItem13.getDatasetIndex();
        java.lang.String str17 = legendItem13.getLabel();
        java.lang.String str18 = legendItem13.getLabel();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset19 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo20 = new org.jfree.chart.event.DatasetChangeInfo();
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent21 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object) legendItem13, (org.jfree.data.general.Dataset) defaultCategoryDataset19, datasetChangeInfo20);
        defaultCategoryDataset19.clearSelection();
        try {
            defaultCategoryDataset19.incrementValue(0.05d, (java.lang.Comparable) "GradientPaintTransformType.CENTER_HORIZONTAL", (java.lang.Comparable) "PlotEntity: tooltip = ItemLabelAnchor.OUTSIDE1");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Row key (GradientPaintTransformType.CENTER_HORIZONTAL) not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape0, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity(shape4, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape8 = chartEntity7.getArea();
        chartEntity3.setArea(shape8);
        chartEntity3.setURLText("AxisLocation.BOTTOM_OR_LEFT");
        java.lang.String str12 = chartEntity3.getShapeType();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "rect" + "'", str12.equals("rect"));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        lineAndShapeRenderer2.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator7);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = lineAndShapeRenderer2.getSeriesPositiveItemLabelPosition(0);
        lineAndShapeRenderer2.setBaseShapesFilled(false);
        lineAndShapeRenderer2.setSeriesShapesVisible(2, (java.lang.Boolean) true);
        boolean boolean16 = lineAndShapeRenderer2.getUseOutlinePaint();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge();
        org.jfree.chart.axis.AxisLocation axisLocation4 = categoryPlot0.getDomainAxisLocation();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        categoryPlot0.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        categoryPlot0.setDataset(categoryDataset8);
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        categoryPlot0.addChangeListener(plotChangeListener10);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(axisLocation4);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        java.awt.Shape shape4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        int int9 = categoryPlot5.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot5.getRowRenderingOrder();
        java.awt.Stroke stroke11 = categoryPlot5.getRangeZeroBaselineStroke();
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("", "", "hi!", "", shape4, stroke11, paint12);
        legendItem13.setDescription("");
        int int16 = legendItem13.getDatasetIndex();
        java.lang.String str17 = legendItem13.getLabel();
        java.lang.String str18 = legendItem13.getLabel();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset19 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo20 = new org.jfree.chart.event.DatasetChangeInfo();
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent21 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object) legendItem13, (org.jfree.data.general.Dataset) defaultCategoryDataset19, datasetChangeInfo20);
        defaultCategoryDataset19.clearSelection();
        try {
            defaultCategoryDataset19.incrementValue((double) 0.5f, (java.lang.Comparable) "PlotEntity: tooltip = ItemLabelAnchor.OUTSIDE1", (java.lang.Comparable) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Row key (PlotEntity: tooltip = ItemLabelAnchor.OUTSIDE1) not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        java.awt.Color color0 = java.awt.Color.black;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        java.lang.String str1 = plotOrientation0.toString();
        org.junit.Assert.assertNotNull(plotOrientation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "PlotOrientation.VERTICAL" + "'", str1.equals("PlotOrientation.VERTICAL"));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        try {
            keyedObjects0.insertValue(100, (java.lang.Comparable) 100, (java.lang.Object) 1.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 'position' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder5 = categoryPlot0.getRowRenderingOrder();
        categoryPlot0.setWeight((int) (short) 100);
        boolean boolean8 = categoryPlot0.isDomainCrosshairVisible();
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot0.getRangeAxisLocation();
        java.awt.Paint paint10 = categoryPlot0.getDomainGridlinePaint();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(sortOrder5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder5 = categoryPlot0.getRowRenderingOrder();
        java.awt.Stroke stroke6 = categoryPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent7 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent7);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot9.setRangeAxisLocation(axisLocation10, true);
        categoryPlot0.setDomainAxisLocation(axisLocation10);
        categoryPlot0.setCrosshairDatasetIndex((int) (short) 1);
        org.jfree.data.category.CategoryDataset categoryDataset16 = categoryPlot0.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = categoryPlot0.getAxisOffset();
        categoryPlot0.setOutlineVisible(true);
        org.jfree.chart.plot.Marker marker20 = null;
        org.jfree.chart.util.Layer layer21 = null;
        try {
            categoryPlot0.addRangeMarker(marker20, layer21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(sortOrder5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNull(categoryDataset16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        lineAndShapeRenderer2.setBaseSeriesVisibleInLegend(false, true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer12 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke13 = lineAndShapeRenderer12.getBaseStroke();
        java.awt.Paint paint15 = lineAndShapeRenderer12.getSeriesPaint(15);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = lineAndShapeRenderer12.getSeriesNegativeItemLabelPosition(255);
        lineAndShapeRenderer2.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition17);
        java.awt.Shape shape22 = lineAndShapeRenderer2.getItemShape(2, 0, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = lineAndShapeRenderer2.getNegativeItemLabelPosition((int) (short) 0, 255, true);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation27 = null;
        try {
            lineAndShapeRenderer2.addAnnotation(categoryAnnotation27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNull(paint15);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(itemLabelPosition26);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Paint paint6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        lineAndShapeRenderer2.setBaseOutlinePaint(paint6);
        java.awt.Font font8 = lineAndShapeRenderer2.getBaseItemLabelFont();
        java.awt.Paint paint9 = lineAndShapeRenderer2.getBaseFillPaint();
        boolean boolean10 = lineAndShapeRenderer2.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor12 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE5;
        java.awt.Color color13 = java.awt.Color.white;
        boolean boolean14 = itemLabelAnchor12.equals((java.lang.Object) color13);
        org.jfree.chart.text.TextAnchor textAnchor15 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor12, textAnchor15);
        try {
            lineAndShapeRenderer2.setSeriesNegativeItemLabelPosition((-1), itemLabelPosition16, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(textAnchor15);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = lineAndShapeRenderer2.getBasePositiveItemLabelPosition();
        lineAndShapeRenderer2.setItemLabelAnchorOffset((double) 100);
        org.junit.Assert.assertNotNull(itemLabelPosition3);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.chart.renderer.RenderAttributes renderAttributes4 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        renderAttributes4.setDefaultFillPaint((java.awt.Paint) color5);
        java.awt.Shape shape9 = renderAttributes4.getItemShape((int) (byte) 100, (int) 'a');
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        renderAttributes4.setDefaultShape(shape10);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot12.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis15 = categoryPlot12.getRangeAxis();
        int int16 = categoryPlot12.getBackgroundImageAlignment();
        categoryPlot12.setDomainCrosshairColumnKey((java.lang.Comparable) (short) -1, true);
        java.awt.Stroke stroke20 = categoryPlot12.getDomainGridlineStroke();
        java.awt.Color color21 = java.awt.Color.MAGENTA;
        org.jfree.chart.LegendItem legendItem22 = new org.jfree.chart.LegendItem("hi!", "AxisLocation.BOTTOM_OR_LEFT", "AxisLocation.BOTTOM_OR_LEFT", "ChartChangeEventType.GENERAL", shape10, stroke20, (java.awt.Paint) color21);
        org.jfree.chart.plot.Plot plot23 = null;
        try {
            org.jfree.chart.entity.PlotEntity plotEntity25 = new org.jfree.chart.entity.PlotEntity(shape10, plot23, "DatasetRenderingOrder.REVERSE");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(shape9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNull(valueAxis15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 15 + "'", int16 == 15);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color21);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE9;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Shape shape9 = lineAndShapeRenderer2.getItemShape((int) (short) 10, 100, true);
        lineAndShapeRenderer2.setBaseSeriesVisible(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = lineAndShapeRenderer2.getLegendItemLabelGenerator();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator12);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("rect");
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor9 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis13 = categoryPlot10.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Point2D point2D16 = null;
        categoryPlot10.zoomDomainAxes((double) 10.0f, plotRenderingInfo15, point2D16, false);
        boolean boolean19 = categoryPlot10.isRangeCrosshairVisible();
        java.awt.Stroke stroke20 = categoryPlot10.getRangeCrosshairStroke();
        boolean boolean21 = categoryAnchor9.equals((java.lang.Object) categoryPlot10);
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot22.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = categoryPlot22.getDomainAxisEdge();
        int int26 = categoryPlot22.getWeight();
        java.lang.Comparable comparable27 = categoryPlot22.getDomainCrosshairColumnKey();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer30 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke31 = lineAndShapeRenderer30.getBaseStroke();
        java.awt.Paint paint33 = lineAndShapeRenderer30.getSeriesPaint(15);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition35 = lineAndShapeRenderer30.getSeriesNegativeItemLabelPosition(255);
        int int36 = lineAndShapeRenderer30.getDefaultEntityRadius();
        java.awt.Stroke stroke37 = lineAndShapeRenderer30.getBaseOutlineStroke();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator39 = lineAndShapeRenderer30.getSeriesToolTipGenerator(128);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer42 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke43 = lineAndShapeRenderer42.getBaseStroke();
        java.awt.Stroke stroke45 = lineAndShapeRenderer42.lookupSeriesStroke(10);
        java.awt.Shape shape49 = lineAndShapeRenderer42.getItemShape((int) (short) 10, 100, true);
        lineAndShapeRenderer42.setBaseSeriesVisible(false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer54 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke55 = lineAndShapeRenderer54.getBaseStroke();
        java.awt.Stroke stroke57 = lineAndShapeRenderer54.lookupSeriesStroke(10);
        java.awt.Paint paint58 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        lineAndShapeRenderer54.setBaseOutlinePaint(paint58);
        java.awt.Font font60 = lineAndShapeRenderer54.getBaseItemLabelFont();
        java.awt.Paint paint61 = lineAndShapeRenderer54.getBaseFillPaint();
        boolean boolean62 = lineAndShapeRenderer54.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer65 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke66 = lineAndShapeRenderer65.getBaseStroke();
        org.jfree.chart.LegendItemCollection legendItemCollection67 = lineAndShapeRenderer65.getLegendItems();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer70 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke71 = lineAndShapeRenderer70.getBaseStroke();
        java.awt.Paint paint73 = lineAndShapeRenderer70.getSeriesPaint(15);
        double double74 = lineAndShapeRenderer70.getItemLabelAnchorOffset();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer77 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke78 = lineAndShapeRenderer77.getBaseStroke();
        java.awt.Stroke stroke80 = lineAndShapeRenderer77.lookupSeriesStroke(10);
        java.awt.Shape shape84 = lineAndShapeRenderer77.getItemShape((int) (short) 10, 100, true);
        java.awt.Paint paint86 = lineAndShapeRenderer77.getSeriesFillPaint((int) (short) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray87 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { lineAndShapeRenderer30, lineAndShapeRenderer42, lineAndShapeRenderer54, lineAndShapeRenderer65, lineAndShapeRenderer70, lineAndShapeRenderer77 };
        categoryPlot22.setRenderers(categoryItemRendererArray87);
        categoryPlot10.setRenderers(categoryItemRendererArray87);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(categoryAnchor9);
        org.junit.Assert.assertNull(valueAxis13);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(rectangleEdge25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNull(comparable27);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNull(paint33);
        org.junit.Assert.assertNotNull(itemLabelPosition35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 3 + "'", int36 == 3);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNull(categoryToolTipGenerator39);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(shape49);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertNotNull(paint58);
        org.junit.Assert.assertNotNull(font60);
        org.junit.Assert.assertNotNull(paint61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(stroke66);
        org.junit.Assert.assertNotNull(legendItemCollection67);
        org.junit.Assert.assertNotNull(stroke71);
        org.junit.Assert.assertNull(paint73);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 2.0d + "'", double74 == 2.0d);
        org.junit.Assert.assertNotNull(stroke78);
        org.junit.Assert.assertNotNull(stroke80);
        org.junit.Assert.assertNotNull(shape84);
        org.junit.Assert.assertNull(paint86);
        org.junit.Assert.assertNotNull(categoryItemRendererArray87);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        categoryPlot0.setDomainCrosshairColumnKey((java.lang.Comparable) (short) -1, true);
        org.jfree.chart.util.Layer layer9 = null;
        java.util.Collection collection10 = categoryPlot0.getRangeMarkers((int) (short) 0, layer9);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot11.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis14 = categoryPlot11.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        categoryPlot11.zoomDomainAxes((double) 10.0f, plotRenderingInfo16, point2D17, false);
        java.lang.Comparable comparable20 = categoryPlot11.getDomainCrosshairColumnKey();
        boolean boolean21 = categoryPlot11.isRangeCrosshairLockedOnData();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = categoryPlot11.getAxisOffset();
        double double23 = rectangleInsets22.getLeft();
        categoryPlot0.setAxisOffset(rectangleInsets22);
        double double26 = rectangleInsets22.calculateRightOutset((double) (byte) 1);
        org.jfree.chart.util.UnitType unitType27 = rectangleInsets22.getUnitType();
        double double29 = rectangleInsets22.extendHeight((double) (short) -1);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNull(collection10);
        org.junit.Assert.assertNull(valueAxis14);
        org.junit.Assert.assertNull(comparable20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 4.0d + "'", double23 == 4.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 4.0d + "'", double26 == 4.0d);
        org.junit.Assert.assertNotNull(unitType27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 7.0d + "'", double29 == 7.0d);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape0, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape4 = chartEntity3.getArea();
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape4);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor6 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE10;
        boolean boolean7 = chartEntity5.equals((java.lang.Object) itemLabelAnchor6);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(itemLabelAnchor6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        categoryPlot0.setDomainCrosshairColumnKey((java.lang.Comparable) (short) -1, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot0.zoomRangeAxes((double) (byte) 1, plotRenderingInfo9, point2D10, true);
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) 0.0f, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot16.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis19 = categoryPlot16.getRangeAxis();
        int int20 = categoryPlot16.getBackgroundImageAlignment();
        java.awt.Paint paint21 = categoryPlot16.getNoDataMessagePaint();
        java.awt.Paint paint22 = categoryPlot16.getRangeMinorGridlinePaint();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot16);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        categoryPlot0.zoomRangeAxes((double) (byte) 10, plotRenderingInfo25, point2D26);
        org.jfree.chart.plot.Marker marker28 = null;
        try {
            boolean boolean29 = categoryPlot0.removeRangeMarker(marker28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNull(valueAxis19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 15 + "'", int20 == 15);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.clearSeriesStrokes(true);
        java.lang.Boolean boolean4 = lineAndShapeRenderer0.getSeriesVisibleInLegend(3);
        java.lang.Boolean boolean6 = lineAndShapeRenderer0.getSeriesShapesFilled(10);
        lineAndShapeRenderer0.setSeriesVisible(15, (java.lang.Boolean) false, true);
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertNull(boolean6);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        java.awt.Stroke stroke0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets(8.0d, (double) 10L, (double) 255, (double) 1L);
        double double6 = rectangleInsets4.calculateBottomOutset(8.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 255.0d + "'", double6 == 255.0d);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        java.awt.Shape shape4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        int int9 = categoryPlot5.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot5.getRowRenderingOrder();
        java.awt.Stroke stroke11 = categoryPlot5.getRangeZeroBaselineStroke();
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("", "", "hi!", "", shape4, stroke11, paint12);
        legendItem13.setDescription("");
        int int16 = legendItem13.getDatasetIndex();
        java.lang.String str17 = legendItem13.getLabel();
        java.lang.String str18 = legendItem13.getLabel();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset19 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo20 = new org.jfree.chart.event.DatasetChangeInfo();
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent21 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object) legendItem13, (org.jfree.data.general.Dataset) defaultCategoryDataset19, datasetChangeInfo20);
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot22.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis25 = categoryPlot22.getRangeAxis();
        int int26 = categoryPlot22.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder27 = categoryPlot22.getRowRenderingOrder();
        java.awt.Stroke stroke28 = categoryPlot22.getRangeZeroBaselineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent29 = null;
        categoryPlot22.rendererChanged(rendererChangeEvent29);
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation32 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot31.setRangeAxisLocation(axisLocation32, true);
        categoryPlot22.setDomainAxisLocation(axisLocation32);
        categoryPlot22.setCrosshairDatasetIndex((int) (short) 1);
        java.awt.Image image38 = categoryPlot22.getBackgroundImage();
        java.awt.Paint paint39 = categoryPlot22.getOutlinePaint();
        defaultCategoryDataset19.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot22);
        try {
            boolean boolean43 = defaultCategoryDataset19.isSelected((int) 'a', 255);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertNull(valueAxis25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 15 + "'", int26 == 15);
        org.junit.Assert.assertNotNull(sortOrder27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(axisLocation32);
        org.junit.Assert.assertNull(image38);
        org.junit.Assert.assertNotNull(paint39);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        java.lang.Comparable comparable9 = categoryPlot0.getDomainCrosshairColumnKey();
        boolean boolean10 = categoryPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = categoryPlot0.getAxisOffset();
        double double12 = rectangleInsets11.getLeft();
        double double14 = rectangleInsets11.extendWidth((double) (short) 1);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNull(comparable9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 4.0d + "'", double12 == 4.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 9.0d + "'", double14 == 9.0d);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) 100L, 0.0f, 100.0f);
        int int4 = color3.getBlue();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 156 + "'", int4 == 156);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets(8.0d, (double) 10L, (double) 255, (double) 1L);
        double double6 = rectangleInsets4.extendWidth((double) 128);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 139.0d + "'", double6 == 139.0d);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Shape shape9 = lineAndShapeRenderer2.getItemShape((int) (short) 10, 100, true);
        lineAndShapeRenderer2.setBaseCreateEntities(true);
        lineAndShapeRenderer2.setAutoPopulateSeriesOutlinePaint(false);
        java.awt.Paint paint17 = lineAndShapeRenderer2.getItemLabelPaint((int) '4', 0, false);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Shape shape11 = null;
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", shape11, (java.awt.Paint) color12);
        int int14 = color12.getBlue();
        lineAndShapeRenderer2.setSeriesItemLabelPaint((int) (byte) 1, (java.awt.Paint) color12);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean17 = categoryPlot16.isRangeGridlinesVisible();
        categoryPlot16.clearDomainAxes();
        lineAndShapeRenderer2.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot16);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator21 = lineAndShapeRenderer2.getSeriesURLGenerator((int) 'a');
        lineAndShapeRenderer2.setAutoPopulateSeriesOutlineStroke(false);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 128 + "'", int14 == 128);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNull(categoryURLGenerator21);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        java.lang.Comparable comparable9 = categoryPlot0.getDomainCrosshairColumnKey();
        boolean boolean10 = categoryPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent11 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot0);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNull(comparable9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE7;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot4.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis7 = categoryPlot4.getRangeAxis();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot4.getDrawingSupplier();
        org.jfree.data.category.CategoryDataset categoryDataset9 = categoryPlot4.getDataset();
        boolean boolean10 = lineAndShapeRenderer2.hasListener((java.util.EventListener) categoryPlot4);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation11 = null;
        try {
            lineAndShapeRenderer2.addAnnotation(categoryAnnotation11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNull(categoryDataset9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge();
        org.jfree.chart.axis.AxisLocation axisLocation4 = categoryPlot0.getDomainAxisLocation();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        categoryPlot0.drawBackgroundImage(graphics2D5, rectangle2D6);
        java.awt.Paint paint8 = categoryPlot0.getRangeZeroBaselinePaint();
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        java.awt.Font font0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        lineAndShapeRenderer2.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator7);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = lineAndShapeRenderer2.getSeriesPositiveItemLabelPosition(0);
        java.awt.Stroke stroke11 = lineAndShapeRenderer2.getBaseStroke();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = lineAndShapeRenderer2.getLegendItemURLGenerator();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator12);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        renderAttributes0.setDefaultFillPaint((java.awt.Paint) color1);
        java.awt.Paint paint3 = renderAttributes0.getDefaultOutlinePaint();
        java.awt.Stroke stroke4 = renderAttributes0.getDefaultStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        int int9 = categoryPlot5.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot5.getRowRenderingOrder();
        categoryPlot5.setWeight((int) (short) 100);
        int int13 = categoryPlot5.getDomainAxisCount();
        java.lang.Object obj14 = categoryPlot5.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot15.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis18 = categoryPlot15.getRangeAxis();
        java.awt.Paint paint19 = categoryPlot15.getDomainGridlinePaint();
        categoryPlot5.setDomainCrosshairPaint(paint19);
        renderAttributes0.setDefaultLabelPaint(paint19);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNull(stroke4);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNull(valueAxis18);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        java.awt.Paint paint5 = categoryPlot0.getNoDataMessagePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = categoryPlot0.getDomainAxisForDataset((int) 'a');
        categoryPlot0.setBackgroundImageAlpha((float) 0);
        java.awt.Shape shape15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot16.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis19 = categoryPlot16.getRangeAxis();
        int int20 = categoryPlot16.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder21 = categoryPlot16.getRowRenderingOrder();
        java.awt.Stroke stroke22 = categoryPlot16.getRangeZeroBaselineStroke();
        java.awt.Paint paint23 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem24 = new org.jfree.chart.LegendItem("", "", "hi!", "", shape15, stroke22, paint23);
        legendItem24.setDescription("");
        int int27 = legendItem24.getDatasetIndex();
        java.lang.String str28 = legendItem24.getLabel();
        java.lang.String str29 = legendItem24.getLabel();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset30 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo31 = new org.jfree.chart.event.DatasetChangeInfo();
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent32 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object) legendItem24, (org.jfree.data.general.Dataset) defaultCategoryDataset30, datasetChangeInfo31);
        java.util.List list33 = defaultCategoryDataset30.getRowKeys();
        try {
            categoryPlot0.mapDatasetToDomainAxes(0, list33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Empty list not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(categoryAxis7);
        org.junit.Assert.assertNull(valueAxis19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 15 + "'", int20 == 15);
        org.junit.Assert.assertNotNull(sortOrder21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "" + "'", str28.equals(""));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "" + "'", str29.equals(""));
        org.junit.Assert.assertNotNull(list33);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge();
        int int4 = categoryPlot0.getWeight();
        java.util.List list5 = categoryPlot0.getAnnotations();
        categoryPlot0.setWeight((-1));
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(list5);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(true);
        java.awt.Color color3 = java.awt.Color.magenta;
        renderAttributes1.setSeriesOutlinePaint(128, (java.awt.Paint) color3);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot6.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis9 = categoryPlot6.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot6.zoomDomainAxes((double) 10.0f, plotRenderingInfo11, point2D12, false);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent15 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot6);
        org.jfree.chart.plot.Marker marker16 = null;
        org.jfree.chart.util.Layer layer17 = null;
        boolean boolean18 = categoryPlot6.removeDomainMarker(marker16, layer17);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot19.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis22 = categoryPlot19.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        java.awt.geom.Point2D point2D25 = null;
        categoryPlot19.zoomDomainAxes((double) 10.0f, plotRenderingInfo24, point2D25, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor28 = categoryPlot19.getDomainGridlinePosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot29.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis32 = categoryPlot29.getRangeAxis();
        int int33 = categoryPlot29.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder34 = categoryPlot29.getRowRenderingOrder();
        java.awt.Stroke stroke35 = categoryPlot29.getRangeZeroBaselineStroke();
        categoryPlot19.setRangeMinorGridlineStroke(stroke35);
        categoryPlot6.setRangeGridlineStroke(stroke35);
        try {
            renderAttributes1.setSeriesOutlineStroke((int) (byte) 1, stroke35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(valueAxis22);
        org.junit.Assert.assertNotNull(categoryAnchor28);
        org.junit.Assert.assertNull(valueAxis32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 15 + "'", int33 == 15);
        org.junit.Assert.assertNotNull(sortOrder34);
        org.junit.Assert.assertNotNull(stroke35);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Shape shape9 = lineAndShapeRenderer2.getItemShape((int) (short) 10, 100, true);
        lineAndShapeRenderer2.setBaseSeriesVisible(false);
        java.awt.Shape shape12 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity15 = new org.jfree.chart.entity.ChartEntity(shape12, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape16 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity19 = new org.jfree.chart.entity.ChartEntity(shape16, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape20 = chartEntity19.getArea();
        chartEntity15.setArea(shape20);
        lineAndShapeRenderer2.setBaseShape(shape20, true);
        java.lang.Boolean boolean25 = lineAndShapeRenderer2.getSeriesShapesVisible(1);
        java.awt.Font font26 = lineAndShapeRenderer2.getBaseItemLabelFont();
        lineAndShapeRenderer2.setSeriesShapesVisible(1, true);
        boolean boolean33 = lineAndShapeRenderer2.isItemLabelVisible(15, (int) (short) 1, false);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNull(boolean25);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset0 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.category.CategoryDatasetSelectionState categoryDatasetSelectionState1 = null;
        abstractCategoryDataset0.setSelectionState(categoryDatasetSelectionState1);
        java.lang.Object obj3 = abstractCategoryDataset0.clone();
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        renderAttributes0.setDefaultFillPaint((java.awt.Paint) color1);
        java.awt.Stroke stroke4 = renderAttributes0.getSeriesStroke((int) ' ');
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity9 = new org.jfree.chart.entity.ChartEntity(shape6, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape10 = chartEntity9.getArea();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot11.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis14 = categoryPlot11.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        categoryPlot11.zoomDomainAxes((double) 10.0f, plotRenderingInfo16, point2D17, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor20 = categoryPlot11.getDomainGridlinePosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot21.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis24 = categoryPlot21.getRangeAxis();
        int int25 = categoryPlot21.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder26 = categoryPlot21.getRowRenderingOrder();
        java.awt.Stroke stroke27 = categoryPlot21.getRangeZeroBaselineStroke();
        categoryPlot11.setRangeMinorGridlineStroke(stroke27);
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = categoryPlot11.getDomainAxis(100);
        boolean boolean31 = categoryPlot11.isNotify();
        org.jfree.chart.entity.PlotEntity plotEntity33 = new org.jfree.chart.entity.PlotEntity(shape10, (org.jfree.chart.plot.Plot) categoryPlot11, "ItemLabelAnchor.OUTSIDE1");
        renderAttributes0.setSeriesShape((int) (byte) 100, shape10);
        org.jfree.data.category.CategoryDataset categoryDataset37 = null;
        try {
            org.jfree.chart.entity.CategoryItemEntity categoryItemEntity40 = new org.jfree.chart.entity.CategoryItemEntity(shape10, "java.awt.Color[r=0,g=0,b=0]", "SortOrder.ASCENDING", categoryDataset37, (java.lang.Comparable) 2.0d, (java.lang.Comparable) "GradientPaintTransformType.CENTER_HORIZONTAL");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNull(stroke4);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNull(valueAxis14);
        org.junit.Assert.assertNotNull(categoryAnchor20);
        org.junit.Assert.assertNull(valueAxis24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 15 + "'", int25 == 15);
        org.junit.Assert.assertNotNull(sortOrder26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNull(categoryAxis30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Paint paint5 = lineAndShapeRenderer2.getSeriesPaint(15);
        double double6 = lineAndShapeRenderer2.getItemLabelAnchorOffset();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot7.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis10 = categoryPlot7.getRangeAxis();
        int int11 = categoryPlot7.getBackgroundImageAlignment();
        categoryPlot7.setDomainCrosshairColumnKey((java.lang.Comparable) (short) -1, true);
        java.awt.Stroke stroke15 = categoryPlot7.getDomainGridlineStroke();
        lineAndShapeRenderer2.setBaseStroke(stroke15);
        org.jfree.chart.renderer.RenderAttributes renderAttributes17 = lineAndShapeRenderer2.getSelectedItemAttributes();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.0d + "'", double6 == 2.0d);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 15 + "'", int11 == 15);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(renderAttributes17);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        java.lang.Comparable comparable9 = categoryPlot0.getDomainCrosshairColumnKey();
        boolean boolean10 = categoryPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = categoryPlot0.getAxisOffset();
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.util.Layer layer14 = null;
        java.util.Collection collection15 = categoryPlot0.getDomainMarkers(3, layer14);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot16.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis19 = categoryPlot16.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        categoryPlot16.zoomDomainAxes((double) 10.0f, plotRenderingInfo21, point2D22, false);
        java.lang.Comparable comparable25 = categoryPlot16.getDomainCrosshairColumnKey();
        boolean boolean26 = categoryPlot16.isRangeCrosshairLockedOnData();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = categoryPlot16.getAxisOffset();
        boolean boolean28 = categoryPlot16.isSubplot();
        boolean boolean29 = categoryPlot0.equals((java.lang.Object) categoryPlot16);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNull(comparable9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNull(valueAxis19);
        org.junit.Assert.assertNull(comparable25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = null;
        lineAndShapeRenderer2.setSeriesItemLabelGenerator((int) (byte) 1, categoryItemLabelGenerator5);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke11 = lineAndShapeRenderer10.getBaseStroke();
        java.awt.Paint paint13 = lineAndShapeRenderer10.getSeriesPaint(15);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer17 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke18 = lineAndShapeRenderer17.getBaseStroke();
        java.awt.Stroke stroke20 = lineAndShapeRenderer17.lookupSeriesStroke(10);
        java.awt.Paint paint21 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        lineAndShapeRenderer17.setBaseOutlinePaint(paint21);
        java.awt.Font font23 = lineAndShapeRenderer17.getBaseItemLabelFont();
        lineAndShapeRenderer10.setSeriesItemLabelFont((int) (byte) 1, font23);
        lineAndShapeRenderer2.setSeriesItemLabelFont((int) (short) 10, font23, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot27.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis30 = categoryPlot27.getRangeAxis();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier31 = categoryPlot27.getDrawingSupplier();
        org.jfree.data.category.CategoryDataset categoryDataset32 = categoryPlot27.getDataset();
        org.jfree.chart.renderer.RenderAttributes renderAttributes33 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color34 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        renderAttributes33.setDefaultFillPaint((java.awt.Paint) color34);
        categoryPlot27.setBackgroundPaint((java.awt.Paint) color34);
        org.jfree.chart.axis.ValueAxis valueAxis37 = categoryPlot27.getRangeAxis();
        int int38 = categoryPlot27.getRendererCount();
        boolean boolean39 = lineAndShapeRenderer2.equals((java.lang.Object) categoryPlot27);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNull(valueAxis30);
        org.junit.Assert.assertNotNull(drawingSupplier31);
        org.junit.Assert.assertNull(categoryDataset32);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNull(valueAxis37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        java.awt.Shape shape4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        int int9 = categoryPlot5.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot5.getRowRenderingOrder();
        java.awt.Stroke stroke11 = categoryPlot5.getRangeZeroBaselineStroke();
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("", "", "hi!", "", shape4, stroke11, paint12);
        legendItem13.setDescription("");
        java.awt.Paint paint16 = legendItem13.getOutlinePaint();
        legendItem13.setSeriesIndex((-128));
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        java.awt.Shape shape4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        int int9 = categoryPlot5.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot5.getRowRenderingOrder();
        java.awt.Stroke stroke11 = categoryPlot5.getRangeZeroBaselineStroke();
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("", "", "hi!", "", shape4, stroke11, paint12);
        legendItem13.setDescription("");
        int int16 = legendItem13.getDatasetIndex();
        java.lang.String str17 = legendItem13.getLabel();
        java.awt.Paint paint18 = legendItem13.getOutlinePaint();
        legendItem13.setDatasetIndex((int) (short) 100);
        java.awt.Font font21 = null;
        legendItem13.setLabelFont(font21);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        categoryPlot0.setRangeCrosshairVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        int int9 = categoryPlot5.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot5.getRowRenderingOrder();
        java.awt.Stroke stroke11 = categoryPlot5.getRangeZeroBaselineStroke();
        categoryPlot5.setRangeGridlinesVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot14.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis17 = categoryPlot14.getRangeAxis();
        int int18 = categoryPlot14.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder19 = categoryPlot14.getRowRenderingOrder();
        java.awt.Stroke stroke20 = categoryPlot14.getRangeZeroBaselineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent21 = null;
        categoryPlot14.rendererChanged(rendererChangeEvent21);
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation24 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot23.setRangeAxisLocation(axisLocation24, true);
        categoryPlot14.setDomainAxisLocation(axisLocation24);
        categoryPlot5.setDomainAxisLocation(axisLocation24, true);
        categoryPlot5.setBackgroundAlpha((float) 10);
        org.jfree.chart.axis.AxisLocation axisLocation32 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.axis.AxisLocation axisLocation33 = axisLocation32.getOpposite();
        categoryPlot5.setRangeAxisLocation(axisLocation33);
        categoryPlot0.setDomainAxisLocation(axisLocation33, false);
        boolean boolean37 = categoryPlot0.isDomainZoomable();
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(valueAxis17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 15 + "'", int18 == 15);
        org.junit.Assert.assertNotNull(sortOrder19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertNotNull(axisLocation32);
        org.junit.Assert.assertNotNull(axisLocation33);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.clearSeriesStrokes(true);
        lineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.renderer.RenderAttributes renderAttributes7 = new org.jfree.chart.renderer.RenderAttributes(true);
        java.awt.Color color9 = java.awt.Color.magenta;
        renderAttributes7.setSeriesOutlinePaint(128, (java.awt.Paint) color9);
        lineAndShapeRenderer0.setSeriesItemLabelPaint((int) (short) 1, (java.awt.Paint) color9);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot13.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis16 = categoryPlot13.getRangeAxis();
        int int17 = categoryPlot13.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder18 = categoryPlot13.getRowRenderingOrder();
        java.awt.Stroke stroke19 = categoryPlot13.getRangeZeroBaselineStroke();
        categoryPlot13.setRangeGridlinesVisible(false);
        java.lang.Class<?> wildcardClass22 = categoryPlot13.getClass();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = categoryAxis24.getTickLabelInsets();
        categoryAxis24.setCategoryLabelPositionOffset(0);
        categoryAxis24.setMinorTickMarksVisible(false);
        float float30 = categoryAxis24.getMinorTickMarkOutsideLength();
        boolean boolean31 = categoryAxis24.isVisible();
        org.jfree.chart.plot.CategoryMarker categoryMarker32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        try {
            lineAndShapeRenderer0.drawDomainMarker(graphics2D12, categoryPlot13, categoryAxis24, categoryMarker32, rectangle2D33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNull(valueAxis16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 15 + "'", int17 == 15);
        org.junit.Assert.assertNotNull(sortOrder18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 2.0f + "'", float30 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke7 = lineAndShapeRenderer6.getBaseStroke();
        java.awt.Stroke stroke9 = lineAndShapeRenderer6.lookupSeriesStroke(10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator11 = null;
        lineAndShapeRenderer6.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator11);
        lineAndShapeRenderer6.setSeriesVisible((int) (short) 100, (java.lang.Boolean) false, true);
        boolean boolean19 = lineAndShapeRenderer6.getItemShapeVisible((int) (short) 10, 3);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator20 = lineAndShapeRenderer6.getLegendItemLabelGenerator();
        lineAndShapeRenderer6.setSeriesVisible((int) '4', (java.lang.Boolean) true);
        java.awt.Shape shape24 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity27 = new org.jfree.chart.entity.ChartEntity(shape24, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape28 = chartEntity27.getArea();
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot29.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis32 = categoryPlot29.getRangeAxis();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier33 = categoryPlot29.getDrawingSupplier();
        org.jfree.data.category.CategoryDataset categoryDataset34 = categoryPlot29.getDataset();
        org.jfree.chart.renderer.RenderAttributes renderAttributes35 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color36 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        renderAttributes35.setDefaultFillPaint((java.awt.Paint) color36);
        categoryPlot29.setBackgroundPaint((java.awt.Paint) color36);
        org.jfree.chart.axis.ValueAxis valueAxis39 = categoryPlot29.getRangeAxis();
        org.jfree.chart.entity.PlotEntity plotEntity42 = new org.jfree.chart.entity.PlotEntity(shape28, (org.jfree.chart.plot.Plot) categoryPlot29, "ChartChangeEventType.GENERAL", "hi!");
        lineAndShapeRenderer6.setBaseShape(shape28);
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation45 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot44.setRangeAxisLocation(axisLocation45, true);
        java.util.List list48 = categoryPlot44.getAnnotations();
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = null;
        categoryPlot44.setDomainAxis((int) (byte) 0, categoryAxis50, false);
        org.jfree.chart.entity.PlotEntity plotEntity55 = new org.jfree.chart.entity.PlotEntity(shape28, (org.jfree.chart.plot.Plot) categoryPlot44, "DatasetRenderingOrder.REVERSE", "{0}");
        org.jfree.chart.plot.CategoryPlot categoryPlot56 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot56.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis59 = categoryPlot56.getRangeAxis();
        int int60 = categoryPlot56.getBackgroundImageAlignment();
        categoryPlot56.setDomainCrosshairColumnKey((java.lang.Comparable) (short) -1, true);
        java.awt.Stroke stroke64 = categoryPlot56.getDomainGridlineStroke();
        java.awt.Stroke stroke65 = categoryPlot56.getDomainGridlineStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot66 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot66.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis69 = categoryPlot66.getRangeAxis();
        int int70 = categoryPlot66.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder71 = categoryPlot66.getRowRenderingOrder();
        categoryPlot66.setWeight((int) (short) 100);
        int int74 = categoryPlot66.getDomainAxisCount();
        java.lang.Object obj75 = categoryPlot66.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot76 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot76.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis79 = categoryPlot76.getRangeAxis();
        java.awt.Paint paint80 = categoryPlot76.getDomainGridlinePaint();
        categoryPlot66.setDomainCrosshairPaint(paint80);
        try {
            org.jfree.chart.LegendItem legendItem82 = new org.jfree.chart.LegendItem(attributedString0, "SortOrder.ASCENDING", "SortOrder.ASCENDING", "", shape28, stroke65, paint80);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator20);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNull(valueAxis32);
        org.junit.Assert.assertNotNull(drawingSupplier33);
        org.junit.Assert.assertNull(categoryDataset34);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNull(valueAxis39);
        org.junit.Assert.assertNotNull(axisLocation45);
        org.junit.Assert.assertNotNull(list48);
        org.junit.Assert.assertNull(valueAxis59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 15 + "'", int60 == 15);
        org.junit.Assert.assertNotNull(stroke64);
        org.junit.Assert.assertNotNull(stroke65);
        org.junit.Assert.assertNull(valueAxis69);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 15 + "'", int70 == 15);
        org.junit.Assert.assertNotNull(sortOrder71);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 1 + "'", int74 == 1);
        org.junit.Assert.assertNotNull(obj75);
        org.junit.Assert.assertNull(valueAxis79);
        org.junit.Assert.assertNotNull(paint80);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = defaultCategoryDataset0.getGroup();
        try {
            defaultCategoryDataset0.removeRow((java.lang.Comparable) 255);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Row key (255) not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(datasetGroup1);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Shape shape9 = lineAndShapeRenderer2.getItemShape((int) (short) 10, 100, true);
        lineAndShapeRenderer2.setBaseSeriesVisible(false);
        java.awt.Shape shape12 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity15 = new org.jfree.chart.entity.ChartEntity(shape12, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape16 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity19 = new org.jfree.chart.entity.ChartEntity(shape16, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape20 = chartEntity19.getArea();
        chartEntity15.setArea(shape20);
        lineAndShapeRenderer2.setBaseShape(shape20, true);
        java.awt.Graphics2D graphics2D26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation29 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot28.setRangeAxisLocation(axisLocation29, true);
        org.jfree.chart.axis.ValueAxis valueAxis33 = categoryPlot28.getRangeAxis((int) '#');
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = categoryAxis35.getTickLabelInsets();
        categoryAxis35.setCategoryLabelPositionOffset(0);
        categoryAxis35.setMinorTickMarksVisible(false);
        float float41 = categoryAxis35.getMinorTickMarkOutsideLength();
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = categoryAxis35.getLabelInsets();
        org.jfree.chart.axis.ValueAxis valueAxis43 = null;
        org.jfree.data.category.CategoryDataset categoryDataset44 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer50 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke51 = lineAndShapeRenderer50.getBaseStroke();
        java.awt.Paint paint53 = lineAndShapeRenderer50.getSeriesPaint(15);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition55 = lineAndShapeRenderer50.getSeriesNegativeItemLabelPosition(255);
        int int56 = lineAndShapeRenderer50.getDefaultEntityRadius();
        java.awt.Stroke stroke57 = lineAndShapeRenderer50.getBaseOutlineStroke();
        java.awt.Graphics2D graphics2D58 = null;
        java.awt.geom.Rectangle2D rectangle2D59 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation61 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot60.setRangeAxisLocation(axisLocation61, true);
        java.lang.Comparable comparable64 = categoryPlot60.getDomainCrosshairColumnKey();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer67 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke68 = lineAndShapeRenderer67.getBaseStroke();
        org.jfree.chart.LegendItemCollection legendItemCollection69 = lineAndShapeRenderer67.getLegendItems();
        categoryPlot60.setFixedLegendItems(legendItemCollection69);
        org.jfree.data.category.CategoryDataset categoryDataset71 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo72 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState73 = lineAndShapeRenderer50.initialise(graphics2D58, rectangle2D59, categoryPlot60, categoryDataset71, plotRenderingInfo72);
        try {
            boolean boolean74 = lineAndShapeRenderer2.hitTest(0.2d, (double) 1, graphics2D26, rectangle2D27, categoryPlot28, categoryAxis35, valueAxis43, categoryDataset44, 128, 1, true, categoryItemRendererState73);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(axisLocation29);
        org.junit.Assert.assertNull(valueAxis33);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + float41 + "' != '" + 2.0f + "'", float41 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets42);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNull(paint53);
        org.junit.Assert.assertNotNull(itemLabelPosition55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 3 + "'", int56 == 3);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertNotNull(axisLocation61);
        org.junit.Assert.assertNull(comparable64);
        org.junit.Assert.assertNotNull(stroke68);
        org.junit.Assert.assertNotNull(legendItemCollection69);
        org.junit.Assert.assertNotNull(categoryItemRendererState73);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        renderAttributes0.setDefaultFillPaint((java.awt.Paint) color1);
        java.awt.Shape shape5 = renderAttributes0.getItemShape((int) (byte) 100, (int) 'a');
        java.awt.Shape shape7 = null;
        renderAttributes0.setSeriesShape((int) (byte) 1, shape7);
        renderAttributes0.setDefaultCreateEntity((java.lang.Boolean) true);
        java.awt.Paint paint11 = renderAttributes0.getDefaultPaint();
        java.awt.Color color12 = java.awt.Color.yellow;
        java.awt.color.ColorSpace colorSpace13 = color12.getColorSpace();
        float[] floatArray17 = new float[] { (byte) 1, '#', 15 };
        float[] floatArray18 = color12.getRGBColorComponents(floatArray17);
        renderAttributes0.setDefaultLabelPaint((java.awt.Paint) color12);
        try {
            renderAttributes0.setSeriesCreateEntity((-256), (java.lang.Boolean) false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNull(shape5);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(colorSpace13);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        renderAttributes0.setDefaultFillPaint((java.awt.Paint) color1);
        java.awt.Shape shape5 = renderAttributes0.getItemShape((int) (byte) 100, (int) 'a');
        java.awt.Shape shape7 = null;
        renderAttributes0.setSeriesShape((int) (byte) 1, shape7);
        renderAttributes0.setDefaultCreateEntity((java.lang.Boolean) true);
        java.awt.Paint paint11 = renderAttributes0.getDefaultPaint();
        java.awt.Color color12 = java.awt.Color.yellow;
        java.awt.color.ColorSpace colorSpace13 = color12.getColorSpace();
        float[] floatArray17 = new float[] { (byte) 1, '#', 15 };
        float[] floatArray18 = color12.getRGBColorComponents(floatArray17);
        renderAttributes0.setDefaultLabelPaint((java.awt.Paint) color12);
        java.awt.Paint paint21 = renderAttributes0.getSeriesOutlinePaint(128);
        boolean boolean22 = renderAttributes0.getAllowNull();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNull(shape5);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(colorSpace13);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        java.awt.Shape shape4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        int int9 = categoryPlot5.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot5.getRowRenderingOrder();
        java.awt.Stroke stroke11 = categoryPlot5.getRangeZeroBaselineStroke();
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("", "", "hi!", "", shape4, stroke11, paint12);
        legendItem13.setDescription("");
        int int16 = legendItem13.getDatasetIndex();
        java.lang.String str17 = legendItem13.getLabel();
        java.lang.String str18 = legendItem13.getLabel();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset19 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo20 = new org.jfree.chart.event.DatasetChangeInfo();
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent21 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object) legendItem13, (org.jfree.data.general.Dataset) defaultCategoryDataset19, datasetChangeInfo20);
        org.jfree.data.general.Dataset dataset22 = datasetChangeEvent21.getDataset();
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertNotNull(dataset22);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        org.jfree.chart.LegendItemCollection legendItemCollection4 = lineAndShapeRenderer2.getLegendItems();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        int int9 = categoryPlot5.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot5.getRowRenderingOrder();
        java.awt.Stroke stroke11 = categoryPlot5.getRangeZeroBaselineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        categoryPlot5.rendererChanged(rendererChangeEvent12);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot14.setRangeAxisLocation(axisLocation15, true);
        categoryPlot5.setDomainAxisLocation(axisLocation15);
        categoryPlot5.setCrosshairDatasetIndex((int) (short) 1);
        org.jfree.data.category.CategoryDataset categoryDataset21 = categoryPlot5.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = categoryPlot5.getAxisOffset();
        double double24 = rectangleInsets22.calculateRightInset((double) (-1L));
        boolean boolean25 = legendItemCollection4.equals((java.lang.Object) (-1L));
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(legendItemCollection4);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNull(categoryDataset21);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 4.0d + "'", double24 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        java.awt.Color color0 = java.awt.Color.magenta;
        int int1 = color0.getRed();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape0, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape4 = chartEntity3.getArea();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier9 = categoryPlot5.getDrawingSupplier();
        org.jfree.data.category.CategoryDataset categoryDataset10 = categoryPlot5.getDataset();
        org.jfree.chart.renderer.RenderAttributes renderAttributes11 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        renderAttributes11.setDefaultFillPaint((java.awt.Paint) color12);
        categoryPlot5.setBackgroundPaint((java.awt.Paint) color12);
        org.jfree.chart.axis.ValueAxis valueAxis15 = categoryPlot5.getRangeAxis();
        org.jfree.chart.entity.PlotEntity plotEntity18 = new org.jfree.chart.entity.PlotEntity(shape4, (org.jfree.chart.plot.Plot) categoryPlot5, "ChartChangeEventType.GENERAL", "hi!");
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot20.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis23 = categoryPlot20.getRangeAxis();
        int int24 = categoryPlot20.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder25 = categoryPlot20.getRowRenderingOrder();
        java.awt.Stroke stroke26 = categoryPlot20.getRangeZeroBaselineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = categoryPlot20.getInsets();
        org.jfree.chart.axis.AxisLocation axisLocation28 = categoryPlot20.getRangeAxisLocation();
        try {
            categoryPlot5.setRangeAxisLocation((int) (byte) -1, axisLocation28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertNotNull(drawingSupplier9);
        org.junit.Assert.assertNull(categoryDataset10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNull(valueAxis15);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 15 + "'", int24 == 15);
        org.junit.Assert.assertNotNull(sortOrder25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(axisLocation28);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        org.jfree.chart.LegendItemCollection legendItemCollection4 = lineAndShapeRenderer2.getLegendItems();
        java.lang.Object obj5 = legendItemCollection4.clone();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(legendItemCollection4);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        lineAndShapeRenderer2.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator7);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = lineAndShapeRenderer2.getSeriesPositiveItemLabelPosition(0);
        lineAndShapeRenderer2.setBaseShapesFilled(false);
        lineAndShapeRenderer2.setSeriesShapesVisible(2, (java.lang.Boolean) true);
        int int16 = lineAndShapeRenderer2.getDefaultEntityRadius();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 3 + "'", int16 == 3);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier4 = categoryPlot0.getDrawingSupplier();
        java.awt.Stroke stroke5 = categoryPlot0.getOutlineStroke();
        org.jfree.chart.plot.Plot plot6 = categoryPlot0.getParent();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor7 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE10;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis11 = categoryPlot8.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot8.zoomDomainAxes((double) 10.0f, plotRenderingInfo13, point2D14, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor17 = categoryPlot8.getDomainGridlinePosition();
        boolean boolean18 = itemLabelAnchor7.equals((java.lang.Object) categoryAnchor17);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot19.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis22 = categoryPlot19.getRangeAxis();
        int int23 = categoryPlot19.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder24 = categoryPlot19.getRowRenderingOrder();
        categoryPlot19.setWeight((int) (short) 100);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder27 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        categoryPlot19.setDatasetRenderingOrder(datasetRenderingOrder27);
        boolean boolean29 = categoryAnchor17.equals((java.lang.Object) categoryPlot19);
        boolean boolean30 = categoryPlot19.isDomainZoomable();
        java.awt.Paint paint31 = categoryPlot19.getNoDataMessagePaint();
        categoryPlot0.setBackgroundPaint(paint31);
        try {
            categoryPlot0.setBackgroundImageAlpha((float) 15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(drawingSupplier4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNull(plot6);
        org.junit.Assert.assertNotNull(itemLabelAnchor7);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertNotNull(categoryAnchor17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(valueAxis22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 15 + "'", int23 == 15);
        org.junit.Assert.assertNotNull(sortOrder24);
        org.junit.Assert.assertNotNull(datasetRenderingOrder27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(paint31);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor9 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis13 = categoryPlot10.getRangeAxis();
        int int14 = categoryPlot10.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder15 = categoryPlot10.getRowRenderingOrder();
        java.awt.Stroke stroke16 = categoryPlot10.getRangeZeroBaselineStroke();
        categoryPlot0.setRangeMinorGridlineStroke(stroke16);
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = categoryPlot0.getDomainAxis(100);
        boolean boolean20 = categoryPlot0.isNotify();
        categoryPlot0.clearAnnotations();
        java.awt.Stroke stroke22 = null;
        try {
            categoryPlot0.setRangeZeroBaselineStroke(stroke22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(categoryAnchor9);
        org.junit.Assert.assertNull(valueAxis13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 15 + "'", int14 == 15);
        org.junit.Assert.assertNotNull(sortOrder15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNull(categoryAxis19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean4 = lineAndShapeRenderer0.isItemLabelVisible((int) (short) 0, (int) (short) 0, true);
        try {
            lineAndShapeRenderer0.setSeriesVisible((-256), (java.lang.Boolean) false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        java.awt.Shape shape4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        int int9 = categoryPlot5.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot5.getRowRenderingOrder();
        java.awt.Stroke stroke11 = categoryPlot5.getRangeZeroBaselineStroke();
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("", "", "hi!", "", shape4, stroke11, paint12);
        legendItem13.setDescription("");
        int int16 = legendItem13.getDatasetIndex();
        java.lang.String str17 = legendItem13.getLabel();
        java.awt.Paint paint18 = legendItem13.getOutlinePaint();
        int int19 = legendItem13.getSeriesIndex();
        java.awt.Paint paint20 = legendItem13.getFillPaint();
        boolean boolean21 = legendItem13.isShapeFilled();
        java.awt.Paint paint22 = legendItem13.getFillPaint();
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        java.awt.Shape shape4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        int int9 = categoryPlot5.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot5.getRowRenderingOrder();
        java.awt.Stroke stroke11 = categoryPlot5.getRangeZeroBaselineStroke();
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("", "", "hi!", "", shape4, stroke11, paint12);
        legendItem13.setDescription("");
        int int16 = legendItem13.getDatasetIndex();
        java.lang.String str17 = legendItem13.getLabel();
        java.awt.Paint paint18 = legendItem13.getOutlinePaint();
        int int19 = legendItem13.getSeriesIndex();
        java.awt.Paint paint20 = legendItem13.getFillPaint();
        boolean boolean21 = legendItem13.isShapeFilled();
        legendItem13.setDescription("AxisLocation.BOTTOM_OR_LEFT");
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        double double2 = categoryAxis1.getLabelAngle();
        java.awt.Color color3 = java.awt.Color.pink;
        categoryAxis1.setLabelPaint((java.awt.Paint) color3);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        try {
            java.awt.Color color1 = java.awt.Color.decode("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Zero length string");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        java.awt.Shape shape4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        int int9 = categoryPlot5.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot5.getRowRenderingOrder();
        java.awt.Stroke stroke11 = categoryPlot5.getRangeZeroBaselineStroke();
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("", "", "hi!", "", shape4, stroke11, paint12);
        legendItem13.setSeriesIndex((int) (byte) 10);
        java.awt.Shape shape16 = legendItem13.getShape();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke20 = lineAndShapeRenderer19.getBaseStroke();
        java.awt.Paint paint22 = lineAndShapeRenderer19.getSeriesPaint(15);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition24 = lineAndShapeRenderer19.getSeriesNegativeItemLabelPosition(255);
        int int25 = lineAndShapeRenderer19.getDefaultEntityRadius();
        java.awt.Stroke stroke26 = lineAndShapeRenderer19.getBaseOutlineStroke();
        java.awt.Shape shape28 = lineAndShapeRenderer19.getSeriesShape(15);
        java.awt.Shape shape30 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity33 = new org.jfree.chart.entity.ChartEntity(shape30, "ChartChangeEventType.GENERAL", "");
        lineAndShapeRenderer19.setSeriesShape(3, shape30);
        legendItem13.setShape(shape30);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNull(paint22);
        org.junit.Assert.assertNotNull(itemLabelPosition24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 3 + "'", int25 == 3);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNull(shape28);
        org.junit.Assert.assertNotNull(shape30);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Paint paint6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        lineAndShapeRenderer2.setBaseOutlinePaint(paint6);
        java.awt.Font font8 = lineAndShapeRenderer2.getBaseItemLabelFont();
        java.awt.Paint paint9 = lineAndShapeRenderer2.getBaseFillPaint();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer12 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke13 = lineAndShapeRenderer12.getBaseStroke();
        java.awt.Paint paint15 = lineAndShapeRenderer12.getSeriesPaint(15);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = lineAndShapeRenderer12.getSeriesNegativeItemLabelPosition(255);
        lineAndShapeRenderer2.setBasePositiveItemLabelPosition(itemLabelPosition17, true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNull(paint15);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Shape shape9 = lineAndShapeRenderer2.getItemShape((int) (short) 10, 100, true);
        java.awt.Paint paint11 = lineAndShapeRenderer2.getSeriesFillPaint((int) (short) 10);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator12 = null;
        lineAndShapeRenderer2.setBaseURLGenerator(categoryURLGenerator12);
        boolean boolean16 = lineAndShapeRenderer2.getItemShapeFilled((int) 'a', 2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator18 = lineAndShapeRenderer2.getSeriesURLGenerator(64);
        boolean boolean20 = lineAndShapeRenderer2.isSeriesVisibleInLegend(15);
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot22.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis25 = categoryPlot22.getRangeAxis();
        categoryPlot22.clearDomainMarkers();
        org.jfree.chart.axis.AxisSpace axisSpace27 = null;
        categoryPlot22.setFixedDomainAxisSpace(axisSpace27, true);
        org.jfree.chart.plot.Marker marker30 = null;
        boolean boolean31 = categoryPlot22.removeDomainMarker(marker30);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        java.awt.geom.Point2D point2D34 = null;
        categoryPlot22.zoomRangeAxes((double) (-16728064), plotRenderingInfo33, point2D34);
        org.jfree.chart.axis.AxisSpace axisSpace36 = null;
        categoryPlot22.setFixedDomainAxisSpace(axisSpace36);
        int int38 = categoryPlot22.getRangeAxisCount();
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        try {
            lineAndShapeRenderer2.drawBackground(graphics2D21, categoryPlot22, rectangle2D39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNull(categoryURLGenerator18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNull(valueAxis25);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        categoryPlot0.setDomainCrosshairColumnKey((java.lang.Comparable) (short) -1, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot0.zoomRangeAxes((double) (byte) 1, plotRenderingInfo9, point2D10, true);
        java.awt.Stroke stroke13 = categoryPlot0.getOutlineStroke();
        org.jfree.chart.plot.Marker marker14 = null;
        org.jfree.chart.util.Layer layer15 = null;
        boolean boolean16 = categoryPlot0.removeDomainMarker(marker14, layer15);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        java.awt.Shape shape4 = null;
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem6 = new org.jfree.chart.LegendItem("", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", shape4, (java.awt.Paint) color5);
        java.awt.Shape shape11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot12.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis15 = categoryPlot12.getRangeAxis();
        int int16 = categoryPlot12.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder17 = categoryPlot12.getRowRenderingOrder();
        java.awt.Stroke stroke18 = categoryPlot12.getRangeZeroBaselineStroke();
        java.awt.Paint paint19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("", "", "hi!", "", shape11, stroke18, paint19);
        legendItem20.setDescription("");
        int int23 = legendItem20.getDatasetIndex();
        java.lang.String str24 = legendItem20.getLabel();
        java.lang.String str25 = legendItem20.getLabel();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer26 = legendItem20.getFillPaintTransformer();
        legendItem6.setFillPaintTransformer(gradientPaintTransformer26);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(valueAxis15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 15 + "'", int16 == 15);
        org.junit.Assert.assertNotNull(sortOrder17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
        org.junit.Assert.assertNotNull(gradientPaintTransformer26);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        java.awt.Shape shape4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        int int9 = categoryPlot5.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot5.getRowRenderingOrder();
        java.awt.Stroke stroke11 = categoryPlot5.getRangeZeroBaselineStroke();
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("", "", "hi!", "", shape4, stroke11, paint12);
        legendItem13.setDescription("");
        int int16 = legendItem13.getDatasetIndex();
        java.lang.String str17 = legendItem13.getLabel();
        java.lang.String str18 = legendItem13.getLabel();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset19 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo20 = new org.jfree.chart.event.DatasetChangeInfo();
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent21 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object) legendItem13, (org.jfree.data.general.Dataset) defaultCategoryDataset19, datasetChangeInfo20);
        defaultCategoryDataset19.clearSelection();
        int int23 = defaultCategoryDataset19.getRowCount();
        int int25 = defaultCategoryDataset19.getColumnIndex((java.lang.Comparable) "AxisLocation.BOTTOM_OR_LEFT");
        try {
            boolean boolean28 = defaultCategoryDataset19.isSelected(64, (-128));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 64, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        java.lang.Comparable comparable9 = categoryPlot0.getDomainCrosshairColumnKey();
        boolean boolean10 = categoryPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = categoryPlot0.getAxisOffset();
        org.jfree.chart.axis.ValueAxis valueAxis12 = categoryPlot0.getRangeAxis();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNull(comparable9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNull(valueAxis12);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_HORIZONTAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
        java.awt.GradientPaint gradientPaint2 = null;
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape3, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape7 = chartEntity6.getArea();
        try {
            java.awt.GradientPaint gradientPaint8 = standardGradientPaintTransformer1.transform(gradientPaint2, shape7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(shape7);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("java.awt.Color[r=0,g=0,b=0]");
        java.lang.String str2 = datasetGroup1.getID();
        java.lang.Object obj3 = datasetGroup1.clone();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "java.awt.Color[r=0,g=0,b=0]" + "'", str2.equals("java.awt.Color[r=0,g=0,b=0]"));
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = categoryAxis1.getTickLabelInsets();
        categoryAxis1.setCategoryLabelPositionOffset(0);
        categoryAxis1.setMinorTickMarksVisible(false);
        float float7 = categoryAxis1.getMinorTickMarkOutsideLength();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = categoryAxis1.getLabelInsets();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis1.setTickMarkPaint((java.awt.Paint) color9);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot15.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = categoryPlot15.getDomainAxisEdge();
        org.jfree.chart.axis.AxisLocation axisLocation19 = categoryPlot15.getDomainAxisLocation();
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = categoryPlot15.getDomainAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        try {
            org.jfree.chart.axis.AxisState axisState22 = categoryAxis1.draw(graphics2D11, 0.0d, rectangle2D13, rectangle2D14, rectangleEdge20, plotRenderingInfo21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 2.0f + "'", float7 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNotNull(rectangleEdge20);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Shape shape9 = lineAndShapeRenderer2.getItemShape((int) (short) 10, 100, true);
        java.awt.Paint paint11 = lineAndShapeRenderer2.getSeriesFillPaint((int) (short) 10);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator12 = null;
        lineAndShapeRenderer2.setBaseURLGenerator(categoryURLGenerator12);
        boolean boolean16 = lineAndShapeRenderer2.getItemShapeFilled((int) 'a', 2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator18 = lineAndShapeRenderer2.getSeriesURLGenerator(64);
        boolean boolean20 = lineAndShapeRenderer2.isSeriesVisibleInLegend(15);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator21 = null;
        lineAndShapeRenderer2.setBaseItemLabelGenerator(categoryItemLabelGenerator21, false);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNull(categoryURLGenerator18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Shape shape9 = lineAndShapeRenderer2.getItemShape((int) (short) 10, 100, true);
        lineAndShapeRenderer2.setBaseSeriesVisible(false);
        java.awt.Shape shape12 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity15 = new org.jfree.chart.entity.ChartEntity(shape12, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape16 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity19 = new org.jfree.chart.entity.ChartEntity(shape16, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape20 = chartEntity19.getArea();
        chartEntity15.setArea(shape20);
        lineAndShapeRenderer2.setBaseShape(shape20, true);
        lineAndShapeRenderer2.clearSeriesPaints(false);
        java.awt.Graphics2D graphics2D26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        double double30 = categoryAxis29.getLabelAngle();
        categoryAxis29.setTickLabelsVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.util.Layer layer34 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        try {
            lineAndShapeRenderer2.drawAnnotations(graphics2D26, rectangle2D27, categoryAxis29, valueAxis33, layer34, plotRenderingInfo35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Paint paint6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        lineAndShapeRenderer2.setBaseOutlinePaint(paint6);
        org.jfree.chart.renderer.RenderAttributes renderAttributes9 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        renderAttributes9.setDefaultFillPaint((java.awt.Paint) color10);
        java.awt.Stroke stroke13 = renderAttributes9.getSeriesStroke((int) ' ');
        java.awt.Shape shape15 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity18 = new org.jfree.chart.entity.ChartEntity(shape15, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape19 = chartEntity18.getArea();
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot20.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis23 = categoryPlot20.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        categoryPlot20.zoomDomainAxes((double) 10.0f, plotRenderingInfo25, point2D26, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor29 = categoryPlot20.getDomainGridlinePosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot30.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis33 = categoryPlot30.getRangeAxis();
        int int34 = categoryPlot30.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder35 = categoryPlot30.getRowRenderingOrder();
        java.awt.Stroke stroke36 = categoryPlot30.getRangeZeroBaselineStroke();
        categoryPlot20.setRangeMinorGridlineStroke(stroke36);
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = categoryPlot20.getDomainAxis(100);
        boolean boolean40 = categoryPlot20.isNotify();
        org.jfree.chart.entity.PlotEntity plotEntity42 = new org.jfree.chart.entity.PlotEntity(shape19, (org.jfree.chart.plot.Plot) categoryPlot20, "ItemLabelAnchor.OUTSIDE1");
        renderAttributes9.setSeriesShape((int) (byte) 100, shape19);
        lineAndShapeRenderer2.setSeriesShape(128, shape19, false);
        java.lang.Boolean boolean47 = lineAndShapeRenderer2.getSeriesShapesVisible(100);
        lineAndShapeRenderer2.setBaseSeriesVisibleInLegend(false, true);
        java.awt.Stroke stroke51 = lineAndShapeRenderer2.getBaseStroke();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNull(stroke13);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(categoryAnchor29);
        org.junit.Assert.assertNull(valueAxis33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 15 + "'", int34 == 15);
        org.junit.Assert.assertNotNull(sortOrder35);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNull(categoryAxis39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNull(boolean47);
        org.junit.Assert.assertNotNull(stroke51);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Shape shape9 = lineAndShapeRenderer2.getItemShape((int) (short) 10, 100, true);
        lineAndShapeRenderer2.setBaseCreateEntities(true);
        lineAndShapeRenderer2.setAutoPopulateSeriesOutlinePaint(false);
        boolean boolean17 = lineAndShapeRenderer2.isItemLabelVisible((int) '4', (int) (byte) -1, true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent9 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot0);
        org.jfree.chart.plot.Marker marker10 = null;
        org.jfree.chart.util.Layer layer11 = null;
        boolean boolean12 = categoryPlot0.removeDomainMarker(marker10, layer11);
        org.jfree.chart.plot.Marker marker14 = null;
        org.jfree.chart.util.Layer layer15 = null;
        try {
            boolean boolean17 = categoryPlot0.removeRangeMarker((int) (byte) 0, marker14, layer15, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape0, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape4 = chartEntity3.getArea();
        java.awt.Shape shape5 = chartEntity3.getArea();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot6.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = categoryPlot6.getDomainAxisEdge();
        int int10 = categoryPlot6.getWeight();
        java.lang.Comparable comparable11 = categoryPlot6.getDomainCrosshairColumnKey();
        boolean boolean12 = categoryPlot6.canSelectByRegion();
        org.jfree.chart.axis.AxisLocation axisLocation13 = categoryPlot6.getRangeAxisLocation();
        org.jfree.chart.entity.PlotEntity plotEntity16 = new org.jfree.chart.entity.PlotEntity(shape5, (org.jfree.chart.plot.Plot) categoryPlot6, "ItemLabelAnchor.OUTSIDE1", "java.awt.Color[r=0,g=0,b=0]");
        java.lang.String str17 = plotEntity16.getShapeType();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNull(comparable11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "rect" + "'", str17.equals("rect"));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Paint paint5 = lineAndShapeRenderer2.getSeriesPaint(15);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = lineAndShapeRenderer2.getSeriesNegativeItemLabelPosition(255);
        int int8 = lineAndShapeRenderer2.getDefaultEntityRadius();
        java.awt.Stroke stroke9 = lineAndShapeRenderer2.getBaseOutlineStroke();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator11 = lineAndShapeRenderer2.getSeriesToolTipGenerator(128);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.util.Layer layer16 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        try {
            lineAndShapeRenderer2.drawAnnotations(graphics2D12, rectangle2D13, categoryAxis14, valueAxis15, layer16, plotRenderingInfo17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNull(categoryToolTipGenerator11);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        categoryPlot0.setDomainCrosshairColumnKey((java.lang.Comparable) (short) -1, true);
        org.jfree.chart.util.Layer layer9 = null;
        java.util.Collection collection10 = categoryPlot0.getRangeMarkers((int) (short) 0, layer9);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot11.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis14 = categoryPlot11.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        categoryPlot11.zoomDomainAxes((double) 10.0f, plotRenderingInfo16, point2D17, false);
        java.lang.Comparable comparable20 = categoryPlot11.getDomainCrosshairColumnKey();
        boolean boolean21 = categoryPlot11.isRangeCrosshairLockedOnData();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = categoryPlot11.getAxisOffset();
        double double23 = rectangleInsets22.getLeft();
        categoryPlot0.setAxisOffset(rectangleInsets22);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = null;
        try {
            categoryPlot0.setAxisOffset(rectangleInsets25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'offset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNull(collection10);
        org.junit.Assert.assertNull(valueAxis14);
        org.junit.Assert.assertNull(comparable20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 4.0d + "'", double23 == 4.0d);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        categoryPlot0.setDomainCrosshairColumnKey((java.lang.Comparable) (short) -1, true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer8.clearSeriesStrokes(true);
        lineAndShapeRenderer8.setAutoPopulateSeriesFillPaint(true);
        java.awt.Stroke stroke13 = lineAndShapeRenderer8.getBaseOutlineStroke();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer16 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke17 = lineAndShapeRenderer16.getBaseStroke();
        java.awt.Paint paint19 = lineAndShapeRenderer16.getSeriesPaint(15);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition21 = lineAndShapeRenderer16.getSeriesNegativeItemLabelPosition(255);
        java.awt.Font font22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        lineAndShapeRenderer16.setBaseLegendTextFont(font22);
        lineAndShapeRenderer8.setBaseItemLabelFont(font22);
        categoryPlot0.setNoDataMessageFont(font22);
        categoryPlot0.setRangeCrosshairLockedOnData(true);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNull(paint19);
        org.junit.Assert.assertNotNull(itemLabelPosition21);
        org.junit.Assert.assertNotNull(font22);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = categoryAxis3.getTickLabelInsets();
        categoryAxis3.setCategoryLabelPositionOffset(0);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions7 = categoryAxis3.getCategoryLabelPositions();
        categoryAxis1.setCategoryLabelPositions(categoryLabelPositions7);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot9.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis12 = categoryPlot9.getRangeAxis();
        int int13 = categoryPlot9.getBackgroundImageAlignment();
        categoryPlot9.setDomainCrosshairColumnKey((java.lang.Comparable) (short) -1, true);
        org.jfree.chart.util.Layer layer18 = null;
        java.util.Collection collection19 = categoryPlot9.getRangeMarkers((int) (short) 0, layer18);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot20.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis23 = categoryPlot20.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        categoryPlot20.zoomDomainAxes((double) 10.0f, plotRenderingInfo25, point2D26, false);
        java.lang.Comparable comparable29 = categoryPlot20.getDomainCrosshairColumnKey();
        boolean boolean30 = categoryPlot20.isRangeCrosshairLockedOnData();
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = categoryPlot20.getAxisOffset();
        double double32 = rectangleInsets31.getLeft();
        categoryPlot9.setAxisOffset(rectangleInsets31);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        categoryPlot9.setRenderer(0, categoryItemRenderer35);
        java.awt.Color color37 = java.awt.Color.yellow;
        java.awt.color.ColorSpace colorSpace38 = color37.getColorSpace();
        categoryPlot9.setRangeCrosshairPaint((java.awt.Paint) color37);
        categoryAxis1.setTickLabelPaint((java.awt.Paint) color37);
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot44.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = categoryPlot44.getDomainAxisEdge();
        org.jfree.chart.axis.AxisLocation axisLocation48 = categoryPlot44.getDomainAxisLocation();
        org.jfree.chart.util.RectangleEdge rectangleEdge49 = categoryPlot44.getDomainAxisEdge();
        try {
            double double50 = categoryAxis1.getCategoryMiddle((int) (short) 1, (int) '4', rectangle2D43, rectangleEdge49);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(categoryLabelPositions7);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 15 + "'", int13 == 15);
        org.junit.Assert.assertNull(collection19);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNull(comparable29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 4.0d + "'", double32 == 4.0d);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(colorSpace38);
        org.junit.Assert.assertNotNull(rectangleEdge47);
        org.junit.Assert.assertNotNull(axisLocation48);
        org.junit.Assert.assertNotNull(rectangleEdge49);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        lineAndShapeRenderer2.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator7);
        lineAndShapeRenderer2.setSeriesVisible((int) (short) 100, (java.lang.Boolean) false, true);
        boolean boolean15 = lineAndShapeRenderer2.getItemShapeVisible((int) (short) 10, 3);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator16 = lineAndShapeRenderer2.getLegendItemLabelGenerator();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = lineAndShapeRenderer2.getSeriesPositiveItemLabelPosition((int) (short) -1);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor19 = itemLabelPosition18.getItemLabelAnchor();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator16);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNotNull(itemLabelAnchor19);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder5 = categoryPlot0.getRowRenderingOrder();
        java.awt.Stroke stroke6 = categoryPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent7 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent7);
        categoryPlot0.setRangeZeroBaselineVisible(false);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(sortOrder5);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        java.awt.Color color0 = java.awt.Color.GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor9 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis13 = categoryPlot10.getRangeAxis();
        int int14 = categoryPlot10.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder15 = categoryPlot10.getRowRenderingOrder();
        categoryPlot0.setRowRenderingOrder(sortOrder15);
        categoryPlot0.mapDatasetToDomainAxis(2, 10);
        categoryPlot0.setNotify(false);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(categoryAnchor9);
        org.junit.Assert.assertNull(valueAxis13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 15 + "'", int14 == 15);
        org.junit.Assert.assertNotNull(sortOrder15);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.clearSeriesStrokes(true);
        lineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.renderer.RenderAttributes renderAttributes7 = new org.jfree.chart.renderer.RenderAttributes(true);
        java.awt.Color color9 = java.awt.Color.magenta;
        renderAttributes7.setSeriesOutlinePaint(128, (java.awt.Paint) color9);
        lineAndShapeRenderer0.setSeriesItemLabelPaint((int) (short) 1, (java.awt.Paint) color9);
        lineAndShapeRenderer0.setAutoPopulateSeriesOutlineStroke(true);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape0, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape4 = chartEntity3.getArea();
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape4);
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot7.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis10 = categoryPlot7.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot7.zoomDomainAxes((double) 10.0f, plotRenderingInfo12, point2D13, false);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent16 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot7);
        org.jfree.chart.JFreeChart jFreeChart17 = null;
        plotChangeEvent16.setChart(jFreeChart17);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType19 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        plotChangeEvent16.setType(chartChangeEventType19);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent21 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) chartEntity5, jFreeChart6, chartChangeEventType19);
        java.awt.Shape shape22 = chartEntity5.getArea();
        java.lang.String str23 = chartEntity5.getShapeType();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertNotNull(chartChangeEventType19);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "rect" + "'", str23.equals("rect"));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent9 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot0);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer12 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke13 = lineAndShapeRenderer12.getBaseStroke();
        categoryPlot0.setRangeMinorGridlineStroke(stroke13);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor15 = org.jfree.chart.axis.CategoryAnchor.START;
        categoryPlot0.setDomainGridlinePosition(categoryAnchor15);
        org.jfree.chart.plot.Plot plot17 = categoryPlot0.getRootPlot();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(categoryAnchor15);
        org.junit.Assert.assertNotNull(plot17);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset0 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.category.CategoryDatasetSelectionState categoryDatasetSelectionState1 = null;
        abstractCategoryDataset0.setSelectionState(categoryDatasetSelectionState1);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot3.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot3.zoomDomainAxes((double) 10.0f, plotRenderingInfo8, point2D9, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor12 = categoryPlot3.getDomainGridlinePosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot13.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis16 = categoryPlot13.getRangeAxis();
        int int17 = categoryPlot13.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder18 = categoryPlot13.getRowRenderingOrder();
        java.awt.Stroke stroke19 = categoryPlot13.getRangeZeroBaselineStroke();
        categoryPlot3.setRangeMinorGridlineStroke(stroke19);
        org.jfree.chart.axis.ValueAxis valueAxis22 = categoryPlot3.getRangeAxis(1);
        boolean boolean23 = abstractCategoryDataset0.hasListener((java.util.EventListener) categoryPlot3);
        org.jfree.data.category.CategoryDatasetSelectionState categoryDatasetSelectionState24 = abstractCategoryDataset0.getSelectionState();
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(categoryAnchor12);
        org.junit.Assert.assertNull(valueAxis16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 15 + "'", int17 == 15);
        org.junit.Assert.assertNotNull(sortOrder18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(valueAxis22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(categoryDatasetSelectionState24);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairLockedOnData(false);
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) (short) 10);
        categoryPlot0.setAnchorValue((double) (short) 10, false);
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace8);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        categoryPlot0.markerChanged(markerChangeEvent10);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke15 = lineAndShapeRenderer14.getBaseStroke();
        java.awt.Stroke stroke17 = lineAndShapeRenderer14.lookupSeriesStroke(10);
        java.awt.Shape shape23 = null;
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", shape23, (java.awt.Paint) color24);
        int int26 = color24.getBlue();
        lineAndShapeRenderer14.setSeriesItemLabelPaint((int) (byte) 1, (java.awt.Paint) color24);
        int int28 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer14);
        boolean boolean29 = lineAndShapeRenderer14.getBaseCreateEntities();
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 128 + "'", int26 == 128);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = categoryAxis1.getTickLabelInsets();
        categoryAxis1.setCategoryLabelPositionOffset(0);
        categoryAxis1.setMinorTickMarksVisible(false);
        float float7 = categoryAxis1.getMinorTickMarkOutsideLength();
        boolean boolean8 = categoryAxis1.isVisible();
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean13 = categoryPlot12.isRangeGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = categoryPlot12.getRangeAxisEdge((int) (byte) -1);
        org.jfree.chart.axis.AxisState axisState16 = null;
        categoryAxis1.drawTickMarks(graphics2D9, (double) 1L, rectangle2D11, rectangleEdge15, axisState16);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor18 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE10;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot19.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis22 = categoryPlot19.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        java.awt.geom.Point2D point2D25 = null;
        categoryPlot19.zoomDomainAxes((double) 10.0f, plotRenderingInfo24, point2D25, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor28 = categoryPlot19.getDomainGridlinePosition();
        boolean boolean29 = itemLabelAnchor18.equals((java.lang.Object) categoryAnchor28);
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot30.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis33 = categoryPlot30.getRangeAxis();
        int int34 = categoryPlot30.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder35 = categoryPlot30.getRowRenderingOrder();
        categoryPlot30.setWeight((int) (short) 100);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder38 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        categoryPlot30.setDatasetRenderingOrder(datasetRenderingOrder38);
        boolean boolean40 = categoryAnchor28.equals((java.lang.Object) categoryPlot30);
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot44.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = categoryPlot44.getDomainAxisEdge();
        org.jfree.chart.axis.AxisLocation axisLocation48 = categoryPlot44.getDomainAxisLocation();
        org.jfree.chart.util.RectangleEdge rectangleEdge49 = categoryPlot44.getDomainAxisEdge();
        try {
            double double50 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor28, 0, (int) (short) 100, rectangle2D43, rectangleEdge49);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 2.0f + "'", float7 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(itemLabelAnchor18);
        org.junit.Assert.assertNull(valueAxis22);
        org.junit.Assert.assertNotNull(categoryAnchor28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNull(valueAxis33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 15 + "'", int34 == 15);
        org.junit.Assert.assertNotNull(sortOrder35);
        org.junit.Assert.assertNotNull(datasetRenderingOrder38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(rectangleEdge47);
        org.junit.Assert.assertNotNull(axisLocation48);
        org.junit.Assert.assertNotNull(rectangleEdge49);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        java.awt.Shape shape4 = null;
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem6 = new org.jfree.chart.LegendItem("", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", shape4, (java.awt.Paint) color5);
        java.awt.Shape shape7 = legendItem6.getShape();
        java.awt.Paint paint8 = legendItem6.getLinePaint();
        java.awt.Paint paint9 = legendItem6.getLinePaint();
        java.lang.Object obj10 = legendItem6.clone();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(shape7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE7;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.clear();
        try {
            defaultCategoryDataset0.setSelected((-256), (-128), false);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -256");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape0, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape4 = chartEntity3.getArea();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot5.zoomDomainAxes((double) 10.0f, plotRenderingInfo10, point2D11, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor14 = categoryPlot5.getDomainGridlinePosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot15.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis18 = categoryPlot15.getRangeAxis();
        int int19 = categoryPlot15.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder20 = categoryPlot15.getRowRenderingOrder();
        java.awt.Stroke stroke21 = categoryPlot15.getRangeZeroBaselineStroke();
        categoryPlot5.setRangeMinorGridlineStroke(stroke21);
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = categoryPlot5.getDomainAxis(100);
        boolean boolean25 = categoryPlot5.isNotify();
        org.jfree.chart.entity.PlotEntity plotEntity27 = new org.jfree.chart.entity.PlotEntity(shape4, (org.jfree.chart.plot.Plot) categoryPlot5, "ItemLabelAnchor.OUTSIDE1");
        java.lang.String str28 = plotEntity27.toString();
        java.awt.Shape shape29 = plotEntity27.getArea();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertNotNull(categoryAnchor14);
        org.junit.Assert.assertNull(valueAxis18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 15 + "'", int19 == 15);
        org.junit.Assert.assertNotNull(sortOrder20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNull(categoryAxis24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "PlotEntity: tooltip = ItemLabelAnchor.OUTSIDE1" + "'", str28.equals("PlotEntity: tooltip = ItemLabelAnchor.OUTSIDE1"));
        org.junit.Assert.assertNotNull(shape29);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        int int2 = keyedObjects0.getIndex((java.lang.Comparable) (short) 100);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot3.getDomainAxisEdge();
        int int7 = categoryPlot3.getWeight();
        java.lang.Comparable comparable8 = categoryPlot3.getDomainCrosshairColumnKey();
        boolean boolean9 = categoryPlot3.canSelectByRegion();
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot3.getRangeAxisLocation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot3.zoomDomainAxes((double) (short) 100, plotRenderingInfo12, point2D13, false);
        boolean boolean16 = keyedObjects0.equals((java.lang.Object) false);
        java.lang.Comparable comparable17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean19 = categoryPlot18.isRangeGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = categoryPlot18.getRangeAxisEdge((int) (byte) -1);
        boolean boolean22 = categoryPlot18.canSelectByRegion();
        java.awt.Color color26 = java.awt.Color.getHSBColor((float) (short) 1, (float) 100, 0.0f);
        float[] floatArray33 = new float[] { (byte) 10, (byte) 1, 1.0f, (byte) 0, 10, (byte) 100 };
        float[] floatArray34 = color26.getRGBComponents(floatArray33);
        java.lang.String str35 = color26.toString();
        categoryPlot18.setRangeCrosshairPaint((java.awt.Paint) color26);
        try {
            keyedObjects0.setObject(comparable17, (java.lang.Object) color26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNull(comparable8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertNotNull(floatArray34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "java.awt.Color[r=0,g=0,b=0]" + "'", str35.equals("java.awt.Color[r=0,g=0,b=0]"));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = categoryAxis1.getTickLabelInsets();
        categoryAxis1.setCategoryLabelPositionOffset(0);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        int int9 = categoryPlot5.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot5.getRowRenderingOrder();
        java.awt.Stroke stroke11 = categoryPlot5.getRangeZeroBaselineStroke();
        int int12 = categoryPlot5.getCrosshairDatasetIndex();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke16 = lineAndShapeRenderer15.getBaseStroke();
        java.awt.Stroke stroke18 = lineAndShapeRenderer15.lookupSeriesStroke(10);
        lineAndShapeRenderer15.setAutoPopulateSeriesStroke(true);
        categoryPlot5.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer15, true);
        categoryAxis1.setPlot((org.jfree.chart.plot.Plot) categoryPlot5);
        java.lang.Object obj24 = categoryAxis1.clone();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor25 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE10;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot26.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis29 = categoryPlot26.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        java.awt.geom.Point2D point2D32 = null;
        categoryPlot26.zoomDomainAxes((double) 10.0f, plotRenderingInfo31, point2D32, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor35 = categoryPlot26.getDomainGridlinePosition();
        boolean boolean36 = itemLabelAnchor25.equals((java.lang.Object) categoryAnchor35);
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean41 = categoryPlot40.isRangeGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = categoryPlot40.getRangeAxisEdge((int) (byte) -1);
        try {
            double double44 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor35, 156, 128, rectangle2D39, rectangleEdge43);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid category index: 156");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertNotNull(itemLabelAnchor25);
        org.junit.Assert.assertNull(valueAxis29);
        org.junit.Assert.assertNotNull(categoryAnchor35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(rectangleEdge43);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = categoryAxis1.getTickLabelInsets();
        categoryAxis1.setCategoryLabelPositionOffset(0);
        categoryAxis1.setMinorTickMarksVisible(false);
        float float7 = categoryAxis1.getMinorTickMarkOutsideLength();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = categoryAxis1.getLabelInsets();
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        try {
            rectangleInsets8.trim(rectangle2D9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 2.0f + "'", float7 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets8);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        categoryPlot0.setDomainCrosshairColumnKey((java.lang.Comparable) (short) -1, true);
        org.jfree.chart.util.Layer layer9 = null;
        java.util.Collection collection10 = categoryPlot0.getRangeMarkers((int) (short) 0, layer9);
        categoryPlot0.setRangeMinorGridlinesVisible(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot13.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis16 = categoryPlot13.getRangeAxis();
        int int17 = categoryPlot13.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder18 = categoryPlot13.getRowRenderingOrder();
        categoryPlot13.setWeight((int) (short) 100);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder21 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        categoryPlot13.setDatasetRenderingOrder(datasetRenderingOrder21);
        categoryPlot0.setDatasetRenderingOrder(datasetRenderingOrder21);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNull(collection10);
        org.junit.Assert.assertNull(valueAxis16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 15 + "'", int17 == 15);
        org.junit.Assert.assertNotNull(sortOrder18);
        org.junit.Assert.assertNotNull(datasetRenderingOrder21);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape0, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape4 = chartEntity3.getArea();
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape4);
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot7.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis10 = categoryPlot7.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot7.zoomDomainAxes((double) 10.0f, plotRenderingInfo12, point2D13, false);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent16 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot7);
        org.jfree.chart.JFreeChart jFreeChart17 = null;
        plotChangeEvent16.setChart(jFreeChart17);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType19 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        plotChangeEvent16.setType(chartChangeEventType19);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent21 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) chartEntity5, jFreeChart6, chartChangeEventType19);
        java.awt.Shape shape22 = chartEntity5.getArea();
        chartEntity5.setToolTipText("SortOrder.ASCENDING");
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertNotNull(chartChangeEventType19);
        org.junit.Assert.assertNotNull(shape22);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        java.lang.Comparable comparable9 = categoryPlot0.getDomainCrosshairColumnKey();
        boolean boolean10 = categoryPlot0.isRangeCrosshairLockedOnData();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        categoryPlot0.setDomainCrosshairPaint((java.awt.Paint) color11);
        java.awt.Shape shape17 = null;
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem19 = new org.jfree.chart.LegendItem("", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", shape17, (java.awt.Paint) color18);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color18);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        categoryPlot0.panRangeAxes((double) 255, plotRenderingInfo22, point2D23);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = categoryPlot0.getAxisOffset();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNull(comparable9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(rectangleInsets25);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getMinimumBarLength();
        java.awt.Paint paint5 = barRenderer0.getItemPaint(0, 15, true);
        double double6 = barRenderer0.getShadowXOffset();
        boolean boolean7 = barRenderer0.getIncludeBaseInRange();
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = categoryAxis11.getTickLabelInsets();
        categoryAxis11.setCategoryLabelPositionOffset(0);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions15 = categoryAxis11.getCategoryLabelPositions();
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.util.Layer layer17 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        try {
            barRenderer0.drawAnnotations(graphics2D8, rectangle2D9, categoryAxis11, valueAxis16, layer17, plotRenderingInfo18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(categoryLabelPositions15);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        renderAttributes0.setDefaultFillPaint((java.awt.Paint) color1);
        java.awt.Shape shape5 = renderAttributes0.getItemShape((int) (byte) 100, (int) 'a');
        java.awt.Shape shape7 = null;
        renderAttributes0.setSeriesShape((int) (byte) 1, shape7);
        java.awt.Paint paint9 = renderAttributes0.getDefaultFillPaint();
        java.awt.Paint paint11 = renderAttributes0.getSeriesFillPaint(3);
        java.awt.Paint paint13 = renderAttributes0.getSeriesOutlinePaint((-128));
        java.awt.Color color14 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Color color15 = color14.darker();
        renderAttributes0.setDefaultLabelPaint((java.awt.Paint) color15);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNull(shape5);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        categoryPlot0.setDomainCrosshairColumnKey((java.lang.Comparable) (short) -1, true);
        org.jfree.chart.util.Layer layer9 = null;
        java.util.Collection collection10 = categoryPlot0.getRangeMarkers((int) (short) 0, layer9);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot11.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis14 = categoryPlot11.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        categoryPlot11.zoomDomainAxes((double) 10.0f, plotRenderingInfo16, point2D17, false);
        java.lang.Comparable comparable20 = categoryPlot11.getDomainCrosshairColumnKey();
        boolean boolean21 = categoryPlot11.isRangeCrosshairLockedOnData();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = categoryPlot11.getAxisOffset();
        double double23 = rectangleInsets22.getLeft();
        categoryPlot0.setAxisOffset(rectangleInsets22);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        categoryPlot0.setRenderer(0, categoryItemRenderer26);
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        categoryPlot0.setRangeAxis((int) ' ', valueAxis29, false);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNull(collection10);
        org.junit.Assert.assertNull(valueAxis14);
        org.junit.Assert.assertNull(comparable20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 4.0d + "'", double23 == 4.0d);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        java.awt.Shape shape4 = null;
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem6 = new org.jfree.chart.LegendItem("", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", shape4, (java.awt.Paint) color5);
        java.awt.Shape shape7 = legendItem6.getShape();
        org.jfree.data.general.Dataset dataset8 = legendItem6.getDataset();
        legendItem6.setSeriesKey((java.lang.Comparable) (-1.0d));
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(shape7);
        org.junit.Assert.assertNull(dataset8);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        renderAttributes0.setDefaultFillPaint((java.awt.Paint) color1);
        java.awt.Stroke stroke4 = renderAttributes0.getSeriesStroke((int) ' ');
        org.jfree.chart.renderer.RenderAttributes renderAttributes7 = new org.jfree.chart.renderer.RenderAttributes(true);
        java.awt.Color color9 = java.awt.Color.magenta;
        renderAttributes7.setSeriesOutlinePaint(128, (java.awt.Paint) color9);
        renderAttributes0.setSeriesFillPaint((int) ' ', (java.awt.Paint) color9);
        java.awt.Paint paint14 = renderAttributes0.getItemOutlinePaint(3, (int) '#');
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNull(stroke4);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNull(paint14);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor9 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        categoryPlot0.setRenderer(categoryItemRenderer10, false);
        org.jfree.chart.plot.Marker marker14 = null;
        org.jfree.chart.util.Layer layer15 = null;
        try {
            boolean boolean16 = categoryPlot0.removeRangeMarker(1, marker14, layer15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(categoryAnchor9);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.clearSeriesStrokes(true);
        lineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(true);
        java.awt.Stroke stroke5 = lineAndShapeRenderer0.getBaseOutlineStroke();
        lineAndShapeRenderer0.setBaseCreateEntities(false, true);
        boolean boolean9 = lineAndShapeRenderer0.getAutoPopulateSeriesOutlineStroke();
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot9.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis12 = categoryPlot9.getRangeAxis();
        int int13 = categoryPlot9.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder14 = categoryPlot9.getRowRenderingOrder();
        java.awt.Stroke stroke15 = categoryPlot9.getRangeZeroBaselineStroke();
        java.awt.Paint paint16 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("", "", "hi!", "", shape8, stroke15, paint16);
        legendItem17.setSeriesIndex((int) (byte) 10);
        java.awt.Shape shape20 = legendItem17.getShape();
        org.jfree.chart.renderer.RenderAttributes renderAttributes25 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        renderAttributes25.setDefaultFillPaint((java.awt.Paint) color26);
        java.awt.Shape shape30 = renderAttributes25.getItemShape((int) (byte) 100, (int) 'a');
        java.awt.Shape shape31 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        renderAttributes25.setDefaultShape(shape31);
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot33.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis36 = categoryPlot33.getRangeAxis();
        int int37 = categoryPlot33.getBackgroundImageAlignment();
        categoryPlot33.setDomainCrosshairColumnKey((java.lang.Comparable) (short) -1, true);
        java.awt.Stroke stroke41 = categoryPlot33.getDomainGridlineStroke();
        java.awt.Color color42 = java.awt.Color.MAGENTA;
        org.jfree.chart.LegendItem legendItem43 = new org.jfree.chart.LegendItem("hi!", "AxisLocation.BOTTOM_OR_LEFT", "AxisLocation.BOTTOM_OR_LEFT", "ChartChangeEventType.GENERAL", shape31, stroke41, (java.awt.Paint) color42);
        java.awt.Stroke stroke44 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.renderer.RenderAttributes renderAttributes45 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color46 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        renderAttributes45.setDefaultFillPaint((java.awt.Paint) color46);
        try {
            org.jfree.chart.LegendItem legendItem48 = new org.jfree.chart.LegendItem(attributedString0, "PlotEntity: tooltip = ItemLabelAnchor.OUTSIDE1", "", "PlotEntity: tooltip = ItemLabelAnchor.OUTSIDE1", shape20, (java.awt.Paint) color42, stroke44, (java.awt.Paint) color46);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 15 + "'", int13 == 15);
        org.junit.Assert.assertNotNull(sortOrder14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNull(shape30);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNull(valueAxis36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 15 + "'", int37 == 15);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(color46);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        java.lang.Comparable comparable9 = categoryPlot0.getDomainCrosshairColumnKey();
        boolean boolean10 = categoryPlot0.isRangeCrosshairLockedOnData();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        categoryPlot0.setDomainCrosshairPaint((java.awt.Paint) color11);
        java.awt.Shape shape17 = null;
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem19 = new org.jfree.chart.LegendItem("", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", shape17, (java.awt.Paint) color18);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color18);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        categoryPlot0.zoomRangeAxes(4.0d, plotRenderingInfo22, point2D23);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNull(comparable9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color18);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        java.util.List list4 = null;
        try {
            categoryPlot0.mapDatasetToDomainAxes(64, list4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        java.lang.Comparable comparable9 = categoryPlot0.getDomainCrosshairColumnKey();
        boolean boolean10 = categoryPlot0.isDomainZoomable();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNull(comparable9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis4 = categoryPlot1.getRangeAxis();
        int int5 = categoryPlot1.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder6 = categoryPlot1.getRowRenderingOrder();
        java.awt.Stroke stroke7 = categoryPlot1.getRangeZeroBaselineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent8 = null;
        categoryPlot1.rendererChanged(rendererChangeEvent8);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation11 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot10.setRangeAxisLocation(axisLocation11, true);
        categoryPlot1.setDomainAxisLocation(axisLocation11);
        categoryPlot1.setCrosshairDatasetIndex((int) (short) 1);
        org.jfree.data.category.CategoryDataset categoryDataset17 = categoryPlot1.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = categoryPlot1.getAxisOffset();
        org.jfree.chart.util.SortOrder sortOrder19 = categoryPlot1.getRowRenderingOrder();
        keyedObjects0.sortByObjects(sortOrder19);
        try {
            keyedObjects0.removeValue(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
        org.junit.Assert.assertNotNull(sortOrder6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNull(categoryDataset17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(sortOrder19);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        java.awt.Color color0 = java.awt.Color.yellow;
        java.awt.color.ColorSpace colorSpace1 = color0.getColorSpace();
        float[] floatArray5 = new float[] { (byte) 1, '#', 15 };
        float[] floatArray6 = color0.getRGBColorComponents(floatArray5);
        java.awt.image.ColorModel colorModel7 = null;
        java.awt.Rectangle rectangle8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.awt.geom.AffineTransform affineTransform10 = null;
        java.awt.RenderingHints renderingHints11 = null;
        java.awt.PaintContext paintContext12 = color0.createContext(colorModel7, rectangle8, rectangle2D9, affineTransform10, renderingHints11);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(colorSpace1);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(paintContext12);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getMinimumBarLength();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = null;
        barRenderer0.setSeriesURLGenerator((int) (short) 0, categoryURLGenerator3);
        boolean boolean6 = barRenderer0.isSeriesVisibleInLegend(0);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot9.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis12 = categoryPlot9.getRangeAxis();
        int int13 = categoryPlot9.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder14 = categoryPlot9.getRowRenderingOrder();
        java.awt.Stroke stroke15 = categoryPlot9.getRangeZeroBaselineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent16 = null;
        categoryPlot9.rendererChanged(rendererChangeEvent16);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation19 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot18.setRangeAxisLocation(axisLocation19, true);
        categoryPlot9.setDomainAxisLocation(axisLocation19);
        categoryPlot9.setCrosshairDatasetIndex((int) (short) 1);
        org.jfree.data.category.CategoryDataset categoryDataset25 = categoryPlot9.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = categoryPlot9.getAxisOffset();
        categoryPlot9.setOutlineVisible(true);
        java.awt.Shape shape33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot34.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis37 = categoryPlot34.getRangeAxis();
        int int38 = categoryPlot34.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder39 = categoryPlot34.getRowRenderingOrder();
        java.awt.Stroke stroke40 = categoryPlot34.getRangeZeroBaselineStroke();
        java.awt.Paint paint41 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem42 = new org.jfree.chart.LegendItem("", "", "hi!", "", shape33, stroke40, paint41);
        legendItem42.setDescription("");
        int int45 = legendItem42.getDatasetIndex();
        java.lang.String str46 = legendItem42.getLabel();
        java.lang.String str47 = legendItem42.getLabel();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset48 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo49 = new org.jfree.chart.event.DatasetChangeInfo();
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent50 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object) legendItem42, (org.jfree.data.general.Dataset) defaultCategoryDataset48, datasetChangeInfo49);
        java.util.List list51 = defaultCategoryDataset48.getRowKeys();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo52 = null;
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState53 = barRenderer0.initialise(graphics2D7, rectangle2D8, categoryPlot9, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset48, plotRenderingInfo52);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'index'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 15 + "'", int13 == 15);
        org.junit.Assert.assertNotNull(sortOrder14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNull(categoryDataset25);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNull(valueAxis37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 15 + "'", int38 == 15);
        org.junit.Assert.assertNotNull(sortOrder39);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "" + "'", str46.equals(""));
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "" + "'", str47.equals(""));
        org.junit.Assert.assertNotNull(list51);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Shape shape11 = null;
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", shape11, (java.awt.Paint) color12);
        int int14 = color12.getBlue();
        lineAndShapeRenderer2.setSeriesItemLabelPaint((int) (byte) 1, (java.awt.Paint) color12);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean17 = categoryPlot16.isRangeGridlinesVisible();
        categoryPlot16.clearDomainAxes();
        lineAndShapeRenderer2.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot16);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator21 = lineAndShapeRenderer2.getSeriesURLGenerator((int) 'a');
        lineAndShapeRenderer2.setBaseItemLabelsVisible(true, false);
        lineAndShapeRenderer2.setSeriesCreateEntities(255, (java.lang.Boolean) true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 128 + "'", int14 == 128);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNull(categoryURLGenerator21);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier4 = categoryPlot0.getDrawingSupplier();
        double double5 = categoryPlot0.getRangeCrosshairValue();
        int int6 = categoryPlot0.getDomainAxisCount();
        int int7 = categoryPlot0.getDatasetCount();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(drawingSupplier4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = lineAndShapeRenderer2.getBasePositiveItemLabelPosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot4.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = categoryPlot4.getDomainAxisEdge();
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot4.getDomainAxisLocation();
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        categoryPlot4.drawBackgroundImage(graphics2D9, rectangle2D10);
        java.awt.Paint paint12 = categoryPlot4.getNoDataMessagePaint();
        lineAndShapeRenderer2.setBaseItemLabelPaint(paint12);
        java.lang.Boolean boolean15 = lineAndShapeRenderer2.getSeriesShapesFilled(10);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier17 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot18.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis21 = categoryPlot18.getRangeAxis();
        int int22 = categoryPlot18.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder23 = categoryPlot18.getRowRenderingOrder();
        java.awt.Stroke stroke24 = categoryPlot18.getRangeZeroBaselineStroke();
        categoryPlot18.setRangeGridlinesVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot27.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis30 = categoryPlot27.getRangeAxis();
        int int31 = categoryPlot27.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder32 = categoryPlot27.getRowRenderingOrder();
        java.awt.Stroke stroke33 = categoryPlot27.getRangeZeroBaselineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent34 = null;
        categoryPlot27.rendererChanged(rendererChangeEvent34);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation37 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot36.setRangeAxisLocation(axisLocation37, true);
        categoryPlot27.setDomainAxisLocation(axisLocation37);
        categoryPlot18.setDomainAxisLocation(axisLocation37, true);
        categoryPlot18.setBackgroundAlpha((float) 10);
        boolean boolean45 = defaultDrawingSupplier17.equals((java.lang.Object) 10);
        java.awt.Paint paint46 = defaultDrawingSupplier17.getNextOutlinePaint();
        java.awt.Paint paint47 = defaultDrawingSupplier17.getNextFillPaint();
        try {
            lineAndShapeRenderer2.setSeriesPaint((-256), paint47, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(boolean15);
        org.junit.Assert.assertNull(valueAxis21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 15 + "'", int22 == 15);
        org.junit.Assert.assertNotNull(sortOrder23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNull(valueAxis30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 15 + "'", int31 == 15);
        org.junit.Assert.assertNotNull(sortOrder32);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(paint47);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        int int2 = keyedObjects0.getIndex((java.lang.Comparable) (short) 100);
        java.util.List list3 = keyedObjects0.getKeys();
        try {
            java.lang.Comparable comparable5 = keyedObjects0.getKey(15);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 15, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(list3);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE10;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis4 = categoryPlot1.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot1.zoomDomainAxes((double) 10.0f, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor10 = categoryPlot1.getDomainGridlinePosition();
        boolean boolean11 = itemLabelAnchor0.equals((java.lang.Object) categoryAnchor10);
        java.lang.String str12 = categoryAnchor10.toString();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertNotNull(categoryAnchor10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "CategoryAnchor.MIDDLE" + "'", str12.equals("CategoryAnchor.MIDDLE"));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.axis.AxisSpace axisSpace5 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace5, true);
        org.jfree.chart.plot.Marker marker8 = null;
        boolean boolean9 = categoryPlot0.removeDomainMarker(marker8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot0.zoomRangeAxes((double) (-16728064), plotRenderingInfo11, point2D12);
        org.jfree.chart.axis.AxisSpace axisSpace14 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace14);
        int int16 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        categoryPlot0.panDomainAxes(0.0d, plotRenderingInfo18, point2D19);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape0, "ChartChangeEventType.GENERAL", "");
        chartEntity3.setToolTipText("ItemLabelAnchor.OUTSIDE1");
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        lineAndShapeRenderer2.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator7);
        lineAndShapeRenderer2.setSeriesVisible((int) (short) 100, (java.lang.Boolean) false, true);
        lineAndShapeRenderer2.setSeriesShapesVisible(3, false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke20 = lineAndShapeRenderer19.getBaseStroke();
        org.jfree.chart.LegendItemCollection legendItemCollection21 = lineAndShapeRenderer19.getLegendItems();
        org.jfree.chart.renderer.RenderAttributes renderAttributes22 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Shape shape25 = renderAttributes22.getItemShape((int) (byte) 10, 15);
        java.awt.Color color27 = java.awt.Color.CYAN;
        renderAttributes22.setSeriesOutlinePaint((int) (byte) 0, (java.awt.Paint) color27);
        lineAndShapeRenderer19.setBaseItemLabelPaint((java.awt.Paint) color27, true);
        java.awt.Font font34 = lineAndShapeRenderer19.getItemLabelFont((int) (byte) 0, (-1), false);
        try {
            lineAndShapeRenderer2.setLegendTextFont((-1), font34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(legendItemCollection21);
        org.junit.Assert.assertNull(shape25);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(font34);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.data.general.DatasetGroup datasetGroup0 = new org.jfree.data.general.DatasetGroup();
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.clearSeriesStrokes(true);
        java.lang.Boolean boolean4 = lineAndShapeRenderer0.getSeriesVisibleInLegend(3);
        java.lang.Boolean boolean6 = lineAndShapeRenderer0.getSeriesShapesFilled(10);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator7 = null;
        lineAndShapeRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator7, true);
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot12.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = categoryPlot12.getDomainAxisEdge();
        org.jfree.chart.axis.AxisLocation axisLocation16 = categoryPlot12.getDomainAxisLocation();
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = categoryPlot12.getDomainAxisEdge();
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        java.awt.Shape shape25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot26.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis29 = categoryPlot26.getRangeAxis();
        int int30 = categoryPlot26.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder31 = categoryPlot26.getRowRenderingOrder();
        java.awt.Stroke stroke32 = categoryPlot26.getRangeZeroBaselineStroke();
        java.awt.Paint paint33 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem34 = new org.jfree.chart.LegendItem("", "", "hi!", "", shape25, stroke32, paint33);
        legendItem34.setDescription("");
        int int37 = legendItem34.getDatasetIndex();
        java.lang.String str38 = legendItem34.getLabel();
        java.lang.String str39 = legendItem34.getLabel();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset40 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo41 = new org.jfree.chart.event.DatasetChangeInfo();
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent42 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object) legendItem34, (org.jfree.data.general.Dataset) defaultCategoryDataset40, datasetChangeInfo41);
        defaultCategoryDataset40.clearSelection();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer49 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke50 = lineAndShapeRenderer49.getBaseStroke();
        java.awt.Paint paint52 = lineAndShapeRenderer49.getSeriesPaint(15);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition54 = lineAndShapeRenderer49.getSeriesNegativeItemLabelPosition(255);
        int int55 = lineAndShapeRenderer49.getDefaultEntityRadius();
        java.awt.Stroke stroke56 = lineAndShapeRenderer49.getBaseOutlineStroke();
        java.awt.Graphics2D graphics2D57 = null;
        java.awt.geom.Rectangle2D rectangle2D58 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot59 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation60 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot59.setRangeAxisLocation(axisLocation60, true);
        java.lang.Comparable comparable63 = categoryPlot59.getDomainCrosshairColumnKey();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer66 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke67 = lineAndShapeRenderer66.getBaseStroke();
        org.jfree.chart.LegendItemCollection legendItemCollection68 = lineAndShapeRenderer66.getLegendItems();
        categoryPlot59.setFixedLegendItems(legendItemCollection68);
        org.jfree.data.category.CategoryDataset categoryDataset70 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo71 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState72 = lineAndShapeRenderer49.initialise(graphics2D57, rectangle2D58, categoryPlot59, categoryDataset70, plotRenderingInfo71);
        java.awt.geom.Rectangle2D rectangle2D73 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D74 = lineAndShapeRenderer0.createHotSpotBounds(graphics2D10, rectangle2D11, categoryPlot12, categoryAxis19, valueAxis20, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset40, (int) '4', (int) (short) -1, true, categoryItemRendererState72, rectangle2D73);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertNull(boolean6);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNull(valueAxis29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 15 + "'", int30 == 15);
        org.junit.Assert.assertNotNull(sortOrder31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "" + "'", str38.equals(""));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "" + "'", str39.equals(""));
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNull(paint52);
        org.junit.Assert.assertNotNull(itemLabelPosition54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 3 + "'", int55 == 3);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertNotNull(axisLocation60);
        org.junit.Assert.assertNull(comparable63);
        org.junit.Assert.assertNotNull(stroke67);
        org.junit.Assert.assertNotNull(legendItemCollection68);
        org.junit.Assert.assertNotNull(categoryItemRendererState72);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Paint paint5 = lineAndShapeRenderer2.getSeriesPaint(15);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot7.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis10 = categoryPlot7.getRangeAxis();
        int int11 = categoryPlot7.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder12 = categoryPlot7.getRowRenderingOrder();
        categoryPlot7.setWeight((int) (short) 100);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot15.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis18 = categoryPlot15.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        java.awt.geom.Point2D point2D21 = null;
        categoryPlot15.zoomDomainAxes((double) 10.0f, plotRenderingInfo20, point2D21, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor24 = categoryPlot15.getDomainGridlinePosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot25.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis28 = categoryPlot25.getRangeAxis();
        int int29 = categoryPlot25.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder30 = categoryPlot25.getRowRenderingOrder();
        java.awt.Stroke stroke31 = categoryPlot25.getRangeZeroBaselineStroke();
        categoryPlot15.setRangeMinorGridlineStroke(stroke31);
        categoryPlot7.setRangeZeroBaselineStroke(stroke31);
        lineAndShapeRenderer2.setSeriesOutlineStroke((int) 'a', stroke31, false);
        java.awt.Font font39 = lineAndShapeRenderer2.getItemLabelFont((int) ' ', 156, true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 15 + "'", int11 == 15);
        org.junit.Assert.assertNotNull(sortOrder12);
        org.junit.Assert.assertNull(valueAxis18);
        org.junit.Assert.assertNotNull(categoryAnchor24);
        org.junit.Assert.assertNull(valueAxis28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 15 + "'", int29 == 15);
        org.junit.Assert.assertNotNull(sortOrder30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(font39);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Color color7 = java.awt.Color.getHSBColor((float) (short) 1, (float) 100, 0.0f);
        float[] floatArray14 = new float[] { (byte) 10, (byte) 1, 1.0f, (byte) 0, 10, (byte) 100 };
        float[] floatArray15 = color7.getRGBComponents(floatArray14);
        float[] floatArray16 = java.awt.Color.RGBtoHSB(100, (int) (short) 10, 128, floatArray15);
        float[] floatArray17 = color0.getRGBColorComponents(floatArray15);
        java.awt.image.ColorModel colorModel18 = null;
        java.awt.Rectangle rectangle19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        java.awt.geom.AffineTransform affineTransform21 = null;
        java.awt.RenderingHints renderingHints22 = null;
        java.awt.PaintContext paintContext23 = color0.createContext(colorModel18, rectangle19, rectangle2D20, affineTransform21, renderingHints22);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(paintContext23);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor9 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis13 = categoryPlot10.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Point2D point2D16 = null;
        categoryPlot10.zoomDomainAxes((double) 10.0f, plotRenderingInfo15, point2D16, false);
        boolean boolean19 = categoryPlot10.isRangeCrosshairVisible();
        java.awt.Stroke stroke20 = categoryPlot10.getRangeCrosshairStroke();
        boolean boolean21 = categoryAnchor9.equals((java.lang.Object) categoryPlot10);
        int int22 = categoryPlot10.getCrosshairDatasetIndex();
        java.awt.Stroke stroke23 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot10.setDomainGridlineStroke(stroke23);
        boolean boolean25 = categoryPlot10.canSelectByPoint();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(categoryAnchor9);
        org.junit.Assert.assertNull(valueAxis13);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        lineAndShapeRenderer2.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator7);
        lineAndShapeRenderer2.setSeriesVisible((int) (short) 100, (java.lang.Boolean) false, true);
        boolean boolean15 = lineAndShapeRenderer2.getItemShapeVisible((int) (short) 10, 3);
        lineAndShapeRenderer2.removeAnnotations();
        lineAndShapeRenderer2.setAutoPopulateSeriesShape(false);
        boolean boolean19 = lineAndShapeRenderer2.getUseOutlinePaint();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        org.jfree.chart.LegendItemCollection legendItemCollection4 = lineAndShapeRenderer2.getLegendItems();
        java.util.Iterator iterator5 = legendItemCollection4.iterator();
        try {
            org.jfree.chart.LegendItem legendItem7 = legendItemCollection4.get((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(legendItemCollection4);
        org.junit.Assert.assertNotNull(iterator5);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        java.awt.Color color0 = java.awt.Color.BLACK;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor1 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE5;
        java.awt.Color color2 = java.awt.Color.white;
        boolean boolean3 = itemLabelAnchor1.equals((java.lang.Object) color2);
        java.awt.Color color4 = java.awt.Color.yellow;
        java.awt.color.ColorSpace colorSpace5 = color4.getColorSpace();
        java.awt.Color color12 = java.awt.Color.getHSBColor((float) (short) 1, (float) 100, 0.0f);
        float[] floatArray19 = new float[] { (byte) 10, (byte) 1, 1.0f, (byte) 0, 10, (byte) 100 };
        float[] floatArray20 = color12.getRGBComponents(floatArray19);
        float[] floatArray21 = java.awt.Color.RGBtoHSB((int) ' ', 1, 255, floatArray19);
        float[] floatArray22 = color2.getComponents(colorSpace5, floatArray21);
        float[] floatArray23 = color0.getColorComponents(floatArray21);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(itemLabelAnchor1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(colorSpace5);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray23);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder5 = categoryPlot0.getRowRenderingOrder();
        java.awt.Stroke stroke6 = categoryPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = categoryPlot0.getInsets();
        categoryPlot0.clearAnnotations();
        categoryPlot0.setRangeZeroBaselineVisible(false);
        org.jfree.chart.plot.Plot plot11 = categoryPlot0.getRootPlot();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(sortOrder5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(plot11);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent9 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot0);
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace10);
        org.junit.Assert.assertNull(valueAxis3);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Shape shape9 = lineAndShapeRenderer2.getItemShape((int) (short) 10, 100, true);
        lineAndShapeRenderer2.setBaseSeriesVisible(false);
        java.awt.Shape shape12 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity15 = new org.jfree.chart.entity.ChartEntity(shape12, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape16 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity19 = new org.jfree.chart.entity.ChartEntity(shape16, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape20 = chartEntity19.getArea();
        chartEntity15.setArea(shape20);
        lineAndShapeRenderer2.setBaseShape(shape20, true);
        java.lang.Boolean boolean25 = lineAndShapeRenderer2.getSeriesShapesVisible(1);
        java.awt.Font font26 = lineAndShapeRenderer2.getBaseItemLabelFont();
        lineAndShapeRenderer2.setSeriesShapesVisible(1, true);
        lineAndShapeRenderer2.setBaseSeriesVisible(false);
        java.lang.Boolean boolean33 = lineAndShapeRenderer2.getSeriesVisibleInLegend(64);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNull(boolean25);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNull(boolean33);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = categoryAxis1.getTickLabelInsets();
        categoryAxis1.setCategoryLabelPositionOffset(0);
        categoryAxis1.setMinorTickMarksVisible(false);
        float float7 = categoryAxis1.getMinorTickMarkOutsideLength();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 10, "");
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 2.0f + "'", float7 == 2.0f);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        java.awt.Shape shape4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        int int9 = categoryPlot5.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot5.getRowRenderingOrder();
        java.awt.Stroke stroke11 = categoryPlot5.getRangeZeroBaselineStroke();
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("", "", "hi!", "", shape4, stroke11, paint12);
        legendItem13.setDescription("");
        int int16 = legendItem13.getDatasetIndex();
        legendItem13.setToolTipText("SortOrder.ASCENDING");
        boolean boolean19 = legendItem13.isShapeOutlineVisible();
        boolean boolean20 = legendItem13.isShapeFilled();
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Color color23 = java.awt.Color.getColor("ItemLabelAnchor.OUTSIDE1", color22);
        boolean boolean24 = legendItem13.equals((java.lang.Object) color23);
        legendItem13.setShapeVisible(false);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier4 = categoryPlot0.getDrawingSupplier();
        org.jfree.data.category.CategoryDataset categoryDataset5 = categoryPlot0.getDataset();
        org.jfree.chart.renderer.RenderAttributes renderAttributes6 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        renderAttributes6.setDefaultFillPaint((java.awt.Paint) color7);
        categoryPlot0.setBackgroundPaint((java.awt.Paint) color7);
        org.jfree.chart.axis.ValueAxis valueAxis10 = categoryPlot0.getRangeAxis();
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        int int12 = color11.getTransparency();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color11);
        categoryPlot0.setCrosshairDatasetIndex((int) (short) 1);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(drawingSupplier4);
        org.junit.Assert.assertNull(categoryDataset5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Paint paint5 = lineAndShapeRenderer2.getSeriesPaint(15);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot7.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis10 = categoryPlot7.getRangeAxis();
        int int11 = categoryPlot7.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder12 = categoryPlot7.getRowRenderingOrder();
        categoryPlot7.setWeight((int) (short) 100);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot15.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis18 = categoryPlot15.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        java.awt.geom.Point2D point2D21 = null;
        categoryPlot15.zoomDomainAxes((double) 10.0f, plotRenderingInfo20, point2D21, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor24 = categoryPlot15.getDomainGridlinePosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot25.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis28 = categoryPlot25.getRangeAxis();
        int int29 = categoryPlot25.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder30 = categoryPlot25.getRowRenderingOrder();
        java.awt.Stroke stroke31 = categoryPlot25.getRangeZeroBaselineStroke();
        categoryPlot15.setRangeMinorGridlineStroke(stroke31);
        categoryPlot7.setRangeZeroBaselineStroke(stroke31);
        lineAndShapeRenderer2.setSeriesOutlineStroke((int) 'a', stroke31, false);
        java.awt.Stroke stroke37 = lineAndShapeRenderer2.getSeriesOutlineStroke(0);
        int int38 = lineAndShapeRenderer2.getPassCount();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 15 + "'", int11 == 15);
        org.junit.Assert.assertNotNull(sortOrder12);
        org.junit.Assert.assertNull(valueAxis18);
        org.junit.Assert.assertNotNull(categoryAnchor24);
        org.junit.Assert.assertNull(valueAxis28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 15 + "'", int29 == 15);
        org.junit.Assert.assertNotNull(sortOrder30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNull(stroke37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2 + "'", int38 == 2);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = categoryAxis1.getTickLabelInsets();
        categoryAxis1.setCategoryLabelPositionOffset(0);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        int int9 = categoryPlot5.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot5.getRowRenderingOrder();
        java.awt.Stroke stroke11 = categoryPlot5.getRangeZeroBaselineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        categoryPlot5.rendererChanged(rendererChangeEvent12);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot14.setRangeAxisLocation(axisLocation15, true);
        categoryPlot5.setDomainAxisLocation(axisLocation15);
        categoryPlot5.setCrosshairDatasetIndex((int) (short) 1);
        categoryAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot5);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = categoryAxis1.getLabelInsets();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions23 = categoryAxis1.getCategoryLabelPositions();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(categoryLabelPositions23);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke7 = lineAndShapeRenderer6.getBaseStroke();
        java.awt.Stroke stroke9 = lineAndShapeRenderer6.lookupSeriesStroke(10);
        java.awt.Shape shape13 = lineAndShapeRenderer6.getItemShape((int) (short) 10, 100, true);
        lineAndShapeRenderer6.setBaseSeriesVisible(false);
        lineAndShapeRenderer6.setSeriesShapesVisible((int) (short) 10, false);
        java.awt.Shape shape20 = lineAndShapeRenderer6.lookupSeriesShape(1);
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot21.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis24 = categoryPlot21.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        java.awt.geom.Point2D point2D27 = null;
        categoryPlot21.zoomDomainAxes((double) 10.0f, plotRenderingInfo26, point2D27, false);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent30 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot21);
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot31.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis34 = categoryPlot31.getRangeAxis();
        int int35 = categoryPlot31.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder36 = categoryPlot31.getRowRenderingOrder();
        java.awt.Stroke stroke37 = categoryPlot31.getRangeZeroBaselineStroke();
        categoryPlot21.setOutlineStroke(stroke37);
        org.jfree.chart.plot.Marker marker40 = null;
        org.jfree.chart.util.Layer layer41 = null;
        boolean boolean42 = categoryPlot21.removeDomainMarker(15, marker40, layer41);
        java.awt.Stroke stroke43 = categoryPlot21.getRangeZeroBaselineStroke();
        org.jfree.chart.renderer.RenderAttributes renderAttributes44 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color45 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        renderAttributes44.setDefaultFillPaint((java.awt.Paint) color45);
        java.awt.Shape shape49 = renderAttributes44.getItemShape((int) (byte) 100, (int) 'a');
        java.awt.Shape shape51 = null;
        renderAttributes44.setSeriesShape((int) (byte) 1, shape51);
        java.awt.Paint paint53 = renderAttributes44.getDefaultFillPaint();
        try {
            org.jfree.chart.LegendItem legendItem54 = new org.jfree.chart.LegendItem(attributedString0, "", "CategoryAnchor.MIDDLE", "", shape20, stroke43, paint53);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNull(valueAxis24);
        org.junit.Assert.assertNull(valueAxis34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 15 + "'", int35 == 15);
        org.junit.Assert.assertNotNull(sortOrder36);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNull(shape49);
        org.junit.Assert.assertNotNull(paint53);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Paint paint5 = lineAndShapeRenderer2.getSeriesPaint(15);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = lineAndShapeRenderer2.getSeriesNegativeItemLabelPosition(255);
        int int8 = lineAndShapeRenderer2.getDefaultEntityRadius();
        java.awt.Stroke stroke9 = lineAndShapeRenderer2.getBaseOutlineStroke();
        lineAndShapeRenderer2.setUseOutlinePaint(false);
        java.awt.Shape shape13 = lineAndShapeRenderer2.getLegendShape((int) (byte) 1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNull(shape13);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        int int1 = paintList0.size();
        java.awt.Paint paint3 = paintList0.getPaint((int) '#');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNull(paint3);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.clearSeriesStrokes(true);
        java.lang.Boolean boolean4 = lineAndShapeRenderer0.getSeriesVisibleInLegend(3);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator6 = lineAndShapeRenderer0.getSeriesURLGenerator((-1));
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = categoryAxis10.getTickLabelInsets();
        categoryAxis10.setCategoryLabelPositionOffset(0);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot14.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis17 = categoryPlot14.getRangeAxis();
        int int18 = categoryPlot14.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder19 = categoryPlot14.getRowRenderingOrder();
        java.awt.Stroke stroke20 = categoryPlot14.getRangeZeroBaselineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent21 = null;
        categoryPlot14.rendererChanged(rendererChangeEvent21);
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation24 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot23.setRangeAxisLocation(axisLocation24, true);
        categoryPlot14.setDomainAxisLocation(axisLocation24);
        categoryPlot14.setCrosshairDatasetIndex((int) (short) 1);
        categoryAxis10.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot14);
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.util.Layer layer32 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        try {
            lineAndShapeRenderer0.drawAnnotations(graphics2D7, rectangle2D8, categoryAxis10, valueAxis31, layer32, plotRenderingInfo33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertNull(categoryURLGenerator6);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNull(valueAxis17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 15 + "'", int18 == 15);
        org.junit.Assert.assertNotNull(sortOrder19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(axisLocation24);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Shape shape11 = null;
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", shape11, (java.awt.Paint) color12);
        int int14 = color12.getBlue();
        lineAndShapeRenderer2.setSeriesItemLabelPaint((int) (byte) 1, (java.awt.Paint) color12);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean17 = categoryPlot16.isRangeGridlinesVisible();
        categoryPlot16.clearDomainAxes();
        lineAndShapeRenderer2.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot16);
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = categoryAxis21.getTickLabelInsets();
        categoryAxis21.setCategoryLabelPositionOffset(0);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot25.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis28 = categoryPlot25.getRangeAxis();
        int int29 = categoryPlot25.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder30 = categoryPlot25.getRowRenderingOrder();
        java.awt.Stroke stroke31 = categoryPlot25.getRangeZeroBaselineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent32 = null;
        categoryPlot25.rendererChanged(rendererChangeEvent32);
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation35 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot34.setRangeAxisLocation(axisLocation35, true);
        categoryPlot25.setDomainAxisLocation(axisLocation35);
        categoryPlot25.setCrosshairDatasetIndex((int) (short) 1);
        categoryAxis21.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot25);
        java.util.List list42 = categoryPlot16.getCategoriesForAxis(categoryAxis21);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 128 + "'", int14 == 128);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNull(valueAxis28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 15 + "'", int29 == 15);
        org.junit.Assert.assertNotNull(sortOrder30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertNotNull(list42);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.clearSeriesStrokes(true);
        java.lang.Boolean boolean4 = lineAndShapeRenderer0.getSeriesVisibleInLegend(3);
        java.lang.Boolean boolean6 = lineAndShapeRenderer0.getSeriesShapesFilled(10);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator7 = null;
        lineAndShapeRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator7, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator10 = lineAndShapeRenderer0.getLegendItemToolTipGenerator();
        java.util.EventListener eventListener11 = null;
        boolean boolean12 = lineAndShapeRenderer0.hasListener(eventListener11);
        java.awt.Paint paint14 = lineAndShapeRenderer0.lookupSeriesFillPaint((int) (short) 10);
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertNull(boolean6);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.clearSeriesStrokes(true);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator4 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("java.awt.Color[r=0,g=0,b=0]");
        lineAndShapeRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator4);
        java.awt.Paint paint9 = lineAndShapeRenderer0.getItemFillPaint((int) (byte) 0, 156, true);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        java.awt.Shape shape21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot22.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis25 = categoryPlot22.getRangeAxis();
        int int26 = categoryPlot22.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder27 = categoryPlot22.getRowRenderingOrder();
        java.awt.Stroke stroke28 = categoryPlot22.getRangeZeroBaselineStroke();
        java.awt.Paint paint29 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem30 = new org.jfree.chart.LegendItem("", "", "hi!", "", shape21, stroke28, paint29);
        legendItem30.setDescription("");
        int int33 = legendItem30.getDatasetIndex();
        java.lang.String str34 = legendItem30.getLabel();
        java.lang.String str35 = legendItem30.getLabel();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset36 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo37 = new org.jfree.chart.event.DatasetChangeInfo();
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent38 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object) legendItem30, (org.jfree.data.general.Dataset) defaultCategoryDataset36, datasetChangeInfo37);
        defaultCategoryDataset36.clearSelection();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer45 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke46 = lineAndShapeRenderer45.getBaseStroke();
        java.awt.Paint paint48 = lineAndShapeRenderer45.getSeriesPaint(15);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition50 = lineAndShapeRenderer45.getSeriesNegativeItemLabelPosition(255);
        int int51 = lineAndShapeRenderer45.getDefaultEntityRadius();
        java.awt.Stroke stroke52 = lineAndShapeRenderer45.getBaseOutlineStroke();
        java.awt.Graphics2D graphics2D53 = null;
        java.awt.geom.Rectangle2D rectangle2D54 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot55 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation56 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot55.setRangeAxisLocation(axisLocation56, true);
        java.lang.Comparable comparable59 = categoryPlot55.getDomainCrosshairColumnKey();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer62 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke63 = lineAndShapeRenderer62.getBaseStroke();
        org.jfree.chart.LegendItemCollection legendItemCollection64 = lineAndShapeRenderer62.getLegendItems();
        categoryPlot55.setFixedLegendItems(legendItemCollection64);
        org.jfree.data.category.CategoryDataset categoryDataset66 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo67 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState68 = lineAndShapeRenderer45.initialise(graphics2D53, rectangle2D54, categoryPlot55, categoryDataset66, plotRenderingInfo67);
        try {
            boolean boolean69 = lineAndShapeRenderer0.hitTest((double) ' ', (double) (short) 0, graphics2D12, rectangle2D13, categoryPlot14, categoryAxis15, valueAxis16, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset36, (-1), (-16728064), false, categoryItemRendererState68);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -16728064");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(valueAxis25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 15 + "'", int26 == 15);
        org.junit.Assert.assertNotNull(sortOrder27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "" + "'", str34.equals(""));
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "" + "'", str35.equals(""));
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNull(paint48);
        org.junit.Assert.assertNotNull(itemLabelPosition50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 3 + "'", int51 == 3);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNotNull(axisLocation56);
        org.junit.Assert.assertNull(comparable59);
        org.junit.Assert.assertNotNull(stroke63);
        org.junit.Assert.assertNotNull(legendItemCollection64);
        org.junit.Assert.assertNotNull(categoryItemRendererState68);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.clearSeriesStrokes(true);
        java.lang.Boolean boolean4 = lineAndShapeRenderer0.getSeriesVisibleInLegend(3);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator6 = lineAndShapeRenderer0.getSeriesURLGenerator((-1));
        boolean boolean7 = lineAndShapeRenderer0.getUseSeriesOffset();
        lineAndShapeRenderer0.setBaseLinesVisible(false);
        java.awt.Shape shape11 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity14 = new org.jfree.chart.entity.ChartEntity(shape11, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape15 = chartEntity14.getArea();
        org.jfree.chart.entity.ChartEntity chartEntity16 = new org.jfree.chart.entity.ChartEntity(shape15);
        try {
            lineAndShapeRenderer0.setLegendShape((-128), shape15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertNull(categoryURLGenerator6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(shape15);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor(100, (int) '#', (int) (short) 0);
        int int4 = chartColor3.getRGB();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-10214656) + "'", int4 == (-10214656));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis4 = categoryPlot1.getRangeAxis();
        int int5 = categoryPlot1.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder6 = categoryPlot1.getRowRenderingOrder();
        java.awt.Stroke stroke7 = categoryPlot1.getRangeZeroBaselineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent8 = null;
        categoryPlot1.rendererChanged(rendererChangeEvent8);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation11 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot10.setRangeAxisLocation(axisLocation11, true);
        categoryPlot1.setDomainAxisLocation(axisLocation11);
        categoryPlot1.setCrosshairDatasetIndex((int) (short) 1);
        org.jfree.data.category.CategoryDataset categoryDataset17 = categoryPlot1.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = categoryPlot1.getAxisOffset();
        org.jfree.chart.util.SortOrder sortOrder19 = categoryPlot1.getRowRenderingOrder();
        keyedObjects0.sortByObjects(sortOrder19);
        java.util.List list21 = keyedObjects0.getKeys();
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
        org.junit.Assert.assertNotNull(sortOrder6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNull(categoryDataset17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(sortOrder19);
        org.junit.Assert.assertNotNull(list21);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent9 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot0);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType10 = plotChangeEvent9.getType();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType11 = plotChangeEvent9.getType();
        java.lang.Object obj12 = plotChangeEvent9.getSource();
        org.jfree.chart.plot.Plot plot13 = plotChangeEvent9.getPlot();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(chartChangeEventType10);
        org.junit.Assert.assertNotNull(chartChangeEventType11);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(plot13);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent9 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot0);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer12 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke13 = lineAndShapeRenderer12.getBaseStroke();
        categoryPlot0.setRangeMinorGridlineStroke(stroke13);
        java.awt.Paint paint15 = categoryPlot0.getRangeMinorGridlinePaint();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("AxisLocation.BOTTOM_OR_LEFT");
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis5 = categoryPlot2.getRangeAxis();
        int int6 = categoryPlot2.getBackgroundImageAlignment();
        categoryPlot2.setDomainCrosshairColumnKey((java.lang.Comparable) (short) -1, true);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot2.getRangeMarkers((int) (short) 0, layer11);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot13.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis16 = categoryPlot13.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        categoryPlot13.zoomDomainAxes((double) 10.0f, plotRenderingInfo18, point2D19, false);
        java.lang.Comparable comparable22 = categoryPlot13.getDomainCrosshairColumnKey();
        boolean boolean23 = categoryPlot13.isRangeCrosshairLockedOnData();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = categoryPlot13.getAxisOffset();
        double double25 = rectangleInsets24.getLeft();
        categoryPlot2.setAxisOffset(rectangleInsets24);
        boolean boolean27 = standardCategorySeriesLabelGenerator1.equals((java.lang.Object) rectangleInsets24);
        org.jfree.chart.util.UnitType unitType28 = rectangleInsets24.getUnitType();
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNull(valueAxis16);
        org.junit.Assert.assertNull(comparable22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 4.0d + "'", double25 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(unitType28);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        lineAndShapeRenderer2.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator7);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = lineAndShapeRenderer2.getSeriesPositiveItemLabelPosition(0);
        lineAndShapeRenderer2.setBaseShapesFilled(false);
        boolean boolean14 = lineAndShapeRenderer2.isSeriesItemLabelsVisible(8);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape0, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape4 = chartEntity3.getArea();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot5.zoomDomainAxes((double) 10.0f, plotRenderingInfo10, point2D11, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor14 = categoryPlot5.getDomainGridlinePosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot15.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis18 = categoryPlot15.getRangeAxis();
        int int19 = categoryPlot15.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder20 = categoryPlot15.getRowRenderingOrder();
        java.awt.Stroke stroke21 = categoryPlot15.getRangeZeroBaselineStroke();
        categoryPlot5.setRangeMinorGridlineStroke(stroke21);
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = categoryPlot5.getDomainAxis(100);
        boolean boolean25 = categoryPlot5.isNotify();
        org.jfree.chart.entity.PlotEntity plotEntity27 = new org.jfree.chart.entity.PlotEntity(shape4, (org.jfree.chart.plot.Plot) categoryPlot5, "ItemLabelAnchor.OUTSIDE1");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset30 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity33 = new org.jfree.chart.entity.CategoryItemEntity(shape4, "PlotOrientation.VERTICAL", "PlotOrientation.VERTICAL", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset30, (java.lang.Comparable) 10, (java.lang.Comparable) 'a');
        java.lang.Comparable comparable34 = categoryItemEntity33.getRowKey();
        org.jfree.data.category.CategoryDataset categoryDataset35 = null;
        try {
            categoryItemEntity33.setDataset(categoryDataset35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertNotNull(categoryAnchor14);
        org.junit.Assert.assertNull(valueAxis18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 15 + "'", int19 == 15);
        org.junit.Assert.assertNotNull(sortOrder20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNull(categoryAxis24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + comparable34 + "' != '" + 10 + "'", comparable34.equals(10));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier4 = categoryPlot0.getDrawingSupplier();
        java.awt.Stroke stroke5 = categoryPlot0.getOutlineStroke();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = categoryPlot0.getRenderer();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = categoryPlot0.getDomainAxis();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(drawingSupplier4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNull(categoryItemRenderer6);
        org.junit.Assert.assertNull(categoryAxis7);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        lineAndShapeRenderer2.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator7);
        lineAndShapeRenderer2.setSeriesVisible((int) (short) 100, (java.lang.Boolean) false, true);
        java.awt.Paint paint14 = lineAndShapeRenderer2.lookupSeriesFillPaint((int) (short) 0);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairLockedOnData(false);
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) (short) 10);
        categoryPlot0.setAnchorValue((double) (short) 10, false);
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace8);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        categoryPlot0.markerChanged(markerChangeEvent10);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke15 = lineAndShapeRenderer14.getBaseStroke();
        java.awt.Stroke stroke17 = lineAndShapeRenderer14.lookupSeriesStroke(10);
        java.awt.Shape shape23 = null;
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", shape23, (java.awt.Paint) color24);
        int int26 = color24.getBlue();
        lineAndShapeRenderer14.setSeriesItemLabelPaint((int) (byte) 1, (java.awt.Paint) color24);
        int int28 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer14);
        java.awt.Paint paint29 = null;
        lineAndShapeRenderer14.setBaseLegendTextPaint(paint29);
        lineAndShapeRenderer14.setSeriesVisibleInLegend(10, (java.lang.Boolean) false);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 128 + "'", int26 == 128);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        java.awt.Shape shape4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        int int9 = categoryPlot5.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot5.getRowRenderingOrder();
        java.awt.Stroke stroke11 = categoryPlot5.getRangeZeroBaselineStroke();
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("", "", "hi!", "", shape4, stroke11, paint12);
        legendItem13.setDescription("");
        int int16 = legendItem13.getDatasetIndex();
        legendItem13.setToolTipText("SortOrder.ASCENDING");
        boolean boolean19 = legendItem13.isShapeOutlineVisible();
        boolean boolean20 = legendItem13.isShapeFilled();
        legendItem13.setDescription("CategoryAnchor.MIDDLE");
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        java.awt.Shape shape4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        int int9 = categoryPlot5.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot5.getRowRenderingOrder();
        java.awt.Stroke stroke11 = categoryPlot5.getRangeZeroBaselineStroke();
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("", "", "hi!", "", shape4, stroke11, paint12);
        legendItem13.setDescription("");
        int int16 = legendItem13.getDatasetIndex();
        java.lang.String str17 = legendItem13.getLabel();
        java.lang.String str18 = legendItem13.getLabel();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset19 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo20 = new org.jfree.chart.event.DatasetChangeInfo();
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent21 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object) legendItem13, (org.jfree.data.general.Dataset) defaultCategoryDataset19, datasetChangeInfo20);
        defaultCategoryDataset19.addValue((double) 2.0f, (java.lang.Comparable) '4', (java.lang.Comparable) 'a');
        try {
            java.lang.Comparable comparable27 = defaultCategoryDataset19.getColumnKey(128);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 128, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder5 = categoryPlot0.getRowRenderingOrder();
        java.awt.Stroke stroke6 = categoryPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = categoryPlot0.getInsets();
        java.lang.Object obj8 = categoryPlot0.clone();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot0.zoomRangeAxes((double) 2, plotRenderingInfo10, point2D11, false);
        java.awt.Paint paint14 = null;
        categoryPlot0.setOutlinePaint(paint14);
        org.jfree.chart.plot.Marker marker17 = null;
        org.jfree.chart.util.Layer layer18 = null;
        boolean boolean20 = categoryPlot0.removeDomainMarker((int) (short) 100, marker17, layer18, true);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(sortOrder5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        java.awt.Paint paint5 = categoryPlot0.getNoDataMessagePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = categoryPlot0.getDomainAxisForDataset((int) 'a');
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke11 = lineAndShapeRenderer10.getBaseStroke();
        org.jfree.chart.LegendItemCollection legendItemCollection12 = lineAndShapeRenderer10.getLegendItems();
        int int13 = legendItemCollection12.getItemCount();
        categoryPlot0.setFixedLegendItems(legendItemCollection12);
        categoryPlot0.setRangeGridlinesVisible(true);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(categoryAxis7);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(legendItemCollection12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        int int2 = keyedObjects0.getIndex((java.lang.Comparable) (short) 100);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot3.getDomainAxisEdge();
        int int7 = categoryPlot3.getWeight();
        java.lang.Comparable comparable8 = categoryPlot3.getDomainCrosshairColumnKey();
        boolean boolean9 = categoryPlot3.canSelectByRegion();
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot3.getRangeAxisLocation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot3.zoomDomainAxes((double) (short) 100, plotRenderingInfo12, point2D13, false);
        boolean boolean16 = keyedObjects0.equals((java.lang.Object) false);
        try {
            keyedObjects0.removeValue((java.lang.Comparable) 1.0d);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: The key (1.0) is not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNull(comparable8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        int int9 = categoryPlot0.getRangeAxisCount();
        boolean boolean10 = categoryPlot0.isRangeMinorGridlinesVisible();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        java.awt.Shape shape4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        int int9 = categoryPlot5.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot5.getRowRenderingOrder();
        java.awt.Stroke stroke11 = categoryPlot5.getRangeZeroBaselineStroke();
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("", "", "hi!", "", shape4, stroke11, paint12);
        legendItem13.setDescription("");
        int int16 = legendItem13.getDatasetIndex();
        java.lang.String str17 = legendItem13.getLabel();
        java.lang.String str18 = legendItem13.getLabel();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset19 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo20 = new org.jfree.chart.event.DatasetChangeInfo();
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent21 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object) legendItem13, (org.jfree.data.general.Dataset) defaultCategoryDataset19, datasetChangeInfo20);
        defaultCategoryDataset19.addValue((double) 2.0f, (java.lang.Comparable) '4', (java.lang.Comparable) 'a');
        try {
            java.lang.Comparable comparable27 = defaultCategoryDataset19.getColumnKey(156);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 156, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis4 = categoryPlot1.getRangeAxis();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier5 = categoryPlot1.getDrawingSupplier();
        categoryPlot0.setDrawingSupplier(drawingSupplier5);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        categoryPlot0.setRangeAxis(valueAxis7);
        java.awt.Paint paint9 = categoryPlot0.getRangeZeroBaselinePaint();
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertNotNull(drawingSupplier5);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        java.awt.Shape shape4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        int int9 = categoryPlot5.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot5.getRowRenderingOrder();
        java.awt.Stroke stroke11 = categoryPlot5.getRangeZeroBaselineStroke();
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("", "", "hi!", "", shape4, stroke11, paint12);
        legendItem13.setDescription("");
        int int16 = legendItem13.getDatasetIndex();
        java.lang.String str17 = legendItem13.getLabel();
        java.lang.String str18 = legendItem13.getLabel();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset19 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo20 = new org.jfree.chart.event.DatasetChangeInfo();
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent21 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object) legendItem13, (org.jfree.data.general.Dataset) defaultCategoryDataset19, datasetChangeInfo20);
        defaultCategoryDataset19.clearSelection();
        int int23 = defaultCategoryDataset19.getRowCount();
        int int25 = defaultCategoryDataset19.getColumnIndex((java.lang.Comparable) "AxisLocation.BOTTOM_OR_LEFT");
        try {
            defaultCategoryDataset19.removeRow(64);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 64, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        java.awt.Paint paint4 = categoryPlot0.getDomainGridlinePaint();
        categoryPlot0.configureRangeAxes();
        categoryPlot0.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis11 = categoryPlot8.getRangeAxis();
        int int12 = categoryPlot8.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder13 = categoryPlot8.getRowRenderingOrder();
        java.awt.Stroke stroke14 = categoryPlot8.getRangeZeroBaselineStroke();
        categoryPlot8.setRangeGridlinesVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot17.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis20 = categoryPlot17.getRangeAxis();
        int int21 = categoryPlot17.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot17.getRowRenderingOrder();
        java.awt.Stroke stroke23 = categoryPlot17.getRangeZeroBaselineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent24 = null;
        categoryPlot17.rendererChanged(rendererChangeEvent24);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation27 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot26.setRangeAxisLocation(axisLocation27, true);
        categoryPlot17.setDomainAxisLocation(axisLocation27);
        categoryPlot8.setDomainAxisLocation(axisLocation27, true);
        categoryPlot8.setBackgroundAlpha((float) 10);
        org.jfree.chart.axis.AxisLocation axisLocation35 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.axis.AxisLocation axisLocation36 = axisLocation35.getOpposite();
        categoryPlot8.setRangeAxisLocation(axisLocation36);
        categoryPlot0.setDomainAxisLocation(axisLocation36);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 15 + "'", int12 == 15);
        org.junit.Assert.assertNotNull(sortOrder13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNull(valueAxis20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 15 + "'", int21 == 15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertNotNull(axisLocation36);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = categoryAxis1.getTickLabelInsets();
        categoryAxis1.setCategoryLabelPositionOffset(0);
        categoryAxis1.setMinorTickMarksVisible(false);
        float float7 = categoryAxis1.getMinorTickMarkOutsideLength();
        boolean boolean8 = categoryAxis1.isVisible();
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean13 = categoryPlot12.isRangeGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = categoryPlot12.getRangeAxisEdge((int) (byte) -1);
        org.jfree.chart.axis.AxisState axisState16 = null;
        categoryAxis1.drawTickMarks(graphics2D9, (double) 1L, rectangle2D11, rectangleEdge15, axisState16);
        java.awt.Stroke stroke18 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryAxis1.setAxisLineStroke(stroke18);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 2.0f + "'", float7 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        java.lang.Comparable comparable9 = categoryPlot0.getDomainCrosshairColumnKey();
        boolean boolean10 = categoryPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = categoryPlot0.getAxisOffset();
        categoryPlot0.setRangeCrosshairVisible(true);
        categoryPlot0.setRangeGridlinesVisible(true);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNull(comparable9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(rectangleInsets11);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity8 = new org.jfree.chart.entity.ChartEntity(shape5, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape9 = chartEntity8.getArea();
        java.awt.Shape shape10 = chartEntity8.getArea();
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        int int15 = color14.getBlue();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer16 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer16.clearSeriesStrokes(true);
        java.lang.Boolean boolean20 = lineAndShapeRenderer16.getSeriesVisibleInLegend(3);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator22 = lineAndShapeRenderer16.getSeriesURLGenerator((-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot24.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis27 = categoryPlot24.getRangeAxis();
        int int28 = categoryPlot24.getBackgroundImageAlignment();
        categoryPlot24.setDomainCrosshairColumnKey((java.lang.Comparable) (short) -1, true);
        org.jfree.chart.util.Layer layer33 = null;
        java.util.Collection collection34 = categoryPlot24.getRangeMarkers((int) (short) 0, layer33);
        categoryPlot24.setRangeMinorGridlinesVisible(true);
        java.util.List list37 = categoryPlot24.getCategories();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer40 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke41 = lineAndShapeRenderer40.getBaseStroke();
        java.awt.Stroke stroke43 = lineAndShapeRenderer40.lookupSeriesStroke(10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator45 = null;
        lineAndShapeRenderer40.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator45);
        lineAndShapeRenderer40.setSeriesVisible((int) (short) 100, (java.lang.Boolean) false, true);
        boolean boolean53 = lineAndShapeRenderer40.getItemShapeVisible((int) (short) 10, 3);
        lineAndShapeRenderer40.removeAnnotations();
        lineAndShapeRenderer40.setAutoPopulateSeriesShape(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot57 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot57.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis60 = categoryPlot57.getRangeAxis();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier61 = categoryPlot57.getDrawingSupplier();
        java.awt.Stroke stroke62 = categoryPlot57.getOutlineStroke();
        lineAndShapeRenderer40.setBaseOutlineStroke(stroke62, false);
        categoryPlot24.setRangeGridlineStroke(stroke62);
        lineAndShapeRenderer16.setSeriesOutlineStroke((int) (short) 100, stroke62);
        java.awt.Shape shape68 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity71 = new org.jfree.chart.entity.ChartEntity(shape68, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape72 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity75 = new org.jfree.chart.entity.ChartEntity(shape72, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape76 = chartEntity75.getArea();
        chartEntity71.setArea(shape76);
        org.jfree.chart.plot.CategoryPlot categoryPlot78 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot78.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis81 = categoryPlot78.getRangeAxis();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier82 = categoryPlot78.getDrawingSupplier();
        java.awt.Stroke stroke83 = categoryPlot78.getOutlineStroke();
        java.awt.Paint paint84 = null;
        try {
            org.jfree.chart.LegendItem legendItem85 = new org.jfree.chart.LegendItem(attributedString0, "DatasetRenderingOrder.REVERSE", "SortOrder.ASCENDING", "AxisLocation.BOTTOM_OR_LEFT", true, shape10, false, (java.awt.Paint) color12, false, (java.awt.Paint) color14, stroke62, true, shape76, stroke83, paint84);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 255 + "'", int15 == 255);
        org.junit.Assert.assertNull(boolean20);
        org.junit.Assert.assertNull(categoryURLGenerator22);
        org.junit.Assert.assertNull(valueAxis27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 15 + "'", int28 == 15);
        org.junit.Assert.assertNull(collection34);
        org.junit.Assert.assertNull(list37);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertNull(valueAxis60);
        org.junit.Assert.assertNotNull(drawingSupplier61);
        org.junit.Assert.assertNotNull(stroke62);
        org.junit.Assert.assertNotNull(shape68);
        org.junit.Assert.assertNotNull(shape72);
        org.junit.Assert.assertNotNull(shape76);
        org.junit.Assert.assertNull(valueAxis81);
        org.junit.Assert.assertNotNull(drawingSupplier82);
        org.junit.Assert.assertNotNull(stroke83);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.CENTER;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge();
        org.jfree.chart.axis.AxisLocation axisLocation4 = categoryPlot0.getDomainAxisLocation();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        categoryPlot0.drawBackgroundImage(graphics2D5, rectangle2D6);
        categoryPlot0.setRangePannable(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis13 = categoryPlot10.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Point2D point2D16 = null;
        categoryPlot10.zoomDomainAxes((double) 10.0f, plotRenderingInfo15, point2D16, false);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent19 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot10);
        org.jfree.chart.JFreeChart jFreeChart20 = null;
        plotChangeEvent19.setChart(jFreeChart20);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType22 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        plotChangeEvent19.setType(chartChangeEventType22);
        categoryPlot0.notifyListeners(plotChangeEvent19);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNull(valueAxis13);
        org.junit.Assert.assertNotNull(chartChangeEventType22);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = defaultCategoryDataset0.getGroup();
        int int3 = defaultCategoryDataset0.getColumnIndex((java.lang.Comparable) '#');
        org.junit.Assert.assertNotNull(datasetGroup1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier4 = categoryPlot0.getDrawingSupplier();
        java.awt.Paint paint5 = categoryPlot0.getOutlinePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot6.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis9 = categoryPlot6.getRangeAxis();
        int int10 = categoryPlot6.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder11 = categoryPlot6.getRowRenderingOrder();
        java.awt.Stroke stroke12 = categoryPlot6.getRangeZeroBaselineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
        categoryPlot6.rendererChanged(rendererChangeEvent13);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot15.setRangeAxisLocation(axisLocation16, true);
        categoryPlot6.setDomainAxisLocation(axisLocation16);
        categoryPlot6.setCrosshairDatasetIndex((int) (short) 1);
        org.jfree.data.category.CategoryDataset categoryDataset22 = categoryPlot6.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = categoryPlot6.getAxisOffset();
        categoryPlot0.setAxisOffset(rectangleInsets23);
        double double26 = rectangleInsets23.calculateBottomInset(139.0d);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(drawingSupplier4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 15 + "'", int10 == 15);
        org.junit.Assert.assertNotNull(sortOrder11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNull(categoryDataset22);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 4.0d + "'", double26 == 4.0d);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Paint paint5 = lineAndShapeRenderer2.getSeriesPaint(15);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = lineAndShapeRenderer2.getSeriesNegativeItemLabelPosition(255);
        int int8 = lineAndShapeRenderer2.getDefaultEntityRadius();
        java.awt.Stroke stroke9 = lineAndShapeRenderer2.getBaseOutlineStroke();
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot12.setRangeAxisLocation(axisLocation13, true);
        java.lang.Comparable comparable16 = categoryPlot12.getDomainCrosshairColumnKey();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke20 = lineAndShapeRenderer19.getBaseStroke();
        org.jfree.chart.LegendItemCollection legendItemCollection21 = lineAndShapeRenderer19.getLegendItems();
        categoryPlot12.setFixedLegendItems(legendItemCollection21);
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState25 = lineAndShapeRenderer2.initialise(graphics2D10, rectangle2D11, categoryPlot12, categoryDataset23, plotRenderingInfo24);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot12.getDomainAxisEdge();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNull(comparable16);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(legendItemCollection21);
        org.junit.Assert.assertNotNull(categoryItemRendererState25);
        org.junit.Assert.assertNotNull(rectangleEdge26);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        java.awt.Color color1 = null;
        try {
            org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator5 = new org.jfree.chart.util.DefaultShadowGenerator(0, color1, 0.0f, (int) (short) 1, (double) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'color' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor9 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis13 = categoryPlot10.getRangeAxis();
        int int14 = categoryPlot10.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder15 = categoryPlot10.getRowRenderingOrder();
        java.awt.Stroke stroke16 = categoryPlot10.getRangeZeroBaselineStroke();
        categoryPlot0.setRangeMinorGridlineStroke(stroke16);
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = categoryPlot0.getDomainAxis(100);
        boolean boolean20 = categoryPlot0.isNotify();
        categoryPlot0.clearRangeMarkers((int) (short) -1);
        org.jfree.chart.plot.Marker marker23 = null;
        org.jfree.chart.util.Layer layer24 = null;
        boolean boolean25 = categoryPlot0.removeDomainMarker(marker23, layer24);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(categoryAnchor9);
        org.junit.Assert.assertNull(valueAxis13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 15 + "'", int14 == 15);
        org.junit.Assert.assertNotNull(sortOrder15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNull(categoryAxis19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = categoryAxis1.getTickLabelInsets();
        categoryAxis1.setCategoryLabelPositionOffset(0);
        categoryAxis1.setMinorTickMarksVisible(false);
        float float7 = categoryAxis1.getMinorTickMarkOutsideLength();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation9 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot8.setRangeAxisLocation(axisLocation9, true);
        java.lang.Comparable comparable12 = categoryPlot8.getDomainCrosshairColumnKey();
        java.awt.Color color13 = java.awt.Color.yellow;
        java.awt.color.ColorSpace colorSpace14 = color13.getColorSpace();
        float[] floatArray18 = new float[] { (byte) 1, '#', 15 };
        float[] floatArray19 = color13.getRGBColorComponents(floatArray18);
        categoryPlot8.setDomainGridlinePaint((java.awt.Paint) color13);
        boolean boolean21 = categoryAxis1.hasListener((java.util.EventListener) categoryPlot8);
        java.awt.Paint paint22 = categoryPlot8.getRangeMinorGridlinePaint();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 2.0f + "'", float7 == 2.0f);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNull(comparable12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(colorSpace14);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        renderAttributes0.setDefaultFillPaint((java.awt.Paint) color1);
        java.awt.Shape shape5 = renderAttributes0.getItemShape((int) (byte) 100, (int) 'a');
        java.awt.Shape shape7 = null;
        renderAttributes0.setSeriesShape((int) (byte) 1, shape7);
        java.awt.Paint paint9 = renderAttributes0.getDefaultFillPaint();
        java.awt.Paint paint12 = renderAttributes0.getItemOutlinePaint((int) (short) -1, (int) ' ');
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNull(shape5);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(paint12);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Color color1 = color0.darker();
        java.awt.Color color2 = color0.brighter();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis4 = categoryPlot1.getRangeAxis();
        int int5 = categoryPlot1.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder6 = categoryPlot1.getRowRenderingOrder();
        java.awt.Stroke stroke7 = categoryPlot1.getRangeZeroBaselineStroke();
        int int8 = categoryPlot1.getCrosshairDatasetIndex();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer11 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke12 = lineAndShapeRenderer11.getBaseStroke();
        java.awt.Stroke stroke14 = lineAndShapeRenderer11.lookupSeriesStroke(10);
        lineAndShapeRenderer11.setAutoPopulateSeriesStroke(true);
        categoryPlot1.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer11, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator20 = lineAndShapeRenderer11.getSeriesToolTipGenerator((int) (short) 1);
        boolean boolean21 = plotOrientation0.equals((java.lang.Object) (short) 1);
        org.junit.Assert.assertNotNull(plotOrientation0);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
        org.junit.Assert.assertNotNull(sortOrder6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNull(categoryToolTipGenerator20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor9 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis13 = categoryPlot10.getRangeAxis();
        int int14 = categoryPlot10.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder15 = categoryPlot10.getRowRenderingOrder();
        java.awt.Stroke stroke16 = categoryPlot10.getRangeZeroBaselineStroke();
        categoryPlot0.setRangeMinorGridlineStroke(stroke16);
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = categoryPlot0.getDomainAxis(100);
        boolean boolean20 = categoryPlot0.isNotify();
        categoryPlot0.clearAnnotations();
        boolean boolean22 = categoryPlot0.isOutlineVisible();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(categoryAnchor9);
        org.junit.Assert.assertNull(valueAxis13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 15 + "'", int14 == 15);
        org.junit.Assert.assertNotNull(sortOrder15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNull(categoryAxis19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = categoryAxis1.getTickLabelInsets();
        categoryAxis1.setCategoryLabelPositionOffset(0);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        int int9 = categoryPlot5.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot5.getRowRenderingOrder();
        java.awt.Stroke stroke11 = categoryPlot5.getRangeZeroBaselineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        categoryPlot5.rendererChanged(rendererChangeEvent12);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot14.setRangeAxisLocation(axisLocation15, true);
        categoryPlot5.setDomainAxisLocation(axisLocation15);
        categoryPlot5.setCrosshairDatasetIndex((int) (short) 1);
        categoryAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot5);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = categoryAxis1.getLabelInsets();
        java.awt.Paint paint23 = categoryAxis1.getTickMarkPaint();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(paint23);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent9 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot0);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType10 = plotChangeEvent9.getType();
        java.lang.String str11 = chartChangeEventType10.toString();
        java.lang.String str12 = chartChangeEventType10.toString();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(chartChangeEventType10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ChartChangeEventType.GENERAL" + "'", str11.equals("ChartChangeEventType.GENERAL"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "ChartChangeEventType.GENERAL" + "'", str12.equals("ChartChangeEventType.GENERAL"));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = null;
        lineAndShapeRenderer2.setBaseToolTipGenerator(categoryToolTipGenerator6);
        java.awt.Stroke stroke11 = lineAndShapeRenderer2.getItemOutlineStroke(0, 100, true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.chart.axis.AxisLocation axisLocation1 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation2 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation1, plotOrientation2);
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge4 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation0, plotOrientation2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNotNull(plotOrientation2);
        org.junit.Assert.assertNotNull(rectangleEdge3);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Shape shape9 = lineAndShapeRenderer2.getItemShape((int) (short) 10, 100, true);
        java.awt.Paint paint11 = lineAndShapeRenderer2.getSeriesFillPaint((int) (short) 10);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator12 = null;
        lineAndShapeRenderer2.setBaseURLGenerator(categoryURLGenerator12);
        boolean boolean16 = lineAndShapeRenderer2.getItemShapeFilled((int) 'a', 2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator18 = lineAndShapeRenderer2.getSeriesURLGenerator(64);
        int int19 = lineAndShapeRenderer2.getDefaultEntityRadius();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNull(categoryURLGenerator18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 3 + "'", int19 == 3);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent9 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot0);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType10 = plotChangeEvent9.getType();
        java.awt.Color color11 = java.awt.Color.yellow;
        java.awt.color.ColorSpace colorSpace12 = color11.getColorSpace();
        float[] floatArray16 = new float[] { (byte) 1, '#', 15 };
        float[] floatArray17 = color11.getRGBColorComponents(floatArray16);
        boolean boolean18 = chartChangeEventType10.equals((java.lang.Object) floatArray16);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(chartChangeEventType10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(colorSpace12);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier4 = categoryPlot0.getDrawingSupplier();
        double double5 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot6.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = categoryPlot6.getDomainAxisEdge();
        int int10 = categoryPlot6.getWeight();
        java.lang.Comparable comparable11 = categoryPlot6.getDomainCrosshairColumnKey();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke15 = lineAndShapeRenderer14.getBaseStroke();
        java.awt.Paint paint17 = lineAndShapeRenderer14.getSeriesPaint(15);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = lineAndShapeRenderer14.getSeriesNegativeItemLabelPosition(255);
        int int20 = lineAndShapeRenderer14.getDefaultEntityRadius();
        java.awt.Stroke stroke21 = lineAndShapeRenderer14.getBaseOutlineStroke();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator23 = lineAndShapeRenderer14.getSeriesToolTipGenerator(128);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer26 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke27 = lineAndShapeRenderer26.getBaseStroke();
        java.awt.Stroke stroke29 = lineAndShapeRenderer26.lookupSeriesStroke(10);
        java.awt.Shape shape33 = lineAndShapeRenderer26.getItemShape((int) (short) 10, 100, true);
        lineAndShapeRenderer26.setBaseSeriesVisible(false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer38 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke39 = lineAndShapeRenderer38.getBaseStroke();
        java.awt.Stroke stroke41 = lineAndShapeRenderer38.lookupSeriesStroke(10);
        java.awt.Paint paint42 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        lineAndShapeRenderer38.setBaseOutlinePaint(paint42);
        java.awt.Font font44 = lineAndShapeRenderer38.getBaseItemLabelFont();
        java.awt.Paint paint45 = lineAndShapeRenderer38.getBaseFillPaint();
        boolean boolean46 = lineAndShapeRenderer38.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer49 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke50 = lineAndShapeRenderer49.getBaseStroke();
        org.jfree.chart.LegendItemCollection legendItemCollection51 = lineAndShapeRenderer49.getLegendItems();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer54 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke55 = lineAndShapeRenderer54.getBaseStroke();
        java.awt.Paint paint57 = lineAndShapeRenderer54.getSeriesPaint(15);
        double double58 = lineAndShapeRenderer54.getItemLabelAnchorOffset();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer61 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke62 = lineAndShapeRenderer61.getBaseStroke();
        java.awt.Stroke stroke64 = lineAndShapeRenderer61.lookupSeriesStroke(10);
        java.awt.Shape shape68 = lineAndShapeRenderer61.getItemShape((int) (short) 10, 100, true);
        java.awt.Paint paint70 = lineAndShapeRenderer61.getSeriesFillPaint((int) (short) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray71 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { lineAndShapeRenderer14, lineAndShapeRenderer26, lineAndShapeRenderer38, lineAndShapeRenderer49, lineAndShapeRenderer54, lineAndShapeRenderer61 };
        categoryPlot6.setRenderers(categoryItemRendererArray71);
        categoryPlot0.setRenderers(categoryItemRendererArray71);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(drawingSupplier4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNull(comparable11);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNull(paint17);
        org.junit.Assert.assertNotNull(itemLabelPosition19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 3 + "'", int20 == 3);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNull(categoryToolTipGenerator23);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(font44);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNotNull(legendItemCollection51);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNull(paint57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 2.0d + "'", double58 == 2.0d);
        org.junit.Assert.assertNotNull(stroke62);
        org.junit.Assert.assertNotNull(stroke64);
        org.junit.Assert.assertNotNull(shape68);
        org.junit.Assert.assertNull(paint70);
        org.junit.Assert.assertNotNull(categoryItemRendererArray71);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Shape shape9 = lineAndShapeRenderer2.getItemShape((int) (short) 10, 100, true);
        java.awt.Paint paint11 = lineAndShapeRenderer2.getSeriesFillPaint((int) (short) 10);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator12 = null;
        lineAndShapeRenderer2.setBaseURLGenerator(categoryURLGenerator12);
        boolean boolean16 = lineAndShapeRenderer2.getItemShapeFilled((int) 'a', 2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator18 = lineAndShapeRenderer2.getSeriesURLGenerator(64);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer21 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke22 = lineAndShapeRenderer21.getBaseStroke();
        java.awt.Stroke stroke24 = lineAndShapeRenderer21.lookupSeriesStroke(10);
        lineAndShapeRenderer2.setBaseStroke(stroke24);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer29 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke30 = lineAndShapeRenderer29.getBaseStroke();
        java.awt.Stroke stroke32 = lineAndShapeRenderer29.lookupSeriesStroke(10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator34 = null;
        lineAndShapeRenderer29.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator34);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition37 = lineAndShapeRenderer29.getSeriesPositiveItemLabelPosition(0);
        java.awt.Stroke stroke38 = lineAndShapeRenderer29.getBaseStroke();
        lineAndShapeRenderer2.setSeriesOutlineStroke(64, stroke38);
        java.awt.Stroke stroke41 = lineAndShapeRenderer2.getSeriesOutlineStroke((int) (short) 1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNull(categoryURLGenerator18);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(itemLabelPosition37);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNull(stroke41);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isRangeGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getRangeAxisEdge((int) (byte) -1);
        org.jfree.chart.axis.ValueAxis valueAxis4 = categoryPlot0.getRangeAxis();
        java.awt.Stroke stroke5 = categoryPlot0.getRangeGridlineStroke();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        java.awt.Shape shape4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        int int9 = categoryPlot5.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot5.getRowRenderingOrder();
        java.awt.Stroke stroke11 = categoryPlot5.getRangeZeroBaselineStroke();
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("", "", "hi!", "", shape4, stroke11, paint12);
        legendItem13.setDescription("");
        int int16 = legendItem13.getDatasetIndex();
        java.lang.String str17 = legendItem13.getLabel();
        java.lang.String str18 = legendItem13.getLabel();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset19 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo20 = new org.jfree.chart.event.DatasetChangeInfo();
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent21 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object) legendItem13, (org.jfree.data.general.Dataset) defaultCategoryDataset19, datasetChangeInfo20);
        defaultCategoryDataset19.clearSelection();
        int int23 = defaultCategoryDataset19.getRowCount();
        try {
            java.lang.Number number26 = defaultCategoryDataset19.getValue((java.lang.Comparable) (short) 1, (java.lang.Comparable) 1);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Row key (1) not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        java.lang.Comparable comparable9 = categoryPlot0.getDomainCrosshairColumnKey();
        boolean boolean10 = categoryPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = categoryPlot0.getAxisOffset();
        boolean boolean12 = categoryPlot0.isRangeZoomable();
        try {
            categoryPlot0.zoom((double) (-256));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNull(comparable9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.axis.AxisSpace axisSpace5 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace5, true);
        org.jfree.chart.plot.Marker marker8 = null;
        boolean boolean9 = categoryPlot0.removeDomainMarker(marker8);
        org.jfree.chart.plot.Marker marker10 = null;
        try {
            categoryPlot0.addRangeMarker(marker10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.LegendItem legendItem2 = new org.jfree.chart.LegendItem("ItemLabelAnchor.OUTSIDE1", (java.awt.Paint) color1);
        java.lang.String str3 = legendItem2.getURLText();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.chart.renderer.category.BarPainter barPainter0 = org.jfree.chart.renderer.category.BarRenderer.getDefaultBarPainter();
        org.jfree.chart.renderer.category.BarRenderer.setDefaultBarPainter(barPainter0);
        org.junit.Assert.assertNotNull(barPainter0);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.getSeriesStroke((int) ' ');
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(stroke5);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        lineAndShapeRenderer2.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator7);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = null;
        lineAndShapeRenderer2.setSeriesURLGenerator(0, categoryURLGenerator10);
        lineAndShapeRenderer2.setSeriesShapesVisible(64, true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset0 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis4 = categoryPlot1.getRangeAxis();
        int int5 = categoryPlot1.getBackgroundImageAlignment();
        categoryPlot1.setDomainCrosshairColumnKey((java.lang.Comparable) (short) -1, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot1.zoomRangeAxes((double) (byte) 1, plotRenderingInfo10, point2D11, true);
        abstractCategoryDataset0.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot1);
        org.jfree.chart.plot.Marker marker15 = null;
        try {
            categoryPlot1.addRangeMarker(marker15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        lineAndShapeRenderer2.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator7);
        lineAndShapeRenderer2.setSeriesVisible((int) (short) 100, (java.lang.Boolean) false, true);
        boolean boolean15 = lineAndShapeRenderer2.getItemShapeVisible((int) (short) 10, 3);
        java.awt.Font font16 = lineAndShapeRenderer2.getBaseLegendTextFont();
        lineAndShapeRenderer2.setUseFillPaint(false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer21 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke22 = lineAndShapeRenderer21.getBaseStroke();
        java.awt.Stroke stroke24 = lineAndShapeRenderer21.lookupSeriesStroke(10);
        lineAndShapeRenderer21.setBaseSeriesVisibleInLegend(false, true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer31 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke32 = lineAndShapeRenderer31.getBaseStroke();
        java.awt.Paint paint34 = lineAndShapeRenderer31.getSeriesPaint(15);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition36 = lineAndShapeRenderer31.getSeriesNegativeItemLabelPosition(255);
        lineAndShapeRenderer21.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition36);
        java.awt.Shape shape41 = lineAndShapeRenderer21.getItemShape(2, 0, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition45 = lineAndShapeRenderer21.getNegativeItemLabelPosition((int) (short) 0, 255, true);
        lineAndShapeRenderer2.setBaseNegativeItemLabelPosition(itemLabelPosition45, true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(font16);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNull(paint34);
        org.junit.Assert.assertNotNull(itemLabelPosition36);
        org.junit.Assert.assertNotNull(shape41);
        org.junit.Assert.assertNotNull(itemLabelPosition45);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder5 = categoryPlot0.getRowRenderingOrder();
        java.awt.Stroke stroke6 = categoryPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = categoryPlot0.getInsets();
        double double9 = rectangleInsets7.calculateRightInset((double) 0.0f);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(sortOrder5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 8.0d + "'", double9 == 8.0d);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        categoryPlot0.setDomainCrosshairColumnKey((java.lang.Comparable) (short) -1, true);
        org.jfree.chart.util.Layer layer9 = null;
        java.util.Collection collection10 = categoryPlot0.getRangeMarkers((int) (short) 0, layer9);
        categoryPlot0.setRangeCrosshairLockedOnData(false);
        java.lang.Comparable comparable13 = categoryPlot0.getDomainCrosshairColumnKey();
        java.lang.Class<?> wildcardClass14 = categoryPlot0.getClass();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = categoryPlot0.getInsets();
        double double17 = rectangleInsets15.trimHeight((double) 10L);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNull(collection10);
        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + (short) -1 + "'", comparable13.equals((short) -1));
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 2.0d + "'", double17 == 2.0d);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        boolean boolean2 = gradientPaintTransformType0.equals((java.lang.Object) 10.0d);
        java.awt.Paint paint3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        boolean boolean4 = gradientPaintTransformType0.equals((java.lang.Object) paint3);
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        categoryPlot0.setDomainCrosshairColumnKey((java.lang.Comparable) (short) -1, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot0.zoomRangeAxes((double) (byte) 1, plotRenderingInfo9, point2D10, true);
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) 0.0f, false);
        org.jfree.chart.plot.Plot plot16 = categoryPlot0.getRootPlot();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(plot16);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        java.awt.Color color2 = java.awt.Color.yellow;
        java.awt.color.ColorSpace colorSpace3 = color2.getColorSpace();
        int int4 = color2.getTransparency();
        paintList0.setPaint(0, (java.awt.Paint) color2);
        java.awt.Paint paint7 = paintList0.getPaint((int) (short) -1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(colorSpace3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNull(paint7);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        java.awt.Shape shape4 = null;
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem6 = new org.jfree.chart.LegendItem("", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", shape4, (java.awt.Paint) color5);
        java.awt.Shape shape7 = legendItem6.getShape();
        java.awt.Paint paint8 = legendItem6.getLinePaint();
        java.awt.Paint paint9 = legendItem6.getLinePaint();
        java.awt.Paint paint10 = legendItem6.getOutlinePaint();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor11 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE5;
        java.awt.Color color12 = java.awt.Color.white;
        boolean boolean13 = itemLabelAnchor11.equals((java.lang.Object) color12);
        legendItem6.setOutlinePaint((java.awt.Paint) color12);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(shape7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(itemLabelAnchor11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor9 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis13 = categoryPlot10.getRangeAxis();
        int int14 = categoryPlot10.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder15 = categoryPlot10.getRowRenderingOrder();
        java.awt.Stroke stroke16 = categoryPlot10.getRangeZeroBaselineStroke();
        categoryPlot0.setRangeMinorGridlineStroke(stroke16);
        java.awt.Stroke stroke18 = categoryPlot0.getDomainGridlineStroke();
        org.jfree.chart.LegendItemCollection legendItemCollection19 = categoryPlot0.getLegendItems();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(categoryAnchor9);
        org.junit.Assert.assertNull(valueAxis13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 15 + "'", int14 == 15);
        org.junit.Assert.assertNotNull(sortOrder15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(legendItemCollection19);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Shape shape11 = null;
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", shape11, (java.awt.Paint) color12);
        int int14 = color12.getBlue();
        lineAndShapeRenderer2.setSeriesItemLabelPaint((int) (byte) 1, (java.awt.Paint) color12);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean17 = categoryPlot16.isRangeGridlinesVisible();
        categoryPlot16.clearDomainAxes();
        lineAndShapeRenderer2.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot16);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator20 = lineAndShapeRenderer2.getLegendItemToolTipGenerator();
        lineAndShapeRenderer2.setSeriesShapesVisible((int) (byte) 100, true);
        java.awt.Paint paint25 = lineAndShapeRenderer2.lookupSeriesOutlinePaint(2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 128 + "'", int14 == 128);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator20);
        org.junit.Assert.assertNotNull(paint25);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        lineAndShapeRenderer2.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator7);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = lineAndShapeRenderer2.getSeriesPositiveItemLabelPosition(0);
        lineAndShapeRenderer2.setBaseShapesFilled(false);
        lineAndShapeRenderer2.setSeriesShapesVisible(2, (java.lang.Boolean) true);
        java.awt.Font font16 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        lineAndShapeRenderer2.setBaseItemLabelFont(font16, false);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertNotNull(font16);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder5 = categoryPlot0.getRowRenderingOrder();
        categoryPlot0.setWeight((int) (short) 100);
        int int8 = categoryPlot0.getDomainAxisCount();
        java.lang.Object obj9 = categoryPlot0.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis13 = categoryPlot10.getRangeAxis();
        java.awt.Paint paint14 = categoryPlot10.getDomainGridlinePaint();
        categoryPlot0.setDomainCrosshairPaint(paint14);
        categoryPlot0.setBackgroundImageAlignment(100);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        categoryPlot0.zoomRangeAxes((double) 100, plotRenderingInfo19, point2D20);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(sortOrder5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(valueAxis13);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot0.setRangeAxisLocation(axisLocation1, true);
        java.lang.Comparable comparable4 = categoryPlot0.getDomainCrosshairColumnKey();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke8 = lineAndShapeRenderer7.getBaseStroke();
        org.jfree.chart.LegendItemCollection legendItemCollection9 = lineAndShapeRenderer7.getLegendItems();
        categoryPlot0.setFixedLegendItems(legendItemCollection9);
        categoryPlot0.setDomainGridlinesVisible(true);
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNull(comparable4);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(legendItemCollection9);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge();
        org.jfree.chart.axis.AxisLocation axisLocation4 = categoryPlot0.getDomainAxisLocation();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        categoryPlot0.drawBackgroundImage(graphics2D5, rectangle2D6);
        java.awt.Paint paint8 = categoryPlot0.getNoDataMessagePaint();
        float float9 = categoryPlot0.getBackgroundAlpha();
        boolean boolean10 = categoryPlot0.isRangeCrosshairLockedOnData();
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 1.0f + "'", float9 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        int int2 = keyedObjects0.getIndex((java.lang.Comparable) (short) 100);
        java.util.List list3 = keyedObjects0.getKeys();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor5 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE10;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot6.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis9 = categoryPlot6.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot6.zoomDomainAxes((double) 10.0f, plotRenderingInfo11, point2D12, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor15 = categoryPlot6.getDomainGridlinePosition();
        boolean boolean16 = itemLabelAnchor5.equals((java.lang.Object) categoryAnchor15);
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot17.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis20 = categoryPlot17.getRangeAxis();
        int int21 = categoryPlot17.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot17.getRowRenderingOrder();
        categoryPlot17.setWeight((int) (short) 100);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder25 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        categoryPlot17.setDatasetRenderingOrder(datasetRenderingOrder25);
        boolean boolean27 = categoryAnchor15.equals((java.lang.Object) categoryPlot17);
        boolean boolean28 = categoryPlot17.isDomainZoomable();
        java.awt.Paint paint29 = categoryPlot17.getNoDataMessagePaint();
        keyedObjects0.setObject((java.lang.Comparable) 0.0f, (java.lang.Object) categoryPlot17);
        org.jfree.chart.util.SortOrder sortOrder31 = org.jfree.chart.util.SortOrder.ASCENDING;
        java.lang.String str32 = sortOrder31.toString();
        keyedObjects0.sortByKeys(sortOrder31);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNotNull(itemLabelAnchor5);
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertNotNull(categoryAnchor15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(valueAxis20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 15 + "'", int21 == 15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(datasetRenderingOrder25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(sortOrder31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "SortOrder.ASCENDING" + "'", str32.equals("SortOrder.ASCENDING"));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge();
        org.jfree.chart.axis.AxisLocation axisLocation4 = categoryPlot0.getDomainAxisLocation();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = categoryPlot0.getAxisOffset();
        java.awt.geom.GeneralPath generalPath6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.RenderingSource renderingSource8 = null;
        categoryPlot0.select(generalPath6, rectangle2D7, renderingSource8);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        java.awt.Paint paint5 = categoryPlot0.getNoDataMessagePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = categoryPlot0.getDomainAxisForDataset((int) 'a');
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke11 = lineAndShapeRenderer10.getBaseStroke();
        org.jfree.chart.LegendItemCollection legendItemCollection12 = lineAndShapeRenderer10.getLegendItems();
        int int13 = legendItemCollection12.getItemCount();
        categoryPlot0.setFixedLegendItems(legendItemCollection12);
        org.jfree.chart.LegendItemCollection legendItemCollection15 = null;
        try {
            legendItemCollection12.addAll(legendItemCollection15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(categoryAxis7);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(legendItemCollection12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis4 = categoryPlot1.getRangeAxis();
        int int5 = categoryPlot1.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder6 = categoryPlot1.getRowRenderingOrder();
        java.awt.Stroke stroke7 = categoryPlot1.getRangeZeroBaselineStroke();
        categoryPlot1.setRangeGridlinesVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis13 = categoryPlot10.getRangeAxis();
        int int14 = categoryPlot10.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder15 = categoryPlot10.getRowRenderingOrder();
        java.awt.Stroke stroke16 = categoryPlot10.getRangeZeroBaselineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent17 = null;
        categoryPlot10.rendererChanged(rendererChangeEvent17);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation20 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot19.setRangeAxisLocation(axisLocation20, true);
        categoryPlot10.setDomainAxisLocation(axisLocation20);
        categoryPlot1.setDomainAxisLocation(axisLocation20, true);
        categoryPlot1.setBackgroundAlpha((float) 10);
        boolean boolean28 = defaultDrawingSupplier0.equals((java.lang.Object) 10);
        java.awt.Paint paint29 = defaultDrawingSupplier0.getNextOutlinePaint();
        java.awt.Paint paint30 = defaultDrawingSupplier0.getNextFillPaint();
        java.awt.Color color31 = java.awt.Color.blue;
        boolean boolean32 = defaultDrawingSupplier0.equals((java.lang.Object) color31);
        java.awt.Stroke stroke33 = defaultDrawingSupplier0.getNextStroke();
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
        org.junit.Assert.assertNotNull(sortOrder6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(valueAxis13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 15 + "'", int14 == 15);
        org.junit.Assert.assertNotNull(sortOrder15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(stroke33);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge();
        org.jfree.chart.axis.AxisLocation axisLocation4 = categoryPlot0.getDomainAxisLocation();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        categoryPlot0.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        categoryPlot0.setRenderer(categoryItemRenderer8);
        java.awt.Paint paint10 = categoryPlot0.getDomainGridlinePaint();
        categoryPlot0.clearDomainAxes();
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = categoryAxis1.getTickLabelInsets();
        categoryAxis1.setCategoryLabelPositionOffset(0);
        categoryAxis1.setMinorTickMarksVisible(false);
        float float7 = categoryAxis1.getMinorTickMarkOutsideLength();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = categoryAxis1.getLabelInsets();
        categoryAxis1.setTickLabelsVisible(false);
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot14.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = categoryPlot14.getDomainAxisEdge();
        org.jfree.chart.axis.AxisLocation axisLocation18 = categoryPlot14.getDomainAxisLocation();
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = categoryPlot14.getDomainAxisEdge();
        try {
            double double20 = categoryAxis1.getCategoryStart(64, (int) (short) -1, rectangle2D13, rectangleEdge19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 2.0f + "'", float7 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(rectangleEdge19);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Paint paint5 = lineAndShapeRenderer2.getSeriesPaint(15);
        double double6 = lineAndShapeRenderer2.getItemLabelAnchorOffset();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = lineAndShapeRenderer2.getSeriesPositiveItemLabelPosition((-1));
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.0d + "'", double6 == 2.0d);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        java.awt.Paint paint5 = categoryPlot0.getNoDataMessagePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = categoryPlot0.getDomainAxisForDataset((int) 'a');
        java.awt.Paint paint8 = categoryPlot0.getDomainCrosshairPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot9.setRangeAxisLocation(axisLocation10, true);
        java.lang.Comparable comparable13 = categoryPlot9.getDomainCrosshairColumnKey();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer16 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke17 = lineAndShapeRenderer16.getBaseStroke();
        org.jfree.chart.LegendItemCollection legendItemCollection18 = lineAndShapeRenderer16.getLegendItems();
        categoryPlot9.setFixedLegendItems(legendItemCollection18);
        categoryPlot0.setFixedLegendItems(legendItemCollection18);
        java.lang.Object obj21 = legendItemCollection18.clone();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(categoryAxis7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNull(comparable13);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(legendItemCollection18);
        org.junit.Assert.assertNotNull(obj21);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        java.awt.Shape shape4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        int int9 = categoryPlot5.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot5.getRowRenderingOrder();
        java.awt.Stroke stroke11 = categoryPlot5.getRangeZeroBaselineStroke();
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("", "", "hi!", "", shape4, stroke11, paint12);
        legendItem13.setDescription("");
        int int16 = legendItem13.getDatasetIndex();
        java.lang.String str17 = legendItem13.getLabel();
        java.lang.String str18 = legendItem13.getLabel();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset19 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo20 = new org.jfree.chart.event.DatasetChangeInfo();
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent21 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object) legendItem13, (org.jfree.data.general.Dataset) defaultCategoryDataset19, datasetChangeInfo20);
        defaultCategoryDataset19.clearSelection();
        int int23 = defaultCategoryDataset19.getRowCount();
        int int25 = defaultCategoryDataset19.getColumnIndex((java.lang.Comparable) "AxisLocation.BOTTOM_OR_LEFT");
        defaultCategoryDataset19.fireSelectionEvent();
        try {
            defaultCategoryDataset19.removeRow((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot3.getRangeAxis();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier7 = categoryPlot3.getDrawingSupplier();
        org.jfree.data.category.CategoryDataset categoryDataset8 = categoryPlot3.getDataset();
        org.jfree.chart.renderer.RenderAttributes renderAttributes9 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        renderAttributes9.setDefaultFillPaint((java.awt.Paint) color10);
        categoryPlot3.setBackgroundPaint((java.awt.Paint) color10);
        lineAndShapeRenderer2.setPlot(categoryPlot3);
        lineAndShapeRenderer2.setBaseShapesFilled(true);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(drawingSupplier7);
        org.junit.Assert.assertNull(categoryDataset8);
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = categoryAxis1.getTickLabelInsets();
        categoryAxis1.setCategoryLabelPositionOffset(0);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        int int9 = categoryPlot5.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot5.getRowRenderingOrder();
        java.awt.Stroke stroke11 = categoryPlot5.getRangeZeroBaselineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        categoryPlot5.rendererChanged(rendererChangeEvent12);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot14.setRangeAxisLocation(axisLocation15, true);
        categoryPlot5.setDomainAxisLocation(axisLocation15);
        categoryPlot5.setCrosshairDatasetIndex((int) (short) 1);
        categoryAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot5);
        categoryAxis1.setUpperMargin((double) 100.0f);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(axisLocation15);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isRangeGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getRangeAxisEdge((int) (byte) -1);
        boolean boolean4 = categoryPlot0.canSelectByRegion();
        java.awt.Color color8 = java.awt.Color.getHSBColor((float) (short) 1, (float) 100, 0.0f);
        float[] floatArray15 = new float[] { (byte) 10, (byte) 1, 1.0f, (byte) 0, 10, (byte) 100 };
        float[] floatArray16 = color8.getRGBComponents(floatArray15);
        java.lang.String str17 = color8.toString();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color8);
        java.awt.Font font19 = null;
        try {
            categoryPlot0.setNoDataMessageFont(font19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "java.awt.Color[r=0,g=0,b=0]" + "'", str17.equals("java.awt.Color[r=0,g=0,b=0]"));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        try {
            java.lang.Object obj2 = keyedObjects0.getObject((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge();
        org.jfree.chart.axis.AxisLocation axisLocation4 = categoryPlot0.getDomainAxisLocation();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        categoryPlot0.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        categoryPlot0.setRenderer(categoryItemRenderer8);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot11.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis14 = categoryPlot11.getRangeAxis();
        int int15 = categoryPlot11.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder16 = categoryPlot11.getRowRenderingOrder();
        java.awt.Stroke stroke17 = categoryPlot11.getRangeZeroBaselineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent18 = null;
        categoryPlot11.rendererChanged(rendererChangeEvent18);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation21 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot20.setRangeAxisLocation(axisLocation21, true);
        categoryPlot11.setDomainAxisLocation(axisLocation21);
        try {
            categoryPlot0.setRangeAxisLocation((-256), axisLocation21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNull(valueAxis14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 15 + "'", int15 == 15);
        org.junit.Assert.assertNotNull(sortOrder16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(axisLocation21);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent9 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot0);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType10 = plotChangeEvent9.getType();
        org.jfree.chart.JFreeChart jFreeChart11 = plotChangeEvent9.getChart();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(chartChangeEventType10);
        org.junit.Assert.assertNull(jFreeChart11);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Shape shape9 = lineAndShapeRenderer2.getItemShape((int) (short) 10, 100, true);
        lineAndShapeRenderer2.setBaseSeriesVisible(false);
        java.awt.Shape shape12 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity15 = new org.jfree.chart.entity.ChartEntity(shape12, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape16 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity19 = new org.jfree.chart.entity.ChartEntity(shape16, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape20 = chartEntity19.getArea();
        chartEntity15.setArea(shape20);
        lineAndShapeRenderer2.setBaseShape(shape20, true);
        java.lang.Boolean boolean25 = lineAndShapeRenderer2.getSeriesShapesVisible(1);
        lineAndShapeRenderer2.setSeriesCreateEntities(156, (java.lang.Boolean) false);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNull(boolean25);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_INSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.0f + "'", float0 == 0.0f);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Shape shape9 = lineAndShapeRenderer2.getItemShape((int) (short) 10, 100, true);
        lineAndShapeRenderer2.setBaseSeriesVisible(false);
        java.awt.Shape shape12 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity15 = new org.jfree.chart.entity.ChartEntity(shape12, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape16 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity19 = new org.jfree.chart.entity.ChartEntity(shape16, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape20 = chartEntity19.getArea();
        chartEntity15.setArea(shape20);
        lineAndShapeRenderer2.setBaseShape(shape20, true);
        java.lang.Boolean boolean25 = lineAndShapeRenderer2.getSeriesShapesVisible(1);
        java.awt.Font font26 = lineAndShapeRenderer2.getBaseItemLabelFont();
        lineAndShapeRenderer2.setSeriesShapesVisible(1, true);
        lineAndShapeRenderer2.setBaseSeriesVisible(false);
        java.lang.Boolean boolean33 = lineAndShapeRenderer2.getSeriesCreateEntities((-16728064));
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator35 = null;
        lineAndShapeRenderer2.setSeriesToolTipGenerator(156, categoryToolTipGenerator35, false);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNull(boolean25);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNull(boolean33);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Paint paint5 = lineAndShapeRenderer2.getSeriesPaint(15);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = lineAndShapeRenderer2.getSeriesNegativeItemLabelPosition(255);
        int int8 = lineAndShapeRenderer2.getDefaultEntityRadius();
        java.awt.Stroke stroke9 = lineAndShapeRenderer2.getBaseOutlineStroke();
        lineAndShapeRenderer2.setUseOutlinePaint(false);
        boolean boolean12 = lineAndShapeRenderer2.getBaseSeriesVisibleInLegend();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        categoryPlot0.setDomainCrosshairColumnKey((java.lang.Comparable) (short) -1, true);
        java.awt.Stroke stroke8 = categoryPlot0.getDomainGridlineStroke();
        int int9 = categoryPlot0.getCrosshairDatasetIndex();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot0.zoomDomainAxes((double) (-1.0f), plotRenderingInfo11, point2D12, false);
        boolean boolean15 = categoryPlot0.isSubplot();
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        int int17 = categoryPlot0.indexOf(categoryDataset16);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.clearSeriesStrokes(true);
        lineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.renderer.RenderAttributes renderAttributes7 = new org.jfree.chart.renderer.RenderAttributes(true);
        java.awt.Color color9 = java.awt.Color.magenta;
        renderAttributes7.setSeriesOutlinePaint(128, (java.awt.Paint) color9);
        lineAndShapeRenderer0.setSeriesItemLabelPaint((int) (short) 1, (java.awt.Paint) color9);
        boolean boolean14 = lineAndShapeRenderer0.getItemShapeVisible(0, 255);
        lineAndShapeRenderer0.setSeriesItemLabelsVisible(64, (java.lang.Boolean) false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        java.lang.Object obj0 = null;
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset1 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.category.CategoryDatasetSelectionState categoryDatasetSelectionState2 = null;
        abstractCategoryDataset1.setSelectionState(categoryDatasetSelectionState2);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot4.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis7 = categoryPlot4.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot4.zoomDomainAxes((double) 10.0f, plotRenderingInfo9, point2D10, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor13 = categoryPlot4.getDomainGridlinePosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot14.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis17 = categoryPlot14.getRangeAxis();
        int int18 = categoryPlot14.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder19 = categoryPlot14.getRowRenderingOrder();
        java.awt.Stroke stroke20 = categoryPlot14.getRangeZeroBaselineStroke();
        categoryPlot4.setRangeMinorGridlineStroke(stroke20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = categoryPlot4.getRangeAxis(1);
        boolean boolean24 = abstractCategoryDataset1.hasListener((java.util.EventListener) categoryPlot4);
        java.awt.Shape shape29 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot30.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis33 = categoryPlot30.getRangeAxis();
        int int34 = categoryPlot30.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder35 = categoryPlot30.getRowRenderingOrder();
        java.awt.Stroke stroke36 = categoryPlot30.getRangeZeroBaselineStroke();
        java.awt.Paint paint37 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem38 = new org.jfree.chart.LegendItem("", "", "hi!", "", shape29, stroke36, paint37);
        legendItem38.setDescription("");
        int int41 = legendItem38.getDatasetIndex();
        java.lang.String str42 = legendItem38.getLabel();
        java.lang.String str43 = legendItem38.getLabel();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset44 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo45 = new org.jfree.chart.event.DatasetChangeInfo();
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent46 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object) legendItem38, (org.jfree.data.general.Dataset) defaultCategoryDataset44, datasetChangeInfo45);
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo47 = datasetChangeEvent46.getInfo();
        try {
            org.jfree.data.event.DatasetChangeEvent datasetChangeEvent48 = new org.jfree.data.event.DatasetChangeEvent(obj0, (org.jfree.data.general.Dataset) abstractCategoryDataset1, datasetChangeInfo47);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNotNull(categoryAnchor13);
        org.junit.Assert.assertNull(valueAxis17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 15 + "'", int18 == 15);
        org.junit.Assert.assertNotNull(sortOrder19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(valueAxis33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 15 + "'", int34 == 15);
        org.junit.Assert.assertNotNull(sortOrder35);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "" + "'", str42.equals(""));
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "" + "'", str43.equals(""));
        org.junit.Assert.assertNotNull(datasetChangeInfo47);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        renderAttributes0.setDefaultFillPaint((java.awt.Paint) color1);
        java.awt.Stroke stroke4 = renderAttributes0.getSeriesStroke((int) ' ');
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity9 = new org.jfree.chart.entity.ChartEntity(shape6, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape10 = chartEntity9.getArea();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot11.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis14 = categoryPlot11.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        categoryPlot11.zoomDomainAxes((double) 10.0f, plotRenderingInfo16, point2D17, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor20 = categoryPlot11.getDomainGridlinePosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot21.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis24 = categoryPlot21.getRangeAxis();
        int int25 = categoryPlot21.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder26 = categoryPlot21.getRowRenderingOrder();
        java.awt.Stroke stroke27 = categoryPlot21.getRangeZeroBaselineStroke();
        categoryPlot11.setRangeMinorGridlineStroke(stroke27);
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = categoryPlot11.getDomainAxis(100);
        boolean boolean31 = categoryPlot11.isNotify();
        org.jfree.chart.entity.PlotEntity plotEntity33 = new org.jfree.chart.entity.PlotEntity(shape10, (org.jfree.chart.plot.Plot) categoryPlot11, "ItemLabelAnchor.OUTSIDE1");
        renderAttributes0.setSeriesShape((int) (byte) 100, shape10);
        renderAttributes0.setDefaultCreateEntity((java.lang.Boolean) false);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNull(stroke4);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNull(valueAxis14);
        org.junit.Assert.assertNotNull(categoryAnchor20);
        org.junit.Assert.assertNull(valueAxis24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 15 + "'", int25 == 15);
        org.junit.Assert.assertNotNull(sortOrder26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNull(categoryAxis30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = categoryAxis1.getTickLabelInsets();
        categoryAxis1.setCategoryLabelPositionOffset(0);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        int int9 = categoryPlot5.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot5.getRowRenderingOrder();
        java.awt.Stroke stroke11 = categoryPlot5.getRangeZeroBaselineStroke();
        int int12 = categoryPlot5.getCrosshairDatasetIndex();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke16 = lineAndShapeRenderer15.getBaseStroke();
        java.awt.Stroke stroke18 = lineAndShapeRenderer15.lookupSeriesStroke(10);
        lineAndShapeRenderer15.setAutoPopulateSeriesStroke(true);
        categoryPlot5.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer15, true);
        categoryAxis1.setPlot((org.jfree.chart.plot.Plot) categoryPlot5);
        categoryAxis1.setCategoryMargin((double) 100L);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = null;
        try {
            categoryAxis1.setLabelInsets(rectangleInsets26, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        java.awt.Shape shape4 = null;
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem6 = new org.jfree.chart.LegendItem("", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", shape4, (java.awt.Paint) color5);
        java.awt.Shape shape7 = legendItem6.getShape();
        int int8 = legendItem6.getSeriesIndex();
        boolean boolean9 = legendItem6.isShapeVisible();
        int int10 = legendItem6.getDatasetIndex();
        legendItem6.setLineVisible(false);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(shape7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent9 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot0);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType10 = plotChangeEvent9.getType();
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        plotChangeEvent9.setChart(jFreeChart11);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(chartChangeEventType10);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier4 = categoryPlot0.getDrawingSupplier();
        java.awt.Paint paint5 = categoryPlot0.getOutlinePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot6.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis9 = categoryPlot6.getRangeAxis();
        int int10 = categoryPlot6.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder11 = categoryPlot6.getRowRenderingOrder();
        java.awt.Stroke stroke12 = categoryPlot6.getRangeZeroBaselineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
        categoryPlot6.rendererChanged(rendererChangeEvent13);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot15.setRangeAxisLocation(axisLocation16, true);
        categoryPlot6.setDomainAxisLocation(axisLocation16);
        categoryPlot6.setCrosshairDatasetIndex((int) (short) 1);
        org.jfree.data.category.CategoryDataset categoryDataset22 = categoryPlot6.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = categoryPlot6.getAxisOffset();
        categoryPlot0.setAxisOffset(rectangleInsets23);
        boolean boolean25 = categoryPlot0.isRangeMinorGridlinesVisible();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(drawingSupplier4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 15 + "'", int10 == 15);
        org.junit.Assert.assertNotNull(sortOrder11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNull(categoryDataset22);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        org.jfree.chart.LegendItemCollection legendItemCollection4 = lineAndShapeRenderer2.getLegendItems();
        int int5 = lineAndShapeRenderer2.getRowCount();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(legendItemCollection4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Paint paint6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        lineAndShapeRenderer2.setBaseOutlinePaint(paint6);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = lineAndShapeRenderer2.getSeriesPositiveItemLabelPosition((int) (short) -1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryPlot0.getAxisOffset();
        boolean boolean4 = categoryPlot0.isDomainGridlinesVisible();
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = categoryAxis1.getTickLabelInsets();
        categoryAxis1.setCategoryLabelPositionOffset(0);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        int int9 = categoryPlot5.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot5.getRowRenderingOrder();
        java.awt.Stroke stroke11 = categoryPlot5.getRangeZeroBaselineStroke();
        int int12 = categoryPlot5.getCrosshairDatasetIndex();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke16 = lineAndShapeRenderer15.getBaseStroke();
        java.awt.Stroke stroke18 = lineAndShapeRenderer15.lookupSeriesStroke(10);
        lineAndShapeRenderer15.setAutoPopulateSeriesStroke(true);
        categoryPlot5.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer15, true);
        categoryAxis1.setPlot((org.jfree.chart.plot.Plot) categoryPlot5);
        java.lang.Object obj24 = categoryAxis1.clone();
        java.awt.Graphics2D graphics2D25 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.axis.AxisLocation axisLocation29 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation30 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation29, plotOrientation30);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        try {
            org.jfree.chart.axis.AxisState axisState33 = categoryAxis1.draw(graphics2D25, (double) 100.0f, rectangle2D27, rectangle2D28, rectangleEdge31, plotRenderingInfo32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertNotNull(axisLocation29);
        org.junit.Assert.assertNotNull(plotOrientation30);
        org.junit.Assert.assertNotNull(rectangleEdge31);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape0, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity(shape4, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape8 = chartEntity7.getArea();
        chartEntity3.setArea(shape8);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis13 = categoryPlot10.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Point2D point2D16 = null;
        categoryPlot10.zoomDomainAxes((double) 10.0f, plotRenderingInfo15, point2D16, false);
        java.lang.Comparable comparable19 = categoryPlot10.getDomainCrosshairColumnKey();
        boolean boolean20 = categoryPlot10.isRangeCrosshairLockedOnData();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = categoryPlot10.getAxisOffset();
        categoryPlot10.configureDomainAxes();
        org.jfree.chart.entity.PlotEntity plotEntity23 = new org.jfree.chart.entity.PlotEntity(shape8, (org.jfree.chart.plot.Plot) categoryPlot10);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNull(valueAxis13);
        org.junit.Assert.assertNull(comparable19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(rectangleInsets21);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets0.createOutsetRectangle(rectangle2D1, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        java.awt.Shape shape4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        int int9 = categoryPlot5.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot5.getRowRenderingOrder();
        java.awt.Stroke stroke11 = categoryPlot5.getRangeZeroBaselineStroke();
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("", "", "hi!", "", shape4, stroke11, paint12);
        legendItem13.setDescription("");
        int int16 = legendItem13.getDatasetIndex();
        java.lang.String str17 = legendItem13.getLabel();
        java.lang.String str18 = legendItem13.getLabel();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset19 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo20 = new org.jfree.chart.event.DatasetChangeInfo();
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent21 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object) legendItem13, (org.jfree.data.general.Dataset) defaultCategoryDataset19, datasetChangeInfo20);
        defaultCategoryDataset19.addValue((java.lang.Number) 1.0d, (java.lang.Comparable) false, (java.lang.Comparable) (byte) 1);
        java.lang.Comparable comparable27 = defaultCategoryDataset19.getColumnKey(0);
        try {
            defaultCategoryDataset19.setSelected(1, (int) (short) 10, true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + comparable27 + "' != '" + (byte) 1 + "'", comparable27.equals((byte) 1));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder5 = categoryPlot0.getRowRenderingOrder();
        java.awt.Stroke stroke6 = categoryPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent7 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent7);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot9.setRangeAxisLocation(axisLocation10, true);
        categoryPlot0.setDomainAxisLocation(axisLocation10);
        categoryPlot0.setCrosshairDatasetIndex((int) (short) 1);
        java.awt.Image image16 = categoryPlot0.getBackgroundImage();
        java.awt.Paint paint17 = categoryPlot0.getOutlinePaint();
        org.jfree.chart.plot.PlotOrientation plotOrientation18 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        categoryPlot0.setOrientation(plotOrientation18);
        org.jfree.chart.plot.Marker marker21 = null;
        org.jfree.chart.util.Layer layer22 = null;
        try {
            categoryPlot0.addRangeMarker((int) 'a', marker21, layer22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(sortOrder5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNull(image16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(plotOrientation18);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.awt.Color color4 = java.awt.Color.getHSBColor((float) (short) 1, (float) 100, 0.0f);
        float[] floatArray11 = new float[] { (byte) 10, (byte) 1, 1.0f, (byte) 0, 10, (byte) 100 };
        float[] floatArray12 = color4.getRGBComponents(floatArray11);
        float[] floatArray13 = color0.getColorComponents(floatArray11);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot14.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis17 = categoryPlot14.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        categoryPlot14.zoomDomainAxes((double) 10.0f, plotRenderingInfo19, point2D20, false);
        java.lang.Comparable comparable23 = categoryPlot14.getDomainCrosshairColumnKey();
        boolean boolean24 = categoryPlot14.isRangeCrosshairLockedOnData();
        boolean boolean25 = color0.equals((java.lang.Object) boolean24);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNull(valueAxis17);
        org.junit.Assert.assertNull(comparable23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Paint paint5 = lineAndShapeRenderer2.getSeriesPaint(15);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = lineAndShapeRenderer2.getSeriesNegativeItemLabelPosition(255);
        int int8 = lineAndShapeRenderer2.getDefaultEntityRadius();
        lineAndShapeRenderer2.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = lineAndShapeRenderer2.getNegativeItemLabelPosition(8, 0, false);
        org.jfree.chart.text.TextAnchor textAnchor15 = itemLabelPosition14.getTextAnchor();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
        org.junit.Assert.assertNotNull(textAnchor15);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Paint paint6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        lineAndShapeRenderer2.setBaseOutlinePaint(paint6);
        java.awt.Font font8 = lineAndShapeRenderer2.getBaseItemLabelFont();
        java.awt.Paint paint9 = lineAndShapeRenderer2.getBaseFillPaint();
        boolean boolean10 = lineAndShapeRenderer2.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape12 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity15 = new org.jfree.chart.entity.ChartEntity(shape12, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape16 = chartEntity15.getArea();
        lineAndShapeRenderer2.setSeriesShape((int) (short) 100, shape16, true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape16);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot0.setRangeAxisLocation(axisLocation1, true);
        java.lang.Comparable comparable4 = categoryPlot0.getDomainCrosshairColumnKey();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke8 = lineAndShapeRenderer7.getBaseStroke();
        org.jfree.chart.LegendItemCollection legendItemCollection9 = lineAndShapeRenderer7.getLegendItems();
        categoryPlot0.setFixedLegendItems(legendItemCollection9);
        java.awt.Shape shape15 = null;
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", shape15, (java.awt.Paint) color16);
        java.awt.Shape shape18 = legendItem17.getShape();
        java.awt.Paint paint19 = legendItem17.getLinePaint();
        legendItemCollection9.add(legendItem17);
        java.lang.Object obj21 = legendItemCollection9.clone();
        try {
            org.jfree.chart.LegendItem legendItem23 = legendItemCollection9.get((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNull(comparable4);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(legendItemCollection9);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(shape18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(obj21);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder5 = categoryPlot0.getRowRenderingOrder();
        java.awt.Stroke stroke6 = categoryPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent7 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent7);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation9 = null;
        try {
            boolean boolean10 = categoryPlot0.removeAnnotation(categoryAnnotation9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(sortOrder5);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = null;
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        try {
            org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor1, textAnchor2, (-1.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'itemLabelAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertNotNull(textAnchor2);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        boolean boolean9 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace10, true);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        java.awt.Color color2 = java.awt.Color.getColor("", 1);
        java.awt.color.ColorSpace colorSpace3 = color2.getColorSpace();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(colorSpace3);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier4 = categoryPlot0.getDrawingSupplier();
        org.jfree.data.category.CategoryDataset categoryDataset5 = categoryPlot0.getDataset();
        org.jfree.chart.renderer.RenderAttributes renderAttributes6 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        renderAttributes6.setDefaultFillPaint((java.awt.Paint) color7);
        categoryPlot0.setBackgroundPaint((java.awt.Paint) color7);
        float[] floatArray10 = new float[] {};
        try {
            float[] floatArray11 = color7.getRGBComponents(floatArray10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(drawingSupplier4);
        org.junit.Assert.assertNull(categoryDataset5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(floatArray10);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        java.lang.Comparable comparable9 = categoryPlot0.getDomainCrosshairColumnKey();
        boolean boolean10 = categoryPlot0.isRangeCrosshairLockedOnData();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        categoryPlot0.setDomainCrosshairPaint((java.awt.Paint) color11);
        java.awt.Shape shape17 = null;
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem19 = new org.jfree.chart.LegendItem("", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", shape17, (java.awt.Paint) color18);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color18);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        categoryPlot0.panRangeAxes((double) 255, plotRenderingInfo22, point2D23);
        categoryPlot0.setRangeCrosshairValue((double) 3, true);
        org.jfree.chart.util.ShadowGenerator shadowGenerator28 = categoryPlot0.getShadowGenerator();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNull(comparable9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(shadowGenerator28);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        categoryPlot0.setDomainCrosshairColumnKey((java.lang.Comparable) (short) -1, true);
        org.jfree.chart.util.Layer layer9 = null;
        java.util.Collection collection10 = categoryPlot0.getRangeMarkers((int) (short) 0, layer9);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot11.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis14 = categoryPlot11.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        categoryPlot11.zoomDomainAxes((double) 10.0f, plotRenderingInfo16, point2D17, false);
        java.lang.Comparable comparable20 = categoryPlot11.getDomainCrosshairColumnKey();
        boolean boolean21 = categoryPlot11.isRangeCrosshairLockedOnData();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = categoryPlot11.getAxisOffset();
        double double23 = rectangleInsets22.getLeft();
        categoryPlot0.setAxisOffset(rectangleInsets22);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        categoryPlot0.setRenderer(0, categoryItemRenderer26);
        java.awt.Color color28 = java.awt.Color.yellow;
        java.awt.color.ColorSpace colorSpace29 = color28.getColorSpace();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color28);
        org.jfree.chart.axis.AxisSpace axisSpace31 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace31, false);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNull(collection10);
        org.junit.Assert.assertNull(valueAxis14);
        org.junit.Assert.assertNull(comparable20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 4.0d + "'", double23 == 4.0d);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(colorSpace29);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = categoryAxis1.getTickLabelInsets();
        float float3 = categoryAxis1.getMinorTickMarkOutsideLength();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        int int2 = keyedObjects0.getIndex((java.lang.Comparable) (short) 100);
        java.util.List list3 = keyedObjects0.getKeys();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor5 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE10;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot6.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis9 = categoryPlot6.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot6.zoomDomainAxes((double) 10.0f, plotRenderingInfo11, point2D12, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor15 = categoryPlot6.getDomainGridlinePosition();
        boolean boolean16 = itemLabelAnchor5.equals((java.lang.Object) categoryAnchor15);
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot17.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis20 = categoryPlot17.getRangeAxis();
        int int21 = categoryPlot17.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot17.getRowRenderingOrder();
        categoryPlot17.setWeight((int) (short) 100);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder25 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        categoryPlot17.setDatasetRenderingOrder(datasetRenderingOrder25);
        boolean boolean27 = categoryAnchor15.equals((java.lang.Object) categoryPlot17);
        boolean boolean28 = categoryPlot17.isDomainZoomable();
        java.awt.Paint paint29 = categoryPlot17.getNoDataMessagePaint();
        keyedObjects0.setObject((java.lang.Comparable) 0.0f, (java.lang.Object) categoryPlot17);
        try {
            keyedObjects0.removeValue(2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNotNull(itemLabelAnchor5);
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertNotNull(categoryAnchor15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(valueAxis20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 15 + "'", int21 == 15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(datasetRenderingOrder25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(paint29);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        java.lang.Comparable comparable9 = categoryPlot0.getDomainCrosshairColumnKey();
        boolean boolean10 = categoryPlot0.isRangeCrosshairLockedOnData();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        categoryPlot0.setDomainCrosshairPaint((java.awt.Paint) color11);
        java.awt.Shape shape17 = null;
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem19 = new org.jfree.chart.LegendItem("", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", shape17, (java.awt.Paint) color18);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color18);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        try {
            int int22 = categoryPlot0.getRangeAxisIndex(valueAxis21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNull(comparable9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color18);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier4 = categoryPlot0.getDrawingSupplier();
        java.awt.Paint paint5 = categoryPlot0.getOutlinePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot6.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis9 = categoryPlot6.getRangeAxis();
        int int10 = categoryPlot6.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder11 = categoryPlot6.getRowRenderingOrder();
        java.awt.Stroke stroke12 = categoryPlot6.getRangeZeroBaselineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
        categoryPlot6.rendererChanged(rendererChangeEvent13);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot15.setRangeAxisLocation(axisLocation16, true);
        categoryPlot6.setDomainAxisLocation(axisLocation16);
        categoryPlot6.setCrosshairDatasetIndex((int) (short) 1);
        org.jfree.data.category.CategoryDataset categoryDataset22 = categoryPlot6.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = categoryPlot6.getAxisOffset();
        categoryPlot0.setAxisOffset(rectangleInsets23);
        float float25 = categoryPlot0.getBackgroundAlpha();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(drawingSupplier4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 15 + "'", int10 == 15);
        org.junit.Assert.assertNotNull(sortOrder11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNull(categoryDataset22);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 1.0f + "'", float25 == 1.0f);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("hi!");
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        java.lang.Comparable comparable9 = categoryPlot0.getDomainCrosshairColumnKey();
        boolean boolean10 = categoryPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = categoryPlot0.getAxisOffset();
        categoryPlot0.setRangeCrosshairVisible(true);
        java.lang.Object obj14 = categoryPlot0.clone();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNull(comparable9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier4 = categoryPlot0.getDrawingSupplier();
        java.awt.Paint paint5 = categoryPlot0.getOutlinePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot6.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis9 = categoryPlot6.getRangeAxis();
        int int10 = categoryPlot6.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder11 = categoryPlot6.getRowRenderingOrder();
        java.awt.Stroke stroke12 = categoryPlot6.getRangeZeroBaselineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
        categoryPlot6.rendererChanged(rendererChangeEvent13);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot15.setRangeAxisLocation(axisLocation16, true);
        categoryPlot6.setDomainAxisLocation(axisLocation16);
        categoryPlot6.setCrosshairDatasetIndex((int) (short) 1);
        org.jfree.data.category.CategoryDataset categoryDataset22 = categoryPlot6.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = categoryPlot6.getAxisOffset();
        categoryPlot0.setAxisOffset(rectangleInsets23);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier25 = categoryPlot0.getDrawingSupplier();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(drawingSupplier4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 15 + "'", int10 == 15);
        org.junit.Assert.assertNotNull(sortOrder11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNull(categoryDataset22);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(drawingSupplier25);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge();
        org.jfree.chart.axis.AxisLocation axisLocation4 = categoryPlot0.getDomainAxisLocation();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        categoryPlot0.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        categoryPlot0.setRenderer(categoryItemRenderer8);
        java.awt.Paint paint10 = categoryPlot0.getDomainGridlinePaint();
        java.awt.Stroke stroke11 = categoryPlot0.getRangeMinorGridlineStroke();
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        categoryPlot0.setDomainCrosshairColumnKey((java.lang.Comparable) (short) -1, true);
        org.jfree.chart.util.Layer layer9 = null;
        java.util.Collection collection10 = categoryPlot0.getRangeMarkers((int) (short) 0, layer9);
        categoryPlot0.setRangeCrosshairLockedOnData(false);
        java.lang.Comparable comparable13 = categoryPlot0.getDomainCrosshairColumnKey();
        java.lang.Class<?> wildcardClass14 = categoryPlot0.getClass();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = categoryPlot0.getInsets();
        java.awt.Shape shape20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot21.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis24 = categoryPlot21.getRangeAxis();
        int int25 = categoryPlot21.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder26 = categoryPlot21.getRowRenderingOrder();
        java.awt.Stroke stroke27 = categoryPlot21.getRangeZeroBaselineStroke();
        java.awt.Paint paint28 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem29 = new org.jfree.chart.LegendItem("", "", "hi!", "", shape20, stroke27, paint28);
        boolean boolean30 = rectangleInsets15.equals((java.lang.Object) "");
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNull(collection10);
        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + (short) -1 + "'", comparable13.equals((short) -1));
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNull(valueAxis24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 15 + "'", int25 == 15);
        org.junit.Assert.assertNotNull(sortOrder26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }
}

