import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isRangeGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getRangeAxisEdge((int) (byte) -1);
        boolean boolean4 = categoryPlot0.canSelectByRegion();
        java.awt.Color color8 = java.awt.Color.getHSBColor((float) (short) 1, (float) 100, 0.0f);
        float[] floatArray15 = new float[] { (byte) 10, (byte) 1, 1.0f, (byte) 0, 10, (byte) 100 };
        float[] floatArray16 = color8.getRGBComponents(floatArray15);
        java.lang.String str17 = color8.toString();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color8);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier19 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape20 = defaultDrawingSupplier19.getNextShape();
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier19);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "java.awt.Color[r=0,g=0,b=0]" + "'", str17.equals("java.awt.Color[r=0,g=0,b=0]"));
        org.junit.Assert.assertNotNull(shape20);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = categoryAxis1.getTickLabelInsets();
        categoryAxis1.setCategoryLabelPositionOffset(0);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        int int9 = categoryPlot5.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot5.getRowRenderingOrder();
        java.awt.Stroke stroke11 = categoryPlot5.getRangeZeroBaselineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        categoryPlot5.rendererChanged(rendererChangeEvent12);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot14.setRangeAxisLocation(axisLocation15, true);
        categoryPlot5.setDomainAxisLocation(axisLocation15);
        categoryPlot5.setCrosshairDatasetIndex((int) (short) 1);
        categoryAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot5);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = categoryAxis1.getLabelInsets();
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot26.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = categoryPlot26.getRangeAxisEdge();
        try {
            double double30 = categoryAxis1.getCategoryMiddle((int) (short) -1, (int) (short) -1, rectangle2D25, rectangleEdge29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid category index: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(rectangleEdge29);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        int int2 = keyedObjects0.getIndex((java.lang.Comparable) (short) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = categoryAxis4.getTickLabelInsets();
        categoryAxis4.setCategoryLabelPositionOffset(0);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis11 = categoryPlot8.getRangeAxis();
        int int12 = categoryPlot8.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder13 = categoryPlot8.getRowRenderingOrder();
        java.awt.Stroke stroke14 = categoryPlot8.getRangeZeroBaselineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent15 = null;
        categoryPlot8.rendererChanged(rendererChangeEvent15);
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot17.setRangeAxisLocation(axisLocation18, true);
        categoryPlot8.setDomainAxisLocation(axisLocation18);
        categoryPlot8.setCrosshairDatasetIndex((int) (short) 1);
        categoryAxis4.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot8);
        boolean boolean25 = keyedObjects0.equals((java.lang.Object) categoryPlot8);
        org.jfree.chart.util.SortOrder sortOrder26 = null;
        try {
            keyedObjects0.sortByKeys(sortOrder26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 15 + "'", int12 == 15);
        org.junit.Assert.assertNotNull(sortOrder13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        renderAttributes0.setDefaultFillPaint((java.awt.Paint) color1);
        java.awt.Shape shape5 = renderAttributes0.getItemShape((int) (byte) 100, (int) 'a');
        java.awt.Shape shape7 = null;
        renderAttributes0.setSeriesShape((int) (byte) 1, shape7);
        renderAttributes0.setDefaultCreateEntity((java.lang.Boolean) true);
        java.awt.Paint paint11 = renderAttributes0.getDefaultPaint();
        java.awt.Paint paint12 = renderAttributes0.getDefaultPaint();
        java.awt.Paint paint13 = renderAttributes0.getDefaultOutlinePaint();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer17 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke18 = lineAndShapeRenderer17.getBaseStroke();
        java.awt.Stroke stroke20 = lineAndShapeRenderer17.lookupSeriesStroke(10);
        java.awt.Shape shape24 = lineAndShapeRenderer17.getItemShape((int) (short) 10, 100, true);
        lineAndShapeRenderer17.setBaseCreateEntities(true);
        java.awt.Paint paint30 = lineAndShapeRenderer17.getItemLabelPaint(0, (int) 'a', false);
        try {
            renderAttributes0.setSeriesFillPaint((-16728064), paint30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNull(shape5);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(paint30);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder5 = categoryPlot0.getRowRenderingOrder();
        java.awt.Stroke stroke6 = categoryPlot0.getRangeZeroBaselineStroke();
        int int7 = categoryPlot0.getCrosshairDatasetIndex();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke11 = lineAndShapeRenderer10.getBaseStroke();
        java.awt.Stroke stroke13 = lineAndShapeRenderer10.lookupSeriesStroke(10);
        lineAndShapeRenderer10.setAutoPopulateSeriesStroke(true);
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer10, true);
        lineAndShapeRenderer10.setSeriesShapesFilled((int) (short) 0, (java.lang.Boolean) false);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(sortOrder5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor9 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.plot.Plot plot10 = null;
        categoryPlot0.setParent(plot10);
        categoryPlot0.setDomainGridlinesVisible(true);
        categoryPlot0.setDomainGridlinesVisible(false);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(categoryAnchor9);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Paint paint5 = lineAndShapeRenderer2.getSeriesPaint(15);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = lineAndShapeRenderer2.getSeriesNegativeItemLabelPosition(255);
        int int8 = lineAndShapeRenderer2.getDefaultEntityRadius();
        java.awt.Stroke stroke9 = lineAndShapeRenderer2.getBaseOutlineStroke();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator11 = lineAndShapeRenderer2.getSeriesToolTipGenerator(128);
        lineAndShapeRenderer2.setSeriesItemLabelsVisible((int) (byte) 1, (java.lang.Boolean) false);
        lineAndShapeRenderer2.setAutoPopulateSeriesStroke(false);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNull(categoryToolTipGenerator11);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairLockedOnData(false);
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) (short) 10);
        categoryPlot0.setAnchorValue((double) (short) 10, false);
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace8);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        categoryPlot0.markerChanged(markerChangeEvent10);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke15 = lineAndShapeRenderer14.getBaseStroke();
        java.awt.Stroke stroke17 = lineAndShapeRenderer14.lookupSeriesStroke(10);
        java.awt.Shape shape23 = null;
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", shape23, (java.awt.Paint) color24);
        int int26 = color24.getBlue();
        lineAndShapeRenderer14.setSeriesItemLabelPaint((int) (byte) 1, (java.awt.Paint) color24);
        int int28 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer14);
        boolean boolean29 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.plot.Plot plot30 = categoryPlot0.getRootPlot();
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 128 + "'", int26 == 128);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(plot30);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE2;
        java.lang.String str1 = itemLabelAnchor0.toString();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ItemLabelAnchor.OUTSIDE2" + "'", str1.equals("ItemLabelAnchor.OUTSIDE2"));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        lineAndShapeRenderer2.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator7);
        lineAndShapeRenderer2.setSeriesVisible((int) (short) 100, (java.lang.Boolean) false, true);
        boolean boolean15 = lineAndShapeRenderer2.getItemShapeVisible((int) (short) 10, 3);
        lineAndShapeRenderer2.removeAnnotations();
        lineAndShapeRenderer2.setAutoPopulateSeriesShape(false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer21 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke22 = lineAndShapeRenderer21.getBaseStroke();
        java.awt.Stroke stroke24 = lineAndShapeRenderer21.lookupSeriesStroke(10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator26 = null;
        lineAndShapeRenderer21.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator26);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition29 = lineAndShapeRenderer21.getSeriesPositiveItemLabelPosition(0);
        lineAndShapeRenderer2.setBasePositiveItemLabelPosition(itemLabelPosition29, false);
        lineAndShapeRenderer2.setAutoPopulateSeriesStroke(false);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(itemLabelPosition29);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = lineAndShapeRenderer2.getBasePositiveItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor4 = itemLabelPosition3.getRotationAnchor();
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.clearSeriesStrokes(true);
        lineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(true);
        java.awt.Stroke stroke5 = lineAndShapeRenderer0.getBaseOutlineStroke();
        lineAndShapeRenderer0.setBaseItemLabelsVisible(true, false);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder4 = categoryPlot0.getDatasetRenderingOrder();
        float float5 = categoryPlot0.getBackgroundImageAlpha();
        java.awt.Image image6 = categoryPlot0.getBackgroundImage();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot7.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis10 = categoryPlot7.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot7.zoomDomainAxes((double) 10.0f, plotRenderingInfo12, point2D13, false);
        java.lang.Comparable comparable16 = categoryPlot7.getDomainCrosshairColumnKey();
        boolean boolean17 = categoryPlot7.isRangeCrosshairLockedOnData();
        categoryPlot7.setCrosshairDatasetIndex((int) (byte) 10, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = categoryPlot7.getInsets();
        categoryPlot0.setInsets(rectangleInsets21);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(datasetRenderingOrder4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.5f + "'", float5 == 0.5f);
        org.junit.Assert.assertNull(image6);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertNull(comparable16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(rectangleInsets21);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Paint paint5 = lineAndShapeRenderer2.getSeriesPaint(15);
        double double6 = lineAndShapeRenderer2.getItemLabelAnchorOffset();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot7.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis10 = categoryPlot7.getRangeAxis();
        int int11 = categoryPlot7.getBackgroundImageAlignment();
        categoryPlot7.setDomainCrosshairColumnKey((java.lang.Comparable) (short) -1, true);
        java.awt.Stroke stroke15 = categoryPlot7.getDomainGridlineStroke();
        lineAndShapeRenderer2.setBaseStroke(stroke15);
        java.awt.Paint paint18 = lineAndShapeRenderer2.getSeriesItemLabelPaint((int) (short) 1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.0d + "'", double6 == 2.0d);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 15 + "'", int11 == 15);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNull(paint18);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Paint paint6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        lineAndShapeRenderer2.setBaseOutlinePaint(paint6);
        java.awt.Font font8 = lineAndShapeRenderer2.getBaseItemLabelFont();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = lineAndShapeRenderer2.getNegativeItemLabelPosition(1, (-1), false);
        lineAndShapeRenderer2.setSeriesVisible(8, (java.lang.Boolean) true, true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(itemLabelPosition12);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.axis.AxisSpace axisSpace5 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace5, true);
        org.jfree.chart.plot.Marker marker8 = null;
        boolean boolean9 = categoryPlot0.removeDomainMarker(marker8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot0.zoomRangeAxes((double) (-16728064), plotRenderingInfo11, point2D12);
        org.jfree.chart.axis.AxisSpace axisSpace14 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace14);
        categoryPlot0.setAnchorValue((double) 0.5f);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.category.BarPainter barPainter1 = org.jfree.chart.renderer.category.BarRenderer.getDefaultBarPainter();
        barRenderer0.setBarPainter(barPainter1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = barRenderer0.getPositiveItemLabelPositionFallback();
        org.junit.Assert.assertNotNull(barPainter1);
        org.junit.Assert.assertNull(itemLabelPosition3);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot4.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis7 = categoryPlot4.getRangeAxis();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot4.getDrawingSupplier();
        org.jfree.data.category.CategoryDataset categoryDataset9 = categoryPlot4.getDataset();
        boolean boolean10 = lineAndShapeRenderer2.hasListener((java.util.EventListener) categoryPlot4);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = categoryPlot4.getDomainAxisEdge(255);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNull(categoryDataset9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleEdge12);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        lineAndShapeRenderer2.setAutoPopulateSeriesOutlinePaint(true);
        boolean boolean8 = lineAndShapeRenderer2.isItemLabelVisible(128, (-256), true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = categoryAxis1.getTickLabelInsets();
        categoryAxis1.setCategoryLabelPositionOffset(0);
        categoryAxis1.setMinorTickMarksVisible(false);
        float float7 = categoryAxis1.getMinorTickMarkOutsideLength();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = categoryAxis1.getLabelInsets();
        org.jfree.chart.util.UnitType unitType9 = rectangleInsets8.getUnitType();
        double double11 = rectangleInsets8.trimWidth((double) 100L);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 2.0f + "'", float7 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(unitType9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 94.0d + "'", double11 == 94.0d);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape0, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape4 = chartEntity3.getArea();
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape4);
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot7.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis10 = categoryPlot7.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot7.zoomDomainAxes((double) 10.0f, plotRenderingInfo12, point2D13, false);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent16 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot7);
        org.jfree.chart.JFreeChart jFreeChart17 = null;
        plotChangeEvent16.setChart(jFreeChart17);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType19 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        plotChangeEvent16.setType(chartChangeEventType19);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent21 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) chartEntity5, jFreeChart6, chartChangeEventType19);
        java.awt.Shape shape22 = chartEntity5.getArea();
        java.awt.Shape shape23 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity26 = new org.jfree.chart.entity.ChartEntity(shape23, "ChartChangeEventType.GENERAL", "");
        org.jfree.chart.entity.ChartEntity chartEntity27 = new org.jfree.chart.entity.ChartEntity(shape23);
        chartEntity5.setArea(shape23);
        java.lang.String str29 = chartEntity5.getToolTipText();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertNotNull(chartChangeEventType19);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNull(str29);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = categoryAxis1.getTickLabelInsets();
        categoryAxis1.setCategoryLabelPositionOffset(0);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        int int9 = categoryPlot5.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot5.getRowRenderingOrder();
        java.awt.Stroke stroke11 = categoryPlot5.getRangeZeroBaselineStroke();
        int int12 = categoryPlot5.getCrosshairDatasetIndex();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke16 = lineAndShapeRenderer15.getBaseStroke();
        java.awt.Stroke stroke18 = lineAndShapeRenderer15.lookupSeriesStroke(10);
        lineAndShapeRenderer15.setAutoPopulateSeriesStroke(true);
        categoryPlot5.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer15, true);
        categoryAxis1.setPlot((org.jfree.chart.plot.Plot) categoryPlot5);
        categoryAxis1.setCategoryMargin((double) 100L);
        categoryAxis1.setTickLabelsVisible(true);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape0, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape4 = chartEntity3.getArea();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot5.zoomDomainAxes((double) 10.0f, plotRenderingInfo10, point2D11, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor14 = categoryPlot5.getDomainGridlinePosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot15.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis18 = categoryPlot15.getRangeAxis();
        int int19 = categoryPlot15.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder20 = categoryPlot15.getRowRenderingOrder();
        java.awt.Stroke stroke21 = categoryPlot15.getRangeZeroBaselineStroke();
        categoryPlot5.setRangeMinorGridlineStroke(stroke21);
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = categoryPlot5.getDomainAxis(100);
        boolean boolean25 = categoryPlot5.isNotify();
        org.jfree.chart.entity.PlotEntity plotEntity27 = new org.jfree.chart.entity.PlotEntity(shape4, (org.jfree.chart.plot.Plot) categoryPlot5, "ItemLabelAnchor.OUTSIDE1");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset30 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity33 = new org.jfree.chart.entity.CategoryItemEntity(shape4, "PlotOrientation.VERTICAL", "PlotOrientation.VERTICAL", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset30, (java.lang.Comparable) 10, (java.lang.Comparable) 'a');
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset36 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset36.clear();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity40 = new org.jfree.chart.entity.CategoryItemEntity(shape4, "AxisLocation.BOTTOM_OR_LEFT", "ItemLabelAnchor.OUTSIDE2", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset36, (java.lang.Comparable) 7.0d, (java.lang.Comparable) "PlotOrientation.VERTICAL");
        java.lang.String str41 = categoryItemEntity40.toString();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertNotNull(categoryAnchor14);
        org.junit.Assert.assertNull(valueAxis18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 15 + "'", int19 == 15);
        org.junit.Assert.assertNotNull(sortOrder20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNull(categoryAxis24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Shape shape9 = lineAndShapeRenderer2.getItemShape((int) (short) 10, 100, true);
        lineAndShapeRenderer2.setBaseSeriesVisible(false);
        java.awt.Shape shape12 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity15 = new org.jfree.chart.entity.ChartEntity(shape12, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape16 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity19 = new org.jfree.chart.entity.ChartEntity(shape16, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape20 = chartEntity19.getArea();
        chartEntity15.setArea(shape20);
        lineAndShapeRenderer2.setBaseShape(shape20, true);
        java.lang.Boolean boolean25 = lineAndShapeRenderer2.getSeriesShapesVisible(1);
        double double26 = lineAndShapeRenderer2.getItemMargin();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNull(boolean25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType2 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets0.createAdjustedRectangle(rectangle2D1, lengthAdjustmentType2, lengthAdjustmentType3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        categoryPlot0.setDomainCrosshairColumnKey((java.lang.Comparable) (short) -1, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot0.zoomRangeAxes((double) (byte) 1, plotRenderingInfo9, point2D10, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Point2D point2D16 = null;
        categoryPlot0.zoomDomainAxes((double) 1L, (double) (byte) -1, plotRenderingInfo15, point2D16);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        java.awt.Paint paint5 = categoryPlot0.getNoDataMessagePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = categoryPlot0.getDomainAxisForDataset((int) 'a');
        java.awt.Paint paint8 = categoryPlot0.getDomainCrosshairPaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = categoryAxis10.getTickLabelInsets();
        categoryPlot0.setDomainAxis(categoryAxis10);
        java.awt.Font font13 = categoryAxis10.getLabelFont();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(categoryAxis7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(font13);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        lineAndShapeRenderer2.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator7);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = lineAndShapeRenderer2.getSeriesPositiveItemLabelPosition(0);
        java.awt.Stroke stroke11 = lineAndShapeRenderer2.getBaseStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = lineAndShapeRenderer2.getPlot();
        java.awt.Shape shape14 = lineAndShapeRenderer2.getLegendShape((int) (short) 100);
        boolean boolean15 = lineAndShapeRenderer2.getDrawOutlines();
        lineAndShapeRenderer2.setDefaultEntityRadius((int) (short) -1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(categoryPlot12);
        org.junit.Assert.assertNull(shape14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        renderAttributes0.setDefaultFillPaint((java.awt.Paint) color1);
        java.awt.Stroke stroke4 = renderAttributes0.getSeriesStroke((int) ' ');
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity9 = new org.jfree.chart.entity.ChartEntity(shape6, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape10 = chartEntity9.getArea();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot11.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis14 = categoryPlot11.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        categoryPlot11.zoomDomainAxes((double) 10.0f, plotRenderingInfo16, point2D17, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor20 = categoryPlot11.getDomainGridlinePosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot21.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis24 = categoryPlot21.getRangeAxis();
        int int25 = categoryPlot21.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder26 = categoryPlot21.getRowRenderingOrder();
        java.awt.Stroke stroke27 = categoryPlot21.getRangeZeroBaselineStroke();
        categoryPlot11.setRangeMinorGridlineStroke(stroke27);
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = categoryPlot11.getDomainAxis(100);
        boolean boolean31 = categoryPlot11.isNotify();
        org.jfree.chart.entity.PlotEntity plotEntity33 = new org.jfree.chart.entity.PlotEntity(shape10, (org.jfree.chart.plot.Plot) categoryPlot11, "ItemLabelAnchor.OUTSIDE1");
        renderAttributes0.setSeriesShape((int) (byte) 100, shape10);
        try {
            renderAttributes0.setSeriesCreateEntity(100, (java.lang.Boolean) true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNull(stroke4);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNull(valueAxis14);
        org.junit.Assert.assertNotNull(categoryAnchor20);
        org.junit.Assert.assertNull(valueAxis24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 15 + "'", int25 == 15);
        org.junit.Assert.assertNotNull(sortOrder26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNull(categoryAxis30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        java.awt.Shape shape4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        int int9 = categoryPlot5.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot5.getRowRenderingOrder();
        java.awt.Stroke stroke11 = categoryPlot5.getRangeZeroBaselineStroke();
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("", "", "hi!", "", shape4, stroke11, paint12);
        legendItem13.setSeriesIndex((int) (byte) 10);
        java.awt.Shape shape16 = legendItem13.getShape();
        org.jfree.chart.entity.ChartEntity chartEntity17 = new org.jfree.chart.entity.ChartEntity(shape16);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(shape16);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder5 = categoryPlot0.getRowRenderingOrder();
        java.awt.Stroke stroke6 = categoryPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent7 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent7);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot9.setRangeAxisLocation(axisLocation10, true);
        categoryPlot0.setDomainAxisLocation(axisLocation10);
        categoryPlot0.setCrosshairDatasetIndex((int) (short) 1);
        org.jfree.data.category.CategoryDataset categoryDataset16 = categoryPlot0.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = categoryPlot0.getAxisOffset();
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D21 = rectangleInsets17.createOutsetRectangle(rectangle2D18, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(sortOrder5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNull(categoryDataset16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge();
        org.jfree.chart.axis.AxisLocation axisLocation4 = categoryPlot0.getDomainAxisLocation();
        java.awt.Paint paint5 = categoryPlot0.getNoDataMessagePaint();
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color7 = java.awt.Color.getHSBColor((float) (short) 1, (float) 100, 0.0f);
        float[] floatArray14 = new float[] { (byte) 10, (byte) 1, 1.0f, (byte) 0, 10, (byte) 100 };
        float[] floatArray15 = color7.getRGBComponents(floatArray14);
        float[] floatArray16 = java.awt.Color.RGBtoHSB((int) ' ', 1, 255, floatArray14);
        float[] floatArray17 = color0.getRGBColorComponents(floatArray14);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        try {
            keyedObjects0.removeValue((java.lang.Comparable) "ItemLabelAnchor.OUTSIDE2");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: The key (ItemLabelAnchor.OUTSIDE2) is not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        java.awt.Shape shape4 = null;
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem6 = new org.jfree.chart.LegendItem("", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", shape4, (java.awt.Paint) color5);
        java.awt.Shape shape7 = legendItem6.getShape();
        java.awt.Paint paint8 = legendItem6.getLinePaint();
        java.awt.Paint paint9 = legendItem6.getLinePaint();
        org.jfree.chart.JFreeChart jFreeChart10 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent11 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) paint9, jFreeChart10);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(shape7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        java.awt.Shape shape4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        int int9 = categoryPlot5.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot5.getRowRenderingOrder();
        java.awt.Stroke stroke11 = categoryPlot5.getRangeZeroBaselineStroke();
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("", "", "hi!", "", shape4, stroke11, paint12);
        legendItem13.setDescription("");
        int int16 = legendItem13.getDatasetIndex();
        java.lang.String str17 = legendItem13.getLabel();
        java.lang.String str18 = legendItem13.getLabel();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset19 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo20 = new org.jfree.chart.event.DatasetChangeInfo();
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent21 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object) legendItem13, (org.jfree.data.general.Dataset) defaultCategoryDataset19, datasetChangeInfo20);
        defaultCategoryDataset19.clearSelection();
        int int23 = defaultCategoryDataset19.getRowCount();
        int int25 = defaultCategoryDataset19.getColumnIndex((java.lang.Comparable) "AxisLocation.BOTTOM_OR_LEFT");
        try {
            java.lang.Comparable comparable27 = defaultCategoryDataset19.getColumnKey((-16728064));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -16728064");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        java.awt.Shape shape4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        int int9 = categoryPlot5.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot5.getRowRenderingOrder();
        java.awt.Stroke stroke11 = categoryPlot5.getRangeZeroBaselineStroke();
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("", "", "hi!", "", shape4, stroke11, paint12);
        legendItem13.setDescription("");
        int int16 = legendItem13.getDatasetIndex();
        java.lang.String str17 = legendItem13.getLabel();
        java.lang.String str18 = legendItem13.getLabel();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset19 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo20 = new org.jfree.chart.event.DatasetChangeInfo();
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent21 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object) legendItem13, (org.jfree.data.general.Dataset) defaultCategoryDataset19, datasetChangeInfo20);
        defaultCategoryDataset19.clearSelection();
        int int24 = defaultCategoryDataset19.getColumnIndex((java.lang.Comparable) 4.0d);
        java.lang.Comparable comparable26 = null;
        try {
            java.lang.Number number27 = defaultCategoryDataset19.getValue((java.lang.Comparable) "ChartChangeEventType.GENERAL", comparable26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'columnKey' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = categoryAxis1.getTickLabelInsets();
        categoryAxis1.setCategoryLabelPositionOffset(0);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        int int9 = categoryPlot5.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot5.getRowRenderingOrder();
        java.awt.Stroke stroke11 = categoryPlot5.getRangeZeroBaselineStroke();
        int int12 = categoryPlot5.getCrosshairDatasetIndex();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke16 = lineAndShapeRenderer15.getBaseStroke();
        java.awt.Stroke stroke18 = lineAndShapeRenderer15.lookupSeriesStroke(10);
        lineAndShapeRenderer15.setAutoPopulateSeriesStroke(true);
        categoryPlot5.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer15, true);
        categoryAxis1.setPlot((org.jfree.chart.plot.Plot) categoryPlot5);
        java.lang.Object obj24 = categoryAxis1.clone();
        categoryAxis1.removeCategoryLabelToolTip((java.lang.Comparable) 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(obj24);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        renderAttributes0.setDefaultFillPaint((java.awt.Paint) color1);
        java.awt.Paint paint3 = renderAttributes0.getDefaultOutlinePaint();
        java.awt.Stroke stroke4 = renderAttributes0.getDefaultStroke();
        java.awt.Shape shape6 = null;
        renderAttributes0.setSeriesShape(0, shape6);
        java.awt.Stroke stroke8 = null;
        try {
            renderAttributes0.setDefaultOutlineStroke(stroke8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNull(stroke4);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.clearSeriesStrokes(true);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator4 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("java.awt.Color[r=0,g=0,b=0]");
        lineAndShapeRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator4);
        java.awt.Paint paint9 = lineAndShapeRenderer0.getItemFillPaint((int) (byte) 0, 156, true);
        try {
            lineAndShapeRenderer0.setSeriesCreateEntities((-128), (java.lang.Boolean) false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("ItemLabelAnchor.OUTSIDE2");
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape0, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape4 = chartEntity3.getArea();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot5.zoomDomainAxes((double) 10.0f, plotRenderingInfo10, point2D11, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor14 = categoryPlot5.getDomainGridlinePosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot15.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis18 = categoryPlot15.getRangeAxis();
        int int19 = categoryPlot15.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder20 = categoryPlot15.getRowRenderingOrder();
        java.awt.Stroke stroke21 = categoryPlot15.getRangeZeroBaselineStroke();
        categoryPlot5.setRangeMinorGridlineStroke(stroke21);
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = categoryPlot5.getDomainAxis(100);
        boolean boolean25 = categoryPlot5.isNotify();
        org.jfree.chart.entity.PlotEntity plotEntity27 = new org.jfree.chart.entity.PlotEntity(shape4, (org.jfree.chart.plot.Plot) categoryPlot5, "ItemLabelAnchor.OUTSIDE1");
        boolean boolean28 = categoryPlot5.isRangeZoomable();
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryPlot5.setRangeCrosshairPaint((java.awt.Paint) color29);
        org.jfree.chart.axis.AxisLocation axisLocation32 = categoryPlot5.getDomainAxisLocation(15);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor33 = categoryPlot5.getDomainGridlinePosition();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor34 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE5;
        java.awt.Color color35 = java.awt.Color.white;
        boolean boolean36 = itemLabelAnchor34.equals((java.lang.Object) color35);
        java.awt.Color color37 = color35.darker();
        categoryPlot5.setDomainCrosshairPaint((java.awt.Paint) color37);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertNotNull(categoryAnchor14);
        org.junit.Assert.assertNull(valueAxis18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 15 + "'", int19 == 15);
        org.junit.Assert.assertNotNull(sortOrder20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNull(categoryAxis24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(axisLocation32);
        org.junit.Assert.assertNotNull(categoryAnchor33);
        org.junit.Assert.assertNotNull(itemLabelAnchor34);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(color37);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        renderAttributes0.setDefaultFillPaint((java.awt.Paint) color1);
        java.awt.Paint paint3 = renderAttributes0.getDefaultOutlinePaint();
        java.awt.Stroke stroke4 = renderAttributes0.getDefaultStroke();
        java.awt.Shape shape6 = null;
        renderAttributes0.setSeriesShape(0, shape6);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer11 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = lineAndShapeRenderer11.getBasePositiveItemLabelPosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot13.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = categoryPlot13.getDomainAxisEdge();
        org.jfree.chart.axis.AxisLocation axisLocation17 = categoryPlot13.getDomainAxisLocation();
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        categoryPlot13.drawBackgroundImage(graphics2D18, rectangle2D19);
        java.awt.Paint paint21 = categoryPlot13.getNoDataMessagePaint();
        lineAndShapeRenderer11.setBaseItemLabelPaint(paint21);
        java.lang.Boolean boolean24 = lineAndShapeRenderer11.getSeriesShapesFilled(10);
        java.awt.Shape shape25 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity28 = new org.jfree.chart.entity.ChartEntity(shape25, "ChartChangeEventType.GENERAL", "");
        lineAndShapeRenderer11.setBaseShape(shape25, false);
        renderAttributes0.setSeriesShape(0, shape25);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNull(stroke4);
        org.junit.Assert.assertNotNull(itemLabelPosition12);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNull(boolean24);
        org.junit.Assert.assertNotNull(shape25);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = categoryAxis1.getTickLabelInsets();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer5.getBasePositiveItemLabelPosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot7.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = categoryPlot7.getDomainAxisEdge();
        org.jfree.chart.axis.AxisLocation axisLocation11 = categoryPlot7.getDomainAxisLocation();
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        categoryPlot7.drawBackgroundImage(graphics2D12, rectangle2D13);
        java.awt.Paint paint15 = categoryPlot7.getNoDataMessagePaint();
        lineAndShapeRenderer5.setBaseItemLabelPaint(paint15);
        java.awt.Stroke stroke18 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        lineAndShapeRenderer5.setSeriesStroke((int) (byte) 0, stroke18, false);
        categoryAxis1.setAxisLineStroke(stroke18);
        java.lang.String str23 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) (byte) 1);
        org.jfree.data.KeyedObjects keyedObjects25 = new org.jfree.data.KeyedObjects();
        int int27 = keyedObjects25.getIndex((java.lang.Comparable) (short) 100);
        int int28 = keyedObjects25.getItemCount();
        java.util.List list29 = keyedObjects25.getKeys();
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = null;
        try {
            double double32 = categoryAxis1.getCategoryMiddle((java.lang.Comparable) 1, list29, rectangle2D30, rectangleEdge31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid category index: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(list29);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = null;
        lineAndShapeRenderer2.setSeriesItemLabelGenerator((int) (byte) 1, categoryItemLabelGenerator5);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot9.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis12 = categoryPlot9.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot9.zoomDomainAxes((double) 10.0f, plotRenderingInfo14, point2D15, false);
        java.lang.Comparable comparable18 = categoryPlot9.getDomainCrosshairColumnKey();
        boolean boolean19 = categoryPlot9.isRangeCrosshairLockedOnData();
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        categoryPlot9.setDomainCrosshairPaint((java.awt.Paint) color20);
        java.awt.Shape shape26 = null;
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem28 = new org.jfree.chart.LegendItem("", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", shape26, (java.awt.Paint) color27);
        categoryPlot9.setDomainGridlinePaint((java.awt.Paint) color27);
        java.awt.Color color30 = java.awt.Color.getColor("PlotEntity: tooltip = ItemLabelAnchor.OUTSIDE1", color27);
        java.awt.color.ColorSpace colorSpace31 = color27.getColorSpace();
        lineAndShapeRenderer2.setSeriesPaint(1, (java.awt.Paint) color27, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot34.setRangeCrosshairLockedOnData(false);
        categoryPlot34.setDomainCrosshairRowKey((java.lang.Comparable) (short) 10);
        java.awt.Stroke stroke39 = categoryPlot34.getRangeZeroBaselineStroke();
        lineAndShapeRenderer2.setBaseOutlineStroke(stroke39);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNull(comparable18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(colorSpace31);
        org.junit.Assert.assertNotNull(stroke39);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Shape shape9 = lineAndShapeRenderer2.getItemShape((int) (short) 10, 100, true);
        lineAndShapeRenderer2.setBaseSeriesVisible(false);
        java.awt.Shape shape12 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity15 = new org.jfree.chart.entity.ChartEntity(shape12, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape16 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity19 = new org.jfree.chart.entity.ChartEntity(shape16, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape20 = chartEntity19.getArea();
        chartEntity15.setArea(shape20);
        lineAndShapeRenderer2.setBaseShape(shape20, true);
        java.lang.Boolean boolean25 = lineAndShapeRenderer2.getSeriesShapesVisible(1);
        java.awt.Font font26 = lineAndShapeRenderer2.getBaseItemLabelFont();
        java.awt.Font font28 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        lineAndShapeRenderer2.setSeriesItemLabelFont((int) (short) 100, font28);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator33 = lineAndShapeRenderer2.getURLGenerator(156, (int) (byte) 0, false);
        lineAndShapeRenderer2.setUseFillPaint(true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNull(boolean25);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNull(categoryURLGenerator33);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot3.getRangeAxis();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier7 = categoryPlot3.getDrawingSupplier();
        org.jfree.data.category.CategoryDataset categoryDataset8 = categoryPlot3.getDataset();
        org.jfree.chart.renderer.RenderAttributes renderAttributes9 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        renderAttributes9.setDefaultFillPaint((java.awt.Paint) color10);
        categoryPlot3.setBackgroundPaint((java.awt.Paint) color10);
        lineAndShapeRenderer2.setPlot(categoryPlot3);
        boolean boolean16 = lineAndShapeRenderer2.getItemLineVisible((int) (short) 10, (-16728064));
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(drawingSupplier7);
        org.junit.Assert.assertNull(categoryDataset8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        java.awt.Shape shape4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        int int9 = categoryPlot5.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot5.getRowRenderingOrder();
        java.awt.Stroke stroke11 = categoryPlot5.getRangeZeroBaselineStroke();
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("", "", "hi!", "", shape4, stroke11, paint12);
        legendItem13.setDescription("");
        int int16 = legendItem13.getDatasetIndex();
        java.lang.String str17 = legendItem13.getLabel();
        java.lang.String str18 = legendItem13.getLabel();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset19 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo20 = new org.jfree.chart.event.DatasetChangeInfo();
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent21 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object) legendItem13, (org.jfree.data.general.Dataset) defaultCategoryDataset19, datasetChangeInfo20);
        defaultCategoryDataset19.clearSelection();
        int int23 = defaultCategoryDataset19.getRowCount();
        int int25 = defaultCategoryDataset19.getColumnIndex((java.lang.Comparable) "AxisLocation.BOTTOM_OR_LEFT");
        org.jfree.data.category.CategoryDatasetSelectionState categoryDatasetSelectionState26 = defaultCategoryDataset19.getSelectionState();
        try {
            defaultCategoryDataset19.removeValue((java.lang.Comparable) "ItemLabelAnchor.OUTSIDE1", (java.lang.Comparable) "ItemLabelAnchor.OUTSIDE1");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Row key (ItemLabelAnchor.OUTSIDE1) not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNotNull(categoryDatasetSelectionState26);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier4 = categoryPlot0.getDrawingSupplier();
        java.awt.Paint paint5 = categoryPlot0.getOutlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation6 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.axis.AxisLocation axisLocation7 = axisLocation6.getOpposite();
        categoryPlot0.setDomainAxisLocation(axisLocation6);
        org.jfree.chart.axis.AxisSpace axisSpace9 = categoryPlot0.getFixedDomainAxisSpace();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(drawingSupplier4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNull(axisSpace9);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        java.awt.Shape shape4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        int int9 = categoryPlot5.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot5.getRowRenderingOrder();
        java.awt.Stroke stroke11 = categoryPlot5.getRangeZeroBaselineStroke();
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("", "", "hi!", "", shape4, stroke11, paint12);
        legendItem13.setDescription("");
        int int16 = legendItem13.getDatasetIndex();
        java.lang.String str17 = legendItem13.getLabel();
        java.lang.String str18 = legendItem13.getLabel();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset19 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo20 = new org.jfree.chart.event.DatasetChangeInfo();
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent21 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object) legendItem13, (org.jfree.data.general.Dataset) defaultCategoryDataset19, datasetChangeInfo20);
        defaultCategoryDataset19.clearSelection();
        int int23 = defaultCategoryDataset19.getRowCount();
        int int25 = defaultCategoryDataset19.getColumnIndex((java.lang.Comparable) "AxisLocation.BOTTOM_OR_LEFT");
        try {
            java.lang.Comparable comparable27 = defaultCategoryDataset19.getColumnKey((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape0, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape4 = chartEntity3.getArea();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot5.zoomDomainAxes((double) 10.0f, plotRenderingInfo10, point2D11, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor14 = categoryPlot5.getDomainGridlinePosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot15.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis18 = categoryPlot15.getRangeAxis();
        int int19 = categoryPlot15.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder20 = categoryPlot15.getRowRenderingOrder();
        java.awt.Stroke stroke21 = categoryPlot15.getRangeZeroBaselineStroke();
        categoryPlot5.setRangeMinorGridlineStroke(stroke21);
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = categoryPlot5.getDomainAxis(100);
        boolean boolean25 = categoryPlot5.isNotify();
        org.jfree.chart.entity.PlotEntity plotEntity27 = new org.jfree.chart.entity.PlotEntity(shape4, (org.jfree.chart.plot.Plot) categoryPlot5, "ItemLabelAnchor.OUTSIDE1");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset30 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity33 = new org.jfree.chart.entity.CategoryItemEntity(shape4, "PlotOrientation.VERTICAL", "PlotOrientation.VERTICAL", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset30, (java.lang.Comparable) 10, (java.lang.Comparable) 'a');
        java.lang.Object obj34 = null;
        boolean boolean35 = categoryItemEntity33.equals(obj34);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor36 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE5;
        java.awt.Color color37 = java.awt.Color.white;
        boolean boolean38 = itemLabelAnchor36.equals((java.lang.Object) color37);
        java.awt.Color color39 = java.awt.Color.yellow;
        java.awt.color.ColorSpace colorSpace40 = color39.getColorSpace();
        java.awt.Color color47 = java.awt.Color.getHSBColor((float) (short) 1, (float) 100, 0.0f);
        float[] floatArray54 = new float[] { (byte) 10, (byte) 1, 1.0f, (byte) 0, 10, (byte) 100 };
        float[] floatArray55 = color47.getRGBComponents(floatArray54);
        float[] floatArray56 = java.awt.Color.RGBtoHSB((int) ' ', 1, 255, floatArray54);
        float[] floatArray57 = color37.getComponents(colorSpace40, floatArray56);
        boolean boolean58 = categoryItemEntity33.equals((java.lang.Object) colorSpace40);
        categoryItemEntity33.setColumnKey((java.lang.Comparable) '4');
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertNotNull(categoryAnchor14);
        org.junit.Assert.assertNull(valueAxis18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 15 + "'", int19 == 15);
        org.junit.Assert.assertNotNull(sortOrder20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNull(categoryAxis24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(colorSpace40);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(floatArray54);
        org.junit.Assert.assertNotNull(floatArray55);
        org.junit.Assert.assertNotNull(floatArray56);
        org.junit.Assert.assertNotNull(floatArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder5 = categoryPlot0.getRowRenderingOrder();
        categoryPlot0.mapDatasetToRangeAxis((int) '#', (int) (byte) 10);
        categoryPlot0.setRangeZeroBaselineVisible(false);
        categoryPlot0.setNoDataMessage("ChartChangeEventType.GENERAL");
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(sortOrder5);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getMaximumBarWidth();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
        java.lang.Object obj2 = standardCategorySeriesLabelGenerator1.clone();
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        java.awt.Shape shape4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        int int9 = categoryPlot5.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot5.getRowRenderingOrder();
        java.awt.Stroke stroke11 = categoryPlot5.getRangeZeroBaselineStroke();
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("", "", "hi!", "", shape4, stroke11, paint12);
        legendItem13.setDescription("");
        int int16 = legendItem13.getDatasetIndex();
        java.lang.String str17 = legendItem13.getLabel();
        java.lang.String str18 = legendItem13.getLabel();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset19 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo20 = new org.jfree.chart.event.DatasetChangeInfo();
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent21 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object) legendItem13, (org.jfree.data.general.Dataset) defaultCategoryDataset19, datasetChangeInfo20);
        defaultCategoryDataset19.clearSelection();
        int int23 = defaultCategoryDataset19.getRowCount();
        int int25 = defaultCategoryDataset19.getColumnIndex((java.lang.Comparable) "AxisLocation.BOTTOM_OR_LEFT");
        org.jfree.data.category.CategoryDatasetSelectionState categoryDatasetSelectionState26 = defaultCategoryDataset19.getSelectionState();
        try {
            defaultCategoryDataset19.setSelected(128, (-10214656), true);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 128, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNotNull(categoryDatasetSelectionState26);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape0, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape4 = chartEntity3.getArea();
        java.awt.Shape shape5 = chartEntity3.getArea();
        java.awt.Shape shape6 = chartEntity3.getArea();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(shape6);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Shape shape11 = null;
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", shape11, (java.awt.Paint) color12);
        int int14 = color12.getBlue();
        lineAndShapeRenderer2.setSeriesItemLabelPaint((int) (byte) 1, (java.awt.Paint) color12);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean17 = categoryPlot16.isRangeGridlinesVisible();
        categoryPlot16.clearDomainAxes();
        lineAndShapeRenderer2.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot16);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator20 = lineAndShapeRenderer2.getLegendItemToolTipGenerator();
        lineAndShapeRenderer2.setBaseItemLabelsVisible(true);
        java.awt.Shape shape24 = null;
        lineAndShapeRenderer2.setSeriesShape(15, shape24);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 128 + "'", int14 == 128);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator20);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = categoryAxis1.getTickLabelInsets();
        categoryAxis1.setCategoryLabelPositionOffset(0);
        categoryAxis1.setMinorTickMarksVisible(false);
        float float7 = categoryAxis1.getMinorTickMarkOutsideLength();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = categoryAxis1.getLabelInsets();
        org.jfree.chart.util.UnitType unitType9 = rectangleInsets8.getUnitType();
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType11 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType12 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D13 = rectangleInsets8.createAdjustedRectangle(rectangle2D10, lengthAdjustmentType11, lengthAdjustmentType12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 2.0f + "'", float7 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(unitType9);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape0, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape4 = chartEntity3.getArea();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot5.zoomDomainAxes((double) 10.0f, plotRenderingInfo10, point2D11, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor14 = categoryPlot5.getDomainGridlinePosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot15.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis18 = categoryPlot15.getRangeAxis();
        int int19 = categoryPlot15.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder20 = categoryPlot15.getRowRenderingOrder();
        java.awt.Stroke stroke21 = categoryPlot15.getRangeZeroBaselineStroke();
        categoryPlot5.setRangeMinorGridlineStroke(stroke21);
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = categoryPlot5.getDomainAxis(100);
        boolean boolean25 = categoryPlot5.isNotify();
        org.jfree.chart.entity.PlotEntity plotEntity27 = new org.jfree.chart.entity.PlotEntity(shape4, (org.jfree.chart.plot.Plot) categoryPlot5, "ItemLabelAnchor.OUTSIDE1");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset30 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity33 = new org.jfree.chart.entity.CategoryItemEntity(shape4, "PlotOrientation.VERTICAL", "PlotOrientation.VERTICAL", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset30, (java.lang.Comparable) 10, (java.lang.Comparable) 'a');
        java.awt.Shape shape34 = categoryItemEntity33.getArea();
        java.lang.String str35 = categoryItemEntity33.toString();
        org.jfree.data.category.CategoryDataset categoryDataset36 = categoryItemEntity33.getDataset();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertNotNull(categoryAnchor14);
        org.junit.Assert.assertNull(valueAxis18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 15 + "'", int19 == 15);
        org.junit.Assert.assertNotNull(sortOrder20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNull(categoryAxis24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNotNull(categoryDataset36);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Shape shape11 = null;
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", shape11, (java.awt.Paint) color12);
        int int14 = color12.getBlue();
        lineAndShapeRenderer2.setSeriesItemLabelPaint((int) (byte) 1, (java.awt.Paint) color12);
        java.lang.Boolean boolean17 = lineAndShapeRenderer2.getSeriesShapesFilled(0);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator18 = lineAndShapeRenderer2.getBaseToolTipGenerator();
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.data.Range range20 = lineAndShapeRenderer2.findRangeBounds(categoryDataset19);
        boolean boolean24 = lineAndShapeRenderer2.getItemCreateEntity((int) (byte) 0, (int) (byte) 0, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator25 = lineAndShapeRenderer2.getLegendItemToolTipGenerator();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 128 + "'", int14 == 128);
        org.junit.Assert.assertNull(boolean17);
        org.junit.Assert.assertNull(categoryToolTipGenerator18);
        org.junit.Assert.assertNull(range20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator25);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        java.awt.Shape shape4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        int int9 = categoryPlot5.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot5.getRowRenderingOrder();
        java.awt.Stroke stroke11 = categoryPlot5.getRangeZeroBaselineStroke();
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("", "", "hi!", "", shape4, stroke11, paint12);
        legendItem13.setDescription("");
        int int16 = legendItem13.getDatasetIndex();
        java.lang.String str17 = legendItem13.getLabel();
        java.lang.String str18 = legendItem13.getLabel();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset19 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo20 = new org.jfree.chart.event.DatasetChangeInfo();
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent21 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object) legendItem13, (org.jfree.data.general.Dataset) defaultCategoryDataset19, datasetChangeInfo20);
        defaultCategoryDataset19.clearSelection();
        boolean boolean24 = defaultCategoryDataset19.equals((java.lang.Object) 15);
        try {
            defaultCategoryDataset19.removeRow(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        java.awt.Shape shape4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        int int9 = categoryPlot5.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot5.getRowRenderingOrder();
        java.awt.Stroke stroke11 = categoryPlot5.getRangeZeroBaselineStroke();
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("", "", "hi!", "", shape4, stroke11, paint12);
        legendItem13.setDescription("");
        int int16 = legendItem13.getDatasetIndex();
        java.lang.String str17 = legendItem13.getLabel();
        java.lang.String str18 = legendItem13.getLabel();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset19 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo20 = new org.jfree.chart.event.DatasetChangeInfo();
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent21 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object) legendItem13, (org.jfree.data.general.Dataset) defaultCategoryDataset19, datasetChangeInfo20);
        defaultCategoryDataset19.clearSelection();
        int int23 = defaultCategoryDataset19.getRowCount();
        int int25 = defaultCategoryDataset19.getColumnIndex((java.lang.Comparable) "AxisLocation.BOTTOM_OR_LEFT");
        org.jfree.data.category.CategoryDatasetSelectionState categoryDatasetSelectionState26 = defaultCategoryDataset19.getSelectionState();
        try {
            boolean boolean29 = defaultCategoryDataset19.isSelected((int) '#', (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNotNull(categoryDatasetSelectionState26);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder5 = categoryPlot0.getRowRenderingOrder();
        java.awt.Stroke stroke6 = categoryPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = categoryPlot0.getInsets();
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = categoryPlot10.getDomainAxisEdge();
        int int14 = categoryPlot10.getWeight();
        java.util.List list15 = categoryPlot10.getAnnotations();
        try {
            categoryPlot0.mapDatasetToDomainAxes(2, list15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Empty list not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(sortOrder5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(list15);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder5 = categoryPlot0.getRowRenderingOrder();
        java.awt.Stroke stroke6 = categoryPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent7 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent7);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot9.setRangeAxisLocation(axisLocation10, true);
        categoryPlot0.setDomainAxisLocation(axisLocation10);
        categoryPlot0.setCrosshairDatasetIndex((int) (short) 1);
        org.jfree.data.category.CategoryDataset categoryDataset16 = categoryPlot0.getDataset();
        categoryPlot0.setDomainCrosshairVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.data.Range range20 = categoryPlot0.getDataRange(valueAxis19);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(sortOrder5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNull(categoryDataset16);
        org.junit.Assert.assertNull(range20);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Paint paint6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        lineAndShapeRenderer2.setBaseOutlinePaint(paint6);
        org.jfree.chart.LegendItemCollection legendItemCollection8 = lineAndShapeRenderer2.getLegendItems();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(legendItemCollection8);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder5 = categoryPlot0.getRowRenderingOrder();
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        try {
            categoryPlot0.drawBackground(graphics2D6, rectangle2D7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(sortOrder5);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("rect");
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        java.awt.Shape shape4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        int int9 = categoryPlot5.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot5.getRowRenderingOrder();
        java.awt.Stroke stroke11 = categoryPlot5.getRangeZeroBaselineStroke();
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("", "", "hi!", "", shape4, stroke11, paint12);
        legendItem13.setDescription("");
        int int16 = legendItem13.getDatasetIndex();
        java.lang.String str17 = legendItem13.getLabel();
        java.lang.String str18 = legendItem13.getLabel();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer19 = legendItem13.getFillPaintTransformer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer20 = legendItem13.getFillPaintTransformer();
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertNotNull(gradientPaintTransformer19);
        org.junit.Assert.assertNotNull(gradientPaintTransformer20);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE3;
        java.lang.String str1 = itemLabelAnchor0.toString();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ItemLabelAnchor.OUTSIDE3" + "'", str1.equals("ItemLabelAnchor.OUTSIDE3"));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        java.awt.Color color0 = java.awt.Color.DARK_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Paint paint5 = lineAndShapeRenderer2.getSeriesPaint(15);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = lineAndShapeRenderer2.getSeriesNegativeItemLabelPosition(255);
        int int8 = lineAndShapeRenderer2.getDefaultEntityRadius();
        java.awt.Stroke stroke9 = lineAndShapeRenderer2.getBaseOutlineStroke();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator11 = lineAndShapeRenderer2.getSeriesToolTipGenerator(128);
        lineAndShapeRenderer2.setSeriesItemLabelsVisible(64, (java.lang.Boolean) true, false);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNull(categoryToolTipGenerator11);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot4.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis7 = categoryPlot4.getRangeAxis();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot4.getDrawingSupplier();
        org.jfree.data.category.CategoryDataset categoryDataset9 = categoryPlot4.getDataset();
        boolean boolean10 = lineAndShapeRenderer2.hasListener((java.util.EventListener) categoryPlot4);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = categoryAxis13.getTickLabelInsets();
        categoryAxis13.setCategoryLabelPositionOffset(0);
        categoryAxis13.setMinorTickMarksVisible(false);
        categoryPlot4.setDomainAxis(2, categoryAxis13, false);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNull(categoryDataset9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleInsets14);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Shape shape11 = null;
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", shape11, (java.awt.Paint) color12);
        int int14 = color12.getBlue();
        lineAndShapeRenderer2.setSeriesItemLabelPaint((int) (byte) 1, (java.awt.Paint) color12);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean17 = categoryPlot16.isRangeGridlinesVisible();
        categoryPlot16.clearDomainAxes();
        lineAndShapeRenderer2.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot16);
        float float20 = categoryPlot16.getBackgroundAlpha();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 128 + "'", int14 == 128);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 1.0f + "'", float20 == 1.0f);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        try {
            java.awt.Color color1 = java.awt.Color.decode("{0}");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"{0}\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = categoryAxis1.getTickLabelInsets();
        categoryAxis1.setCategoryLabelPositionOffset(0);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        int int9 = categoryPlot5.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot5.getRowRenderingOrder();
        java.awt.Stroke stroke11 = categoryPlot5.getRangeZeroBaselineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        categoryPlot5.rendererChanged(rendererChangeEvent12);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot14.setRangeAxisLocation(axisLocation15, true);
        categoryPlot5.setDomainAxisLocation(axisLocation15);
        categoryPlot5.setCrosshairDatasetIndex((int) (short) 1);
        categoryAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot5);
        try {
            categoryPlot5.setBackgroundImageAlpha((float) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(axisLocation15);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.clearSeriesStrokes(true);
        lineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(true);
        java.awt.Stroke stroke5 = lineAndShapeRenderer0.getBaseOutlineStroke();
        int int6 = lineAndShapeRenderer0.getPassCount();
        boolean boolean9 = lineAndShapeRenderer0.getItemShapeVisible((int) '#', (int) 'a');
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Paint paint5 = lineAndShapeRenderer2.getSeriesPaint(15);
        double double6 = lineAndShapeRenderer2.getItemLabelAnchorOffset();
        lineAndShapeRenderer2.setSeriesShapesVisible(10, (java.lang.Boolean) true);
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot12.clearDomainMarkers((int) (short) 10);
        categoryPlot12.setDomainGridlinesVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot17.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis20 = categoryPlot17.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        categoryPlot17.zoomDomainAxes((double) 10.0f, plotRenderingInfo22, point2D23, false);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent26 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot17);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType27 = plotChangeEvent26.getType();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType28 = plotChangeEvent26.getType();
        java.lang.Object obj29 = plotChangeEvent26.getSource();
        categoryPlot12.notifyListeners(plotChangeEvent26);
        boolean boolean32 = categoryPlot12.equals((java.lang.Object) "");
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        java.awt.Shape shape39 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot40.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis43 = categoryPlot40.getRangeAxis();
        int int44 = categoryPlot40.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder45 = categoryPlot40.getRowRenderingOrder();
        java.awt.Stroke stroke46 = categoryPlot40.getRangeZeroBaselineStroke();
        java.awt.Paint paint47 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem48 = new org.jfree.chart.LegendItem("", "", "hi!", "", shape39, stroke46, paint47);
        legendItem48.setDescription("");
        int int51 = legendItem48.getDatasetIndex();
        java.lang.String str52 = legendItem48.getLabel();
        java.lang.String str53 = legendItem48.getLabel();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset54 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo55 = new org.jfree.chart.event.DatasetChangeInfo();
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent56 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object) legendItem48, (org.jfree.data.general.Dataset) defaultCategoryDataset54, datasetChangeInfo55);
        defaultCategoryDataset54.clearSelection();
        int int58 = defaultCategoryDataset54.getRowCount();
        int int60 = defaultCategoryDataset54.getColumnIndex((java.lang.Comparable) "AxisLocation.BOTTOM_OR_LEFT");
        defaultCategoryDataset54.fireSelectionEvent();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer67 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke68 = lineAndShapeRenderer67.getBaseStroke();
        java.awt.Paint paint70 = lineAndShapeRenderer67.getSeriesPaint(15);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition72 = lineAndShapeRenderer67.getSeriesNegativeItemLabelPosition(255);
        int int73 = lineAndShapeRenderer67.getDefaultEntityRadius();
        java.awt.Stroke stroke74 = lineAndShapeRenderer67.getBaseOutlineStroke();
        java.awt.Graphics2D graphics2D75 = null;
        java.awt.geom.Rectangle2D rectangle2D76 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot77 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation78 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot77.setRangeAxisLocation(axisLocation78, true);
        java.lang.Comparable comparable81 = categoryPlot77.getDomainCrosshairColumnKey();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer84 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke85 = lineAndShapeRenderer84.getBaseStroke();
        org.jfree.chart.LegendItemCollection legendItemCollection86 = lineAndShapeRenderer84.getLegendItems();
        categoryPlot77.setFixedLegendItems(legendItemCollection86);
        org.jfree.data.category.CategoryDataset categoryDataset88 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo89 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState90 = lineAndShapeRenderer67.initialise(graphics2D75, rectangle2D76, categoryPlot77, categoryDataset88, plotRenderingInfo89);
        try {
            java.awt.Shape shape91 = lineAndShapeRenderer2.createHotSpotShape(graphics2D10, rectangle2D11, categoryPlot12, categoryAxis33, valueAxis34, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset54, (int) (short) 1, (-128), true, categoryItemRendererState90);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.0d + "'", double6 == 2.0d);
        org.junit.Assert.assertNull(valueAxis20);
        org.junit.Assert.assertNotNull(chartChangeEventType27);
        org.junit.Assert.assertNotNull(chartChangeEventType28);
        org.junit.Assert.assertNotNull(obj29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNull(valueAxis43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 15 + "'", int44 == 15);
        org.junit.Assert.assertNotNull(sortOrder45);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "" + "'", str52.equals(""));
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "" + "'", str53.equals(""));
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1) + "'", int60 == (-1));
        org.junit.Assert.assertNotNull(stroke68);
        org.junit.Assert.assertNull(paint70);
        org.junit.Assert.assertNotNull(itemLabelPosition72);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 3 + "'", int73 == 3);
        org.junit.Assert.assertNotNull(stroke74);
        org.junit.Assert.assertNotNull(axisLocation78);
        org.junit.Assert.assertNull(comparable81);
        org.junit.Assert.assertNotNull(stroke85);
        org.junit.Assert.assertNotNull(legendItemCollection86);
        org.junit.Assert.assertNotNull(categoryItemRendererState90);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        java.awt.Shape shape4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        int int9 = categoryPlot5.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot5.getRowRenderingOrder();
        java.awt.Stroke stroke11 = categoryPlot5.getRangeZeroBaselineStroke();
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("", "", "hi!", "", shape4, stroke11, paint12);
        legendItem13.setDescription("");
        java.awt.Paint paint16 = legendItem13.getOutlinePaint();
        java.awt.Paint paint17 = legendItem13.getLinePaint();
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Shape shape9 = lineAndShapeRenderer2.getItemShape((int) (short) 10, 100, true);
        lineAndShapeRenderer2.setBaseSeriesVisible(false);
        java.awt.Shape shape12 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity15 = new org.jfree.chart.entity.ChartEntity(shape12, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape16 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity19 = new org.jfree.chart.entity.ChartEntity(shape16, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape20 = chartEntity19.getArea();
        chartEntity15.setArea(shape20);
        lineAndShapeRenderer2.setBaseShape(shape20, true);
        java.lang.Boolean boolean25 = lineAndShapeRenderer2.getSeriesShapesVisible(1);
        java.awt.Font font26 = lineAndShapeRenderer2.getBaseItemLabelFont();
        java.awt.Font font28 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        lineAndShapeRenderer2.setSeriesItemLabelFont((int) (short) 100, font28);
        lineAndShapeRenderer2.setBaseCreateEntities(true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNull(boolean25);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(font28);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Shape shape9 = lineAndShapeRenderer2.getItemShape((int) (short) 10, 100, true);
        lineAndShapeRenderer2.setBaseSeriesVisible(false);
        java.awt.Shape shape12 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity15 = new org.jfree.chart.entity.ChartEntity(shape12, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape16 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity19 = new org.jfree.chart.entity.ChartEntity(shape16, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape20 = chartEntity19.getArea();
        chartEntity15.setArea(shape20);
        lineAndShapeRenderer2.setBaseShape(shape20, true);
        java.lang.Boolean boolean25 = lineAndShapeRenderer2.getSeriesShapesVisible(1);
        java.awt.Font font26 = lineAndShapeRenderer2.getBaseItemLabelFont();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator28 = lineAndShapeRenderer2.getSeriesItemLabelGenerator(64);
        try {
            lineAndShapeRenderer2.setItemMargin((double) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 0.0 <= margin < 1.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNull(boolean25);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNull(categoryItemLabelGenerator28);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        java.lang.Comparable comparable9 = categoryPlot0.getDomainCrosshairColumnKey();
        boolean boolean10 = categoryPlot0.isRangeCrosshairLockedOnData();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        categoryPlot0.setDomainCrosshairPaint((java.awt.Paint) color11);
        boolean boolean13 = categoryPlot0.isRangeCrosshairVisible();
        java.awt.Shape shape19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot20.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis23 = categoryPlot20.getRangeAxis();
        int int24 = categoryPlot20.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder25 = categoryPlot20.getRowRenderingOrder();
        java.awt.Stroke stroke26 = categoryPlot20.getRangeZeroBaselineStroke();
        java.awt.Paint paint27 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem28 = new org.jfree.chart.LegendItem("", "", "hi!", "", shape19, stroke26, paint27);
        legendItem28.setDescription("");
        int int31 = legendItem28.getDatasetIndex();
        java.lang.String str32 = legendItem28.getLabel();
        java.lang.String str33 = legendItem28.getLabel();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset34 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo35 = new org.jfree.chart.event.DatasetChangeInfo();
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent36 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object) legendItem28, (org.jfree.data.general.Dataset) defaultCategoryDataset34, datasetChangeInfo35);
        java.util.List list37 = defaultCategoryDataset34.getRowKeys();
        try {
            categoryPlot0.mapDatasetToRangeAxes((int) (short) 1, list37);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Empty list not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNull(comparable9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 15 + "'", int24 == 15);
        org.junit.Assert.assertNotNull(sortOrder25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "" + "'", str32.equals(""));
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "" + "'", str33.equals(""));
        org.junit.Assert.assertNotNull(list37);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        java.awt.Shape shape4 = null;
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem6 = new org.jfree.chart.LegendItem("", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", shape4, (java.awt.Paint) color5);
        java.awt.Shape shape7 = legendItem6.getShape();
        int int8 = legendItem6.getSeriesIndex();
        boolean boolean9 = legendItem6.isShapeVisible();
        java.text.AttributedString attributedString10 = legendItem6.getAttributedLabel();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(shape7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(attributedString10);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent9 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot0);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis13 = categoryPlot10.getRangeAxis();
        int int14 = categoryPlot10.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder15 = categoryPlot10.getRowRenderingOrder();
        java.awt.Stroke stroke16 = categoryPlot10.getRangeZeroBaselineStroke();
        categoryPlot0.setOutlineStroke(stroke16);
        categoryPlot0.setRangeCrosshairVisible(false);
        int int20 = categoryPlot0.getDomainAxisCount();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = categoryPlot0.getAxisOffset();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNull(valueAxis13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 15 + "'", int14 == 15);
        org.junit.Assert.assertNotNull(sortOrder15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(rectangleInsets21);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        java.lang.Comparable comparable9 = categoryPlot0.getDomainCrosshairColumnKey();
        boolean boolean10 = categoryPlot0.isRangeCrosshairLockedOnData();
        categoryPlot0.setCrosshairDatasetIndex((int) (byte) 10, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = categoryPlot0.getInsets();
        double double16 = rectangleInsets14.extendHeight((-1.0d));
        double double18 = rectangleInsets14.calculateTopOutset((double) (byte) 0);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNull(comparable9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 7.0d + "'", double16 == 7.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 4.0d + "'", double18 == 4.0d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        categoryPlot0.setRangeCrosshairVisible(false);
        categoryPlot0.setCrosshairDatasetIndex(3, true);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        lineAndShapeRenderer2.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator7);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = lineAndShapeRenderer2.getSeriesPositiveItemLabelPosition(0);
        java.awt.Stroke stroke11 = lineAndShapeRenderer2.getBaseStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = lineAndShapeRenderer2.getPlot();
        java.lang.Boolean boolean14 = lineAndShapeRenderer2.getSeriesLinesVisible((int) (short) 10);
        lineAndShapeRenderer2.setBaseShapesFilled(false);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(categoryPlot12);
        org.junit.Assert.assertNull(boolean14);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        renderAttributes0.setDefaultFillPaint((java.awt.Paint) color1);
        java.awt.Shape shape5 = renderAttributes0.getItemShape((int) (byte) 100, (int) 'a');
        java.awt.Shape shape7 = null;
        renderAttributes0.setSeriesShape((int) (byte) 1, shape7);
        java.awt.Paint paint9 = renderAttributes0.getDefaultFillPaint();
        java.awt.Paint paint10 = renderAttributes0.getDefaultLabelPaint();
        java.awt.Paint paint12 = renderAttributes0.getSeriesFillPaint((-10214656));
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNull(shape5);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNull(paint12);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis4 = categoryPlot1.getRangeAxis();
        int int5 = categoryPlot1.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder6 = categoryPlot1.getRowRenderingOrder();
        java.awt.Stroke stroke7 = categoryPlot1.getRangeZeroBaselineStroke();
        categoryPlot1.setRangeGridlinesVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis13 = categoryPlot10.getRangeAxis();
        int int14 = categoryPlot10.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder15 = categoryPlot10.getRowRenderingOrder();
        java.awt.Stroke stroke16 = categoryPlot10.getRangeZeroBaselineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent17 = null;
        categoryPlot10.rendererChanged(rendererChangeEvent17);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation20 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot19.setRangeAxisLocation(axisLocation20, true);
        categoryPlot10.setDomainAxisLocation(axisLocation20);
        categoryPlot1.setDomainAxisLocation(axisLocation20, true);
        categoryPlot1.setBackgroundAlpha((float) 10);
        boolean boolean28 = defaultDrawingSupplier0.equals((java.lang.Object) 10);
        java.awt.Paint paint29 = defaultDrawingSupplier0.getNextOutlinePaint();
        java.awt.Shape shape30 = defaultDrawingSupplier0.getNextShape();
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
        org.junit.Assert.assertNotNull(sortOrder6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(valueAxis13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 15 + "'", int14 == 15);
        org.junit.Assert.assertNotNull(sortOrder15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(shape30);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder5 = categoryPlot0.getRowRenderingOrder();
        categoryPlot0.setWeight((int) (short) 100);
        int int8 = categoryPlot0.getDomainAxisCount();
        org.jfree.chart.LegendItemCollection legendItemCollection9 = categoryPlot0.getFixedLegendItems();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(sortOrder5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNull(legendItemCollection9);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        lineAndShapeRenderer2.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator7);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = lineAndShapeRenderer2.getSeriesPositiveItemLabelPosition(0);
        lineAndShapeRenderer2.setBaseShapesFilled(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
        lineAndShapeRenderer2.notifyListeners(rendererChangeEvent13);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot15.clearDomainMarkers((int) (short) 10);
        categoryPlot15.setDomainGridlinesVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot20.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis23 = categoryPlot20.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        categoryPlot20.zoomDomainAxes((double) 10.0f, plotRenderingInfo25, point2D26, false);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent29 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot20);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType30 = plotChangeEvent29.getType();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType31 = plotChangeEvent29.getType();
        java.lang.Object obj32 = plotChangeEvent29.getSource();
        categoryPlot15.notifyListeners(plotChangeEvent29);
        java.awt.Stroke stroke34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot15.setOutlineStroke(stroke34);
        lineAndShapeRenderer2.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot15);
        categoryPlot15.setCrosshairDatasetIndex(0, true);
        categoryPlot15.configureDomainAxes();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(chartChangeEventType30);
        org.junit.Assert.assertNotNull(chartChangeEventType31);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertNotNull(stroke34);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape0, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape4 = chartEntity3.getArea();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot5.zoomDomainAxes((double) 10.0f, plotRenderingInfo10, point2D11, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor14 = categoryPlot5.getDomainGridlinePosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot15.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis18 = categoryPlot15.getRangeAxis();
        int int19 = categoryPlot15.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder20 = categoryPlot15.getRowRenderingOrder();
        java.awt.Stroke stroke21 = categoryPlot15.getRangeZeroBaselineStroke();
        categoryPlot5.setRangeMinorGridlineStroke(stroke21);
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = categoryPlot5.getDomainAxis(100);
        boolean boolean25 = categoryPlot5.isNotify();
        org.jfree.chart.entity.PlotEntity plotEntity27 = new org.jfree.chart.entity.PlotEntity(shape4, (org.jfree.chart.plot.Plot) categoryPlot5, "ItemLabelAnchor.OUTSIDE1");
        boolean boolean28 = categoryPlot5.isRangeZoomable();
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryPlot5.setRangeCrosshairPaint((java.awt.Paint) color29);
        org.jfree.chart.plot.Marker marker32 = null;
        org.jfree.chart.util.Layer layer33 = null;
        try {
            categoryPlot5.addRangeMarker(15, marker32, layer33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertNotNull(categoryAnchor14);
        org.junit.Assert.assertNull(valueAxis18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 15 + "'", int19 == 15);
        org.junit.Assert.assertNotNull(sortOrder20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNull(categoryAxis24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(color29);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Shape shape9 = lineAndShapeRenderer2.getItemShape((int) (short) 10, 100, true);
        lineAndShapeRenderer2.setBaseSeriesVisible(false);
        java.awt.Shape shape12 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity15 = new org.jfree.chart.entity.ChartEntity(shape12, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape16 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity19 = new org.jfree.chart.entity.ChartEntity(shape16, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape20 = chartEntity19.getArea();
        chartEntity15.setArea(shape20);
        lineAndShapeRenderer2.setBaseShape(shape20, true);
        java.lang.Boolean boolean25 = lineAndShapeRenderer2.getSeriesShapesVisible(1);
        java.awt.Font font26 = lineAndShapeRenderer2.getBaseItemLabelFont();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator28 = lineAndShapeRenderer2.getSeriesItemLabelGenerator(64);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator30 = null;
        lineAndShapeRenderer2.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator30, true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNull(boolean25);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNull(categoryItemLabelGenerator28);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        lineAndShapeRenderer2.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator7);
        lineAndShapeRenderer2.setSeriesVisible((int) (short) 100, (java.lang.Boolean) false, true);
        boolean boolean15 = lineAndShapeRenderer2.getItemShapeVisible((int) (short) 10, 3);
        lineAndShapeRenderer2.setSeriesVisibleInLegend(100, (java.lang.Boolean) true, true);
        java.awt.Shape shape21 = lineAndShapeRenderer2.lookupSeriesShape((int) (byte) 100);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(shape21);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = categoryAxis3.getTickLabelInsets();
        categoryAxis3.setCategoryLabelPositionOffset(0);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions7 = categoryAxis3.getCategoryLabelPositions();
        categoryAxis1.setCategoryLabelPositions(categoryLabelPositions7);
        java.lang.Comparable comparable9 = null;
        java.awt.Shape shape14 = null;
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem16 = new org.jfree.chart.LegendItem("", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", shape14, (java.awt.Paint) color15);
        java.awt.color.ColorSpace colorSpace17 = color15.getColorSpace();
        java.awt.Color color18 = org.jfree.chart.ChartColor.DARK_CYAN;
        boolean boolean19 = color15.equals((java.lang.Object) color18);
        try {
            categoryAxis1.setTickLabelPaint(comparable9, (java.awt.Paint) color18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(categoryLabelPositions7);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(colorSpace17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getMinimumBarLength();
        java.awt.Paint paint5 = barRenderer0.getItemPaint(0, 15, true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator6 = barRenderer0.getBaseURLGenerator();
        try {
            barRenderer0.setMinimumBarLength((double) (-128));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'min' >= 0.0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(categoryURLGenerator6);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        java.awt.Shape shape4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        int int9 = categoryPlot5.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot5.getRowRenderingOrder();
        java.awt.Stroke stroke11 = categoryPlot5.getRangeZeroBaselineStroke();
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("", "", "hi!", "", shape4, stroke11, paint12);
        legendItem13.setDescription("");
        int int16 = legendItem13.getDatasetIndex();
        legendItem13.setToolTipText("SortOrder.ASCENDING");
        boolean boolean19 = legendItem13.isShapeOutlineVisible();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType20 = org.jfree.chart.util.GradientPaintTransformType.CENTER_HORIZONTAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer21 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType20);
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType22 = standardGradientPaintTransformer21.getType();
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot23.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis26 = categoryPlot23.getRangeAxis();
        int int27 = categoryPlot23.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder28 = categoryPlot23.getRowRenderingOrder();
        java.awt.Stroke stroke29 = categoryPlot23.getRangeZeroBaselineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent30 = null;
        categoryPlot23.rendererChanged(rendererChangeEvent30);
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation33 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot32.setRangeAxisLocation(axisLocation33, true);
        categoryPlot23.setDomainAxisLocation(axisLocation33);
        categoryPlot23.setCrosshairDatasetIndex((int) (short) 1);
        org.jfree.data.category.CategoryDataset categoryDataset39 = categoryPlot23.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = categoryPlot23.getAxisOffset();
        double double42 = rectangleInsets40.calculateRightInset((double) (-1L));
        boolean boolean43 = standardGradientPaintTransformer21.equals((java.lang.Object) rectangleInsets40);
        legendItem13.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer21);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(gradientPaintTransformType20);
        org.junit.Assert.assertNotNull(gradientPaintTransformType22);
        org.junit.Assert.assertNull(valueAxis26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 15 + "'", int27 == 15);
        org.junit.Assert.assertNotNull(sortOrder28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(axisLocation33);
        org.junit.Assert.assertNull(categoryDataset39);
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 4.0d + "'", double42 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.clearSeriesStrokes(true);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator4 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("java.awt.Color[r=0,g=0,b=0]");
        lineAndShapeRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator4);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator6 = lineAndShapeRenderer0.getBaseItemLabelGenerator();
        lineAndShapeRenderer0.setSeriesVisible(100, (java.lang.Boolean) true, false);
        org.junit.Assert.assertNull(categoryItemLabelGenerator6);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Shape shape9 = lineAndShapeRenderer2.getItemShape((int) (short) 10, 100, true);
        boolean boolean13 = lineAndShapeRenderer2.getItemCreateEntity(0, (int) 'a', true);
        java.awt.Font font15 = lineAndShapeRenderer2.lookupLegendTextFont((int) (byte) 10);
        java.awt.Color color17 = java.awt.Color.red;
        lineAndShapeRenderer2.setSeriesPaint(156, (java.awt.Paint) color17);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNull(font15);
        org.junit.Assert.assertNotNull(color17);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder5 = categoryPlot0.getRowRenderingOrder();
        java.awt.Stroke stroke6 = categoryPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = categoryPlot0.getInsets();
        java.lang.Object obj8 = categoryPlot0.clone();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot0.zoomRangeAxes((double) 2, plotRenderingInfo10, point2D11, false);
        java.awt.Paint paint14 = null;
        categoryPlot0.setOutlinePaint(paint14);
        categoryPlot0.clearDomainMarkers((-10214656));
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        try {
            categoryPlot0.handleClick((-10214656), 0, plotRenderingInfo20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(sortOrder5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getMinimumBarLength();
        java.awt.Paint paint5 = barRenderer0.getItemPaint(0, 15, true);
        barRenderer0.setShadowXOffset((double) 100L);
        java.awt.Shape shape13 = null;
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", shape13, (java.awt.Paint) color14);
        java.awt.Shape shape16 = legendItem15.getShape();
        java.awt.Paint paint17 = legendItem15.getLinePaint();
        java.awt.Paint paint18 = legendItem15.getLinePaint();
        java.awt.Paint paint19 = legendItem15.getOutlinePaint();
        barRenderer0.setSeriesPaint((int) (short) 100, paint19, true);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNull(shape16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor9 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis13 = categoryPlot10.getRangeAxis();
        int int14 = categoryPlot10.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder15 = categoryPlot10.getRowRenderingOrder();
        java.awt.Stroke stroke16 = categoryPlot10.getRangeZeroBaselineStroke();
        categoryPlot0.setRangeMinorGridlineStroke(stroke16);
        org.jfree.chart.axis.ValueAxis valueAxis19 = categoryPlot0.getRangeAxis(1);
        boolean boolean20 = categoryPlot0.isDomainZoomable();
        java.awt.Paint paint21 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer24 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke25 = lineAndShapeRenderer24.getBaseStroke();
        org.jfree.chart.LegendItemCollection legendItemCollection26 = lineAndShapeRenderer24.getLegendItems();
        org.jfree.chart.renderer.RenderAttributes renderAttributes27 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Shape shape30 = renderAttributes27.getItemShape((int) (byte) 10, 15);
        java.awt.Color color32 = java.awt.Color.CYAN;
        renderAttributes27.setSeriesOutlinePaint((int) (byte) 0, (java.awt.Paint) color32);
        lineAndShapeRenderer24.setBaseItemLabelPaint((java.awt.Paint) color32, true);
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color32);
        org.jfree.chart.plot.Marker marker38 = null;
        org.jfree.chart.util.Layer layer39 = null;
        try {
            categoryPlot0.addRangeMarker(255, marker38, layer39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(categoryAnchor9);
        org.junit.Assert.assertNull(valueAxis13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 15 + "'", int14 == 15);
        org.junit.Assert.assertNotNull(sortOrder15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNull(valueAxis19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(legendItemCollection26);
        org.junit.Assert.assertNull(shape30);
        org.junit.Assert.assertNotNull(color32);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Shape shape11 = null;
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", shape11, (java.awt.Paint) color12);
        int int14 = color12.getBlue();
        lineAndShapeRenderer2.setSeriesItemLabelPaint((int) (byte) 1, (java.awt.Paint) color12);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean17 = categoryPlot16.isRangeGridlinesVisible();
        categoryPlot16.clearDomainAxes();
        lineAndShapeRenderer2.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot16);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator21 = lineAndShapeRenderer2.getSeriesURLGenerator((int) 'a');
        lineAndShapeRenderer2.setBaseItemLabelsVisible(true, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition25 = lineAndShapeRenderer2.getBasePositiveItemLabelPosition();
        java.awt.Paint paint27 = lineAndShapeRenderer2.getLegendTextPaint(64);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 128 + "'", int14 == 128);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNull(categoryURLGenerator21);
        org.junit.Assert.assertNotNull(itemLabelPosition25);
        org.junit.Assert.assertNull(paint27);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        java.awt.Color color0 = java.awt.Color.yellow;
        java.awt.color.ColorSpace colorSpace1 = color0.getColorSpace();
        int int2 = color0.getTransparency();
        int int3 = color0.getAlpha();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(colorSpace1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 255 + "'", int3 == 255);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape2, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape6 = chartEntity5.getArea();
        java.awt.Shape shape7 = chartEntity5.getArea();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot8.getDomainAxisEdge();
        int int12 = categoryPlot8.getWeight();
        java.lang.Comparable comparable13 = categoryPlot8.getDomainCrosshairColumnKey();
        boolean boolean14 = categoryPlot8.canSelectByRegion();
        org.jfree.chart.axis.AxisLocation axisLocation15 = categoryPlot8.getRangeAxisLocation();
        org.jfree.chart.entity.PlotEntity plotEntity18 = new org.jfree.chart.entity.PlotEntity(shape7, (org.jfree.chart.plot.Plot) categoryPlot8, "ItemLabelAnchor.OUTSIDE1", "java.awt.Color[r=0,g=0,b=0]");
        shapeList0.setShape(156, shape7);
        org.jfree.data.UnknownKeyException unknownKeyException21 = new org.jfree.data.UnknownKeyException("rect");
        java.lang.Throwable[] throwableArray22 = unknownKeyException21.getSuppressed();
        boolean boolean23 = shapeList0.equals((java.lang.Object) throwableArray22);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNull(comparable13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(throwableArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        java.lang.Comparable comparable9 = categoryPlot0.getDomainCrosshairColumnKey();
        boolean boolean10 = categoryPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = categoryPlot0.getAxisOffset();
        double double13 = rectangleInsets11.calculateLeftOutset(2.0d);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNull(comparable9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 4.0d + "'", double13 == 4.0d);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder5 = categoryPlot0.getRowRenderingOrder();
        java.awt.Stroke stroke6 = categoryPlot0.getRangeZeroBaselineStroke();
        int int7 = categoryPlot0.getCrosshairDatasetIndex();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke11 = lineAndShapeRenderer10.getBaseStroke();
        java.awt.Stroke stroke13 = lineAndShapeRenderer10.lookupSeriesStroke(10);
        lineAndShapeRenderer10.setAutoPopulateSeriesStroke(true);
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer10, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator19 = lineAndShapeRenderer10.getSeriesToolTipGenerator((int) (short) 1);
        java.lang.Boolean boolean21 = lineAndShapeRenderer10.getSeriesCreateEntities((-16728064));
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(sortOrder5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNull(categoryToolTipGenerator19);
        org.junit.Assert.assertNull(boolean21);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        java.awt.Color color1 = java.awt.Color.gray;
        org.jfree.chart.LegendItem legendItem2 = new org.jfree.chart.LegendItem("ItemLabelAnchor.OUTSIDE1", (java.awt.Paint) color1);
        java.lang.String str3 = legendItem2.getToolTipText();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder5 = categoryPlot0.getRowRenderingOrder();
        java.awt.Stroke stroke6 = categoryPlot0.getRangeZeroBaselineStroke();
        categoryPlot0.setRangeGridlinesVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot9.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis12 = categoryPlot9.getRangeAxis();
        int int13 = categoryPlot9.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder14 = categoryPlot9.getRowRenderingOrder();
        java.awt.Stroke stroke15 = categoryPlot9.getRangeZeroBaselineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent16 = null;
        categoryPlot9.rendererChanged(rendererChangeEvent16);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation19 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot18.setRangeAxisLocation(axisLocation19, true);
        categoryPlot9.setDomainAxisLocation(axisLocation19);
        categoryPlot0.setDomainAxisLocation(axisLocation19, true);
        categoryPlot0.setBackgroundAlpha((float) 10);
        org.jfree.chart.axis.AxisLocation axisLocation27 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.axis.AxisLocation axisLocation28 = axisLocation27.getOpposite();
        categoryPlot0.setRangeAxisLocation(axisLocation28);
        java.awt.Paint paint30 = categoryPlot0.getOutlinePaint();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(sortOrder5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 15 + "'", int13 == 15);
        org.junit.Assert.assertNotNull(sortOrder14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertNotNull(paint30);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor9 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis13 = categoryPlot10.getRangeAxis();
        int int14 = categoryPlot10.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder15 = categoryPlot10.getRowRenderingOrder();
        java.awt.Stroke stroke16 = categoryPlot10.getRangeZeroBaselineStroke();
        categoryPlot0.setRangeMinorGridlineStroke(stroke16);
        org.jfree.chart.axis.AxisSpace axisSpace18 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace18);
        org.jfree.chart.axis.AxisLocation axisLocation21 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot0.setRangeAxisLocation(0, axisLocation21);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(categoryAnchor9);
        org.junit.Assert.assertNull(valueAxis13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 15 + "'", int14 == 15);
        org.junit.Assert.assertNotNull(sortOrder15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(axisLocation21);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateBottomInset((double) (byte) 1);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setAutoPopulateSeriesPaint(true);
        java.util.EventListener eventListener3 = null;
        boolean boolean4 = lineAndShapeRenderer0.hasListener(eventListener3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = null;
        lineAndShapeRenderer2.setSeriesItemLabelGenerator((int) (byte) 1, categoryItemLabelGenerator5);
        java.awt.Paint paint7 = lineAndShapeRenderer2.getBaseOutlinePaint();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Shape shape9 = lineAndShapeRenderer2.getItemShape((int) (short) 10, 100, true);
        lineAndShapeRenderer2.setBaseSeriesVisible(false);
        java.awt.Shape shape15 = lineAndShapeRenderer2.getItemShape((int) (byte) 100, 1, true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(shape15);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Shape shape9 = lineAndShapeRenderer2.getItemShape((int) (short) 10, 100, true);
        lineAndShapeRenderer2.setBaseSeriesVisible(false);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation12 = null;
        try {
            lineAndShapeRenderer2.addAnnotation(categoryAnnotation12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(shape9);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        java.awt.Paint paint5 = categoryPlot0.getNoDataMessagePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = categoryPlot0.getDomainAxisForDataset((int) 'a');
        java.awt.Paint paint8 = categoryPlot0.getDomainCrosshairPaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = categoryAxis10.getTickLabelInsets();
        categoryPlot0.setDomainAxis(categoryAxis10);
        java.awt.Stroke stroke13 = categoryAxis10.getTickMarkStroke();
        int int14 = categoryAxis10.getCategoryLabelPositionOffset();
        boolean boolean15 = categoryAxis10.isTickMarksVisible();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(categoryAxis7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("AxisLocation.BOTTOM_OR_LEFT", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor9 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis13 = categoryPlot10.getRangeAxis();
        int int14 = categoryPlot10.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder15 = categoryPlot10.getRowRenderingOrder();
        categoryPlot0.setRowRenderingOrder(sortOrder15);
        categoryPlot0.mapDatasetToDomainAxis(2, 10);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier20 = categoryPlot0.getDrawingSupplier();
        org.jfree.chart.LegendItemCollection legendItemCollection21 = categoryPlot0.getLegendItems();
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = categoryAxis23.getTickLabelInsets();
        categoryAxis23.setCategoryLabelPositionOffset(0);
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot27.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis30 = categoryPlot27.getRangeAxis();
        int int31 = categoryPlot27.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder32 = categoryPlot27.getRowRenderingOrder();
        java.awt.Stroke stroke33 = categoryPlot27.getRangeZeroBaselineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent34 = null;
        categoryPlot27.rendererChanged(rendererChangeEvent34);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation37 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot36.setRangeAxisLocation(axisLocation37, true);
        categoryPlot27.setDomainAxisLocation(axisLocation37);
        categoryPlot27.setCrosshairDatasetIndex((int) (short) 1);
        categoryAxis23.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot27);
        org.jfree.chart.plot.Plot plot44 = categoryAxis23.getPlot();
        boolean boolean45 = legendItemCollection21.equals((java.lang.Object) plot44);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(categoryAnchor9);
        org.junit.Assert.assertNull(valueAxis13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 15 + "'", int14 == 15);
        org.junit.Assert.assertNotNull(sortOrder15);
        org.junit.Assert.assertNotNull(drawingSupplier20);
        org.junit.Assert.assertNotNull(legendItemCollection21);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNull(valueAxis30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 15 + "'", int31 == 15);
        org.junit.Assert.assertNotNull(sortOrder32);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNull(plot44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.clearSeriesStrokes(true);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator4 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("java.awt.Color[r=0,g=0,b=0]");
        lineAndShapeRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator4);
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity9 = new org.jfree.chart.entity.ChartEntity(shape6, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape10 = chartEntity9.getArea();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot11.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis14 = categoryPlot11.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        categoryPlot11.zoomDomainAxes((double) 10.0f, plotRenderingInfo16, point2D17, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor20 = categoryPlot11.getDomainGridlinePosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot21.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis24 = categoryPlot21.getRangeAxis();
        int int25 = categoryPlot21.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder26 = categoryPlot21.getRowRenderingOrder();
        java.awt.Stroke stroke27 = categoryPlot21.getRangeZeroBaselineStroke();
        categoryPlot11.setRangeMinorGridlineStroke(stroke27);
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = categoryPlot11.getDomainAxis(100);
        boolean boolean31 = categoryPlot11.isNotify();
        org.jfree.chart.entity.PlotEntity plotEntity33 = new org.jfree.chart.entity.PlotEntity(shape10, (org.jfree.chart.plot.Plot) categoryPlot11, "ItemLabelAnchor.OUTSIDE1");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset36 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity39 = new org.jfree.chart.entity.CategoryItemEntity(shape10, "PlotOrientation.VERTICAL", "PlotOrientation.VERTICAL", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset36, (java.lang.Comparable) 10, (java.lang.Comparable) 'a');
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset42 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset42.clear();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity46 = new org.jfree.chart.entity.CategoryItemEntity(shape10, "AxisLocation.BOTTOM_OR_LEFT", "ItemLabelAnchor.OUTSIDE2", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset42, (java.lang.Comparable) 7.0d, (java.lang.Comparable) "PlotOrientation.VERTICAL");
        try {
            java.lang.String str48 = standardCategorySeriesLabelGenerator4.generateLabel((org.jfree.data.category.CategoryDataset) defaultCategoryDataset42, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNull(valueAxis14);
        org.junit.Assert.assertNotNull(categoryAnchor20);
        org.junit.Assert.assertNull(valueAxis24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 15 + "'", int25 == 15);
        org.junit.Assert.assertNotNull(sortOrder26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNull(categoryAxis30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor9 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis13 = categoryPlot10.getRangeAxis();
        int int14 = categoryPlot10.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder15 = categoryPlot10.getRowRenderingOrder();
        categoryPlot0.setRowRenderingOrder(sortOrder15);
        categoryPlot0.mapDatasetToDomainAxis(2, 10);
        org.jfree.chart.axis.AxisLocation axisLocation21 = categoryPlot0.getRangeAxisLocation(156);
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = null;
        org.jfree.chart.util.Layer layer23 = null;
        try {
            categoryPlot0.addDomainMarker(categoryMarker22, layer23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(categoryAnchor9);
        org.junit.Assert.assertNull(valueAxis13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 15 + "'", int14 == 15);
        org.junit.Assert.assertNotNull(sortOrder15);
        org.junit.Assert.assertNotNull(axisLocation21);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = defaultCategoryDataset0.getGroup();
        java.lang.Object obj2 = datasetGroup1.clone();
        org.junit.Assert.assertNotNull(datasetGroup1);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        categoryPlot0.setDomainCrosshairColumnKey((java.lang.Comparable) (short) -1, true);
        org.jfree.chart.util.Layer layer9 = null;
        java.util.Collection collection10 = categoryPlot0.getRangeMarkers((int) (short) 0, layer9);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot11.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis14 = categoryPlot11.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        categoryPlot11.zoomDomainAxes((double) 10.0f, plotRenderingInfo16, point2D17, false);
        java.lang.Comparable comparable20 = categoryPlot11.getDomainCrosshairColumnKey();
        boolean boolean21 = categoryPlot11.isRangeCrosshairLockedOnData();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = categoryPlot11.getAxisOffset();
        double double23 = rectangleInsets22.getLeft();
        categoryPlot0.setAxisOffset(rectangleInsets22);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        categoryPlot0.setRenderer(0, categoryItemRenderer26);
        java.awt.Color color28 = java.awt.Color.yellow;
        java.awt.color.ColorSpace colorSpace29 = color28.getColorSpace();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color28);
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = categoryPlot0.getDomainAxis(0);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNull(collection10);
        org.junit.Assert.assertNull(valueAxis14);
        org.junit.Assert.assertNull(comparable20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 4.0d + "'", double23 == 4.0d);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(colorSpace29);
        org.junit.Assert.assertNull(categoryAxis32);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor9 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis13 = categoryPlot10.getRangeAxis();
        int int14 = categoryPlot10.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder15 = categoryPlot10.getRowRenderingOrder();
        java.awt.Stroke stroke16 = categoryPlot10.getRangeZeroBaselineStroke();
        categoryPlot0.setRangeMinorGridlineStroke(stroke16);
        java.awt.Stroke stroke18 = categoryPlot0.getDomainGridlineStroke();
        boolean boolean19 = categoryPlot0.isDomainCrosshairVisible();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(categoryAnchor9);
        org.junit.Assert.assertNull(valueAxis13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 15 + "'", int14 == 15);
        org.junit.Assert.assertNotNull(sortOrder15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = categoryAxis3.getTickLabelInsets();
        categoryAxis3.setCategoryLabelPositionOffset(0);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions7 = categoryAxis3.getCategoryLabelPositions();
        categoryAxis1.setCategoryLabelPositions(categoryLabelPositions7);
        java.awt.Paint paint9 = categoryAxis1.getAxisLinePaint();
        double double10 = categoryAxis1.getLowerMargin();
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(categoryLabelPositions7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.05d + "'", double10 == 0.05d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("hi!");
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor9 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis13 = categoryPlot10.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Point2D point2D16 = null;
        categoryPlot10.zoomDomainAxes((double) 10.0f, plotRenderingInfo15, point2D16, false);
        boolean boolean19 = categoryPlot10.isRangeCrosshairVisible();
        java.awt.Stroke stroke20 = categoryPlot10.getRangeCrosshairStroke();
        boolean boolean21 = categoryAnchor9.equals((java.lang.Object) categoryPlot10);
        int int22 = categoryPlot10.getCrosshairDatasetIndex();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray23 = new org.jfree.chart.axis.ValueAxis[] {};
        categoryPlot10.setRangeAxes(valueAxisArray23);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = categoryPlot10.getInsets();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(categoryAnchor9);
        org.junit.Assert.assertNull(valueAxis13);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(valueAxisArray23);
        org.junit.Assert.assertNotNull(rectangleInsets25);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = categoryAxis1.getTickLabelInsets();
        java.lang.String str3 = categoryAxis1.getLabel();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets();
        double double6 = rectangleInsets4.calculateTopOutset((double) ' ');
        categoryAxis1.setLabelInsets(rectangleInsets4);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "DatasetRenderingOrder.REVERSE" + "'", str3.equals("DatasetRenderingOrder.REVERSE"));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Shape shape11 = null;
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", shape11, (java.awt.Paint) color12);
        int int14 = color12.getBlue();
        lineAndShapeRenderer2.setSeriesItemLabelPaint((int) (byte) 1, (java.awt.Paint) color12);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean17 = categoryPlot16.isRangeGridlinesVisible();
        categoryPlot16.clearDomainAxes();
        lineAndShapeRenderer2.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot16);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator21 = lineAndShapeRenderer2.getSeriesURLGenerator((int) 'a');
        lineAndShapeRenderer2.setBaseItemLabelsVisible(true, false);
        java.lang.Boolean boolean26 = lineAndShapeRenderer2.getSeriesVisible(156);
        int int27 = lineAndShapeRenderer2.getPassCount();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 128 + "'", int14 == 128);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNull(categoryURLGenerator21);
        org.junit.Assert.assertNull(boolean26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2 + "'", int27 == 2);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isRangeGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getRangeAxisEdge((int) (byte) -1);
        categoryPlot0.clearRangeMarkers((int) (short) -1);
        int int6 = categoryPlot0.getWeight();
        org.jfree.chart.plot.CategoryMarker categoryMarker7 = null;
        try {
            categoryPlot0.addDomainMarker(categoryMarker7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        lineAndShapeRenderer2.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator7);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = lineAndShapeRenderer2.getSeriesPositiveItemLabelPosition(0);
        java.awt.Stroke stroke11 = lineAndShapeRenderer2.getBaseStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = lineAndShapeRenderer2.getPlot();
        java.lang.Boolean boolean14 = lineAndShapeRenderer2.getSeriesLinesVisible((int) (short) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = null;
        try {
            lineAndShapeRenderer2.setBasePositiveItemLabelPosition(itemLabelPosition15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(categoryPlot12);
        org.junit.Assert.assertNull(boolean14);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        java.awt.Paint paint5 = categoryPlot0.getNoDataMessagePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = categoryPlot0.getDomainAxisForDataset((int) 'a');
        categoryPlot0.setBackgroundImageAlpha((float) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis13 = categoryPlot10.getRangeAxis();
        int int14 = categoryPlot10.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder15 = categoryPlot10.getRowRenderingOrder();
        categoryPlot10.setWeight((int) (short) 100);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot18.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis21 = categoryPlot18.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Point2D point2D24 = null;
        categoryPlot18.zoomDomainAxes((double) 10.0f, plotRenderingInfo23, point2D24, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor27 = categoryPlot18.getDomainGridlinePosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot28.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis31 = categoryPlot28.getRangeAxis();
        int int32 = categoryPlot28.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder33 = categoryPlot28.getRowRenderingOrder();
        java.awt.Stroke stroke34 = categoryPlot28.getRangeZeroBaselineStroke();
        categoryPlot18.setRangeMinorGridlineStroke(stroke34);
        categoryPlot10.setRangeZeroBaselineStroke(stroke34);
        categoryPlot0.setDomainCrosshairStroke(stroke34);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(categoryAxis7);
        org.junit.Assert.assertNull(valueAxis13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 15 + "'", int14 == 15);
        org.junit.Assert.assertNotNull(sortOrder15);
        org.junit.Assert.assertNull(valueAxis21);
        org.junit.Assert.assertNotNull(categoryAnchor27);
        org.junit.Assert.assertNull(valueAxis31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 15 + "'", int32 == 15);
        org.junit.Assert.assertNotNull(sortOrder33);
        org.junit.Assert.assertNotNull(stroke34);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        org.jfree.chart.LegendItemCollection legendItemCollection4 = lineAndShapeRenderer2.getLegendItems();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke9 = lineAndShapeRenderer8.getBaseStroke();
        java.awt.Paint paint11 = lineAndShapeRenderer8.getSeriesPaint(15);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = lineAndShapeRenderer8.getSeriesNegativeItemLabelPosition(255);
        lineAndShapeRenderer2.setSeriesNegativeItemLabelPosition(0, itemLabelPosition13, false);
        java.awt.Color color20 = java.awt.Color.getHSBColor((float) 100L, 0.0f, 100.0f);
        lineAndShapeRenderer2.setLegendTextPaint((int) (short) 100, (java.awt.Paint) color20);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(legendItemCollection4);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(itemLabelPosition13);
        org.junit.Assert.assertNotNull(color20);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        lineAndShapeRenderer2.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator7);
        lineAndShapeRenderer2.setSeriesVisible((int) (short) 100, (java.lang.Boolean) false, true);
        boolean boolean15 = lineAndShapeRenderer2.getItemShapeVisible((int) (short) 10, 3);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator16 = lineAndShapeRenderer2.getLegendItemLabelGenerator();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = lineAndShapeRenderer2.getSeriesPositiveItemLabelPosition((int) (short) -1);
        lineAndShapeRenderer2.clearSeriesPaints(false);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator16);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Shape shape9 = lineAndShapeRenderer2.getItemShape((int) (short) 10, 100, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator13 = lineAndShapeRenderer2.getItemLabelGenerator((int) 'a', 0, false);
        lineAndShapeRenderer2.setSeriesLinesVisible((int) (short) 100, (java.lang.Boolean) true);
        java.awt.Font font18 = lineAndShapeRenderer2.getLegendTextFont((int) (byte) 1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNull(categoryItemLabelGenerator13);
        org.junit.Assert.assertNull(font18);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Shape shape9 = lineAndShapeRenderer2.getItemShape((int) (short) 10, 100, true);
        java.awt.Paint paint11 = lineAndShapeRenderer2.getSeriesFillPaint((int) (short) 10);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator12 = null;
        lineAndShapeRenderer2.setBaseURLGenerator(categoryURLGenerator12);
        int int14 = lineAndShapeRenderer2.getPassCount();
        lineAndShapeRenderer2.setBaseSeriesVisibleInLegend(false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke20 = lineAndShapeRenderer19.getBaseStroke();
        java.awt.Stroke stroke22 = lineAndShapeRenderer19.lookupSeriesStroke(10);
        java.awt.Shape shape28 = null;
        java.awt.Color color29 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem30 = new org.jfree.chart.LegendItem("", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", shape28, (java.awt.Paint) color29);
        int int31 = color29.getBlue();
        lineAndShapeRenderer19.setSeriesItemLabelPaint((int) (byte) 1, (java.awt.Paint) color29);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer35 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke36 = lineAndShapeRenderer35.getBaseStroke();
        java.awt.Stroke stroke38 = lineAndShapeRenderer35.lookupSeriesStroke(10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator40 = null;
        lineAndShapeRenderer35.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator40);
        lineAndShapeRenderer35.setSeriesVisible((int) (short) 100, (java.lang.Boolean) false, true);
        boolean boolean48 = lineAndShapeRenderer35.getItemShapeVisible((int) (short) 10, 3);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator49 = lineAndShapeRenderer35.getLegendItemLabelGenerator();
        lineAndShapeRenderer19.setLegendItemLabelGenerator(categorySeriesLabelGenerator49);
        lineAndShapeRenderer2.setLegendItemLabelGenerator(categorySeriesLabelGenerator49);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator53 = null;
        lineAndShapeRenderer2.setSeriesItemLabelGenerator(156, categoryItemLabelGenerator53);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 128 + "'", int31 == 128);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator49);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Paint paint5 = lineAndShapeRenderer2.getSeriesPaint(15);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = lineAndShapeRenderer2.getSeriesNegativeItemLabelPosition(255);
        int int8 = lineAndShapeRenderer2.getDefaultEntityRadius();
        java.awt.Stroke stroke9 = lineAndShapeRenderer2.getBaseOutlineStroke();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator11 = lineAndShapeRenderer2.getSeriesToolTipGenerator(128);
        lineAndShapeRenderer2.setSeriesItemLabelsVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Paint paint16 = lineAndShapeRenderer2.lookupSeriesPaint((int) (short) 100);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNull(categoryToolTipGenerator11);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets(8.0d, (double) 10L, (double) 255, (double) 1L);
        double double6 = rectangleInsets4.calculateTopInset(0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 8.0d + "'", double6 == 8.0d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = categoryAxis1.getTickLabelInsets();
        categoryAxis1.setCategoryLabelPositionOffset(0);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions5 = categoryAxis1.getCategoryLabelPositions();
        categoryAxis1.configure();
        categoryAxis1.setMinorTickMarksVisible(true);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(categoryLabelPositions5);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("PlotOrientation.VERTICAL", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        java.awt.Paint paint2 = paintList0.getPaint(0);
        org.junit.Assert.assertNull(paint2);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis4 = categoryPlot1.getRangeAxis();
        int int5 = categoryPlot1.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder6 = categoryPlot1.getRowRenderingOrder();
        categoryPlot1.mapDatasetToRangeAxis((int) '#', (int) (byte) 10);
        boolean boolean10 = datasetRenderingOrder0.equals((java.lang.Object) categoryPlot1);
        java.lang.String str11 = datasetRenderingOrder0.toString();
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
        org.junit.Assert.assertNotNull(sortOrder6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "DatasetRenderingOrder.FORWARD" + "'", str11.equals("DatasetRenderingOrder.FORWARD"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        renderAttributes0.setDefaultFillPaint((java.awt.Paint) color1);
        java.awt.Shape shape5 = renderAttributes0.getItemShape((int) (byte) 100, (int) 'a');
        java.awt.Shape shape7 = null;
        renderAttributes0.setSeriesShape((int) (byte) 1, shape7);
        java.awt.Font font9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        renderAttributes0.setDefaultLabelFont(font9);
        java.awt.Stroke stroke13 = renderAttributes0.getItemStroke((-1), (int) (short) 1);
        java.awt.Stroke stroke14 = renderAttributes0.getDefaultOutlineStroke();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNull(shape5);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNull(stroke13);
        org.junit.Assert.assertNull(stroke14);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Shape shape9 = lineAndShapeRenderer2.getItemShape((int) (short) 10, 100, true);
        java.awt.Paint paint11 = lineAndShapeRenderer2.getSeriesFillPaint((int) (short) 10);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator12 = null;
        lineAndShapeRenderer2.setBaseURLGenerator(categoryURLGenerator12);
        int int14 = lineAndShapeRenderer2.getPassCount();
        lineAndShapeRenderer2.setBaseCreateEntities(false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer20 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke21 = lineAndShapeRenderer20.getBaseStroke();
        java.awt.Stroke stroke23 = lineAndShapeRenderer20.lookupSeriesStroke(10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator25 = null;
        lineAndShapeRenderer20.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator25);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition28 = lineAndShapeRenderer20.getSeriesPositiveItemLabelPosition(0);
        java.awt.Stroke stroke29 = lineAndShapeRenderer20.getBaseStroke();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer33 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke34 = lineAndShapeRenderer33.getBaseStroke();
        java.awt.Stroke stroke36 = lineAndShapeRenderer33.lookupSeriesStroke(10);
        java.awt.Shape shape40 = lineAndShapeRenderer33.getItemShape((int) (short) 10, 100, true);
        lineAndShapeRenderer33.setBaseSeriesVisible(false);
        java.awt.Shape shape43 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity46 = new org.jfree.chart.entity.ChartEntity(shape43, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape47 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity50 = new org.jfree.chart.entity.ChartEntity(shape47, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape51 = chartEntity50.getArea();
        chartEntity46.setArea(shape51);
        lineAndShapeRenderer33.setBaseShape(shape51, true);
        java.lang.Boolean boolean56 = lineAndShapeRenderer33.getSeriesShapesVisible(1);
        java.awt.Font font57 = lineAndShapeRenderer33.getBaseItemLabelFont();
        java.awt.Font font59 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        lineAndShapeRenderer33.setSeriesItemLabelFont((int) (short) 100, font59);
        lineAndShapeRenderer20.setLegendTextFont(0, font59);
        try {
            lineAndShapeRenderer2.setLegendTextFont((-128), font59);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(itemLabelPosition28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertNotNull(shape43);
        org.junit.Assert.assertNotNull(shape47);
        org.junit.Assert.assertNotNull(shape51);
        org.junit.Assert.assertNull(boolean56);
        org.junit.Assert.assertNotNull(font57);
        org.junit.Assert.assertNotNull(font59);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        renderAttributes0.setDefaultFillPaint((java.awt.Paint) color1);
        java.awt.Shape shape5 = renderAttributes0.getItemShape((int) (byte) 100, (int) 'a');
        java.awt.Shape shape7 = null;
        renderAttributes0.setSeriesShape((int) (byte) 1, shape7);
        java.awt.Paint paint9 = renderAttributes0.getDefaultFillPaint();
        java.awt.Paint paint11 = renderAttributes0.getSeriesFillPaint(3);
        java.awt.Paint paint13 = renderAttributes0.getSeriesOutlinePaint((-128));
        java.awt.Stroke stroke14 = renderAttributes0.getDefaultOutlineStroke();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNull(shape5);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertNull(stroke14);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = categoryAxis1.getTickLabelInsets();
        java.lang.String str3 = categoryAxis1.getLabel();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis1.getCategoryStart(128, (int) (byte) 100, rectangle2D6, rectangleEdge7);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "DatasetRenderingOrder.REVERSE" + "'", str3.equals("DatasetRenderingOrder.REVERSE"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        lineAndShapeRenderer2.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator7);
        lineAndShapeRenderer2.setSeriesVisible((int) (short) 100, (java.lang.Boolean) false, true);
        boolean boolean15 = lineAndShapeRenderer2.getItemShapeVisible((int) (short) 10, 3);
        java.awt.Font font16 = lineAndShapeRenderer2.getBaseLegendTextFont();
        java.awt.Paint paint18 = lineAndShapeRenderer2.lookupSeriesOutlinePaint((int) (byte) 0);
        lineAndShapeRenderer2.setBaseCreateEntities(true, true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(font16);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Shape shape11 = null;
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", shape11, (java.awt.Paint) color12);
        int int14 = color12.getBlue();
        lineAndShapeRenderer2.setSeriesItemLabelPaint((int) (byte) 1, (java.awt.Paint) color12);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot16.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis19 = categoryPlot16.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        categoryPlot16.zoomDomainAxes((double) 10.0f, plotRenderingInfo21, point2D22, false);
        java.lang.Comparable comparable25 = categoryPlot16.getDomainCrosshairColumnKey();
        java.awt.Paint paint26 = categoryPlot16.getRangeCrosshairPaint();
        lineAndShapeRenderer2.setBaseOutlinePaint(paint26);
        lineAndShapeRenderer2.setDataBoundsIncludesVisibleSeriesOnly(false);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 128 + "'", int14 == 128);
        org.junit.Assert.assertNull(valueAxis19);
        org.junit.Assert.assertNull(comparable25);
        org.junit.Assert.assertNotNull(paint26);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE10;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis4 = categoryPlot1.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot1.zoomDomainAxes((double) 10.0f, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor10 = categoryPlot1.getDomainGridlinePosition();
        boolean boolean11 = itemLabelAnchor0.equals((java.lang.Object) categoryAnchor10);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot12.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis15 = categoryPlot12.getRangeAxis();
        int int16 = categoryPlot12.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder17 = categoryPlot12.getRowRenderingOrder();
        categoryPlot12.setWeight((int) (short) 100);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder20 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        categoryPlot12.setDatasetRenderingOrder(datasetRenderingOrder20);
        boolean boolean22 = categoryAnchor10.equals((java.lang.Object) categoryPlot12);
        categoryPlot12.clearDomainMarkers((int) '4');
        java.awt.Shape shape30 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot31.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis34 = categoryPlot31.getRangeAxis();
        int int35 = categoryPlot31.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder36 = categoryPlot31.getRowRenderingOrder();
        java.awt.Stroke stroke37 = categoryPlot31.getRangeZeroBaselineStroke();
        java.awt.Paint paint38 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem39 = new org.jfree.chart.LegendItem("", "", "hi!", "", shape30, stroke37, paint38);
        legendItem39.setDescription("");
        int int42 = legendItem39.getDatasetIndex();
        java.lang.String str43 = legendItem39.getLabel();
        java.lang.String str44 = legendItem39.getLabel();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset45 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo46 = new org.jfree.chart.event.DatasetChangeInfo();
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent47 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object) legendItem39, (org.jfree.data.general.Dataset) defaultCategoryDataset45, datasetChangeInfo46);
        defaultCategoryDataset45.clearSelection();
        try {
            categoryPlot12.setDataset((-1), (org.jfree.data.category.CategoryDataset) defaultCategoryDataset45);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertNotNull(categoryAnchor10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(valueAxis15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 15 + "'", int16 == 15);
        org.junit.Assert.assertNotNull(sortOrder17);
        org.junit.Assert.assertNotNull(datasetRenderingOrder20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(valueAxis34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 15 + "'", int35 == 15);
        org.junit.Assert.assertNotNull(sortOrder36);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "" + "'", str43.equals(""));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "" + "'", str44.equals(""));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        boolean boolean9 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.axis.AxisLocation axisLocation11 = null;
        categoryPlot0.setDomainAxisLocation(255, axisLocation11);
        org.jfree.chart.util.SortOrder sortOrder13 = categoryPlot0.getRowRenderingOrder();
        categoryPlot0.setBackgroundImageAlignment(0);
        java.awt.Color color19 = java.awt.Color.getHSBColor((float) (short) 1, (float) 100, 0.0f);
        float[] floatArray26 = new float[] { (byte) 10, (byte) 1, 1.0f, (byte) 0, 10, (byte) 100 };
        float[] floatArray27 = color19.getRGBComponents(floatArray26);
        java.lang.String str28 = color19.toString();
        boolean boolean29 = categoryPlot0.equals((java.lang.Object) color19);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(sortOrder13);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(floatArray26);
        org.junit.Assert.assertNotNull(floatArray27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "java.awt.Color[r=0,g=0,b=0]" + "'", str28.equals("java.awt.Color[r=0,g=0,b=0]"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        org.jfree.chart.LegendItemCollection legendItemCollection9 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation11 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation10, plotOrientation11);
        categoryPlot0.setRangeAxisLocation(axisLocation10);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        try {
            int int15 = categoryPlot0.getRangeAxisIndex(valueAxis14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNull(legendItemCollection9);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(plotOrientation11);
        org.junit.Assert.assertNotNull(rectangleEdge12);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot0.setRangeAxisLocation(axisLocation1, true);
        java.lang.Comparable comparable4 = categoryPlot0.getDomainCrosshairColumnKey();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke8 = lineAndShapeRenderer7.getBaseStroke();
        org.jfree.chart.LegendItemCollection legendItemCollection9 = lineAndShapeRenderer7.getLegendItems();
        categoryPlot0.setFixedLegendItems(legendItemCollection9);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation12 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot11.setRangeAxisLocation(axisLocation12, true);
        java.lang.Comparable comparable15 = categoryPlot11.getDomainCrosshairColumnKey();
        boolean boolean16 = legendItemCollection9.equals((java.lang.Object) categoryPlot11);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer17 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer17.clearSeriesStrokes(true);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator21 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("java.awt.Color[r=0,g=0,b=0]");
        lineAndShapeRenderer17.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator21);
        java.awt.Paint paint26 = lineAndShapeRenderer17.getItemFillPaint((int) (byte) 0, 156, true);
        boolean boolean27 = legendItemCollection9.equals((java.lang.Object) (byte) 0);
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNull(comparable4);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(legendItemCollection9);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNull(comparable15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        java.lang.Comparable comparable9 = categoryPlot0.getDomainCrosshairColumnKey();
        boolean boolean10 = categoryPlot0.isRangeCrosshairLockedOnData();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        categoryPlot0.setDomainCrosshairPaint((java.awt.Paint) color11);
        java.awt.Shape shape17 = null;
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem19 = new org.jfree.chart.LegendItem("", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", shape17, (java.awt.Paint) color18);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color18);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        categoryPlot0.panRangeAxes((double) 255, plotRenderingInfo22, point2D23);
        categoryPlot0.setRangeCrosshairValue((double) 3, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot28.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis31 = categoryPlot28.getRangeAxis();
        int int32 = categoryPlot28.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder33 = categoryPlot28.getRowRenderingOrder();
        java.awt.Stroke stroke34 = categoryPlot28.getRangeZeroBaselineStroke();
        categoryPlot0.setDomainCrosshairStroke(stroke34);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNull(comparable9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNull(valueAxis31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 15 + "'", int32 == 15);
        org.junit.Assert.assertNotNull(sortOrder33);
        org.junit.Assert.assertNotNull(stroke34);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        java.lang.Comparable comparable9 = categoryPlot0.getDomainCrosshairColumnKey();
        boolean boolean10 = categoryPlot0.isRangeCrosshairLockedOnData();
        categoryPlot0.setCrosshairDatasetIndex((int) (byte) 10, false);
        org.jfree.chart.axis.AxisSpace axisSpace14 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace14);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNull(comparable9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        try {
            defaultCategoryDataset0.removeColumn((java.lang.Comparable) "ItemLabelAnchor.OUTSIDE3");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Column key (ItemLabelAnchor.OUTSIDE3) not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder5 = categoryPlot0.getRowRenderingOrder();
        java.awt.Stroke stroke6 = categoryPlot0.getRangeZeroBaselineStroke();
        categoryPlot0.setAnchorValue((double) (-1), true);
        java.lang.Comparable comparable10 = categoryPlot0.getDomainCrosshairColumnKey();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(sortOrder5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(comparable10);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier4 = categoryPlot0.getDrawingSupplier();
        org.jfree.data.category.CategoryDataset categoryDataset5 = categoryPlot0.getDataset();
        org.jfree.chart.renderer.RenderAttributes renderAttributes6 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        renderAttributes6.setDefaultFillPaint((java.awt.Paint) color7);
        categoryPlot0.setBackgroundPaint((java.awt.Paint) color7);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation10 = null;
        try {
            boolean boolean12 = categoryPlot0.removeAnnotation(categoryAnnotation10, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(drawingSupplier4);
        org.junit.Assert.assertNull(categoryDataset5);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Shape shape11 = null;
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", shape11, (java.awt.Paint) color12);
        int int14 = color12.getBlue();
        lineAndShapeRenderer2.setSeriesItemLabelPaint((int) (byte) 1, (java.awt.Paint) color12);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean17 = categoryPlot16.isRangeGridlinesVisible();
        categoryPlot16.clearDomainAxes();
        lineAndShapeRenderer2.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot16);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator20 = lineAndShapeRenderer2.getLegendItemToolTipGenerator();
        lineAndShapeRenderer2.setBaseItemLabelsVisible(true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer26 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke27 = lineAndShapeRenderer26.getBaseStroke();
        java.awt.Stroke stroke29 = lineAndShapeRenderer26.lookupSeriesStroke(10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator31 = null;
        lineAndShapeRenderer26.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator31);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition34 = lineAndShapeRenderer26.getSeriesPositiveItemLabelPosition(0);
        java.awt.Shape shape36 = lineAndShapeRenderer26.lookupLegendShape(15);
        lineAndShapeRenderer2.setSeriesShape(4, shape36);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 128 + "'", int14 == 128);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator20);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(itemLabelPosition34);
        org.junit.Assert.assertNotNull(shape36);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        categoryPlot0.setDomainCrosshairColumnKey((java.lang.Comparable) (short) -1, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot0.zoomRangeAxes((double) (byte) 1, plotRenderingInfo9, point2D10, true);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        categoryPlot0.drawBackgroundImage(graphics2D13, rectangle2D14);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer18 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke19 = lineAndShapeRenderer18.getBaseStroke();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator21 = null;
        lineAndShapeRenderer18.setSeriesItemLabelGenerator((int) (byte) 1, categoryItemLabelGenerator21);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer26 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke27 = lineAndShapeRenderer26.getBaseStroke();
        java.awt.Paint paint29 = lineAndShapeRenderer26.getSeriesPaint(15);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer33 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke34 = lineAndShapeRenderer33.getBaseStroke();
        java.awt.Stroke stroke36 = lineAndShapeRenderer33.lookupSeriesStroke(10);
        java.awt.Paint paint37 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        lineAndShapeRenderer33.setBaseOutlinePaint(paint37);
        java.awt.Font font39 = lineAndShapeRenderer33.getBaseItemLabelFont();
        lineAndShapeRenderer26.setSeriesItemLabelFont((int) (byte) 1, font39);
        lineAndShapeRenderer18.setSeriesItemLabelFont((int) (short) 10, font39, true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer46 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke47 = lineAndShapeRenderer46.getBaseStroke();
        java.awt.Stroke stroke49 = lineAndShapeRenderer46.lookupSeriesStroke(10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator51 = null;
        lineAndShapeRenderer46.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator51);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition54 = lineAndShapeRenderer46.getSeriesPositiveItemLabelPosition(0);
        lineAndShapeRenderer46.setBaseShapesFilled(false);
        lineAndShapeRenderer46.setSeriesVisibleInLegend((int) (short) 10, (java.lang.Boolean) false);
        java.awt.Stroke stroke61 = lineAndShapeRenderer46.lookupSeriesOutlineStroke((-1));
        lineAndShapeRenderer18.setSeriesStroke((int) (short) 10, stroke61, false);
        categoryPlot0.setDomainGridlineStroke(stroke61);
        org.jfree.chart.axis.CategoryAxis categoryAxis66 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets67 = categoryAxis66.getTickLabelInsets();
        categoryAxis66.setCategoryLabelPositionOffset(0);
        categoryAxis66.setMinorTickMarksVisible(false);
        float float72 = categoryAxis66.getMinorTickMarkOutsideLength();
        org.jfree.chart.util.RectangleInsets rectangleInsets73 = categoryAxis66.getLabelInsets();
        org.jfree.chart.util.UnitType unitType74 = rectangleInsets73.getUnitType();
        categoryPlot0.setInsets(rectangleInsets73);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNull(paint29);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(font39);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(itemLabelPosition54);
        org.junit.Assert.assertNotNull(stroke61);
        org.junit.Assert.assertNotNull(rectangleInsets67);
        org.junit.Assert.assertTrue("'" + float72 + "' != '" + 2.0f + "'", float72 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets73);
        org.junit.Assert.assertNotNull(unitType74);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = categoryAxis1.getTickLabelInsets();
        categoryAxis1.setCategoryLabelPositionOffset(0);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        int int9 = categoryPlot5.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot5.getRowRenderingOrder();
        java.awt.Stroke stroke11 = categoryPlot5.getRangeZeroBaselineStroke();
        int int12 = categoryPlot5.getCrosshairDatasetIndex();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke16 = lineAndShapeRenderer15.getBaseStroke();
        java.awt.Stroke stroke18 = lineAndShapeRenderer15.lookupSeriesStroke(10);
        lineAndShapeRenderer15.setAutoPopulateSeriesStroke(true);
        categoryPlot5.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer15, true);
        categoryAxis1.setPlot((org.jfree.chart.plot.Plot) categoryPlot5);
        categoryAxis1.setCategoryMargin((double) 100L);
        java.awt.Font font26 = categoryAxis1.getTickLabelFont();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(font26);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape0, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape4 = chartEntity3.getArea();
        java.awt.Shape shape5 = chartEntity3.getArea();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot6.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = categoryPlot6.getDomainAxisEdge();
        int int10 = categoryPlot6.getWeight();
        java.lang.Comparable comparable11 = categoryPlot6.getDomainCrosshairColumnKey();
        boolean boolean12 = categoryPlot6.canSelectByRegion();
        org.jfree.chart.axis.AxisLocation axisLocation13 = categoryPlot6.getRangeAxisLocation();
        org.jfree.chart.entity.PlotEntity plotEntity16 = new org.jfree.chart.entity.PlotEntity(shape5, (org.jfree.chart.plot.Plot) categoryPlot6, "ItemLabelAnchor.OUTSIDE1", "java.awt.Color[r=0,g=0,b=0]");
        plotEntity16.setURLText("ItemLabelAnchor.OUTSIDE1");
        java.lang.String str19 = plotEntity16.getShapeCoords();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNull(comparable11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "-4,-4,4,4" + "'", str19.equals("-4,-4,4,4"));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        java.awt.Shape shape4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        int int9 = categoryPlot5.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot5.getRowRenderingOrder();
        java.awt.Stroke stroke11 = categoryPlot5.getRangeZeroBaselineStroke();
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("", "", "hi!", "", shape4, stroke11, paint12);
        legendItem13.setDescription("");
        int int16 = legendItem13.getDatasetIndex();
        java.lang.String str17 = legendItem13.getLabel();
        java.awt.Paint paint18 = legendItem13.getOutlinePaint();
        legendItem13.setDatasetIndex((int) ' ');
        java.text.AttributedString attributedString21 = legendItem13.getAttributedLabel();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer24 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke25 = lineAndShapeRenderer24.getBaseStroke();
        java.awt.Stroke stroke27 = lineAndShapeRenderer24.lookupSeriesStroke(10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator29 = null;
        lineAndShapeRenderer24.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator29);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition32 = lineAndShapeRenderer24.getSeriesPositiveItemLabelPosition(0);
        java.awt.Shape shape34 = lineAndShapeRenderer24.lookupLegendShape(15);
        legendItem13.setLine(shape34);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNull(attributedString21);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(itemLabelPosition32);
        org.junit.Assert.assertNotNull(shape34);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        org.jfree.chart.LegendItemCollection legendItemCollection4 = lineAndShapeRenderer2.getLegendItems();
        lineAndShapeRenderer2.setDataBoundsIncludesVisibleSeriesOnly(false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke10 = lineAndShapeRenderer9.getBaseStroke();
        java.awt.Stroke stroke12 = lineAndShapeRenderer9.lookupSeriesStroke(10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator14 = null;
        lineAndShapeRenderer9.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator14);
        lineAndShapeRenderer9.setSeriesVisible((int) (short) 100, (java.lang.Boolean) false, true);
        boolean boolean22 = lineAndShapeRenderer9.getItemShapeVisible((int) (short) 10, 3);
        lineAndShapeRenderer9.removeAnnotations();
        lineAndShapeRenderer9.setAutoPopulateSeriesShape(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot26.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis29 = categoryPlot26.getRangeAxis();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier30 = categoryPlot26.getDrawingSupplier();
        java.awt.Stroke stroke31 = categoryPlot26.getOutlineStroke();
        lineAndShapeRenderer9.setBaseOutlineStroke(stroke31, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition37 = lineAndShapeRenderer9.getNegativeItemLabelPosition((int) (short) 100, (int) (short) 1, false);
        lineAndShapeRenderer2.setBaseNegativeItemLabelPosition(itemLabelPosition37, true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(legendItemCollection4);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNull(valueAxis29);
        org.junit.Assert.assertNotNull(drawingSupplier30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(itemLabelPosition37);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        java.awt.Color color3 = java.awt.Color.getHSBColor(1.0f, 2.0f, 10.0f);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        boolean boolean6 = lineAndShapeRenderer2.getUseSeriesOffset();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot7.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis10 = categoryPlot7.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot7.zoomDomainAxes((double) 10.0f, plotRenderingInfo12, point2D13, false);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent16 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot7);
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot17.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis20 = categoryPlot17.getRangeAxis();
        int int21 = categoryPlot17.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot17.getRowRenderingOrder();
        java.awt.Stroke stroke23 = categoryPlot17.getRangeZeroBaselineStroke();
        categoryPlot7.setOutlineStroke(stroke23);
        org.jfree.chart.plot.Marker marker26 = null;
        org.jfree.chart.util.Layer layer27 = null;
        boolean boolean28 = categoryPlot7.removeDomainMarker(15, marker26, layer27);
        categoryPlot7.setOutlineVisible(true);
        java.lang.Comparable comparable31 = categoryPlot7.getDomainCrosshairColumnKey();
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot7);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertNull(valueAxis20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 15 + "'", int21 == 15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(comparable31);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Paint paint5 = lineAndShapeRenderer2.getSeriesPaint(15);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = lineAndShapeRenderer2.getSeriesNegativeItemLabelPosition(255);
        int int8 = lineAndShapeRenderer2.getDefaultEntityRadius();
        java.awt.Stroke stroke9 = lineAndShapeRenderer2.getBaseOutlineStroke();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator11 = lineAndShapeRenderer2.getSeriesToolTipGenerator(128);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator12 = null;
        lineAndShapeRenderer2.setBaseItemLabelGenerator(categoryItemLabelGenerator12);
        int int14 = lineAndShapeRenderer2.getRowCount();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNull(categoryToolTipGenerator11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke1 = defaultDrawingSupplier0.getNextOutlineStroke();
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        renderAttributes0.setDefaultFillPaint((java.awt.Paint) color1);
        java.awt.Shape shape5 = renderAttributes0.getItemShape((int) (byte) 100, (int) 'a');
        java.awt.Shape shape7 = null;
        renderAttributes0.setSeriesShape((int) (byte) 1, shape7);
        renderAttributes0.setDefaultCreateEntity((java.lang.Boolean) true);
        java.awt.Paint paint11 = renderAttributes0.getDefaultPaint();
        java.awt.Paint paint12 = renderAttributes0.getDefaultOutlinePaint();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNull(shape5);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNull(paint12);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis4 = categoryPlot1.getRangeAxis();
        int int5 = categoryPlot1.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder6 = categoryPlot1.getRowRenderingOrder();
        java.awt.Stroke stroke7 = categoryPlot1.getRangeZeroBaselineStroke();
        categoryPlot1.setRangeGridlinesVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis13 = categoryPlot10.getRangeAxis();
        int int14 = categoryPlot10.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder15 = categoryPlot10.getRowRenderingOrder();
        java.awt.Stroke stroke16 = categoryPlot10.getRangeZeroBaselineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent17 = null;
        categoryPlot10.rendererChanged(rendererChangeEvent17);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation20 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot19.setRangeAxisLocation(axisLocation20, true);
        categoryPlot10.setDomainAxisLocation(axisLocation20);
        categoryPlot1.setDomainAxisLocation(axisLocation20, true);
        categoryPlot1.setBackgroundAlpha((float) 10);
        boolean boolean28 = defaultDrawingSupplier0.equals((java.lang.Object) 10);
        java.awt.Paint paint29 = defaultDrawingSupplier0.getNextOutlinePaint();
        java.awt.Paint paint30 = defaultDrawingSupplier0.getNextPaint();
        java.awt.Paint paint31 = defaultDrawingSupplier0.getNextOutlinePaint();
        java.awt.Stroke stroke32 = defaultDrawingSupplier0.getNextStroke();
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
        org.junit.Assert.assertNotNull(sortOrder6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(valueAxis13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 15 + "'", int14 == 15);
        org.junit.Assert.assertNotNull(sortOrder15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(stroke32);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        java.lang.Comparable comparable9 = categoryPlot0.getDomainCrosshairColumnKey();
        boolean boolean10 = categoryPlot0.isRangeCrosshairLockedOnData();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        categoryPlot0.setDomainCrosshairPaint((java.awt.Paint) color11);
        java.awt.Shape shape17 = null;
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem19 = new org.jfree.chart.LegendItem("", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", shape17, (java.awt.Paint) color18);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color18);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        categoryPlot0.panRangeAxes((double) 255, plotRenderingInfo22, point2D23);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = categoryPlot0.getInsets();
        double double26 = rectangleInsets25.getBottom();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNull(comparable9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 4.0d + "'", double26 == 4.0d);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        java.awt.Shape shape4 = null;
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem6 = new org.jfree.chart.LegendItem("", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", shape4, (java.awt.Paint) color5);
        java.awt.Shape shape7 = legendItem6.getShape();
        int int8 = legendItem6.getSeriesIndex();
        org.jfree.data.general.Dataset dataset9 = legendItem6.getDataset();
        java.text.AttributedString attributedString10 = legendItem6.getAttributedLabel();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(shape7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNull(dataset9);
        org.junit.Assert.assertNull(attributedString10);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = categoryAxis1.getTickLabelInsets();
        categoryAxis1.setCategoryLabelPositionOffset(0);
        categoryAxis1.setMinorTickMarksVisible(false);
        float float7 = categoryAxis1.getMinorTickMarkOutsideLength();
        boolean boolean8 = categoryAxis1.isVisible();
        categoryAxis1.setTickMarkOutsideLength((float) 10L);
        float float11 = categoryAxis1.getTickMarkOutsideLength();
        int int12 = categoryAxis1.getCategoryLabelPositionOffset();
        int int13 = categoryAxis1.getCategoryLabelPositionOffset();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer16 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke17 = lineAndShapeRenderer16.getBaseStroke();
        java.awt.Stroke stroke19 = lineAndShapeRenderer16.lookupSeriesStroke(10);
        java.awt.Shape shape23 = lineAndShapeRenderer16.getItemShape((int) (short) 10, 100, true);
        lineAndShapeRenderer16.setBaseSeriesVisible(false);
        boolean boolean26 = lineAndShapeRenderer16.getUseFillPaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition30 = lineAndShapeRenderer16.getPositiveItemLabelPosition((-128), 0, false);
        boolean boolean31 = categoryAxis1.equals((java.lang.Object) 0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 2.0f + "'", float7 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 10.0f + "'", float11 == 10.0f);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = null;
        lineAndShapeRenderer2.setSeriesItemLabelGenerator((int) (byte) 1, categoryItemLabelGenerator5);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke11 = lineAndShapeRenderer10.getBaseStroke();
        java.awt.Paint paint13 = lineAndShapeRenderer10.getSeriesPaint(15);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer17 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke18 = lineAndShapeRenderer17.getBaseStroke();
        java.awt.Stroke stroke20 = lineAndShapeRenderer17.lookupSeriesStroke(10);
        java.awt.Paint paint21 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        lineAndShapeRenderer17.setBaseOutlinePaint(paint21);
        java.awt.Font font23 = lineAndShapeRenderer17.getBaseItemLabelFont();
        lineAndShapeRenderer10.setSeriesItemLabelFont((int) (byte) 1, font23);
        lineAndShapeRenderer2.setSeriesItemLabelFont((int) (short) 10, font23, true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer30 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke31 = lineAndShapeRenderer30.getBaseStroke();
        java.awt.Stroke stroke33 = lineAndShapeRenderer30.lookupSeriesStroke(10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator35 = null;
        lineAndShapeRenderer30.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator35);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition38 = lineAndShapeRenderer30.getSeriesPositiveItemLabelPosition(0);
        lineAndShapeRenderer30.setBaseShapesFilled(false);
        lineAndShapeRenderer30.setSeriesVisibleInLegend((int) (short) 10, (java.lang.Boolean) false);
        java.awt.Stroke stroke45 = lineAndShapeRenderer30.lookupSeriesOutlineStroke((-1));
        lineAndShapeRenderer2.setSeriesStroke((int) (short) 10, stroke45, false);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor48 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE5;
        java.awt.Color color49 = java.awt.Color.white;
        boolean boolean50 = itemLabelAnchor48.equals((java.lang.Object) color49);
        org.jfree.chart.text.TextAnchor textAnchor51 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition52 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor48, textAnchor51);
        org.jfree.chart.text.TextAnchor textAnchor53 = itemLabelPosition52.getRotationAnchor();
        lineAndShapeRenderer2.setBasePositiveItemLabelPosition(itemLabelPosition52);
        org.jfree.chart.plot.CategoryPlot categoryPlot55 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean56 = categoryPlot55.isRangeGridlinesVisible();
        categoryPlot55.clearDomainAxes();
        java.awt.Color color58 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        categoryPlot55.setOutlinePaint((java.awt.Paint) color58);
        lineAndShapeRenderer2.setPlot(categoryPlot55);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator62 = null;
        lineAndShapeRenderer2.setSeriesURLGenerator((int) (short) 0, categoryURLGenerator62, false);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(itemLabelPosition38);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(itemLabelAnchor48);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(textAnchor51);
        org.junit.Assert.assertNotNull(textAnchor53);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertNotNull(color58);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        renderAttributes0.setDefaultFillPaint((java.awt.Paint) color1);
        java.awt.Paint paint3 = renderAttributes0.getDefaultOutlinePaint();
        java.awt.Stroke stroke4 = renderAttributes0.getDefaultStroke();
        java.awt.Shape shape6 = null;
        renderAttributes0.setSeriesShape(0, shape6);
        java.awt.Paint paint10 = renderAttributes0.getItemFillPaint(100, (int) '#');
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNull(stroke4);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        int int2 = keyedObjects0.getIndex((java.lang.Comparable) (short) 100);
        java.util.List list3 = keyedObjects0.getKeys();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor5 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE10;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot6.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis9 = categoryPlot6.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot6.zoomDomainAxes((double) 10.0f, plotRenderingInfo11, point2D12, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor15 = categoryPlot6.getDomainGridlinePosition();
        boolean boolean16 = itemLabelAnchor5.equals((java.lang.Object) categoryAnchor15);
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot17.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis20 = categoryPlot17.getRangeAxis();
        int int21 = categoryPlot17.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot17.getRowRenderingOrder();
        categoryPlot17.setWeight((int) (short) 100);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder25 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        categoryPlot17.setDatasetRenderingOrder(datasetRenderingOrder25);
        boolean boolean27 = categoryAnchor15.equals((java.lang.Object) categoryPlot17);
        boolean boolean28 = categoryPlot17.isDomainZoomable();
        java.awt.Paint paint29 = categoryPlot17.getNoDataMessagePaint();
        keyedObjects0.setObject((java.lang.Comparable) 0.0f, (java.lang.Object) categoryPlot17);
        try {
            java.lang.Object obj32 = keyedObjects0.getObject((java.lang.Comparable) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: The key (-1) is not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNotNull(itemLabelAnchor5);
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertNotNull(categoryAnchor15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(valueAxis20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 15 + "'", int21 == 15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(datasetRenderingOrder25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(paint29);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape0, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape4 = chartEntity3.getArea();
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape4);
        java.lang.Object obj6 = chartEntity5.clone();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        java.awt.Shape shape4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        int int9 = categoryPlot5.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot5.getRowRenderingOrder();
        java.awt.Stroke stroke11 = categoryPlot5.getRangeZeroBaselineStroke();
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("", "", "hi!", "", shape4, stroke11, paint12);
        legendItem13.setDescription("");
        int int16 = legendItem13.getDatasetIndex();
        java.lang.String str17 = legendItem13.getLabel();
        java.lang.String str18 = legendItem13.getLabel();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset19 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo20 = new org.jfree.chart.event.DatasetChangeInfo();
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent21 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object) legendItem13, (org.jfree.data.general.Dataset) defaultCategoryDataset19, datasetChangeInfo20);
        java.util.List list22 = defaultCategoryDataset19.getRowKeys();
        java.lang.Comparable comparable25 = null;
        try {
            defaultCategoryDataset19.incrementValue((double) (byte) -1, (java.lang.Comparable) '4', comparable25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'columnKey' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertNotNull(list22);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge();
        org.jfree.chart.axis.AxisLocation axisLocation4 = categoryPlot0.getDomainAxisLocation();
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = categoryPlot0.getDomainAxisEdge();
        org.jfree.chart.util.SortOrder sortOrder6 = categoryPlot0.getRowRenderingOrder();
        java.lang.String str7 = sortOrder6.toString();
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertNotNull(sortOrder6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "SortOrder.ASCENDING" + "'", str7.equals("SortOrder.ASCENDING"));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        lineAndShapeRenderer2.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator6 = null;
        lineAndShapeRenderer2.setSeriesURLGenerator(255, categoryURLGenerator6, false);
        java.awt.Shape shape12 = lineAndShapeRenderer2.getItemShape(4, (int) (byte) 1, false);
        org.junit.Assert.assertNotNull(shape12);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Shape shape9 = lineAndShapeRenderer2.getItemShape((int) (short) 10, 100, true);
        lineAndShapeRenderer2.setBaseSeriesVisible(false);
        java.awt.Shape shape12 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity15 = new org.jfree.chart.entity.ChartEntity(shape12, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape16 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity19 = new org.jfree.chart.entity.ChartEntity(shape16, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape20 = chartEntity19.getArea();
        chartEntity15.setArea(shape20);
        lineAndShapeRenderer2.setBaseShape(shape20, true);
        java.lang.Boolean boolean25 = lineAndShapeRenderer2.getSeriesShapesVisible(1);
        java.awt.Font font26 = lineAndShapeRenderer2.getBaseItemLabelFont();
        lineAndShapeRenderer2.setSeriesShapesVisible(1, true);
        lineAndShapeRenderer2.setBaseSeriesVisible(false);
        boolean boolean32 = lineAndShapeRenderer2.getAutoPopulateSeriesPaint();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNull(boolean25);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Shape shape9 = lineAndShapeRenderer2.getItemShape((int) (short) 10, 100, true);
        lineAndShapeRenderer2.setBaseSeriesVisible(false);
        lineAndShapeRenderer2.setSeriesShapesVisible((int) (short) 10, false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer15.clearSeriesStrokes(true);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator19 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("java.awt.Color[r=0,g=0,b=0]");
        lineAndShapeRenderer15.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator19);
        lineAndShapeRenderer2.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator19);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(shape9);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis4 = categoryPlot1.getRangeAxis();
        int int5 = categoryPlot1.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder6 = categoryPlot1.getRowRenderingOrder();
        java.awt.Stroke stroke7 = categoryPlot1.getRangeZeroBaselineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent8 = null;
        categoryPlot1.rendererChanged(rendererChangeEvent8);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation11 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot10.setRangeAxisLocation(axisLocation11, true);
        categoryPlot1.setDomainAxisLocation(axisLocation11);
        categoryPlot1.setCrosshairDatasetIndex((int) (short) 1);
        org.jfree.data.category.CategoryDataset categoryDataset17 = categoryPlot1.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = categoryPlot1.getAxisOffset();
        org.jfree.chart.util.SortOrder sortOrder19 = categoryPlot1.getRowRenderingOrder();
        keyedObjects0.sortByObjects(sortOrder19);
        int int22 = keyedObjects0.getIndex((java.lang.Comparable) 2.0f);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
        org.junit.Assert.assertNotNull(sortOrder6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNull(categoryDataset17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(sortOrder19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = lineAndShapeRenderer2.getBasePositiveItemLabelPosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot4.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = categoryPlot4.getDomainAxisEdge();
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot4.getDomainAxisLocation();
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        categoryPlot4.drawBackgroundImage(graphics2D9, rectangle2D10);
        java.awt.Paint paint12 = categoryPlot4.getNoDataMessagePaint();
        lineAndShapeRenderer2.setBaseItemLabelPaint(paint12);
        java.awt.Stroke stroke15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        lineAndShapeRenderer2.setSeriesStroke((int) (byte) 0, stroke15, false);
        java.awt.Font font19 = lineAndShapeRenderer2.lookupLegendTextFont(3);
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNull(font19);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        java.awt.Shape shape4 = null;
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem6 = new org.jfree.chart.LegendItem("", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", shape4, (java.awt.Paint) color5);
        java.awt.Stroke stroke7 = legendItem6.getLineStroke();
        legendItem6.setDescription("ChartChangeEventType.GENERAL");
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape0, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape4 = chartEntity3.getArea();
        java.awt.Shape shape5 = chartEntity3.getArea();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot6.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = categoryPlot6.getDomainAxisEdge();
        int int10 = categoryPlot6.getWeight();
        java.lang.Comparable comparable11 = categoryPlot6.getDomainCrosshairColumnKey();
        boolean boolean12 = categoryPlot6.canSelectByRegion();
        org.jfree.chart.axis.AxisLocation axisLocation13 = categoryPlot6.getRangeAxisLocation();
        org.jfree.chart.entity.PlotEntity plotEntity16 = new org.jfree.chart.entity.PlotEntity(shape5, (org.jfree.chart.plot.Plot) categoryPlot6, "ItemLabelAnchor.OUTSIDE1", "java.awt.Color[r=0,g=0,b=0]");
        plotEntity16.setURLText("ItemLabelAnchor.OUTSIDE1");
        org.jfree.chart.plot.Plot plot19 = plotEntity16.getPlot();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer22 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke23 = lineAndShapeRenderer22.getBaseStroke();
        java.awt.Stroke stroke25 = lineAndShapeRenderer22.lookupSeriesStroke(10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator27 = null;
        lineAndShapeRenderer22.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator27);
        lineAndShapeRenderer22.setSeriesVisible((int) (short) 100, (java.lang.Boolean) false, true);
        java.awt.Paint paint33 = lineAndShapeRenderer22.getBaseOutlinePaint();
        plot19.setNoDataMessagePaint(paint33);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNull(comparable11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(plot19);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint33);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = categoryAxis1.getTickLabelInsets();
        categoryAxis1.setCategoryLabelPositionOffset(0);
        categoryAxis1.setMinorTickMarksVisible(false);
        float float7 = categoryAxis1.getMinorTickMarkOutsideLength();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = categoryAxis1.getLabelInsets();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis1.setTickMarkPaint((java.awt.Paint) color9);
        float float11 = categoryAxis1.getMinorTickMarkInsideLength();
        double double12 = categoryAxis1.getFixedDimension();
        categoryAxis1.setCategoryMargin(0.2d);
        java.lang.Comparable comparable15 = null;
        try {
            categoryAxis1.addCategoryLabelToolTip(comparable15, "{0}");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 2.0f + "'", float7 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.0f + "'", float11 == 0.0f);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        java.lang.Comparable comparable9 = categoryPlot0.getDomainCrosshairColumnKey();
        boolean boolean10 = categoryPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = categoryPlot0.getAxisOffset();
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = null;
        org.jfree.chart.util.Layer layer15 = null;
        try {
            categoryPlot0.addDomainMarker((int) (byte) 100, categoryMarker14, layer15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNull(comparable9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(rectangleInsets11);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        java.awt.Shape shape4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        int int9 = categoryPlot5.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot5.getRowRenderingOrder();
        java.awt.Stroke stroke11 = categoryPlot5.getRangeZeroBaselineStroke();
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("", "", "hi!", "", shape4, stroke11, paint12);
        legendItem13.setDescription("");
        int int16 = legendItem13.getDatasetIndex();
        java.lang.String str17 = legendItem13.getLabel();
        java.awt.Paint paint18 = legendItem13.getOutlinePaint();
        legendItem13.setDescription("ChartChangeEventType.GENERAL");
        legendItem13.setDescription("ItemLabelAnchor.OUTSIDE1");
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot4.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis7 = categoryPlot4.getRangeAxis();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot4.getDrawingSupplier();
        org.jfree.data.category.CategoryDataset categoryDataset9 = categoryPlot4.getDataset();
        boolean boolean10 = lineAndShapeRenderer2.hasListener((java.util.EventListener) categoryPlot4);
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot4.getRangeAxisLocation((int) '4');
        boolean boolean14 = axisLocation12.equals((java.lang.Object) (byte) 0);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNull(categoryDataset9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape0, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape4 = chartEntity3.getArea();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot5.zoomDomainAxes((double) 10.0f, plotRenderingInfo10, point2D11, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor14 = categoryPlot5.getDomainGridlinePosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot15.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis18 = categoryPlot15.getRangeAxis();
        int int19 = categoryPlot15.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder20 = categoryPlot15.getRowRenderingOrder();
        java.awt.Stroke stroke21 = categoryPlot15.getRangeZeroBaselineStroke();
        categoryPlot5.setRangeMinorGridlineStroke(stroke21);
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = categoryPlot5.getDomainAxis(100);
        boolean boolean25 = categoryPlot5.isNotify();
        org.jfree.chart.entity.PlotEntity plotEntity27 = new org.jfree.chart.entity.PlotEntity(shape4, (org.jfree.chart.plot.Plot) categoryPlot5, "ItemLabelAnchor.OUTSIDE1");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset30 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity33 = new org.jfree.chart.entity.CategoryItemEntity(shape4, "PlotOrientation.VERTICAL", "PlotOrientation.VERTICAL", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset30, (java.lang.Comparable) 10, (java.lang.Comparable) 'a');
        org.jfree.chart.entity.ChartEntity chartEntity34 = new org.jfree.chart.entity.ChartEntity(shape4);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertNotNull(categoryAnchor14);
        org.junit.Assert.assertNull(valueAxis18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 15 + "'", int19 == 15);
        org.junit.Assert.assertNotNull(sortOrder20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNull(categoryAxis24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Shape shape9 = lineAndShapeRenderer2.getItemShape((int) (short) 10, 100, true);
        lineAndShapeRenderer2.setBaseSeriesVisible(false);
        java.awt.Shape shape12 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity15 = new org.jfree.chart.entity.ChartEntity(shape12, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape16 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity19 = new org.jfree.chart.entity.ChartEntity(shape16, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape20 = chartEntity19.getArea();
        chartEntity15.setArea(shape20);
        lineAndShapeRenderer2.setBaseShape(shape20, true);
        java.awt.Paint paint25 = lineAndShapeRenderer2.getLegendTextPaint(156);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNull(paint25);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot3.getRangeAxis();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier7 = categoryPlot3.getDrawingSupplier();
        org.jfree.data.category.CategoryDataset categoryDataset8 = categoryPlot3.getDataset();
        org.jfree.chart.renderer.RenderAttributes renderAttributes9 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        renderAttributes9.setDefaultFillPaint((java.awt.Paint) color10);
        categoryPlot3.setBackgroundPaint((java.awt.Paint) color10);
        lineAndShapeRenderer2.setPlot(categoryPlot3);
        boolean boolean14 = lineAndShapeRenderer2.getDrawOutlines();
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(drawingSupplier7);
        org.junit.Assert.assertNull(categoryDataset8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = categoryAxis3.getTickLabelInsets();
        categoryAxis3.setCategoryLabelPositionOffset(0);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions7 = categoryAxis3.getCategoryLabelPositions();
        categoryAxis1.setCategoryLabelPositions(categoryLabelPositions7);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot9.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis12 = categoryPlot9.getRangeAxis();
        int int13 = categoryPlot9.getBackgroundImageAlignment();
        categoryPlot9.setDomainCrosshairColumnKey((java.lang.Comparable) (short) -1, true);
        org.jfree.chart.util.Layer layer18 = null;
        java.util.Collection collection19 = categoryPlot9.getRangeMarkers((int) (short) 0, layer18);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot20.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis23 = categoryPlot20.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        categoryPlot20.zoomDomainAxes((double) 10.0f, plotRenderingInfo25, point2D26, false);
        java.lang.Comparable comparable29 = categoryPlot20.getDomainCrosshairColumnKey();
        boolean boolean30 = categoryPlot20.isRangeCrosshairLockedOnData();
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = categoryPlot20.getAxisOffset();
        double double32 = rectangleInsets31.getLeft();
        categoryPlot9.setAxisOffset(rectangleInsets31);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        categoryPlot9.setRenderer(0, categoryItemRenderer35);
        java.awt.Color color37 = java.awt.Color.yellow;
        java.awt.color.ColorSpace colorSpace38 = color37.getColorSpace();
        categoryPlot9.setRangeCrosshairPaint((java.awt.Paint) color37);
        categoryAxis1.setTickLabelPaint((java.awt.Paint) color37);
        categoryAxis1.setLowerMargin((double) 156);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(categoryLabelPositions7);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 15 + "'", int13 == 15);
        org.junit.Assert.assertNull(collection19);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNull(comparable29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 4.0d + "'", double32 == 4.0d);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(colorSpace38);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder5 = categoryPlot0.getRowRenderingOrder();
        categoryPlot0.setWeight((int) (short) 100);
        boolean boolean8 = categoryPlot0.isDomainCrosshairVisible();
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot0.getRangeAxisLocation();
        categoryPlot0.mapDatasetToRangeAxis(0, 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = categoryPlot0.getDomainAxisEdge();
        java.lang.Comparable comparable14 = categoryPlot0.getDomainCrosshairColumnKey();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(sortOrder5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertNull(comparable14);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_HORIZONTAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
        boolean boolean3 = gradientPaintTransformType0.equals((java.lang.Object) "");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer4 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        lineAndShapeRenderer2.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator7);
        lineAndShapeRenderer2.setSeriesVisible((int) (short) 100, (java.lang.Boolean) false, true);
        boolean boolean15 = lineAndShapeRenderer2.getItemShapeVisible((int) (short) 10, 3);
        java.awt.Font font16 = lineAndShapeRenderer2.getBaseLegendTextFont();
        lineAndShapeRenderer2.setUseFillPaint(false);
        java.lang.Boolean boolean20 = lineAndShapeRenderer2.getSeriesCreateEntities((int) (byte) 1);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator21 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        lineAndShapeRenderer2.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator21);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(font16);
        org.junit.Assert.assertNull(boolean20);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getMinimumBarLength();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = barRenderer0.getDrawingSupplier();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot4.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = categoryPlot4.getDomainAxisEdge();
        int int8 = categoryPlot4.getWeight();
        java.util.List list9 = categoryPlot4.getAnnotations();
        java.awt.Color color10 = java.awt.Color.WHITE;
        categoryPlot4.setOutlinePaint((java.awt.Paint) color10);
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.Color color15 = java.awt.Color.yellow;
        java.awt.color.ColorSpace colorSpace16 = color15.getColorSpace();
        float[] floatArray20 = new float[] { (byte) 1, '#', 15 };
        float[] floatArray21 = color15.getRGBColorComponents(floatArray20);
        int int22 = color15.getRGB();
        java.awt.Shape shape27 = null;
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem29 = new org.jfree.chart.LegendItem("", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", shape27, (java.awt.Paint) color28);
        java.awt.Shape shape30 = legendItem29.getShape();
        int int31 = legendItem29.getSeriesIndex();
        org.jfree.data.general.Dataset dataset32 = legendItem29.getDataset();
        java.awt.Stroke stroke33 = legendItem29.getOutlineStroke();
        try {
            barRenderer0.drawRangeLine(graphics2D3, categoryPlot4, valueAxis12, rectangle2D13, (double) 100.0f, (java.awt.Paint) color15, stroke33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(drawingSupplier2);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(colorSpace16);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-256) + "'", int22 == (-256));
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNull(shape30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNull(dataset32);
        org.junit.Assert.assertNotNull(stroke33);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor9 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        categoryPlot0.setRenderer(categoryItemRenderer10, false);
        float float13 = categoryPlot0.getBackgroundImageAlpha();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Point2D point2D16 = null;
        categoryPlot0.panDomainAxes((double) (byte) 100, plotRenderingInfo15, point2D16);
        org.jfree.data.category.CategoryDataset categoryDataset19 = categoryPlot0.getDataset(3);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(categoryAnchor9);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.5f + "'", float13 == 0.5f);
        org.junit.Assert.assertNull(categoryDataset19);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Shape shape9 = lineAndShapeRenderer2.getItemShape((int) (short) 10, 100, true);
        lineAndShapeRenderer2.setBaseSeriesVisible(false);
        boolean boolean12 = lineAndShapeRenderer2.getUseFillPaint();
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot15.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis18 = categoryPlot15.getRangeAxis();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier19 = categoryPlot15.getDrawingSupplier();
        java.awt.Stroke stroke20 = categoryPlot15.getOutlineStroke();
        java.awt.Shape shape25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot26.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis29 = categoryPlot26.getRangeAxis();
        int int30 = categoryPlot26.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder31 = categoryPlot26.getRowRenderingOrder();
        java.awt.Stroke stroke32 = categoryPlot26.getRangeZeroBaselineStroke();
        java.awt.Paint paint33 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem34 = new org.jfree.chart.LegendItem("", "", "hi!", "", shape25, stroke32, paint33);
        legendItem34.setDescription("");
        int int37 = legendItem34.getDatasetIndex();
        java.lang.String str38 = legendItem34.getLabel();
        java.lang.String str39 = legendItem34.getLabel();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset40 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo41 = new org.jfree.chart.event.DatasetChangeInfo();
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent42 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object) legendItem34, (org.jfree.data.general.Dataset) defaultCategoryDataset40, datasetChangeInfo41);
        defaultCategoryDataset40.clearSelection();
        int int45 = defaultCategoryDataset40.getColumnIndex((java.lang.Comparable) 4.0d);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo46 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState47 = lineAndShapeRenderer2.initialise(graphics2D13, rectangle2D14, categoryPlot15, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset40, plotRenderingInfo46);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(valueAxis18);
        org.junit.Assert.assertNotNull(drawingSupplier19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNull(valueAxis29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 15 + "'", int30 == 15);
        org.junit.Assert.assertNotNull(sortOrder31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "" + "'", str38.equals(""));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "" + "'", str39.equals(""));
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertNotNull(categoryItemRendererState47);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        java.lang.String str1 = chartChangeEventType0.toString();
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ChartChangeEventType.NEW_DATASET" + "'", str1.equals("ChartChangeEventType.NEW_DATASET"));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE10;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis4 = categoryPlot1.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot1.zoomDomainAxes((double) 10.0f, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor10 = categoryPlot1.getDomainGridlinePosition();
        boolean boolean11 = itemLabelAnchor0.equals((java.lang.Object) categoryAnchor10);
        org.jfree.chart.text.TextAnchor textAnchor12 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor13 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor12, textAnchor13, (double) 10);
        org.jfree.chart.renderer.RenderAttributes renderAttributes20 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        renderAttributes20.setDefaultFillPaint((java.awt.Paint) color21);
        java.awt.Shape shape25 = renderAttributes20.getItemShape((int) (byte) 100, (int) 'a');
        java.awt.Shape shape26 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        renderAttributes20.setDefaultShape(shape26);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot28.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis31 = categoryPlot28.getRangeAxis();
        int int32 = categoryPlot28.getBackgroundImageAlignment();
        categoryPlot28.setDomainCrosshairColumnKey((java.lang.Comparable) (short) -1, true);
        java.awt.Stroke stroke36 = categoryPlot28.getDomainGridlineStroke();
        java.awt.Color color37 = java.awt.Color.MAGENTA;
        org.jfree.chart.LegendItem legendItem38 = new org.jfree.chart.LegendItem("hi!", "AxisLocation.BOTTOM_OR_LEFT", "AxisLocation.BOTTOM_OR_LEFT", "ChartChangeEventType.GENERAL", shape26, stroke36, (java.awt.Paint) color37);
        boolean boolean39 = textAnchor13.equals((java.lang.Object) "AxisLocation.BOTTOM_OR_LEFT");
        java.lang.String str40 = textAnchor13.toString();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertNotNull(categoryAnchor10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(textAnchor12);
        org.junit.Assert.assertNotNull(textAnchor13);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNull(shape25);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNull(valueAxis31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 15 + "'", int32 == 15);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str40.equals("TextAnchor.BASELINE_LEFT"));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        java.awt.Shape shape4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        int int9 = categoryPlot5.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot5.getRowRenderingOrder();
        java.awt.Stroke stroke11 = categoryPlot5.getRangeZeroBaselineStroke();
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("", "", "hi!", "", shape4, stroke11, paint12);
        legendItem13.setSeriesKey((java.lang.Comparable) 0.0d);
        java.lang.Object obj16 = legendItem13.clone();
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(obj16);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        categoryPlot0.setDomainCrosshairColumnKey((java.lang.Comparable) (short) -1, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot0.zoomRangeAxes((double) (byte) 1, plotRenderingInfo9, point2D10, true);
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) 0.0f, false);
        org.jfree.chart.util.ShadowGenerator shadowGenerator16 = categoryPlot0.getShadowGenerator();
        categoryPlot0.clearAnnotations();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(shadowGenerator16);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        lineAndShapeRenderer2.setAutoPopulateSeriesStroke(true);
        java.lang.Boolean boolean9 = lineAndShapeRenderer2.getSeriesShapesFilled((int) (short) -1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNull(boolean9);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot3.getRangeAxis();
        int int7 = categoryPlot3.getBackgroundImageAlignment();
        java.awt.Paint paint8 = categoryPlot3.getNoDataMessagePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot3.getDomainAxisForDataset((int) 'a');
        java.awt.Paint paint11 = categoryPlot3.getDomainCrosshairPaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = categoryAxis13.getTickLabelInsets();
        categoryAxis13.setCategoryLabelPositionOffset(0);
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot17.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis20 = categoryPlot17.getRangeAxis();
        int int21 = categoryPlot17.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot17.getRowRenderingOrder();
        java.awt.Stroke stroke23 = categoryPlot17.getRangeZeroBaselineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent24 = null;
        categoryPlot17.rendererChanged(rendererChangeEvent24);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation27 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot26.setRangeAxisLocation(axisLocation27, true);
        categoryPlot17.setDomainAxisLocation(axisLocation27);
        categoryPlot17.setCrosshairDatasetIndex((int) (short) 1);
        categoryAxis13.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot17);
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.data.category.CategoryDataset categoryDataset35 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer41 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke42 = lineAndShapeRenderer41.getBaseStroke();
        java.awt.Paint paint44 = lineAndShapeRenderer41.getSeriesPaint(15);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition46 = lineAndShapeRenderer41.getSeriesNegativeItemLabelPosition(255);
        int int47 = lineAndShapeRenderer41.getDefaultEntityRadius();
        java.awt.Stroke stroke48 = lineAndShapeRenderer41.getBaseOutlineStroke();
        java.awt.Graphics2D graphics2D49 = null;
        java.awt.geom.Rectangle2D rectangle2D50 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation52 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot51.setRangeAxisLocation(axisLocation52, true);
        java.lang.Comparable comparable55 = categoryPlot51.getDomainCrosshairColumnKey();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer58 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke59 = lineAndShapeRenderer58.getBaseStroke();
        org.jfree.chart.LegendItemCollection legendItemCollection60 = lineAndShapeRenderer58.getLegendItems();
        categoryPlot51.setFixedLegendItems(legendItemCollection60);
        org.jfree.data.category.CategoryDataset categoryDataset62 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo63 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState64 = lineAndShapeRenderer41.initialise(graphics2D49, rectangle2D50, categoryPlot51, categoryDataset62, plotRenderingInfo63);
        java.awt.geom.Rectangle2D rectangle2D65 = null;
        java.awt.geom.Rectangle2D rectangle2D66 = barRenderer0.createHotSpotBounds(graphics2D1, rectangle2D2, categoryPlot3, categoryAxis13, valueAxis34, categoryDataset35, 0, 255, false, categoryItemRendererState64, rectangle2D65);
        categoryPlot3.setRangeZeroBaselineVisible(false);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 15 + "'", int7 == 15);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNull(valueAxis20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 15 + "'", int21 == 15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNull(paint44);
        org.junit.Assert.assertNotNull(itemLabelPosition46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 3 + "'", int47 == 3);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(axisLocation52);
        org.junit.Assert.assertNull(comparable55);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertNotNull(legendItemCollection60);
        org.junit.Assert.assertNotNull(categoryItemRendererState64);
        org.junit.Assert.assertNull(rectangle2D66);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape1 = defaultDrawingSupplier0.getNextShape();
        java.awt.Stroke stroke2 = defaultDrawingSupplier0.getNextStroke();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape3, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape7 = chartEntity6.getArea();
        java.awt.Shape shape8 = chartEntity6.getArea();
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot9.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = categoryPlot9.getDomainAxisEdge();
        int int13 = categoryPlot9.getWeight();
        java.lang.Comparable comparable14 = categoryPlot9.getDomainCrosshairColumnKey();
        boolean boolean15 = categoryPlot9.canSelectByRegion();
        org.jfree.chart.axis.AxisLocation axisLocation16 = categoryPlot9.getRangeAxisLocation();
        org.jfree.chart.entity.PlotEntity plotEntity19 = new org.jfree.chart.entity.PlotEntity(shape8, (org.jfree.chart.plot.Plot) categoryPlot9, "ItemLabelAnchor.OUTSIDE1", "java.awt.Color[r=0,g=0,b=0]");
        plotEntity19.setURLText("ItemLabelAnchor.OUTSIDE1");
        org.jfree.chart.plot.Plot plot22 = plotEntity19.getPlot();
        boolean boolean23 = defaultDrawingSupplier0.equals((java.lang.Object) plot22);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNull(comparable14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(plot22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.util.Layer layer5 = null;
        java.util.Collection collection6 = categoryPlot0.getRangeMarkers(10, layer5);
        org.jfree.chart.axis.AxisLocation axisLocation7 = categoryPlot0.getDomainAxisLocation();
        categoryPlot0.setRangeCrosshairValue((double) (short) -1, true);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNull(collection6);
        org.junit.Assert.assertNotNull(axisLocation7);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairLockedOnData(false);
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) (short) 10);
        categoryPlot0.setAnchorValue((double) (short) 10, false);
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace8);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        categoryPlot0.markerChanged(markerChangeEvent10);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke15 = lineAndShapeRenderer14.getBaseStroke();
        java.awt.Stroke stroke17 = lineAndShapeRenderer14.lookupSeriesStroke(10);
        java.awt.Shape shape23 = null;
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", shape23, (java.awt.Paint) color24);
        int int26 = color24.getBlue();
        lineAndShapeRenderer14.setSeriesItemLabelPaint((int) (byte) 1, (java.awt.Paint) color24);
        int int28 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer14);
        java.awt.Paint paint29 = null;
        lineAndShapeRenderer14.setBaseLegendTextPaint(paint29);
        java.awt.Font font31 = lineAndShapeRenderer14.getBaseItemLabelFont();
        java.lang.Boolean boolean33 = lineAndShapeRenderer14.getSeriesShapesVisible((int) (byte) 0);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 128 + "'", int26 == 128);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNull(boolean33);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        renderAttributes0.setDefaultFillPaint((java.awt.Paint) color1);
        java.awt.Shape shape5 = renderAttributes0.getItemShape((int) (byte) 100, (int) 'a');
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        renderAttributes0.setDefaultShape(shape6);
        renderAttributes0.setDefaultLabelVisible((java.lang.Boolean) true);
        java.awt.Paint paint12 = renderAttributes0.getItemOutlinePaint(100, (int) ' ');
        java.awt.Paint paint13 = renderAttributes0.getDefaultOutlinePaint();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNull(shape5);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertNull(paint13);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        renderAttributes0.setDefaultFillPaint((java.awt.Paint) color1);
        java.awt.Shape shape5 = renderAttributes0.getItemShape((int) (byte) 100, (int) 'a');
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        renderAttributes0.setDefaultShape(shape6);
        java.awt.Paint paint8 = renderAttributes0.getDefaultOutlinePaint();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer12 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke13 = lineAndShapeRenderer12.getBaseStroke();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator15 = null;
        lineAndShapeRenderer12.setSeriesItemLabelGenerator((int) (byte) 1, categoryItemLabelGenerator15);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer20 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke21 = lineAndShapeRenderer20.getBaseStroke();
        java.awt.Paint paint23 = lineAndShapeRenderer20.getSeriesPaint(15);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer27 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke28 = lineAndShapeRenderer27.getBaseStroke();
        java.awt.Stroke stroke30 = lineAndShapeRenderer27.lookupSeriesStroke(10);
        java.awt.Paint paint31 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        lineAndShapeRenderer27.setBaseOutlinePaint(paint31);
        java.awt.Font font33 = lineAndShapeRenderer27.getBaseItemLabelFont();
        lineAndShapeRenderer20.setSeriesItemLabelFont((int) (byte) 1, font33);
        lineAndShapeRenderer12.setSeriesItemLabelFont((int) (short) 10, font33, true);
        try {
            renderAttributes0.setSeriesLabelFont((int) '#', font33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNull(shape5);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNull(paint23);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(font33);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        java.lang.Comparable comparable9 = categoryPlot0.getDomainCrosshairColumnKey();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        categoryPlot0.setDataset(categoryDataset10);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot13.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis16 = categoryPlot13.getRangeAxis();
        int int17 = categoryPlot13.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder18 = categoryPlot13.getRowRenderingOrder();
        categoryPlot13.mapDatasetToRangeAxis((int) '#', (int) (byte) 10);
        categoryPlot13.setRangeZeroBaselineVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot24.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis27 = categoryPlot24.getRangeAxis();
        int int28 = categoryPlot24.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder29 = categoryPlot24.getRowRenderingOrder();
        java.awt.Stroke stroke30 = categoryPlot24.getRangeZeroBaselineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent31 = null;
        categoryPlot24.rendererChanged(rendererChangeEvent31);
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation34 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot33.setRangeAxisLocation(axisLocation34, true);
        categoryPlot24.setDomainAxisLocation(axisLocation34);
        categoryPlot13.setRangeAxisLocation(axisLocation34);
        categoryPlot0.setRangeAxisLocation((int) (byte) 1, axisLocation34);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNull(comparable9);
        org.junit.Assert.assertNull(valueAxis16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 15 + "'", int17 == 15);
        org.junit.Assert.assertNotNull(sortOrder18);
        org.junit.Assert.assertNull(valueAxis27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 15 + "'", int28 == 15);
        org.junit.Assert.assertNotNull(sortOrder29);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(axisLocation34);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryPlot0.getAxisOffset();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.panRangeAxes(92.0d, plotRenderingInfo5, point2D6);
        org.junit.Assert.assertNotNull(rectangleInsets3);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        java.awt.Paint paint5 = categoryPlot0.getNoDataMessagePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = categoryPlot0.getDomainAxisForDataset((int) 'a');
        java.awt.Paint paint8 = categoryPlot0.getDomainCrosshairPaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = categoryAxis10.getTickLabelInsets();
        categoryPlot0.setDomainAxis(categoryAxis10);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        categoryPlot0.drawBackgroundImage(graphics2D13, rectangle2D14);
        categoryPlot0.setRangeCrosshairValue(0.0d, false);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(categoryAxis7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(rectangleInsets11);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        java.awt.Color color1 = java.awt.Color.getColor("AxisLocation.BOTTOM_OR_LEFT");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Shape shape9 = lineAndShapeRenderer2.getItemShape((int) (short) 10, 100, true);
        lineAndShapeRenderer2.setBaseSeriesVisible(false);
        lineAndShapeRenderer2.setSeriesShapesVisible((int) (short) 10, false);
        java.awt.Shape shape16 = lineAndShapeRenderer2.lookupSeriesShape(1);
        int int17 = lineAndShapeRenderer2.getColumnCount();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        java.awt.Paint paint5 = categoryPlot0.getNoDataMessagePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = categoryPlot0.getDomainAxisForDataset((int) 'a');
        java.awt.Paint paint8 = categoryPlot0.getDomainCrosshairPaint();
        categoryPlot0.setRangePannable(true);
        java.awt.Color color11 = java.awt.Color.yellow;
        java.awt.color.ColorSpace colorSpace12 = color11.getColorSpace();
        float[] floatArray16 = new float[] { (byte) 1, '#', 15 };
        float[] floatArray17 = color11.getRGBColorComponents(floatArray16);
        int int18 = color11.getRGB();
        categoryPlot0.setRangeMinorGridlinePaint((java.awt.Paint) color11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        categoryPlot0.zoomRangeAxes((double) (short) -1, plotRenderingInfo21, point2D22);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(categoryAxis7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(colorSpace12);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-256) + "'", int18 == (-256));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        java.awt.Shape shape4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        int int9 = categoryPlot5.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot5.getRowRenderingOrder();
        java.awt.Stroke stroke11 = categoryPlot5.getRangeZeroBaselineStroke();
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("", "", "hi!", "", shape4, stroke11, paint12);
        legendItem13.setDescription("");
        int int16 = legendItem13.getDatasetIndex();
        java.lang.String str17 = legendItem13.getLabel();
        java.lang.String str18 = legendItem13.getLabel();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset19 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo20 = new org.jfree.chart.event.DatasetChangeInfo();
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent21 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object) legendItem13, (org.jfree.data.general.Dataset) defaultCategoryDataset19, datasetChangeInfo20);
        java.util.List list22 = defaultCategoryDataset19.getRowKeys();
        defaultCategoryDataset19.clearSelection();
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertNotNull(list22);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getMinimumBarLength();
        java.awt.Paint paint5 = barRenderer0.getItemPaint(0, 15, true);
        double double6 = barRenderer0.getShadowXOffset();
        double double7 = barRenderer0.getItemMargin();
        double double8 = barRenderer0.getItemMargin();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.2d + "'", double7 == 0.2d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.2d + "'", double8 == 0.2d);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape0, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape4 = chartEntity3.getArea();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot5.zoomDomainAxes((double) 10.0f, plotRenderingInfo10, point2D11, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor14 = categoryPlot5.getDomainGridlinePosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot15.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis18 = categoryPlot15.getRangeAxis();
        int int19 = categoryPlot15.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder20 = categoryPlot15.getRowRenderingOrder();
        java.awt.Stroke stroke21 = categoryPlot15.getRangeZeroBaselineStroke();
        categoryPlot5.setRangeMinorGridlineStroke(stroke21);
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = categoryPlot5.getDomainAxis(100);
        boolean boolean25 = categoryPlot5.isNotify();
        org.jfree.chart.entity.PlotEntity plotEntity27 = new org.jfree.chart.entity.PlotEntity(shape4, (org.jfree.chart.plot.Plot) categoryPlot5, "ItemLabelAnchor.OUTSIDE1");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset30 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity33 = new org.jfree.chart.entity.CategoryItemEntity(shape4, "PlotOrientation.VERTICAL", "PlotOrientation.VERTICAL", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset30, (java.lang.Comparable) 10, (java.lang.Comparable) 'a');
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset36 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset36.clear();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity40 = new org.jfree.chart.entity.CategoryItemEntity(shape4, "AxisLocation.BOTTOM_OR_LEFT", "ItemLabelAnchor.OUTSIDE2", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset36, (java.lang.Comparable) 7.0d, (java.lang.Comparable) "PlotOrientation.VERTICAL");
        int int41 = defaultCategoryDataset36.getColumnCount();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertNotNull(categoryAnchor14);
        org.junit.Assert.assertNull(valueAxis18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 15 + "'", int19 == 15);
        org.junit.Assert.assertNotNull(sortOrder20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNull(categoryAxis24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier4 = categoryPlot0.getDrawingSupplier();
        java.awt.Stroke stroke5 = categoryPlot0.getOutlineStroke();
        org.jfree.chart.plot.Plot plot6 = categoryPlot0.getParent();
        categoryPlot0.setDrawSharedDomainAxis(false);
        java.awt.Paint paint9 = categoryPlot0.getBackgroundPaint();
        categoryPlot0.setRangeCrosshairVisible(false);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(drawingSupplier4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNull(plot6);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        java.awt.Shape shape4 = null;
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem6 = new org.jfree.chart.LegendItem("", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", shape4, (java.awt.Paint) color5);
        java.awt.Shape shape7 = legendItem6.getShape();
        int int8 = legendItem6.getSeriesIndex();
        boolean boolean9 = legendItem6.isShapeVisible();
        java.lang.String str10 = legendItem6.getLabel();
        int int11 = legendItem6.getSeriesIndex();
        java.awt.Color color12 = java.awt.Color.yellow;
        java.awt.color.ColorSpace colorSpace13 = color12.getColorSpace();
        int int14 = color12.getTransparency();
        legendItem6.setLinePaint((java.awt.Paint) color12);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer16 = legendItem6.getFillPaintTransformer();
        java.awt.Stroke stroke17 = legendItem6.getOutlineStroke();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(shape7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(colorSpace13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(gradientPaintTransformer16);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        java.awt.Paint paint5 = categoryPlot0.getNoDataMessagePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = categoryPlot0.getDomainAxisForDataset((int) 'a');
        java.awt.Paint paint8 = categoryPlot0.getDomainCrosshairPaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = categoryAxis10.getTickLabelInsets();
        categoryPlot0.setDomainAxis(categoryAxis10);
        categoryPlot0.clearRangeAxes();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(categoryAxis7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(rectangleInsets11);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = categoryAxis1.getTickLabelInsets();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer5.getBasePositiveItemLabelPosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot7.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = categoryPlot7.getDomainAxisEdge();
        org.jfree.chart.axis.AxisLocation axisLocation11 = categoryPlot7.getDomainAxisLocation();
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        categoryPlot7.drawBackgroundImage(graphics2D12, rectangle2D13);
        java.awt.Paint paint15 = categoryPlot7.getNoDataMessagePaint();
        lineAndShapeRenderer5.setBaseItemLabelPaint(paint15);
        java.awt.Stroke stroke18 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        lineAndShapeRenderer5.setSeriesStroke((int) (byte) 0, stroke18, false);
        categoryAxis1.setAxisLineStroke(stroke18);
        java.lang.String str23 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) (byte) 1);
        categoryAxis1.setLabel("-4,-4,4,4");
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNull(str23);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        java.awt.Shape shape4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        int int9 = categoryPlot5.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot5.getRowRenderingOrder();
        java.awt.Stroke stroke11 = categoryPlot5.getRangeZeroBaselineStroke();
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("", "", "hi!", "", shape4, stroke11, paint12);
        legendItem13.setDescription("");
        int int16 = legendItem13.getDatasetIndex();
        java.lang.String str17 = legendItem13.getLabel();
        java.awt.Paint paint18 = legendItem13.getOutlinePaint();
        int int19 = legendItem13.getSeriesIndex();
        java.awt.Paint paint20 = legendItem13.getFillPaint();
        legendItem13.setSeriesIndex(64);
        java.lang.String str23 = legendItem13.getToolTipText();
        boolean boolean24 = legendItem13.isShapeVisible();
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "hi!" + "'", str23.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairLockedOnData(false);
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) (short) 10);
        categoryPlot0.setAnchorValue((double) (short) 10, false);
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace8);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        categoryPlot0.markerChanged(markerChangeEvent10);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke15 = lineAndShapeRenderer14.getBaseStroke();
        java.awt.Stroke stroke17 = lineAndShapeRenderer14.lookupSeriesStroke(10);
        java.awt.Shape shape23 = null;
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", shape23, (java.awt.Paint) color24);
        int int26 = color24.getBlue();
        lineAndShapeRenderer14.setSeriesItemLabelPaint((int) (byte) 1, (java.awt.Paint) color24);
        int int28 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer14);
        java.awt.Paint paint29 = null;
        lineAndShapeRenderer14.setBaseLegendTextPaint(paint29);
        lineAndShapeRenderer14.setSeriesItemLabelsVisible(100, false);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 128 + "'", int26 == 128);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Shape shape9 = lineAndShapeRenderer2.getItemShape((int) (short) 10, 100, true);
        lineAndShapeRenderer2.setBaseSeriesVisible(false);
        java.awt.Shape shape12 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity15 = new org.jfree.chart.entity.ChartEntity(shape12, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape16 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity19 = new org.jfree.chart.entity.ChartEntity(shape16, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape20 = chartEntity19.getArea();
        chartEntity15.setArea(shape20);
        lineAndShapeRenderer2.setBaseShape(shape20, true);
        java.lang.Boolean boolean25 = lineAndShapeRenderer2.getSeriesShapesVisible(1);
        java.awt.Font font26 = lineAndShapeRenderer2.getBaseItemLabelFont();
        java.awt.Font font28 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        lineAndShapeRenderer2.setSeriesItemLabelFont((int) (short) 100, font28);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator33 = lineAndShapeRenderer2.getURLGenerator(156, (int) (byte) 0, false);
        org.jfree.chart.util.ShapeList shapeList35 = new org.jfree.chart.util.ShapeList();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer39 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke40 = lineAndShapeRenderer39.getBaseStroke();
        java.awt.Paint paint42 = lineAndShapeRenderer39.getSeriesPaint(15);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition44 = lineAndShapeRenderer39.getSeriesNegativeItemLabelPosition(255);
        int int45 = lineAndShapeRenderer39.getDefaultEntityRadius();
        java.awt.Stroke stroke46 = lineAndShapeRenderer39.getBaseOutlineStroke();
        java.awt.Shape shape48 = lineAndShapeRenderer39.getSeriesShape(15);
        java.awt.Shape shape50 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity53 = new org.jfree.chart.entity.ChartEntity(shape50, "ChartChangeEventType.GENERAL", "");
        lineAndShapeRenderer39.setSeriesShape(3, shape50);
        shapeList35.setShape(255, shape50);
        lineAndShapeRenderer2.setSeriesShape((int) 'a', shape50);
        java.awt.Paint paint57 = lineAndShapeRenderer2.getBaseFillPaint();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNull(boolean25);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNull(categoryURLGenerator33);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNull(paint42);
        org.junit.Assert.assertNotNull(itemLabelPosition44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 3 + "'", int45 == 3);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNull(shape48);
        org.junit.Assert.assertNotNull(shape50);
        org.junit.Assert.assertNotNull(paint57);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.clearSeriesStrokes(true);
        java.lang.Boolean boolean4 = lineAndShapeRenderer0.getSeriesVisibleInLegend(3);
        java.lang.Boolean boolean6 = lineAndShapeRenderer0.getSeriesShapesFilled(10);
        lineAndShapeRenderer0.clearSeriesStrokes(false);
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertNull(boolean6);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Shape shape9 = lineAndShapeRenderer2.getItemShape((int) (short) 10, 100, true);
        boolean boolean13 = lineAndShapeRenderer2.getItemCreateEntity(0, (int) 'a', true);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot15.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis18 = categoryPlot15.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        java.awt.geom.Point2D point2D21 = null;
        categoryPlot15.zoomDomainAxes((double) 10.0f, plotRenderingInfo20, point2D21, false);
        java.lang.Comparable comparable24 = categoryPlot15.getDomainCrosshairColumnKey();
        boolean boolean25 = categoryPlot15.isRangeCrosshairLockedOnData();
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        categoryPlot15.setDomainCrosshairPaint((java.awt.Paint) color26);
        java.awt.Shape shape32 = null;
        java.awt.Color color33 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem34 = new org.jfree.chart.LegendItem("", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", shape32, (java.awt.Paint) color33);
        categoryPlot15.setDomainGridlinePaint((java.awt.Paint) color33);
        java.awt.Color color36 = color33.brighter();
        lineAndShapeRenderer2.setSeriesFillPaint((int) '4', (java.awt.Paint) color36);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNull(valueAxis18);
        org.junit.Assert.assertNull(comparable24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(color36);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge();
        org.jfree.chart.axis.AxisLocation axisLocation4 = categoryPlot0.getDomainAxisLocation();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        categoryPlot0.drawBackgroundImage(graphics2D5, rectangle2D6);
        java.awt.Paint paint8 = categoryPlot0.getNoDataMessagePaint();
        float float9 = categoryPlot0.getBackgroundAlpha();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        categoryPlot0.markerChanged(markerChangeEvent10);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 1.0f + "'", float9 == 1.0f);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        org.jfree.chart.LegendItemCollection legendItemCollection4 = lineAndShapeRenderer2.getLegendItems();
        org.jfree.chart.renderer.RenderAttributes renderAttributes5 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Shape shape8 = renderAttributes5.getItemShape((int) (byte) 10, 15);
        java.awt.Color color10 = java.awt.Color.CYAN;
        renderAttributes5.setSeriesOutlinePaint((int) (byte) 0, (java.awt.Paint) color10);
        lineAndShapeRenderer2.setBaseItemLabelPaint((java.awt.Paint) color10, true);
        boolean boolean14 = lineAndShapeRenderer2.getBaseLinesVisible();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(legendItemCollection4);
        org.junit.Assert.assertNull(shape8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        int int2 = keyedObjects0.getIndex((java.lang.Comparable) (short) 100);
        java.util.List list3 = keyedObjects0.getKeys();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.setRangeCrosshairLockedOnData(false);
        categoryPlot5.setDomainCrosshairRowKey((java.lang.Comparable) (short) 10);
        keyedObjects0.addObject((java.lang.Comparable) (short) -1, (java.lang.Object) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(list3);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getMinimumBarLength();
        java.awt.Paint paint5 = barRenderer0.getItemPaint(0, 15, true);
        double double6 = barRenderer0.getShadowXOffset();
        boolean boolean7 = barRenderer0.getIncludeBaseInRange();
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis13 = categoryPlot10.getRangeAxis();
        int int14 = categoryPlot10.getBackgroundImageAlignment();
        categoryPlot10.setDomainCrosshairColumnKey((java.lang.Comparable) (short) -1, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        categoryPlot10.zoomRangeAxes((double) (byte) 1, plotRenderingInfo19, point2D20, true);
        categoryPlot10.setDomainCrosshairRowKey((java.lang.Comparable) 0.0f, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot26.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis29 = categoryPlot26.getRangeAxis();
        int int30 = categoryPlot26.getBackgroundImageAlignment();
        java.awt.Paint paint31 = categoryPlot26.getNoDataMessagePaint();
        java.awt.Paint paint32 = categoryPlot26.getRangeMinorGridlinePaint();
        categoryPlot10.setParent((org.jfree.chart.plot.Plot) categoryPlot26);
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = categoryAxis35.getTickLabelInsets();
        categoryAxis35.setCategoryLabelPositionOffset(0);
        categoryAxis35.setMinorTickMarksVisible(false);
        float float41 = categoryAxis35.getMinorTickMarkOutsideLength();
        boolean boolean42 = categoryAxis35.isVisible();
        categoryAxis35.setTickMarkOutsideLength((float) 10L);
        float float45 = categoryAxis35.getTickMarkOutsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis46 = null;
        java.awt.Shape shape51 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot52 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot52.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis55 = categoryPlot52.getRangeAxis();
        int int56 = categoryPlot52.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder57 = categoryPlot52.getRowRenderingOrder();
        java.awt.Stroke stroke58 = categoryPlot52.getRangeZeroBaselineStroke();
        java.awt.Paint paint59 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem60 = new org.jfree.chart.LegendItem("", "", "hi!", "", shape51, stroke58, paint59);
        legendItem60.setDescription("");
        int int63 = legendItem60.getDatasetIndex();
        java.lang.String str64 = legendItem60.getLabel();
        java.lang.String str65 = legendItem60.getLabel();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset66 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo67 = new org.jfree.chart.event.DatasetChangeInfo();
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent68 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object) legendItem60, (org.jfree.data.general.Dataset) defaultCategoryDataset66, datasetChangeInfo67);
        defaultCategoryDataset66.clearSelection();
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState73 = null;
        java.awt.geom.Rectangle2D rectangle2D74 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D75 = barRenderer0.createHotSpotBounds(graphics2D8, rectangle2D9, categoryPlot10, categoryAxis35, valueAxis46, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset66, 15, 0, true, categoryItemRendererState73, rectangle2D74);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(valueAxis13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 15 + "'", int14 == 15);
        org.junit.Assert.assertNull(valueAxis29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 15 + "'", int30 == 15);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + float41 + "' != '" + 2.0f + "'", float41 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + float45 + "' != '" + 10.0f + "'", float45 == 10.0f);
        org.junit.Assert.assertNull(valueAxis55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 15 + "'", int56 == 15);
        org.junit.Assert.assertNotNull(sortOrder57);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertNotNull(paint59);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "" + "'", str64.equals(""));
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "" + "'", str65.equals(""));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Shape shape11 = null;
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", shape11, (java.awt.Paint) color12);
        int int14 = color12.getBlue();
        lineAndShapeRenderer2.setSeriesItemLabelPaint((int) (byte) 1, (java.awt.Paint) color12);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean17 = categoryPlot16.isRangeGridlinesVisible();
        categoryPlot16.clearDomainAxes();
        lineAndShapeRenderer2.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot16);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator21 = lineAndShapeRenderer2.getSeriesURLGenerator((int) 'a');
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator23 = null;
        lineAndShapeRenderer2.setSeriesURLGenerator(0, categoryURLGenerator23);
        boolean boolean25 = lineAndShapeRenderer2.getDataBoundsIncludesVisibleSeriesOnly();
        boolean boolean26 = lineAndShapeRenderer2.getAutoPopulateSeriesShape();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 128 + "'", int14 == 128);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNull(categoryURLGenerator21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        org.jfree.chart.LegendItem legendItem2 = new org.jfree.chart.LegendItem("PlotEntity: tooltip = ItemLabelAnchor.OUTSIDE1", (java.awt.Paint) color1);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor3 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE5;
        java.awt.Color color4 = java.awt.Color.white;
        boolean boolean5 = itemLabelAnchor3.equals((java.lang.Object) color4);
        java.awt.Color color6 = java.awt.Color.yellow;
        java.awt.color.ColorSpace colorSpace7 = color6.getColorSpace();
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) (short) 1, (float) 100, 0.0f);
        float[] floatArray21 = new float[] { (byte) 10, (byte) 1, 1.0f, (byte) 0, 10, (byte) 100 };
        float[] floatArray22 = color14.getRGBComponents(floatArray21);
        float[] floatArray23 = java.awt.Color.RGBtoHSB((int) ' ', 1, 255, floatArray21);
        float[] floatArray24 = color4.getComponents(colorSpace7, floatArray23);
        float[] floatArray25 = color1.getRGBColorComponents(floatArray23);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(itemLabelAnchor3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(colorSpace7);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray25);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Shape shape9 = lineAndShapeRenderer2.getItemShape((int) (short) 10, 100, true);
        lineAndShapeRenderer2.setBaseSeriesVisible(false);
        java.awt.Shape shape12 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity15 = new org.jfree.chart.entity.ChartEntity(shape12, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape16 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity19 = new org.jfree.chart.entity.ChartEntity(shape16, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape20 = chartEntity19.getArea();
        chartEntity15.setArea(shape20);
        lineAndShapeRenderer2.setBaseShape(shape20, true);
        java.lang.Boolean boolean25 = lineAndShapeRenderer2.getSeriesShapesVisible(1);
        java.awt.Font font26 = lineAndShapeRenderer2.getBaseItemLabelFont();
        lineAndShapeRenderer2.setSeriesShapesVisible(1, true);
        java.awt.Paint paint30 = lineAndShapeRenderer2.getBaseOutlinePaint();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNull(boolean25);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(paint30);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge();
        int int4 = categoryPlot0.getWeight();
        java.lang.Comparable comparable5 = categoryPlot0.getDomainCrosshairColumnKey();
        boolean boolean6 = categoryPlot0.canSelectByRegion();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = categoryPlot0.getRenderer((int) (byte) 10);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNull(comparable5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(categoryItemRenderer8);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape0, "ChartChangeEventType.GENERAL", "");
        java.lang.Object obj4 = chartEntity3.clone();
        chartEntity3.setURLText("");
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        java.lang.String str1 = categoryAnchor0.toString();
        org.junit.Assert.assertNotNull(categoryAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CategoryAnchor.MIDDLE" + "'", str1.equals("CategoryAnchor.MIDDLE"));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.clearSeriesStrokes(true);
        java.lang.Boolean boolean4 = lineAndShapeRenderer0.getSeriesVisibleInLegend(3);
        java.lang.Boolean boolean6 = lineAndShapeRenderer0.getSeriesShapesFilled(10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = null;
        lineAndShapeRenderer0.setSeriesNegativeItemLabelPosition(1, itemLabelPosition8);
        java.awt.Paint paint11 = lineAndShapeRenderer0.getSeriesPaint((int) ' ');
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertNull(boolean6);
        org.junit.Assert.assertNull(paint11);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = categoryAxis3.getTickLabelInsets();
        categoryAxis3.setCategoryLabelPositionOffset(0);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions7 = categoryAxis3.getCategoryLabelPositions();
        categoryAxis1.setCategoryLabelPositions(categoryLabelPositions7);
        java.awt.Paint paint9 = categoryAxis1.getAxisLinePaint();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot16.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis19 = categoryPlot16.getRangeAxis();
        categoryPlot16.clearDomainMarkers();
        org.jfree.chart.event.AnnotationChangeEvent annotationChangeEvent21 = null;
        categoryPlot16.annotationChanged(annotationChangeEvent21);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = categoryPlot16.getRangeAxisEdge();
        try {
            double double24 = categoryAxis1.getCategorySeriesMiddle(0, (int) 'a', (int) (short) 0, 64, (double) 100L, rectangle2D15, rectangleEdge23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(categoryLabelPositions7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(valueAxis19);
        org.junit.Assert.assertNotNull(rectangleEdge23);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairLockedOnData(false);
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) (short) 10);
        categoryPlot0.setAnchorValue((double) (short) 10, false);
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace8);
        boolean boolean10 = categoryPlot0.canSelectByRegion();
        int int11 = categoryPlot0.getRangeAxisCount();
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairLockedOnData(false);
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) (short) 10);
        categoryPlot0.setAnchorValue((double) (short) 10, false);
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace8);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        categoryPlot0.markerChanged(markerChangeEvent10);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke15 = lineAndShapeRenderer14.getBaseStroke();
        java.awt.Stroke stroke17 = lineAndShapeRenderer14.lookupSeriesStroke(10);
        java.awt.Shape shape23 = null;
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", shape23, (java.awt.Paint) color24);
        int int26 = color24.getBlue();
        lineAndShapeRenderer14.setSeriesItemLabelPaint((int) (byte) 1, (java.awt.Paint) color24);
        int int28 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer14);
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) 3.0d, true);
        java.awt.Stroke stroke32 = null;
        try {
            categoryPlot0.setRangeMinorGridlineStroke(stroke32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 128 + "'", int26 == 128);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        lineAndShapeRenderer2.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator7);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = lineAndShapeRenderer2.getSeriesPositiveItemLabelPosition(0);
        java.lang.Object obj11 = lineAndShapeRenderer2.clone();
        java.awt.Color color12 = java.awt.Color.blue;
        lineAndShapeRenderer2.setBaseFillPaint((java.awt.Paint) color12);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(color12);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairLockedOnData(false);
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) (short) 10);
        categoryPlot0.setAnchorValue((double) (short) 10, false);
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace8);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        categoryPlot0.markerChanged(markerChangeEvent10);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke15 = lineAndShapeRenderer14.getBaseStroke();
        java.awt.Stroke stroke17 = lineAndShapeRenderer14.lookupSeriesStroke(10);
        java.awt.Shape shape23 = null;
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", shape23, (java.awt.Paint) color24);
        int int26 = color24.getBlue();
        lineAndShapeRenderer14.setSeriesItemLabelPaint((int) (byte) 1, (java.awt.Paint) color24);
        int int28 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer14);
        java.awt.Stroke stroke30 = lineAndShapeRenderer14.lookupSeriesStroke((-1));
        java.awt.Stroke stroke32 = lineAndShapeRenderer14.getSeriesOutlineStroke((int) ' ');
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean35 = categoryPlot34.isRangeGridlinesVisible();
        categoryPlot34.clearDomainAxes();
        java.awt.Color color37 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        categoryPlot34.setOutlinePaint((java.awt.Paint) color37);
        try {
            lineAndShapeRenderer14.setSeriesOutlinePaint((-256), (java.awt.Paint) color37);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 128 + "'", int26 == 128);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNull(stroke32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(color37);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        lineAndShapeRenderer2.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator6 = null;
        lineAndShapeRenderer2.setSeriesURLGenerator(255, categoryURLGenerator6, false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer12 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke13 = lineAndShapeRenderer12.getBaseStroke();
        java.awt.Stroke stroke15 = lineAndShapeRenderer12.lookupSeriesStroke(10);
        java.awt.Shape shape19 = lineAndShapeRenderer12.getItemShape((int) (short) 10, 100, true);
        java.awt.Paint paint21 = lineAndShapeRenderer12.getSeriesFillPaint((int) (short) 10);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator22 = null;
        lineAndShapeRenderer12.setBaseURLGenerator(categoryURLGenerator22);
        int int24 = lineAndShapeRenderer12.getPassCount();
        lineAndShapeRenderer12.setBaseSeriesVisibleInLegend(false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer29 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke30 = lineAndShapeRenderer29.getBaseStroke();
        java.awt.Stroke stroke32 = lineAndShapeRenderer29.lookupSeriesStroke(10);
        java.awt.Shape shape38 = null;
        java.awt.Color color39 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem40 = new org.jfree.chart.LegendItem("", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", shape38, (java.awt.Paint) color39);
        int int41 = color39.getBlue();
        lineAndShapeRenderer29.setSeriesItemLabelPaint((int) (byte) 1, (java.awt.Paint) color39);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer45 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke46 = lineAndShapeRenderer45.getBaseStroke();
        java.awt.Stroke stroke48 = lineAndShapeRenderer45.lookupSeriesStroke(10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator50 = null;
        lineAndShapeRenderer45.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator50);
        lineAndShapeRenderer45.setSeriesVisible((int) (short) 100, (java.lang.Boolean) false, true);
        boolean boolean58 = lineAndShapeRenderer45.getItemShapeVisible((int) (short) 10, 3);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator59 = lineAndShapeRenderer45.getLegendItemLabelGenerator();
        lineAndShapeRenderer29.setLegendItemLabelGenerator(categorySeriesLabelGenerator59);
        lineAndShapeRenderer12.setLegendItemLabelGenerator(categorySeriesLabelGenerator59);
        java.awt.Stroke stroke63 = lineAndShapeRenderer12.lookupSeriesOutlineStroke((-10214656));
        lineAndShapeRenderer2.setSeriesOutlineStroke(8, stroke63);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNull(paint21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2 + "'", int24 == 2);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 128 + "'", int41 == 128);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator59);
        org.junit.Assert.assertNotNull(stroke63);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier1 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis5 = categoryPlot2.getRangeAxis();
        int int6 = categoryPlot2.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder7 = categoryPlot2.getRowRenderingOrder();
        java.awt.Stroke stroke8 = categoryPlot2.getRangeZeroBaselineStroke();
        categoryPlot2.setRangeGridlinesVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot11.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis14 = categoryPlot11.getRangeAxis();
        int int15 = categoryPlot11.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder16 = categoryPlot11.getRowRenderingOrder();
        java.awt.Stroke stroke17 = categoryPlot11.getRangeZeroBaselineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent18 = null;
        categoryPlot11.rendererChanged(rendererChangeEvent18);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation21 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot20.setRangeAxisLocation(axisLocation21, true);
        categoryPlot11.setDomainAxisLocation(axisLocation21);
        categoryPlot2.setDomainAxisLocation(axisLocation21, true);
        categoryPlot2.setBackgroundAlpha((float) 10);
        boolean boolean29 = defaultDrawingSupplier1.equals((java.lang.Object) 10);
        java.awt.Paint paint30 = defaultDrawingSupplier1.getNextOutlinePaint();
        lineAndShapeRenderer0.setBaseFillPaint(paint30, true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator33 = lineAndShapeRenderer0.getBaseURLGenerator();
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
        org.junit.Assert.assertNotNull(sortOrder7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(valueAxis14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 15 + "'", int15 == 15);
        org.junit.Assert.assertNotNull(sortOrder16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNull(categoryURLGenerator33);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = categoryAxis1.getTickLabelInsets();
        categoryAxis1.setCategoryLabelPositionOffset(0);
        categoryAxis1.setMinorTickMarksVisible(false);
        float float7 = categoryAxis1.getMinorTickMarkOutsideLength();
        boolean boolean8 = categoryAxis1.isVisible();
        categoryAxis1.setTickMarkOutsideLength((float) 10L);
        float float11 = categoryAxis1.getTickMarkOutsideLength();
        categoryAxis1.setMinorTickMarkOutsideLength(0.0f);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 2.0f + "'", float7 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 10.0f + "'", float11 == 10.0f);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier4 = categoryPlot0.getDrawingSupplier();
        double double5 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryPlot0.getAxisOffset();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(drawingSupplier4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets6);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE5;
        java.awt.Color color1 = java.awt.Color.white;
        boolean boolean2 = itemLabelAnchor0.equals((java.lang.Object) color1);
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor3);
        org.jfree.chart.text.TextAnchor textAnchor5 = itemLabelPosition4.getRotationAnchor();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke9 = lineAndShapeRenderer8.getBaseStroke();
        java.awt.Stroke stroke11 = lineAndShapeRenderer8.lookupSeriesStroke(10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator13 = null;
        lineAndShapeRenderer8.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator13);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = lineAndShapeRenderer8.getSeriesPositiveItemLabelPosition(0);
        java.awt.Stroke stroke17 = lineAndShapeRenderer8.getBaseStroke();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer21 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke22 = lineAndShapeRenderer21.getBaseStroke();
        java.awt.Stroke stroke24 = lineAndShapeRenderer21.lookupSeriesStroke(10);
        java.awt.Shape shape28 = lineAndShapeRenderer21.getItemShape((int) (short) 10, 100, true);
        lineAndShapeRenderer21.setBaseSeriesVisible(false);
        java.awt.Shape shape31 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity34 = new org.jfree.chart.entity.ChartEntity(shape31, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape35 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity38 = new org.jfree.chart.entity.ChartEntity(shape35, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape39 = chartEntity38.getArea();
        chartEntity34.setArea(shape39);
        lineAndShapeRenderer21.setBaseShape(shape39, true);
        java.lang.Boolean boolean44 = lineAndShapeRenderer21.getSeriesShapesVisible(1);
        java.awt.Font font45 = lineAndShapeRenderer21.getBaseItemLabelFont();
        java.awt.Font font47 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        lineAndShapeRenderer21.setSeriesItemLabelFont((int) (short) 100, font47);
        lineAndShapeRenderer8.setLegendTextFont(0, font47);
        boolean boolean50 = textAnchor5.equals((java.lang.Object) lineAndShapeRenderer8);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(itemLabelPosition16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNull(boolean44);
        org.junit.Assert.assertNotNull(font45);
        org.junit.Assert.assertNotNull(font47);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        java.awt.Shape shape4 = null;
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem6 = new org.jfree.chart.LegendItem("", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", shape4, (java.awt.Paint) color5);
        java.awt.Shape shape7 = legendItem6.getShape();
        java.awt.Paint paint8 = legendItem6.getLinePaint();
        legendItem6.setDescription("PlotOrientation.VERTICAL");
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(shape7);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Shape shape9 = lineAndShapeRenderer2.getItemShape((int) (short) 10, 100, true);
        lineAndShapeRenderer2.setBaseCreateEntities(true);
        java.awt.Paint paint15 = lineAndShapeRenderer2.getItemLabelPaint(0, (int) 'a', false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer18 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke19 = lineAndShapeRenderer18.getBaseStroke();
        java.awt.Stroke stroke21 = lineAndShapeRenderer18.lookupSeriesStroke(10);
        java.awt.Shape shape25 = lineAndShapeRenderer18.getItemShape((int) (short) 10, 100, true);
        lineAndShapeRenderer18.setBaseCreateEntities(true);
        lineAndShapeRenderer18.setAutoPopulateSeriesOutlinePaint(false);
        java.awt.Shape shape30 = lineAndShapeRenderer18.getBaseLegendShape();
        java.awt.Font font31 = lineAndShapeRenderer18.getBaseItemLabelFont();
        lineAndShapeRenderer2.setBaseItemLabelFont(font31);
        org.jfree.chart.renderer.RenderAttributes renderAttributes33 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color34 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        renderAttributes33.setDefaultFillPaint((java.awt.Paint) color34);
        java.awt.Stroke stroke37 = renderAttributes33.getSeriesStroke((int) ' ');
        java.awt.Stroke stroke38 = renderAttributes33.getDefaultStroke();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier39 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot40.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis43 = categoryPlot40.getRangeAxis();
        int int44 = categoryPlot40.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder45 = categoryPlot40.getRowRenderingOrder();
        java.awt.Stroke stroke46 = categoryPlot40.getRangeZeroBaselineStroke();
        categoryPlot40.setRangeGridlinesVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot49 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot49.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis52 = categoryPlot49.getRangeAxis();
        int int53 = categoryPlot49.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder54 = categoryPlot49.getRowRenderingOrder();
        java.awt.Stroke stroke55 = categoryPlot49.getRangeZeroBaselineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent56 = null;
        categoryPlot49.rendererChanged(rendererChangeEvent56);
        org.jfree.chart.plot.CategoryPlot categoryPlot58 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation59 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot58.setRangeAxisLocation(axisLocation59, true);
        categoryPlot49.setDomainAxisLocation(axisLocation59);
        categoryPlot40.setDomainAxisLocation(axisLocation59, true);
        categoryPlot40.setBackgroundAlpha((float) 10);
        boolean boolean67 = defaultDrawingSupplier39.equals((java.lang.Object) 10);
        java.awt.Paint paint68 = defaultDrawingSupplier39.getNextOutlinePaint();
        java.awt.Paint paint69 = defaultDrawingSupplier39.getNextPaint();
        java.awt.Paint paint70 = defaultDrawingSupplier39.getNextOutlinePaint();
        renderAttributes33.setDefaultPaint(paint70);
        lineAndShapeRenderer2.setBaseItemLabelPaint(paint70, false);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNull(shape30);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNull(stroke37);
        org.junit.Assert.assertNull(stroke38);
        org.junit.Assert.assertNull(valueAxis43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 15 + "'", int44 == 15);
        org.junit.Assert.assertNotNull(sortOrder45);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNull(valueAxis52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 15 + "'", int53 == 15);
        org.junit.Assert.assertNotNull(sortOrder54);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNotNull(axisLocation59);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(paint68);
        org.junit.Assert.assertNotNull(paint69);
        org.junit.Assert.assertNotNull(paint70);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        boolean boolean2 = booleanList0.equals((java.lang.Object) (short) 0);
        java.lang.Boolean boolean4 = booleanList0.getBoolean(2);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation6 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot5.setRangeAxisLocation(axisLocation6, true);
        boolean boolean9 = booleanList0.equals((java.lang.Object) categoryPlot5);
        org.jfree.chart.plot.Marker marker10 = null;
        try {
            categoryPlot5.addRangeMarker(marker10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE10;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis4 = categoryPlot1.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot1.zoomDomainAxes((double) 10.0f, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor10 = categoryPlot1.getDomainGridlinePosition();
        boolean boolean11 = itemLabelAnchor0.equals((java.lang.Object) categoryAnchor10);
        org.jfree.chart.text.TextAnchor textAnchor12 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor13 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor12, textAnchor13, (double) 10);
        org.jfree.chart.text.TextAnchor textAnchor16 = itemLabelPosition15.getRotationAnchor();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertNotNull(categoryAnchor10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(textAnchor12);
        org.junit.Assert.assertNotNull(textAnchor13);
        org.junit.Assert.assertNotNull(textAnchor16);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.clearSeriesStrokes(true);
        java.lang.Boolean boolean4 = lineAndShapeRenderer0.getSeriesVisibleInLegend(3);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator6 = lineAndShapeRenderer0.getSeriesURLGenerator((-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis11 = categoryPlot8.getRangeAxis();
        int int12 = categoryPlot8.getBackgroundImageAlignment();
        categoryPlot8.setDomainCrosshairColumnKey((java.lang.Comparable) (short) -1, true);
        org.jfree.chart.util.Layer layer17 = null;
        java.util.Collection collection18 = categoryPlot8.getRangeMarkers((int) (short) 0, layer17);
        categoryPlot8.setRangeMinorGridlinesVisible(true);
        java.util.List list21 = categoryPlot8.getCategories();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer24 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke25 = lineAndShapeRenderer24.getBaseStroke();
        java.awt.Stroke stroke27 = lineAndShapeRenderer24.lookupSeriesStroke(10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator29 = null;
        lineAndShapeRenderer24.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator29);
        lineAndShapeRenderer24.setSeriesVisible((int) (short) 100, (java.lang.Boolean) false, true);
        boolean boolean37 = lineAndShapeRenderer24.getItemShapeVisible((int) (short) 10, 3);
        lineAndShapeRenderer24.removeAnnotations();
        lineAndShapeRenderer24.setAutoPopulateSeriesShape(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot41.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis44 = categoryPlot41.getRangeAxis();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier45 = categoryPlot41.getDrawingSupplier();
        java.awt.Stroke stroke46 = categoryPlot41.getOutlineStroke();
        lineAndShapeRenderer24.setBaseOutlineStroke(stroke46, false);
        categoryPlot8.setRangeGridlineStroke(stroke46);
        lineAndShapeRenderer0.setSeriesOutlineStroke((int) (short) 100, stroke46);
        java.awt.Graphics2D graphics2D51 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot52 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot52.setRangeCrosshairLockedOnData(false);
        categoryPlot52.setDomainCrosshairRowKey((java.lang.Comparable) (short) 10);
        java.awt.Stroke stroke57 = categoryPlot52.getRangeZeroBaselineStroke();
        categoryPlot52.setRangeCrosshairValue((double) 100.0f);
        java.awt.geom.Rectangle2D rectangle2D60 = null;
        try {
            lineAndShapeRenderer0.drawBackground(graphics2D51, categoryPlot52, rectangle2D60);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertNull(categoryURLGenerator6);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 15 + "'", int12 == 15);
        org.junit.Assert.assertNull(collection18);
        org.junit.Assert.assertNull(list21);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNull(valueAxis44);
        org.junit.Assert.assertNotNull(drawingSupplier45);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(stroke57);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder5 = categoryPlot0.getRowRenderingOrder();
        java.awt.Stroke stroke6 = categoryPlot0.getRangeZeroBaselineStroke();
        int int7 = categoryPlot0.getCrosshairDatasetIndex();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke11 = lineAndShapeRenderer10.getBaseStroke();
        java.awt.Stroke stroke13 = lineAndShapeRenderer10.lookupSeriesStroke(10);
        lineAndShapeRenderer10.setAutoPopulateSeriesStroke(true);
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer10, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator19 = lineAndShapeRenderer10.getSeriesToolTipGenerator((int) (short) 1);
        lineAndShapeRenderer10.setItemLabelAnchorOffset(3.0d);
        java.lang.Boolean boolean23 = lineAndShapeRenderer10.getSeriesLinesVisible(0);
        lineAndShapeRenderer10.setBaseSeriesVisibleInLegend(false, false);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(sortOrder5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNull(categoryToolTipGenerator19);
        org.junit.Assert.assertNull(boolean23);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder5 = categoryPlot0.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        categoryPlot0.setDomainAxis(categoryAxis6);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(sortOrder5);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = lineAndShapeRenderer2.getBasePositiveItemLabelPosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot4.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = categoryPlot4.getDomainAxisEdge();
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot4.getDomainAxisLocation();
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        categoryPlot4.drawBackgroundImage(graphics2D9, rectangle2D10);
        java.awt.Paint paint12 = categoryPlot4.getNoDataMessagePaint();
        lineAndShapeRenderer2.setBaseItemLabelPaint(paint12);
        java.lang.Boolean boolean15 = lineAndShapeRenderer2.getSeriesShapesFilled(10);
        java.awt.Stroke stroke19 = lineAndShapeRenderer2.getItemStroke(100, (-10214656), true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator21 = null;
        lineAndShapeRenderer2.setSeriesItemLabelGenerator((int) (byte) 10, categoryItemLabelGenerator21);
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(boolean15);
        org.junit.Assert.assertNotNull(stroke19);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        boolean boolean9 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.axis.AxisLocation axisLocation11 = null;
        categoryPlot0.setDomainAxisLocation(255, axisLocation11);
        org.jfree.chart.util.SortOrder sortOrder13 = categoryPlot0.getRowRenderingOrder();
        categoryPlot0.setBackgroundImageAlignment(0);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = categoryPlot0.getRendererForDataset(categoryDataset16);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(sortOrder13);
        org.junit.Assert.assertNull(categoryItemRenderer17);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        int int2 = keyedObjects0.getIndex((java.lang.Comparable) (short) 100);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot3.getDomainAxisEdge();
        int int7 = categoryPlot3.getWeight();
        java.lang.Comparable comparable8 = categoryPlot3.getDomainCrosshairColumnKey();
        boolean boolean9 = categoryPlot3.canSelectByRegion();
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot3.getRangeAxisLocation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot3.zoomDomainAxes((double) (short) 100, plotRenderingInfo12, point2D13, false);
        boolean boolean16 = keyedObjects0.equals((java.lang.Object) false);
        try {
            java.lang.Object obj18 = keyedObjects0.getObject((java.lang.Comparable) 4);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: The key (4) is not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNull(comparable8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        java.lang.Comparable comparable9 = categoryPlot0.getDomainCrosshairColumnKey();
        boolean boolean10 = categoryPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = categoryPlot0.getAxisOffset();
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.axis.AxisSpace axisSpace13 = categoryPlot0.getFixedRangeAxisSpace();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNull(comparable9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNull(axisSpace13);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        java.awt.Color color1 = java.awt.Color.GRAY;
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator5 = new org.jfree.chart.util.DefaultShadowGenerator((int) (short) -1, color1, 0.0f, (int) (byte) -1, (double) 'a');
        int int6 = color1.getRed();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 128 + "'", int6 == 128);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        java.lang.Comparable comparable9 = categoryPlot0.getDomainCrosshairColumnKey();
        boolean boolean10 = categoryPlot0.isRangeCrosshairLockedOnData();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        categoryPlot0.setDomainCrosshairPaint((java.awt.Paint) color11);
        java.awt.Shape shape17 = null;
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem19 = new org.jfree.chart.LegendItem("", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", shape17, (java.awt.Paint) color18);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color18);
        int int21 = color18.getRed();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNull(comparable9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 255 + "'", int21 == 255);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier4 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape5 = defaultDrawingSupplier4.getNextShape();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot6.setRangeAxisLocation(axisLocation7, true);
        java.lang.Comparable comparable10 = categoryPlot6.getDomainCrosshairColumnKey();
        java.awt.Stroke stroke11 = categoryPlot6.getOutlineStroke();
        java.awt.Color color12 = java.awt.Color.red;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("rect", "hi!", "AxisLocation.BOTTOM_OR_LEFT", "GradientPaintTransformType.CENTER_HORIZONTAL", shape5, stroke11, (java.awt.Paint) color12);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNull(comparable10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(color12);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        java.awt.Paint paint5 = categoryPlot0.getNoDataMessagePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = categoryPlot0.getDomainAxisForDataset((int) 'a');
        java.awt.Paint paint8 = categoryPlot0.getDomainCrosshairPaint();
        categoryPlot0.setRangePannable(true);
        org.jfree.chart.plot.PlotOrientation plotOrientation11 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke15 = lineAndShapeRenderer14.getBaseStroke();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator17 = null;
        lineAndShapeRenderer14.setSeriesItemLabelGenerator((int) (byte) 1, categoryItemLabelGenerator17);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer22 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke23 = lineAndShapeRenderer22.getBaseStroke();
        java.awt.Paint paint25 = lineAndShapeRenderer22.getSeriesPaint(15);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer29 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke30 = lineAndShapeRenderer29.getBaseStroke();
        java.awt.Stroke stroke32 = lineAndShapeRenderer29.lookupSeriesStroke(10);
        java.awt.Paint paint33 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        lineAndShapeRenderer29.setBaseOutlinePaint(paint33);
        java.awt.Font font35 = lineAndShapeRenderer29.getBaseItemLabelFont();
        lineAndShapeRenderer22.setSeriesItemLabelFont((int) (byte) 1, font35);
        lineAndShapeRenderer14.setSeriesItemLabelFont((int) (short) 10, font35, true);
        boolean boolean39 = plotOrientation11.equals((java.lang.Object) (short) 10);
        categoryPlot0.setOrientation(plotOrientation11);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        boolean boolean42 = plotOrientation11.equals((java.lang.Object) rectangleInsets41);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(categoryAxis7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(plotOrientation11);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNull(paint25);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder5 = categoryPlot0.getRowRenderingOrder();
        java.awt.Stroke stroke6 = categoryPlot0.getRangeZeroBaselineStroke();
        int int7 = categoryPlot0.getCrosshairDatasetIndex();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke11 = lineAndShapeRenderer10.getBaseStroke();
        java.awt.Stroke stroke13 = lineAndShapeRenderer10.lookupSeriesStroke(10);
        lineAndShapeRenderer10.setAutoPopulateSeriesStroke(true);
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer10, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator19 = lineAndShapeRenderer10.getSeriesToolTipGenerator((int) (short) 1);
        lineAndShapeRenderer10.setItemLabelAnchorOffset(3.0d);
        java.awt.Stroke stroke23 = null;
        lineAndShapeRenderer10.setSeriesStroke(15, stroke23);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator26 = null;
        try {
            lineAndShapeRenderer10.setSeriesItemLabelGenerator((int) (short) -1, categoryItemLabelGenerator26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(sortOrder5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNull(categoryToolTipGenerator19);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Shape shape4 = renderAttributes1.getItemShape((int) (byte) 10, 15);
        java.awt.Color color6 = java.awt.Color.CYAN;
        renderAttributes1.setSeriesOutlinePaint((int) (byte) 0, (java.awt.Paint) color6);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis11 = categoryPlot8.getRangeAxis();
        int int12 = categoryPlot8.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder13 = categoryPlot8.getRowRenderingOrder();
        categoryPlot8.mapDatasetToRangeAxis((int) '#', (int) (byte) 10);
        boolean boolean17 = color6.equals((java.lang.Object) (byte) 10);
        org.jfree.chart.LegendItem legendItem18 = new org.jfree.chart.LegendItem("", (java.awt.Paint) color6);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer21 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke22 = lineAndShapeRenderer21.getBaseStroke();
        java.awt.Stroke stroke24 = lineAndShapeRenderer21.lookupSeriesStroke(10);
        java.awt.Shape shape28 = lineAndShapeRenderer21.getItemShape((int) (short) 10, 100, true);
        lineAndShapeRenderer21.setBaseSeriesVisible(false);
        lineAndShapeRenderer21.setSeriesShapesVisible((int) (short) 10, false);
        java.awt.Shape shape35 = lineAndShapeRenderer21.lookupSeriesShape(1);
        org.jfree.chart.entity.ChartEntity chartEntity38 = new org.jfree.chart.entity.ChartEntity(shape35, "", "rect");
        legendItem18.setLine(shape35);
        org.junit.Assert.assertNull(shape4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 15 + "'", int12 == 15);
        org.junit.Assert.assertNotNull(sortOrder13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(shape35);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Paint paint5 = null;
        lineAndShapeRenderer2.setSeriesOutlinePaint((int) '#', paint5, false);
        boolean boolean11 = lineAndShapeRenderer2.isItemLabelVisible((int) ' ', (int) (byte) -1, false);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        renderAttributes0.setDefaultFillPaint((java.awt.Paint) color1);
        java.awt.Shape shape5 = renderAttributes0.getItemShape((int) (byte) 100, (int) 'a');
        java.awt.Shape shape7 = null;
        renderAttributes0.setSeriesShape((int) (byte) 1, shape7);
        renderAttributes0.setDefaultCreateEntity((java.lang.Boolean) true);
        java.awt.Paint paint11 = renderAttributes0.getDefaultPaint();
        java.awt.Paint paint12 = renderAttributes0.getDefaultPaint();
        try {
            java.lang.Boolean boolean14 = renderAttributes0.getSeriesLabelVisible((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNull(shape5);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNull(paint12);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isRangeGridlinesVisible();
        categoryPlot0.clearDomainAxes();
        org.jfree.chart.plot.Marker marker3 = null;
        boolean boolean4 = categoryPlot0.removeDomainMarker(marker3);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Shape shape11 = null;
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", shape11, (java.awt.Paint) color12);
        int int14 = color12.getBlue();
        lineAndShapeRenderer2.setSeriesItemLabelPaint((int) (byte) 1, (java.awt.Paint) color12);
        lineAndShapeRenderer2.setSeriesShapesFilled(156, (java.lang.Boolean) true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 128 + "'", int14 == 128);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder5 = categoryPlot0.getRowRenderingOrder();
        categoryPlot0.setWeight((int) (short) 100);
        boolean boolean8 = categoryPlot0.isDomainCrosshairVisible();
        org.jfree.chart.util.ShadowGenerator shadowGenerator9 = categoryPlot0.getShadowGenerator();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryPlot0.getAxisOffset();
        org.jfree.chart.util.UnitType unitType11 = rectangleInsets10.getUnitType();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(sortOrder5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(shadowGenerator9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(unitType11);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        renderAttributes0.setDefaultFillPaint((java.awt.Paint) color1);
        java.awt.Shape shape5 = renderAttributes0.getItemShape((int) (byte) 100, (int) 'a');
        java.awt.Shape shape7 = null;
        renderAttributes0.setSeriesShape((int) (byte) 1, shape7);
        java.awt.Paint paint10 = renderAttributes0.getSeriesOutlinePaint((int) (byte) 1);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot11.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis14 = categoryPlot11.getRangeAxis();
        int int15 = categoryPlot11.getBackgroundImageAlignment();
        categoryPlot11.setDomainCrosshairColumnKey((java.lang.Comparable) (short) -1, true);
        java.awt.Stroke stroke19 = categoryPlot11.getDomainGridlineStroke();
        renderAttributes0.setDefaultStroke(stroke19);
        java.awt.Paint paint22 = renderAttributes0.getSeriesPaint((int) '#');
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNull(shape5);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNull(valueAxis14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 15 + "'", int15 == 15);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(paint22);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot0.setRangeAxisLocation(axisLocation1, true);
        org.jfree.chart.axis.ValueAxis valueAxis5 = categoryPlot0.getRangeAxis((int) '#');
        categoryPlot0.clearDomainAxes();
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        categoryPlot0.setRangeAxis(156, valueAxis8, false);
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNull(valueAxis5);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        categoryPlot0.setDomainCrosshairColumnKey((java.lang.Comparable) (short) -1, true);
        org.jfree.chart.util.Layer layer9 = null;
        java.util.Collection collection10 = categoryPlot0.getRangeMarkers((int) (short) 0, layer9);
        categoryPlot0.setRangeCrosshairLockedOnData(false);
        boolean boolean13 = categoryPlot0.isDomainCrosshairVisible();
        categoryPlot0.clearRangeMarkers((int) (byte) 0);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNull(collection10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Shape shape9 = lineAndShapeRenderer2.getItemShape((int) (short) 10, 100, true);
        lineAndShapeRenderer2.setBaseCreateEntities(true);
        lineAndShapeRenderer2.setAutoPopulateSeriesOutlinePaint(false);
        java.awt.Shape shape14 = lineAndShapeRenderer2.getBaseLegendShape();
        lineAndShapeRenderer2.setAutoPopulateSeriesFillPaint(true);
        java.awt.Shape shape17 = lineAndShapeRenderer2.getBaseShape();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNull(shape14);
        org.junit.Assert.assertNotNull(shape17);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        java.awt.Shape shape4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        int int9 = categoryPlot5.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot5.getRowRenderingOrder();
        java.awt.Stroke stroke11 = categoryPlot5.getRangeZeroBaselineStroke();
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("", "", "hi!", "", shape4, stroke11, paint12);
        legendItem13.setDescription("");
        int int16 = legendItem13.getDatasetIndex();
        java.lang.String str17 = legendItem13.getLabel();
        java.awt.Paint paint18 = legendItem13.getOutlinePaint();
        int int19 = legendItem13.getDatasetIndex();
        java.lang.String str20 = legendItem13.getLabel();
        int int21 = legendItem13.getDatasetIndex();
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent9 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot0);
        org.jfree.chart.JFreeChart jFreeChart10 = null;
        plotChangeEvent9.setChart(jFreeChart10);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        plotChangeEvent9.setType(chartChangeEventType12);
        boolean boolean15 = chartChangeEventType12.equals((java.lang.Object) (byte) 10);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot16.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis19 = categoryPlot16.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        categoryPlot16.zoomDomainAxes((double) 10.0f, plotRenderingInfo21, point2D22, false);
        java.lang.Comparable comparable25 = categoryPlot16.getDomainCrosshairColumnKey();
        boolean boolean26 = categoryPlot16.isRangeCrosshairLockedOnData();
        boolean boolean27 = chartChangeEventType12.equals((java.lang.Object) categoryPlot16);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(chartChangeEventType12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(valueAxis19);
        org.junit.Assert.assertNull(comparable25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = categoryAxis1.getTickLabelInsets();
        categoryAxis1.setCategoryLabelPositionOffset(0);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions5 = categoryAxis1.getCategoryLabelPositions();
        categoryAxis1.configure();
        java.awt.Shape shape11 = null;
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", shape11, (java.awt.Paint) color12);
        java.awt.color.ColorSpace colorSpace14 = color12.getColorSpace();
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_CYAN;
        boolean boolean16 = color12.equals((java.lang.Object) color15);
        categoryAxis1.setTickLabelPaint((java.awt.Paint) color15);
        org.jfree.chart.plot.Plot plot18 = categoryAxis1.getPlot();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(categoryLabelPositions5);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(colorSpace14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(plot18);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge();
        org.jfree.chart.axis.AxisLocation axisLocation4 = categoryPlot0.getDomainAxisLocation();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = categoryPlot0.getAxisOffset();
        org.jfree.chart.plot.Marker marker7 = null;
        org.jfree.chart.util.Layer layer8 = null;
        try {
            boolean boolean9 = categoryPlot0.removeRangeMarker((int) (short) -1, marker7, layer8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        renderAttributes0.setDefaultFillPaint((java.awt.Paint) color1);
        java.awt.Shape shape3 = renderAttributes0.getDefaultShape();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNull(shape3);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        categoryPlot0.setRangeCrosshairVisible(false);
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder6 = categoryPlot0.getDatasetRenderingOrder();
        java.awt.Color color7 = java.awt.Color.RED;
        boolean boolean8 = datasetRenderingOrder6.equals((java.lang.Object) color7);
        org.junit.Assert.assertNotNull(datasetRenderingOrder6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        lineAndShapeRenderer2.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator7);
        lineAndShapeRenderer2.setSeriesVisible((int) (short) 100, (java.lang.Boolean) false, true);
        boolean boolean15 = lineAndShapeRenderer2.getItemShapeVisible((int) (short) 10, 3);
        lineAndShapeRenderer2.setSeriesVisibleInLegend(100, (java.lang.Boolean) true, true);
        java.awt.Stroke stroke21 = lineAndShapeRenderer2.lookupSeriesOutlineStroke((-128));
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(stroke21);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        java.awt.Color color2 = java.awt.Color.yellow;
        java.awt.color.ColorSpace colorSpace3 = color2.getColorSpace();
        int int4 = color2.getTransparency();
        paintList0.setPaint(0, (java.awt.Paint) color2);
        java.awt.Shape shape10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot11.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis14 = categoryPlot11.getRangeAxis();
        int int15 = categoryPlot11.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder16 = categoryPlot11.getRowRenderingOrder();
        java.awt.Stroke stroke17 = categoryPlot11.getRangeZeroBaselineStroke();
        java.awt.Paint paint18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem19 = new org.jfree.chart.LegendItem("", "", "hi!", "", shape10, stroke17, paint18);
        boolean boolean20 = paintList0.equals((java.lang.Object) stroke17);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(colorSpace3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNull(valueAxis14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 15 + "'", int15 == 15);
        org.junit.Assert.assertNotNull(sortOrder16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) 1, (float) (byte) 10, (float) 0);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Shape shape9 = lineAndShapeRenderer2.getItemShape((int) (short) 10, 100, true);
        lineAndShapeRenderer2.setBaseSeriesVisible(false);
        java.awt.Shape shape12 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity15 = new org.jfree.chart.entity.ChartEntity(shape12, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape16 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity19 = new org.jfree.chart.entity.ChartEntity(shape16, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape20 = chartEntity19.getArea();
        chartEntity15.setArea(shape20);
        lineAndShapeRenderer2.setBaseShape(shape20, true);
        try {
            lineAndShapeRenderer2.setItemMargin((double) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 0.0 <= margin < 1.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(shape20);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.chart.renderer.RenderAttributes renderAttributes4 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        renderAttributes4.setDefaultFillPaint((java.awt.Paint) color5);
        java.awt.Shape shape9 = renderAttributes4.getItemShape((int) (byte) 100, (int) 'a');
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        renderAttributes4.setDefaultShape(shape10);
        java.awt.Paint paint12 = null;
        java.awt.Stroke stroke13 = null;
        java.awt.Color color17 = java.awt.Color.getHSBColor((float) 100L, 0.0f, 100.0f);
        java.awt.Color color18 = java.awt.Color.yellow;
        java.awt.color.ColorSpace colorSpace19 = color18.getColorSpace();
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        java.awt.Color color21 = java.awt.Color.yellow;
        java.awt.color.ColorSpace colorSpace22 = color21.getColorSpace();
        java.awt.Color color26 = java.awt.Color.getHSBColor((float) (short) 1, (float) 100, 0.0f);
        float[] floatArray33 = new float[] { (byte) 10, (byte) 1, 1.0f, (byte) 0, 10, (byte) 100 };
        float[] floatArray34 = color26.getRGBComponents(floatArray33);
        float[] floatArray35 = color20.getColorComponents(colorSpace22, floatArray33);
        float[] floatArray36 = color17.getComponents(colorSpace19, floatArray35);
        try {
            org.jfree.chart.LegendItem legendItem37 = new org.jfree.chart.LegendItem("ItemLabelAnchor.OUTSIDE3", "GradientPaintTransformType.CENTER_HORIZONTAL", "hi!", "TextAnchor.BASELINE_LEFT", shape10, paint12, stroke13, (java.awt.Paint) color17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'fillPaint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(shape9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(colorSpace19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(colorSpace22);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertNotNull(floatArray34);
        org.junit.Assert.assertNotNull(floatArray35);
        org.junit.Assert.assertNotNull(floatArray36);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape2, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape6 = chartEntity5.getArea();
        java.awt.Shape shape7 = chartEntity5.getArea();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot8.getDomainAxisEdge();
        int int12 = categoryPlot8.getWeight();
        java.lang.Comparable comparable13 = categoryPlot8.getDomainCrosshairColumnKey();
        boolean boolean14 = categoryPlot8.canSelectByRegion();
        org.jfree.chart.axis.AxisLocation axisLocation15 = categoryPlot8.getRangeAxisLocation();
        org.jfree.chart.entity.PlotEntity plotEntity18 = new org.jfree.chart.entity.PlotEntity(shape7, (org.jfree.chart.plot.Plot) categoryPlot8, "ItemLabelAnchor.OUTSIDE1", "java.awt.Color[r=0,g=0,b=0]");
        shapeList0.setShape(156, shape7);
        java.awt.Shape shape21 = shapeList0.getShape((int) (byte) 1);
        java.lang.Object obj22 = shapeList0.clone();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNull(comparable13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNull(shape21);
        org.junit.Assert.assertNotNull(obj22);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        categoryPlot0.setDomainCrosshairColumnKey((java.lang.Comparable) (short) -1, true);
        org.jfree.chart.util.Layer layer9 = null;
        java.util.Collection collection10 = categoryPlot0.getRangeMarkers((int) (short) 0, layer9);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot11.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis14 = categoryPlot11.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        categoryPlot11.zoomDomainAxes((double) 10.0f, plotRenderingInfo16, point2D17, false);
        java.lang.Comparable comparable20 = categoryPlot11.getDomainCrosshairColumnKey();
        boolean boolean21 = categoryPlot11.isRangeCrosshairLockedOnData();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = categoryPlot11.getAxisOffset();
        double double23 = rectangleInsets22.getLeft();
        categoryPlot0.setAxisOffset(rectangleInsets22);
        double double26 = rectangleInsets22.calculateRightOutset((double) (byte) 1);
        double double28 = rectangleInsets22.calculateBottomOutset((double) 128);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNull(collection10);
        org.junit.Assert.assertNull(valueAxis14);
        org.junit.Assert.assertNull(comparable20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 4.0d + "'", double23 == 4.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 4.0d + "'", double26 == 4.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 4.0d + "'", double28 == 4.0d);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("");
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        java.awt.Color color0 = java.awt.Color.ORANGE;
        float[] floatArray1 = null;
        float[] floatArray2 = color0.getRGBComponents(floatArray1);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray2);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE12;
        java.lang.Object obj1 = null;
        boolean boolean2 = itemLabelAnchor0.equals(obj1);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        double double2 = categoryAxis1.getLabelAngle();
        categoryAxis1.setTickLabelsVisible(true);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = categoryAxis12.getTickLabelInsets();
        categoryAxis12.setCategoryLabelPositionOffset(0);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot16.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis19 = categoryPlot16.getRangeAxis();
        int int20 = categoryPlot16.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder21 = categoryPlot16.getRowRenderingOrder();
        java.awt.Stroke stroke22 = categoryPlot16.getRangeZeroBaselineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent23 = null;
        categoryPlot16.rendererChanged(rendererChangeEvent23);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation26 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot25.setRangeAxisLocation(axisLocation26, true);
        categoryPlot16.setDomainAxisLocation(axisLocation26);
        categoryPlot16.setCrosshairDatasetIndex((int) (short) 1);
        categoryAxis12.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot16);
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = categoryAxis12.getLabelInsets();
        java.awt.Graphics2D graphics2D34 = null;
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = categoryAxis38.getTickLabelInsets();
        categoryAxis38.setCategoryLabelPositionOffset(0);
        categoryAxis38.setMinorTickMarksVisible(false);
        float float44 = categoryAxis38.getMinorTickMarkOutsideLength();
        boolean boolean45 = categoryAxis38.isVisible();
        java.awt.Graphics2D graphics2D46 = null;
        java.awt.geom.Rectangle2D rectangle2D48 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot49 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean50 = categoryPlot49.isRangeGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge52 = categoryPlot49.getRangeAxisEdge((int) (byte) -1);
        org.jfree.chart.axis.AxisState axisState53 = null;
        categoryAxis38.drawTickMarks(graphics2D46, (double) 1L, rectangle2D48, rectangleEdge52, axisState53);
        org.jfree.chart.axis.AxisState axisState55 = null;
        categoryAxis12.drawTickMarks(graphics2D34, (double) 2, rectangle2D36, rectangleEdge52, axisState55);
        try {
            double double57 = categoryAxis1.getCategorySeriesMiddle((int) (byte) 10, (-10214656), (int) (short) 1, (int) 'a', (double) 10.0f, rectangle2D10, rectangleEdge52);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNull(valueAxis19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 15 + "'", int20 == 15);
        org.junit.Assert.assertNotNull(sortOrder21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertNotNull(rectangleInsets39);
        org.junit.Assert.assertTrue("'" + float44 + "' != '" + 2.0f + "'", float44 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(rectangleEdge52);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder5 = categoryPlot0.getRowRenderingOrder();
        java.awt.Stroke stroke6 = categoryPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent7 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent7);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot9.setRangeAxisLocation(axisLocation10, true);
        categoryPlot0.setDomainAxisLocation(axisLocation10);
        org.jfree.chart.event.PlotChangeListener plotChangeListener14 = null;
        categoryPlot0.removeChangeListener(plotChangeListener14);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(sortOrder5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(axisLocation10);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.util.Layer layer5 = null;
        java.util.Collection collection6 = categoryPlot0.getRangeMarkers(10, layer5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot7.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis10 = categoryPlot7.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot7.zoomDomainAxes((double) 10.0f, plotRenderingInfo12, point2D13, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor16 = categoryPlot7.getDomainGridlinePosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot17.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis20 = categoryPlot17.getRangeAxis();
        int int21 = categoryPlot17.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot17.getRowRenderingOrder();
        java.awt.Stroke stroke23 = categoryPlot17.getRangeZeroBaselineStroke();
        categoryPlot7.setRangeMinorGridlineStroke(stroke23);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder25 = categoryPlot7.getDatasetRenderingOrder();
        categoryPlot0.setDatasetRenderingOrder(datasetRenderingOrder25);
        org.jfree.chart.LegendItemCollection legendItemCollection27 = null;
        categoryPlot0.setFixedLegendItems(legendItemCollection27);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNull(collection6);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertNotNull(categoryAnchor16);
        org.junit.Assert.assertNull(valueAxis20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 15 + "'", int21 == 15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(datasetRenderingOrder25);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder5 = categoryPlot0.getRowRenderingOrder();
        java.awt.Stroke stroke6 = categoryPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent7 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent7);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot9.setRangeAxisLocation(axisLocation10, true);
        categoryPlot0.setDomainAxisLocation(axisLocation10);
        categoryPlot0.setCrosshairDatasetIndex((int) (short) 1);
        org.jfree.data.category.CategoryDataset categoryDataset16 = categoryPlot0.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = categoryPlot0.getAxisOffset();
        double double19 = rectangleInsets17.extendWidth(0.0d);
        double double21 = rectangleInsets17.trimWidth((double) 100L);
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        boolean boolean23 = rectangleInsets17.equals((java.lang.Object) color22);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(sortOrder5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNull(categoryDataset16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 8.0d + "'", double19 == 8.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 92.0d + "'", double21 == 92.0d);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis4 = categoryPlot1.getRangeAxis();
        int int5 = categoryPlot1.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder6 = categoryPlot1.getRowRenderingOrder();
        java.awt.Stroke stroke7 = categoryPlot1.getRangeZeroBaselineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent8 = null;
        categoryPlot1.rendererChanged(rendererChangeEvent8);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation11 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot10.setRangeAxisLocation(axisLocation11, true);
        categoryPlot1.setDomainAxisLocation(axisLocation11);
        categoryPlot1.setCrosshairDatasetIndex((int) (short) 1);
        org.jfree.data.category.CategoryDataset categoryDataset17 = categoryPlot1.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = categoryPlot1.getAxisOffset();
        org.jfree.chart.util.SortOrder sortOrder19 = categoryPlot1.getRowRenderingOrder();
        keyedObjects0.sortByObjects(sortOrder19);
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean22 = categoryPlot21.isRangeGridlinesVisible();
        categoryPlot21.clearDomainAxes();
        boolean boolean24 = keyedObjects0.equals((java.lang.Object) categoryPlot21);
        java.lang.Comparable comparable25 = null;
        try {
            java.lang.Object obj26 = keyedObjects0.getObject(comparable25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
        org.junit.Assert.assertNotNull(sortOrder6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNull(categoryDataset17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(sortOrder19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        java.awt.Shape shape4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        int int9 = categoryPlot5.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot5.getRowRenderingOrder();
        java.awt.Stroke stroke11 = categoryPlot5.getRangeZeroBaselineStroke();
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("", "", "hi!", "", shape4, stroke11, paint12);
        legendItem13.setDescription("");
        int int16 = legendItem13.getDatasetIndex();
        java.lang.String str17 = legendItem13.getLabel();
        java.lang.String str18 = legendItem13.getLabel();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset19 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo20 = new org.jfree.chart.event.DatasetChangeInfo();
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent21 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object) legendItem13, (org.jfree.data.general.Dataset) defaultCategoryDataset19, datasetChangeInfo20);
        java.lang.String str22 = legendItem13.getDescription();
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("AxisLocation.BOTTOM_OR_LEFT");
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis5 = categoryPlot2.getRangeAxis();
        int int6 = categoryPlot2.getBackgroundImageAlignment();
        categoryPlot2.setDomainCrosshairColumnKey((java.lang.Comparable) (short) -1, true);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot2.getRangeMarkers((int) (short) 0, layer11);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot13.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis16 = categoryPlot13.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        categoryPlot13.zoomDomainAxes((double) 10.0f, plotRenderingInfo18, point2D19, false);
        java.lang.Comparable comparable22 = categoryPlot13.getDomainCrosshairColumnKey();
        boolean boolean23 = categoryPlot13.isRangeCrosshairLockedOnData();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = categoryPlot13.getAxisOffset();
        double double25 = rectangleInsets24.getLeft();
        categoryPlot2.setAxisOffset(rectangleInsets24);
        boolean boolean27 = standardCategorySeriesLabelGenerator1.equals((java.lang.Object) rectangleInsets24);
        java.awt.Color color31 = java.awt.Color.getHSBColor((float) 100L, 0.0f, 100.0f);
        java.awt.Color color32 = java.awt.Color.yellow;
        java.awt.color.ColorSpace colorSpace33 = color32.getColorSpace();
        java.awt.Color color34 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        java.awt.Color color35 = java.awt.Color.yellow;
        java.awt.color.ColorSpace colorSpace36 = color35.getColorSpace();
        java.awt.Color color40 = java.awt.Color.getHSBColor((float) (short) 1, (float) 100, 0.0f);
        float[] floatArray47 = new float[] { (byte) 10, (byte) 1, 1.0f, (byte) 0, 10, (byte) 100 };
        float[] floatArray48 = color40.getRGBComponents(floatArray47);
        float[] floatArray49 = color34.getColorComponents(colorSpace36, floatArray47);
        float[] floatArray50 = color31.getComponents(colorSpace33, floatArray49);
        boolean boolean51 = standardCategorySeriesLabelGenerator1.equals((java.lang.Object) color31);
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNull(valueAxis16);
        org.junit.Assert.assertNull(comparable22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 4.0d + "'", double25 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(colorSpace33);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(colorSpace36);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(floatArray47);
        org.junit.Assert.assertNotNull(floatArray48);
        org.junit.Assert.assertNotNull(floatArray49);
        org.junit.Assert.assertNotNull(floatArray50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setBaseItemLabelsVisible(true, false);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = lineAndShapeRenderer2.getBasePositiveItemLabelPosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot4.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = categoryPlot4.getDomainAxisEdge();
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot4.getDomainAxisLocation();
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        categoryPlot4.drawBackgroundImage(graphics2D9, rectangle2D10);
        java.awt.Paint paint12 = categoryPlot4.getNoDataMessagePaint();
        lineAndShapeRenderer2.setBaseItemLabelPaint(paint12);
        java.lang.Boolean boolean15 = lineAndShapeRenderer2.getSeriesShapesFilled(10);
        java.awt.Shape shape16 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity19 = new org.jfree.chart.entity.ChartEntity(shape16, "ChartChangeEventType.GENERAL", "");
        lineAndShapeRenderer2.setBaseShape(shape16, false);
        lineAndShapeRenderer2.setBaseLinesVisible(false);
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(boolean15);
        org.junit.Assert.assertNotNull(shape16);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        java.awt.Shape shape4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        int int9 = categoryPlot5.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot5.getRowRenderingOrder();
        java.awt.Stroke stroke11 = categoryPlot5.getRangeZeroBaselineStroke();
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("", "", "hi!", "", shape4, stroke11, paint12);
        legendItem13.setDescription("");
        int int16 = legendItem13.getDatasetIndex();
        java.lang.String str17 = legendItem13.getLabel();
        java.awt.Paint paint18 = legendItem13.getOutlinePaint();
        int int19 = legendItem13.getSeriesIndex();
        java.awt.Paint paint20 = legendItem13.getFillPaint();
        boolean boolean21 = legendItem13.isShapeVisible();
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape0, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape4 = chartEntity3.getArea();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot5.zoomDomainAxes((double) 10.0f, plotRenderingInfo10, point2D11, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor14 = categoryPlot5.getDomainGridlinePosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot15.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis18 = categoryPlot15.getRangeAxis();
        int int19 = categoryPlot15.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder20 = categoryPlot15.getRowRenderingOrder();
        java.awt.Stroke stroke21 = categoryPlot15.getRangeZeroBaselineStroke();
        categoryPlot5.setRangeMinorGridlineStroke(stroke21);
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = categoryPlot5.getDomainAxis(100);
        boolean boolean25 = categoryPlot5.isNotify();
        org.jfree.chart.entity.PlotEntity plotEntity27 = new org.jfree.chart.entity.PlotEntity(shape4, (org.jfree.chart.plot.Plot) categoryPlot5, "ItemLabelAnchor.OUTSIDE1");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset30 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity33 = new org.jfree.chart.entity.CategoryItemEntity(shape4, "PlotOrientation.VERTICAL", "PlotOrientation.VERTICAL", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset30, (java.lang.Comparable) 10, (java.lang.Comparable) 'a');
        java.awt.Shape shape34 = categoryItemEntity33.getArea();
        java.lang.String str35 = categoryItemEntity33.toString();
        java.lang.String str36 = categoryItemEntity33.toString();
        java.awt.Color color37 = java.awt.Color.pink;
        boolean boolean38 = categoryItemEntity33.equals((java.lang.Object) color37);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertNotNull(categoryAnchor14);
        org.junit.Assert.assertNull(valueAxis18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 15 + "'", int19 == 15);
        org.junit.Assert.assertNotNull(sortOrder20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNull(categoryAxis24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent9 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot0);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer12 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke13 = lineAndShapeRenderer12.getBaseStroke();
        categoryPlot0.setRangeMinorGridlineStroke(stroke13);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor15 = org.jfree.chart.axis.CategoryAnchor.START;
        categoryPlot0.setDomainGridlinePosition(categoryAnchor15);
        int int17 = categoryPlot0.getDomainAxisCount();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(categoryAnchor15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = categoryAxis1.getTickLabelInsets();
        categoryAxis1.setCategoryLabelPositionOffset(0);
        categoryAxis1.setMinorTickMarksVisible(false);
        float float7 = categoryAxis1.getMinorTickMarkOutsideLength();
        boolean boolean8 = categoryAxis1.isVisible();
        categoryAxis1.setTickMarkOutsideLength((float) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot11.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis14 = categoryPlot11.getRangeAxis();
        int int15 = categoryPlot11.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder16 = categoryPlot11.getRowRenderingOrder();
        categoryPlot11.setWeight((int) (short) 100);
        boolean boolean19 = categoryPlot11.isDomainCrosshairVisible();
        org.jfree.chart.axis.AxisLocation axisLocation20 = categoryPlot11.getRangeAxisLocation();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot11);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 2.0f + "'", float7 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(valueAxis14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 15 + "'", int15 == 15);
        org.junit.Assert.assertNotNull(sortOrder16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(axisLocation20);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        java.lang.Comparable comparable9 = categoryPlot0.getDomainCrosshairColumnKey();
        boolean boolean10 = categoryPlot0.isRangeCrosshairLockedOnData();
        categoryPlot0.setCrosshairDatasetIndex((int) (byte) 10, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = categoryPlot0.getInsets();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D18 = rectangleInsets14.createInsetRectangle(rectangle2D15, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNull(comparable9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(rectangleInsets14);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder5 = categoryPlot0.getRowRenderingOrder();
        java.awt.Stroke stroke6 = categoryPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = categoryPlot0.getInsets();
        double double8 = rectangleInsets7.getRight();
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        try {
            rectangleInsets7.trim(rectangle2D9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(sortOrder5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 8.0d + "'", double8 == 8.0d);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getMinimumBarLength();
        java.awt.Paint paint5 = barRenderer0.getItemPaint(0, 15, true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator6 = barRenderer0.getBaseURLGenerator();
        barRenderer0.setBase((double) '4');
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer9 = barRenderer0.getGradientPaintTransformer();
        java.awt.Shape shape13 = barRenderer0.getItemShape((int) (short) 100, (int) (byte) 0, false);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(categoryURLGenerator6);
        org.junit.Assert.assertNotNull(gradientPaintTransformer9);
        org.junit.Assert.assertNotNull(shape13);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.chart.renderer.category.BarRenderer.setDefaultShadowsVisible(true);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = null;
        lineAndShapeRenderer2.setSeriesItemLabelGenerator((int) (byte) 1, categoryItemLabelGenerator5);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke11 = lineAndShapeRenderer10.getBaseStroke();
        java.awt.Paint paint13 = lineAndShapeRenderer10.getSeriesPaint(15);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer17 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke18 = lineAndShapeRenderer17.getBaseStroke();
        java.awt.Stroke stroke20 = lineAndShapeRenderer17.lookupSeriesStroke(10);
        java.awt.Paint paint21 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        lineAndShapeRenderer17.setBaseOutlinePaint(paint21);
        java.awt.Font font23 = lineAndShapeRenderer17.getBaseItemLabelFont();
        lineAndShapeRenderer10.setSeriesItemLabelFont((int) (byte) 1, font23);
        lineAndShapeRenderer2.setSeriesItemLabelFont((int) (short) 10, font23, true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer30 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke31 = lineAndShapeRenderer30.getBaseStroke();
        java.awt.Stroke stroke33 = lineAndShapeRenderer30.lookupSeriesStroke(10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator35 = null;
        lineAndShapeRenderer30.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator35);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition38 = lineAndShapeRenderer30.getSeriesPositiveItemLabelPosition(0);
        lineAndShapeRenderer30.setBaseShapesFilled(false);
        lineAndShapeRenderer30.setSeriesVisibleInLegend((int) (short) 10, (java.lang.Boolean) false);
        java.awt.Stroke stroke45 = lineAndShapeRenderer30.lookupSeriesOutlineStroke((-1));
        lineAndShapeRenderer2.setSeriesStroke((int) (short) 10, stroke45, false);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor48 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE5;
        java.awt.Color color49 = java.awt.Color.white;
        boolean boolean50 = itemLabelAnchor48.equals((java.lang.Object) color49);
        org.jfree.chart.text.TextAnchor textAnchor51 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition52 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor48, textAnchor51);
        org.jfree.chart.text.TextAnchor textAnchor53 = itemLabelPosition52.getRotationAnchor();
        lineAndShapeRenderer2.setBasePositiveItemLabelPosition(itemLabelPosition52);
        org.jfree.chart.plot.CategoryPlot categoryPlot55 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean56 = categoryPlot55.isRangeGridlinesVisible();
        categoryPlot55.clearDomainAxes();
        java.awt.Color color58 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        categoryPlot55.setOutlinePaint((java.awt.Paint) color58);
        lineAndShapeRenderer2.setPlot(categoryPlot55);
        try {
            categoryPlot55.mapDatasetToRangeAxis((int) (short) -1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'index' >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(itemLabelPosition38);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(itemLabelAnchor48);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(textAnchor51);
        org.junit.Assert.assertNotNull(textAnchor53);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertNotNull(color58);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextOutlinePaint();
        java.awt.Paint paint2 = defaultDrawingSupplier0.getNextOutlinePaint();
        java.awt.Paint paint3 = defaultDrawingSupplier0.getNextOutlinePaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator0 = new org.jfree.chart.util.DefaultShadowGenerator();
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = categoryAxis3.getTickLabelInsets();
        categoryAxis3.setCategoryLabelPositionOffset(0);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions7 = categoryAxis3.getCategoryLabelPositions();
        categoryAxis1.setCategoryLabelPositions(categoryLabelPositions7);
        java.awt.Paint paint9 = categoryAxis1.getAxisLinePaint();
        boolean boolean10 = categoryAxis1.isTickMarksVisible();
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(categoryLabelPositions7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        org.jfree.chart.axis.ValueAxis valueAxis9 = categoryPlot0.getRangeAxis();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNull(valueAxis9);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getMinimumBarLength();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = null;
        barRenderer0.setSeriesURLGenerator((int) (short) 0, categoryURLGenerator3);
        boolean boolean6 = barRenderer0.isSeriesVisibleInLegend(0);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = barRenderer0.getURLGenerator(255, 3, true);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(categoryURLGenerator10);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Paint paint5 = lineAndShapeRenderer2.getSeriesPaint(15);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke10 = lineAndShapeRenderer9.getBaseStroke();
        java.awt.Stroke stroke12 = lineAndShapeRenderer9.lookupSeriesStroke(10);
        java.awt.Paint paint13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        lineAndShapeRenderer9.setBaseOutlinePaint(paint13);
        java.awt.Font font15 = lineAndShapeRenderer9.getBaseItemLabelFont();
        lineAndShapeRenderer2.setSeriesItemLabelFont((int) (byte) 1, font15);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent17 = null;
        lineAndShapeRenderer2.notifyListeners(rendererChangeEvent17);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(font15);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder5 = categoryPlot0.getRowRenderingOrder();
        java.awt.Stroke stroke6 = categoryPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = categoryPlot0.getInsets();
        java.lang.Object obj8 = categoryPlot0.clone();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot0.zoomRangeAxes((double) 2, plotRenderingInfo10, point2D11, false);
        categoryPlot0.clearRangeMarkers();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(sortOrder5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Shape shape9 = lineAndShapeRenderer2.getItemShape((int) (short) 10, 100, true);
        lineAndShapeRenderer2.setBaseSeriesVisible(false);
        java.awt.Shape shape12 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity15 = new org.jfree.chart.entity.ChartEntity(shape12, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape16 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity19 = new org.jfree.chart.entity.ChartEntity(shape16, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape20 = chartEntity19.getArea();
        chartEntity15.setArea(shape20);
        lineAndShapeRenderer2.setBaseShape(shape20, true);
        java.lang.Boolean boolean25 = lineAndShapeRenderer2.getSeriesShapesVisible(1);
        java.awt.Font font26 = lineAndShapeRenderer2.getBaseItemLabelFont();
        lineAndShapeRenderer2.setSeriesShapesVisible(1, true);
        lineAndShapeRenderer2.setDataBoundsIncludesVisibleSeriesOnly(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator32 = lineAndShapeRenderer2.getBaseURLGenerator();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNull(boolean25);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNull(categoryURLGenerator32);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Shape shape9 = lineAndShapeRenderer2.getItemShape((int) (short) 10, 100, true);
        lineAndShapeRenderer2.setBaseSeriesVisible(false);
        java.awt.Shape shape12 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity15 = new org.jfree.chart.entity.ChartEntity(shape12, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape16 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity19 = new org.jfree.chart.entity.ChartEntity(shape16, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape20 = chartEntity19.getArea();
        chartEntity15.setArea(shape20);
        lineAndShapeRenderer2.setBaseShape(shape20, true);
        java.lang.Boolean boolean25 = lineAndShapeRenderer2.getSeriesShapesVisible(1);
        java.awt.Font font26 = lineAndShapeRenderer2.getBaseItemLabelFont();
        lineAndShapeRenderer2.setSeriesShapesVisible(1, true);
        java.awt.Graphics2D graphics2D30 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = categoryAxis33.getTickLabelInsets();
        categoryAxis33.setCategoryLabelPositionOffset(0);
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        org.jfree.chart.util.Layer layer38 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = null;
        try {
            lineAndShapeRenderer2.drawAnnotations(graphics2D30, rectangle2D31, categoryAxis33, valueAxis37, layer38, plotRenderingInfo39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNull(boolean25);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(rectangleInsets34);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        try {
            java.awt.Color color1 = java.awt.Color.decode("AxisLocation.BOTTOM_OR_LEFT");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"AxisLocation.BOTTOM_OR_LEFT\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Shape shape9 = lineAndShapeRenderer2.getItemShape((int) (short) 10, 100, true);
        lineAndShapeRenderer2.setBaseSeriesVisible(false);
        java.awt.Shape shape12 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity15 = new org.jfree.chart.entity.ChartEntity(shape12, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape16 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity19 = new org.jfree.chart.entity.ChartEntity(shape16, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape20 = chartEntity19.getArea();
        chartEntity15.setArea(shape20);
        lineAndShapeRenderer2.setBaseShape(shape20, true);
        java.lang.Boolean boolean25 = lineAndShapeRenderer2.getSeriesShapesVisible(1);
        lineAndShapeRenderer2.setAutoPopulateSeriesStroke(true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNull(boolean25);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.axis.AxisLocation axisLocation6 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot0.setDomainAxisLocation(0, axisLocation6);
        java.lang.String str8 = axisLocation6.toString();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "AxisLocation.TOP_OR_LEFT" + "'", str8.equals("AxisLocation.TOP_OR_LEFT"));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Shape shape9 = lineAndShapeRenderer2.getItemShape((int) (short) 10, 100, true);
        lineAndShapeRenderer2.setBaseSeriesVisible(false);
        lineAndShapeRenderer2.setSeriesShapesVisible((int) (short) 10, false);
        java.awt.Shape shape16 = lineAndShapeRenderer2.lookupSeriesShape(1);
        java.lang.Object obj17 = lineAndShapeRenderer2.clone();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(obj17);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.util.Layer layer5 = null;
        java.util.Collection collection6 = categoryPlot0.getRangeMarkers(10, layer5);
        org.jfree.chart.axis.AxisLocation axisLocation7 = categoryPlot0.getDomainAxisLocation();
        categoryPlot0.setCrosshairDatasetIndex(156);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNull(collection6);
        org.junit.Assert.assertNotNull(axisLocation7);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        java.awt.Shape shape4 = null;
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem6 = new org.jfree.chart.LegendItem("", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", shape4, (java.awt.Paint) color5);
        java.awt.Shape shape7 = legendItem6.getShape();
        int int8 = legendItem6.getSeriesIndex();
        boolean boolean9 = legendItem6.isShapeVisible();
        java.lang.String str10 = legendItem6.getLabel();
        boolean boolean11 = legendItem6.isShapeFilled();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(shape7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = categoryAxis1.getTickLabelInsets();
        categoryAxis1.setCategoryLabelPositionOffset(0);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        int int9 = categoryPlot5.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot5.getRowRenderingOrder();
        java.awt.Stroke stroke11 = categoryPlot5.getRangeZeroBaselineStroke();
        int int12 = categoryPlot5.getCrosshairDatasetIndex();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke16 = lineAndShapeRenderer15.getBaseStroke();
        java.awt.Stroke stroke18 = lineAndShapeRenderer15.lookupSeriesStroke(10);
        lineAndShapeRenderer15.setAutoPopulateSeriesStroke(true);
        categoryPlot5.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer15, true);
        categoryAxis1.setPlot((org.jfree.chart.plot.Plot) categoryPlot5);
        java.lang.Object obj24 = categoryAxis1.clone();
        int int25 = categoryAxis1.getMaximumCategoryLabelLines();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis4 = categoryPlot1.getRangeAxis();
        int int5 = categoryPlot1.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder6 = categoryPlot1.getRowRenderingOrder();
        java.awt.Stroke stroke7 = categoryPlot1.getRangeZeroBaselineStroke();
        categoryPlot1.setRangeGridlinesVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis13 = categoryPlot10.getRangeAxis();
        int int14 = categoryPlot10.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder15 = categoryPlot10.getRowRenderingOrder();
        java.awt.Stroke stroke16 = categoryPlot10.getRangeZeroBaselineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent17 = null;
        categoryPlot10.rendererChanged(rendererChangeEvent17);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation20 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot19.setRangeAxisLocation(axisLocation20, true);
        categoryPlot10.setDomainAxisLocation(axisLocation20);
        categoryPlot1.setDomainAxisLocation(axisLocation20, true);
        categoryPlot1.setBackgroundAlpha((float) 10);
        boolean boolean28 = defaultDrawingSupplier0.equals((java.lang.Object) 10);
        java.awt.Paint paint29 = defaultDrawingSupplier0.getNextOutlinePaint();
        java.awt.Paint paint30 = defaultDrawingSupplier0.getNextFillPaint();
        java.awt.Stroke stroke31 = defaultDrawingSupplier0.getNextStroke();
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
        org.junit.Assert.assertNotNull(sortOrder6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(valueAxis13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 15 + "'", int14 == 15);
        org.junit.Assert.assertNotNull(sortOrder15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(stroke31);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        java.lang.Comparable comparable9 = categoryPlot0.getDomainCrosshairColumnKey();
        boolean boolean10 = categoryPlot0.isRangeCrosshairLockedOnData();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        categoryPlot0.setDomainCrosshairPaint((java.awt.Paint) color11);
        boolean boolean13 = categoryPlot0.isRangeCrosshairVisible();
        categoryPlot0.setNoDataMessage("ItemLabelAnchor.OUTSIDE1");
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNull(comparable9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Shape shape9 = lineAndShapeRenderer2.getItemShape((int) (short) 10, 100, true);
        lineAndShapeRenderer2.setBaseCreateEntities(true);
        lineAndShapeRenderer2.setAutoPopulateSeriesOutlinePaint(false);
        java.awt.Shape shape14 = lineAndShapeRenderer2.getBaseLegendShape();
        lineAndShapeRenderer2.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot18.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis21 = categoryPlot18.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Point2D point2D24 = null;
        categoryPlot18.zoomDomainAxes((double) 10.0f, plotRenderingInfo23, point2D24, false);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent27 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot18);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot28.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis31 = categoryPlot28.getRangeAxis();
        int int32 = categoryPlot28.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder33 = categoryPlot28.getRowRenderingOrder();
        java.awt.Stroke stroke34 = categoryPlot28.getRangeZeroBaselineStroke();
        categoryPlot18.setOutlineStroke(stroke34);
        org.jfree.chart.plot.Marker marker37 = null;
        org.jfree.chart.util.Layer layer38 = null;
        boolean boolean39 = categoryPlot18.removeDomainMarker(15, marker37, layer38);
        java.awt.Stroke stroke40 = categoryPlot18.getRangeZeroBaselineStroke();
        lineAndShapeRenderer2.setSeriesStroke((int) (short) 1, stroke40);
        java.awt.Shape shape43 = lineAndShapeRenderer2.getLegendShape(8);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNull(shape14);
        org.junit.Assert.assertNull(valueAxis21);
        org.junit.Assert.assertNull(valueAxis31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 15 + "'", int32 == 15);
        org.junit.Assert.assertNotNull(sortOrder33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNull(shape43);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        org.jfree.chart.LegendItem legendItem2 = new org.jfree.chart.LegendItem("PlotEntity: tooltip = ItemLabelAnchor.OUTSIDE1", (java.awt.Paint) color1);
        java.awt.color.ColorSpace colorSpace3 = color1.getColorSpace();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(colorSpace3);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor9 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis13 = categoryPlot10.getRangeAxis();
        int int14 = categoryPlot10.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder15 = categoryPlot10.getRowRenderingOrder();
        java.awt.Stroke stroke16 = categoryPlot10.getRangeZeroBaselineStroke();
        categoryPlot0.setRangeMinorGridlineStroke(stroke16);
        categoryPlot0.clearDomainAxes();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(categoryAnchor9);
        org.junit.Assert.assertNull(valueAxis13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 15 + "'", int14 == 15);
        org.junit.Assert.assertNotNull(sortOrder15);
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = categoryAxis1.getTickLabelInsets();
        categoryAxis1.setCategoryLabelPositionOffset(0);
        categoryAxis1.setMinorTickMarksVisible(false);
        float float7 = categoryAxis1.getMinorTickMarkOutsideLength();
        boolean boolean8 = categoryAxis1.isVisible();
        categoryAxis1.setTickMarkOutsideLength((float) 10L);
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        double double12 = barRenderer11.getMinimumBarLength();
        java.awt.Paint paint16 = barRenderer11.getItemPaint(0, 15, true);
        barRenderer11.setShadowVisible(true);
        java.awt.Shape shape20 = barRenderer11.lookupSeriesShape(255);
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot21.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis24 = categoryPlot21.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        java.awt.geom.Point2D point2D27 = null;
        categoryPlot21.zoomDomainAxes((double) 10.0f, plotRenderingInfo26, point2D27, false);
        boolean boolean30 = categoryPlot21.isRangeCrosshairVisible();
        java.awt.Stroke stroke31 = categoryPlot21.getRangeCrosshairStroke();
        barRenderer11.setBaseOutlineStroke(stroke31, true);
        categoryAxis1.setAxisLineStroke(stroke31);
        java.lang.String str35 = categoryAxis1.getLabelToolTip();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 2.0f + "'", float7 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNull(valueAxis24);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNull(str35);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        categoryPlot0.setDomainGridlinesVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot5.zoomDomainAxes((double) 10.0f, plotRenderingInfo10, point2D11, false);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent14 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot5);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType15 = plotChangeEvent14.getType();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType16 = plotChangeEvent14.getType();
        java.lang.Object obj17 = plotChangeEvent14.getSource();
        categoryPlot0.notifyListeners(plotChangeEvent14);
        categoryPlot0.setDomainCrosshairColumnKey((java.lang.Comparable) (short) 100, true);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertNotNull(chartChangeEventType15);
        org.junit.Assert.assertNotNull(chartChangeEventType16);
        org.junit.Assert.assertNotNull(obj17);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        java.lang.Comparable comparable9 = categoryPlot0.getDomainCrosshairColumnKey();
        boolean boolean10 = categoryPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = categoryPlot0.getAxisOffset();
        boolean boolean12 = categoryPlot0.isSubplot();
        categoryPlot0.setForegroundAlpha(0.0f);
        org.jfree.chart.axis.AxisSpace axisSpace15 = categoryPlot0.getFixedDomainAxisSpace();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNull(comparable9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(axisSpace15);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent9 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot0);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis13 = categoryPlot10.getRangeAxis();
        int int14 = categoryPlot10.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder15 = categoryPlot10.getRowRenderingOrder();
        java.awt.Stroke stroke16 = categoryPlot10.getRangeZeroBaselineStroke();
        categoryPlot0.setOutlineStroke(stroke16);
        org.jfree.chart.plot.Marker marker19 = null;
        org.jfree.chart.util.Layer layer20 = null;
        boolean boolean21 = categoryPlot0.removeDomainMarker(15, marker19, layer20);
        categoryPlot0.setOutlineVisible(true);
        org.jfree.chart.util.SortOrder sortOrder24 = categoryPlot0.getColumnRenderingOrder();
        categoryPlot0.setRangeCrosshairValue((double) 128);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNull(valueAxis13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 15 + "'", int14 == 15);
        org.junit.Assert.assertNotNull(sortOrder15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(sortOrder24);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        lineAndShapeRenderer2.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator7);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = lineAndShapeRenderer2.getSeriesPositiveItemLabelPosition(0);
        java.awt.Stroke stroke11 = lineAndShapeRenderer2.getBaseStroke();
        boolean boolean12 = lineAndShapeRenderer2.getBaseItemLabelsVisible();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer16 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke17 = lineAndShapeRenderer16.getBaseStroke();
        java.awt.Stroke stroke19 = lineAndShapeRenderer16.lookupSeriesStroke(10);
        lineAndShapeRenderer2.setSeriesOutlineStroke((int) ' ', stroke19);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(stroke19);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        java.awt.Shape shape4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        int int9 = categoryPlot5.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot5.getRowRenderingOrder();
        java.awt.Stroke stroke11 = categoryPlot5.getRangeZeroBaselineStroke();
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("", "", "hi!", "", shape4, stroke11, paint12);
        legendItem13.setDescription("");
        int int16 = legendItem13.getDatasetIndex();
        java.lang.String str17 = legendItem13.getLabel();
        java.lang.String str18 = legendItem13.getLabel();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset19 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo20 = new org.jfree.chart.event.DatasetChangeInfo();
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent21 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object) legendItem13, (org.jfree.data.general.Dataset) defaultCategoryDataset19, datasetChangeInfo20);
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo22 = datasetChangeEvent21.getInfo();
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo23 = datasetChangeEvent21.getInfo();
        org.jfree.data.general.Dataset dataset24 = datasetChangeEvent21.getDataset();
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertNotNull(datasetChangeInfo22);
        org.junit.Assert.assertNotNull(datasetChangeInfo23);
        org.junit.Assert.assertNotNull(dataset24);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        boolean boolean6 = lineAndShapeRenderer2.getUseSeriesOffset();
        boolean boolean7 = lineAndShapeRenderer2.getDataBoundsIncludesVisibleSeriesOnly();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        java.awt.Shape shape4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        int int9 = categoryPlot5.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot5.getRowRenderingOrder();
        java.awt.Stroke stroke11 = categoryPlot5.getRangeZeroBaselineStroke();
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("", "", "hi!", "", shape4, stroke11, paint12);
        legendItem13.setDescription("");
        int int16 = legendItem13.getDatasetIndex();
        java.lang.String str17 = legendItem13.getLabel();
        java.text.AttributedString attributedString18 = legendItem13.getAttributedLabel();
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertNull(attributedString18);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        java.lang.Comparable comparable9 = categoryPlot0.getDomainCrosshairColumnKey();
        boolean boolean10 = categoryPlot0.isRangeCrosshairLockedOnData();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        categoryPlot0.setDomainCrosshairPaint((java.awt.Paint) color11);
        java.awt.Shape shape17 = null;
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem19 = new org.jfree.chart.LegendItem("", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", shape17, (java.awt.Paint) color18);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color18);
        java.awt.Color color21 = color18.brighter();
        java.awt.Color color25 = java.awt.Color.getHSBColor((float) (short) 1, (float) 100, 0.0f);
        float[] floatArray32 = new float[] { (byte) 10, (byte) 1, 1.0f, (byte) 0, 10, (byte) 100 };
        float[] floatArray33 = color25.getRGBComponents(floatArray32);
        float[] floatArray34 = color21.getColorComponents(floatArray33);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNull(comparable9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertNotNull(floatArray34);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor9 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis13 = categoryPlot10.getRangeAxis();
        int int14 = categoryPlot10.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder15 = categoryPlot10.getRowRenderingOrder();
        java.awt.Stroke stroke16 = categoryPlot10.getRangeZeroBaselineStroke();
        categoryPlot0.setRangeMinorGridlineStroke(stroke16);
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = categoryPlot0.getDomainAxis(100);
        boolean boolean20 = categoryPlot0.isNotify();
        categoryPlot0.clearRangeMarkers((int) (short) -1);
        java.awt.Paint paint23 = categoryPlot0.getRangeMinorGridlinePaint();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(categoryAnchor9);
        org.junit.Assert.assertNull(valueAxis13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 15 + "'", int14 == 15);
        org.junit.Assert.assertNotNull(sortOrder15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNull(categoryAxis19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(paint23);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        categoryPlot0.setDomainCrosshairColumnKey((java.lang.Comparable) (short) -1, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot0.zoomRangeAxes((double) (byte) 1, plotRenderingInfo9, point2D10, true);
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) 0.0f, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot16.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis19 = categoryPlot16.getRangeAxis();
        int int20 = categoryPlot16.getBackgroundImageAlignment();
        java.awt.Paint paint21 = categoryPlot16.getNoDataMessagePaint();
        java.awt.Paint paint22 = categoryPlot16.getRangeMinorGridlinePaint();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot16);
        java.awt.Stroke stroke24 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        categoryPlot16.setRangeGridlineStroke(stroke24);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNull(valueAxis19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 15 + "'", int20 == 15);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(stroke24);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairLockedOnData(false);
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) (short) 10);
        categoryPlot0.setAnchorValue((double) (short) 10, false);
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace8);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        categoryPlot0.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot0.zoomRangeAxes(139.0d, (double) (short) 100, plotRenderingInfo14, point2D15);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Shape shape9 = lineAndShapeRenderer2.getItemShape((int) (short) 10, 100, true);
        lineAndShapeRenderer2.setBaseSeriesVisible(false);
        java.awt.Shape shape12 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity15 = new org.jfree.chart.entity.ChartEntity(shape12, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape16 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity19 = new org.jfree.chart.entity.ChartEntity(shape16, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape20 = chartEntity19.getArea();
        chartEntity15.setArea(shape20);
        lineAndShapeRenderer2.setBaseShape(shape20, true);
        java.lang.Boolean boolean25 = lineAndShapeRenderer2.getSeriesShapesVisible(1);
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot27.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis30 = categoryPlot27.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        java.awt.geom.Point2D point2D33 = null;
        categoryPlot27.zoomDomainAxes((double) 10.0f, plotRenderingInfo32, point2D33, false);
        java.lang.Comparable comparable36 = categoryPlot27.getDomainCrosshairColumnKey();
        boolean boolean37 = categoryPlot27.isRangeCrosshairLockedOnData();
        categoryPlot27.setCrosshairDatasetIndex((int) (byte) 10, false);
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        java.awt.Paint paint43 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot44.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis47 = categoryPlot44.getRangeAxis();
        int int48 = categoryPlot44.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder49 = categoryPlot44.getRowRenderingOrder();
        categoryPlot44.setWeight((int) (short) 100);
        org.jfree.chart.plot.CategoryPlot categoryPlot52 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot52.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis55 = categoryPlot52.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo57 = null;
        java.awt.geom.Point2D point2D58 = null;
        categoryPlot52.zoomDomainAxes((double) 10.0f, plotRenderingInfo57, point2D58, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor61 = categoryPlot52.getDomainGridlinePosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot62.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis65 = categoryPlot62.getRangeAxis();
        int int66 = categoryPlot62.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder67 = categoryPlot62.getRowRenderingOrder();
        java.awt.Stroke stroke68 = categoryPlot62.getRangeZeroBaselineStroke();
        categoryPlot52.setRangeMinorGridlineStroke(stroke68);
        categoryPlot44.setRangeZeroBaselineStroke(stroke68);
        try {
            lineAndShapeRenderer2.drawDomainLine(graphics2D26, categoryPlot27, rectangle2D41, (double) 8, paint43, stroke68);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNull(boolean25);
        org.junit.Assert.assertNull(valueAxis30);
        org.junit.Assert.assertNull(comparable36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNull(valueAxis47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 15 + "'", int48 == 15);
        org.junit.Assert.assertNotNull(sortOrder49);
        org.junit.Assert.assertNull(valueAxis55);
        org.junit.Assert.assertNotNull(categoryAnchor61);
        org.junit.Assert.assertNull(valueAxis65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 15 + "'", int66 == 15);
        org.junit.Assert.assertNotNull(sortOrder67);
        org.junit.Assert.assertNotNull(stroke68);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(true);
        java.awt.Color color3 = java.awt.Color.magenta;
        renderAttributes1.setSeriesOutlinePaint(128, (java.awt.Paint) color3);
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_YELLOW;
        renderAttributes1.setSeriesOutlinePaint(0, (java.awt.Paint) color6);
        java.awt.Color color8 = java.awt.Color.cyan;
        renderAttributes1.setDefaultOutlinePaint((java.awt.Paint) color8);
        org.jfree.chart.renderer.RenderAttributes renderAttributes11 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        renderAttributes11.setDefaultFillPaint((java.awt.Paint) color12);
        java.awt.Stroke stroke15 = renderAttributes11.getSeriesStroke((int) ' ');
        java.awt.Stroke stroke16 = renderAttributes11.getDefaultStroke();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier17 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot18.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis21 = categoryPlot18.getRangeAxis();
        int int22 = categoryPlot18.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder23 = categoryPlot18.getRowRenderingOrder();
        java.awt.Stroke stroke24 = categoryPlot18.getRangeZeroBaselineStroke();
        categoryPlot18.setRangeGridlinesVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot27.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis30 = categoryPlot27.getRangeAxis();
        int int31 = categoryPlot27.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder32 = categoryPlot27.getRowRenderingOrder();
        java.awt.Stroke stroke33 = categoryPlot27.getRangeZeroBaselineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent34 = null;
        categoryPlot27.rendererChanged(rendererChangeEvent34);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation37 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot36.setRangeAxisLocation(axisLocation37, true);
        categoryPlot27.setDomainAxisLocation(axisLocation37);
        categoryPlot18.setDomainAxisLocation(axisLocation37, true);
        categoryPlot18.setBackgroundAlpha((float) 10);
        boolean boolean45 = defaultDrawingSupplier17.equals((java.lang.Object) 10);
        java.awt.Paint paint46 = defaultDrawingSupplier17.getNextOutlinePaint();
        java.awt.Paint paint47 = defaultDrawingSupplier17.getNextPaint();
        java.awt.Paint paint48 = defaultDrawingSupplier17.getNextOutlinePaint();
        renderAttributes11.setDefaultPaint(paint48);
        renderAttributes1.setSeriesPaint((int) ' ', paint48);
        java.awt.Paint paint51 = renderAttributes1.getDefaultFillPaint();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNull(stroke15);
        org.junit.Assert.assertNull(stroke16);
        org.junit.Assert.assertNull(valueAxis21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 15 + "'", int22 == 15);
        org.junit.Assert.assertNotNull(sortOrder23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNull(valueAxis30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 15 + "'", int31 == 15);
        org.junit.Assert.assertNotNull(sortOrder32);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNull(paint51);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        renderAttributes0.setDefaultFillPaint((java.awt.Paint) color1);
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        renderAttributes0.setSeriesPaint((int) (short) 100, (java.awt.Paint) color4);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        org.jfree.chart.LegendItemCollection legendItemCollection4 = lineAndShapeRenderer2.getLegendItems();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke9 = lineAndShapeRenderer8.getBaseStroke();
        java.awt.Paint paint11 = lineAndShapeRenderer8.getSeriesPaint(15);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = lineAndShapeRenderer8.getSeriesNegativeItemLabelPosition(255);
        lineAndShapeRenderer2.setSeriesNegativeItemLabelPosition(0, itemLabelPosition13, false);
        lineAndShapeRenderer2.clearSeriesPaints(false);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(legendItemCollection4);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(itemLabelPosition13);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        lineAndShapeRenderer2.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator7);
        lineAndShapeRenderer2.setSeriesVisible((int) (short) 100, (java.lang.Boolean) false, true);
        boolean boolean15 = lineAndShapeRenderer2.getItemShapeVisible((int) (short) 10, 3);
        lineAndShapeRenderer2.setSeriesVisibleInLegend(100, (java.lang.Boolean) true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot20.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis23 = categoryPlot20.getRangeAxis();
        int int24 = categoryPlot20.getBackgroundImageAlignment();
        categoryPlot20.setDomainCrosshairColumnKey((java.lang.Comparable) (short) -1, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        java.awt.geom.Point2D point2D30 = null;
        categoryPlot20.zoomRangeAxes((double) (byte) 1, plotRenderingInfo29, point2D30, true);
        java.awt.Graphics2D graphics2D33 = null;
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        categoryPlot20.drawBackgroundImage(graphics2D33, rectangle2D34);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer38 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke39 = lineAndShapeRenderer38.getBaseStroke();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator41 = null;
        lineAndShapeRenderer38.setSeriesItemLabelGenerator((int) (byte) 1, categoryItemLabelGenerator41);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer46 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke47 = lineAndShapeRenderer46.getBaseStroke();
        java.awt.Paint paint49 = lineAndShapeRenderer46.getSeriesPaint(15);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer53 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke54 = lineAndShapeRenderer53.getBaseStroke();
        java.awt.Stroke stroke56 = lineAndShapeRenderer53.lookupSeriesStroke(10);
        java.awt.Paint paint57 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        lineAndShapeRenderer53.setBaseOutlinePaint(paint57);
        java.awt.Font font59 = lineAndShapeRenderer53.getBaseItemLabelFont();
        lineAndShapeRenderer46.setSeriesItemLabelFont((int) (byte) 1, font59);
        lineAndShapeRenderer38.setSeriesItemLabelFont((int) (short) 10, font59, true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer66 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke67 = lineAndShapeRenderer66.getBaseStroke();
        java.awt.Stroke stroke69 = lineAndShapeRenderer66.lookupSeriesStroke(10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator71 = null;
        lineAndShapeRenderer66.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator71);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition74 = lineAndShapeRenderer66.getSeriesPositiveItemLabelPosition(0);
        lineAndShapeRenderer66.setBaseShapesFilled(false);
        lineAndShapeRenderer66.setSeriesVisibleInLegend((int) (short) 10, (java.lang.Boolean) false);
        java.awt.Stroke stroke81 = lineAndShapeRenderer66.lookupSeriesOutlineStroke((-1));
        lineAndShapeRenderer38.setSeriesStroke((int) (short) 10, stroke81, false);
        categoryPlot20.setDomainGridlineStroke(stroke81);
        lineAndShapeRenderer2.setBaseOutlineStroke(stroke81, true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 15 + "'", int24 == 15);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNull(paint49);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertNotNull(paint57);
        org.junit.Assert.assertNotNull(font59);
        org.junit.Assert.assertNotNull(stroke67);
        org.junit.Assert.assertNotNull(stroke69);
        org.junit.Assert.assertNotNull(itemLabelPosition74);
        org.junit.Assert.assertNotNull(stroke81);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        java.awt.Paint paint3 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) (short) 10);
        categoryAxis1.setMinorTickMarksVisible(true);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj2 = objectList0.get(8);
        java.lang.Object obj4 = objectList0.get(128);
        java.lang.Object obj5 = objectList0.clone();
        java.lang.Object obj6 = objectList0.clone();
        org.junit.Assert.assertNull(obj2);
        org.junit.Assert.assertNull(obj4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor9 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis13 = categoryPlot10.getRangeAxis();
        int int14 = categoryPlot10.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder15 = categoryPlot10.getRowRenderingOrder();
        java.awt.Stroke stroke16 = categoryPlot10.getRangeZeroBaselineStroke();
        categoryPlot0.setRangeMinorGridlineStroke(stroke16);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder18 = categoryPlot0.getDatasetRenderingOrder();
        org.jfree.chart.axis.AxisSpace axisSpace19 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace19, false);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(categoryAnchor9);
        org.junit.Assert.assertNull(valueAxis13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 15 + "'", int14 == 15);
        org.junit.Assert.assertNotNull(sortOrder15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(datasetRenderingOrder18);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Shape shape9 = lineAndShapeRenderer2.getItemShape((int) (short) 10, 100, true);
        lineAndShapeRenderer2.setBaseCreateEntities(true);
        java.awt.Paint paint15 = lineAndShapeRenderer2.getItemLabelPaint(0, (int) 'a', false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer18 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke19 = lineAndShapeRenderer18.getBaseStroke();
        java.awt.Stroke stroke21 = lineAndShapeRenderer18.lookupSeriesStroke(10);
        java.awt.Shape shape25 = lineAndShapeRenderer18.getItemShape((int) (short) 10, 100, true);
        lineAndShapeRenderer18.setBaseCreateEntities(true);
        lineAndShapeRenderer18.setAutoPopulateSeriesOutlinePaint(false);
        java.awt.Shape shape30 = lineAndShapeRenderer18.getBaseLegendShape();
        java.awt.Font font31 = lineAndShapeRenderer18.getBaseItemLabelFont();
        lineAndShapeRenderer2.setBaseItemLabelFont(font31);
        boolean boolean33 = lineAndShapeRenderer2.getUseOutlinePaint();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNull(shape30);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        lineAndShapeRenderer2.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator7);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = lineAndShapeRenderer2.getSeriesPositiveItemLabelPosition(0);
        java.awt.Stroke stroke11 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Color color14 = java.awt.Color.getColor("ItemLabelAnchor.OUTSIDE1", 0);
        lineAndShapeRenderer2.setBasePaint((java.awt.Paint) color14);
        java.lang.Boolean boolean17 = lineAndShapeRenderer2.getSeriesVisibleInLegend(3);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNull(boolean17);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        int int1 = color0.getGreen();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        boolean boolean1 = categoryAxis0.isAxisLineVisible();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        renderAttributes0.setDefaultFillPaint((java.awt.Paint) color1);
        java.awt.Shape shape5 = renderAttributes0.getItemShape((int) (byte) 100, (int) 'a');
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        java.awt.Color color7 = java.awt.Color.yellow;
        java.awt.color.ColorSpace colorSpace8 = color7.getColorSpace();
        java.awt.Color color12 = java.awt.Color.getHSBColor((float) (short) 1, (float) 100, 0.0f);
        float[] floatArray19 = new float[] { (byte) 10, (byte) 1, 1.0f, (byte) 0, 10, (byte) 100 };
        float[] floatArray20 = color12.getRGBComponents(floatArray19);
        float[] floatArray21 = color6.getColorComponents(colorSpace8, floatArray19);
        renderAttributes0.setDefaultLabelPaint((java.awt.Paint) color6);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNull(shape5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(colorSpace8);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        try {
            java.util.ResourceBundle resourceBundle1 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("java.awt.Color[r=0,g=0,b=0]");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name java.awt.Color[r=0,g=0,b=0], locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        lineAndShapeRenderer2.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator7);
        lineAndShapeRenderer2.setSeriesVisible((int) (short) 100, (java.lang.Boolean) false, true);
        boolean boolean15 = lineAndShapeRenderer2.getItemShapeVisible((int) (short) 10, 3);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator16 = lineAndShapeRenderer2.getLegendItemLabelGenerator();
        lineAndShapeRenderer2.setSeriesVisible((int) '4', (java.lang.Boolean) true);
        java.awt.Shape shape20 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity23 = new org.jfree.chart.entity.ChartEntity(shape20, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape24 = chartEntity23.getArea();
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot25.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis28 = categoryPlot25.getRangeAxis();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier29 = categoryPlot25.getDrawingSupplier();
        org.jfree.data.category.CategoryDataset categoryDataset30 = categoryPlot25.getDataset();
        org.jfree.chart.renderer.RenderAttributes renderAttributes31 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        renderAttributes31.setDefaultFillPaint((java.awt.Paint) color32);
        categoryPlot25.setBackgroundPaint((java.awt.Paint) color32);
        org.jfree.chart.axis.ValueAxis valueAxis35 = categoryPlot25.getRangeAxis();
        org.jfree.chart.entity.PlotEntity plotEntity38 = new org.jfree.chart.entity.PlotEntity(shape24, (org.jfree.chart.plot.Plot) categoryPlot25, "ChartChangeEventType.GENERAL", "hi!");
        lineAndShapeRenderer2.setBaseShape(shape24);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator40 = lineAndShapeRenderer2.getLegendItemLabelGenerator();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator16);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNull(valueAxis28);
        org.junit.Assert.assertNotNull(drawingSupplier29);
        org.junit.Assert.assertNull(categoryDataset30);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNull(valueAxis35);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator40);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder5 = categoryPlot0.getRowRenderingOrder();
        java.awt.Stroke stroke6 = categoryPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent7 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent7);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot9.setRangeAxisLocation(axisLocation10, true);
        categoryPlot0.setDomainAxisLocation(axisLocation10);
        categoryPlot0.setCrosshairDatasetIndex((int) (short) 1);
        java.awt.Image image16 = categoryPlot0.getBackgroundImage();
        java.awt.Paint paint17 = categoryPlot0.getOutlinePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot18.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = categoryPlot18.getDomainAxisEdge();
        int int22 = categoryPlot18.getWeight();
        java.lang.Comparable comparable23 = categoryPlot18.getDomainCrosshairColumnKey();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer26 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke27 = lineAndShapeRenderer26.getBaseStroke();
        java.awt.Paint paint29 = lineAndShapeRenderer26.getSeriesPaint(15);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition31 = lineAndShapeRenderer26.getSeriesNegativeItemLabelPosition(255);
        int int32 = lineAndShapeRenderer26.getDefaultEntityRadius();
        java.awt.Stroke stroke33 = lineAndShapeRenderer26.getBaseOutlineStroke();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator35 = lineAndShapeRenderer26.getSeriesToolTipGenerator(128);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer38 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke39 = lineAndShapeRenderer38.getBaseStroke();
        java.awt.Stroke stroke41 = lineAndShapeRenderer38.lookupSeriesStroke(10);
        java.awt.Shape shape45 = lineAndShapeRenderer38.getItemShape((int) (short) 10, 100, true);
        lineAndShapeRenderer38.setBaseSeriesVisible(false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer50 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke51 = lineAndShapeRenderer50.getBaseStroke();
        java.awt.Stroke stroke53 = lineAndShapeRenderer50.lookupSeriesStroke(10);
        java.awt.Paint paint54 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        lineAndShapeRenderer50.setBaseOutlinePaint(paint54);
        java.awt.Font font56 = lineAndShapeRenderer50.getBaseItemLabelFont();
        java.awt.Paint paint57 = lineAndShapeRenderer50.getBaseFillPaint();
        boolean boolean58 = lineAndShapeRenderer50.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer61 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke62 = lineAndShapeRenderer61.getBaseStroke();
        org.jfree.chart.LegendItemCollection legendItemCollection63 = lineAndShapeRenderer61.getLegendItems();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer66 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke67 = lineAndShapeRenderer66.getBaseStroke();
        java.awt.Paint paint69 = lineAndShapeRenderer66.getSeriesPaint(15);
        double double70 = lineAndShapeRenderer66.getItemLabelAnchorOffset();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer73 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke74 = lineAndShapeRenderer73.getBaseStroke();
        java.awt.Stroke stroke76 = lineAndShapeRenderer73.lookupSeriesStroke(10);
        java.awt.Shape shape80 = lineAndShapeRenderer73.getItemShape((int) (short) 10, 100, true);
        java.awt.Paint paint82 = lineAndShapeRenderer73.getSeriesFillPaint((int) (short) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray83 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { lineAndShapeRenderer26, lineAndShapeRenderer38, lineAndShapeRenderer50, lineAndShapeRenderer61, lineAndShapeRenderer66, lineAndShapeRenderer73 };
        categoryPlot18.setRenderers(categoryItemRendererArray83);
        categoryPlot0.setRenderers(categoryItemRendererArray83);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(sortOrder5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNull(image16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNull(comparable23);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNull(paint29);
        org.junit.Assert.assertNotNull(itemLabelPosition31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 3 + "'", int32 == 3);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNull(categoryToolTipGenerator35);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(shape45);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertNotNull(font56);
        org.junit.Assert.assertNotNull(paint57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(stroke62);
        org.junit.Assert.assertNotNull(legendItemCollection63);
        org.junit.Assert.assertNotNull(stroke67);
        org.junit.Assert.assertNull(paint69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 2.0d + "'", double70 == 2.0d);
        org.junit.Assert.assertNotNull(stroke74);
        org.junit.Assert.assertNotNull(stroke76);
        org.junit.Assert.assertNotNull(shape80);
        org.junit.Assert.assertNull(paint82);
        org.junit.Assert.assertNotNull(categoryItemRendererArray83);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        java.awt.Shape shape4 = null;
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem6 = new org.jfree.chart.LegendItem("", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", shape4, (java.awt.Paint) color5);
        legendItem6.setDescription("hi!");
        legendItem6.setShapeVisible(false);
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isRangeGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getRangeAxisEdge((int) (byte) -1);
        boolean boolean4 = categoryPlot0.canSelectByRegion();
        java.awt.Color color8 = java.awt.Color.getHSBColor((float) (short) 1, (float) 100, 0.0f);
        float[] floatArray15 = new float[] { (byte) 10, (byte) 1, 1.0f, (byte) 0, 10, (byte) 100 };
        float[] floatArray16 = color8.getRGBComponents(floatArray15);
        java.lang.String str17 = color8.toString();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color8);
        float float19 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.util.SortOrder sortOrder20 = categoryPlot0.getRowRenderingOrder();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        try {
            categoryPlot0.handleClick(3, (-16728064), plotRenderingInfo23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "java.awt.Color[r=0,g=0,b=0]" + "'", str17.equals("java.awt.Color[r=0,g=0,b=0]"));
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 1.0f + "'", float19 == 1.0f);
        org.junit.Assert.assertNotNull(sortOrder20);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        boolean boolean3 = lineAndShapeRenderer2.getDrawOutlines();
        boolean boolean6 = lineAndShapeRenderer2.getItemVisible((int) (byte) 1, 8);
        boolean boolean7 = lineAndShapeRenderer2.getDataBoundsIncludesVisibleSeriesOnly();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getMinimumBarLength();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = null;
        barRenderer0.setSeriesURLGenerator((int) (short) 0, categoryURLGenerator3);
        java.lang.Boolean boolean6 = barRenderer0.getSeriesItemLabelsVisible((int) (short) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = barRenderer0.getNegativeItemLabelPositionFallback();
        double double8 = barRenderer0.getMaximumBarWidth();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(boolean6);
        org.junit.Assert.assertNull(itemLabelPosition7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset0 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.category.CategoryDatasetSelectionState categoryDatasetSelectionState1 = null;
        abstractCategoryDataset0.setSelectionState(categoryDatasetSelectionState1);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot3.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot3.zoomDomainAxes((double) 10.0f, plotRenderingInfo8, point2D9, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor12 = categoryPlot3.getDomainGridlinePosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot13.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis16 = categoryPlot13.getRangeAxis();
        int int17 = categoryPlot13.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder18 = categoryPlot13.getRowRenderingOrder();
        java.awt.Stroke stroke19 = categoryPlot13.getRangeZeroBaselineStroke();
        categoryPlot3.setRangeMinorGridlineStroke(stroke19);
        org.jfree.chart.axis.ValueAxis valueAxis22 = categoryPlot3.getRangeAxis(1);
        boolean boolean23 = abstractCategoryDataset0.hasListener((java.util.EventListener) categoryPlot3);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset24 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup25 = defaultCategoryDataset24.getGroup();
        abstractCategoryDataset0.setGroup(datasetGroup25);
        java.lang.Object obj27 = datasetGroup25.clone();
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(categoryAnchor12);
        org.junit.Assert.assertNull(valueAxis16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 15 + "'", int17 == 15);
        org.junit.Assert.assertNotNull(sortOrder18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(valueAxis22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(datasetGroup25);
        org.junit.Assert.assertNotNull(obj27);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge();
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_RED;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color4);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = null;
        lineAndShapeRenderer2.setSeriesItemLabelGenerator((int) (byte) 1, categoryItemLabelGenerator5);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke11 = lineAndShapeRenderer10.getBaseStroke();
        java.awt.Paint paint13 = lineAndShapeRenderer10.getSeriesPaint(15);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer17 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke18 = lineAndShapeRenderer17.getBaseStroke();
        java.awt.Stroke stroke20 = lineAndShapeRenderer17.lookupSeriesStroke(10);
        java.awt.Paint paint21 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        lineAndShapeRenderer17.setBaseOutlinePaint(paint21);
        java.awt.Font font23 = lineAndShapeRenderer17.getBaseItemLabelFont();
        lineAndShapeRenderer10.setSeriesItemLabelFont((int) (byte) 1, font23);
        lineAndShapeRenderer2.setSeriesItemLabelFont((int) (short) 10, font23, true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer30 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke31 = lineAndShapeRenderer30.getBaseStroke();
        java.awt.Stroke stroke33 = lineAndShapeRenderer30.lookupSeriesStroke(10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator35 = null;
        lineAndShapeRenderer30.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator35);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition38 = lineAndShapeRenderer30.getSeriesPositiveItemLabelPosition(0);
        lineAndShapeRenderer30.setBaseShapesFilled(false);
        lineAndShapeRenderer30.setSeriesVisibleInLegend((int) (short) 10, (java.lang.Boolean) false);
        java.awt.Stroke stroke45 = lineAndShapeRenderer30.lookupSeriesOutlineStroke((-1));
        lineAndShapeRenderer2.setSeriesStroke((int) (short) 10, stroke45, false);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor48 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE5;
        java.awt.Color color49 = java.awt.Color.white;
        boolean boolean50 = itemLabelAnchor48.equals((java.lang.Object) color49);
        org.jfree.chart.text.TextAnchor textAnchor51 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition52 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor48, textAnchor51);
        org.jfree.chart.text.TextAnchor textAnchor53 = itemLabelPosition52.getRotationAnchor();
        lineAndShapeRenderer2.setBasePositiveItemLabelPosition(itemLabelPosition52);
        org.jfree.chart.plot.CategoryPlot categoryPlot55 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean56 = categoryPlot55.isRangeGridlinesVisible();
        categoryPlot55.clearDomainAxes();
        java.awt.Color color58 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        categoryPlot55.setOutlinePaint((java.awt.Paint) color58);
        lineAndShapeRenderer2.setPlot(categoryPlot55);
        java.awt.Paint paint62 = lineAndShapeRenderer2.getSeriesOutlinePaint((int) '#');
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(itemLabelPosition38);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(itemLabelAnchor48);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(textAnchor51);
        org.junit.Assert.assertNotNull(textAnchor53);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertNotNull(color58);
        org.junit.Assert.assertNull(paint62);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        categoryPlot0.setDomainCrosshairColumnKey((java.lang.Comparable) (short) -1, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot0.zoomRangeAxes((double) (byte) 1, plotRenderingInfo9, point2D10, true);
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) 0.0f, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot16.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis19 = categoryPlot16.getRangeAxis();
        int int20 = categoryPlot16.getBackgroundImageAlignment();
        java.awt.Paint paint21 = categoryPlot16.getNoDataMessagePaint();
        java.awt.Paint paint22 = categoryPlot16.getRangeMinorGridlinePaint();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot16);
        java.awt.Paint paint24 = categoryPlot16.getDomainGridlinePaint();
        java.awt.Shape shape30 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot31.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis34 = categoryPlot31.getRangeAxis();
        int int35 = categoryPlot31.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder36 = categoryPlot31.getRowRenderingOrder();
        java.awt.Stroke stroke37 = categoryPlot31.getRangeZeroBaselineStroke();
        java.awt.Paint paint38 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem39 = new org.jfree.chart.LegendItem("", "", "hi!", "", shape30, stroke37, paint38);
        legendItem39.setDescription("");
        int int42 = legendItem39.getDatasetIndex();
        java.lang.String str43 = legendItem39.getLabel();
        java.lang.String str44 = legendItem39.getLabel();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset45 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo46 = new org.jfree.chart.event.DatasetChangeInfo();
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent47 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object) legendItem39, (org.jfree.data.general.Dataset) defaultCategoryDataset45, datasetChangeInfo46);
        defaultCategoryDataset45.clearSelection();
        int int49 = defaultCategoryDataset45.getRowCount();
        int int51 = defaultCategoryDataset45.getColumnIndex((java.lang.Comparable) "AxisLocation.BOTTOM_OR_LEFT");
        defaultCategoryDataset45.fireSelectionEvent();
        categoryPlot16.setDataset(10, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset45);
        try {
            defaultCategoryDataset45.incrementValue((double) (byte) -1, (java.lang.Comparable) 64, (java.lang.Comparable) "ItemLabelAnchor.OUTSIDE2");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Row key (64) not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNull(valueAxis19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 15 + "'", int20 == 15);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNull(valueAxis34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 15 + "'", int35 == 15);
        org.junit.Assert.assertNotNull(sortOrder36);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "" + "'", str43.equals(""));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "" + "'", str44.equals(""));
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1) + "'", int51 == (-1));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        lineAndShapeRenderer2.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.data.Range range6 = lineAndShapeRenderer2.findRangeBounds(categoryDataset5);
        org.junit.Assert.assertNull(range6);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        renderAttributes0.setDefaultFillPaint((java.awt.Paint) color1);
        java.awt.Shape shape5 = renderAttributes0.getItemShape((int) (byte) 100, (int) 'a');
        renderAttributes0.setDefaultCreateEntity((java.lang.Boolean) false);
        java.lang.Boolean boolean8 = renderAttributes0.getDefaultLabelVisible();
        java.awt.Paint paint9 = renderAttributes0.getDefaultPaint();
        renderAttributes0.setDefaultLabelVisible((java.lang.Boolean) true);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNull(shape5);
        org.junit.Assert.assertNull(boolean8);
        org.junit.Assert.assertNull(paint9);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = lineAndShapeRenderer2.getBasePositiveItemLabelPosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot4.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = categoryPlot4.getDomainAxisEdge();
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot4.getDomainAxisLocation();
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        categoryPlot4.drawBackgroundImage(graphics2D9, rectangle2D10);
        java.awt.Paint paint12 = categoryPlot4.getNoDataMessagePaint();
        lineAndShapeRenderer2.setBaseItemLabelPaint(paint12);
        java.lang.Boolean boolean15 = lineAndShapeRenderer2.getSeriesShapesFilled(10);
        java.awt.Shape shape16 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity19 = new org.jfree.chart.entity.ChartEntity(shape16, "ChartChangeEventType.GENERAL", "");
        lineAndShapeRenderer2.setBaseShape(shape16, false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer24 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke25 = lineAndShapeRenderer24.getBaseStroke();
        java.awt.Stroke stroke27 = lineAndShapeRenderer24.lookupSeriesStroke(10);
        java.awt.Shape shape31 = lineAndShapeRenderer24.getItemShape((int) (short) 10, 100, true);
        lineAndShapeRenderer24.setBaseSeriesVisible(false);
        boolean boolean34 = lineAndShapeRenderer24.getUseFillPaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition38 = lineAndShapeRenderer24.getPositiveItemLabelPosition((-128), 0, false);
        lineAndShapeRenderer2.setBaseNegativeItemLabelPosition(itemLabelPosition38, false);
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(boolean15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition38);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = categoryAxis1.getTickLabelInsets();
        categoryAxis1.setCategoryLabelPositionOffset(0);
        categoryAxis1.setMinorTickMarksVisible(false);
        float float7 = categoryAxis1.getMinorTickMarkOutsideLength();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = categoryAxis1.getLabelInsets();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis1.setTickMarkPaint((java.awt.Paint) color9);
        float float11 = categoryAxis1.getMinorTickMarkInsideLength();
        boolean boolean12 = categoryAxis1.isAxisLineVisible();
        int int13 = categoryAxis1.getCategoryLabelPositionOffset();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 2.0f + "'", float7 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.0f + "'", float11 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = categoryAxis1.getTickLabelInsets();
        categoryAxis1.setCategoryLabelPositionOffset(0);
        categoryAxis1.setMinorTickMarksVisible(false);
        float float7 = categoryAxis1.getMinorTickMarkOutsideLength();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = categoryAxis1.getLabelInsets();
        float float9 = categoryAxis1.getMinorTickMarkOutsideLength();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 2.0f + "'", float7 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 2.0f + "'", float9 == 2.0f);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        renderAttributes0.setDefaultFillPaint((java.awt.Paint) color1);
        java.awt.Shape shape5 = renderAttributes0.getItemShape((int) (byte) 100, (int) 'a');
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        renderAttributes0.setDefaultShape(shape6);
        renderAttributes0.setDefaultLabelVisible((java.lang.Boolean) true);
        java.awt.Stroke stroke11 = renderAttributes0.getSeriesStroke((-128));
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNull(shape5);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNull(stroke11);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot0.setRangeAxisLocation(axisLocation1, true);
        org.jfree.chart.axis.ValueAxis valueAxis5 = categoryPlot0.getRangeAxis((int) '#');
        categoryPlot0.clearDomainAxes();
        int int7 = categoryPlot0.getRangeAxisCount();
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = categoryAxis1.getTickLabelInsets();
        categoryAxis1.setCategoryLabelPositionOffset(0);
        categoryAxis1.setMinorTickMarksVisible(false);
        float float7 = categoryAxis1.getMinorTickMarkOutsideLength();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = categoryAxis1.getLabelInsets();
        org.jfree.chart.util.UnitType unitType9 = rectangleInsets8.getUnitType();
        java.lang.String str10 = unitType9.toString();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 2.0f + "'", float7 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(unitType9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "UnitType.ABSOLUTE" + "'", str10.equals("UnitType.ABSOLUTE"));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        lineAndShapeRenderer2.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator7);
        lineAndShapeRenderer2.setSeriesVisible((int) (short) 100, (java.lang.Boolean) false, true);
        boolean boolean15 = lineAndShapeRenderer2.getItemShapeVisible((int) (short) 10, 3);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator16 = lineAndShapeRenderer2.getLegendItemLabelGenerator();
        lineAndShapeRenderer2.setSeriesVisible((int) '4', (java.lang.Boolean) true);
        java.awt.Shape shape24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot25.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis28 = categoryPlot25.getRangeAxis();
        int int29 = categoryPlot25.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder30 = categoryPlot25.getRowRenderingOrder();
        java.awt.Stroke stroke31 = categoryPlot25.getRangeZeroBaselineStroke();
        java.awt.Paint paint32 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem33 = new org.jfree.chart.LegendItem("", "", "hi!", "", shape24, stroke31, paint32);
        legendItem33.setDescription("");
        int int36 = legendItem33.getDatasetIndex();
        java.lang.String str37 = legendItem33.getLabel();
        java.lang.String str38 = legendItem33.getLabel();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset39 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo40 = new org.jfree.chart.event.DatasetChangeInfo();
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent41 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object) legendItem33, (org.jfree.data.general.Dataset) defaultCategoryDataset39, datasetChangeInfo40);
        org.jfree.data.Range range42 = lineAndShapeRenderer2.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset39);
        int int44 = defaultCategoryDataset39.getRowIndex((java.lang.Comparable) "PlotEntity: tooltip = ItemLabelAnchor.OUTSIDE1");
        try {
            defaultCategoryDataset39.removeColumn((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator16);
        org.junit.Assert.assertNull(valueAxis28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 15 + "'", int29 == 15);
        org.junit.Assert.assertNotNull(sortOrder30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "" + "'", str37.equals(""));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "" + "'", str38.equals(""));
        org.junit.Assert.assertNull(range42);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Shape shape9 = lineAndShapeRenderer2.getItemShape((int) (short) 10, 100, true);
        lineAndShapeRenderer2.setBaseSeriesVisible(false);
        java.awt.Shape shape12 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity15 = new org.jfree.chart.entity.ChartEntity(shape12, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape16 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity19 = new org.jfree.chart.entity.ChartEntity(shape16, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape20 = chartEntity19.getArea();
        chartEntity15.setArea(shape20);
        lineAndShapeRenderer2.setBaseShape(shape20, true);
        java.lang.Boolean boolean25 = lineAndShapeRenderer2.getSeriesShapesVisible(1);
        java.awt.Font font26 = lineAndShapeRenderer2.getBaseItemLabelFont();
        lineAndShapeRenderer2.setSeriesShapesVisible(1, true);
        lineAndShapeRenderer2.setBaseSeriesVisible(false);
        java.lang.Boolean boolean33 = lineAndShapeRenderer2.getSeriesCreateEntities((-16728064));
        lineAndShapeRenderer2.setBaseSeriesVisibleInLegend(true, true);
        boolean boolean37 = lineAndShapeRenderer2.getBaseItemLabelsVisible();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNull(boolean25);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNull(boolean33);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        java.awt.Color color0 = java.awt.Color.yellow;
        java.awt.color.ColorSpace colorSpace1 = color0.getColorSpace();
        int int2 = color0.getTransparency();
        java.awt.Color color9 = java.awt.Color.getHSBColor((float) (short) 1, (float) 100, 0.0f);
        float[] floatArray16 = new float[] { (byte) 10, (byte) 1, 1.0f, (byte) 0, 10, (byte) 100 };
        float[] floatArray17 = color9.getRGBComponents(floatArray16);
        float[] floatArray18 = java.awt.Color.RGBtoHSB((int) ' ', 1, 255, floatArray16);
        float[] floatArray19 = color0.getRGBComponents(floatArray16);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(colorSpace1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray19);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        boolean boolean9 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.axis.AxisLocation axisLocation11 = null;
        categoryPlot0.setDomainAxisLocation(255, axisLocation11);
        org.jfree.chart.util.SortOrder sortOrder13 = categoryPlot0.getRowRenderingOrder();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot14.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis17 = categoryPlot14.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        categoryPlot14.zoomDomainAxes((double) 10.0f, plotRenderingInfo19, point2D20, false);
        java.lang.Comparable comparable23 = categoryPlot14.getDomainCrosshairColumnKey();
        boolean boolean24 = categoryPlot14.isRangeCrosshairLockedOnData();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = categoryPlot14.getAxisOffset();
        categoryPlot14.setRangeCrosshairVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.data.Range range29 = categoryPlot14.getDataRange(valueAxis28);
        boolean boolean30 = sortOrder13.equals((java.lang.Object) range29);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(sortOrder13);
        org.junit.Assert.assertNull(valueAxis17);
        org.junit.Assert.assertNull(comparable23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNull(range29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder5 = categoryPlot0.getRowRenderingOrder();
        java.awt.Stroke stroke6 = categoryPlot0.getRangeZeroBaselineStroke();
        categoryPlot0.setRangeGridlinesVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot9.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis12 = categoryPlot9.getRangeAxis();
        int int13 = categoryPlot9.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder14 = categoryPlot9.getRowRenderingOrder();
        java.awt.Stroke stroke15 = categoryPlot9.getRangeZeroBaselineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent16 = null;
        categoryPlot9.rendererChanged(rendererChangeEvent16);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation19 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot18.setRangeAxisLocation(axisLocation19, true);
        categoryPlot9.setDomainAxisLocation(axisLocation19);
        categoryPlot0.setDomainAxisLocation(axisLocation19, true);
        boolean boolean25 = categoryPlot0.isSubplot();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(sortOrder5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 15 + "'", int13 == 15);
        org.junit.Assert.assertNotNull(sortOrder14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke7 = lineAndShapeRenderer6.getBaseStroke();
        java.awt.Stroke stroke9 = lineAndShapeRenderer6.lookupSeriesStroke(10);
        java.awt.Shape shape13 = lineAndShapeRenderer6.getItemShape((int) (short) 10, 100, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot14.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis17 = categoryPlot14.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        categoryPlot14.zoomDomainAxes((double) 10.0f, plotRenderingInfo19, point2D20, false);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent23 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot14);
        java.awt.Paint paint24 = categoryPlot14.getDomainCrosshairPaint();
        try {
            org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem(attributedString0, "AxisLocation.BOTTOM_OR_LEFT", "", "", shape13, paint24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNull(valueAxis17);
        org.junit.Assert.assertNotNull(paint24);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Shape shape9 = lineAndShapeRenderer2.getItemShape((int) (short) 10, 100, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator13 = lineAndShapeRenderer2.getItemLabelGenerator((int) 'a', 0, false);
        lineAndShapeRenderer2.clearSeriesStrokes(true);
        java.awt.Stroke stroke17 = lineAndShapeRenderer2.getSeriesOutlineStroke((int) 'a');
        boolean boolean18 = lineAndShapeRenderer2.getBaseShapesVisible();
        java.lang.Boolean boolean20 = lineAndShapeRenderer2.getSeriesCreateEntities((-16728064));
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNull(categoryItemLabelGenerator13);
        org.junit.Assert.assertNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNull(boolean20);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        java.awt.Color color1 = java.awt.Color.GRAY;
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator5 = new org.jfree.chart.util.DefaultShadowGenerator((int) (short) -1, color1, 0.0f, (int) (byte) -1, (double) 'a');
        int int6 = defaultShadowGenerator5.calculateOffsetX();
        java.awt.image.BufferedImage bufferedImage7 = null;
        try {
            java.awt.image.BufferedImage bufferedImage8 = defaultShadowGenerator5.createDropShadow(bufferedImage7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.axis.AxisSpace axisSpace5 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace5, true);
        org.jfree.chart.plot.Marker marker8 = null;
        boolean boolean9 = categoryPlot0.removeDomainMarker(marker8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot0.zoomRangeAxes((double) (-16728064), plotRenderingInfo11, point2D12);
        org.jfree.chart.axis.AxisSpace axisSpace14 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace14);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot16.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis19 = categoryPlot16.getRangeAxis();
        int int20 = categoryPlot16.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder21 = categoryPlot16.getRowRenderingOrder();
        java.awt.Stroke stroke22 = categoryPlot16.getRangeZeroBaselineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent23 = null;
        categoryPlot16.rendererChanged(rendererChangeEvent23);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation26 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot25.setRangeAxisLocation(axisLocation26, true);
        categoryPlot16.setDomainAxisLocation(axisLocation26);
        categoryPlot16.setCrosshairDatasetIndex((int) (short) 1);
        java.awt.Image image32 = categoryPlot16.getBackgroundImage();
        java.awt.Paint paint33 = categoryPlot16.getOutlinePaint();
        org.jfree.chart.plot.PlotOrientation plotOrientation34 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        categoryPlot16.setOrientation(plotOrientation34);
        categoryPlot0.setOrientation(plotOrientation34);
        java.awt.Shape shape41 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot42.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis45 = categoryPlot42.getRangeAxis();
        int int46 = categoryPlot42.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder47 = categoryPlot42.getRowRenderingOrder();
        java.awt.Stroke stroke48 = categoryPlot42.getRangeZeroBaselineStroke();
        java.awt.Paint paint49 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem50 = new org.jfree.chart.LegendItem("", "", "hi!", "", shape41, stroke48, paint49);
        legendItem50.setSeriesIndex((int) (byte) 10);
        java.awt.Shape shape53 = legendItem50.getShape();
        boolean boolean54 = plotOrientation34.equals((java.lang.Object) legendItem50);
        boolean boolean55 = legendItem50.isShapeOutlineVisible();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(valueAxis19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 15 + "'", int20 == 15);
        org.junit.Assert.assertNotNull(sortOrder21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNull(image32);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(plotOrientation34);
        org.junit.Assert.assertNull(valueAxis45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 15 + "'", int46 == 15);
        org.junit.Assert.assertNotNull(sortOrder47);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertNotNull(shape53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        java.awt.Color color1 = java.awt.Color.GRAY;
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator5 = new org.jfree.chart.util.DefaultShadowGenerator((int) (short) -1, color1, 0.0f, (int) (byte) -1, (double) 'a');
        int int6 = defaultShadowGenerator5.calculateOffsetY();
        int int7 = defaultShadowGenerator5.getShadowSize();
        int int8 = defaultShadowGenerator5.calculateOffsetY();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor9 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace10, false);
        org.jfree.chart.axis.AxisLocation axisLocation14 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.axis.AxisLocation axisLocation15 = axisLocation14.getOpposite();
        categoryPlot0.setDomainAxisLocation(1, axisLocation14, true);
        java.awt.Paint paint18 = categoryPlot0.getBackgroundPaint();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(categoryAnchor9);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = categoryAxis1.getTickLabelInsets();
        categoryAxis1.setCategoryLabelPositionOffset(0);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        int int9 = categoryPlot5.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot5.getRowRenderingOrder();
        java.awt.Stroke stroke11 = categoryPlot5.getRangeZeroBaselineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        categoryPlot5.rendererChanged(rendererChangeEvent12);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot14.setRangeAxisLocation(axisLocation15, true);
        categoryPlot5.setDomainAxisLocation(axisLocation15);
        categoryPlot5.setCrosshairDatasetIndex((int) (short) 1);
        categoryAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot5);
        org.jfree.chart.plot.Plot plot22 = categoryAxis1.getPlot();
        java.lang.String str23 = categoryAxis1.getLabelToolTip();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNull(str23);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.getSeriesItemLabelPaint((int) '4');
        boolean boolean3 = barRenderer0.isDrawBarOutline();
        java.awt.Color color7 = java.awt.Color.getHSBColor((float) (short) 1, (float) 100, 0.0f);
        float[] floatArray14 = new float[] { (byte) 10, (byte) 1, 1.0f, (byte) 0, 10, (byte) 100 };
        float[] floatArray15 = color7.getRGBComponents(floatArray14);
        barRenderer0.setBaseLegendTextPaint((java.awt.Paint) color7);
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(floatArray15);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        renderAttributes0.setDefaultFillPaint((java.awt.Paint) color1);
        java.awt.Shape shape5 = renderAttributes0.getItemShape((int) (byte) 100, (int) 'a');
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        renderAttributes0.setDefaultShape(shape6);
        java.awt.Shape shape9 = renderAttributes0.getSeriesShape(0);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer13 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke14 = lineAndShapeRenderer13.getBaseStroke();
        java.awt.Stroke stroke16 = lineAndShapeRenderer13.lookupSeriesStroke(10);
        java.awt.Shape shape20 = lineAndShapeRenderer13.getItemShape((int) (short) 10, 100, true);
        lineAndShapeRenderer13.setBaseSeriesVisible(false);
        java.awt.Shape shape23 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity26 = new org.jfree.chart.entity.ChartEntity(shape23, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape27 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity30 = new org.jfree.chart.entity.ChartEntity(shape27, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape31 = chartEntity30.getArea();
        chartEntity26.setArea(shape31);
        lineAndShapeRenderer13.setBaseShape(shape31, true);
        java.lang.Boolean boolean36 = lineAndShapeRenderer13.getSeriesShapesVisible(1);
        java.awt.Font font37 = lineAndShapeRenderer13.getBaseItemLabelFont();
        lineAndShapeRenderer13.setSeriesShapesVisible(1, true);
        java.awt.Color color43 = java.awt.Color.GRAY;
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator47 = new org.jfree.chart.util.DefaultShadowGenerator((int) (short) -1, color43, 0.0f, (int) (byte) -1, (double) 'a');
        lineAndShapeRenderer13.setSeriesFillPaint(64, (java.awt.Paint) color43);
        renderAttributes0.setSeriesPaint((int) (short) 1, (java.awt.Paint) color43);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNull(shape5);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNull(shape9);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNull(boolean36);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNotNull(color43);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        categoryPlot0.setRangeCrosshairVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        int int9 = categoryPlot5.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot5.getRowRenderingOrder();
        java.awt.Stroke stroke11 = categoryPlot5.getRangeZeroBaselineStroke();
        categoryPlot5.setRangeGridlinesVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot14.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis17 = categoryPlot14.getRangeAxis();
        int int18 = categoryPlot14.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder19 = categoryPlot14.getRowRenderingOrder();
        java.awt.Stroke stroke20 = categoryPlot14.getRangeZeroBaselineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent21 = null;
        categoryPlot14.rendererChanged(rendererChangeEvent21);
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation24 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot23.setRangeAxisLocation(axisLocation24, true);
        categoryPlot14.setDomainAxisLocation(axisLocation24);
        categoryPlot5.setDomainAxisLocation(axisLocation24, true);
        categoryPlot5.setBackgroundAlpha((float) 10);
        org.jfree.chart.axis.AxisLocation axisLocation32 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.axis.AxisLocation axisLocation33 = axisLocation32.getOpposite();
        categoryPlot5.setRangeAxisLocation(axisLocation33);
        categoryPlot0.setDomainAxisLocation(axisLocation33, false);
        org.jfree.chart.plot.Marker marker38 = null;
        org.jfree.chart.util.Layer layer39 = null;
        try {
            categoryPlot0.addRangeMarker((int) (byte) 10, marker38, layer39, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(valueAxis17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 15 + "'", int18 == 15);
        org.junit.Assert.assertNotNull(sortOrder19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertNotNull(axisLocation32);
        org.junit.Assert.assertNotNull(axisLocation33);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder5 = categoryPlot0.getRowRenderingOrder();
        java.awt.Stroke stroke6 = categoryPlot0.getRangeZeroBaselineStroke();
        categoryPlot0.setRangeGridlinesVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot9.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis12 = categoryPlot9.getRangeAxis();
        int int13 = categoryPlot9.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder14 = categoryPlot9.getRowRenderingOrder();
        java.awt.Stroke stroke15 = categoryPlot9.getRangeZeroBaselineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent16 = null;
        categoryPlot9.rendererChanged(rendererChangeEvent16);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation19 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot18.setRangeAxisLocation(axisLocation19, true);
        categoryPlot9.setDomainAxisLocation(axisLocation19);
        categoryPlot0.setDomainAxisLocation(axisLocation19, true);
        org.jfree.data.general.DatasetGroup datasetGroup25 = categoryPlot0.getDatasetGroup();
        java.awt.Paint paint26 = categoryPlot0.getOutlinePaint();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(sortOrder5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 15 + "'", int13 == 15);
        org.junit.Assert.assertNotNull(sortOrder14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNull(datasetGroup25);
        org.junit.Assert.assertNotNull(paint26);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        renderAttributes0.setDefaultFillPaint((java.awt.Paint) color1);
        java.awt.Shape shape5 = renderAttributes0.getItemShape((int) (byte) 100, (int) 'a');
        java.awt.Shape shape7 = null;
        renderAttributes0.setSeriesShape((int) (byte) 1, shape7);
        java.awt.Paint paint9 = renderAttributes0.getDefaultFillPaint();
        java.awt.Paint paint11 = renderAttributes0.getSeriesFillPaint(3);
        java.awt.Paint paint12 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        renderAttributes0.setDefaultPaint(paint12);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNull(shape5);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder5 = categoryPlot0.getRowRenderingOrder();
        java.awt.Stroke stroke6 = categoryPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = categoryPlot0.getInsets();
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = categoryPlot0.getRangeAxisEdge();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(sortOrder5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNotNull(rectangleEdge9);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Color color1 = color0.darker();
        int int2 = color0.getTransparency();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        lineAndShapeRenderer2.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator7);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = lineAndShapeRenderer2.getSeriesPositiveItemLabelPosition(0);
        lineAndShapeRenderer2.setBaseShapesFilled(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
        lineAndShapeRenderer2.notifyListeners(rendererChangeEvent13);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot15.clearDomainMarkers((int) (short) 10);
        categoryPlot15.setDomainGridlinesVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot20.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis23 = categoryPlot20.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        categoryPlot20.zoomDomainAxes((double) 10.0f, plotRenderingInfo25, point2D26, false);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent29 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot20);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType30 = plotChangeEvent29.getType();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType31 = plotChangeEvent29.getType();
        java.lang.Object obj32 = plotChangeEvent29.getSource();
        categoryPlot15.notifyListeners(plotChangeEvent29);
        java.awt.Stroke stroke34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot15.setOutlineStroke(stroke34);
        lineAndShapeRenderer2.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot15);
        org.jfree.chart.LegendItemCollection legendItemCollection37 = lineAndShapeRenderer2.getLegendItems();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(chartChangeEventType30);
        org.junit.Assert.assertNotNull(chartChangeEventType31);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(legendItemCollection37);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = categoryAxis1.getTickLabelInsets();
        categoryAxis1.setCategoryLabelPositionOffset(0);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        int int9 = categoryPlot5.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot5.getRowRenderingOrder();
        java.awt.Stroke stroke11 = categoryPlot5.getRangeZeroBaselineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        categoryPlot5.rendererChanged(rendererChangeEvent12);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot14.setRangeAxisLocation(axisLocation15, true);
        categoryPlot5.setDomainAxisLocation(axisLocation15);
        categoryPlot5.setCrosshairDatasetIndex((int) (short) 1);
        categoryAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot5);
        boolean boolean22 = categoryPlot5.isRangeZeroBaselineVisible();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = categoryAxis1.getTickLabelInsets();
        categoryAxis1.setCategoryLabelPositionOffset(0);
        categoryAxis1.setMinorTickMarksVisible(false);
        float float7 = categoryAxis1.getMinorTickMarkOutsideLength();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = categoryAxis1.getLabelInsets();
        org.jfree.chart.util.UnitType unitType9 = rectangleInsets8.getUnitType();
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D11 = rectangleInsets8.createInsetRectangle(rectangle2D10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 2.0f + "'", float7 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(unitType9);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier4 = categoryPlot0.getDrawingSupplier();
        java.awt.Paint paint5 = categoryPlot0.getOutlinePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot6.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis9 = categoryPlot6.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot6.zoomDomainAxes((double) 10.0f, plotRenderingInfo11, point2D12, false);
        boolean boolean15 = categoryPlot6.isRangeCrosshairVisible();
        org.jfree.chart.axis.AxisLocation axisLocation17 = null;
        categoryPlot6.setDomainAxisLocation(255, axisLocation17);
        org.jfree.chart.util.SortOrder sortOrder19 = categoryPlot6.getRowRenderingOrder();
        categoryPlot0.setRowRenderingOrder(sortOrder19);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(drawingSupplier4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(sortOrder19);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder5 = categoryPlot0.getRowRenderingOrder();
        categoryPlot0.setWeight((int) (short) 100);
        boolean boolean8 = categoryPlot0.isDomainCrosshairVisible();
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot0.getRangeAxisLocation();
        java.awt.Paint paint10 = categoryPlot0.getNoDataMessagePaint();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(sortOrder5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot0.setRangeAxisLocation(axisLocation1, true);
        java.util.List list4 = categoryPlot0.getAnnotations();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        categoryPlot0.setDomainAxis((int) (byte) 0, categoryAxis6, false);
        java.util.List list9 = categoryPlot0.getCategories();
        java.awt.Stroke stroke10 = categoryPlot0.getDomainCrosshairStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = categoryAxis13.getTickLabelInsets();
        categoryAxis13.setCategoryLabelPositionOffset(0);
        categoryAxis13.setMinorTickMarksVisible(false);
        float float19 = categoryAxis13.getMinorTickMarkOutsideLength();
        boolean boolean20 = categoryAxis13.isVisible();
        categoryAxis13.setTickMarkOutsideLength((float) 10L);
        float float23 = categoryAxis13.getTickMarkOutsideLength();
        int int24 = categoryAxis13.getCategoryLabelPositionOffset();
        try {
            categoryPlot0.setDomainAxis((-128), categoryAxis13, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNull(list9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 10.0f + "'", float23 == 10.0f);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier4 = categoryPlot0.getDrawingSupplier();
        java.awt.Stroke stroke5 = categoryPlot0.getOutlineStroke();
        org.jfree.chart.plot.Plot plot6 = categoryPlot0.getParent();
        categoryPlot0.setDrawSharedDomainAxis(false);
        categoryPlot0.setRangeCrosshairValue(7.0d, true);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(drawingSupplier4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNull(plot6);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("ItemLabelAnchor.OUTSIDE1");
        java.lang.Throwable[] throwableArray2 = unknownKeyException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder5 = categoryPlot0.getRowRenderingOrder();
        java.awt.Stroke stroke6 = categoryPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        int int8 = categoryPlot0.getIndexOf(categoryItemRenderer7);
        java.awt.Stroke stroke9 = categoryPlot0.getRangeMinorGridlineStroke();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(sortOrder5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        categoryPlot0.setDomainCrosshairColumnKey((java.lang.Comparable) (short) -1, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot0.zoomRangeAxes((double) (byte) 1, plotRenderingInfo9, point2D10, true);
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) 0.0f, false);
        categoryPlot0.setRangeCrosshairVisible(false);
        boolean boolean18 = categoryPlot0.isDomainPannable();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition0 = new org.jfree.chart.labels.ItemLabelPosition();
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        java.lang.Object obj1 = strokeList0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Shape shape9 = lineAndShapeRenderer2.getItemShape((int) (short) 10, 100, true);
        lineAndShapeRenderer2.setBaseSeriesVisible(false);
        java.awt.Shape shape12 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity15 = new org.jfree.chart.entity.ChartEntity(shape12, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape16 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity19 = new org.jfree.chart.entity.ChartEntity(shape16, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape20 = chartEntity19.getArea();
        chartEntity15.setArea(shape20);
        lineAndShapeRenderer2.setBaseShape(shape20, true);
        java.lang.Boolean boolean25 = lineAndShapeRenderer2.getSeriesShapesVisible(1);
        java.awt.Font font26 = lineAndShapeRenderer2.getBaseItemLabelFont();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator28 = lineAndShapeRenderer2.getSeriesItemLabelGenerator(64);
        try {
            lineAndShapeRenderer2.setSeriesLinesVisible((-256), true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNull(boolean25);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNull(categoryItemLabelGenerator28);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape0, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape4 = chartEntity3.getArea();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier9 = categoryPlot5.getDrawingSupplier();
        org.jfree.data.category.CategoryDataset categoryDataset10 = categoryPlot5.getDataset();
        org.jfree.chart.renderer.RenderAttributes renderAttributes11 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        renderAttributes11.setDefaultFillPaint((java.awt.Paint) color12);
        categoryPlot5.setBackgroundPaint((java.awt.Paint) color12);
        org.jfree.chart.axis.ValueAxis valueAxis15 = categoryPlot5.getRangeAxis();
        org.jfree.chart.entity.PlotEntity plotEntity18 = new org.jfree.chart.entity.PlotEntity(shape4, (org.jfree.chart.plot.Plot) categoryPlot5, "ChartChangeEventType.GENERAL", "hi!");
        java.lang.Object obj19 = plotEntity18.clone();
        java.lang.String str20 = plotEntity18.getToolTipText();
        java.lang.Object obj21 = plotEntity18.clone();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertNotNull(drawingSupplier9);
        org.junit.Assert.assertNull(categoryDataset10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNull(valueAxis15);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "ChartChangeEventType.GENERAL" + "'", str20.equals("ChartChangeEventType.GENERAL"));
        org.junit.Assert.assertNotNull(obj21);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.clearSeriesStrokes(true);
        java.lang.Boolean boolean4 = lineAndShapeRenderer0.getSeriesVisibleInLegend(3);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator6 = lineAndShapeRenderer0.getSeriesURLGenerator((-1));
        lineAndShapeRenderer0.setAutoPopulateSeriesStroke(true);
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertNull(categoryURLGenerator6);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier4 = categoryPlot0.getDrawingSupplier();
        java.awt.Stroke stroke5 = categoryPlot0.getOutlineStroke();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = categoryPlot0.getRenderer();
        boolean boolean7 = categoryPlot0.isDomainCrosshairVisible();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(drawingSupplier4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNull(categoryItemRenderer6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getMinimumBarLength();
        java.awt.Paint paint5 = barRenderer0.getItemPaint(0, 15, true);
        java.awt.Paint paint7 = barRenderer0.getSeriesItemLabelPaint((int) 'a');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(paint7);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = lineAndShapeRenderer2.getBasePositiveItemLabelPosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot4.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = categoryPlot4.getDomainAxisEdge();
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot4.getDomainAxisLocation();
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        categoryPlot4.drawBackgroundImage(graphics2D9, rectangle2D10);
        java.awt.Paint paint12 = categoryPlot4.getNoDataMessagePaint();
        lineAndShapeRenderer2.setBaseItemLabelPaint(paint12);
        java.lang.Boolean boolean15 = lineAndShapeRenderer2.getSeriesShapesFilled(10);
        java.awt.Shape shape16 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity19 = new org.jfree.chart.entity.ChartEntity(shape16, "ChartChangeEventType.GENERAL", "");
        lineAndShapeRenderer2.setBaseShape(shape16, false);
        java.awt.Stroke stroke25 = lineAndShapeRenderer2.getItemOutlineStroke(100, 0, false);
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(boolean15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(stroke25);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.axis.AxisSpace axisSpace5 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace5, true);
        org.jfree.chart.plot.Marker marker8 = null;
        boolean boolean9 = categoryPlot0.removeDomainMarker(marker8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot0.zoomRangeAxes((double) (-16728064), plotRenderingInfo11, point2D12);
        org.jfree.chart.axis.AxisSpace axisSpace14 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace14);
        int int16 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot18.clearDomainMarkers((int) (short) 10);
        categoryPlot18.setRangeCrosshairVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot23.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis26 = categoryPlot23.getRangeAxis();
        int int27 = categoryPlot23.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder28 = categoryPlot23.getRowRenderingOrder();
        java.awt.Stroke stroke29 = categoryPlot23.getRangeZeroBaselineStroke();
        categoryPlot23.setRangeGridlinesVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot32.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis35 = categoryPlot32.getRangeAxis();
        int int36 = categoryPlot32.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder37 = categoryPlot32.getRowRenderingOrder();
        java.awt.Stroke stroke38 = categoryPlot32.getRangeZeroBaselineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent39 = null;
        categoryPlot32.rendererChanged(rendererChangeEvent39);
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation42 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot41.setRangeAxisLocation(axisLocation42, true);
        categoryPlot32.setDomainAxisLocation(axisLocation42);
        categoryPlot23.setDomainAxisLocation(axisLocation42, true);
        categoryPlot23.setBackgroundAlpha((float) 10);
        org.jfree.chart.axis.AxisLocation axisLocation50 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.axis.AxisLocation axisLocation51 = axisLocation50.getOpposite();
        categoryPlot23.setRangeAxisLocation(axisLocation51);
        categoryPlot18.setDomainAxisLocation(axisLocation51, false);
        categoryPlot0.setDomainAxisLocation(100, axisLocation51, false);
        java.lang.Comparable comparable57 = categoryPlot0.getDomainCrosshairColumnKey();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNull(valueAxis26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 15 + "'", int27 == 15);
        org.junit.Assert.assertNotNull(sortOrder28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNull(valueAxis35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 15 + "'", int36 == 15);
        org.junit.Assert.assertNotNull(sortOrder37);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(axisLocation42);
        org.junit.Assert.assertNotNull(axisLocation50);
        org.junit.Assert.assertNotNull(axisLocation51);
        org.junit.Assert.assertNull(comparable57);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Paint paint6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        lineAndShapeRenderer2.setBaseOutlinePaint(paint6);
        org.jfree.chart.renderer.RenderAttributes renderAttributes9 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        renderAttributes9.setDefaultFillPaint((java.awt.Paint) color10);
        java.awt.Stroke stroke13 = renderAttributes9.getSeriesStroke((int) ' ');
        java.awt.Shape shape15 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity18 = new org.jfree.chart.entity.ChartEntity(shape15, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape19 = chartEntity18.getArea();
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot20.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis23 = categoryPlot20.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        categoryPlot20.zoomDomainAxes((double) 10.0f, plotRenderingInfo25, point2D26, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor29 = categoryPlot20.getDomainGridlinePosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot30.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis33 = categoryPlot30.getRangeAxis();
        int int34 = categoryPlot30.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder35 = categoryPlot30.getRowRenderingOrder();
        java.awt.Stroke stroke36 = categoryPlot30.getRangeZeroBaselineStroke();
        categoryPlot20.setRangeMinorGridlineStroke(stroke36);
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = categoryPlot20.getDomainAxis(100);
        boolean boolean40 = categoryPlot20.isNotify();
        org.jfree.chart.entity.PlotEntity plotEntity42 = new org.jfree.chart.entity.PlotEntity(shape19, (org.jfree.chart.plot.Plot) categoryPlot20, "ItemLabelAnchor.OUTSIDE1");
        renderAttributes9.setSeriesShape((int) (byte) 100, shape19);
        lineAndShapeRenderer2.setSeriesShape(128, shape19, false);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent46 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) lineAndShapeRenderer2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNull(stroke13);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(categoryAnchor29);
        org.junit.Assert.assertNull(valueAxis33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 15 + "'", int34 == 15);
        org.junit.Assert.assertNotNull(sortOrder35);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNull(categoryAxis39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder5 = categoryPlot0.getRowRenderingOrder();
        java.awt.Stroke stroke6 = categoryPlot0.getRangeZeroBaselineStroke();
        categoryPlot0.setRangeGridlinesVisible(false);
        categoryPlot0.clearRangeMarkers(100);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(sortOrder5);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.clearSeriesStrokes(true);
        lineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(true);
        java.awt.Stroke stroke5 = lineAndShapeRenderer0.getBaseOutlineStroke();
        boolean boolean6 = lineAndShapeRenderer0.getBaseCreateEntities();
        lineAndShapeRenderer0.setDefaultEntityRadius(255);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        try {
            keyedObjects2D0.removeRow((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getMinimumBarLength();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = null;
        barRenderer0.setSeriesURLGenerator((int) (short) 0, categoryURLGenerator3);
        boolean boolean6 = barRenderer0.isSeriesVisibleInLegend(0);
        org.jfree.chart.LegendItem legendItem9 = barRenderer0.getLegendItem((int) (short) 100, 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = categoryAxis11.getTickLabelInsets();
        categoryAxis11.setCategoryLabelPositionOffset(0);
        categoryAxis11.setMinorTickMarksVisible(false);
        float float17 = categoryAxis11.getMinorTickMarkOutsideLength();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = categoryAxis11.getLabelInsets();
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis11.setTickMarkPaint((java.awt.Paint) color19);
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot21.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis24 = categoryPlot21.getRangeAxis();
        int int25 = categoryPlot21.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder26 = categoryPlot21.getRowRenderingOrder();
        java.awt.Stroke stroke27 = categoryPlot21.getRangeZeroBaselineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent28 = null;
        categoryPlot21.rendererChanged(rendererChangeEvent28);
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation31 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot30.setRangeAxisLocation(axisLocation31, true);
        categoryPlot21.setDomainAxisLocation(axisLocation31);
        categoryAxis11.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot21);
        categoryPlot21.clearRangeAxes();
        boolean boolean37 = barRenderer0.hasListener((java.util.EventListener) categoryPlot21);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(legendItem9);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 2.0f + "'", float17 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNull(valueAxis24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 15 + "'", int25 == 15);
        org.junit.Assert.assertNotNull(sortOrder26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        java.awt.Shape shape4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        int int9 = categoryPlot5.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot5.getRowRenderingOrder();
        java.awt.Stroke stroke11 = categoryPlot5.getRangeZeroBaselineStroke();
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("", "", "hi!", "", shape4, stroke11, paint12);
        legendItem13.setDescription("");
        int int16 = legendItem13.getDatasetIndex();
        java.lang.String str17 = legendItem13.getLabel();
        java.awt.Paint paint18 = legendItem13.getOutlinePaint();
        legendItem13.setDatasetIndex((int) (short) 100);
        legendItem13.setSeriesKey((java.lang.Comparable) "java.awt.Color[r=0,g=0,b=0]");
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isOutlineVisible();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis5 = categoryPlot2.getRangeAxis();
        int int6 = categoryPlot2.getBackgroundImageAlignment();
        categoryPlot2.setDomainCrosshairColumnKey((java.lang.Comparable) (short) -1, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot2.zoomRangeAxes((double) (byte) 1, plotRenderingInfo11, point2D12, true);
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        categoryPlot2.drawBackgroundImage(graphics2D15, rectangle2D16);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot18.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis21 = categoryPlot18.getRangeAxis();
        int int22 = categoryPlot18.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder23 = categoryPlot18.getRowRenderingOrder();
        java.awt.Stroke stroke24 = categoryPlot18.getRangeZeroBaselineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent25 = null;
        categoryPlot18.rendererChanged(rendererChangeEvent25);
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation28 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot27.setRangeAxisLocation(axisLocation28, true);
        categoryPlot18.setDomainAxisLocation(axisLocation28);
        categoryPlot18.setCrosshairDatasetIndex((int) (short) 1);
        java.awt.Image image34 = categoryPlot18.getBackgroundImage();
        java.awt.Paint paint35 = categoryPlot18.getOutlinePaint();
        org.jfree.chart.plot.PlotOrientation plotOrientation36 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        categoryPlot18.setOrientation(plotOrientation36);
        categoryPlot2.setOrientation(plotOrientation36);
        categoryPlot0.setOrientation(plotOrientation36);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
        org.junit.Assert.assertNull(valueAxis21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 15 + "'", int22 == 15);
        org.junit.Assert.assertNotNull(sortOrder23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertNull(image34);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(plotOrientation36);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        lineAndShapeRenderer2.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator7);
        lineAndShapeRenderer2.setSeriesVisible((int) (short) 100, (java.lang.Boolean) false, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator13 = null;
        lineAndShapeRenderer2.setBaseItemLabelGenerator(categoryItemLabelGenerator13);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent9 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot0);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis13 = categoryPlot10.getRangeAxis();
        int int14 = categoryPlot10.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder15 = categoryPlot10.getRowRenderingOrder();
        java.awt.Stroke stroke16 = categoryPlot10.getRangeZeroBaselineStroke();
        categoryPlot0.setOutlineStroke(stroke16);
        categoryPlot0.setRangeCrosshairVisible(false);
        categoryPlot0.setAnchorValue(8.0d);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer25 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke26 = lineAndShapeRenderer25.getBaseStroke();
        java.awt.Stroke stroke28 = lineAndShapeRenderer25.lookupSeriesStroke(10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator30 = null;
        lineAndShapeRenderer25.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator30);
        lineAndShapeRenderer25.setSeriesVisible((int) (short) 100, (java.lang.Boolean) false, true);
        java.awt.Paint paint36 = lineAndShapeRenderer25.getBaseOutlinePaint();
        lineAndShapeRenderer25.setSeriesCreateEntities(10, (java.lang.Boolean) false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent40 = null;
        lineAndShapeRenderer25.notifyListeners(rendererChangeEvent40);
        categoryPlot0.setRenderer(2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer25, true);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNull(valueAxis13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 15 + "'", int14 == 15);
        org.junit.Assert.assertNotNull(sortOrder15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(paint36);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = categoryAxis1.getTickLabelInsets();
        categoryAxis1.setCategoryLabelPositionOffset(0);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions5 = categoryAxis1.getCategoryLabelPositions();
        categoryAxis1.configure();
        java.awt.Shape shape11 = null;
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", shape11, (java.awt.Paint) color12);
        java.awt.color.ColorSpace colorSpace14 = color12.getColorSpace();
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_CYAN;
        boolean boolean16 = color12.equals((java.lang.Object) color15);
        categoryAxis1.setTickLabelPaint((java.awt.Paint) color15);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot18.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis21 = categoryPlot18.getRangeAxis();
        int int22 = categoryPlot18.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder23 = categoryPlot18.getRowRenderingOrder();
        java.awt.Stroke stroke24 = categoryPlot18.getRangeZeroBaselineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = categoryPlot18.getInsets();
        double double26 = rectangleInsets25.getBottom();
        categoryAxis1.setLabelInsets(rectangleInsets25, false);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(categoryLabelPositions5);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(colorSpace14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(valueAxis21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 15 + "'", int22 == 15);
        org.junit.Assert.assertNotNull(sortOrder23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 4.0d + "'", double26 == 4.0d);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        lineAndShapeRenderer2.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator7);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = lineAndShapeRenderer2.getSeriesPositiveItemLabelPosition(0);
        java.lang.Boolean boolean12 = lineAndShapeRenderer2.getSeriesShapesFilled((int) (byte) 100);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertNull(boolean12);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity(shape4, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape8 = chartEntity7.getArea();
        java.awt.Shape shape9 = chartEntity7.getArea();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = categoryPlot10.getDomainAxisEdge();
        int int14 = categoryPlot10.getWeight();
        java.lang.Comparable comparable15 = categoryPlot10.getDomainCrosshairColumnKey();
        boolean boolean16 = categoryPlot10.canSelectByRegion();
        org.jfree.chart.axis.AxisLocation axisLocation17 = categoryPlot10.getRangeAxisLocation();
        org.jfree.chart.entity.PlotEntity plotEntity20 = new org.jfree.chart.entity.PlotEntity(shape9, (org.jfree.chart.plot.Plot) categoryPlot10, "ItemLabelAnchor.OUTSIDE1", "java.awt.Color[r=0,g=0,b=0]");
        java.awt.Color color21 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem22 = new org.jfree.chart.LegendItem("rect", "GradientPaintTransformType.CENTER_HORIZONTAL", "hi!", "AxisLocation.BOTTOM_OR_LEFT", shape9, (java.awt.Paint) color21);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNull(comparable15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(color21);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        java.lang.Comparable comparable9 = categoryPlot0.getDomainCrosshairColumnKey();
        boolean boolean10 = categoryPlot0.isRangeCrosshairLockedOnData();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        categoryPlot0.setDomainCrosshairPaint((java.awt.Paint) color11);
        java.awt.Shape shape17 = null;
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem19 = new org.jfree.chart.LegendItem("", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", shape17, (java.awt.Paint) color18);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color18);
        categoryPlot0.clearAnnotations();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNull(comparable9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color18);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape2, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape6 = chartEntity5.getArea();
        java.awt.Shape shape7 = chartEntity5.getArea();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot8.getDomainAxisEdge();
        int int12 = categoryPlot8.getWeight();
        java.lang.Comparable comparable13 = categoryPlot8.getDomainCrosshairColumnKey();
        boolean boolean14 = categoryPlot8.canSelectByRegion();
        org.jfree.chart.axis.AxisLocation axisLocation15 = categoryPlot8.getRangeAxisLocation();
        org.jfree.chart.entity.PlotEntity plotEntity18 = new org.jfree.chart.entity.PlotEntity(shape7, (org.jfree.chart.plot.Plot) categoryPlot8, "ItemLabelAnchor.OUTSIDE1", "java.awt.Color[r=0,g=0,b=0]");
        shapeList0.setShape(156, shape7);
        java.awt.Shape shape21 = shapeList0.getShape((int) (byte) 1);
        java.awt.Shape shape23 = shapeList0.getShape(8);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNull(comparable13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNull(shape21);
        org.junit.Assert.assertNull(shape23);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder5 = categoryPlot0.getRowRenderingOrder();
        categoryPlot0.setWeight((int) (short) 100);
        boolean boolean8 = categoryPlot0.isDomainCrosshairVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection9 = categoryPlot0.getLegendItems();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis13 = categoryPlot10.getRangeAxis();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier14 = categoryPlot10.getDrawingSupplier();
        java.awt.Paint paint15 = categoryPlot10.getOutlinePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot16.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis19 = categoryPlot16.getRangeAxis();
        int int20 = categoryPlot16.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder21 = categoryPlot16.getRowRenderingOrder();
        java.awt.Stroke stroke22 = categoryPlot16.getRangeZeroBaselineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent23 = null;
        categoryPlot16.rendererChanged(rendererChangeEvent23);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation26 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot25.setRangeAxisLocation(axisLocation26, true);
        categoryPlot16.setDomainAxisLocation(axisLocation26);
        categoryPlot16.setCrosshairDatasetIndex((int) (short) 1);
        org.jfree.data.category.CategoryDataset categoryDataset32 = categoryPlot16.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = categoryPlot16.getAxisOffset();
        categoryPlot10.setAxisOffset(rectangleInsets33);
        double double36 = rectangleInsets33.extendWidth((-1.0d));
        categoryPlot0.setInsets(rectangleInsets33, false);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(sortOrder5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(legendItemCollection9);
        org.junit.Assert.assertNull(valueAxis13);
        org.junit.Assert.assertNotNull(drawingSupplier14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNull(valueAxis19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 15 + "'", int20 == 15);
        org.junit.Assert.assertNotNull(sortOrder21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNull(categoryDataset32);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 7.0d + "'", double36 == 7.0d);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        try {
            java.lang.Comparable comparable2 = keyedObjects2D0.getColumnKey(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryPlot0.getAxisOffset();
        org.jfree.chart.util.UnitType unitType4 = rectangleInsets3.getUnitType();
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D6 = rectangleInsets3.createInsetRectangle(rectangle2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(unitType4);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge();
        org.jfree.chart.axis.AxisLocation axisLocation4 = categoryPlot0.getDomainAxisLocation();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        categoryPlot0.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot9.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = categoryPlot9.getDomainAxisEdge();
        int int13 = categoryPlot9.getWeight();
        java.lang.Comparable comparable14 = categoryPlot9.getDomainCrosshairColumnKey();
        boolean boolean15 = categoryPlot9.canSelectByRegion();
        org.jfree.chart.axis.AxisLocation axisLocation16 = categoryPlot9.getRangeAxisLocation();
        categoryPlot0.setDomainAxisLocation((int) (byte) 0, axisLocation16);
        org.jfree.chart.axis.AxisLocation axisLocation18 = axisLocation16.getOpposite();
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNull(comparable14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(axisLocation18);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape0, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape4 = chartEntity3.getArea();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier9 = categoryPlot5.getDrawingSupplier();
        org.jfree.data.category.CategoryDataset categoryDataset10 = categoryPlot5.getDataset();
        org.jfree.chart.renderer.RenderAttributes renderAttributes11 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        renderAttributes11.setDefaultFillPaint((java.awt.Paint) color12);
        categoryPlot5.setBackgroundPaint((java.awt.Paint) color12);
        org.jfree.chart.axis.ValueAxis valueAxis15 = categoryPlot5.getRangeAxis();
        org.jfree.chart.entity.PlotEntity plotEntity18 = new org.jfree.chart.entity.PlotEntity(shape4, (org.jfree.chart.plot.Plot) categoryPlot5, "ChartChangeEventType.GENERAL", "hi!");
        java.lang.Object obj19 = plotEntity18.clone();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertNotNull(drawingSupplier9);
        org.junit.Assert.assertNull(categoryDataset10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNull(valueAxis15);
        org.junit.Assert.assertNotNull(obj19);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape0, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity(shape4, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape8 = chartEntity7.getArea();
        chartEntity3.setArea(shape8);
        java.lang.String str10 = chartEntity3.getShapeCoords();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-4,-4,4,4" + "'", str10.equals("-4,-4,4,4"));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        renderAttributes0.setDefaultFillPaint((java.awt.Paint) color1);
        java.awt.Shape shape5 = renderAttributes0.getItemShape((int) (byte) 100, (int) 'a');
        java.awt.Shape shape7 = null;
        renderAttributes0.setSeriesShape((int) (byte) 1, shape7);
        java.awt.Color color10 = java.awt.Color.MAGENTA;
        renderAttributes0.setSeriesFillPaint((int) (short) 10, (java.awt.Paint) color10);
        java.lang.Boolean boolean12 = renderAttributes0.getDefaultLabelVisible();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNull(shape5);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNull(boolean12);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        java.awt.Shape shape4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        int int9 = categoryPlot5.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot5.getRowRenderingOrder();
        java.awt.Stroke stroke11 = categoryPlot5.getRangeZeroBaselineStroke();
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("", "", "hi!", "", shape4, stroke11, paint12);
        legendItem13.setDescription("");
        int int16 = legendItem13.getDatasetIndex();
        legendItem13.setToolTipText("SortOrder.ASCENDING");
        boolean boolean19 = legendItem13.isShapeOutlineVisible();
        boolean boolean20 = legendItem13.isShapeFilled();
        legendItem13.setDescription("GradientPaintTransformType.CENTER_HORIZONTAL");
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        java.awt.Shape shape4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        int int9 = categoryPlot5.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot5.getRowRenderingOrder();
        java.awt.Stroke stroke11 = categoryPlot5.getRangeZeroBaselineStroke();
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("", "", "hi!", "", shape4, stroke11, paint12);
        legendItem13.setDescription("");
        int int16 = legendItem13.getDatasetIndex();
        legendItem13.setToolTipText("SortOrder.ASCENDING");
        java.awt.Stroke stroke19 = legendItem13.getLineStroke();
        java.lang.String str20 = legendItem13.getToolTipText();
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "SortOrder.ASCENDING" + "'", str20.equals("SortOrder.ASCENDING"));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor9 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        categoryPlot0.setRenderer(categoryItemRenderer10, false);
        java.awt.Stroke stroke13 = categoryPlot0.getRangeMinorGridlineStroke();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(categoryAnchor9);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE10;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis4 = categoryPlot1.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot1.zoomDomainAxes((double) 10.0f, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor10 = categoryPlot1.getDomainGridlinePosition();
        boolean boolean11 = itemLabelAnchor0.equals((java.lang.Object) categoryAnchor10);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot12.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis15 = categoryPlot12.getRangeAxis();
        int int16 = categoryPlot12.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder17 = categoryPlot12.getRowRenderingOrder();
        categoryPlot12.setWeight((int) (short) 100);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder20 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        categoryPlot12.setDatasetRenderingOrder(datasetRenderingOrder20);
        boolean boolean22 = categoryAnchor10.equals((java.lang.Object) categoryPlot12);
        boolean boolean23 = categoryPlot12.isDomainZoomable();
        java.awt.Paint paint24 = categoryPlot12.getRangeZeroBaselinePaint();
        float float25 = categoryPlot12.getBackgroundAlpha();
        java.awt.Color color26 = java.awt.Color.blue;
        categoryPlot12.setRangeZeroBaselinePaint((java.awt.Paint) color26);
        float float28 = categoryPlot12.getBackgroundAlpha();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertNotNull(categoryAnchor10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(valueAxis15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 15 + "'", int16 == 15);
        org.junit.Assert.assertNotNull(sortOrder17);
        org.junit.Assert.assertNotNull(datasetRenderingOrder20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 1.0f + "'", float25 == 1.0f);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + float28 + "' != '" + 1.0f + "'", float28 == 1.0f);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder5 = categoryPlot0.getRowRenderingOrder();
        categoryPlot0.mapDatasetToRangeAxis((int) '#', (int) (byte) 10);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace9);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(sortOrder5);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        java.awt.Color color0 = java.awt.Color.lightGray;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot1.getDomainAxisEdge();
        org.jfree.chart.axis.AxisLocation axisLocation5 = categoryPlot1.getDomainAxisLocation();
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        categoryPlot1.drawBackgroundImage(graphics2D6, rectangle2D7);
        java.awt.Paint paint9 = categoryPlot1.getNoDataMessagePaint();
        float float10 = categoryPlot1.getBackgroundAlpha();
        boolean boolean11 = color0.equals((java.lang.Object) float10);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 1.0f + "'", float10 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = categoryAxis3.getTickLabelInsets();
        categoryAxis3.setCategoryLabelPositionOffset(0);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions7 = categoryAxis3.getCategoryLabelPositions();
        categoryAxis1.setCategoryLabelPositions(categoryLabelPositions7);
        java.awt.Paint paint9 = categoryAxis1.getAxisLinePaint();
        java.lang.Object obj10 = categoryAxis1.clone();
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(categoryLabelPositions7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        java.awt.Color color0 = java.awt.Color.green;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        categoryPlot0.setDomainCrosshairColumnKey((java.lang.Comparable) (short) -1, true);
        org.jfree.chart.util.Layer layer9 = null;
        java.util.Collection collection10 = categoryPlot0.getRangeMarkers((int) (short) 0, layer9);
        org.jfree.chart.plot.Marker marker11 = null;
        try {
            boolean boolean12 = categoryPlot0.removeRangeMarker(marker11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNull(collection10);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        int int2 = keyedObjects0.getIndex((java.lang.Comparable) (short) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = categoryAxis4.getTickLabelInsets();
        categoryAxis4.setCategoryLabelPositionOffset(0);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis11 = categoryPlot8.getRangeAxis();
        int int12 = categoryPlot8.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder13 = categoryPlot8.getRowRenderingOrder();
        java.awt.Stroke stroke14 = categoryPlot8.getRangeZeroBaselineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent15 = null;
        categoryPlot8.rendererChanged(rendererChangeEvent15);
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot17.setRangeAxisLocation(axisLocation18, true);
        categoryPlot8.setDomainAxisLocation(axisLocation18);
        categoryPlot8.setCrosshairDatasetIndex((int) (short) 1);
        categoryAxis4.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot8);
        boolean boolean25 = keyedObjects0.equals((java.lang.Object) categoryPlot8);
        java.awt.Graphics2D graphics2D26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        java.awt.geom.Point2D point2D28 = null;
        org.jfree.chart.plot.PlotState plotState29 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        try {
            categoryPlot8.draw(graphics2D26, rectangle2D27, point2D28, plotState29, plotRenderingInfo30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 15 + "'", int12 == 15);
        org.junit.Assert.assertNotNull(sortOrder13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke5 = lineAndShapeRenderer4.getBaseStroke();
        java.awt.Paint paint7 = lineAndShapeRenderer4.getSeriesPaint(15);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = lineAndShapeRenderer4.getSeriesNegativeItemLabelPosition(255);
        int int10 = lineAndShapeRenderer4.getDefaultEntityRadius();
        java.awt.Stroke stroke11 = lineAndShapeRenderer4.getBaseOutlineStroke();
        java.awt.Shape shape13 = lineAndShapeRenderer4.getSeriesShape(15);
        java.awt.Shape shape15 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity18 = new org.jfree.chart.entity.ChartEntity(shape15, "ChartChangeEventType.GENERAL", "");
        lineAndShapeRenderer4.setSeriesShape(3, shape15);
        shapeList0.setShape(255, shape15);
        java.awt.Shape shape22 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity25 = new org.jfree.chart.entity.ChartEntity(shape22, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape26 = chartEntity25.getArea();
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot27.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis30 = categoryPlot27.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        java.awt.geom.Point2D point2D33 = null;
        categoryPlot27.zoomDomainAxes((double) 10.0f, plotRenderingInfo32, point2D33, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor36 = categoryPlot27.getDomainGridlinePosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot37.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis40 = categoryPlot37.getRangeAxis();
        int int41 = categoryPlot37.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder42 = categoryPlot37.getRowRenderingOrder();
        java.awt.Stroke stroke43 = categoryPlot37.getRangeZeroBaselineStroke();
        categoryPlot27.setRangeMinorGridlineStroke(stroke43);
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = categoryPlot27.getDomainAxis(100);
        boolean boolean47 = categoryPlot27.isNotify();
        org.jfree.chart.entity.PlotEntity plotEntity49 = new org.jfree.chart.entity.PlotEntity(shape26, (org.jfree.chart.plot.Plot) categoryPlot27, "ItemLabelAnchor.OUTSIDE1");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset52 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity55 = new org.jfree.chart.entity.CategoryItemEntity(shape26, "PlotOrientation.VERTICAL", "PlotOrientation.VERTICAL", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset52, (java.lang.Comparable) 10, (java.lang.Comparable) 'a');
        shapeList0.setShape(0, shape26);
        java.lang.Object obj57 = shapeList0.clone();
        java.awt.Shape shape59 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity62 = new org.jfree.chart.entity.ChartEntity(shape59, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape63 = chartEntity62.getArea();
        shapeList0.setShape((int) (byte) 100, shape63);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 3 + "'", int10 == 3);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(shape13);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNull(valueAxis30);
        org.junit.Assert.assertNotNull(categoryAnchor36);
        org.junit.Assert.assertNull(valueAxis40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 15 + "'", int41 == 15);
        org.junit.Assert.assertNotNull(sortOrder42);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNull(categoryAxis46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(obj57);
        org.junit.Assert.assertNotNull(shape59);
        org.junit.Assert.assertNotNull(shape63);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Paint paint6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        lineAndShapeRenderer2.setBaseOutlinePaint(paint6);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = lineAndShapeRenderer2.getBaseNegativeItemLabelPosition();
        int int9 = lineAndShapeRenderer2.getDefaultEntityRadius();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        java.awt.Shape shape4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        int int9 = categoryPlot5.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot5.getRowRenderingOrder();
        java.awt.Stroke stroke11 = categoryPlot5.getRangeZeroBaselineStroke();
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("", "", "hi!", "", shape4, stroke11, paint12);
        legendItem13.setDescription("");
        int int16 = legendItem13.getDatasetIndex();
        java.lang.String str17 = legendItem13.getLabel();
        java.lang.String str18 = legendItem13.getLabel();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset19 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo20 = new org.jfree.chart.event.DatasetChangeInfo();
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent21 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object) legendItem13, (org.jfree.data.general.Dataset) defaultCategoryDataset19, datasetChangeInfo20);
        defaultCategoryDataset19.setValue((double) '#', (java.lang.Comparable) 10L, (java.lang.Comparable) 94.0d);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder1 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis5 = categoryPlot2.getRangeAxis();
        int int6 = categoryPlot2.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder7 = categoryPlot2.getRowRenderingOrder();
        categoryPlot2.mapDatasetToRangeAxis((int) '#', (int) (byte) 10);
        boolean boolean11 = datasetRenderingOrder1.equals((java.lang.Object) categoryPlot2);
        org.jfree.data.KeyedObject keyedObject12 = new org.jfree.data.KeyedObject((java.lang.Comparable) (-1L), (java.lang.Object) categoryPlot2);
        java.lang.Comparable comparable13 = keyedObject12.getKey();
        org.junit.Assert.assertNotNull(datasetRenderingOrder1);
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
        org.junit.Assert.assertNotNull(sortOrder7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + (-1L) + "'", comparable13.equals((-1L)));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        lineAndShapeRenderer2.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator7);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = lineAndShapeRenderer2.getSeriesPositiveItemLabelPosition(0);
        lineAndShapeRenderer2.setBaseShapesFilled(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
        lineAndShapeRenderer2.notifyListeners(rendererChangeEvent13);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot15.clearDomainMarkers((int) (short) 10);
        categoryPlot15.setDomainGridlinesVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot20.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis23 = categoryPlot20.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        categoryPlot20.zoomDomainAxes((double) 10.0f, plotRenderingInfo25, point2D26, false);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent29 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot20);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType30 = plotChangeEvent29.getType();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType31 = plotChangeEvent29.getType();
        java.lang.Object obj32 = plotChangeEvent29.getSource();
        categoryPlot15.notifyListeners(plotChangeEvent29);
        java.awt.Stroke stroke34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot15.setOutlineStroke(stroke34);
        lineAndShapeRenderer2.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot15);
        java.awt.Shape shape42 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot43.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis46 = categoryPlot43.getRangeAxis();
        int int47 = categoryPlot43.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder48 = categoryPlot43.getRowRenderingOrder();
        java.awt.Stroke stroke49 = categoryPlot43.getRangeZeroBaselineStroke();
        java.awt.Paint paint50 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem51 = new org.jfree.chart.LegendItem("", "", "hi!", "", shape42, stroke49, paint50);
        legendItem51.setSeriesIndex((int) (byte) 10);
        java.awt.Paint paint54 = legendItem51.getFillPaint();
        java.lang.String str55 = legendItem51.getToolTipText();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer58 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke59 = lineAndShapeRenderer58.getBaseStroke();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator61 = null;
        lineAndShapeRenderer58.setSeriesItemLabelGenerator((int) (byte) 1, categoryItemLabelGenerator61);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer66 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke67 = lineAndShapeRenderer66.getBaseStroke();
        java.awt.Paint paint69 = lineAndShapeRenderer66.getSeriesPaint(15);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer73 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke74 = lineAndShapeRenderer73.getBaseStroke();
        java.awt.Stroke stroke76 = lineAndShapeRenderer73.lookupSeriesStroke(10);
        java.awt.Paint paint77 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        lineAndShapeRenderer73.setBaseOutlinePaint(paint77);
        java.awt.Font font79 = lineAndShapeRenderer73.getBaseItemLabelFont();
        lineAndShapeRenderer66.setSeriesItemLabelFont((int) (byte) 1, font79);
        lineAndShapeRenderer58.setSeriesItemLabelFont((int) (short) 10, font79, true);
        legendItem51.setLabelFont(font79);
        try {
            lineAndShapeRenderer2.setSeriesItemLabelFont((int) (short) -1, font79, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(chartChangeEventType30);
        org.junit.Assert.assertNotNull(chartChangeEventType31);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNull(valueAxis46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 15 + "'", int47 == 15);
        org.junit.Assert.assertNotNull(sortOrder48);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "hi!" + "'", str55.equals("hi!"));
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertNotNull(stroke67);
        org.junit.Assert.assertNull(paint69);
        org.junit.Assert.assertNotNull(stroke74);
        org.junit.Assert.assertNotNull(stroke76);
        org.junit.Assert.assertNotNull(paint77);
        org.junit.Assert.assertNotNull(font79);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot5.zoomDomainAxes((double) 10.0f, plotRenderingInfo10, point2D11, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor14 = categoryPlot5.getDomainGridlinePosition();
        org.jfree.chart.axis.AxisSpace axisSpace15 = null;
        categoryPlot5.setFixedRangeAxisSpace(axisSpace15, false);
        org.jfree.chart.axis.AxisLocation axisLocation19 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.axis.AxisLocation axisLocation20 = axisLocation19.getOpposite();
        categoryPlot5.setDomainAxisLocation(1, axisLocation19, true);
        categoryPlot0.setRangeAxisLocation(axisLocation19, false);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertNotNull(categoryAnchor14);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNotNull(axisLocation20);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder4 = categoryPlot0.getDatasetRenderingOrder();
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot0.getDomainMarkers(0, layer6);
        float float8 = categoryPlot0.getBackgroundAlpha();
        int int9 = categoryPlot0.getRendererCount();
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(datasetRenderingOrder4);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 1.0f + "'", float8 == 1.0f);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = categoryAxis1.getTickLabelInsets();
        categoryAxis1.setCategoryLabelPositionOffset(0);
        categoryAxis1.setMinorTickMarksVisible(false);
        float float7 = categoryAxis1.getMinorTickMarkOutsideLength();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = categoryAxis1.getLabelInsets();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis1.setTickMarkPaint((java.awt.Paint) color9);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot11.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis14 = categoryPlot11.getRangeAxis();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier15 = categoryPlot11.getDrawingSupplier();
        java.awt.Paint paint16 = categoryPlot11.getOutlinePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot17.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis20 = categoryPlot17.getRangeAxis();
        int int21 = categoryPlot17.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot17.getRowRenderingOrder();
        java.awt.Stroke stroke23 = categoryPlot17.getRangeZeroBaselineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent24 = null;
        categoryPlot17.rendererChanged(rendererChangeEvent24);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation27 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot26.setRangeAxisLocation(axisLocation27, true);
        categoryPlot17.setDomainAxisLocation(axisLocation27);
        categoryPlot17.setCrosshairDatasetIndex((int) (short) 1);
        org.jfree.data.category.CategoryDataset categoryDataset33 = categoryPlot17.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = categoryPlot17.getAxisOffset();
        categoryPlot11.setAxisOffset(rectangleInsets34);
        double double37 = rectangleInsets34.calculateRightOutset((-1.0d));
        double double38 = rectangleInsets34.getTop();
        categoryAxis1.setTickLabelInsets(rectangleInsets34);
        double double41 = rectangleInsets34.trimHeight((double) 1L);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 2.0f + "'", float7 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNull(valueAxis14);
        org.junit.Assert.assertNotNull(drawingSupplier15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(valueAxis20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 15 + "'", int21 == 15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNull(categoryDataset33);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 4.0d + "'", double37 == 4.0d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 4.0d + "'", double38 == 4.0d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + (-7.0d) + "'", double41 == (-7.0d));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder5 = categoryPlot0.getRowRenderingOrder();
        categoryPlot0.setWeight((int) (short) 100);
        boolean boolean8 = categoryPlot0.isDomainCrosshairVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection9 = categoryPlot0.getLegendItems();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis13 = categoryPlot10.getRangeAxis();
        int int14 = categoryPlot10.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder15 = categoryPlot10.getRowRenderingOrder();
        java.awt.Stroke stroke16 = categoryPlot10.getRangeZeroBaselineStroke();
        categoryPlot0.setDomainGridlineStroke(stroke16);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(sortOrder5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(legendItemCollection9);
        org.junit.Assert.assertNull(valueAxis13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 15 + "'", int14 == 15);
        org.junit.Assert.assertNotNull(sortOrder15);
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Paint paint6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        lineAndShapeRenderer2.setBaseOutlinePaint(paint6);
        org.jfree.chart.renderer.RenderAttributes renderAttributes9 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        renderAttributes9.setDefaultFillPaint((java.awt.Paint) color10);
        java.awt.Stroke stroke13 = renderAttributes9.getSeriesStroke((int) ' ');
        java.awt.Shape shape15 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity18 = new org.jfree.chart.entity.ChartEntity(shape15, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape19 = chartEntity18.getArea();
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot20.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis23 = categoryPlot20.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        categoryPlot20.zoomDomainAxes((double) 10.0f, plotRenderingInfo25, point2D26, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor29 = categoryPlot20.getDomainGridlinePosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot30.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis33 = categoryPlot30.getRangeAxis();
        int int34 = categoryPlot30.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder35 = categoryPlot30.getRowRenderingOrder();
        java.awt.Stroke stroke36 = categoryPlot30.getRangeZeroBaselineStroke();
        categoryPlot20.setRangeMinorGridlineStroke(stroke36);
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = categoryPlot20.getDomainAxis(100);
        boolean boolean40 = categoryPlot20.isNotify();
        org.jfree.chart.entity.PlotEntity plotEntity42 = new org.jfree.chart.entity.PlotEntity(shape19, (org.jfree.chart.plot.Plot) categoryPlot20, "ItemLabelAnchor.OUTSIDE1");
        renderAttributes9.setSeriesShape((int) (byte) 100, shape19);
        lineAndShapeRenderer2.setSeriesShape(128, shape19, false);
        java.lang.Boolean boolean47 = lineAndShapeRenderer2.getSeriesShapesVisible(100);
        lineAndShapeRenderer2.setBaseSeriesVisibleInLegend(false, true);
        java.awt.Paint paint52 = null;
        try {
            lineAndShapeRenderer2.setSeriesOutlinePaint((-1), paint52);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNull(stroke13);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(categoryAnchor29);
        org.junit.Assert.assertNull(valueAxis33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 15 + "'", int34 == 15);
        org.junit.Assert.assertNotNull(sortOrder35);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNull(categoryAxis39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNull(boolean47);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        lineAndShapeRenderer2.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator7);
        lineAndShapeRenderer2.setSeriesVisible((int) (short) 100, (java.lang.Boolean) false, true);
        java.awt.Paint paint13 = lineAndShapeRenderer2.getBaseOutlinePaint();
        lineAndShapeRenderer2.setSeriesCreateEntities(10, (java.lang.Boolean) false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent17 = null;
        lineAndShapeRenderer2.notifyListeners(rendererChangeEvent17);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer21 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = lineAndShapeRenderer21.getBasePositiveItemLabelPosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot23.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot23.getDomainAxisEdge();
        org.jfree.chart.axis.AxisLocation axisLocation27 = categoryPlot23.getDomainAxisLocation();
        java.awt.Graphics2D graphics2D28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        categoryPlot23.drawBackgroundImage(graphics2D28, rectangle2D29);
        java.awt.Paint paint31 = categoryPlot23.getNoDataMessagePaint();
        lineAndShapeRenderer21.setBaseItemLabelPaint(paint31);
        java.awt.Stroke stroke34 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        lineAndShapeRenderer21.setSeriesStroke((int) (byte) 0, stroke34, false);
        lineAndShapeRenderer2.setBaseStroke(stroke34, false);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(itemLabelPosition22);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(stroke34);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        java.lang.Comparable comparable9 = categoryPlot0.getDomainCrosshairColumnKey();
        boolean boolean10 = categoryPlot0.isRangeCrosshairLockedOnData();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        categoryPlot0.setDomainCrosshairPaint((java.awt.Paint) color11);
        java.awt.Shape shape17 = null;
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem19 = new org.jfree.chart.LegendItem("", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", shape17, (java.awt.Paint) color18);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color18);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        categoryPlot0.panRangeAxes((double) 255, plotRenderingInfo22, point2D23);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        java.awt.geom.Point2D point2D27 = null;
        categoryPlot0.zoomDomainAxes((double) 0, plotRenderingInfo26, point2D27, false);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNull(comparable9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color18);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot0.setRangeAxisLocation(axisLocation1, true);
        java.lang.Comparable comparable4 = categoryPlot0.getDomainCrosshairColumnKey();
        java.awt.Color color5 = java.awt.Color.yellow;
        java.awt.color.ColorSpace colorSpace6 = color5.getColorSpace();
        float[] floatArray10 = new float[] { (byte) 1, '#', 15 };
        float[] floatArray11 = color5.getRGBColorComponents(floatArray10);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color5);
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = categoryPlot0.getRangeAxisEdge((int) (byte) 10);
        double double15 = categoryPlot0.getAnchorValue();
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNull(comparable4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(colorSpace6);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape0, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape4 = chartEntity3.getArea();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot5.zoomDomainAxes((double) 10.0f, plotRenderingInfo10, point2D11, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor14 = categoryPlot5.getDomainGridlinePosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot15.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis18 = categoryPlot15.getRangeAxis();
        int int19 = categoryPlot15.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder20 = categoryPlot15.getRowRenderingOrder();
        java.awt.Stroke stroke21 = categoryPlot15.getRangeZeroBaselineStroke();
        categoryPlot5.setRangeMinorGridlineStroke(stroke21);
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = categoryPlot5.getDomainAxis(100);
        boolean boolean25 = categoryPlot5.isNotify();
        org.jfree.chart.entity.PlotEntity plotEntity27 = new org.jfree.chart.entity.PlotEntity(shape4, (org.jfree.chart.plot.Plot) categoryPlot5, "ItemLabelAnchor.OUTSIDE1");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset30 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity33 = new org.jfree.chart.entity.CategoryItemEntity(shape4, "PlotOrientation.VERTICAL", "PlotOrientation.VERTICAL", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset30, (java.lang.Comparable) 10, (java.lang.Comparable) 'a');
        int int34 = defaultCategoryDataset30.getColumnCount();
        try {
            defaultCategoryDataset30.removeColumn((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertNotNull(categoryAnchor14);
        org.junit.Assert.assertNull(valueAxis18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 15 + "'", int19 == 15);
        org.junit.Assert.assertNotNull(sortOrder20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNull(categoryAxis24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = categoryAxis1.getTickLabelInsets();
        categoryAxis1.setCategoryLabelPositionOffset(0);
        categoryAxis1.setMinorTickMarksVisible(false);
        float float7 = categoryAxis1.getMinorTickMarkOutsideLength();
        boolean boolean8 = categoryAxis1.isVisible();
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean13 = categoryPlot12.isRangeGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = categoryPlot12.getRangeAxisEdge((int) (byte) -1);
        org.jfree.chart.axis.AxisState axisState16 = null;
        categoryAxis1.drawTickMarks(graphics2D9, (double) 1L, rectangle2D11, rectangleEdge15, axisState16);
        java.lang.String str19 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) 100.0f);
        categoryAxis1.clearCategoryLabelToolTips();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 2.0f + "'", float7 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNull(str19);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getRangeAxisEdge();
        categoryPlot0.setForegroundAlpha((float) (byte) 10);
        org.junit.Assert.assertNotNull(rectangleEdge3);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot3.getRangeAxis();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier7 = categoryPlot3.getDrawingSupplier();
        org.jfree.data.category.CategoryDataset categoryDataset8 = categoryPlot3.getDataset();
        org.jfree.chart.renderer.RenderAttributes renderAttributes9 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        renderAttributes9.setDefaultFillPaint((java.awt.Paint) color10);
        categoryPlot3.setBackgroundPaint((java.awt.Paint) color10);
        lineAndShapeRenderer2.setPlot(categoryPlot3);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator17 = lineAndShapeRenderer2.getURLGenerator(2, (-10214656), true);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(drawingSupplier7);
        org.junit.Assert.assertNull(categoryDataset8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNull(categoryURLGenerator17);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_HORIZONTAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape2, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape6 = chartEntity5.getArea();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot7.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis10 = categoryPlot7.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot7.zoomDomainAxes((double) 10.0f, plotRenderingInfo12, point2D13, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor16 = categoryPlot7.getDomainGridlinePosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot17.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis20 = categoryPlot17.getRangeAxis();
        int int21 = categoryPlot17.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot17.getRowRenderingOrder();
        java.awt.Stroke stroke23 = categoryPlot17.getRangeZeroBaselineStroke();
        categoryPlot7.setRangeMinorGridlineStroke(stroke23);
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = categoryPlot7.getDomainAxis(100);
        boolean boolean27 = categoryPlot7.isNotify();
        org.jfree.chart.entity.PlotEntity plotEntity29 = new org.jfree.chart.entity.PlotEntity(shape6, (org.jfree.chart.plot.Plot) categoryPlot7, "ItemLabelAnchor.OUTSIDE1");
        boolean boolean30 = categoryPlot7.isRangeZoomable();
        boolean boolean31 = gradientPaintTransformType0.equals((java.lang.Object) boolean30);
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertNotNull(categoryAnchor16);
        org.junit.Assert.assertNull(valueAxis20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 15 + "'", int21 == 15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNull(categoryAxis26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        java.lang.Comparable comparable9 = categoryPlot0.getDomainCrosshairColumnKey();
        boolean boolean10 = categoryPlot0.isRangeCrosshairLockedOnData();
        float float11 = categoryPlot0.getForegroundAlpha();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNull(comparable9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 1.0f + "'", float11 == 1.0f);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor9 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis13 = categoryPlot10.getRangeAxis();
        int int14 = categoryPlot10.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder15 = categoryPlot10.getRowRenderingOrder();
        java.awt.Stroke stroke16 = categoryPlot10.getRangeZeroBaselineStroke();
        categoryPlot0.setRangeMinorGridlineStroke(stroke16);
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = categoryPlot0.getDomainAxis(100);
        boolean boolean20 = categoryPlot0.isNotify();
        java.awt.Paint paint21 = categoryPlot0.getRangeGridlinePaint();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(categoryAnchor9);
        org.junit.Assert.assertNull(valueAxis13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 15 + "'", int14 == 15);
        org.junit.Assert.assertNotNull(sortOrder15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNull(categoryAxis19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = categoryAxis1.getTickLabelInsets();
        categoryAxis1.setCategoryLabelPositionOffset(0);
        categoryAxis1.setMinorTickMarksVisible(false);
        float float7 = categoryAxis1.getMinorTickMarkOutsideLength();
        boolean boolean8 = categoryAxis1.isVisible();
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean13 = categoryPlot12.isRangeGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = categoryPlot12.getRangeAxisEdge((int) (byte) -1);
        org.jfree.chart.axis.AxisState axisState16 = null;
        categoryAxis1.drawTickMarks(graphics2D9, (double) 1L, rectangle2D11, rectangleEdge15, axisState16);
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = categoryAxis19.getTickLabelInsets();
        categoryAxis19.setCategoryLabelPositionOffset(0);
        categoryAxis19.setMinorTickMarksVisible(false);
        float float25 = categoryAxis19.getMinorTickMarkOutsideLength();
        boolean boolean26 = categoryAxis19.isVisible();
        categoryAxis19.setTickMarkOutsideLength((float) 10L);
        float float29 = categoryAxis19.getTickMarkOutsideLength();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer33 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke34 = lineAndShapeRenderer33.getBaseStroke();
        java.awt.Paint paint36 = lineAndShapeRenderer33.getSeriesPaint(15);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer40 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke41 = lineAndShapeRenderer40.getBaseStroke();
        java.awt.Stroke stroke43 = lineAndShapeRenderer40.lookupSeriesStroke(10);
        java.awt.Paint paint44 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        lineAndShapeRenderer40.setBaseOutlinePaint(paint44);
        java.awt.Font font46 = lineAndShapeRenderer40.getBaseItemLabelFont();
        lineAndShapeRenderer33.setSeriesItemLabelFont((int) (byte) 1, font46);
        categoryAxis19.setTickLabelFont((java.lang.Comparable) '4', font46);
        categoryAxis1.setTickLabelFont(font46);
        org.jfree.chart.plot.Plot plot50 = categoryAxis1.getPlot();
        categoryAxis1.setVisible(false);
        boolean boolean53 = categoryAxis1.isTickMarksVisible();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 2.0f + "'", float7 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 2.0f + "'", float25 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 10.0f + "'", float29 == 10.0f);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNull(paint36);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(font46);
        org.junit.Assert.assertNull(plot50);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getMinimumBarLength();
        org.jfree.chart.LegendItem legendItem4 = barRenderer0.getLegendItem((int) (short) -1, 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(legendItem4);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getMinimumBarLength();
        java.awt.Paint paint5 = barRenderer0.getItemPaint(0, 15, true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator6 = barRenderer0.getBaseURLGenerator();
        barRenderer0.setSeriesVisibleInLegend(255, (java.lang.Boolean) true, true);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(categoryURLGenerator6);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder5 = categoryPlot0.getRowRenderingOrder();
        java.awt.Stroke stroke6 = categoryPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = categoryPlot0.getInsets();
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot0.getRangeAxisLocation();
        java.awt.Paint paint9 = categoryPlot0.getRangeGridlinePaint();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(sortOrder5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        java.awt.Shape shape4 = null;
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem6 = new org.jfree.chart.LegendItem("", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", shape4, (java.awt.Paint) color5);
        java.awt.Paint paint7 = legendItem6.getLabelPaint();
        java.awt.Font font8 = legendItem6.getLabelFont();
        legendItem6.setLineVisible(true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNull(font8);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = categoryAxis1.getTickLabelInsets();
        categoryAxis1.setCategoryLabelPositionOffset(0);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        int int9 = categoryPlot5.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot5.getRowRenderingOrder();
        java.awt.Stroke stroke11 = categoryPlot5.getRangeZeroBaselineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        categoryPlot5.rendererChanged(rendererChangeEvent12);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot14.setRangeAxisLocation(axisLocation15, true);
        categoryPlot5.setDomainAxisLocation(axisLocation15);
        categoryPlot5.setCrosshairDatasetIndex((int) (short) 1);
        categoryAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot5);
        double double22 = categoryAxis1.getCategoryMargin();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.2d + "'", double22 == 0.2d);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = defaultCategoryDataset0.getGroup();
        defaultCategoryDataset0.fireSelectionEvent();
        org.junit.Assert.assertNotNull(datasetGroup1);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        lineAndShapeRenderer2.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator7);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = lineAndShapeRenderer2.getSeriesPositiveItemLabelPosition(0);
        lineAndShapeRenderer2.setBaseShapesFilled(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
        lineAndShapeRenderer2.notifyListeners(rendererChangeEvent13);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot15.clearDomainMarkers((int) (short) 10);
        categoryPlot15.setDomainGridlinesVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot20.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis23 = categoryPlot20.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        categoryPlot20.zoomDomainAxes((double) 10.0f, plotRenderingInfo25, point2D26, false);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent29 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot20);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType30 = plotChangeEvent29.getType();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType31 = plotChangeEvent29.getType();
        java.lang.Object obj32 = plotChangeEvent29.getSource();
        categoryPlot15.notifyListeners(plotChangeEvent29);
        java.awt.Stroke stroke34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot15.setOutlineStroke(stroke34);
        lineAndShapeRenderer2.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot15);
        org.jfree.chart.plot.Marker marker38 = null;
        org.jfree.chart.util.Layer layer39 = null;
        boolean boolean40 = categoryPlot15.removeDomainMarker((int) ' ', marker38, layer39);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(chartChangeEventType30);
        org.junit.Assert.assertNotNull(chartChangeEventType31);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        java.awt.Shape shape4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        int int9 = categoryPlot5.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot5.getRowRenderingOrder();
        java.awt.Stroke stroke11 = categoryPlot5.getRangeZeroBaselineStroke();
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("", "", "hi!", "", shape4, stroke11, paint12);
        legendItem13.setDescription("");
        int int16 = legendItem13.getDatasetIndex();
        java.lang.String str17 = legendItem13.getLabel();
        java.awt.Font font18 = legendItem13.getLabelFont();
        boolean boolean19 = legendItem13.isShapeVisible();
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertNull(font18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_HORIZONTAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor2 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE5;
        java.awt.Color color3 = java.awt.Color.white;
        boolean boolean4 = itemLabelAnchor2.equals((java.lang.Object) color3);
        boolean boolean5 = standardGradientPaintTransformer1.equals((java.lang.Object) boolean4);
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType6 = standardGradientPaintTransformer1.getType();
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertNotNull(itemLabelAnchor2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(gradientPaintTransformType6);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getMinimumBarLength();
        java.awt.Paint paint5 = barRenderer0.getItemPaint(0, 15, true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator6 = barRenderer0.getBaseURLGenerator();
        barRenderer0.setBase((double) '4');
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer9 = barRenderer0.getGradientPaintTransformer();
        int int10 = barRenderer0.getColumnCount();
        double double11 = barRenderer0.getShadowYOffset();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(categoryURLGenerator6);
        org.junit.Assert.assertNotNull(gradientPaintTransformer9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxis(0);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNull(categoryAxis5);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        java.awt.Color color0 = java.awt.Color.PINK;
        java.awt.Color color1 = color0.darker();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = categoryAxis1.getTickLabelInsets();
        categoryAxis1.setCategoryLabelPositionOffset(0);
        categoryAxis1.setMinorTickMarksVisible(false);
        float float7 = categoryAxis1.getMinorTickMarkOutsideLength();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = categoryAxis1.getLabelInsets();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis1.setTickMarkPaint((java.awt.Paint) color9);
        float float11 = categoryAxis1.getMinorTickMarkInsideLength();
        double double12 = categoryAxis1.getFixedDimension();
        float float13 = categoryAxis1.getTickMarkOutsideLength();
        categoryAxis1.setCategoryMargin((double) (-1L));
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 2.0f + "'", float7 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.0f + "'", float11 == 0.0f);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 2.0f + "'", float13 == 2.0f);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        renderAttributes1.setDefaultFillPaint((java.awt.Paint) color2);
        org.jfree.chart.LegendItem legendItem4 = new org.jfree.chart.LegendItem("hi!", (java.awt.Paint) color2);
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity8 = new org.jfree.chart.entity.ChartEntity(shape5, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape9 = chartEntity8.getArea();
        legendItem4.setLine(shape9);
        java.awt.Paint paint11 = legendItem4.getOutlinePaint();
        java.awt.Color color12 = java.awt.Color.darkGray;
        legendItem4.setLinePaint((java.awt.Paint) color12);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(color12);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        renderAttributes0.setDefaultFillPaint((java.awt.Paint) color1);
        java.awt.Shape shape5 = renderAttributes0.getItemShape((int) (byte) 100, (int) 'a');
        java.awt.Shape shape7 = null;
        renderAttributes0.setSeriesShape((int) (byte) 1, shape7);
        java.awt.Paint paint10 = renderAttributes0.getSeriesOutlinePaint((int) (byte) 1);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        java.awt.Color color13 = java.awt.Color.yellow;
        java.awt.color.ColorSpace colorSpace14 = color13.getColorSpace();
        java.awt.Color color18 = java.awt.Color.getHSBColor((float) (short) 1, (float) 100, 0.0f);
        float[] floatArray25 = new float[] { (byte) 10, (byte) 1, 1.0f, (byte) 0, 10, (byte) 100 };
        float[] floatArray26 = color18.getRGBComponents(floatArray25);
        float[] floatArray27 = color12.getColorComponents(colorSpace14, floatArray25);
        renderAttributes0.setSeriesFillPaint((int) (byte) 100, (java.awt.Paint) color12);
        java.awt.Paint paint31 = renderAttributes0.getItemPaint((int) (byte) 1, (int) 'a');
        try {
            java.lang.Boolean boolean33 = renderAttributes0.getSeriesCreateEntity((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNull(shape5);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(colorSpace14);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(floatArray26);
        org.junit.Assert.assertNotNull(floatArray27);
        org.junit.Assert.assertNull(paint31);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge();
        org.jfree.chart.axis.AxisLocation axisLocation4 = categoryPlot0.getDomainAxisLocation();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        categoryPlot0.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        categoryPlot0.setRenderer(categoryItemRenderer8);
        java.awt.Paint paint10 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        categoryPlot0.setDatasetRenderingOrder(datasetRenderingOrder11);
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType13 = org.jfree.chart.util.GradientPaintTransformType.CENTER_HORIZONTAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer14 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType13);
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType15 = standardGradientPaintTransformer14.getType();
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot16.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis19 = categoryPlot16.getRangeAxis();
        int int20 = categoryPlot16.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder21 = categoryPlot16.getRowRenderingOrder();
        java.awt.Stroke stroke22 = categoryPlot16.getRangeZeroBaselineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent23 = null;
        categoryPlot16.rendererChanged(rendererChangeEvent23);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation26 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot25.setRangeAxisLocation(axisLocation26, true);
        categoryPlot16.setDomainAxisLocation(axisLocation26);
        categoryPlot16.setCrosshairDatasetIndex((int) (short) 1);
        org.jfree.data.category.CategoryDataset categoryDataset32 = categoryPlot16.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = categoryPlot16.getAxisOffset();
        double double35 = rectangleInsets33.extendWidth(0.0d);
        double double37 = rectangleInsets33.trimWidth((double) 100L);
        double double38 = rectangleInsets33.getBottom();
        boolean boolean39 = standardGradientPaintTransformer14.equals((java.lang.Object) double38);
        boolean boolean40 = datasetRenderingOrder11.equals((java.lang.Object) double38);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
        org.junit.Assert.assertNotNull(gradientPaintTransformType13);
        org.junit.Assert.assertNotNull(gradientPaintTransformType15);
        org.junit.Assert.assertNull(valueAxis19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 15 + "'", int20 == 15);
        org.junit.Assert.assertNotNull(sortOrder21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNull(categoryDataset32);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 8.0d + "'", double35 == 8.0d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 92.0d + "'", double37 == 92.0d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 4.0d + "'", double38 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        java.awt.Color color0 = java.awt.Color.blue;
        int int1 = color0.getRed();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder5 = categoryPlot0.getRowRenderingOrder();
        java.awt.Stroke stroke6 = categoryPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent7 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent7);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot9.setRangeAxisLocation(axisLocation10, true);
        categoryPlot0.setDomainAxisLocation(axisLocation10);
        categoryPlot0.setCrosshairDatasetIndex((int) (short) 1);
        org.jfree.data.category.CategoryDataset categoryDataset16 = categoryPlot0.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = categoryPlot0.getAxisOffset();
        categoryPlot0.setOutlineVisible(true);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent20 = null;
        categoryPlot0.markerChanged(markerChangeEvent20);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = categoryPlot0.getRangeAxisEdge(64);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(sortOrder5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNull(categoryDataset16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(rectangleEdge23);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        org.jfree.chart.LegendItemCollection legendItemCollection4 = lineAndShapeRenderer2.getLegendItems();
        org.jfree.chart.renderer.RenderAttributes renderAttributes5 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Shape shape8 = renderAttributes5.getItemShape((int) (byte) 10, 15);
        java.awt.Color color10 = java.awt.Color.CYAN;
        renderAttributes5.setSeriesOutlinePaint((int) (byte) 0, (java.awt.Paint) color10);
        lineAndShapeRenderer2.setBaseItemLabelPaint((java.awt.Paint) color10, true);
        java.awt.Font font17 = lineAndShapeRenderer2.getItemLabelFont((int) (byte) 0, (-1), false);
        java.awt.Color color21 = java.awt.Color.getColor("ItemLabelAnchor.OUTSIDE1", 0);
        try {
            lineAndShapeRenderer2.setSeriesPaint((-1), (java.awt.Paint) color21, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(legendItemCollection4);
        org.junit.Assert.assertNull(shape8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(color21);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot4.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis7 = categoryPlot4.getRangeAxis();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot4.getDrawingSupplier();
        org.jfree.data.category.CategoryDataset categoryDataset9 = categoryPlot4.getDataset();
        boolean boolean10 = lineAndShapeRenderer2.hasListener((java.util.EventListener) categoryPlot4);
        java.awt.Paint paint12 = lineAndShapeRenderer2.lookupSeriesPaint((int) (byte) 10);
        java.awt.Font font13 = lineAndShapeRenderer2.getBaseLegendTextFont();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNull(categoryDataset9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(font13);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        boolean boolean6 = lineAndShapeRenderer2.getUseSeriesOffset();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator7 = lineAndShapeRenderer2.getBaseItemLabelGenerator();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryItemLabelGenerator7);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Paint paint5 = lineAndShapeRenderer2.getSeriesPaint(15);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = lineAndShapeRenderer2.getSeriesNegativeItemLabelPosition(255);
        int int8 = lineAndShapeRenderer2.getDefaultEntityRadius();
        lineAndShapeRenderer2.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = lineAndShapeRenderer2.getNegativeItemLabelPosition(8, 0, false);
        lineAndShapeRenderer2.setItemLabelAnchorOffset((double) (-256));
        java.awt.Paint paint18 = null;
        lineAndShapeRenderer2.setSeriesItemLabelPaint(0, paint18, true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = categoryAxis1.getTickLabelInsets();
        categoryAxis1.setCategoryLabelPositionOffset(0);
        categoryAxis1.setMinorTickMarksVisible(false);
        float float7 = categoryAxis1.getMinorTickMarkOutsideLength();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = categoryAxis1.getLabelInsets();
        categoryAxis1.setTickLabelsVisible(false);
        categoryAxis1.setFixedDimension(0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 2.0f + "'", float7 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets8);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Paint paint5 = lineAndShapeRenderer2.getSeriesPaint(15);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = lineAndShapeRenderer2.getSeriesNegativeItemLabelPosition(255);
        int int8 = lineAndShapeRenderer2.getDefaultEntityRadius();
        java.awt.Stroke stroke9 = lineAndShapeRenderer2.getBaseOutlineStroke();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator11 = lineAndShapeRenderer2.getSeriesToolTipGenerator(128);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator12 = null;
        lineAndShapeRenderer2.setBaseItemLabelGenerator(categoryItemLabelGenerator12);
        lineAndShapeRenderer2.setBaseLinesVisible(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator17 = null;
        try {
            lineAndShapeRenderer2.setSeriesURLGenerator((int) (byte) -1, categoryURLGenerator17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNull(categoryToolTipGenerator11);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getMinimumBarLength();
        java.awt.Paint paint5 = barRenderer0.getItemPaint(0, 15, true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator6 = barRenderer0.getBaseURLGenerator();
        barRenderer0.setBase((double) '4');
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer9 = barRenderer0.getGradientPaintTransformer();
        int int10 = barRenderer0.getColumnCount();
        barRenderer0.setBase((double) 2.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(categoryURLGenerator6);
        org.junit.Assert.assertNotNull(gradientPaintTransformer9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke4 = lineAndShapeRenderer3.getBaseStroke();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator6 = null;
        lineAndShapeRenderer3.setSeriesItemLabelGenerator((int) (byte) 1, categoryItemLabelGenerator6);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer11 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke12 = lineAndShapeRenderer11.getBaseStroke();
        java.awt.Paint paint14 = lineAndShapeRenderer11.getSeriesPaint(15);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer18 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke19 = lineAndShapeRenderer18.getBaseStroke();
        java.awt.Stroke stroke21 = lineAndShapeRenderer18.lookupSeriesStroke(10);
        java.awt.Paint paint22 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        lineAndShapeRenderer18.setBaseOutlinePaint(paint22);
        java.awt.Font font24 = lineAndShapeRenderer18.getBaseItemLabelFont();
        lineAndShapeRenderer11.setSeriesItemLabelFont((int) (byte) 1, font24);
        lineAndShapeRenderer3.setSeriesItemLabelFont((int) (short) 10, font24, true);
        boolean boolean28 = plotOrientation0.equals((java.lang.Object) (short) 10);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor29 = org.jfree.chart.axis.CategoryAnchor.END;
        boolean boolean30 = plotOrientation0.equals((java.lang.Object) categoryAnchor29);
        org.junit.Assert.assertNotNull(plotOrientation0);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNull(paint14);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(categoryAnchor29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape0, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape4 = chartEntity3.getArea();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot5.zoomDomainAxes((double) 10.0f, plotRenderingInfo10, point2D11, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor14 = categoryPlot5.getDomainGridlinePosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot15.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis18 = categoryPlot15.getRangeAxis();
        int int19 = categoryPlot15.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder20 = categoryPlot15.getRowRenderingOrder();
        java.awt.Stroke stroke21 = categoryPlot15.getRangeZeroBaselineStroke();
        categoryPlot5.setRangeMinorGridlineStroke(stroke21);
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = categoryPlot5.getDomainAxis(100);
        boolean boolean25 = categoryPlot5.isNotify();
        org.jfree.chart.entity.PlotEntity plotEntity27 = new org.jfree.chart.entity.PlotEntity(shape4, (org.jfree.chart.plot.Plot) categoryPlot5, "ItemLabelAnchor.OUTSIDE1");
        java.lang.String str28 = plotEntity27.getShapeType();
        org.jfree.chart.plot.Plot plot29 = plotEntity27.getPlot();
        java.lang.String str30 = plotEntity27.toString();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertNotNull(categoryAnchor14);
        org.junit.Assert.assertNull(valueAxis18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 15 + "'", int19 == 15);
        org.junit.Assert.assertNotNull(sortOrder20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNull(categoryAxis24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "rect" + "'", str28.equals("rect"));
        org.junit.Assert.assertNotNull(plot29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "PlotEntity: tooltip = ItemLabelAnchor.OUTSIDE1" + "'", str30.equals("PlotEntity: tooltip = ItemLabelAnchor.OUTSIDE1"));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
        boolean boolean3 = lineAndShapeRenderer2.getBaseLinesVisible();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }
}

