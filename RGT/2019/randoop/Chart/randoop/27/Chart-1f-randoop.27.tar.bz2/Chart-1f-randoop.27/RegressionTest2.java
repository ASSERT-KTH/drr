import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Shape shape3 = renderAttributes0.getItemShape((int) (byte) 10, 15);
        org.jfree.chart.renderer.RenderAttributes renderAttributes5 = new org.jfree.chart.renderer.RenderAttributes(true);
        java.awt.Color color7 = java.awt.Color.magenta;
        renderAttributes5.setSeriesOutlinePaint(128, (java.awt.Paint) color7);
        renderAttributes0.setDefaultLabelPaint((java.awt.Paint) color7);
        org.junit.Assert.assertNull(shape3);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        lineAndShapeRenderer2.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator7);
        lineAndShapeRenderer2.setSeriesVisible((int) (short) 100, (java.lang.Boolean) false, true);
        boolean boolean15 = lineAndShapeRenderer2.getItemShapeVisible((int) (short) 10, 3);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator16 = lineAndShapeRenderer2.getLegendItemLabelGenerator();
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation19 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot18.setRangeAxisLocation(axisLocation19, true);
        java.lang.Comparable comparable22 = categoryPlot18.getDomainCrosshairColumnKey();
        java.awt.Color color23 = java.awt.Color.yellow;
        java.awt.color.ColorSpace colorSpace24 = color23.getColorSpace();
        float[] floatArray28 = new float[] { (byte) 1, '#', 15 };
        float[] floatArray29 = color23.getRGBColorComponents(floatArray28);
        categoryPlot18.setDomainGridlinePaint((java.awt.Paint) color23);
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = categoryPlot18.getRangeAxisEdge((int) (byte) 10);
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        java.awt.Paint paint36 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer39 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke40 = lineAndShapeRenderer39.getBaseStroke();
        java.awt.Paint paint42 = lineAndShapeRenderer39.getSeriesPaint(15);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition44 = lineAndShapeRenderer39.getSeriesNegativeItemLabelPosition(255);
        int int45 = lineAndShapeRenderer39.getDefaultEntityRadius();
        org.jfree.chart.plot.CategoryPlot categoryPlot47 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot47.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis50 = categoryPlot47.getRangeAxis();
        int int51 = categoryPlot47.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder52 = categoryPlot47.getRowRenderingOrder();
        java.awt.Stroke stroke53 = categoryPlot47.getRangeZeroBaselineStroke();
        lineAndShapeRenderer39.setSeriesOutlineStroke(255, stroke53, false);
        try {
            lineAndShapeRenderer2.drawRangeLine(graphics2D17, categoryPlot18, valueAxis33, rectangle2D34, (double) 1, paint36, stroke53);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator16);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNull(comparable22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(colorSpace24);
        org.junit.Assert.assertNotNull(floatArray28);
        org.junit.Assert.assertNotNull(floatArray29);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNull(paint42);
        org.junit.Assert.assertNotNull(itemLabelPosition44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 3 + "'", int45 == 3);
        org.junit.Assert.assertNull(valueAxis50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 15 + "'", int51 == 15);
        org.junit.Assert.assertNotNull(sortOrder52);
        org.junit.Assert.assertNotNull(stroke53);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        org.jfree.chart.renderer.RenderAttributes renderAttributes4 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        renderAttributes4.setDefaultFillPaint((java.awt.Paint) color5);
        java.awt.Shape shape9 = renderAttributes4.getItemShape((int) (byte) 100, (int) 'a');
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        renderAttributes4.setDefaultShape(shape10);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot12.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis15 = categoryPlot12.getRangeAxis();
        int int16 = categoryPlot12.getBackgroundImageAlignment();
        categoryPlot12.setDomainCrosshairColumnKey((java.lang.Comparable) (short) -1, true);
        java.awt.Stroke stroke20 = categoryPlot12.getDomainGridlineStroke();
        java.awt.Color color21 = java.awt.Color.MAGENTA;
        org.jfree.chart.LegendItem legendItem22 = new org.jfree.chart.LegendItem("hi!", "AxisLocation.BOTTOM_OR_LEFT", "AxisLocation.BOTTOM_OR_LEFT", "ChartChangeEventType.GENERAL", shape10, stroke20, (java.awt.Paint) color21);
        java.awt.Font font23 = legendItem22.getLabelFont();
        org.jfree.chart.renderer.RenderAttributes renderAttributes24 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        renderAttributes24.setDefaultFillPaint((java.awt.Paint) color25);
        java.awt.Stroke stroke28 = renderAttributes24.getSeriesStroke((int) ' ');
        java.awt.Paint paint31 = renderAttributes24.getItemFillPaint(0, (int) (byte) 100);
        boolean boolean32 = legendItem22.equals((java.lang.Object) 0);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(shape9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNull(valueAxis15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 15 + "'", int16 == 15);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNull(font23);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNull(stroke28);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        lineAndShapeRenderer2.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator7);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = lineAndShapeRenderer2.getSeriesPositiveItemLabelPosition(0);
        lineAndShapeRenderer2.setBaseShapesFilled(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
        lineAndShapeRenderer2.notifyListeners(rendererChangeEvent13);
        lineAndShapeRenderer2.setAutoPopulateSeriesOutlinePaint(false);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        categoryPlot0.setDomainCrosshairColumnKey((java.lang.Comparable) (short) -1, true);
        java.awt.Stroke stroke8 = categoryPlot0.getDomainGridlineStroke();
        int int9 = categoryPlot0.getCrosshairDatasetIndex();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot0.zoomDomainAxes((double) (-1.0f), plotRenderingInfo11, point2D12, false);
        categoryPlot0.clearRangeMarkers((-1));
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.clearSeriesStrokes(true);
        lineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.renderer.RenderAttributes renderAttributes7 = new org.jfree.chart.renderer.RenderAttributes(true);
        java.awt.Color color9 = java.awt.Color.magenta;
        renderAttributes7.setSeriesOutlinePaint(128, (java.awt.Paint) color9);
        lineAndShapeRenderer0.setSeriesItemLabelPaint((int) (short) 1, (java.awt.Paint) color9);
        lineAndShapeRenderer0.setSeriesItemLabelsVisible((int) (byte) 10, (java.lang.Boolean) true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator16 = null;
        lineAndShapeRenderer0.setSeriesToolTipGenerator(1, categoryToolTipGenerator16, false);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        categoryPlot0.setDomainCrosshairColumnKey((java.lang.Comparable) (short) -1, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot0.zoomRangeAxes((double) (byte) 1, plotRenderingInfo9, point2D10, true);
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) 0.0f, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot16.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis19 = categoryPlot16.getRangeAxis();
        int int20 = categoryPlot16.getBackgroundImageAlignment();
        java.awt.Paint paint21 = categoryPlot16.getNoDataMessagePaint();
        java.awt.Paint paint22 = categoryPlot16.getRangeMinorGridlinePaint();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot16);
        java.awt.Paint paint24 = categoryPlot16.getDomainGridlinePaint();
        java.awt.Shape shape30 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot31.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis34 = categoryPlot31.getRangeAxis();
        int int35 = categoryPlot31.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder36 = categoryPlot31.getRowRenderingOrder();
        java.awt.Stroke stroke37 = categoryPlot31.getRangeZeroBaselineStroke();
        java.awt.Paint paint38 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem39 = new org.jfree.chart.LegendItem("", "", "hi!", "", shape30, stroke37, paint38);
        legendItem39.setDescription("");
        int int42 = legendItem39.getDatasetIndex();
        java.lang.String str43 = legendItem39.getLabel();
        java.lang.String str44 = legendItem39.getLabel();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset45 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo46 = new org.jfree.chart.event.DatasetChangeInfo();
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent47 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object) legendItem39, (org.jfree.data.general.Dataset) defaultCategoryDataset45, datasetChangeInfo46);
        defaultCategoryDataset45.clearSelection();
        int int49 = defaultCategoryDataset45.getRowCount();
        int int51 = defaultCategoryDataset45.getColumnIndex((java.lang.Comparable) "AxisLocation.BOTTOM_OR_LEFT");
        defaultCategoryDataset45.fireSelectionEvent();
        categoryPlot16.setDataset(10, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset45);
        try {
            java.lang.Comparable comparable55 = defaultCategoryDataset45.getRowKey((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNull(valueAxis19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 15 + "'", int20 == 15);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNull(valueAxis34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 15 + "'", int35 == 15);
        org.junit.Assert.assertNotNull(sortOrder36);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "" + "'", str43.equals(""));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "" + "'", str44.equals(""));
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1) + "'", int51 == (-1));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.getSeriesItemLabelPaint((int) '4');
        barRenderer0.setItemMargin((double) (-1L));
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = barRenderer0.getPositiveItemLabelPositionFallback();
        boolean boolean6 = barRenderer0.getAutoPopulateSeriesOutlinePaint();
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNull(itemLabelPosition5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Shape shape9 = lineAndShapeRenderer2.getItemShape((int) (short) 10, 100, true);
        lineAndShapeRenderer2.setBaseSeriesVisible(false);
        java.awt.Shape shape12 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity15 = new org.jfree.chart.entity.ChartEntity(shape12, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape16 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity19 = new org.jfree.chart.entity.ChartEntity(shape16, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape20 = chartEntity19.getArea();
        chartEntity15.setArea(shape20);
        lineAndShapeRenderer2.setBaseShape(shape20, true);
        java.lang.Boolean boolean25 = lineAndShapeRenderer2.getSeriesShapesVisible(1);
        java.awt.Font font26 = lineAndShapeRenderer2.getBaseItemLabelFont();
        lineAndShapeRenderer2.setSeriesShapesVisible(1, true);
        lineAndShapeRenderer2.setBaseSeriesVisible(false);
        java.awt.Paint paint33 = lineAndShapeRenderer2.lookupSeriesPaint(0);
        java.awt.Stroke stroke35 = lineAndShapeRenderer2.getSeriesOutlineStroke(0);
        java.awt.Shape shape41 = null;
        java.awt.Color color42 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem43 = new org.jfree.chart.LegendItem("", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", shape41, (java.awt.Paint) color42);
        java.awt.color.ColorSpace colorSpace44 = color42.getColorSpace();
        java.awt.Color color45 = java.awt.Color.getColor("SortOrder.ASCENDING", color42);
        lineAndShapeRenderer2.setBaseOutlinePaint((java.awt.Paint) color42, true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNull(boolean25);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNull(stroke35);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(colorSpace44);
        org.junit.Assert.assertNotNull(color45);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        lineAndShapeRenderer2.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator7);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = lineAndShapeRenderer2.getSeriesPositiveItemLabelPosition(0);
        java.awt.Paint paint12 = lineAndShapeRenderer2.lookupSeriesOutlinePaint(0);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator16 = lineAndShapeRenderer2.getToolTipGenerator(128, (int) (short) 0, true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(categoryToolTipGenerator16);
    }

//    @Test
//    public void test011() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test011");
//        boolean boolean0 = org.jfree.chart.renderer.category.BarRenderer.getDefaultShadowsVisible();
//        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
//    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge();
        org.jfree.chart.axis.AxisLocation axisLocation4 = categoryPlot0.getDomainAxisLocation();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        categoryPlot0.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        categoryPlot0.setRenderer(categoryItemRenderer8);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean14 = categoryPlot0.removeDomainMarker((int) (short) -1, marker11, layer12, false);
        boolean boolean15 = categoryPlot0.isDomainCrosshairVisible();
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        lineAndShapeRenderer2.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator7);
        lineAndShapeRenderer2.setSeriesVisible((int) (short) 100, (java.lang.Boolean) false, true);
        boolean boolean15 = lineAndShapeRenderer2.getItemShapeVisible((int) (short) 10, 3);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator16 = lineAndShapeRenderer2.getLegendItemLabelGenerator();
        lineAndShapeRenderer2.setSeriesVisible((int) '4', (java.lang.Boolean) true);
        java.awt.Shape shape20 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity23 = new org.jfree.chart.entity.ChartEntity(shape20, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape24 = chartEntity23.getArea();
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot25.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis28 = categoryPlot25.getRangeAxis();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier29 = categoryPlot25.getDrawingSupplier();
        org.jfree.data.category.CategoryDataset categoryDataset30 = categoryPlot25.getDataset();
        org.jfree.chart.renderer.RenderAttributes renderAttributes31 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        renderAttributes31.setDefaultFillPaint((java.awt.Paint) color32);
        categoryPlot25.setBackgroundPaint((java.awt.Paint) color32);
        org.jfree.chart.axis.ValueAxis valueAxis35 = categoryPlot25.getRangeAxis();
        org.jfree.chart.entity.PlotEntity plotEntity38 = new org.jfree.chart.entity.PlotEntity(shape24, (org.jfree.chart.plot.Plot) categoryPlot25, "ChartChangeEventType.GENERAL", "hi!");
        lineAndShapeRenderer2.setBaseShape(shape24);
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation41 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot40.setRangeAxisLocation(axisLocation41, true);
        java.util.List list44 = categoryPlot40.getAnnotations();
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = null;
        categoryPlot40.setDomainAxis((int) (byte) 0, categoryAxis46, false);
        org.jfree.chart.entity.PlotEntity plotEntity51 = new org.jfree.chart.entity.PlotEntity(shape24, (org.jfree.chart.plot.Plot) categoryPlot40, "DatasetRenderingOrder.REVERSE", "{0}");
        org.jfree.chart.plot.CategoryPlot categoryPlot52 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot52.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis55 = categoryPlot52.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo57 = null;
        java.awt.geom.Point2D point2D58 = null;
        categoryPlot52.zoomDomainAxes((double) 10.0f, plotRenderingInfo57, point2D58, false);
        java.lang.Comparable comparable61 = categoryPlot52.getDomainCrosshairColumnKey();
        boolean boolean62 = categoryPlot52.isRangeCrosshairLockedOnData();
        org.jfree.chart.util.RectangleInsets rectangleInsets63 = categoryPlot52.getAxisOffset();
        categoryPlot52.configureDomainAxes();
        org.jfree.chart.entity.PlotEntity plotEntity65 = new org.jfree.chart.entity.PlotEntity(shape24, (org.jfree.chart.plot.Plot) categoryPlot52);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator16);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNull(valueAxis28);
        org.junit.Assert.assertNotNull(drawingSupplier29);
        org.junit.Assert.assertNull(categoryDataset30);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNull(valueAxis35);
        org.junit.Assert.assertNotNull(axisLocation41);
        org.junit.Assert.assertNotNull(list44);
        org.junit.Assert.assertNull(valueAxis55);
        org.junit.Assert.assertNull(comparable61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNotNull(rectangleInsets63);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        lineAndShapeRenderer2.setAutoPopulateSeriesOutlinePaint(true);
        lineAndShapeRenderer2.setBaseLinesVisible(false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = null;
        lineAndShapeRenderer2.setSeriesURLGenerator(8, categoryURLGenerator8);
        lineAndShapeRenderer2.setBaseItemLabelsVisible(true);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier12 = lineAndShapeRenderer2.getDrawingSupplier();
        boolean boolean13 = lineAndShapeRenderer2.getBaseShapesVisible();
        org.junit.Assert.assertNull(drawingSupplier12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        java.lang.Comparable comparable9 = categoryPlot0.getDomainCrosshairColumnKey();
        boolean boolean10 = categoryPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = categoryPlot0.getAxisOffset();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot12.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis15 = categoryPlot12.getRangeAxis();
        int int16 = categoryPlot12.getBackgroundImageAlignment();
        categoryPlot12.setDomainCrosshairColumnKey((java.lang.Comparable) (short) -1, true);
        org.jfree.chart.util.Layer layer21 = null;
        java.util.Collection collection22 = categoryPlot12.getRangeMarkers((int) (short) 0, layer21);
        categoryPlot12.setRangeMinorGridlinesVisible(true);
        java.lang.String str25 = categoryPlot12.getNoDataMessage();
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot26.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis29 = categoryPlot26.getRangeAxis();
        int int30 = categoryPlot26.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder31 = categoryPlot26.getRowRenderingOrder();
        categoryPlot26.setWeight((int) (short) 100);
        boolean boolean34 = categoryPlot26.isDomainCrosshairVisible();
        org.jfree.chart.util.ShadowGenerator shadowGenerator35 = categoryPlot26.getShadowGenerator();
        categoryPlot12.setShadowGenerator(shadowGenerator35);
        categoryPlot0.setShadowGenerator(shadowGenerator35);
        org.jfree.chart.axis.AxisSpace axisSpace38 = categoryPlot0.getFixedRangeAxisSpace();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNull(comparable9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNull(valueAxis15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 15 + "'", int16 == 15);
        org.junit.Assert.assertNull(collection22);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertNull(valueAxis29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 15 + "'", int30 == 15);
        org.junit.Assert.assertNotNull(sortOrder31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(shadowGenerator35);
        org.junit.Assert.assertNull(axisSpace38);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor9 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis13 = categoryPlot10.getRangeAxis();
        int int14 = categoryPlot10.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder15 = categoryPlot10.getRowRenderingOrder();
        categoryPlot0.setRowRenderingOrder(sortOrder15);
        categoryPlot0.mapDatasetToDomainAxis(2, 10);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = categoryAxis22.getTickLabelInsets();
        categoryAxis22.setCategoryLabelPositionOffset(0);
        categoryAxis22.setMinorTickMarksVisible(false);
        float float28 = categoryAxis22.getMinorTickMarkOutsideLength();
        boolean boolean29 = categoryAxis22.isAxisLineVisible();
        categoryPlot0.setDomainAxis((int) (short) 10, categoryAxis22);
        java.lang.Object obj31 = categoryAxis22.clone();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(categoryAnchor9);
        org.junit.Assert.assertNull(valueAxis13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 15 + "'", int14 == 15);
        org.junit.Assert.assertNotNull(sortOrder15);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertTrue("'" + float28 + "' != '" + 2.0f + "'", float28 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(obj31);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        java.awt.Paint paint5 = categoryPlot0.getNoDataMessagePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = categoryPlot0.getDomainAxisForDataset((int) 'a');
        java.awt.Paint paint8 = categoryPlot0.getDomainCrosshairPaint();
        categoryPlot0.setRangePannable(true);
        org.jfree.chart.plot.PlotOrientation plotOrientation11 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke15 = lineAndShapeRenderer14.getBaseStroke();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator17 = null;
        lineAndShapeRenderer14.setSeriesItemLabelGenerator((int) (byte) 1, categoryItemLabelGenerator17);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer22 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke23 = lineAndShapeRenderer22.getBaseStroke();
        java.awt.Paint paint25 = lineAndShapeRenderer22.getSeriesPaint(15);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer29 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke30 = lineAndShapeRenderer29.getBaseStroke();
        java.awt.Stroke stroke32 = lineAndShapeRenderer29.lookupSeriesStroke(10);
        java.awt.Paint paint33 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        lineAndShapeRenderer29.setBaseOutlinePaint(paint33);
        java.awt.Font font35 = lineAndShapeRenderer29.getBaseItemLabelFont();
        lineAndShapeRenderer22.setSeriesItemLabelFont((int) (byte) 1, font35);
        lineAndShapeRenderer14.setSeriesItemLabelFont((int) (short) 10, font35, true);
        boolean boolean39 = plotOrientation11.equals((java.lang.Object) (short) 10);
        categoryPlot0.setOrientation(plotOrientation11);
        org.jfree.chart.plot.Marker marker41 = null;
        try {
            boolean boolean42 = categoryPlot0.removeRangeMarker(marker41);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(categoryAxis7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(plotOrientation11);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNull(paint25);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot0.setRangeAxisLocation(axisLocation1, true);
        java.lang.Comparable comparable4 = categoryPlot0.getDomainCrosshairColumnKey();
        java.awt.Color color5 = java.awt.Color.yellow;
        java.awt.color.ColorSpace colorSpace6 = color5.getColorSpace();
        float[] floatArray10 = new float[] { (byte) 1, '#', 15 };
        float[] floatArray11 = color5.getRGBColorComponents(floatArray10);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color5);
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = categoryPlot0.getRangeAxisEdge((int) (byte) 10);
        java.lang.Comparable comparable15 = null;
        categoryPlot0.setDomainCrosshairColumnKey(comparable15, false);
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNull(comparable4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(colorSpace6);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(rectangleEdge14);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = categoryAxis1.getTickLabelInsets();
        categoryAxis1.setCategoryLabelPositionOffset(0);
        categoryAxis1.setMinorTickMarksVisible(false);
        float float7 = categoryAxis1.getMinorTickMarkOutsideLength();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = categoryAxis1.getLabelInsets();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis1.setTickMarkPaint((java.awt.Paint) color9);
        categoryAxis1.setMinorTickMarkInsideLength((float) 1L);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot13.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis16 = categoryPlot13.getRangeAxis();
        int int17 = categoryPlot13.getBackgroundImageAlignment();
        categoryPlot13.setDomainCrosshairColumnKey((java.lang.Comparable) (short) -1, true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer21 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer21.clearSeriesStrokes(true);
        lineAndShapeRenderer21.setAutoPopulateSeriesFillPaint(true);
        java.awt.Stroke stroke26 = lineAndShapeRenderer21.getBaseOutlineStroke();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer29 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke30 = lineAndShapeRenderer29.getBaseStroke();
        java.awt.Paint paint32 = lineAndShapeRenderer29.getSeriesPaint(15);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition34 = lineAndShapeRenderer29.getSeriesNegativeItemLabelPosition(255);
        java.awt.Font font35 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        lineAndShapeRenderer29.setBaseLegendTextFont(font35);
        lineAndShapeRenderer21.setBaseItemLabelFont(font35);
        categoryPlot13.setNoDataMessageFont(font35);
        categoryAxis1.setLabelFont(font35);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 2.0f + "'", float7 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNull(valueAxis16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 15 + "'", int17 == 15);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNull(paint32);
        org.junit.Assert.assertNotNull(itemLabelPosition34);
        org.junit.Assert.assertNotNull(font35);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent9 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot0);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer12 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke13 = lineAndShapeRenderer12.getBaseStroke();
        categoryPlot0.setRangeMinorGridlineStroke(stroke13);
        boolean boolean15 = categoryPlot0.isRangeZeroBaselineVisible();
        org.jfree.chart.event.AnnotationChangeEvent annotationChangeEvent16 = null;
        categoryPlot0.annotationChanged(annotationChangeEvent16);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        java.awt.Shape shape4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        int int9 = categoryPlot5.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot5.getRowRenderingOrder();
        java.awt.Stroke stroke11 = categoryPlot5.getRangeZeroBaselineStroke();
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("", "", "hi!", "", shape4, stroke11, paint12);
        legendItem13.setDescription("");
        int int16 = legendItem13.getDatasetIndex();
        java.awt.Paint paint17 = legendItem13.getLinePaint();
        legendItem13.setToolTipText("SortOrder.ASCENDING");
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        java.awt.Shape shape4 = null;
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem6 = new org.jfree.chart.LegendItem("", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", shape4, (java.awt.Paint) color5);
        java.awt.Shape shape7 = legendItem6.getShape();
        int int8 = legendItem6.getSeriesIndex();
        boolean boolean9 = legendItem6.isShapeVisible();
        java.lang.Object obj10 = legendItem6.clone();
        legendItem6.setToolTipText("ChartChangeEventType.NEW_DATASET");
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(shape7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.clearSeriesStrokes(true);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator4 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("java.awt.Color[r=0,g=0,b=0]");
        lineAndShapeRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator4);
        java.awt.Paint paint9 = lineAndShapeRenderer0.getItemFillPaint((int) (byte) 0, 156, true);
        boolean boolean10 = lineAndShapeRenderer0.getBaseSeriesVisibleInLegend();
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        lineAndShapeRenderer2.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator7);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = lineAndShapeRenderer2.getSeriesPositiveItemLabelPosition(0);
        lineAndShapeRenderer2.setBaseShapesFilled(false);
        lineAndShapeRenderer2.setSeriesShapesVisible(2, (java.lang.Boolean) true);
        boolean boolean19 = lineAndShapeRenderer2.getItemCreateEntity(0, (-10214656), false);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        java.awt.Shape shape4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        int int9 = categoryPlot5.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot5.getRowRenderingOrder();
        java.awt.Stroke stroke11 = categoryPlot5.getRangeZeroBaselineStroke();
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("", "", "hi!", "", shape4, stroke11, paint12);
        legendItem13.setDescription("");
        int int16 = legendItem13.getDatasetIndex();
        java.lang.String str17 = legendItem13.getLabel();
        java.lang.String str18 = legendItem13.getLabel();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset19 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo20 = new org.jfree.chart.event.DatasetChangeInfo();
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent21 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object) legendItem13, (org.jfree.data.general.Dataset) defaultCategoryDataset19, datasetChangeInfo20);
        defaultCategoryDataset19.addValue((double) 2.0f, (java.lang.Comparable) '4', (java.lang.Comparable) 'a');
        try {
            defaultCategoryDataset19.incrementValue(0.2d, (java.lang.Comparable) 64, (java.lang.Comparable) 'a');
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Row key (64) not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        java.awt.Stroke stroke0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getMinimumBarLength();
        java.awt.Paint paint5 = barRenderer0.getItemPaint(0, 15, true);
        barRenderer0.setShadowXOffset((double) 100L);
        boolean boolean8 = barRenderer0.getAutoPopulateSeriesFillPaint();
        boolean boolean12 = barRenderer0.isItemLabelVisible(156, 0, false);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Shape shape9 = lineAndShapeRenderer2.getItemShape((int) (short) 10, 100, true);
        lineAndShapeRenderer2.setBaseCreateEntities(true);
        lineAndShapeRenderer2.setAutoPopulateSeriesOutlinePaint(false);
        java.awt.Shape shape14 = lineAndShapeRenderer2.getBaseLegendShape();
        lineAndShapeRenderer2.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator18 = null;
        lineAndShapeRenderer2.setSeriesItemLabelGenerator(255, categoryItemLabelGenerator18, false);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNull(shape14);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Shape shape9 = lineAndShapeRenderer2.getItemShape((int) (short) 10, 100, true);
        java.awt.Paint paint11 = lineAndShapeRenderer2.getSeriesFillPaint((int) (short) 10);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator12 = null;
        lineAndShapeRenderer2.setBaseURLGenerator(categoryURLGenerator12);
        boolean boolean16 = lineAndShapeRenderer2.getItemShapeFilled((int) 'a', 2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator20 = lineAndShapeRenderer2.getURLGenerator((int) '#', (-1), false);
        java.awt.Color color24 = java.awt.Color.getHSBColor((float) 100L, 0.0f, 100.0f);
        lineAndShapeRenderer2.setBaseFillPaint((java.awt.Paint) color24, false);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNull(categoryURLGenerator20);
        org.junit.Assert.assertNotNull(color24);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Paint paint6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        lineAndShapeRenderer2.setBaseOutlinePaint(paint6);
        org.jfree.chart.renderer.RenderAttributes renderAttributes9 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        renderAttributes9.setDefaultFillPaint((java.awt.Paint) color10);
        java.awt.Stroke stroke13 = renderAttributes9.getSeriesStroke((int) ' ');
        java.awt.Shape shape15 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity18 = new org.jfree.chart.entity.ChartEntity(shape15, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape19 = chartEntity18.getArea();
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot20.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis23 = categoryPlot20.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        categoryPlot20.zoomDomainAxes((double) 10.0f, plotRenderingInfo25, point2D26, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor29 = categoryPlot20.getDomainGridlinePosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot30.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis33 = categoryPlot30.getRangeAxis();
        int int34 = categoryPlot30.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder35 = categoryPlot30.getRowRenderingOrder();
        java.awt.Stroke stroke36 = categoryPlot30.getRangeZeroBaselineStroke();
        categoryPlot20.setRangeMinorGridlineStroke(stroke36);
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = categoryPlot20.getDomainAxis(100);
        boolean boolean40 = categoryPlot20.isNotify();
        org.jfree.chart.entity.PlotEntity plotEntity42 = new org.jfree.chart.entity.PlotEntity(shape19, (org.jfree.chart.plot.Plot) categoryPlot20, "ItemLabelAnchor.OUTSIDE1");
        renderAttributes9.setSeriesShape((int) (byte) 100, shape19);
        lineAndShapeRenderer2.setSeriesShape(128, shape19, false);
        java.lang.Boolean boolean47 = lineAndShapeRenderer2.getSeriesShapesVisible(100);
        lineAndShapeRenderer2.setBaseSeriesVisibleInLegend(false, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition54 = lineAndShapeRenderer2.getNegativeItemLabelPosition((int) (short) -1, 156, false);
        lineAndShapeRenderer2.setAutoPopulateSeriesStroke(false);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNull(stroke13);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(categoryAnchor29);
        org.junit.Assert.assertNull(valueAxis33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 15 + "'", int34 == 15);
        org.junit.Assert.assertNotNull(sortOrder35);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNull(categoryAxis39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNull(boolean47);
        org.junit.Assert.assertNotNull(itemLabelPosition54);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        java.awt.Shape shape4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        int int9 = categoryPlot5.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot5.getRowRenderingOrder();
        java.awt.Stroke stroke11 = categoryPlot5.getRangeZeroBaselineStroke();
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("", "", "hi!", "", shape4, stroke11, paint12);
        legendItem13.setDescription("");
        int int16 = legendItem13.getDatasetIndex();
        java.lang.String str17 = legendItem13.getLabel();
        java.lang.String str18 = legendItem13.getLabel();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset19 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo20 = new org.jfree.chart.event.DatasetChangeInfo();
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent21 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object) legendItem13, (org.jfree.data.general.Dataset) defaultCategoryDataset19, datasetChangeInfo20);
        defaultCategoryDataset19.addValue((java.lang.Number) 1.0d, (java.lang.Comparable) false, (java.lang.Comparable) (byte) 1);
        try {
            defaultCategoryDataset19.setSelected(0, 8, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        categoryPlot0.setDomainCrosshairColumnKey((java.lang.Comparable) (short) -1, true);
        org.jfree.chart.util.Layer layer9 = null;
        java.util.Collection collection10 = categoryPlot0.getRangeMarkers((int) (short) 0, layer9);
        categoryPlot0.setRangeCrosshairLockedOnData(false);
        java.lang.Comparable comparable13 = categoryPlot0.getDomainCrosshairColumnKey();
        org.jfree.chart.axis.AxisSpace axisSpace14 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace14, true);
        org.jfree.chart.plot.Marker marker17 = null;
        org.jfree.chart.util.Layer layer18 = null;
        try {
            boolean boolean19 = categoryPlot0.removeRangeMarker(marker17, layer18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNull(collection10);
        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + (short) -1 + "'", comparable13.equals((short) -1));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getMinimumBarLength();
        java.awt.Paint paint5 = barRenderer0.getItemPaint(0, 15, true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator6 = barRenderer0.getBaseURLGenerator();
        boolean boolean7 = barRenderer0.getAutoPopulateSeriesPaint();
        java.awt.Shape shape12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot13.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis16 = categoryPlot13.getRangeAxis();
        int int17 = categoryPlot13.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder18 = categoryPlot13.getRowRenderingOrder();
        java.awt.Stroke stroke19 = categoryPlot13.getRangeZeroBaselineStroke();
        java.awt.Paint paint20 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem21 = new org.jfree.chart.LegendItem("", "", "hi!", "", shape12, stroke19, paint20);
        legendItem21.setDescription("");
        int int24 = legendItem21.getDatasetIndex();
        java.lang.String str25 = legendItem21.getLabel();
        java.lang.String str26 = legendItem21.getLabel();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset27 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo28 = new org.jfree.chart.event.DatasetChangeInfo();
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent29 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object) legendItem21, (org.jfree.data.general.Dataset) defaultCategoryDataset27, datasetChangeInfo28);
        defaultCategoryDataset27.clearSelection();
        int int31 = defaultCategoryDataset27.getRowCount();
        int int33 = defaultCategoryDataset27.getColumnIndex((java.lang.Comparable) "AxisLocation.BOTTOM_OR_LEFT");
        org.jfree.data.Range range35 = barRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset27, true);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(categoryURLGenerator6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(valueAxis16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 15 + "'", int17 == 15);
        org.junit.Assert.assertNotNull(sortOrder18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertNull(range35);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape2, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape6 = chartEntity5.getArea();
        java.awt.Shape shape7 = chartEntity5.getArea();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot8.getDomainAxisEdge();
        int int12 = categoryPlot8.getWeight();
        java.lang.Comparable comparable13 = categoryPlot8.getDomainCrosshairColumnKey();
        boolean boolean14 = categoryPlot8.canSelectByRegion();
        org.jfree.chart.axis.AxisLocation axisLocation15 = categoryPlot8.getRangeAxisLocation();
        org.jfree.chart.entity.PlotEntity plotEntity18 = new org.jfree.chart.entity.PlotEntity(shape7, (org.jfree.chart.plot.Plot) categoryPlot8, "ItemLabelAnchor.OUTSIDE1", "java.awt.Color[r=0,g=0,b=0]");
        shapeList0.setShape(156, shape7);
        java.awt.Shape shape21 = shapeList0.getShape((int) (byte) 1);
        boolean boolean23 = shapeList0.equals((java.lang.Object) "PlotEntity: tooltip = ItemLabelAnchor.OUTSIDE1");
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNull(comparable13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNull(shape21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getMinimumBarLength();
        java.awt.Paint paint5 = barRenderer0.getItemPaint(0, 15, true);
        barRenderer0.setShadowVisible(true);
        barRenderer0.setIncludeBaseInRange(true);
        barRenderer0.setDrawBarOutline(true);
        barRenderer0.setAutoPopulateSeriesFillPaint(false);
        double double14 = barRenderer0.getMaximumBarWidth();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.clearSeriesStrokes(true);
        lineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(true);
        java.awt.Stroke stroke5 = lineAndShapeRenderer0.getBaseOutlineStroke();
        int int6 = lineAndShapeRenderer0.getPassCount();
        lineAndShapeRenderer0.setSeriesItemLabelsVisible(0, (java.lang.Boolean) false);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent9 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot0);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis13 = categoryPlot10.getRangeAxis();
        int int14 = categoryPlot10.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder15 = categoryPlot10.getRowRenderingOrder();
        java.awt.Stroke stroke16 = categoryPlot10.getRangeZeroBaselineStroke();
        categoryPlot0.setOutlineStroke(stroke16);
        org.jfree.chart.plot.Marker marker19 = null;
        org.jfree.chart.util.Layer layer20 = null;
        boolean boolean21 = categoryPlot0.removeDomainMarker(15, marker19, layer20);
        categoryPlot0.setOutlineVisible(true);
        org.jfree.chart.util.SortOrder sortOrder24 = categoryPlot0.getColumnRenderingOrder();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        java.awt.geom.Point2D point2D28 = null;
        categoryPlot0.zoomDomainAxes((double) (-256), (double) (-256), plotRenderingInfo27, point2D28);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNull(valueAxis13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 15 + "'", int14 == 15);
        org.junit.Assert.assertNotNull(sortOrder15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(sortOrder24);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        java.awt.Color color1 = java.awt.Color.GRAY;
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator5 = new org.jfree.chart.util.DefaultShadowGenerator((int) (short) -1, color1, 0.0f, (int) (byte) -1, (double) 'a');
        int int6 = defaultShadowGenerator5.calculateOffsetY();
        float float7 = defaultShadowGenerator5.getShadowOpacity();
        java.awt.image.BufferedImage bufferedImage8 = null;
        try {
            java.awt.image.BufferedImage bufferedImage9 = defaultShadowGenerator5.createDropShadow(bufferedImage8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = categoryAxis1.getTickLabelInsets();
        categoryAxis1.setCategoryLabelPositionOffset(0);
        categoryAxis1.setMinorTickMarksVisible(false);
        float float7 = categoryAxis1.getMinorTickMarkOutsideLength();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = categoryAxis1.getLabelInsets();
        org.jfree.chart.util.UnitType unitType9 = rectangleInsets8.getUnitType();
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D13 = rectangleInsets8.createInsetRectangle(rectangle2D10, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 2.0f + "'", float7 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(unitType9);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(64);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder5 = categoryPlot0.getRowRenderingOrder();
        java.awt.Stroke stroke6 = categoryPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent7 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent7);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot9.setRangeAxisLocation(axisLocation10, true);
        categoryPlot0.setDomainAxisLocation(axisLocation10);
        categoryPlot0.setCrosshairDatasetIndex((int) (short) 1);
        org.jfree.data.category.CategoryDataset categoryDataset16 = categoryPlot0.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = categoryPlot0.getAxisOffset();
        org.jfree.chart.util.SortOrder sortOrder18 = categoryPlot0.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor19 = null;
        try {
            categoryPlot0.setDomainGridlinePosition(categoryAnchor19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(sortOrder5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNull(categoryDataset16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(sortOrder18);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        java.awt.Color color0 = java.awt.Color.yellow;
        java.awt.color.ColorSpace colorSpace1 = color0.getColorSpace();
        int int2 = color0.getTransparency();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot4.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis7 = categoryPlot4.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot4.zoomDomainAxes((double) 10.0f, plotRenderingInfo9, point2D10, false);
        java.lang.Comparable comparable13 = categoryPlot4.getDomainCrosshairColumnKey();
        boolean boolean14 = categoryPlot4.isRangeCrosshairLockedOnData();
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        categoryPlot4.setDomainCrosshairPaint((java.awt.Paint) color15);
        java.awt.Shape shape21 = null;
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", shape21, (java.awt.Paint) color22);
        categoryPlot4.setDomainGridlinePaint((java.awt.Paint) color22);
        java.awt.Color color25 = java.awt.Color.getColor("PlotEntity: tooltip = ItemLabelAnchor.OUTSIDE1", color22);
        java.awt.Color color32 = java.awt.Color.getHSBColor((float) (short) 1, (float) 100, 0.0f);
        float[] floatArray39 = new float[] { (byte) 10, (byte) 1, 1.0f, (byte) 0, 10, (byte) 100 };
        float[] floatArray40 = color32.getRGBComponents(floatArray39);
        float[] floatArray41 = java.awt.Color.RGBtoHSB((int) ' ', 1, 255, floatArray39);
        float[] floatArray42 = color25.getComponents(floatArray41);
        float[] floatArray43 = color0.getRGBColorComponents(floatArray42);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(colorSpace1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNull(comparable13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(floatArray39);
        org.junit.Assert.assertNotNull(floatArray40);
        org.junit.Assert.assertNotNull(floatArray41);
        org.junit.Assert.assertNotNull(floatArray42);
        org.junit.Assert.assertNotNull(floatArray43);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        java.awt.Paint paint4 = categoryPlot0.getDomainGridlinePaint();
        categoryPlot0.configureRangeAxes();
        categoryPlot0.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor8 = categoryPlot0.getDomainGridlinePosition();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(categoryAnchor8);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        java.awt.Paint paint4 = categoryPlot0.getDomainGridlinePaint();
        boolean boolean5 = categoryPlot0.isDomainCrosshairVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = categoryPlot0.getRenderer((int) (byte) 100);
        org.jfree.data.KeyedObjects keyedObjects9 = new org.jfree.data.KeyedObjects();
        int int11 = keyedObjects9.getIndex((java.lang.Comparable) (short) 100);
        java.util.List list12 = keyedObjects9.getKeys();
        try {
            categoryPlot0.mapDatasetToRangeAxes((int) (short) 0, list12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Empty list not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(categoryItemRenderer7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(list12);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        lineAndShapeRenderer2.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator7);
        lineAndShapeRenderer2.setSeriesVisible((int) (short) 100, (java.lang.Boolean) false, true);
        boolean boolean15 = lineAndShapeRenderer2.getItemShapeVisible((int) (short) 10, 3);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator16 = lineAndShapeRenderer2.getLegendItemLabelGenerator();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = lineAndShapeRenderer2.getSeriesPositiveItemLabelPosition((int) (short) -1);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier19 = lineAndShapeRenderer2.getDrawingSupplier();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator16);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNull(drawingSupplier19);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("");
        java.lang.String str2 = datasetGroup1.getID();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        lineAndShapeRenderer2.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer11 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke12 = lineAndShapeRenderer11.getBaseStroke();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator14 = null;
        lineAndShapeRenderer11.setSeriesItemLabelGenerator((int) (byte) 1, categoryItemLabelGenerator14);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke20 = lineAndShapeRenderer19.getBaseStroke();
        java.awt.Paint paint22 = lineAndShapeRenderer19.getSeriesPaint(15);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer26 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke27 = lineAndShapeRenderer26.getBaseStroke();
        java.awt.Stroke stroke29 = lineAndShapeRenderer26.lookupSeriesStroke(10);
        java.awt.Paint paint30 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        lineAndShapeRenderer26.setBaseOutlinePaint(paint30);
        java.awt.Font font32 = lineAndShapeRenderer26.getBaseItemLabelFont();
        lineAndShapeRenderer19.setSeriesItemLabelFont((int) (byte) 1, font32);
        lineAndShapeRenderer11.setSeriesItemLabelFont((int) (short) 10, font32, true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer39 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke40 = lineAndShapeRenderer39.getBaseStroke();
        java.awt.Stroke stroke42 = lineAndShapeRenderer39.lookupSeriesStroke(10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator44 = null;
        lineAndShapeRenderer39.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator44);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition47 = lineAndShapeRenderer39.getSeriesPositiveItemLabelPosition(0);
        lineAndShapeRenderer39.setBaseShapesFilled(false);
        lineAndShapeRenderer39.setSeriesVisibleInLegend((int) (short) 10, (java.lang.Boolean) false);
        java.awt.Stroke stroke54 = lineAndShapeRenderer39.lookupSeriesOutlineStroke((-1));
        lineAndShapeRenderer11.setSeriesStroke((int) (short) 10, stroke54, false);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor57 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE5;
        java.awt.Color color58 = java.awt.Color.white;
        boolean boolean59 = itemLabelAnchor57.equals((java.lang.Object) color58);
        org.jfree.chart.text.TextAnchor textAnchor60 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition61 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor57, textAnchor60);
        org.jfree.chart.text.TextAnchor textAnchor62 = itemLabelPosition61.getRotationAnchor();
        lineAndShapeRenderer11.setBasePositiveItemLabelPosition(itemLabelPosition61);
        org.jfree.chart.text.TextAnchor textAnchor64 = itemLabelPosition61.getRotationAnchor();
        lineAndShapeRenderer2.setSeriesPositiveItemLabelPosition((int) (byte) 100, itemLabelPosition61);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNull(paint22);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(itemLabelPosition47);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertNotNull(itemLabelAnchor57);
        org.junit.Assert.assertNotNull(color58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(textAnchor60);
        org.junit.Assert.assertNotNull(textAnchor62);
        org.junit.Assert.assertNotNull(textAnchor64);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = categoryAxis1.getTickLabelInsets();
        categoryAxis1.setCategoryLabelPositionOffset(0);
        categoryAxis1.setMinorTickMarksVisible(false);
        float float7 = categoryAxis1.getMinorTickMarkOutsideLength();
        boolean boolean8 = categoryAxis1.isVisible();
        categoryAxis1.setTickMarkOutsideLength((float) 10L);
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        double double12 = barRenderer11.getMinimumBarLength();
        java.awt.Paint paint16 = barRenderer11.getItemPaint(0, 15, true);
        barRenderer11.setShadowVisible(true);
        java.awt.Shape shape20 = barRenderer11.lookupSeriesShape(255);
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot21.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis24 = categoryPlot21.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        java.awt.geom.Point2D point2D27 = null;
        categoryPlot21.zoomDomainAxes((double) 10.0f, plotRenderingInfo26, point2D27, false);
        boolean boolean30 = categoryPlot21.isRangeCrosshairVisible();
        java.awt.Stroke stroke31 = categoryPlot21.getRangeCrosshairStroke();
        barRenderer11.setBaseOutlineStroke(stroke31, true);
        categoryAxis1.setAxisLineStroke(stroke31);
        categoryAxis1.setTickMarksVisible(false);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 2.0f + "'", float7 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNull(valueAxis24);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(stroke31);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = categoryAxis1.getTickLabelInsets();
        categoryAxis1.setCategoryLabelPositionOffset(0);
        categoryAxis1.setMinorTickMarksVisible(false);
        float float7 = categoryAxis1.getMinorTickMarkOutsideLength();
        boolean boolean8 = categoryAxis1.isVisible();
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean13 = categoryPlot12.isRangeGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = categoryPlot12.getRangeAxisEdge((int) (byte) -1);
        org.jfree.chart.axis.AxisState axisState16 = null;
        categoryAxis1.drawTickMarks(graphics2D9, (double) 1L, rectangle2D11, rectangleEdge15, axisState16);
        categoryAxis1.setTickMarkInsideLength(0.0f);
        categoryAxis1.removeCategoryLabelToolTip((java.lang.Comparable) (-1.0d));
        categoryAxis1.setTickLabelsVisible(false);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 2.0f + "'", float7 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(rectangleEdge15);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis4 = categoryPlot1.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot1.zoomDomainAxes((double) 10.0f, plotRenderingInfo6, point2D7, false);
        java.lang.Comparable comparable10 = categoryPlot1.getDomainCrosshairColumnKey();
        boolean boolean11 = categoryPlot1.isRangeCrosshairLockedOnData();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        categoryPlot1.setDomainCrosshairPaint((java.awt.Paint) color12);
        java.awt.Shape shape18 = null;
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", shape18, (java.awt.Paint) color19);
        categoryPlot1.setDomainGridlinePaint((java.awt.Paint) color19);
        java.awt.Color color22 = java.awt.Color.getColor("PlotEntity: tooltip = ItemLabelAnchor.OUTSIDE1", color19);
        java.awt.Color color29 = java.awt.Color.getHSBColor((float) (short) 1, (float) 100, 0.0f);
        float[] floatArray36 = new float[] { (byte) 10, (byte) 1, 1.0f, (byte) 0, 10, (byte) 100 };
        float[] floatArray37 = color29.getRGBComponents(floatArray36);
        float[] floatArray38 = java.awt.Color.RGBtoHSB((int) ' ', 1, 255, floatArray36);
        float[] floatArray39 = color22.getComponents(floatArray38);
        java.awt.Color color40 = color22.brighter();
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertNull(comparable10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(floatArray36);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertNotNull(floatArray38);
        org.junit.Assert.assertNotNull(floatArray39);
        org.junit.Assert.assertNotNull(color40);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        java.lang.Number number0 = null;
        org.jfree.data.SelectableValue selectableValue2 = new org.jfree.data.SelectableValue(number0, false);
        selectableValue2.setSelected(true);
        java.lang.Number number5 = selectableValue2.getValue();
        org.junit.Assert.assertNull(number5);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getMinimumBarLength();
        java.awt.Paint paint5 = barRenderer0.getItemPaint(0, 15, true);
        barRenderer0.setShadowVisible(true);
        barRenderer0.setIncludeBaseInRange(true);
        barRenderer0.setDrawBarOutline(true);
        barRenderer0.setAutoPopulateSeriesFillPaint(false);
        barRenderer0.setItemMargin(100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = categoryAxis1.getTickLabelInsets();
        categoryAxis1.setCategoryLabelPositionOffset(0);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        int int9 = categoryPlot5.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot5.getRowRenderingOrder();
        java.awt.Stroke stroke11 = categoryPlot5.getRangeZeroBaselineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        categoryPlot5.rendererChanged(rendererChangeEvent12);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot14.setRangeAxisLocation(axisLocation15, true);
        categoryPlot5.setDomainAxisLocation(axisLocation15);
        categoryPlot5.setCrosshairDatasetIndex((int) (short) 1);
        categoryAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot5);
        categoryPlot5.setRangeGridlinesVisible(true);
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = categoryPlot5.getDomainAxis();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNull(categoryAxis24);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        renderAttributes1.setDefaultFillPaint((java.awt.Paint) color2);
        org.jfree.chart.LegendItem legendItem4 = new org.jfree.chart.LegendItem("hi!", (java.awt.Paint) color2);
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity8 = new org.jfree.chart.entity.ChartEntity(shape5, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape9 = chartEntity8.getArea();
        legendItem4.setLine(shape9);
        java.text.AttributedString attributedString11 = legendItem4.getAttributedLabel();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNull(attributedString11);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder5 = categoryPlot0.getRowRenderingOrder();
        java.awt.Stroke stroke6 = categoryPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent7 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent7);
        categoryPlot0.setRangeCrosshairVisible(false);
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = null;
        org.jfree.chart.util.Layer layer13 = null;
        try {
            categoryPlot0.addDomainMarker((int) '4', categoryMarker12, layer13, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(sortOrder5);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("AxisLocation.BOTTOM_OR_LEFT");
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis5 = categoryPlot2.getRangeAxis();
        int int6 = categoryPlot2.getBackgroundImageAlignment();
        categoryPlot2.setDomainCrosshairColumnKey((java.lang.Comparable) (short) -1, true);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot2.getRangeMarkers((int) (short) 0, layer11);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot13.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis16 = categoryPlot13.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        categoryPlot13.zoomDomainAxes((double) 10.0f, plotRenderingInfo18, point2D19, false);
        java.lang.Comparable comparable22 = categoryPlot13.getDomainCrosshairColumnKey();
        boolean boolean23 = categoryPlot13.isRangeCrosshairLockedOnData();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = categoryPlot13.getAxisOffset();
        double double25 = rectangleInsets24.getLeft();
        categoryPlot2.setAxisOffset(rectangleInsets24);
        boolean boolean27 = standardCategorySeriesLabelGenerator1.equals((java.lang.Object) rectangleInsets24);
        double double29 = rectangleInsets24.calculateRightInset(100.0d);
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNull(valueAxis16);
        org.junit.Assert.assertNull(comparable22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 4.0d + "'", double25 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 4.0d + "'", double29 == 4.0d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        renderAttributes0.setDefaultFillPaint((java.awt.Paint) color1);
        java.awt.Shape shape5 = renderAttributes0.getItemShape((int) (byte) 100, (int) 'a');
        java.awt.Shape shape7 = null;
        renderAttributes0.setSeriesShape((int) (byte) 1, shape7);
        renderAttributes0.setDefaultCreateEntity((java.lang.Boolean) true);
        java.awt.Paint paint11 = renderAttributes0.getDefaultPaint();
        java.awt.Paint paint12 = renderAttributes0.getDefaultPaint();
        java.awt.Paint paint13 = renderAttributes0.getDefaultOutlinePaint();
        java.awt.Stroke stroke14 = renderAttributes0.getDefaultOutlineStroke();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNull(shape5);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertNull(stroke14);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getMinimumBarLength();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = barRenderer0.getNegativeItemLabelPositionFallback();
        java.awt.Paint paint4 = null;
        barRenderer0.setSeriesFillPaint(64, paint4, false);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(itemLabelPosition2);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        java.awt.Shape shape4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        int int9 = categoryPlot5.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot5.getRowRenderingOrder();
        java.awt.Stroke stroke11 = categoryPlot5.getRangeZeroBaselineStroke();
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("", "", "hi!", "", shape4, stroke11, paint12);
        legendItem13.setDescription("");
        int int16 = legendItem13.getDatasetIndex();
        java.lang.String str17 = legendItem13.getLabel();
        java.lang.String str18 = legendItem13.getLabel();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset19 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo20 = new org.jfree.chart.event.DatasetChangeInfo();
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent21 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object) legendItem13, (org.jfree.data.general.Dataset) defaultCategoryDataset19, datasetChangeInfo20);
        defaultCategoryDataset19.addValue((java.lang.Number) 1.0d, (java.lang.Comparable) false, (java.lang.Comparable) (byte) 1);
        java.lang.Comparable comparable27 = defaultCategoryDataset19.getColumnKey(0);
        try {
            java.lang.Number number30 = defaultCategoryDataset19.getValue((int) (byte) 1, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + comparable27 + "' != '" + (byte) 1 + "'", comparable27.equals((byte) 1));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        java.awt.Shape shape4 = null;
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem6 = new org.jfree.chart.LegendItem("", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", shape4, (java.awt.Paint) color5);
        java.awt.Paint paint7 = legendItem6.getLabelPaint();
        java.awt.Paint paint8 = legendItem6.getLabelPaint();
        boolean boolean9 = legendItem6.isLineVisible();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier1 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis5 = categoryPlot2.getRangeAxis();
        int int6 = categoryPlot2.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder7 = categoryPlot2.getRowRenderingOrder();
        java.awt.Stroke stroke8 = categoryPlot2.getRangeZeroBaselineStroke();
        categoryPlot2.setRangeGridlinesVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot11.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis14 = categoryPlot11.getRangeAxis();
        int int15 = categoryPlot11.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder16 = categoryPlot11.getRowRenderingOrder();
        java.awt.Stroke stroke17 = categoryPlot11.getRangeZeroBaselineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent18 = null;
        categoryPlot11.rendererChanged(rendererChangeEvent18);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation21 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot20.setRangeAxisLocation(axisLocation21, true);
        categoryPlot11.setDomainAxisLocation(axisLocation21);
        categoryPlot2.setDomainAxisLocation(axisLocation21, true);
        categoryPlot2.setBackgroundAlpha((float) 10);
        boolean boolean29 = defaultDrawingSupplier1.equals((java.lang.Object) 10);
        java.awt.Paint paint30 = defaultDrawingSupplier1.getNextOutlinePaint();
        lineAndShapeRenderer0.setBaseFillPaint(paint30, true);
        lineAndShapeRenderer0.setBaseItemLabelsVisible(true);
        boolean boolean36 = lineAndShapeRenderer0.isSeriesVisibleInLegend(1);
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
        org.junit.Assert.assertNotNull(sortOrder7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(valueAxis14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 15 + "'", int15 == 15);
        org.junit.Assert.assertNotNull(sortOrder16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getMinimumBarLength();
        java.awt.Paint paint5 = barRenderer0.getItemPaint(0, 15, true);
        double double6 = barRenderer0.getShadowXOffset();
        barRenderer0.setShadowYOffset((double) 2);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot0.setRangeAxisLocation(axisLocation1, true);
        java.lang.Comparable comparable4 = categoryPlot0.getDomainCrosshairColumnKey();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke8 = lineAndShapeRenderer7.getBaseStroke();
        org.jfree.chart.LegendItemCollection legendItemCollection9 = lineAndShapeRenderer7.getLegendItems();
        categoryPlot0.setFixedLegendItems(legendItemCollection9);
        java.awt.Shape shape15 = null;
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", shape15, (java.awt.Paint) color16);
        java.awt.Shape shape18 = legendItem17.getShape();
        int int19 = legendItem17.getSeriesIndex();
        boolean boolean20 = legendItem17.isShapeVisible();
        java.lang.String str21 = legendItem17.getLabel();
        int int22 = legendItem17.getSeriesIndex();
        java.awt.Color color23 = java.awt.Color.yellow;
        java.awt.color.ColorSpace colorSpace24 = color23.getColorSpace();
        int int25 = color23.getTransparency();
        legendItem17.setLinePaint((java.awt.Paint) color23);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer27 = legendItem17.getFillPaintTransformer();
        legendItemCollection9.add(legendItem17);
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNull(comparable4);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(legendItemCollection9);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(shape18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(colorSpace24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(gradientPaintTransformer27);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        org.jfree.chart.LegendItemCollection legendItemCollection4 = lineAndShapeRenderer2.getLegendItems();
        int int5 = legendItemCollection4.getItemCount();
        try {
            org.jfree.chart.LegendItem legendItem7 = legendItemCollection4.get(255);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 255, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(legendItemCollection4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = categoryAxis1.getTickLabelInsets();
        categoryAxis1.setCategoryLabelPositionOffset(0);
        categoryAxis1.setMinorTickMarksVisible(false);
        float float7 = categoryAxis1.getMinorTickMarkOutsideLength();
        boolean boolean8 = categoryAxis1.isVisible();
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean13 = categoryPlot12.isRangeGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = categoryPlot12.getRangeAxisEdge((int) (byte) -1);
        org.jfree.chart.axis.AxisState axisState16 = null;
        categoryAxis1.drawTickMarks(graphics2D9, (double) 1L, rectangle2D11, rectangleEdge15, axisState16);
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = categoryAxis19.getTickLabelInsets();
        categoryAxis19.setCategoryLabelPositionOffset(0);
        categoryAxis19.setMinorTickMarksVisible(false);
        float float25 = categoryAxis19.getMinorTickMarkOutsideLength();
        boolean boolean26 = categoryAxis19.isVisible();
        categoryAxis19.setTickMarkOutsideLength((float) 10L);
        float float29 = categoryAxis19.getTickMarkOutsideLength();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer33 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke34 = lineAndShapeRenderer33.getBaseStroke();
        java.awt.Paint paint36 = lineAndShapeRenderer33.getSeriesPaint(15);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer40 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke41 = lineAndShapeRenderer40.getBaseStroke();
        java.awt.Stroke stroke43 = lineAndShapeRenderer40.lookupSeriesStroke(10);
        java.awt.Paint paint44 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        lineAndShapeRenderer40.setBaseOutlinePaint(paint44);
        java.awt.Font font46 = lineAndShapeRenderer40.getBaseItemLabelFont();
        lineAndShapeRenderer33.setSeriesItemLabelFont((int) (byte) 1, font46);
        categoryAxis19.setTickLabelFont((java.lang.Comparable) '4', font46);
        categoryAxis1.setTickLabelFont(font46);
        categoryAxis1.setAxisLineVisible(false);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 2.0f + "'", float7 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 2.0f + "'", float25 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 10.0f + "'", float29 == 10.0f);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNull(paint36);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(font46);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = lineAndShapeRenderer2.getBasePositiveItemLabelPosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot4.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = categoryPlot4.getDomainAxisEdge();
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot4.getDomainAxisLocation();
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        categoryPlot4.drawBackgroundImage(graphics2D9, rectangle2D10);
        java.awt.Paint paint12 = categoryPlot4.getNoDataMessagePaint();
        lineAndShapeRenderer2.setBaseItemLabelPaint(paint12);
        boolean boolean15 = lineAndShapeRenderer2.isSeriesVisibleInLegend(100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = lineAndShapeRenderer2.getSeriesNegativeItemLabelPosition(156);
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        lineAndShapeRenderer2.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator7);
        lineAndShapeRenderer2.setSeriesVisible((int) (short) 100, (java.lang.Boolean) false, true);
        boolean boolean15 = lineAndShapeRenderer2.getItemShapeVisible((int) (short) 10, 3);
        lineAndShapeRenderer2.removeAnnotations();
        lineAndShapeRenderer2.setAutoPopulateSeriesShape(false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer22 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke23 = lineAndShapeRenderer22.getBaseStroke();
        java.awt.Stroke stroke25 = lineAndShapeRenderer22.lookupSeriesStroke(10);
        java.awt.Shape shape31 = null;
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem33 = new org.jfree.chart.LegendItem("", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", shape31, (java.awt.Paint) color32);
        int int34 = color32.getBlue();
        lineAndShapeRenderer22.setSeriesItemLabelPaint((int) (byte) 1, (java.awt.Paint) color32);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean37 = categoryPlot36.isRangeGridlinesVisible();
        categoryPlot36.clearDomainAxes();
        lineAndShapeRenderer22.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot36);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator41 = lineAndShapeRenderer22.getSeriesURLGenerator((int) 'a');
        lineAndShapeRenderer22.setBaseItemLabelsVisible(true, false);
        java.lang.Boolean boolean46 = lineAndShapeRenderer22.getSeriesVisible(156);
        java.awt.Paint paint50 = lineAndShapeRenderer22.getItemLabelPaint((int) (byte) 100, 0, false);
        lineAndShapeRenderer2.setSeriesPaint(2, paint50);
        java.awt.Graphics2D graphics2D52 = null;
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis54 = null;
        org.jfree.chart.axis.ValueAxis valueAxis55 = null;
        org.jfree.chart.util.Layer layer56 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo57 = null;
        try {
            lineAndShapeRenderer2.drawAnnotations(graphics2D52, rectangle2D53, categoryAxis54, valueAxis55, layer56, plotRenderingInfo57);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 128 + "'", int34 == 128);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNull(categoryURLGenerator41);
        org.junit.Assert.assertNull(boolean46);
        org.junit.Assert.assertNotNull(paint50);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Shape shape11 = null;
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", shape11, (java.awt.Paint) color12);
        int int14 = color12.getBlue();
        lineAndShapeRenderer2.setSeriesItemLabelPaint((int) (byte) 1, (java.awt.Paint) color12);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean17 = categoryPlot16.isRangeGridlinesVisible();
        categoryPlot16.clearDomainAxes();
        lineAndShapeRenderer2.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot16);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator21 = lineAndShapeRenderer2.getSeriesURLGenerator((int) 'a');
        org.jfree.chart.renderer.category.BarRenderer barRenderer22 = new org.jfree.chart.renderer.category.BarRenderer();
        double double23 = barRenderer22.getMinimumBarLength();
        java.awt.Paint paint27 = barRenderer22.getItemPaint(0, 15, true);
        barRenderer22.setShadowVisible(true);
        java.awt.Shape shape31 = barRenderer22.lookupSeriesShape(255);
        lineAndShapeRenderer2.setBaseShape(shape31, true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 128 + "'", int14 == 128);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNull(categoryURLGenerator21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(shape31);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        renderAttributes0.setDefaultFillPaint((java.awt.Paint) color1);
        java.awt.Shape shape5 = renderAttributes0.getItemShape((int) (byte) 100, (int) 'a');
        java.awt.Shape shape7 = null;
        renderAttributes0.setSeriesShape((int) (byte) 1, shape7);
        renderAttributes0.setDefaultCreateEntity((java.lang.Boolean) true);
        java.awt.Paint paint11 = renderAttributes0.getDefaultPaint();
        java.awt.Shape shape12 = renderAttributes0.getDefaultShape();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNull(shape5);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNull(shape12);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.clearSeriesStrokes(true);
        java.lang.Boolean boolean4 = lineAndShapeRenderer0.getSeriesVisibleInLegend(3);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator6 = lineAndShapeRenderer0.getSeriesURLGenerator((-1));
        boolean boolean7 = lineAndShapeRenderer0.getUseSeriesOffset();
        lineAndShapeRenderer0.setBaseLinesVisible(false);
        boolean boolean13 = lineAndShapeRenderer0.isItemLabelVisible(10, (int) (byte) 1, false);
        java.awt.Color color14 = java.awt.Color.gray;
        lineAndShapeRenderer0.setBaseOutlinePaint((java.awt.Paint) color14);
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertNull(categoryURLGenerator6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(color14);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        categoryPlot0.setDomainGridlinesVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot5.zoomDomainAxes((double) 10.0f, plotRenderingInfo10, point2D11, false);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent14 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot5);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType15 = plotChangeEvent14.getType();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType16 = plotChangeEvent14.getType();
        java.lang.Object obj17 = plotChangeEvent14.getSource();
        categoryPlot0.notifyListeners(plotChangeEvent14);
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        int int20 = categoryPlot0.indexOf(categoryDataset19);
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        categoryPlot0.removeChangeListener(plotChangeListener21);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertNotNull(chartChangeEventType15);
        org.junit.Assert.assertNotNull(chartChangeEventType16);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getMinimumBarLength();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = null;
        barRenderer0.setSeriesURLGenerator((int) (short) 0, categoryURLGenerator3);
        java.lang.Boolean boolean6 = barRenderer0.getSeriesItemLabelsVisible((int) (short) 100);
        barRenderer0.setShadowXOffset((double) 100);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor9 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE8;
        java.awt.Color color10 = java.awt.Color.MAGENTA;
        boolean boolean11 = itemLabelAnchor9.equals((java.lang.Object) color10);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor12 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE10;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot13.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis16 = categoryPlot13.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        categoryPlot13.zoomDomainAxes((double) 10.0f, plotRenderingInfo18, point2D19, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor22 = categoryPlot13.getDomainGridlinePosition();
        boolean boolean23 = itemLabelAnchor12.equals((java.lang.Object) categoryAnchor22);
        org.jfree.chart.text.TextAnchor textAnchor24 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor25 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition27 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor12, textAnchor24, textAnchor25, (double) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition28 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor9, textAnchor24);
        barRenderer0.setPositiveItemLabelPositionFallback(itemLabelPosition28);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(boolean6);
        org.junit.Assert.assertNotNull(itemLabelAnchor9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor12);
        org.junit.Assert.assertNull(valueAxis16);
        org.junit.Assert.assertNotNull(categoryAnchor22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(textAnchor24);
        org.junit.Assert.assertNotNull(textAnchor25);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairLockedOnData(false);
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) (short) 10);
        categoryPlot0.setAnchorValue((double) (short) 10, false);
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace8);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        categoryPlot0.markerChanged(markerChangeEvent10);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke15 = lineAndShapeRenderer14.getBaseStroke();
        java.awt.Stroke stroke17 = lineAndShapeRenderer14.lookupSeriesStroke(10);
        java.awt.Shape shape23 = null;
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", shape23, (java.awt.Paint) color24);
        int int26 = color24.getBlue();
        lineAndShapeRenderer14.setSeriesItemLabelPaint((int) (byte) 1, (java.awt.Paint) color24);
        int int28 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer14);
        java.awt.Stroke stroke29 = categoryPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer33 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke34 = lineAndShapeRenderer33.getBaseStroke();
        java.awt.Stroke stroke36 = lineAndShapeRenderer33.lookupSeriesStroke(10);
        java.awt.Shape shape42 = null;
        java.awt.Color color43 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem44 = new org.jfree.chart.LegendItem("", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", shape42, (java.awt.Paint) color43);
        int int45 = color43.getBlue();
        lineAndShapeRenderer33.setSeriesItemLabelPaint((int) (byte) 1, (java.awt.Paint) color43);
        lineAndShapeRenderer33.setDrawOutlines(false);
        try {
            categoryPlot0.setRenderer((-1), (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 128 + "'", int26 == 128);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 128 + "'", int45 == 128);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot3.getRangeAxis();
        int int7 = categoryPlot3.getBackgroundImageAlignment();
        java.awt.Paint paint8 = categoryPlot3.getNoDataMessagePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot3.getDomainAxisForDataset((int) 'a');
        java.awt.Paint paint11 = categoryPlot3.getDomainCrosshairPaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = categoryAxis13.getTickLabelInsets();
        categoryAxis13.setCategoryLabelPositionOffset(0);
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot17.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis20 = categoryPlot17.getRangeAxis();
        int int21 = categoryPlot17.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot17.getRowRenderingOrder();
        java.awt.Stroke stroke23 = categoryPlot17.getRangeZeroBaselineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent24 = null;
        categoryPlot17.rendererChanged(rendererChangeEvent24);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation27 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot26.setRangeAxisLocation(axisLocation27, true);
        categoryPlot17.setDomainAxisLocation(axisLocation27);
        categoryPlot17.setCrosshairDatasetIndex((int) (short) 1);
        categoryAxis13.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot17);
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.data.category.CategoryDataset categoryDataset35 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer41 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke42 = lineAndShapeRenderer41.getBaseStroke();
        java.awt.Paint paint44 = lineAndShapeRenderer41.getSeriesPaint(15);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition46 = lineAndShapeRenderer41.getSeriesNegativeItemLabelPosition(255);
        int int47 = lineAndShapeRenderer41.getDefaultEntityRadius();
        java.awt.Stroke stroke48 = lineAndShapeRenderer41.getBaseOutlineStroke();
        java.awt.Graphics2D graphics2D49 = null;
        java.awt.geom.Rectangle2D rectangle2D50 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation52 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot51.setRangeAxisLocation(axisLocation52, true);
        java.lang.Comparable comparable55 = categoryPlot51.getDomainCrosshairColumnKey();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer58 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke59 = lineAndShapeRenderer58.getBaseStroke();
        org.jfree.chart.LegendItemCollection legendItemCollection60 = lineAndShapeRenderer58.getLegendItems();
        categoryPlot51.setFixedLegendItems(legendItemCollection60);
        org.jfree.data.category.CategoryDataset categoryDataset62 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo63 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState64 = lineAndShapeRenderer41.initialise(graphics2D49, rectangle2D50, categoryPlot51, categoryDataset62, plotRenderingInfo63);
        java.awt.geom.Rectangle2D rectangle2D65 = null;
        java.awt.geom.Rectangle2D rectangle2D66 = barRenderer0.createHotSpotBounds(graphics2D1, rectangle2D2, categoryPlot3, categoryAxis13, valueAxis34, categoryDataset35, 0, 255, false, categoryItemRendererState64, rectangle2D65);
        java.lang.String str68 = categoryAxis13.getCategoryLabelToolTip((java.lang.Comparable) (-256));
        org.jfree.chart.plot.CategoryPlot categoryPlot69 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot69.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis72 = categoryPlot69.getRangeAxis();
        org.jfree.chart.util.Layer layer74 = null;
        java.util.Collection collection75 = categoryPlot69.getRangeMarkers(10, layer74);
        categoryAxis13.setPlot((org.jfree.chart.plot.Plot) categoryPlot69);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 15 + "'", int7 == 15);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNull(valueAxis20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 15 + "'", int21 == 15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNull(paint44);
        org.junit.Assert.assertNotNull(itemLabelPosition46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 3 + "'", int47 == 3);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(axisLocation52);
        org.junit.Assert.assertNull(comparable55);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertNotNull(legendItemCollection60);
        org.junit.Assert.assertNotNull(categoryItemRendererState64);
        org.junit.Assert.assertNull(rectangle2D66);
        org.junit.Assert.assertNull(str68);
        org.junit.Assert.assertNull(valueAxis72);
        org.junit.Assert.assertNull(collection75);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        categoryPlot0.setDomainCrosshairColumnKey((java.lang.Comparable) (short) -1, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot0.zoomRangeAxes((double) (byte) 1, plotRenderingInfo9, point2D10, true);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.data.Range range14 = categoryPlot0.getDataRange(valueAxis13);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNull(range14);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getMinimumBarLength();
        java.awt.Paint paint5 = barRenderer0.getItemPaint(0, 15, true);
        double double6 = barRenderer0.getShadowXOffset();
        double double7 = barRenderer0.getBase();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape0, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape4 = chartEntity3.getArea();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier9 = categoryPlot5.getDrawingSupplier();
        org.jfree.data.category.CategoryDataset categoryDataset10 = categoryPlot5.getDataset();
        org.jfree.chart.renderer.RenderAttributes renderAttributes11 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        renderAttributes11.setDefaultFillPaint((java.awt.Paint) color12);
        categoryPlot5.setBackgroundPaint((java.awt.Paint) color12);
        org.jfree.chart.axis.ValueAxis valueAxis15 = categoryPlot5.getRangeAxis();
        org.jfree.chart.entity.PlotEntity plotEntity18 = new org.jfree.chart.entity.PlotEntity(shape4, (org.jfree.chart.plot.Plot) categoryPlot5, "ChartChangeEventType.GENERAL", "hi!");
        boolean boolean19 = categoryPlot5.isRangeZeroBaselineVisible();
        org.jfree.chart.plot.CategoryMarker categoryMarker21 = null;
        org.jfree.chart.util.Layer layer22 = null;
        try {
            categoryPlot5.addDomainMarker((-16728064), categoryMarker21, layer22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertNotNull(drawingSupplier9);
        org.junit.Assert.assertNull(categoryDataset10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNull(valueAxis15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isRangeGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getRangeAxisEdge((int) (byte) -1);
        categoryPlot0.clearRangeMarkers((int) (short) -1);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = categoryPlot0.getDomainAxisEdge(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(rectangleEdge7);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = categoryAxis1.getTickLabelInsets();
        categoryAxis1.setCategoryLabelPositionOffset(0);
        categoryAxis1.setMinorTickMarksVisible(false);
        float float7 = categoryAxis1.getMinorTickMarkOutsideLength();
        boolean boolean8 = categoryAxis1.isVisible();
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean13 = categoryPlot12.isRangeGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = categoryPlot12.getRangeAxisEdge((int) (byte) -1);
        org.jfree.chart.axis.AxisState axisState16 = null;
        categoryAxis1.drawTickMarks(graphics2D9, (double) 1L, rectangle2D11, rectangleEdge15, axisState16);
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = categoryAxis19.getTickLabelInsets();
        categoryAxis19.setCategoryLabelPositionOffset(0);
        categoryAxis19.setMinorTickMarksVisible(false);
        float float25 = categoryAxis19.getMinorTickMarkOutsideLength();
        boolean boolean26 = categoryAxis19.isVisible();
        categoryAxis19.setTickMarkOutsideLength((float) 10L);
        float float29 = categoryAxis19.getTickMarkOutsideLength();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer33 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke34 = lineAndShapeRenderer33.getBaseStroke();
        java.awt.Paint paint36 = lineAndShapeRenderer33.getSeriesPaint(15);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer40 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke41 = lineAndShapeRenderer40.getBaseStroke();
        java.awt.Stroke stroke43 = lineAndShapeRenderer40.lookupSeriesStroke(10);
        java.awt.Paint paint44 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        lineAndShapeRenderer40.setBaseOutlinePaint(paint44);
        java.awt.Font font46 = lineAndShapeRenderer40.getBaseItemLabelFont();
        lineAndShapeRenderer33.setSeriesItemLabelFont((int) (byte) 1, font46);
        categoryAxis19.setTickLabelFont((java.lang.Comparable) '4', font46);
        categoryAxis1.setTickLabelFont(font46);
        org.jfree.chart.axis.CategoryAxis categoryAxis51 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets52 = categoryAxis51.getTickLabelInsets();
        java.awt.Stroke stroke53 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        categoryAxis51.setAxisLineStroke(stroke53);
        categoryAxis1.setAxisLineStroke(stroke53);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 2.0f + "'", float7 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 2.0f + "'", float25 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 10.0f + "'", float29 == 10.0f);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNull(paint36);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(font46);
        org.junit.Assert.assertNotNull(rectangleInsets52);
        org.junit.Assert.assertNotNull(stroke53);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator0 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke4 = lineAndShapeRenderer3.getBaseStroke();
        java.awt.Stroke stroke6 = lineAndShapeRenderer3.lookupSeriesStroke(10);
        java.awt.Shape shape10 = lineAndShapeRenderer3.getItemShape((int) (short) 10, 100, true);
        lineAndShapeRenderer3.setBaseSeriesVisible(false);
        java.awt.Shape shape13 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity16 = new org.jfree.chart.entity.ChartEntity(shape13, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape17 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity20 = new org.jfree.chart.entity.ChartEntity(shape17, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape21 = chartEntity20.getArea();
        chartEntity16.setArea(shape21);
        lineAndShapeRenderer3.setBaseShape(shape21, true);
        lineAndShapeRenderer3.clearSeriesPaints(false);
        java.awt.Paint paint28 = lineAndShapeRenderer3.lookupSeriesOutlinePaint((-1));
        boolean boolean29 = standardCategorySeriesLabelGenerator0.equals((java.lang.Object) lineAndShapeRenderer3);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition33 = lineAndShapeRenderer3.getPositiveItemLabelPosition((int) (short) -1, 8, false);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition33);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent9 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot0);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer12 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke13 = lineAndShapeRenderer12.getBaseStroke();
        categoryPlot0.setRangeMinorGridlineStroke(stroke13);
        boolean boolean15 = categoryPlot0.isRangeZeroBaselineVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = categoryPlot0.getInsets();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(rectangleInsets16);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.clearSeriesStrokes(true);
        java.lang.Boolean boolean4 = lineAndShapeRenderer0.getSeriesVisibleInLegend(3);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator6 = lineAndShapeRenderer0.getSeriesURLGenerator((-1));
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator8 = null;
        lineAndShapeRenderer0.setSeriesItemLabelGenerator(156, categoryItemLabelGenerator8, false);
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertNull(categoryURLGenerator6);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        java.awt.Shape shape4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        int int9 = categoryPlot5.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot5.getRowRenderingOrder();
        java.awt.Stroke stroke11 = categoryPlot5.getRangeZeroBaselineStroke();
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("", "", "hi!", "", shape4, stroke11, paint12);
        legendItem13.setSeriesIndex((int) (byte) 10);
        java.awt.Paint paint16 = legendItem13.getFillPaint();
        java.lang.String str17 = legendItem13.getToolTipText();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer20 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke21 = lineAndShapeRenderer20.getBaseStroke();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator23 = null;
        lineAndShapeRenderer20.setSeriesItemLabelGenerator((int) (byte) 1, categoryItemLabelGenerator23);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer28 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke29 = lineAndShapeRenderer28.getBaseStroke();
        java.awt.Paint paint31 = lineAndShapeRenderer28.getSeriesPaint(15);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer35 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke36 = lineAndShapeRenderer35.getBaseStroke();
        java.awt.Stroke stroke38 = lineAndShapeRenderer35.lookupSeriesStroke(10);
        java.awt.Paint paint39 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        lineAndShapeRenderer35.setBaseOutlinePaint(paint39);
        java.awt.Font font41 = lineAndShapeRenderer35.getBaseItemLabelFont();
        lineAndShapeRenderer28.setSeriesItemLabelFont((int) (byte) 1, font41);
        lineAndShapeRenderer20.setSeriesItemLabelFont((int) (short) 10, font41, true);
        legendItem13.setLabelFont(font41);
        java.text.AttributedString attributedString46 = legendItem13.getAttributedLabel();
        java.lang.Comparable comparable47 = legendItem13.getSeriesKey();
        legendItem13.setURLText("java.awt.Color[r=0,g=0,b=0]");
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNull(paint31);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(font41);
        org.junit.Assert.assertNull(attributedString46);
        org.junit.Assert.assertNull(comparable47);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge();
        categoryPlot0.setCrosshairDatasetIndex(2);
        java.awt.Stroke stroke6 = categoryPlot0.getOutlineStroke();
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Shape shape9 = lineAndShapeRenderer2.getItemShape((int) (short) 10, 100, true);
        lineAndShapeRenderer2.setBaseSeriesVisible(false);
        java.awt.Shape shape12 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity15 = new org.jfree.chart.entity.ChartEntity(shape12, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape16 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity19 = new org.jfree.chart.entity.ChartEntity(shape16, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape20 = chartEntity19.getArea();
        chartEntity15.setArea(shape20);
        lineAndShapeRenderer2.setBaseShape(shape20, true);
        java.lang.Boolean boolean25 = lineAndShapeRenderer2.getSeriesShapesVisible(1);
        java.awt.Font font26 = lineAndShapeRenderer2.getBaseItemLabelFont();
        java.awt.Font font28 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        lineAndShapeRenderer2.setSeriesItemLabelFont((int) (short) 100, font28);
        lineAndShapeRenderer2.setUseSeriesOffset(false);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNull(boolean25);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(font28);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getMinimumBarLength();
        java.awt.Paint paint5 = barRenderer0.getItemPaint(0, 15, true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator6 = barRenderer0.getBaseURLGenerator();
        barRenderer0.setBase((double) '4');
        org.jfree.chart.renderer.category.BarRenderer barRenderer9 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor10 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE5;
        java.awt.Color color11 = java.awt.Color.white;
        boolean boolean12 = itemLabelAnchor10.equals((java.lang.Object) color11);
        org.jfree.chart.text.TextAnchor textAnchor13 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor10, textAnchor13);
        double double15 = itemLabelPosition14.getAngle();
        barRenderer9.setPositiveItemLabelPositionFallback(itemLabelPosition14);
        barRenderer0.setPositiveItemLabelPositionFallback(itemLabelPosition14);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(categoryURLGenerator6);
        org.junit.Assert.assertNotNull(itemLabelAnchor10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(textAnchor13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        java.lang.Comparable comparable9 = categoryPlot0.getDomainCrosshairColumnKey();
        boolean boolean10 = categoryPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = categoryPlot0.getAxisOffset();
        boolean boolean12 = categoryPlot0.isSubplot();
        categoryPlot0.setForegroundAlpha(0.0f);
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        org.jfree.chart.plot.CategoryCrosshairState categoryCrosshairState19 = null;
        boolean boolean20 = categoryPlot0.render(graphics2D15, rectangle2D16, 0, plotRenderingInfo18, categoryCrosshairState19);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier21 = null;
        categoryPlot0.setDrawingSupplier(drawingSupplier21);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNull(comparable9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge();
        int int4 = categoryPlot0.getWeight();
        java.util.List list5 = categoryPlot0.getAnnotations();
        categoryPlot0.setRangeMinorGridlinesVisible(false);
        java.awt.Stroke stroke8 = categoryPlot0.getDomainCrosshairStroke();
        org.jfree.chart.LegendItemCollection legendItemCollection9 = categoryPlot0.getFixedLegendItems();
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(legendItemCollection9);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot4.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis7 = categoryPlot4.getRangeAxis();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot4.getDrawingSupplier();
        org.jfree.data.category.CategoryDataset categoryDataset9 = categoryPlot4.getDataset();
        boolean boolean10 = lineAndShapeRenderer2.hasListener((java.util.EventListener) categoryPlot4);
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot4.getRangeAxisLocation((int) '4');
        org.jfree.chart.plot.Marker marker13 = null;
        org.jfree.chart.util.Layer layer14 = null;
        boolean boolean15 = categoryPlot4.removeDomainMarker(marker13, layer14);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNull(categoryDataset9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getMinimumBarLength();
        java.awt.Paint paint5 = barRenderer0.getItemPaint(0, 15, true);
        barRenderer0.setShadowVisible(true);
        java.awt.Shape shape9 = barRenderer0.lookupSeriesShape(255);
        barRenderer0.setShadowVisible(false);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(shape9);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        lineAndShapeRenderer2.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator7);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = lineAndShapeRenderer2.getSeriesPositiveItemLabelPosition(0);
        java.awt.Stroke stroke11 = lineAndShapeRenderer2.getBaseStroke();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator15 = lineAndShapeRenderer2.getItemLabelGenerator(100, (int) (short) -1, false);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(categoryItemLabelGenerator15);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = categoryAxis1.getTickLabelInsets();
        categoryAxis1.setCategoryLabelPositionOffset(0);
        categoryAxis1.setMinorTickMarksVisible(false);
        float float7 = categoryAxis1.getMinorTickMarkOutsideLength();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = categoryAxis1.getLabelInsets();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis1.setTickMarkPaint((java.awt.Paint) color9);
        float float11 = categoryAxis1.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke12 = categoryAxis1.getTickMarkStroke();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 2.0f + "'", float7 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.0f + "'", float11 == 0.0f);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        int int2 = keyedObjects0.getIndex((java.lang.Comparable) (short) 100);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot3.getDomainAxisEdge();
        int int7 = categoryPlot3.getWeight();
        java.lang.Comparable comparable8 = categoryPlot3.getDomainCrosshairColumnKey();
        boolean boolean9 = categoryPlot3.canSelectByRegion();
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot3.getRangeAxisLocation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot3.zoomDomainAxes((double) (short) 100, plotRenderingInfo12, point2D13, false);
        boolean boolean16 = keyedObjects0.equals((java.lang.Object) false);
        java.lang.Object obj18 = null;
        keyedObjects0.addObject((java.lang.Comparable) "TextAnchor.BASELINE_LEFT", obj18);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNull(comparable8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder5 = categoryPlot0.getRowRenderingOrder();
        java.awt.Stroke stroke6 = categoryPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent7 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent7);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot9.setRangeAxisLocation(axisLocation10, true);
        categoryPlot0.setDomainAxisLocation(axisLocation10);
        categoryPlot0.setCrosshairDatasetIndex((int) (short) 1);
        org.jfree.data.category.CategoryDataset categoryDataset16 = categoryPlot0.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = categoryPlot0.getAxisOffset();
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot18.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis21 = categoryPlot18.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Point2D point2D24 = null;
        categoryPlot18.zoomDomainAxes((double) 10.0f, plotRenderingInfo23, point2D24, false);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent27 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot18);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot28.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis31 = categoryPlot28.getRangeAxis();
        int int32 = categoryPlot28.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder33 = categoryPlot28.getRowRenderingOrder();
        java.awt.Stroke stroke34 = categoryPlot28.getRangeZeroBaselineStroke();
        categoryPlot18.setOutlineStroke(stroke34);
        org.jfree.chart.plot.Marker marker37 = null;
        org.jfree.chart.util.Layer layer38 = null;
        boolean boolean39 = categoryPlot18.removeDomainMarker(15, marker37, layer38);
        categoryPlot18.setOutlineVisible(true);
        org.jfree.chart.util.SortOrder sortOrder42 = categoryPlot18.getColumnRenderingOrder();
        categoryPlot0.setColumnRenderingOrder(sortOrder42);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(sortOrder5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNull(categoryDataset16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNull(valueAxis21);
        org.junit.Assert.assertNull(valueAxis31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 15 + "'", int32 == 15);
        org.junit.Assert.assertNotNull(sortOrder33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(sortOrder42);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = categoryAxis1.getTickLabelInsets();
        categoryAxis1.setCategoryLabelPositionOffset(0);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        int int9 = categoryPlot5.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot5.getRowRenderingOrder();
        java.awt.Stroke stroke11 = categoryPlot5.getRangeZeroBaselineStroke();
        int int12 = categoryPlot5.getCrosshairDatasetIndex();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke16 = lineAndShapeRenderer15.getBaseStroke();
        java.awt.Stroke stroke18 = lineAndShapeRenderer15.lookupSeriesStroke(10);
        lineAndShapeRenderer15.setAutoPopulateSeriesStroke(true);
        categoryPlot5.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer15, true);
        categoryAxis1.setPlot((org.jfree.chart.plot.Plot) categoryPlot5);
        categoryAxis1.setCategoryMargin((double) 100L);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot26.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis29 = categoryPlot26.getRangeAxis();
        int int30 = categoryPlot26.getBackgroundImageAlignment();
        categoryPlot26.setDomainCrosshairColumnKey((java.lang.Comparable) (short) -1, true);
        java.awt.Shape shape34 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity37 = new org.jfree.chart.entity.ChartEntity(shape34, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape38 = chartEntity37.getArea();
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot39.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis42 = categoryPlot39.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo44 = null;
        java.awt.geom.Point2D point2D45 = null;
        categoryPlot39.zoomDomainAxes((double) 10.0f, plotRenderingInfo44, point2D45, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor48 = categoryPlot39.getDomainGridlinePosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot49 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot49.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis52 = categoryPlot49.getRangeAxis();
        int int53 = categoryPlot49.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder54 = categoryPlot49.getRowRenderingOrder();
        java.awt.Stroke stroke55 = categoryPlot49.getRangeZeroBaselineStroke();
        categoryPlot39.setRangeMinorGridlineStroke(stroke55);
        org.jfree.chart.axis.CategoryAxis categoryAxis58 = categoryPlot39.getDomainAxis(100);
        boolean boolean59 = categoryPlot39.isNotify();
        org.jfree.chart.entity.PlotEntity plotEntity61 = new org.jfree.chart.entity.PlotEntity(shape38, (org.jfree.chart.plot.Plot) categoryPlot39, "ItemLabelAnchor.OUTSIDE1");
        boolean boolean62 = categoryPlot39.isRangeZoomable();
        java.awt.Color color63 = org.jfree.chart.ChartColor.DARK_BLUE;
        categoryPlot39.setRangeCrosshairPaint((java.awt.Paint) color63);
        org.jfree.chart.axis.AxisLocation axisLocation66 = categoryPlot39.getDomainAxisLocation(15);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor67 = categoryPlot39.getDomainGridlinePosition();
        categoryPlot26.setDomainGridlinePosition(categoryAnchor67);
        java.awt.geom.Rectangle2D rectangle2D71 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot72 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean73 = categoryPlot72.isRangeGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge75 = categoryPlot72.getRangeAxisEdge((int) (byte) -1);
        try {
            double double76 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor67, (-16728064), 128, rectangle2D71, rectangleEdge75);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid category index: -16728064");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNull(valueAxis29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 15 + "'", int30 == 15);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNotNull(shape38);
        org.junit.Assert.assertNull(valueAxis42);
        org.junit.Assert.assertNotNull(categoryAnchor48);
        org.junit.Assert.assertNull(valueAxis52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 15 + "'", int53 == 15);
        org.junit.Assert.assertNotNull(sortOrder54);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNull(categoryAxis58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNotNull(color63);
        org.junit.Assert.assertNotNull(axisLocation66);
        org.junit.Assert.assertNotNull(categoryAnchor67);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
        org.junit.Assert.assertNotNull(rectangleEdge75);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke8 = lineAndShapeRenderer7.getBaseStroke();
        java.awt.Stroke stroke10 = lineAndShapeRenderer7.lookupSeriesStroke(10);
        java.awt.Shape shape14 = lineAndShapeRenderer7.getItemShape((int) (short) 10, 100, true);
        lineAndShapeRenderer7.setBaseSeriesVisible(false);
        java.awt.Shape shape17 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity20 = new org.jfree.chart.entity.ChartEntity(shape17, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape21 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity24 = new org.jfree.chart.entity.ChartEntity(shape21, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape25 = chartEntity24.getArea();
        chartEntity20.setArea(shape25);
        lineAndShapeRenderer7.setBaseShape(shape25, true);
        java.lang.Boolean boolean30 = lineAndShapeRenderer7.getSeriesShapesVisible(1);
        java.awt.Font font31 = lineAndShapeRenderer7.getBaseItemLabelFont();
        categoryPlot0.setNoDataMessageFont(font31);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNull(boolean30);
        org.junit.Assert.assertNotNull(font31);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder5 = categoryPlot0.getRowRenderingOrder();
        java.awt.Stroke stroke6 = categoryPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = categoryPlot0.getInsets();
        double double8 = rectangleInsets7.getRight();
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D12 = rectangleInsets7.createOutsetRectangle(rectangle2D9, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(sortOrder5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 8.0d + "'", double8 == 8.0d);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        renderAttributes0.setDefaultFillPaint((java.awt.Paint) color1);
        java.awt.Shape shape5 = renderAttributes0.getItemShape((int) (byte) 100, (int) 'a');
        java.awt.Shape shape7 = null;
        renderAttributes0.setSeriesShape((int) (byte) 1, shape7);
        renderAttributes0.setDefaultCreateEntity((java.lang.Boolean) true);
        java.awt.Paint paint11 = renderAttributes0.getDefaultPaint();
        java.awt.Color color12 = java.awt.Color.yellow;
        java.awt.color.ColorSpace colorSpace13 = color12.getColorSpace();
        float[] floatArray17 = new float[] { (byte) 1, '#', 15 };
        float[] floatArray18 = color12.getRGBColorComponents(floatArray17);
        renderAttributes0.setDefaultLabelPaint((java.awt.Paint) color12);
        java.awt.Paint paint21 = renderAttributes0.getSeriesOutlinePaint(128);
        java.awt.Shape shape22 = renderAttributes0.getDefaultShape();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNull(shape5);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(colorSpace13);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNull(paint21);
        org.junit.Assert.assertNull(shape22);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.getSeriesItemLabelPaint((int) '4');
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation3 = null;
        try {
            barRenderer0.addAnnotation(categoryAnnotation3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(paint2);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape0, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape4 = chartEntity3.getArea();
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape4);
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot7.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis10 = categoryPlot7.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot7.zoomDomainAxes((double) 10.0f, plotRenderingInfo12, point2D13, false);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent16 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot7);
        org.jfree.chart.JFreeChart jFreeChart17 = null;
        plotChangeEvent16.setChart(jFreeChart17);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType19 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        plotChangeEvent16.setType(chartChangeEventType19);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent21 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) chartEntity5, jFreeChart6, chartChangeEventType19);
        java.awt.Shape shape22 = chartEntity5.getArea();
        org.jfree.chart.entity.ChartEntity chartEntity25 = new org.jfree.chart.entity.ChartEntity(shape22, "", "rect");
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertNotNull(chartChangeEventType19);
        org.junit.Assert.assertNotNull(shape22);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent9 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot0);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis13 = categoryPlot10.getRangeAxis();
        int int14 = categoryPlot10.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder15 = categoryPlot10.getRowRenderingOrder();
        java.awt.Stroke stroke16 = categoryPlot10.getRangeZeroBaselineStroke();
        categoryPlot0.setOutlineStroke(stroke16);
        org.jfree.chart.plot.Marker marker19 = null;
        org.jfree.chart.util.Layer layer20 = null;
        boolean boolean21 = categoryPlot0.removeDomainMarker(15, marker19, layer20);
        categoryPlot0.setOutlineVisible(true);
        java.awt.Paint paint24 = categoryPlot0.getDomainGridlinePaint();
        boolean boolean25 = categoryPlot0.canSelectByRegion();
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = categoryAxis27.getTickLabelInsets();
        categoryAxis27.setCategoryLabelPositionOffset(0);
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot31.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis34 = categoryPlot31.getRangeAxis();
        int int35 = categoryPlot31.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder36 = categoryPlot31.getRowRenderingOrder();
        java.awt.Stroke stroke37 = categoryPlot31.getRangeZeroBaselineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent38 = null;
        categoryPlot31.rendererChanged(rendererChangeEvent38);
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation41 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot40.setRangeAxisLocation(axisLocation41, true);
        categoryPlot31.setDomainAxisLocation(axisLocation41);
        categoryPlot31.setCrosshairDatasetIndex((int) (short) 1);
        categoryAxis27.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot31);
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double50 = rectangleInsets48.calculateTopInset((double) 4);
        categoryAxis27.setTickLabelInsets(rectangleInsets48);
        categoryPlot0.setInsets(rectangleInsets48, true);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNull(valueAxis13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 15 + "'", int14 == 15);
        org.junit.Assert.assertNotNull(sortOrder15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNull(valueAxis34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 15 + "'", int35 == 15);
        org.junit.Assert.assertNotNull(sortOrder36);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(axisLocation41);
        org.junit.Assert.assertNotNull(rectangleInsets48);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 3.0d + "'", double50 == 3.0d);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        java.lang.Number number0 = null;
        org.jfree.data.SelectableValue selectableValue2 = new org.jfree.data.SelectableValue(number0, false);
        selectableValue2.setSelected(true);
        boolean boolean5 = selectableValue2.isSelected();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        java.lang.Comparable comparable9 = categoryPlot0.getDomainCrosshairColumnKey();
        boolean boolean10 = categoryPlot0.isRangeCrosshairLockedOnData();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        categoryPlot0.setDomainCrosshairPaint((java.awt.Paint) color11);
        java.awt.Shape shape17 = null;
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem19 = new org.jfree.chart.LegendItem("", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", shape17, (java.awt.Paint) color18);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color18);
        org.jfree.chart.plot.Marker marker22 = null;
        org.jfree.chart.util.Layer layer23 = null;
        boolean boolean24 = categoryPlot0.removeDomainMarker((-16728064), marker22, layer23);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNull(comparable9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = categoryAxis1.getTickLabelInsets();
        categoryAxis1.setCategoryLabelPositionOffset(0);
        categoryAxis1.setMinorTickMarksVisible(false);
        float float7 = categoryAxis1.getMinorTickMarkOutsideLength();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = categoryAxis1.getLabelInsets();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis1.setTickMarkPaint((java.awt.Paint) color9);
        float float11 = categoryAxis1.getMinorTickMarkInsideLength();
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot13.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis16 = categoryPlot13.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        categoryPlot13.zoomDomainAxes((double) 10.0f, plotRenderingInfo18, point2D19, false);
        boolean boolean22 = categoryPlot13.isRangeCrosshairVisible();
        org.jfree.chart.axis.AxisLocation axisLocation24 = null;
        categoryPlot13.setDomainAxisLocation(255, axisLocation24);
        org.jfree.chart.util.SortOrder sortOrder26 = categoryPlot13.getRowRenderingOrder();
        categoryPlot13.setBackgroundImageAlignment(0);
        java.util.List list29 = categoryPlot13.getAnnotations();
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = categoryAxis32.getTickLabelInsets();
        java.lang.String str34 = categoryAxis32.getLabel();
        java.awt.Graphics2D graphics2D35 = null;
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot38.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis41 = categoryPlot38.getRangeAxis();
        int int42 = categoryPlot38.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder43 = categoryPlot38.getRowRenderingOrder();
        categoryPlot38.setWeight((int) (short) 100);
        boolean boolean46 = categoryPlot38.isDomainCrosshairVisible();
        org.jfree.chart.axis.AxisLocation axisLocation47 = categoryPlot38.getRangeAxisLocation();
        categoryPlot38.mapDatasetToRangeAxis(0, 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge51 = categoryPlot38.getDomainAxisEdge();
        org.jfree.chart.axis.AxisState axisState52 = null;
        categoryAxis32.drawTickMarks(graphics2D35, (double) 100L, rectangle2D37, rectangleEdge51, axisState52);
        try {
            double double54 = categoryAxis1.getCategoryMiddle((java.lang.Comparable) (-1.0f), list29, rectangle2D30, rectangleEdge51);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid category index: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 2.0f + "'", float7 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.0f + "'", float11 == 0.0f);
        org.junit.Assert.assertNull(valueAxis16);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(sortOrder26);
        org.junit.Assert.assertNotNull(list29);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "DatasetRenderingOrder.REVERSE" + "'", str34.equals("DatasetRenderingOrder.REVERSE"));
        org.junit.Assert.assertNull(valueAxis41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 15 + "'", int42 == 15);
        org.junit.Assert.assertNotNull(sortOrder43);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(axisLocation47);
        org.junit.Assert.assertNotNull(rectangleEdge51);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        lineAndShapeRenderer2.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator7);
        lineAndShapeRenderer2.setSeriesVisible((int) (short) 100, (java.lang.Boolean) false, true);
        boolean boolean15 = lineAndShapeRenderer2.getItemShapeVisible((int) (short) 10, 3);
        lineAndShapeRenderer2.setDefaultEntityRadius((-256));
        lineAndShapeRenderer2.setBaseSeriesVisible(false);
        java.awt.Paint paint21 = lineAndShapeRenderer2.getSeriesPaint((int) '4');
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(paint21);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder5 = categoryPlot0.getRowRenderingOrder();
        java.awt.Stroke stroke6 = categoryPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent7 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent7);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot9.setRangeAxisLocation(axisLocation10, true);
        categoryPlot0.setDomainAxisLocation(axisLocation10);
        categoryPlot0.setCrosshairDatasetIndex((int) (short) 1);
        org.jfree.data.category.CategoryDataset categoryDataset16 = categoryPlot0.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = categoryPlot0.getAxisOffset();
        double double19 = rectangleInsets17.extendWidth(0.0d);
        double double21 = rectangleInsets17.trimWidth((double) 100L);
        org.jfree.chart.util.UnitType unitType22 = rectangleInsets17.getUnitType();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(sortOrder5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNull(categoryDataset16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 8.0d + "'", double19 == 8.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 92.0d + "'", double21 == 92.0d);
        org.junit.Assert.assertNotNull(unitType22);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        lineAndShapeRenderer2.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator7);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = lineAndShapeRenderer2.getSeriesPositiveItemLabelPosition(0);
        java.awt.Stroke stroke11 = lineAndShapeRenderer2.getBaseStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = lineAndShapeRenderer2.getPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot13.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = categoryPlot13.getDomainAxisEdge();
        int int17 = categoryPlot13.getWeight();
        java.util.List list18 = categoryPlot13.getAnnotations();
        lineAndShapeRenderer2.setPlot(categoryPlot13);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition23 = lineAndShapeRenderer2.getNegativeItemLabelPosition(255, 1, true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(categoryPlot12);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertNotNull(itemLabelPosition23);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        java.awt.Shape shape4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        int int9 = categoryPlot5.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot5.getRowRenderingOrder();
        java.awt.Stroke stroke11 = categoryPlot5.getRangeZeroBaselineStroke();
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("", "", "hi!", "", shape4, stroke11, paint12);
        legendItem13.setDescription("");
        int int16 = legendItem13.getDatasetIndex();
        java.lang.String str17 = legendItem13.getLabel();
        java.awt.Paint paint18 = legendItem13.getOutlinePaint();
        legendItem13.setDatasetIndex((int) ' ');
        legendItem13.setSeriesIndex((int) '4');
        java.lang.String str23 = legendItem13.getDescription();
        java.awt.Stroke stroke24 = legendItem13.getLineStroke();
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "" + "'", str23.equals(""));
        org.junit.Assert.assertNotNull(stroke24);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        categoryPlot0.setRangeCrosshairVisible(false);
        java.awt.Shape shape9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis13 = categoryPlot10.getRangeAxis();
        int int14 = categoryPlot10.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder15 = categoryPlot10.getRowRenderingOrder();
        java.awt.Stroke stroke16 = categoryPlot10.getRangeZeroBaselineStroke();
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem18 = new org.jfree.chart.LegendItem("", "", "hi!", "", shape9, stroke16, paint17);
        legendItem18.setDescription("");
        int int21 = legendItem18.getDatasetIndex();
        java.lang.String str22 = legendItem18.getLabel();
        java.awt.Paint paint23 = legendItem18.getOutlinePaint();
        categoryPlot0.setRangeZeroBaselinePaint(paint23);
        org.junit.Assert.assertNull(valueAxis13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 15 + "'", int14 == 15);
        org.junit.Assert.assertNotNull(sortOrder15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertNotNull(paint23);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = categoryAxis1.getTickLabelInsets();
        java.lang.String str3 = categoryAxis1.getLabel();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot4.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = categoryPlot4.getDomainAxisEdge();
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot4.getDomainAxisLocation();
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        categoryPlot4.drawBackgroundImage(graphics2D9, rectangle2D10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        categoryPlot4.setRenderer(categoryItemRenderer12);
        categoryAxis1.setPlot((org.jfree.chart.plot.Plot) categoryPlot4);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = categoryPlot4.getAxisOffset();
        java.awt.Paint paint16 = categoryPlot4.getDomainGridlinePaint();
        boolean boolean17 = categoryPlot4.isRangeZeroBaselineVisible();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "DatasetRenderingOrder.REVERSE" + "'", str3.equals("DatasetRenderingOrder.REVERSE"));
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor9 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis13 = categoryPlot10.getRangeAxis();
        int int14 = categoryPlot10.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder15 = categoryPlot10.getRowRenderingOrder();
        java.awt.Stroke stroke16 = categoryPlot10.getRangeZeroBaselineStroke();
        categoryPlot0.setRangeMinorGridlineStroke(stroke16);
        org.jfree.chart.axis.ValueAxis valueAxis19 = categoryPlot0.getRangeAxis(1);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent20 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent20);
        org.jfree.chart.renderer.RenderAttributes renderAttributes22 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        renderAttributes22.setDefaultFillPaint((java.awt.Paint) color23);
        java.awt.Shape shape27 = renderAttributes22.getItemShape((int) (byte) 100, (int) 'a');
        java.awt.Shape shape29 = null;
        renderAttributes22.setSeriesShape((int) (byte) 1, shape29);
        renderAttributes22.setDefaultCreateEntity((java.lang.Boolean) true);
        java.awt.Paint paint33 = renderAttributes22.getDefaultPaint();
        java.awt.Color color34 = java.awt.Color.yellow;
        java.awt.color.ColorSpace colorSpace35 = color34.getColorSpace();
        float[] floatArray39 = new float[] { (byte) 1, '#', 15 };
        float[] floatArray40 = color34.getRGBColorComponents(floatArray39);
        renderAttributes22.setDefaultLabelPaint((java.awt.Paint) color34);
        categoryPlot0.setOutlinePaint((java.awt.Paint) color34);
        categoryPlot0.setRangeCrosshairVisible(false);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(categoryAnchor9);
        org.junit.Assert.assertNull(valueAxis13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 15 + "'", int14 == 15);
        org.junit.Assert.assertNotNull(sortOrder15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNull(valueAxis19);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNull(shape27);
        org.junit.Assert.assertNull(paint33);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(colorSpace35);
        org.junit.Assert.assertNotNull(floatArray39);
        org.junit.Assert.assertNotNull(floatArray40);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = categoryAxis1.getTickLabelInsets();
        categoryAxis1.setCategoryLabelPositionOffset(0);
        categoryAxis1.setMinorTickMarksVisible(false);
        float float7 = categoryAxis1.getMinorTickMarkOutsideLength();
        boolean boolean8 = categoryAxis1.isVisible();
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean13 = categoryPlot12.isRangeGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = categoryPlot12.getRangeAxisEdge((int) (byte) -1);
        org.jfree.chart.axis.AxisState axisState16 = null;
        categoryAxis1.drawTickMarks(graphics2D9, (double) 1L, rectangle2D11, rectangleEdge15, axisState16);
        java.lang.String str19 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) 100.0f);
        categoryAxis1.setTickMarksVisible(true);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 2.0f + "'", float7 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNull(str19);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot0.setRangeAxisLocation(axisLocation1, true);
        java.lang.Comparable comparable4 = categoryPlot0.getDomainCrosshairColumnKey();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke8 = lineAndShapeRenderer7.getBaseStroke();
        org.jfree.chart.LegendItemCollection legendItemCollection9 = lineAndShapeRenderer7.getLegendItems();
        categoryPlot0.setFixedLegendItems(legendItemCollection9);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation12 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot11.setRangeAxisLocation(axisLocation12, true);
        java.lang.Comparable comparable15 = categoryPlot11.getDomainCrosshairColumnKey();
        boolean boolean16 = legendItemCollection9.equals((java.lang.Object) categoryPlot11);
        int int17 = legendItemCollection9.getItemCount();
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNull(comparable4);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(legendItemCollection9);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNull(comparable15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Shape shape9 = lineAndShapeRenderer2.getItemShape((int) (short) 10, 100, true);
        lineAndShapeRenderer2.setBaseSeriesVisible(false);
        java.awt.Shape shape12 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity15 = new org.jfree.chart.entity.ChartEntity(shape12, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape16 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity19 = new org.jfree.chart.entity.ChartEntity(shape16, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape20 = chartEntity19.getArea();
        chartEntity15.setArea(shape20);
        lineAndShapeRenderer2.setBaseShape(shape20, true);
        java.lang.Boolean boolean25 = lineAndShapeRenderer2.getSeriesShapesVisible(1);
        java.awt.Font font26 = lineAndShapeRenderer2.getBaseItemLabelFont();
        java.awt.Font font28 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        lineAndShapeRenderer2.setSeriesItemLabelFont((int) (short) 100, font28);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator33 = lineAndShapeRenderer2.getURLGenerator(156, (int) (byte) 0, false);
        boolean boolean34 = lineAndShapeRenderer2.getAutoPopulateSeriesStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition36 = null;
        lineAndShapeRenderer2.setSeriesNegativeItemLabelPosition(4, itemLabelPosition36);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNull(boolean25);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNull(categoryURLGenerator33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = categoryAxis1.getTickLabelInsets();
        categoryAxis1.setCategoryLabelPositionOffset(0);
        categoryAxis1.setMinorTickMarksVisible(false);
        float float7 = categoryAxis1.getMinorTickMarkOutsideLength();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = categoryAxis1.getLabelInsets();
        java.awt.Color color12 = java.awt.Color.getHSBColor((float) (short) 1, (float) 100, 0.0f);
        float[] floatArray19 = new float[] { (byte) 10, (byte) 1, 1.0f, (byte) 0, 10, (byte) 100 };
        float[] floatArray20 = color12.getRGBComponents(floatArray19);
        java.lang.String str21 = color12.toString();
        categoryAxis1.setTickMarkPaint((java.awt.Paint) color12);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 2.0f + "'", float7 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "java.awt.Color[r=0,g=0,b=0]" + "'", str21.equals("java.awt.Color[r=0,g=0,b=0]"));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        try {
            java.lang.Comparable comparable2 = keyedObjects0.getKey((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot0.setRangeAxisLocation(axisLocation1, true);
        java.util.List list4 = categoryPlot0.getAnnotations();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        categoryPlot0.setDomainAxis((int) (byte) 0, categoryAxis6, false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer11 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke12 = lineAndShapeRenderer11.getBaseStroke();
        java.awt.Stroke stroke14 = lineAndShapeRenderer11.lookupSeriesStroke(10);
        java.awt.Shape shape20 = null;
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem22 = new org.jfree.chart.LegendItem("", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", shape20, (java.awt.Paint) color21);
        int int23 = color21.getBlue();
        lineAndShapeRenderer11.setSeriesItemLabelPaint((int) (byte) 1, (java.awt.Paint) color21);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean26 = categoryPlot25.isRangeGridlinesVisible();
        categoryPlot25.clearDomainAxes();
        lineAndShapeRenderer11.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot25);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator29 = lineAndShapeRenderer11.getLegendItemToolTipGenerator();
        lineAndShapeRenderer11.setSeriesShapesVisible((int) (byte) 100, true);
        java.awt.Font font34 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        lineAndShapeRenderer11.setLegendTextFont(0, font34);
        java.awt.Stroke stroke37 = lineAndShapeRenderer11.lookupSeriesStroke(0);
        categoryPlot0.setDomainCrosshairStroke(stroke37);
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 128 + "'", int23 == 128);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator29);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertNotNull(stroke37);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        java.awt.Color color1 = java.awt.Color.GRAY;
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator5 = new org.jfree.chart.util.DefaultShadowGenerator((int) (short) -1, color1, 0.0f, (int) (byte) -1, (double) 'a');
        int int6 = defaultShadowGenerator5.calculateOffsetX();
        double double7 = defaultShadowGenerator5.getAngle();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 97.0d + "'", double7 == 97.0d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape0, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape4 = chartEntity3.getArea();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot5.zoomDomainAxes((double) 10.0f, plotRenderingInfo10, point2D11, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor14 = categoryPlot5.getDomainGridlinePosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot15.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis18 = categoryPlot15.getRangeAxis();
        int int19 = categoryPlot15.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder20 = categoryPlot15.getRowRenderingOrder();
        java.awt.Stroke stroke21 = categoryPlot15.getRangeZeroBaselineStroke();
        categoryPlot5.setRangeMinorGridlineStroke(stroke21);
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = categoryPlot5.getDomainAxis(100);
        boolean boolean25 = categoryPlot5.isNotify();
        org.jfree.chart.entity.PlotEntity plotEntity27 = new org.jfree.chart.entity.PlotEntity(shape4, (org.jfree.chart.plot.Plot) categoryPlot5, "ItemLabelAnchor.OUTSIDE1");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset30 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity33 = new org.jfree.chart.entity.CategoryItemEntity(shape4, "PlotOrientation.VERTICAL", "PlotOrientation.VERTICAL", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset30, (java.lang.Comparable) 10, (java.lang.Comparable) 'a');
        java.lang.Object obj34 = null;
        boolean boolean35 = categoryItemEntity33.equals(obj34);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor36 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE5;
        java.awt.Color color37 = java.awt.Color.white;
        boolean boolean38 = itemLabelAnchor36.equals((java.lang.Object) color37);
        java.awt.Color color39 = java.awt.Color.yellow;
        java.awt.color.ColorSpace colorSpace40 = color39.getColorSpace();
        java.awt.Color color47 = java.awt.Color.getHSBColor((float) (short) 1, (float) 100, 0.0f);
        float[] floatArray54 = new float[] { (byte) 10, (byte) 1, 1.0f, (byte) 0, 10, (byte) 100 };
        float[] floatArray55 = color47.getRGBComponents(floatArray54);
        float[] floatArray56 = java.awt.Color.RGBtoHSB((int) ' ', 1, 255, floatArray54);
        float[] floatArray57 = color37.getComponents(colorSpace40, floatArray56);
        boolean boolean58 = categoryItemEntity33.equals((java.lang.Object) colorSpace40);
        org.jfree.data.category.CategoryDataset categoryDataset59 = categoryItemEntity33.getDataset();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertNotNull(categoryAnchor14);
        org.junit.Assert.assertNull(valueAxis18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 15 + "'", int19 == 15);
        org.junit.Assert.assertNotNull(sortOrder20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNull(categoryAxis24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(colorSpace40);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(floatArray54);
        org.junit.Assert.assertNotNull(floatArray55);
        org.junit.Assert.assertNotNull(floatArray56);
        org.junit.Assert.assertNotNull(floatArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(categoryDataset59);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        java.lang.Boolean boolean2 = booleanList0.getBoolean(8);
        org.junit.Assert.assertNull(boolean2);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder5 = categoryPlot0.getRowRenderingOrder();
        java.awt.Stroke stroke6 = categoryPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent7 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent7);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot9.setRangeAxisLocation(axisLocation10, true);
        categoryPlot0.setDomainAxisLocation(axisLocation10);
        categoryPlot0.clearRangeMarkers((-128));
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = categoryPlot0.getRangeAxisEdge();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(sortOrder5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(rectangleEdge16);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder5 = categoryPlot0.getRowRenderingOrder();
        java.awt.Stroke stroke6 = categoryPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = categoryPlot0.getInsets();
        java.lang.Object obj8 = categoryPlot0.clone();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot0.zoomRangeAxes((double) 2, plotRenderingInfo10, point2D11, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Point2D point2D16 = null;
        categoryPlot0.panDomainAxes((double) 1.0f, plotRenderingInfo15, point2D16);
        org.jfree.chart.axis.AxisLocation axisLocation19 = categoryPlot0.getDomainAxisLocation(15);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(sortOrder5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(axisLocation19);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor9 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis13 = categoryPlot10.getRangeAxis();
        int int14 = categoryPlot10.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder15 = categoryPlot10.getRowRenderingOrder();
        java.awt.Stroke stroke16 = categoryPlot10.getRangeZeroBaselineStroke();
        categoryPlot0.setRangeMinorGridlineStroke(stroke16);
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = categoryPlot0.getDomainAxis(100);
        boolean boolean20 = categoryPlot0.isNotify();
        categoryPlot0.clearRangeMarkers((int) (short) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot23.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis26 = categoryPlot23.getRangeAxis();
        int int27 = categoryPlot23.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder28 = categoryPlot23.getRowRenderingOrder();
        categoryPlot23.setWeight((int) (short) 100);
        boolean boolean31 = categoryPlot23.isDomainCrosshairVisible();
        org.jfree.chart.util.ShadowGenerator shadowGenerator32 = categoryPlot23.getShadowGenerator();
        categoryPlot0.setShadowGenerator(shadowGenerator32);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(categoryAnchor9);
        org.junit.Assert.assertNull(valueAxis13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 15 + "'", int14 == 15);
        org.junit.Assert.assertNotNull(sortOrder15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNull(categoryAxis19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNull(valueAxis26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 15 + "'", int27 == 15);
        org.junit.Assert.assertNotNull(sortOrder28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(shadowGenerator32);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = categoryAxis1.getTickLabelInsets();
        categoryAxis1.setCategoryLabelPositionOffset(0);
        categoryAxis1.setMinorTickMarksVisible(false);
        float float7 = categoryAxis1.getMinorTickMarkOutsideLength();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = categoryAxis1.getLabelInsets();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis1.setTickMarkPaint((java.awt.Paint) color9);
        categoryAxis1.setLabel("");
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = categoryAxis14.getTickLabelInsets();
        categoryAxis14.setCategoryLabelPositionOffset(0);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions18 = categoryAxis14.getCategoryLabelPositions();
        boolean boolean19 = categoryAxis14.isAxisLineVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = categoryAxis14.getLabelInsets();
        categoryAxis1.setLabelInsets(rectangleInsets20, false);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 2.0f + "'", float7 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(categoryLabelPositions18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(rectangleInsets20);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier4 = categoryPlot0.getDrawingSupplier();
        double double5 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier6 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot7.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis10 = categoryPlot7.getRangeAxis();
        int int11 = categoryPlot7.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder12 = categoryPlot7.getRowRenderingOrder();
        java.awt.Stroke stroke13 = categoryPlot7.getRangeZeroBaselineStroke();
        categoryPlot7.setRangeGridlinesVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot16.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis19 = categoryPlot16.getRangeAxis();
        int int20 = categoryPlot16.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder21 = categoryPlot16.getRowRenderingOrder();
        java.awt.Stroke stroke22 = categoryPlot16.getRangeZeroBaselineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent23 = null;
        categoryPlot16.rendererChanged(rendererChangeEvent23);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation26 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot25.setRangeAxisLocation(axisLocation26, true);
        categoryPlot16.setDomainAxisLocation(axisLocation26);
        categoryPlot7.setDomainAxisLocation(axisLocation26, true);
        categoryPlot7.setBackgroundAlpha((float) 10);
        boolean boolean34 = defaultDrawingSupplier6.equals((java.lang.Object) 10);
        java.awt.Paint paint35 = defaultDrawingSupplier6.getNextOutlinePaint();
        java.awt.Paint paint36 = defaultDrawingSupplier6.getNextPaint();
        java.awt.Paint paint37 = defaultDrawingSupplier6.getNextOutlinePaint();
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier6, true);
        java.lang.Object obj40 = defaultDrawingSupplier6.clone();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(drawingSupplier4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 15 + "'", int11 == 15);
        org.junit.Assert.assertNotNull(sortOrder12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNull(valueAxis19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 15 + "'", int20 == 15);
        org.junit.Assert.assertNotNull(sortOrder21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(obj40);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = categoryAxis1.getTickLabelInsets();
        categoryAxis1.setCategoryLabelPositionOffset(0);
        categoryAxis1.setMinorTickMarksVisible(false);
        float float7 = categoryAxis1.getMinorTickMarkOutsideLength();
        boolean boolean8 = categoryAxis1.isVisible();
        categoryAxis1.setTickMarkOutsideLength((float) 10L);
        float float11 = categoryAxis1.getTickMarkOutsideLength();
        int int12 = categoryAxis1.getCategoryLabelPositionOffset();
        boolean boolean13 = categoryAxis1.isAxisLineVisible();
        java.awt.Paint paint14 = categoryAxis1.getTickMarkPaint();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 2.0f + "'", float7 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 10.0f + "'", float11 == 10.0f);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Shape shape9 = lineAndShapeRenderer2.getItemShape((int) (short) 10, 100, true);
        lineAndShapeRenderer2.setBaseCreateEntities(true);
        java.awt.Shape shape12 = lineAndShapeRenderer2.getBaseLegendShape();
        java.awt.Paint paint13 = lineAndShapeRenderer2.getBasePaint();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNull(shape12);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setAutoPopulateSeriesPaint(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = lineAndShapeRenderer0.getToolTipGenerator((int) ' ', (int) (short) 100, true);
        org.junit.Assert.assertNull(categoryToolTipGenerator6);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(0.2d, (double) 1.0f, (double) 10L, (double) 10.0f);
        int int6 = objectList0.indexOf((java.lang.Object) 10.0f);
        java.lang.Object obj8 = objectList0.get(2);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = categoryAxis10.getTickLabelInsets();
        categoryAxis10.setCategoryLabelPositionOffset(0);
        categoryAxis10.setMinorTickMarksVisible(false);
        float float16 = categoryAxis10.getMinorTickMarkOutsideLength();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = categoryAxis10.getLabelInsets();
        org.jfree.chart.util.UnitType unitType18 = rectangleInsets17.getUnitType();
        boolean boolean19 = objectList0.equals((java.lang.Object) unitType18);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot20.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis23 = categoryPlot20.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        categoryPlot20.zoomDomainAxes((double) 10.0f, plotRenderingInfo25, point2D26, false);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent29 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot20);
        org.jfree.chart.JFreeChart jFreeChart30 = plotChangeEvent29.getChart();
        org.jfree.chart.plot.Plot plot31 = plotChangeEvent29.getPlot();
        int int32 = objectList0.indexOf((java.lang.Object) plotChangeEvent29);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNull(obj8);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 2.0f + "'", float16 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(unitType18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNull(jFreeChart30);
        org.junit.Assert.assertNotNull(plot31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor9 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace10, false);
        org.jfree.chart.axis.AxisLocation axisLocation14 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.axis.AxisLocation axisLocation15 = axisLocation14.getOpposite();
        categoryPlot0.setDomainAxisLocation(1, axisLocation14, true);
        int int18 = categoryPlot0.getDatasetCount();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(categoryAnchor9);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = categoryAxis1.getTickLabelInsets();
        categoryAxis1.setCategoryLabelPositionOffset(0);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions5 = categoryAxis1.getCategoryLabelPositions();
        categoryAxis1.configure();
        java.awt.Shape shape11 = null;
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", shape11, (java.awt.Paint) color12);
        java.awt.color.ColorSpace colorSpace14 = color12.getColorSpace();
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_CYAN;
        boolean boolean16 = color12.equals((java.lang.Object) color15);
        categoryAxis1.setTickLabelPaint((java.awt.Paint) color15);
        java.awt.Paint paint18 = categoryAxis1.getTickLabelPaint();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(categoryLabelPositions5);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(colorSpace14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = categoryAxis1.getTickLabelInsets();
        categoryAxis1.setCategoryLabelPositionOffset(0);
        categoryAxis1.setMinorTickMarksVisible(false);
        float float7 = categoryAxis1.getMinorTickMarkOutsideLength();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = categoryAxis1.getLabelInsets();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis1.setTickMarkPaint((java.awt.Paint) color9);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot11.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis14 = categoryPlot11.getRangeAxis();
        int int15 = categoryPlot11.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder16 = categoryPlot11.getRowRenderingOrder();
        java.awt.Stroke stroke17 = categoryPlot11.getRangeZeroBaselineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent18 = null;
        categoryPlot11.rendererChanged(rendererChangeEvent18);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation21 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot20.setRangeAxisLocation(axisLocation21, true);
        categoryPlot11.setDomainAxisLocation(axisLocation21);
        categoryAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot11);
        org.jfree.chart.LegendItemCollection legendItemCollection26 = categoryPlot11.getFixedLegendItems();
        org.jfree.chart.LegendItemCollection legendItemCollection27 = categoryPlot11.getLegendItems();
        java.awt.Stroke stroke28 = categoryPlot11.getRangeGridlineStroke();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 2.0f + "'", float7 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNull(valueAxis14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 15 + "'", int15 == 15);
        org.junit.Assert.assertNotNull(sortOrder16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNull(legendItemCollection26);
        org.junit.Assert.assertNotNull(legendItemCollection27);
        org.junit.Assert.assertNotNull(stroke28);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor9 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace10, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot14.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis17 = categoryPlot14.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        categoryPlot14.zoomDomainAxes((double) 10.0f, plotRenderingInfo19, point2D20, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor23 = categoryPlot14.getDomainGridlinePosition();
        org.jfree.chart.axis.AxisSpace axisSpace24 = null;
        categoryPlot14.setFixedRangeAxisSpace(axisSpace24, false);
        org.jfree.chart.axis.AxisLocation axisLocation28 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.axis.AxisLocation axisLocation29 = axisLocation28.getOpposite();
        categoryPlot14.setDomainAxisLocation(1, axisLocation28, true);
        categoryPlot0.setDomainAxisLocation(100, axisLocation28);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(categoryAnchor9);
        org.junit.Assert.assertNull(valueAxis17);
        org.junit.Assert.assertNotNull(categoryAnchor23);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertNotNull(axisLocation29);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot3.getRangeAxis();
        int int7 = categoryPlot3.getBackgroundImageAlignment();
        java.awt.Paint paint8 = categoryPlot3.getNoDataMessagePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot3.getDomainAxisForDataset((int) 'a');
        java.awt.Paint paint11 = categoryPlot3.getDomainCrosshairPaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = categoryAxis13.getTickLabelInsets();
        categoryAxis13.setCategoryLabelPositionOffset(0);
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot17.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis20 = categoryPlot17.getRangeAxis();
        int int21 = categoryPlot17.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot17.getRowRenderingOrder();
        java.awt.Stroke stroke23 = categoryPlot17.getRangeZeroBaselineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent24 = null;
        categoryPlot17.rendererChanged(rendererChangeEvent24);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation27 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot26.setRangeAxisLocation(axisLocation27, true);
        categoryPlot17.setDomainAxisLocation(axisLocation27);
        categoryPlot17.setCrosshairDatasetIndex((int) (short) 1);
        categoryAxis13.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot17);
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.data.category.CategoryDataset categoryDataset35 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer41 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke42 = lineAndShapeRenderer41.getBaseStroke();
        java.awt.Paint paint44 = lineAndShapeRenderer41.getSeriesPaint(15);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition46 = lineAndShapeRenderer41.getSeriesNegativeItemLabelPosition(255);
        int int47 = lineAndShapeRenderer41.getDefaultEntityRadius();
        java.awt.Stroke stroke48 = lineAndShapeRenderer41.getBaseOutlineStroke();
        java.awt.Graphics2D graphics2D49 = null;
        java.awt.geom.Rectangle2D rectangle2D50 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation52 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot51.setRangeAxisLocation(axisLocation52, true);
        java.lang.Comparable comparable55 = categoryPlot51.getDomainCrosshairColumnKey();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer58 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke59 = lineAndShapeRenderer58.getBaseStroke();
        org.jfree.chart.LegendItemCollection legendItemCollection60 = lineAndShapeRenderer58.getLegendItems();
        categoryPlot51.setFixedLegendItems(legendItemCollection60);
        org.jfree.data.category.CategoryDataset categoryDataset62 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo63 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState64 = lineAndShapeRenderer41.initialise(graphics2D49, rectangle2D50, categoryPlot51, categoryDataset62, plotRenderingInfo63);
        java.awt.geom.Rectangle2D rectangle2D65 = null;
        java.awt.geom.Rectangle2D rectangle2D66 = barRenderer0.createHotSpotBounds(graphics2D1, rectangle2D2, categoryPlot3, categoryAxis13, valueAxis34, categoryDataset35, 0, 255, false, categoryItemRendererState64, rectangle2D65);
        java.awt.Stroke stroke67 = categoryAxis13.getAxisLineStroke();
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 15 + "'", int7 == 15);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNull(valueAxis20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 15 + "'", int21 == 15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNull(paint44);
        org.junit.Assert.assertNotNull(itemLabelPosition46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 3 + "'", int47 == 3);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(axisLocation52);
        org.junit.Assert.assertNull(comparable55);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertNotNull(legendItemCollection60);
        org.junit.Assert.assertNotNull(categoryItemRendererState64);
        org.junit.Assert.assertNull(rectangle2D66);
        org.junit.Assert.assertNotNull(stroke67);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        try {
            java.lang.Object obj3 = keyedObjects2D0.getObject((java.lang.Comparable) (-7.0d), (java.lang.Comparable) 94.0d);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Row key (-7.0) not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor9 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis13 = categoryPlot10.getRangeAxis();
        int int14 = categoryPlot10.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder15 = categoryPlot10.getRowRenderingOrder();
        java.awt.Stroke stroke16 = categoryPlot10.getRangeZeroBaselineStroke();
        categoryPlot0.setRangeMinorGridlineStroke(stroke16);
        java.awt.Stroke stroke18 = categoryPlot0.getDomainGridlineStroke();
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = categoryPlot0.getDomainAxisEdge(100);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(categoryAnchor9);
        org.junit.Assert.assertNull(valueAxis13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 15 + "'", int14 == 15);
        org.junit.Assert.assertNotNull(sortOrder15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(rectangleEdge20);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor9 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis13 = categoryPlot10.getRangeAxis();
        int int14 = categoryPlot10.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder15 = categoryPlot10.getRowRenderingOrder();
        java.awt.Stroke stroke16 = categoryPlot10.getRangeZeroBaselineStroke();
        categoryPlot0.setRangeMinorGridlineStroke(stroke16);
        org.jfree.chart.axis.ValueAxis valueAxis19 = categoryPlot0.getRangeAxis(1);
        boolean boolean20 = categoryPlot0.isDomainZoomable();
        int int21 = categoryPlot0.getWeight();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(categoryAnchor9);
        org.junit.Assert.assertNull(valueAxis13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 15 + "'", int14 == 15);
        org.junit.Assert.assertNotNull(sortOrder15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNull(valueAxis19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke5 = lineAndShapeRenderer4.getBaseStroke();
        java.awt.Stroke stroke7 = lineAndShapeRenderer4.lookupSeriesStroke(10);
        java.awt.Shape shape11 = lineAndShapeRenderer4.getItemShape((int) (short) 10, 100, true);
        lineAndShapeRenderer4.setBaseSeriesVisible(false);
        java.awt.Shape shape14 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity17 = new org.jfree.chart.entity.ChartEntity(shape14, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape18 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity21 = new org.jfree.chart.entity.ChartEntity(shape18, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape22 = chartEntity21.getArea();
        chartEntity17.setArea(shape22);
        lineAndShapeRenderer4.setBaseShape(shape22, true);
        java.lang.Boolean boolean27 = lineAndShapeRenderer4.getSeriesShapesVisible(1);
        java.awt.Stroke stroke28 = lineAndShapeRenderer4.getBaseOutlineStroke();
        strokeList0.setStroke((int) (byte) 100, stroke28);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNull(boolean27);
        org.junit.Assert.assertNotNull(stroke28);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot0.setRangeAxisLocation(axisLocation1, true);
        java.util.List list4 = categoryPlot0.getAnnotations();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        categoryPlot0.setDomainAxis((int) (byte) 0, categoryAxis6, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot0.zoomRangeAxes((double) (-128), (double) 'a', plotRenderingInfo11, point2D12);
        categoryPlot0.mapDatasetToDomainAxis((int) (short) 100, (int) (short) 1);
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNotNull(list4);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        categoryPlot0.setDomainCrosshairColumnKey((java.lang.Comparable) (short) -1, true);
        org.jfree.chart.util.Layer layer9 = null;
        java.util.Collection collection10 = categoryPlot0.getRangeMarkers((int) (short) 0, layer9);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot11.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis14 = categoryPlot11.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        categoryPlot11.zoomDomainAxes((double) 10.0f, plotRenderingInfo16, point2D17, false);
        java.lang.Comparable comparable20 = categoryPlot11.getDomainCrosshairColumnKey();
        boolean boolean21 = categoryPlot11.isRangeCrosshairLockedOnData();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = categoryPlot11.getAxisOffset();
        double double23 = rectangleInsets22.getLeft();
        categoryPlot0.setAxisOffset(rectangleInsets22);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        categoryPlot0.setRenderer(0, categoryItemRenderer26);
        java.awt.Color color28 = java.awt.Color.yellow;
        java.awt.color.ColorSpace colorSpace29 = color28.getColorSpace();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color28);
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        try {
            int int32 = categoryPlot0.getRangeAxisIndex(valueAxis31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNull(collection10);
        org.junit.Assert.assertNull(valueAxis14);
        org.junit.Assert.assertNull(comparable20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 4.0d + "'", double23 == 4.0d);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(colorSpace29);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Color color2 = java.awt.Color.getColor("ItemLabelAnchor.OUTSIDE1", color1);
        int int3 = color1.getBlue();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 128 + "'", int3 == 128);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Paint paint6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        lineAndShapeRenderer2.setBaseOutlinePaint(paint6);
        java.awt.Font font8 = lineAndShapeRenderer2.getBaseItemLabelFont();
        java.awt.Paint paint9 = lineAndShapeRenderer2.getBaseFillPaint();
        boolean boolean10 = lineAndShapeRenderer2.getAutoPopulateSeriesFillPaint();
        lineAndShapeRenderer2.setSeriesCreateEntities((int) 'a', (java.lang.Boolean) false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = null;
        try {
            lineAndShapeRenderer2.setBasePositiveItemLabelPosition(itemLabelPosition14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        lineAndShapeRenderer2.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator7);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = lineAndShapeRenderer2.getSeriesPositiveItemLabelPosition(0);
        lineAndShapeRenderer2.setBaseShapesFilled(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
        lineAndShapeRenderer2.notifyListeners(rendererChangeEvent13);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot15.clearDomainMarkers((int) (short) 10);
        categoryPlot15.setDomainGridlinesVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot20.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis23 = categoryPlot20.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        categoryPlot20.zoomDomainAxes((double) 10.0f, plotRenderingInfo25, point2D26, false);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent29 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot20);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType30 = plotChangeEvent29.getType();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType31 = plotChangeEvent29.getType();
        java.lang.Object obj32 = plotChangeEvent29.getSource();
        categoryPlot15.notifyListeners(plotChangeEvent29);
        java.awt.Stroke stroke34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot15.setOutlineStroke(stroke34);
        lineAndShapeRenderer2.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot15);
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        try {
            int int38 = categoryPlot15.getRangeAxisIndex(valueAxis37);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(chartChangeEventType30);
        org.junit.Assert.assertNotNull(chartChangeEventType31);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertNotNull(stroke34);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.util.Layer layer5 = null;
        java.util.Collection collection6 = categoryPlot0.getRangeMarkers(10, layer5);
        org.jfree.chart.axis.AxisLocation axisLocation7 = categoryPlot0.getDomainAxisLocation();
        java.awt.Shape shape12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot13.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis16 = categoryPlot13.getRangeAxis();
        int int17 = categoryPlot13.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder18 = categoryPlot13.getRowRenderingOrder();
        java.awt.Stroke stroke19 = categoryPlot13.getRangeZeroBaselineStroke();
        java.awt.Paint paint20 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem21 = new org.jfree.chart.LegendItem("", "", "hi!", "", shape12, stroke19, paint20);
        legendItem21.setDescription("");
        int int24 = legendItem21.getDatasetIndex();
        java.lang.String str25 = legendItem21.getLabel();
        java.lang.String str26 = legendItem21.getLabel();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset27 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo28 = new org.jfree.chart.event.DatasetChangeInfo();
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent29 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object) legendItem21, (org.jfree.data.general.Dataset) defaultCategoryDataset27, datasetChangeInfo28);
        categoryPlot0.datasetChanged(datasetChangeEvent29);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNull(collection6);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNull(valueAxis16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 15 + "'", int17 == 15);
        org.junit.Assert.assertNotNull(sortOrder18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        lineAndShapeRenderer2.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator7);
        lineAndShapeRenderer2.setSeriesVisible((int) (short) 100, (java.lang.Boolean) false, true);
        boolean boolean15 = lineAndShapeRenderer2.getItemShapeVisible((int) (short) 10, 3);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator16 = lineAndShapeRenderer2.getLegendItemLabelGenerator();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator18 = null;
        lineAndShapeRenderer2.setSeriesURLGenerator(3, categoryURLGenerator18, true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator16);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Shape shape9 = lineAndShapeRenderer2.getItemShape((int) (short) 10, 100, true);
        lineAndShapeRenderer2.setBaseSeriesVisible(false);
        boolean boolean12 = lineAndShapeRenderer2.getUseFillPaint();
        lineAndShapeRenderer2.setBaseCreateEntities(false);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge();
        int int4 = categoryPlot0.getWeight();
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        categoryPlot0.addChangeListener(plotChangeListener5);
        categoryPlot0.setWeight(2);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke4 = lineAndShapeRenderer3.getBaseStroke();
        java.awt.Stroke stroke6 = lineAndShapeRenderer3.lookupSeriesStroke(10);
        java.awt.Shape shape10 = lineAndShapeRenderer3.getItemShape((int) (short) 10, 100, true);
        java.awt.Paint paint12 = lineAndShapeRenderer3.getSeriesFillPaint((int) (short) 10);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator13 = null;
        lineAndShapeRenderer3.setBaseURLGenerator(categoryURLGenerator13);
        boolean boolean17 = lineAndShapeRenderer3.getItemShapeFilled((int) 'a', 2);
        boolean boolean18 = rectangleInsets0.equals((java.lang.Object) boolean17);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        java.lang.Number number0 = null;
        org.jfree.data.SelectableValue selectableValue1 = new org.jfree.data.SelectableValue(number0);
        java.lang.Number number2 = selectableValue1.getValue();
        org.junit.Assert.assertNull(number2);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        categoryPlot0.setDomainCrosshairColumnKey((java.lang.Comparable) (short) -1, true);
        org.jfree.chart.util.Layer layer9 = null;
        java.util.Collection collection10 = categoryPlot0.getRangeMarkers((int) (short) 0, layer9);
        categoryPlot0.setRangeCrosshairLockedOnData(false);
        java.lang.Comparable comparable13 = categoryPlot0.getDomainCrosshairColumnKey();
        org.jfree.chart.axis.AxisSpace axisSpace14 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace14, true);
        org.jfree.chart.axis.AxisLocation axisLocation17 = categoryPlot0.getRangeAxisLocation();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNull(collection10);
        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + (short) -1 + "'", comparable13.equals((short) -1));
        org.junit.Assert.assertNotNull(axisLocation17);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        categoryPlot0.setDomainCrosshairColumnKey((java.lang.Comparable) (short) -1, true);
        org.jfree.chart.util.Layer layer9 = null;
        java.util.Collection collection10 = categoryPlot0.getRangeMarkers((int) (short) 0, layer9);
        categoryPlot0.setRangeCrosshairLockedOnData(false);
        java.lang.Comparable comparable13 = categoryPlot0.getDomainCrosshairColumnKey();
        org.jfree.chart.axis.AxisSpace axisSpace14 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace14, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot17.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis20 = categoryPlot17.getRangeAxis();
        int int21 = categoryPlot17.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot17.getRowRenderingOrder();
        java.awt.Stroke stroke23 = categoryPlot17.getRangeZeroBaselineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent24 = null;
        categoryPlot17.rendererChanged(rendererChangeEvent24);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation27 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot26.setRangeAxisLocation(axisLocation27, true);
        categoryPlot17.setDomainAxisLocation(axisLocation27);
        categoryPlot0.setDomainAxisLocation(axisLocation27, false);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNull(collection10);
        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + (short) -1 + "'", comparable13.equals((short) -1));
        org.junit.Assert.assertNull(valueAxis20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 15 + "'", int21 == 15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(axisLocation27);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE10;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis4 = categoryPlot1.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot1.zoomDomainAxes((double) 10.0f, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor10 = categoryPlot1.getDomainGridlinePosition();
        boolean boolean11 = itemLabelAnchor0.equals((java.lang.Object) categoryAnchor10);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot12.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis15 = categoryPlot12.getRangeAxis();
        int int16 = categoryPlot12.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder17 = categoryPlot12.getRowRenderingOrder();
        categoryPlot12.setWeight((int) (short) 100);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder20 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        categoryPlot12.setDatasetRenderingOrder(datasetRenderingOrder20);
        boolean boolean22 = categoryAnchor10.equals((java.lang.Object) categoryPlot12);
        java.lang.Comparable comparable23 = categoryPlot12.getDomainCrosshairColumnKey();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertNotNull(categoryAnchor10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(valueAxis15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 15 + "'", int16 == 15);
        org.junit.Assert.assertNotNull(sortOrder17);
        org.junit.Assert.assertNotNull(datasetRenderingOrder20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(comparable23);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Shape shape9 = lineAndShapeRenderer2.getItemShape((int) (short) 10, 100, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator13 = lineAndShapeRenderer2.getItemLabelGenerator((int) 'a', 0, false);
        lineAndShapeRenderer2.clearSeriesStrokes(true);
        java.awt.Stroke stroke17 = lineAndShapeRenderer2.getSeriesOutlineStroke((int) 'a');
        boolean boolean18 = lineAndShapeRenderer2.getBaseShapesVisible();
        java.awt.Font font22 = lineAndShapeRenderer2.getItemLabelFont((int) 'a', (-10214656), false);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNull(categoryItemLabelGenerator13);
        org.junit.Assert.assertNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(font22);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getMinimumBarLength();
        java.awt.Paint paint5 = barRenderer0.getItemPaint(0, 15, true);
        barRenderer0.setShadowVisible(true);
        barRenderer0.setIncludeBaseInRange(true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer12 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke13 = lineAndShapeRenderer12.getBaseStroke();
        java.awt.Stroke stroke15 = lineAndShapeRenderer12.lookupSeriesStroke(10);
        java.awt.Paint paint16 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        lineAndShapeRenderer12.setBaseOutlinePaint(paint16);
        java.awt.Font font18 = lineAndShapeRenderer12.getBaseItemLabelFont();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = lineAndShapeRenderer12.getNegativeItemLabelPosition(1, (-1), false);
        barRenderer0.setPositiveItemLabelPositionFallback(itemLabelPosition22);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(itemLabelPosition22);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge();
        org.jfree.chart.axis.AxisLocation axisLocation4 = categoryPlot0.getDomainAxisLocation();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        categoryPlot0.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        categoryPlot0.setRenderer(categoryItemRenderer8);
        java.awt.Paint paint10 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        categoryPlot0.setDatasetRenderingOrder(datasetRenderingOrder11);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.data.Range range14 = categoryPlot0.getDataRange(valueAxis13);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
        org.junit.Assert.assertNull(range14);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Shape shape11 = null;
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", shape11, (java.awt.Paint) color12);
        int int14 = color12.getBlue();
        lineAndShapeRenderer2.setSeriesItemLabelPaint((int) (byte) 1, (java.awt.Paint) color12);
        java.lang.Boolean boolean17 = lineAndShapeRenderer2.getSeriesShapesFilled(0);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator18 = lineAndShapeRenderer2.getBaseToolTipGenerator();
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.data.Range range20 = lineAndShapeRenderer2.findRangeBounds(categoryDataset19);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator22 = null;
        lineAndShapeRenderer2.setSeriesURLGenerator((int) (byte) 100, categoryURLGenerator22, false);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 128 + "'", int14 == 128);
        org.junit.Assert.assertNull(boolean17);
        org.junit.Assert.assertNull(categoryToolTipGenerator18);
        org.junit.Assert.assertNull(range20);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        java.awt.Paint paint4 = categoryAxis2.getTickLabelPaint((java.lang.Comparable) (short) 10);
        org.jfree.chart.LegendItem legendItem5 = new org.jfree.chart.LegendItem("DatasetRenderingOrder.REVERSE", paint4);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        boolean boolean9 = categoryPlot0.isRangeCrosshairVisible();
        categoryPlot0.setRangeCrosshairValue((double) 0, false);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        java.lang.Comparable comparable9 = categoryPlot0.getDomainCrosshairColumnKey();
        boolean boolean10 = categoryPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = categoryPlot0.getAxisOffset();
        boolean boolean12 = categoryPlot0.isSubplot();
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot13.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis16 = categoryPlot13.getRangeAxis();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier17 = categoryPlot13.getDrawingSupplier();
        java.awt.Paint paint18 = categoryPlot13.getOutlinePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot19.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis22 = categoryPlot19.getRangeAxis();
        int int23 = categoryPlot19.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder24 = categoryPlot19.getRowRenderingOrder();
        java.awt.Stroke stroke25 = categoryPlot19.getRangeZeroBaselineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent26 = null;
        categoryPlot19.rendererChanged(rendererChangeEvent26);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation29 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot28.setRangeAxisLocation(axisLocation29, true);
        categoryPlot19.setDomainAxisLocation(axisLocation29);
        categoryPlot19.setCrosshairDatasetIndex((int) (short) 1);
        org.jfree.data.category.CategoryDataset categoryDataset35 = categoryPlot19.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = categoryPlot19.getAxisOffset();
        categoryPlot13.setAxisOffset(rectangleInsets36);
        double double39 = rectangleInsets36.extendWidth((-1.0d));
        categoryPlot0.setInsets(rectangleInsets36, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot42.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.util.RectangleEdge rectangleEdge45 = categoryPlot42.getDomainAxisEdge();
        org.jfree.chart.axis.AxisLocation axisLocation46 = categoryPlot42.getDomainAxisLocation();
        java.awt.Graphics2D graphics2D47 = null;
        java.awt.geom.Rectangle2D rectangle2D48 = null;
        categoryPlot42.drawBackgroundImage(graphics2D47, rectangle2D48);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer50 = null;
        categoryPlot42.setRenderer(categoryItemRenderer50);
        java.awt.Paint paint52 = categoryPlot42.getDomainGridlinePaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder53 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        categoryPlot42.setDatasetRenderingOrder(datasetRenderingOrder53);
        categoryPlot0.setDatasetRenderingOrder(datasetRenderingOrder53);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNull(comparable9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(valueAxis16);
        org.junit.Assert.assertNotNull(drawingSupplier17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNull(valueAxis22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 15 + "'", int23 == 15);
        org.junit.Assert.assertNotNull(sortOrder24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(axisLocation29);
        org.junit.Assert.assertNull(categoryDataset35);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 7.0d + "'", double39 == 7.0d);
        org.junit.Assert.assertNotNull(rectangleEdge45);
        org.junit.Assert.assertNotNull(axisLocation46);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertNotNull(datasetRenderingOrder53);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent9 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot0);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer12 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke13 = lineAndShapeRenderer12.getBaseStroke();
        categoryPlot0.setRangeMinorGridlineStroke(stroke13);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor15 = org.jfree.chart.axis.CategoryAnchor.START;
        categoryPlot0.setDomainGridlinePosition(categoryAnchor15);
        java.lang.String str17 = categoryAnchor15.toString();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(categoryAnchor15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "CategoryAnchor.START" + "'", str17.equals("CategoryAnchor.START"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        categoryPlot0.setDomainCrosshairColumnKey((java.lang.Comparable) (short) -1, true);
        org.jfree.chart.util.Layer layer9 = null;
        java.util.Collection collection10 = categoryPlot0.getRangeMarkers((int) (short) 0, layer9);
        categoryPlot0.setRangeMinorGridlinesVisible(true);
        categoryPlot0.setNoDataMessage("hi!");
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation15 = null;
        try {
            categoryPlot0.addAnnotation(categoryAnnotation15, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNull(collection10);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor9 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis13 = categoryPlot10.getRangeAxis();
        int int14 = categoryPlot10.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder15 = categoryPlot10.getRowRenderingOrder();
        java.awt.Stroke stroke16 = categoryPlot10.getRangeZeroBaselineStroke();
        categoryPlot0.setRangeMinorGridlineStroke(stroke16);
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = categoryPlot0.getDomainAxis(100);
        boolean boolean20 = categoryPlot0.isNotify();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder21 = categoryPlot0.getDatasetRenderingOrder();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(categoryAnchor9);
        org.junit.Assert.assertNull(valueAxis13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 15 + "'", int14 == 15);
        org.junit.Assert.assertNotNull(sortOrder15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNull(categoryAxis19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder21);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier4 = categoryPlot0.getDrawingSupplier();
        java.awt.Paint paint5 = categoryPlot0.getOutlinePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot6.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis9 = categoryPlot6.getRangeAxis();
        int int10 = categoryPlot6.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder11 = categoryPlot6.getRowRenderingOrder();
        java.awt.Stroke stroke12 = categoryPlot6.getRangeZeroBaselineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
        categoryPlot6.rendererChanged(rendererChangeEvent13);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot15.setRangeAxisLocation(axisLocation16, true);
        categoryPlot6.setDomainAxisLocation(axisLocation16);
        categoryPlot6.setCrosshairDatasetIndex((int) (short) 1);
        org.jfree.data.category.CategoryDataset categoryDataset22 = categoryPlot6.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = categoryPlot6.getAxisOffset();
        categoryPlot0.setAxisOffset(rectangleInsets23);
        double double26 = rectangleInsets23.extendWidth((-1.0d));
        double double28 = rectangleInsets23.calculateRightOutset((double) 1L);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(drawingSupplier4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 15 + "'", int10 == 15);
        org.junit.Assert.assertNotNull(sortOrder11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNull(categoryDataset22);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 7.0d + "'", double26 == 7.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 4.0d + "'", double28 == 4.0d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape0, "ChartChangeEventType.GENERAL", "");
        org.jfree.chart.entity.ChartEntity chartEntity4 = new org.jfree.chart.entity.ChartEntity(shape0);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation6 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot5.setRangeAxisLocation(axisLocation6, true);
        org.jfree.chart.axis.ValueAxis valueAxis10 = categoryPlot5.getRangeAxis((int) '#');
        categoryPlot5.clearDomainAxes();
        org.jfree.chart.entity.PlotEntity plotEntity14 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) categoryPlot5, "java.awt.Color[r=0,g=0,b=0]", "");
        org.jfree.chart.plot.CategoryMarker categoryMarker16 = null;
        org.jfree.chart.util.Layer layer17 = null;
        try {
            categoryPlot5.addDomainMarker((int) (short) 1, categoryMarker16, layer17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNull(valueAxis10);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Shape shape9 = lineAndShapeRenderer2.getItemShape((int) (short) 10, 100, true);
        lineAndShapeRenderer2.setBaseCreateEntities(true);
        org.jfree.chart.LegendItemCollection legendItemCollection12 = lineAndShapeRenderer2.getLegendItems();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(legendItemCollection12);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = lineAndShapeRenderer2.getBasePositiveItemLabelPosition();
        org.jfree.chart.renderer.RenderAttributes renderAttributes4 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        renderAttributes4.setDefaultFillPaint((java.awt.Paint) color5);
        java.awt.Shape shape9 = renderAttributes4.getItemShape((int) (byte) 100, (int) 'a');
        java.awt.Shape shape11 = null;
        renderAttributes4.setSeriesShape((int) (byte) 1, shape11);
        java.awt.Paint paint13 = renderAttributes4.getDefaultFillPaint();
        boolean boolean14 = itemLabelPosition3.equals((java.lang.Object) paint13);
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(shape9);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder5 = categoryPlot0.getRowRenderingOrder();
        java.awt.Stroke stroke6 = categoryPlot0.getRangeZeroBaselineStroke();
        int int7 = categoryPlot0.getCrosshairDatasetIndex();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke11 = lineAndShapeRenderer10.getBaseStroke();
        java.awt.Stroke stroke13 = lineAndShapeRenderer10.lookupSeriesStroke(10);
        lineAndShapeRenderer10.setAutoPopulateSeriesStroke(true);
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer10, true);
        java.awt.Shape shape19 = lineAndShapeRenderer10.getLegendShape(2);
        java.awt.Paint paint20 = lineAndShapeRenderer10.getBaseOutlinePaint();
        boolean boolean21 = lineAndShapeRenderer10.getUseSeriesOffset();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(sortOrder5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNull(shape19);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairLockedOnData(false);
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) (short) 10);
        categoryPlot0.setAnchorValue((double) (short) 10, false);
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace8);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        categoryPlot0.markerChanged(markerChangeEvent10);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke15 = lineAndShapeRenderer14.getBaseStroke();
        java.awt.Stroke stroke17 = lineAndShapeRenderer14.lookupSeriesStroke(10);
        java.awt.Shape shape23 = null;
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", shape23, (java.awt.Paint) color24);
        int int26 = color24.getBlue();
        lineAndShapeRenderer14.setSeriesItemLabelPaint((int) (byte) 1, (java.awt.Paint) color24);
        int int28 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer14);
        java.awt.Stroke stroke30 = lineAndShapeRenderer14.lookupSeriesStroke((-1));
        java.awt.Stroke stroke32 = lineAndShapeRenderer14.getSeriesOutlineStroke((int) ' ');
        java.awt.Shape shape34 = lineAndShapeRenderer14.lookupLegendShape(0);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 128 + "'", int26 == 128);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNull(stroke32);
        org.junit.Assert.assertNotNull(shape34);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.getSeriesItemLabelPaint((int) '4');
        boolean boolean3 = barRenderer0.isDrawBarOutline();
        java.awt.Font font4 = barRenderer0.getBaseItemLabelFont();
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(font4);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot0.setRangeAxisLocation(axisLocation1, true);
        java.lang.Comparable comparable4 = categoryPlot0.getDomainCrosshairColumnKey();
        java.awt.Color color5 = java.awt.Color.yellow;
        java.awt.color.ColorSpace colorSpace6 = color5.getColorSpace();
        float[] floatArray10 = new float[] { (byte) 1, '#', 15 };
        float[] floatArray11 = color5.getRGBColorComponents(floatArray10);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color5);
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = categoryPlot0.getRangeAxisEdge((int) (byte) 10);
        categoryPlot0.clearRangeMarkers();
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNull(comparable4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(colorSpace6);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(rectangleEdge14);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent9 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot0);
        org.jfree.chart.plot.Marker marker10 = null;
        org.jfree.chart.util.Layer layer11 = null;
        boolean boolean12 = categoryPlot0.removeDomainMarker(marker10, layer11);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot13.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis16 = categoryPlot13.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        categoryPlot13.zoomDomainAxes((double) 10.0f, plotRenderingInfo18, point2D19, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor22 = categoryPlot13.getDomainGridlinePosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot23.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis26 = categoryPlot23.getRangeAxis();
        int int27 = categoryPlot23.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder28 = categoryPlot23.getRowRenderingOrder();
        java.awt.Stroke stroke29 = categoryPlot23.getRangeZeroBaselineStroke();
        categoryPlot13.setRangeMinorGridlineStroke(stroke29);
        categoryPlot0.setRangeGridlineStroke(stroke29);
        boolean boolean32 = categoryPlot0.isSubplot();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(valueAxis16);
        org.junit.Assert.assertNotNull(categoryAnchor22);
        org.junit.Assert.assertNull(valueAxis26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 15 + "'", int27 == 15);
        org.junit.Assert.assertNotNull(sortOrder28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        java.awt.Shape shape4 = null;
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem6 = new org.jfree.chart.LegendItem("", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", shape4, (java.awt.Paint) color5);
        java.awt.Paint paint7 = legendItem6.getLabelPaint();
        java.awt.Font font8 = legendItem6.getLabelFont();
        java.awt.Color color9 = java.awt.Color.pink;
        legendItem6.setFillPaint((java.awt.Paint) color9);
        java.awt.Color color11 = java.awt.Color.white;
        int int12 = color11.getRed();
        java.awt.Color color16 = java.awt.Color.getHSBColor((float) (short) 1, (float) 100, 0.0f);
        float[] floatArray23 = new float[] { (byte) 10, (byte) 1, 1.0f, (byte) 0, 10, (byte) 100 };
        float[] floatArray24 = color16.getRGBComponents(floatArray23);
        float[] floatArray25 = color11.getColorComponents(floatArray24);
        float[] floatArray26 = color9.getRGBComponents(floatArray25);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNull(font8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 255 + "'", int12 == 255);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(floatArray26);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        java.awt.Shape shape4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        int int9 = categoryPlot5.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot5.getRowRenderingOrder();
        java.awt.Stroke stroke11 = categoryPlot5.getRangeZeroBaselineStroke();
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("", "", "hi!", "", shape4, stroke11, paint12);
        legendItem13.setDescription("");
        int int16 = legendItem13.getDatasetIndex();
        java.lang.String str17 = legendItem13.getLabel();
        java.lang.String str18 = legendItem13.getLabel();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset19 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo20 = new org.jfree.chart.event.DatasetChangeInfo();
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent21 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object) legendItem13, (org.jfree.data.general.Dataset) defaultCategoryDataset19, datasetChangeInfo20);
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo22 = datasetChangeEvent21.getInfo();
        org.jfree.data.general.Dataset dataset23 = datasetChangeEvent21.getDataset();
        org.jfree.data.general.Dataset dataset24 = datasetChangeEvent21.getDataset();
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertNotNull(datasetChangeInfo22);
        org.junit.Assert.assertNotNull(dataset23);
        org.junit.Assert.assertNotNull(dataset24);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot0.setRangeAxisLocation(axisLocation1, true);
        java.lang.Comparable comparable4 = categoryPlot0.getDomainCrosshairColumnKey();
        java.awt.Stroke stroke5 = categoryPlot0.getOutlineStroke();
        categoryPlot0.clearRangeMarkers((int) (short) -1);
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNull(comparable4);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = null;
        lineAndShapeRenderer2.setSeriesItemLabelGenerator((int) (byte) 1, categoryItemLabelGenerator5);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke11 = lineAndShapeRenderer10.getBaseStroke();
        java.awt.Paint paint13 = lineAndShapeRenderer10.getSeriesPaint(15);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer17 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke18 = lineAndShapeRenderer17.getBaseStroke();
        java.awt.Stroke stroke20 = lineAndShapeRenderer17.lookupSeriesStroke(10);
        java.awt.Paint paint21 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        lineAndShapeRenderer17.setBaseOutlinePaint(paint21);
        java.awt.Font font23 = lineAndShapeRenderer17.getBaseItemLabelFont();
        lineAndShapeRenderer10.setSeriesItemLabelFont((int) (byte) 1, font23);
        lineAndShapeRenderer2.setSeriesItemLabelFont((int) (short) 10, font23, true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer30 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke31 = lineAndShapeRenderer30.getBaseStroke();
        java.awt.Stroke stroke33 = lineAndShapeRenderer30.lookupSeriesStroke(10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator35 = null;
        lineAndShapeRenderer30.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator35);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition38 = lineAndShapeRenderer30.getSeriesPositiveItemLabelPosition(0);
        lineAndShapeRenderer30.setBaseShapesFilled(false);
        lineAndShapeRenderer30.setSeriesVisibleInLegend((int) (short) 10, (java.lang.Boolean) false);
        java.awt.Stroke stroke45 = lineAndShapeRenderer30.lookupSeriesOutlineStroke((-1));
        lineAndShapeRenderer2.setSeriesStroke((int) (short) 10, stroke45, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition48 = lineAndShapeRenderer2.getBasePositiveItemLabelPosition();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(itemLabelPosition38);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(itemLabelPosition48);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        renderAttributes0.setDefaultFillPaint((java.awt.Paint) color1);
        java.awt.Shape shape5 = renderAttributes0.getItemShape((int) (byte) 100, (int) 'a');
        java.awt.Shape shape7 = null;
        renderAttributes0.setSeriesShape((int) (byte) 1, shape7);
        java.awt.Paint paint10 = renderAttributes0.getSeriesOutlinePaint((int) (byte) 1);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot11.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis14 = categoryPlot11.getRangeAxis();
        int int15 = categoryPlot11.getBackgroundImageAlignment();
        categoryPlot11.setDomainCrosshairColumnKey((java.lang.Comparable) (short) -1, true);
        java.awt.Stroke stroke19 = categoryPlot11.getDomainGridlineStroke();
        renderAttributes0.setDefaultStroke(stroke19);
        try {
            java.awt.Font font22 = renderAttributes0.getSeriesLabelFont((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNull(shape5);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNull(valueAxis14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 15 + "'", int15 == 15);
        org.junit.Assert.assertNotNull(stroke19);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = lineAndShapeRenderer2.getBasePositiveItemLabelPosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot4.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = categoryPlot4.getDomainAxisEdge();
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot4.getDomainAxisLocation();
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        categoryPlot4.drawBackgroundImage(graphics2D9, rectangle2D10);
        java.awt.Paint paint12 = categoryPlot4.getNoDataMessagePaint();
        lineAndShapeRenderer2.setBaseItemLabelPaint(paint12);
        boolean boolean14 = lineAndShapeRenderer2.getUseFillPaint();
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier1 = lineAndShapeRenderer0.getDrawingSupplier();
        org.junit.Assert.assertNull(drawingSupplier1);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_GREEN;
        int int1 = color0.getRGB();
        java.awt.Shape shape6 = null;
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem8 = new org.jfree.chart.LegendItem("", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", shape6, (java.awt.Paint) color7);
        java.awt.color.ColorSpace colorSpace9 = color7.getColorSpace();
        java.awt.Color color10 = java.awt.Color.BLACK;
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Color color18 = java.awt.Color.getHSBColor((float) (short) 1, (float) 100, 0.0f);
        float[] floatArray25 = new float[] { (byte) 10, (byte) 1, 1.0f, (byte) 0, 10, (byte) 100 };
        float[] floatArray26 = color18.getRGBComponents(floatArray25);
        float[] floatArray27 = java.awt.Color.RGBtoHSB(100, (int) (short) 10, 128, floatArray26);
        float[] floatArray28 = color11.getRGBColorComponents(floatArray26);
        float[] floatArray29 = color10.getRGBColorComponents(floatArray28);
        float[] floatArray30 = color0.getComponents(colorSpace9, floatArray29);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-16728064) + "'", int1 == (-16728064));
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(colorSpace9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(floatArray26);
        org.junit.Assert.assertNotNull(floatArray27);
        org.junit.Assert.assertNotNull(floatArray28);
        org.junit.Assert.assertNotNull(floatArray29);
        org.junit.Assert.assertNotNull(floatArray30);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        java.awt.Shape shape4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        int int9 = categoryPlot5.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot5.getRowRenderingOrder();
        java.awt.Stroke stroke11 = categoryPlot5.getRangeZeroBaselineStroke();
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("", "", "hi!", "", shape4, stroke11, paint12);
        legendItem13.setDescription("");
        int int16 = legendItem13.getDatasetIndex();
        java.lang.String str17 = legendItem13.getLabel();
        java.lang.String str18 = legendItem13.getLabel();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset19 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo20 = new org.jfree.chart.event.DatasetChangeInfo();
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent21 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object) legendItem13, (org.jfree.data.general.Dataset) defaultCategoryDataset19, datasetChangeInfo20);
        int int22 = defaultCategoryDataset19.getRowCount();
        int int23 = defaultCategoryDataset19.getColumnCount();
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor1 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE5;
        java.awt.Color color2 = java.awt.Color.white;
        boolean boolean3 = itemLabelAnchor1.equals((java.lang.Object) color2);
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor1, textAnchor4);
        double double6 = itemLabelPosition5.getAngle();
        barRenderer0.setPositiveItemLabelPositionFallback(itemLabelPosition5);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer11 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke12 = lineAndShapeRenderer11.getBaseStroke();
        java.awt.Stroke stroke14 = lineAndShapeRenderer11.lookupSeriesStroke(10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator16 = null;
        lineAndShapeRenderer11.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator16);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = lineAndShapeRenderer11.getSeriesPositiveItemLabelPosition(0);
        lineAndShapeRenderer11.setBaseShapesFilled(false);
        lineAndShapeRenderer11.setSeriesVisibleInLegend((int) (short) 10, (java.lang.Boolean) false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer25 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor26 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE5;
        java.awt.Color color27 = java.awt.Color.white;
        boolean boolean28 = itemLabelAnchor26.equals((java.lang.Object) color27);
        org.jfree.chart.text.TextAnchor textAnchor29 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition30 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor26, textAnchor29);
        double double31 = itemLabelPosition30.getAngle();
        barRenderer25.setPositiveItemLabelPositionFallback(itemLabelPosition30);
        lineAndShapeRenderer11.setBaseNegativeItemLabelPosition(itemLabelPosition30, true);
        barRenderer0.setSeriesNegativeItemLabelPosition(10, itemLabelPosition30, false);
        org.junit.Assert.assertNotNull(itemLabelAnchor1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(itemLabelPosition19);
        org.junit.Assert.assertNotNull(itemLabelAnchor26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(textAnchor29);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        boolean boolean9 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.axis.AxisLocation axisLocation11 = null;
        categoryPlot0.setDomainAxisLocation(255, axisLocation11);
        org.jfree.chart.util.SortOrder sortOrder13 = categoryPlot0.getRowRenderingOrder();
        categoryPlot0.setBackgroundImageAlignment(0);
        java.util.List list16 = categoryPlot0.getAnnotations();
        org.jfree.data.general.DatasetGroup datasetGroup17 = categoryPlot0.getDatasetGroup();
        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.axis.AxisLocation axisLocation19 = axisLocation18.getOpposite();
        categoryPlot0.setRangeAxisLocation(axisLocation19);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(sortOrder13);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertNull(datasetGroup17);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(axisLocation19);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int2 = keyedObjects2D0.getRowIndex((java.lang.Comparable) (byte) 0);
        try {
            keyedObjects2D0.removeRow((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        renderAttributes0.setDefaultFillPaint((java.awt.Paint) color1);
        java.awt.Paint paint3 = renderAttributes0.getDefaultOutlinePaint();
        java.awt.Stroke stroke4 = renderAttributes0.getDefaultStroke();
        java.awt.Paint paint6 = renderAttributes0.getSeriesFillPaint(128);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot7.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = categoryPlot7.getDomainAxisEdge();
        int int11 = categoryPlot7.getWeight();
        java.lang.Comparable comparable12 = categoryPlot7.getDomainCrosshairColumnKey();
        boolean boolean13 = categoryPlot7.canSelectByRegion();
        org.jfree.chart.axis.AxisLocation axisLocation14 = categoryPlot7.getRangeAxisLocation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        categoryPlot7.zoomDomainAxes((double) (short) 100, plotRenderingInfo16, point2D17, false);
        java.awt.Stroke stroke20 = categoryPlot7.getDomainCrosshairStroke();
        renderAttributes0.setDefaultStroke(stroke20);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNull(stroke4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNull(comparable12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        categoryPlot0.setDomainCrosshairColumnKey((java.lang.Comparable) (short) -1, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot0.zoomRangeAxes((double) (byte) 1, plotRenderingInfo9, point2D10, true);
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) 0.0f, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot16.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis19 = categoryPlot16.getRangeAxis();
        int int20 = categoryPlot16.getBackgroundImageAlignment();
        java.awt.Paint paint21 = categoryPlot16.getNoDataMessagePaint();
        java.awt.Paint paint22 = categoryPlot16.getRangeMinorGridlinePaint();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot16);
        java.awt.Paint paint24 = categoryPlot16.getDomainGridlinePaint();
        int int25 = categoryPlot16.getRangeAxisCount();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNull(valueAxis19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 15 + "'", int20 == 15);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = categoryAxis1.getTickLabelInsets();
        categoryAxis1.setCategoryLabelPositionOffset(0);
        categoryAxis1.setMinorTickMarksVisible(false);
        float float7 = categoryAxis1.getMinorTickMarkOutsideLength();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = categoryAxis1.getLabelInsets();
        org.jfree.chart.util.UnitType unitType9 = rectangleInsets8.getUnitType();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = new org.jfree.chart.util.RectangleInsets(unitType9, (double) (byte) 0, (-1.0d), 10.0d, (double) 4);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 2.0f + "'", float7 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(unitType9);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getMinimumBarLength();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = null;
        barRenderer0.setSeriesURLGenerator((int) (short) 0, categoryURLGenerator3);
        boolean boolean6 = barRenderer0.isSeriesVisibleInLegend(0);
        barRenderer0.setShadowXOffset(0.0d);
        barRenderer0.setItemMargin((double) (-128));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder4 = categoryPlot0.getDatasetRenderingOrder();
        float float5 = categoryPlot0.getBackgroundImageAlpha();
        java.awt.Image image6 = categoryPlot0.getBackgroundImage();
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) (-16728064));
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(datasetRenderingOrder4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.5f + "'", float5 == 0.5f);
        org.junit.Assert.assertNull(image6);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Shape shape11 = null;
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", shape11, (java.awt.Paint) color12);
        int int14 = color12.getBlue();
        lineAndShapeRenderer2.setSeriesItemLabelPaint((int) (byte) 1, (java.awt.Paint) color12);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator19 = lineAndShapeRenderer2.getToolTipGenerator((int) (short) 0, (int) (short) 10, false);
        java.awt.Paint paint23 = lineAndShapeRenderer2.getItemPaint((int) (short) -1, 3, false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator27 = lineAndShapeRenderer2.getURLGenerator((int) (short) -1, 128, false);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 128 + "'", int14 == 128);
        org.junit.Assert.assertNull(categoryToolTipGenerator19);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNull(categoryURLGenerator27);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Stroke stroke5 = lineAndShapeRenderer2.lookupSeriesStroke(10);
        java.awt.Shape shape11 = null;
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", "ItemLabelAnchor.OUTSIDE1", shape11, (java.awt.Paint) color12);
        int int14 = color12.getBlue();
        lineAndShapeRenderer2.setSeriesItemLabelPaint((int) (byte) 1, (java.awt.Paint) color12);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean17 = categoryPlot16.isRangeGridlinesVisible();
        categoryPlot16.clearDomainAxes();
        lineAndShapeRenderer2.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot16);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator23 = lineAndShapeRenderer2.getToolTipGenerator((int) ' ', (int) ' ', true);
        boolean boolean24 = lineAndShapeRenderer2.getBaseItemLabelsVisible();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 128 + "'", int14 == 128);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNull(categoryToolTipGenerator23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        renderAttributes0.setDefaultFillPaint((java.awt.Paint) color1);
        java.awt.Shape shape5 = renderAttributes0.getItemShape((int) (byte) 100, (int) 'a');
        java.awt.Shape shape7 = null;
        renderAttributes0.setSeriesShape((int) (byte) 1, shape7);
        java.awt.Paint paint9 = renderAttributes0.getDefaultFillPaint();
        java.awt.Paint paint10 = renderAttributes0.getDefaultLabelPaint();
        java.awt.Shape shape11 = renderAttributes0.getDefaultShape();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNull(shape5);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNull(shape11);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getMinimumBarLength();
        java.awt.Paint paint5 = barRenderer0.getItemPaint(0, 15, true);
        double double6 = barRenderer0.getShadowXOffset();
        boolean boolean7 = barRenderer0.getIncludeBaseInRange();
        barRenderer0.removeAnnotations();
        boolean boolean9 = barRenderer0.isDrawBarOutline();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        categoryPlot0.setDomainCrosshairColumnKey((java.lang.Comparable) (short) -1, true);
        org.jfree.chart.util.Layer layer9 = null;
        java.util.Collection collection10 = categoryPlot0.getRangeMarkers((int) (short) 0, layer9);
        categoryPlot0.setRangeMinorGridlinesVisible(true);
        java.lang.String str13 = categoryPlot0.getNoDataMessage();
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) 128);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNull(collection10);
        org.junit.Assert.assertNull(str13);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(0.2d, (double) 1.0f, (double) 10L, (double) 10.0f);
        int int6 = objectList0.indexOf((java.lang.Object) 10.0f);
        java.lang.Object obj8 = objectList0.get(2);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = categoryAxis10.getTickLabelInsets();
        categoryAxis10.setCategoryLabelPositionOffset(0);
        categoryAxis10.setMinorTickMarksVisible(false);
        float float16 = categoryAxis10.getMinorTickMarkOutsideLength();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = categoryAxis10.getLabelInsets();
        org.jfree.chart.util.UnitType unitType18 = rectangleInsets17.getUnitType();
        boolean boolean19 = objectList0.equals((java.lang.Object) unitType18);
        java.lang.String str20 = unitType18.toString();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNull(obj8);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 2.0f + "'", float16 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(unitType18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "UnitType.ABSOLUTE" + "'", str20.equals("UnitType.ABSOLUTE"));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        double double2 = categoryAxis1.getLabelAngle();
        categoryAxis1.setTickLabelsVisible(true);
        double double5 = categoryAxis1.getUpperMargin();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test196");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.util.List list1 = keyedObjects0.getKeys();
        org.jfree.chart.util.StrokeList strokeList3 = new org.jfree.chart.util.StrokeList();
        keyedObjects0.addObject((java.lang.Comparable) (-10214656), (java.lang.Object) strokeList3);
        org.jfree.chart.util.SortOrder sortOrder5 = org.jfree.chart.util.SortOrder.ASCENDING;
        keyedObjects0.sortByKeys(sortOrder5);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(sortOrder5);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test197");
        java.awt.Shape shape4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        int int9 = categoryPlot5.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot5.getRowRenderingOrder();
        java.awt.Stroke stroke11 = categoryPlot5.getRangeZeroBaselineStroke();
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("", "", "hi!", "", shape4, stroke11, paint12);
        legendItem13.setDescription("");
        int int16 = legendItem13.getDatasetIndex();
        java.lang.String str17 = legendItem13.getLabel();
        java.lang.String str18 = legendItem13.getLabel();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset19 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo20 = new org.jfree.chart.event.DatasetChangeInfo();
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent21 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object) legendItem13, (org.jfree.data.general.Dataset) defaultCategoryDataset19, datasetChangeInfo20);
        defaultCategoryDataset19.clearSelection();
        int int23 = defaultCategoryDataset19.getRowCount();
        int int25 = defaultCategoryDataset19.getColumnIndex((java.lang.Comparable) "AxisLocation.BOTTOM_OR_LEFT");
        org.jfree.data.category.CategoryDatasetSelectionState categoryDatasetSelectionState26 = defaultCategoryDataset19.getSelectionState();
        try {
            java.lang.Comparable comparable28 = defaultCategoryDataset19.getRowKey(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNotNull(categoryDatasetSelectionState26);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        java.awt.Paint paint5 = categoryPlot0.getNoDataMessagePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = categoryPlot0.getDomainAxisForDataset((int) 'a');
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke11 = lineAndShapeRenderer10.getBaseStroke();
        org.jfree.chart.LegendItemCollection legendItemCollection12 = lineAndShapeRenderer10.getLegendItems();
        int int13 = legendItemCollection12.getItemCount();
        categoryPlot0.setFixedLegendItems(legendItemCollection12);
        org.jfree.chart.axis.AxisLocation axisLocation15 = categoryPlot0.getRangeAxisLocation();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(categoryAxis7);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(legendItemCollection12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(axisLocation15);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test199");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isRangeGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getRangeAxisEdge((int) (byte) -1);
        boolean boolean4 = categoryPlot0.canSelectByRegion();
        java.awt.Color color8 = java.awt.Color.getHSBColor((float) (short) 1, (float) 100, 0.0f);
        float[] floatArray15 = new float[] { (byte) 10, (byte) 1, 1.0f, (byte) 0, 10, (byte) 100 };
        float[] floatArray16 = color8.getRGBComponents(floatArray15);
        java.lang.String str17 = color8.toString();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color8);
        float float19 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.plot.Marker marker20 = null;
        try {
            categoryPlot0.addRangeMarker(marker20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "java.awt.Color[r=0,g=0,b=0]" + "'", str17.equals("java.awt.Color[r=0,g=0,b=0]"));
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 1.0f + "'", float19 == 1.0f);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test200");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = categoryAxis1.getTickLabelInsets();
        categoryAxis1.setCategoryLabelPositionOffset(0);
        categoryAxis1.setMinorTickMarksVisible(false);
        float float7 = categoryAxis1.getMinorTickMarkOutsideLength();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation9 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot8.setRangeAxisLocation(axisLocation9, true);
        java.lang.Comparable comparable12 = categoryPlot8.getDomainCrosshairColumnKey();
        java.awt.Color color13 = java.awt.Color.yellow;
        java.awt.color.ColorSpace colorSpace14 = color13.getColorSpace();
        float[] floatArray18 = new float[] { (byte) 1, '#', 15 };
        float[] floatArray19 = color13.getRGBColorComponents(floatArray18);
        categoryPlot8.setDomainGridlinePaint((java.awt.Paint) color13);
        boolean boolean21 = categoryAxis1.hasListener((java.util.EventListener) categoryPlot8);
        java.lang.String str22 = categoryAxis1.getLabelToolTip();
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot23.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis26 = categoryPlot23.getRangeAxis();
        int int27 = categoryPlot23.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder28 = categoryPlot23.getRowRenderingOrder();
        categoryPlot23.setWeight((int) (short) 100);
        boolean boolean31 = categoryPlot23.isDomainCrosshairVisible();
        org.jfree.chart.util.ShadowGenerator shadowGenerator32 = categoryPlot23.getShadowGenerator();
        org.jfree.chart.axis.AxisLocation axisLocation33 = categoryPlot23.getDomainAxisLocation();
        categoryAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot23);
        java.awt.Paint paint35 = null;
        try {
            categoryAxis1.setLabelPaint(paint35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 2.0f + "'", float7 == 2.0f);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNull(comparable12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(colorSpace14);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertNull(valueAxis26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 15 + "'", int27 == 15);
        org.junit.Assert.assertNotNull(sortOrder28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(shadowGenerator32);
        org.junit.Assert.assertNotNull(axisLocation33);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test201");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.axis.AxisSpace axisSpace5 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace5, true);
        org.jfree.chart.plot.Marker marker8 = null;
        boolean boolean9 = categoryPlot0.removeDomainMarker(marker8);
        categoryPlot0.setCrosshairDatasetIndex((int) (short) 1);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test202");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getMinimumBarLength();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = null;
        barRenderer0.setSeriesURLGenerator((int) (short) 0, categoryURLGenerator3);
        java.awt.Paint paint5 = barRenderer0.getShadowPaint();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = barRenderer0.getSeriesToolTipGenerator(255);
        double double8 = barRenderer0.getItemMargin();
        barRenderer0.setMaximumBarWidth((double) (-256));
        barRenderer0.setSeriesItemLabelsVisible((int) (short) 10, false);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(categoryToolTipGenerator7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.2d + "'", double8 == 0.2d);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test203");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int2 = keyedObjects2D0.getRowIndex((java.lang.Comparable) (byte) 0);
        int int4 = keyedObjects2D0.getRowIndex((java.lang.Comparable) "ChartChangeEventType.NEW_DATASET");
        int int6 = keyedObjects2D0.getRowIndex((java.lang.Comparable) false);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test204");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.START;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis4 = categoryPlot1.getRangeAxis();
        int int5 = categoryPlot1.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder6 = categoryPlot1.getRowRenderingOrder();
        java.awt.Stroke stroke7 = categoryPlot1.getRangeZeroBaselineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = categoryPlot1.getInsets();
        java.lang.Object obj9 = categoryPlot1.clone();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot1.zoomRangeAxes((double) 2, plotRenderingInfo11, point2D12, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        categoryPlot1.panDomainAxes((double) 1.0f, plotRenderingInfo16, point2D17);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor19 = categoryPlot1.getDomainGridlinePosition();
        boolean boolean20 = categoryAnchor0.equals((java.lang.Object) categoryPlot1);
        org.junit.Assert.assertNotNull(categoryAnchor0);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
        org.junit.Assert.assertNotNull(sortOrder6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(categoryAnchor19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test205");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder5 = categoryPlot0.getRowRenderingOrder();
        categoryPlot0.setWeight((int) (short) 100);
        int int8 = categoryPlot0.getDomainAxisCount();
        java.lang.Object obj9 = categoryPlot0.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis13 = categoryPlot10.getRangeAxis();
        java.awt.Paint paint14 = categoryPlot10.getDomainGridlinePaint();
        categoryPlot0.setDomainCrosshairPaint(paint14);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot16.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = categoryPlot16.getDomainAxisEdge();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder20 = categoryPlot16.getDatasetRenderingOrder();
        float float21 = categoryPlot16.getBackgroundImageAlpha();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot16);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(sortOrder5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(valueAxis13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertNotNull(datasetRenderingOrder20);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 0.5f + "'", float21 == 0.5f);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test206");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseStroke();
        java.awt.Paint paint5 = lineAndShapeRenderer2.getSeriesPaint(15);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = lineAndShapeRenderer2.getSeriesNegativeItemLabelPosition(255);
        int int8 = lineAndShapeRenderer2.getDefaultEntityRadius();
        java.awt.Stroke stroke9 = lineAndShapeRenderer2.getBaseOutlineStroke();
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot12.setRangeAxisLocation(axisLocation13, true);
        java.lang.Comparable comparable16 = categoryPlot12.getDomainCrosshairColumnKey();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        java.awt.Stroke stroke20 = lineAndShapeRenderer19.getBaseStroke();
        org.jfree.chart.LegendItemCollection legendItemCollection21 = lineAndShapeRenderer19.getLegendItems();
        categoryPlot12.setFixedLegendItems(legendItemCollection21);
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState25 = lineAndShapeRenderer2.initialise(graphics2D10, rectangle2D11, categoryPlot12, categoryDataset23, plotRenderingInfo24);
        org.jfree.chart.util.ShadowGenerator shadowGenerator26 = null;
        categoryPlot12.setShadowGenerator(shadowGenerator26);
        java.awt.Shape shape28 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity31 = new org.jfree.chart.entity.ChartEntity(shape28, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape32 = chartEntity31.getArea();
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot33.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis36 = categoryPlot33.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = null;
        java.awt.geom.Point2D point2D39 = null;
        categoryPlot33.zoomDomainAxes((double) 10.0f, plotRenderingInfo38, point2D39, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor42 = categoryPlot33.getDomainGridlinePosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot43.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis46 = categoryPlot43.getRangeAxis();
        int int47 = categoryPlot43.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder48 = categoryPlot43.getRowRenderingOrder();
        java.awt.Stroke stroke49 = categoryPlot43.getRangeZeroBaselineStroke();
        categoryPlot33.setRangeMinorGridlineStroke(stroke49);
        org.jfree.chart.axis.CategoryAxis categoryAxis52 = categoryPlot33.getDomainAxis(100);
        boolean boolean53 = categoryPlot33.isNotify();
        org.jfree.chart.entity.PlotEntity plotEntity55 = new org.jfree.chart.entity.PlotEntity(shape32, (org.jfree.chart.plot.Plot) categoryPlot33, "ItemLabelAnchor.OUTSIDE1");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset58 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity61 = new org.jfree.chart.entity.CategoryItemEntity(shape32, "PlotOrientation.VERTICAL", "PlotOrientation.VERTICAL", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset58, (java.lang.Comparable) 10, (java.lang.Comparable) 'a');
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset64 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset64.clear();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity68 = new org.jfree.chart.entity.CategoryItemEntity(shape32, "AxisLocation.BOTTOM_OR_LEFT", "ItemLabelAnchor.OUTSIDE2", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset64, (java.lang.Comparable) 7.0d, (java.lang.Comparable) "PlotOrientation.VERTICAL");
        categoryPlot12.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset64);
        org.jfree.chart.plot.CategoryMarker categoryMarker71 = null;
        org.jfree.chart.util.Layer layer72 = null;
        try {
            categoryPlot12.addDomainMarker(0, categoryMarker71, layer72);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNull(comparable16);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(legendItemCollection21);
        org.junit.Assert.assertNotNull(categoryItemRendererState25);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNull(valueAxis36);
        org.junit.Assert.assertNotNull(categoryAnchor42);
        org.junit.Assert.assertNull(valueAxis46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 15 + "'", int47 == 15);
        org.junit.Assert.assertNotNull(sortOrder48);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNull(categoryAxis52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test207");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape1 = defaultDrawingSupplier0.getNextShape();
        java.awt.Stroke stroke2 = defaultDrawingSupplier0.getNextStroke();
        java.awt.Paint paint3 = defaultDrawingSupplier0.getNextPaint();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test208");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape0, "ChartChangeEventType.GENERAL", "");
        java.awt.Shape shape4 = chartEntity3.getArea();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot5.getRangeAxis();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier9 = categoryPlot5.getDrawingSupplier();
        org.jfree.data.category.CategoryDataset categoryDataset10 = categoryPlot5.getDataset();
        org.jfree.chart.renderer.RenderAttributes renderAttributes11 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        renderAttributes11.setDefaultFillPaint((java.awt.Paint) color12);
        categoryPlot5.setBackgroundPaint((java.awt.Paint) color12);
        org.jfree.chart.axis.ValueAxis valueAxis15 = categoryPlot5.getRangeAxis();
        org.jfree.chart.entity.PlotEntity plotEntity18 = new org.jfree.chart.entity.PlotEntity(shape4, (org.jfree.chart.plot.Plot) categoryPlot5, "ChartChangeEventType.GENERAL", "hi!");
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = categoryPlot5.getRangeAxisEdge();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertNotNull(drawingSupplier9);
        org.junit.Assert.assertNull(categoryDataset10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNull(valueAxis15);
        org.junit.Assert.assertNotNull(rectangleEdge19);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test209");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.util.SortOrder sortOrder5 = categoryPlot0.getRowRenderingOrder();
        java.awt.Stroke stroke6 = categoryPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent7 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent7);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot9.setRangeAxisLocation(axisLocation10, true);
        categoryPlot0.setDomainAxisLocation(axisLocation10);
        categoryPlot0.setCrosshairDatasetIndex((int) (short) 1);
        org.jfree.data.category.CategoryDataset categoryDataset16 = categoryPlot0.getDataset();
        org.jfree.chart.util.SortOrder sortOrder17 = categoryPlot0.getColumnRenderingOrder();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(sortOrder5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNull(categoryDataset16);
        org.junit.Assert.assertNotNull(sortOrder17);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test210");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomDomainAxes((double) 10.0f, plotRenderingInfo5, point2D6, false);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent9 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot0);
        org.jfree.chart.JFreeChart jFreeChart10 = null;
        plotChangeEvent9.setChart(jFreeChart10);
        java.lang.Object obj12 = plotChangeEvent9.getSource();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(obj12);
    }
}

