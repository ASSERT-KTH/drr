import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 1900);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Calendar calendar4 = null;
        fixedMillisecond1.peg(calendar4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Object obj8 = null;
        boolean boolean9 = fixedMillisecond7.equals(obj8);
        java.util.Date date10 = fixedMillisecond7.getStart();
        boolean boolean11 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) calendar4, (java.lang.Object) date10);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date10);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Object obj2 = null;
        boolean boolean3 = fixedMillisecond1.equals(obj2);
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass9 = fixedMillisecond8.getClass();
        java.lang.Object obj10 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ClassContext", (java.lang.Class) wildcardClass9);
        java.net.URL uRL11 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", (java.lang.Class) wildcardClass9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass16 = fixedMillisecond15.getClass();
        java.lang.Object obj17 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ClassContext", (java.lang.Class) wildcardClass16);
        java.net.URL uRL18 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", (java.lang.Class) wildcardClass16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Object obj21 = null;
        boolean boolean22 = fixedMillisecond20.equals(obj21);
        java.util.Date date23 = fixedMillisecond20.getStart();
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance(date23);
        java.util.TimeZone timeZone25 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date23, timeZone25);
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Object obj29 = null;
        boolean boolean30 = fixedMillisecond28.equals(obj29);
        java.util.Date date31 = fixedMillisecond28.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass36 = fixedMillisecond35.getClass();
        java.lang.Object obj37 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ClassContext", (java.lang.Class) wildcardClass36);
        java.net.URL uRL38 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", (java.lang.Class) wildcardClass36);
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Object obj41 = null;
        boolean boolean42 = fixedMillisecond40.equals(obj41);
        java.util.Date date43 = fixedMillisecond40.getStart();
        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.createInstance(date43);
        java.util.TimeZone timeZone45 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date43, timeZone45);
        java.lang.ClassLoader classLoader47 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass36);
        org.jfree.data.time.FixedMillisecond fixedMillisecond51 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass52 = fixedMillisecond51.getClass();
        java.lang.Object obj53 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ClassContext", (java.lang.Class) wildcardClass52);
        java.net.URL uRL54 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", (java.lang.Class) wildcardClass52);
        org.jfree.data.time.FixedMillisecond fixedMillisecond56 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Object obj57 = null;
        boolean boolean58 = fixedMillisecond56.equals(obj57);
        java.util.Date date59 = fixedMillisecond56.getStart();
        org.jfree.data.time.SerialDate serialDate60 = org.jfree.data.time.SerialDate.createInstance(date59);
        java.util.TimeZone timeZone61 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass52, date59, timeZone61);
        org.jfree.data.time.FixedMillisecond fixedMillisecond64 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar65 = null;
        long long66 = fixedMillisecond64.getMiddleMillisecond(calendar65);
        java.util.Date date67 = fixedMillisecond64.getTime();
        org.jfree.data.time.SerialDate serialDate68 = org.jfree.data.time.SerialDate.createInstance(date67);
        org.jfree.data.time.FixedMillisecond fixedMillisecond70 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar71 = null;
        long long72 = fixedMillisecond70.getMiddleMillisecond(calendar71);
        java.util.Date date73 = fixedMillisecond70.getTime();
        org.jfree.data.time.Year year74 = new org.jfree.data.time.Year(date73);
        long long75 = year74.getLastMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond79 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass80 = fixedMillisecond79.getClass();
        java.lang.Object obj81 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ClassContext", (java.lang.Class) wildcardClass80);
        java.net.URL uRL82 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", (java.lang.Class) wildcardClass80);
        int int83 = year74.compareTo((java.lang.Object) wildcardClass80);
        org.jfree.data.time.TimeSeries timeSeries84 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date67, (java.lang.Class) wildcardClass80);
        java.util.TimeZone timeZone85 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day86 = new org.jfree.data.time.Day(date67, timeZone85);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod87 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date59, timeZone85);
        org.jfree.data.time.Year year88 = new org.jfree.data.time.Year(date31, timeZone85);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod89 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date23, timeZone85);
        org.jfree.data.time.Day day90 = new org.jfree.data.time.Day(date4, timeZone85);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNull(obj10);
        org.junit.Assert.assertNotNull(uRL11);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNull(obj17);
        org.junit.Assert.assertNotNull(uRL18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNull(obj37);
        org.junit.Assert.assertNotNull(uRL38);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNull(regularTimePeriod46);
        org.junit.Assert.assertNotNull(classLoader47);
        org.junit.Assert.assertNotNull(wildcardClass52);
        org.junit.Assert.assertNull(obj53);
        org.junit.Assert.assertNotNull(uRL54);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertNotNull(serialDate60);
        org.junit.Assert.assertNull(regularTimePeriod62);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 100L + "'", long66 == 100L);
        org.junit.Assert.assertNotNull(date67);
        org.junit.Assert.assertNotNull(serialDate68);
        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 100L + "'", long72 == 100L);
        org.junit.Assert.assertNotNull(date73);
        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 28799999L + "'", long75 == 28799999L);
        org.junit.Assert.assertNotNull(wildcardClass80);
        org.junit.Assert.assertNull(obj81);
        org.junit.Assert.assertNotNull(uRL82);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 1 + "'", int83 == 1);
        org.junit.Assert.assertNotNull(timeZone85);
        org.junit.Assert.assertNull(regularTimePeriod87);
        org.junit.Assert.assertNull(regularTimePeriod89);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        int int2 = spreadsheetDate1.getMonth();
        int int3 = spreadsheetDate1.getDayOfWeek();
        java.util.Date date4 = spreadsheetDate1.toDate();
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance((int) (short) 10);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addDays((int) ' ', serialDate8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Object obj12 = null;
        boolean boolean13 = fixedMillisecond11.equals(obj12);
        java.util.Date date14 = fixedMillisecond11.getStart();
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance(date14);
        org.jfree.data.time.SerialDate serialDate16 = serialDate9.getEndOfCurrentMonth(serialDate15);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate16);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(3);
        int int20 = spreadsheetDate19.getMonth();
        int int21 = spreadsheetDate19.toSerial();
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance((int) (short) 10);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.addDays((int) ' ', serialDate24);
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Object obj28 = null;
        boolean boolean29 = fixedMillisecond27.equals(obj28);
        java.util.Date date30 = fixedMillisecond27.getStart();
        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.createInstance(date30);
        org.jfree.data.time.SerialDate serialDate32 = serialDate25.getEndOfCurrentMonth(serialDate31);
        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar37 = null;
        long long38 = fixedMillisecond36.getMiddleMillisecond(calendar37);
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Object obj41 = null;
        boolean boolean42 = fixedMillisecond40.equals(obj41);
        java.util.Date date43 = fixedMillisecond40.getStart();
        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.createInstance(date43);
        int int45 = fixedMillisecond36.compareTo((java.lang.Object) serialDate44);
        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(7, serialDate44);
        org.jfree.data.time.SerialDate serialDate47 = org.jfree.data.time.SerialDate.addMonths(12, serialDate44);
        boolean boolean49 = spreadsheetDate19.isInRange(serialDate31, serialDate47, 11);
        boolean boolean50 = spreadsheetDate1.isInRange(serialDate16, serialDate47);
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(serialDate16);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 3 + "'", int21 == 3);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 100L + "'", long38 == 100L);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass2 = fixedMillisecond1.getClass();
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, class3);
        timeSeries4.setDescription("31-December-1969");
        java.lang.Class class7 = timeSeries4.getTimePeriodClass();
        timeSeries4.removeAgedItems(true);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar12 = null;
        long long13 = fixedMillisecond11.getMiddleMillisecond(calendar12);
        java.util.Date date14 = fixedMillisecond11.getTime();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date14);
        long long16 = year15.getLastMillisecond();
        long long17 = year15.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year15.next();
        try {
            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) year15, (double) (-2193192000001L), true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 100L + "'", long13 == 100L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 28799999L + "'", long16 == 28799999L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-31507200000L) + "'", long17 == (-31507200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod18);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Object obj6 = null;
        boolean boolean7 = fixedMillisecond5.equals(obj6);
        java.util.Date date8 = fixedMillisecond5.getStart();
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date8);
        int int10 = fixedMillisecond1.compareTo((java.lang.Object) serialDate9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond1.next();
        java.util.Date date12 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date12);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (double) 1.0f);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        int int2 = spreadsheetDate1.getMonth();
        int int3 = spreadsheetDate1.toSerial();
        try {
            org.jfree.data.time.SerialDate serialDate5 = spreadsheetDate1.getPreviousDayOfWeek(1900);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass2 = fixedMillisecond1.getClass();
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond6.getMiddleMillisecond(calendar7);
        java.util.Date date9 = fixedMillisecond6.getTime();
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond6.getFirstMillisecond(calendar10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 10.0f);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond6);
        java.lang.Object obj15 = timeSeries14.clone();
        timeSeries14.setDomainDescription("First");
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(obj15);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass2 = fixedMillisecond1.getClass();
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, class3);
        java.lang.Comparable comparable5 = timeSeries4.getKey();
        boolean boolean6 = timeSeries4.getNotify();
        timeSeries4.removeAgedItems(false);
        java.lang.String str9 = timeSeries4.getRangeDescription();
        boolean boolean10 = timeSeries4.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.createCopy((int) (short) 0, (int) (byte) 100);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(comparable5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Value" + "'", str9.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(timeSeries13);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance((int) (short) 10);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addDays((int) ' ', serialDate4);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate5);
        try {
            org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(30, serialDate5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
    }

//    @Test
//    public void test012() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test012");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.previous();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(100L);
//        java.lang.Class<?> wildcardClass11 = fixedMillisecond10.getClass();
//        java.lang.ClassLoader classLoader12 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass11);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(100L);
//        java.util.Calendar calendar15 = null;
//        long long16 = fixedMillisecond14.getMiddleMillisecond(calendar15);
//        java.util.Date date17 = fixedMillisecond14.getTime();
//        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date17, timeZone18);
//        java.io.InputStream inputStream20 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass11);
//        java.io.InputStream inputStream21 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("org.jfree.data.general.SeriesChangeEvent[source=7]", (java.lang.Class) wildcardClass11);
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod4, "org.jfree.data.general.SeriesChangeEvent[source=7]", "org.jfree.data.general.SeriesChangeEvent[source=7]", (java.lang.Class) wildcardClass11);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(100L);
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond24.getMiddleMillisecond(calendar25);
//        java.util.Date date27 = fixedMillisecond24.getTime();
//        java.util.Calendar calendar28 = null;
//        long long29 = fixedMillisecond24.getFirstMillisecond(calendar28);
//        java.util.Calendar calendar30 = null;
//        fixedMillisecond24.peg(calendar30);
//        long long32 = fixedMillisecond24.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries22.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond(100L);
//        java.lang.Class<?> wildcardClass36 = fixedMillisecond35.getClass();
//        java.lang.Class class37 = null;
//        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond35, class37);
//        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries22.addAndOrUpdate(timeSeries38);
//        java.util.List list40 = timeSeries39.getItems();
//        java.util.Collection collection41 = timeSeries39.getTimePeriods();
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond(100L);
//        java.lang.Class<?> wildcardClass47 = fixedMillisecond46.getClass();
//        java.lang.Object obj48 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ClassContext", (java.lang.Class) wildcardClass47);
//        java.net.URL uRL49 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", (java.lang.Class) wildcardClass47);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond51 = new org.jfree.data.time.FixedMillisecond(100L);
//        java.lang.Object obj52 = null;
//        boolean boolean53 = fixedMillisecond51.equals(obj52);
//        java.util.Date date54 = fixedMillisecond51.getStart();
//        org.jfree.data.time.SerialDate serialDate55 = org.jfree.data.time.SerialDate.createInstance(date54);
//        java.util.TimeZone timeZone56 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass47, date54, timeZone56);
//        int int58 = day42.compareTo((java.lang.Object) date54);
//        long long59 = day42.getSerialIndex();
//        long long60 = day42.getFirstMillisecond();
//        java.lang.Number number61 = null;
//        try {
//            timeSeries39.add((org.jfree.data.time.RegularTimePeriod) day42, number61, false);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNotNull(classLoader12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 100L + "'", long16 == 100L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(timeZone18);
//        org.junit.Assert.assertNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(inputStream20);
//        org.junit.Assert.assertNull(inputStream21);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 100L + "'", long26 == 100L);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 100L + "'", long29 == 100L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 100L + "'", long32 == 100L);
//        org.junit.Assert.assertNull(timeSeriesDataItem33);
//        org.junit.Assert.assertNotNull(wildcardClass36);
//        org.junit.Assert.assertNotNull(timeSeries39);
//        org.junit.Assert.assertNotNull(list40);
//        org.junit.Assert.assertNotNull(collection41);
//        org.junit.Assert.assertNotNull(wildcardClass47);
//        org.junit.Assert.assertNull(obj48);
//        org.junit.Assert.assertNotNull(uRL49);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertNotNull(serialDate55);
//        org.junit.Assert.assertNull(regularTimePeriod57);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 43629L + "'", long59 == 43629L);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1560409200000L + "'", long60 == 1560409200000L);
//    }

//    @Test
//    public void test013() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test013");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
//        int int2 = spreadsheetDate1.getMonth();
//        int int3 = spreadsheetDate1.getMonth();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Object obj5 = null;
//        int int6 = day4.compareTo(obj5);
//        java.lang.String str7 = day4.toString();
//        org.jfree.data.time.SerialDate serialDate8 = day4.getSerialDate();
//        boolean boolean9 = spreadsheetDate1.isOn(serialDate8);
//        int int10 = spreadsheetDate1.toSerial();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "13-June-2019" + "'", str7.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 3 + "'", int10 == 3);
//    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(3);
        int int4 = spreadsheetDate3.getMonth();
        int int5 = spreadsheetDate3.getDayOfWeek();
        java.util.Date date6 = spreadsheetDate3.toDate();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addYears(0, (org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, (org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance((int) (short) 10);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addDays((int) ' ', serialDate11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Object obj15 = null;
        boolean boolean16 = fixedMillisecond14.equals(obj15);
        java.util.Date date17 = fixedMillisecond14.getStart();
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance(date17);
        org.jfree.data.time.SerialDate serialDate19 = serialDate12.getEndOfCurrentMonth(serialDate18);
        int int20 = spreadsheetDate3.compareTo((java.lang.Object) serialDate12);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-39) + "'", int20 == (-39));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Object obj2 = null;
        boolean boolean3 = fixedMillisecond1.equals(obj2);
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month1.previous();
        org.jfree.data.time.Year year3 = month1.getYear();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(11, year3);
        int int5 = month4.getMonth();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 11 + "'", int5 == 11);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond2.getMiddleMillisecond(calendar3);
        java.util.Date date5 = fixedMillisecond2.getTime();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        long long7 = year6.getLastMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass12 = fixedMillisecond11.getClass();
        java.lang.Object obj13 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ClassContext", (java.lang.Class) wildcardClass12);
        java.net.URL uRL14 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", (java.lang.Class) wildcardClass12);
        int int15 = year6.compareTo((java.lang.Object) wildcardClass12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year6.next();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month((int) (short) 10, year6);
        long long18 = month17.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 28799999L + "'", long7 == 28799999L);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNull(obj13);
        org.junit.Assert.assertNotNull(uRL14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-7923600000L) + "'", long18 == (-7923600000L));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass5 = fixedMillisecond4.getClass();
        java.lang.Object obj6 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ClassContext", (java.lang.Class) wildcardClass5);
        java.net.URL uRL7 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", (java.lang.Class) wildcardClass5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Object obj10 = null;
        boolean boolean11 = fixedMillisecond9.equals(obj10);
        java.util.Date date12 = fixedMillisecond9.getStart();
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance(date12);
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date12, timeZone14);
        java.net.URL uRL16 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("June 2019", (java.lang.Class) wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(obj6);
        org.junit.Assert.assertNotNull(uRL7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNull(uRL16);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getMiddleMillisecond(calendar8);
        java.util.Date date10 = fixedMillisecond7.getTime();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date10);
        long long12 = year11.getLastMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass17 = fixedMillisecond16.getClass();
        java.lang.Object obj18 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ClassContext", (java.lang.Class) wildcardClass17);
        java.net.URL uRL19 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", (java.lang.Class) wildcardClass17);
        int int20 = year11.compareTo((java.lang.Object) wildcardClass17);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass17);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener22 = null;
        timeSeries21.addChangeListener(seriesChangeListener22);
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timeSeries21.removePropertyChangeListener(propertyChangeListener24);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28799999L + "'", long12 == 28799999L);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNull(obj18);
        org.junit.Assert.assertNotNull(uRL19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass8 = fixedMillisecond7.getClass();
        java.lang.ClassLoader classLoader9 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar12 = null;
        long long13 = fixedMillisecond11.getMiddleMillisecond(calendar12);
        java.util.Date date14 = fixedMillisecond11.getTime();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date14, timeZone15);
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date14, timeZone17);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date4, timeZone17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass22 = fixedMillisecond21.getClass();
        java.lang.ClassLoader classLoader23 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass22);
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar26 = null;
        long long27 = fixedMillisecond25.getMiddleMillisecond(calendar26);
        java.util.Date date28 = fixedMillisecond25.getTime();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass22, date28, timeZone29);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date4, timeZone29);
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4);
        timeSeries32.clear();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(classLoader9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 100L + "'", long13 == 100L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(classLoader23);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 100L + "'", long27 == 100L);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNull(regularTimePeriod30);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(3);
        int int3 = spreadsheetDate2.getMonth();
        int int4 = spreadsheetDate2.getDayOfWeek();
        java.util.Date date5 = spreadsheetDate2.toDate();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addYears(0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        int int7 = spreadsheetDate2.getDayOfWeek();
        int int8 = spreadsheetDate2.toSerial();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass2 = fixedMillisecond1.getClass();
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond6.getMiddleMillisecond(calendar7);
        java.util.Date date9 = fixedMillisecond6.getTime();
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond6.getFirstMillisecond(calendar10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 10.0f);
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond6.getFirstMillisecond(calendar14);
        java.util.Calendar calendar16 = null;
        long long17 = fixedMillisecond6.getMiddleMillisecond(calendar16);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 100L + "'", long15 == 100L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 100L + "'", long17 == 100L);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass4 = fixedMillisecond3.getClass();
        java.lang.ClassLoader classLoader5 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass4);
        java.io.InputStream inputStream6 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("31-December-1969", (java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, (java.lang.Class) wildcardClass4);
        java.lang.Comparable comparable8 = timeSeries7.getKey();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries7.getDataItem((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(classLoader5);
        org.junit.Assert.assertNull(inputStream6);
        org.junit.Assert.assertNotNull(comparable8);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond1.getFirstMillisecond(calendar5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond1.next();
        long long8 = fixedMillisecond1.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
    }

//    @Test
//    public void test025() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test025");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
//        java.lang.Class<?> wildcardClass2 = fixedMillisecond1.getClass();
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, class3);
//        java.lang.Comparable comparable5 = timeSeries4.getKey();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(100L);
//        java.lang.Class<?> wildcardClass11 = fixedMillisecond10.getClass();
//        java.lang.Object obj12 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ClassContext", (java.lang.Class) wildcardClass11);
//        java.net.URL uRL13 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", (java.lang.Class) wildcardClass11);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(100L);
//        java.lang.Object obj16 = null;
//        boolean boolean17 = fixedMillisecond15.equals(obj16);
//        java.util.Date date18 = fixedMillisecond15.getStart();
//        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(date18);
//        java.util.TimeZone timeZone20 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date18, timeZone20);
//        int int22 = day6.compareTo((java.lang.Object) date18);
//        long long23 = day6.getSerialIndex();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond(100L);
//        java.util.Calendar calendar26 = null;
//        long long27 = fixedMillisecond25.getMiddleMillisecond(calendar26);
//        java.util.Date date28 = fixedMillisecond25.getTime();
//        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date28);
//        long long30 = year29.getLastMillisecond();
//        long long31 = year29.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) day6, (org.jfree.data.time.RegularTimePeriod) year29);
//        java.beans.PropertyChangeListener propertyChangeListener33 = null;
//        timeSeries4.addPropertyChangeListener(propertyChangeListener33);
//        java.lang.Comparable comparable35 = timeSeries4.getKey();
//        java.beans.PropertyChangeListener propertyChangeListener36 = null;
//        timeSeries4.addPropertyChangeListener(propertyChangeListener36);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(comparable5);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNull(obj12);
//        org.junit.Assert.assertNotNull(uRL13);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 43629L + "'", long23 == 43629L);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 100L + "'", long27 == 100L);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 28799999L + "'", long30 == 28799999L);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-31507200000L) + "'", long31 == (-31507200000L));
//        org.junit.Assert.assertNotNull(timeSeries32);
//        org.junit.Assert.assertNotNull(comparable35);
//    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("10-February-1900");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass2 = fixedMillisecond1.getClass();
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, class3);
        timeSeries4.setDescription("31-December-1969");
        java.lang.Class class7 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getMiddleMillisecond(calendar10);
        java.util.Date date12 = fixedMillisecond9.getTime();
        java.util.Calendar calendar13 = null;
        fixedMillisecond9.peg(calendar13);
        int int15 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar18 = null;
        long long19 = fixedMillisecond17.getMiddleMillisecond(calendar18);
        java.util.Date date20 = fixedMillisecond17.getTime();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        long long22 = year21.getLastMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass27 = fixedMillisecond26.getClass();
        java.lang.Object obj28 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ClassContext", (java.lang.Class) wildcardClass27);
        java.net.URL uRL29 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", (java.lang.Class) wildcardClass27);
        int int30 = year21.compareTo((java.lang.Object) wildcardClass27);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year21.next();
        long long32 = year21.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) year21);
        java.util.Collection collection34 = timeSeries4.getTimePeriods();
        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar37 = null;
        long long38 = fixedMillisecond36.getMiddleMillisecond(calendar37);
        java.util.Date date39 = fixedMillisecond36.getTime();
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year(date39);
        long long41 = year40.getLastMillisecond();
        long long42 = year40.getFirstMillisecond();
        int int44 = year40.compareTo((java.lang.Object) '4');
        try {
            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) year40, (java.lang.Number) 1.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 100L + "'", long19 == 100L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 28799999L + "'", long22 == 28799999L);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNull(obj28);
        org.junit.Assert.assertNotNull(uRL29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 28799999L + "'", long32 == 28799999L);
        org.junit.Assert.assertNull(timeSeriesDataItem33);
        org.junit.Assert.assertNotNull(collection34);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 100L + "'", long38 == 100L);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 28799999L + "'", long41 == 28799999L);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-31507200000L) + "'", long42 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass11 = fixedMillisecond10.getClass();
        java.lang.ClassLoader classLoader12 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond14.getMiddleMillisecond(calendar15);
        java.util.Date date17 = fixedMillisecond14.getTime();
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date17, timeZone18);
        java.io.InputStream inputStream20 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass11);
        java.io.InputStream inputStream21 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("org.jfree.data.general.SeriesChangeEvent[source=7]", (java.lang.Class) wildcardClass11);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod4, "org.jfree.data.general.SeriesChangeEvent[source=7]", "org.jfree.data.general.SeriesChangeEvent[source=7]", (java.lang.Class) wildcardClass11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond24.getMiddleMillisecond(calendar25);
        java.util.Date date27 = fixedMillisecond24.getTime();
        java.util.Calendar calendar28 = null;
        long long29 = fixedMillisecond24.getFirstMillisecond(calendar28);
        java.util.Calendar calendar30 = null;
        fixedMillisecond24.peg(calendar30);
        long long32 = fixedMillisecond24.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries22.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass36 = fixedMillisecond35.getClass();
        java.lang.Class class37 = null;
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond35, class37);
        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries22.addAndOrUpdate(timeSeries38);
        java.lang.Class class40 = timeSeries39.getTimePeriodClass();
        boolean boolean41 = timeSeries39.isEmpty();
        java.lang.Class class42 = timeSeries39.getTimePeriodClass();
        try {
            java.lang.Number number44 = timeSeries39.getValue(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(classLoader12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 100L + "'", long16 == 100L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(inputStream20);
        org.junit.Assert.assertNull(inputStream21);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 100L + "'", long26 == 100L);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 100L + "'", long29 == 100L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 100L + "'", long32 == 100L);
        org.junit.Assert.assertNull(timeSeriesDataItem33);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNotNull(timeSeries39);
        org.junit.Assert.assertNull(class40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNull(class42);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        long long6 = year5.getLastMillisecond();
        int int7 = year5.getYear();
        int int8 = year5.getYear();
        java.lang.String str9 = year5.toString();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 28799999L + "'", long6 == 28799999L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1969 + "'", int7 == 1969);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1969" + "'", str9.equals("1969"));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getYear();
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0);
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries2.removePropertyChangeListener(propertyChangeListener3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond6.getMiddleMillisecond(calendar7);
        java.util.Date date9 = fixedMillisecond6.getTime();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date9);
        long long11 = year10.getLastMillisecond();
        long long12 = year10.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year10, (double) 100.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar17 = null;
        long long18 = fixedMillisecond16.getMiddleMillisecond(calendar17);
        java.util.Date date19 = fixedMillisecond16.getTime();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date19);
        long long21 = year20.getLastMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass26 = fixedMillisecond25.getClass();
        java.lang.Object obj27 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ClassContext", (java.lang.Class) wildcardClass26);
        java.net.URL uRL28 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", (java.lang.Class) wildcardClass26);
        int int29 = year20.compareTo((java.lang.Object) wildcardClass26);
        long long30 = year20.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year20, (double) 43629L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = timeSeriesDataItem32.getPeriod();
        int int34 = year10.compareTo((java.lang.Object) timeSeriesDataItem32);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28799999L + "'", long11 == 28799999L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1969L + "'", long12 == 1969L);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 100L + "'", long18 == 100L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 28799999L + "'", long21 == 28799999L);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNull(obj27);
        org.junit.Assert.assertNotNull(uRL28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 28799999L + "'", long30 == 28799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(3);
        int int3 = spreadsheetDate2.getMonth();
        int int4 = spreadsheetDate2.toSerial();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance((int) (short) 10);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addDays((int) ' ', serialDate7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Object obj11 = null;
        boolean boolean12 = fixedMillisecond10.equals(obj11);
        java.util.Date date13 = fixedMillisecond10.getStart();
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(date13);
        org.jfree.data.time.SerialDate serialDate15 = serialDate8.getEndOfCurrentMonth(serialDate14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar20 = null;
        long long21 = fixedMillisecond19.getMiddleMillisecond(calendar20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Object obj24 = null;
        boolean boolean25 = fixedMillisecond23.equals(obj24);
        java.util.Date date26 = fixedMillisecond23.getStart();
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance(date26);
        int int28 = fixedMillisecond19.compareTo((java.lang.Object) serialDate27);
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(7, serialDate27);
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.addMonths(12, serialDate27);
        boolean boolean32 = spreadsheetDate2.isInRange(serialDate14, serialDate30, 11);
        int int33 = spreadsheetDate2.getYYYY();
        try {
            org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (byte) 0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100L + "'", long21 == 100L);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1900 + "'", int33 == 1900);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(43629L);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass5 = fixedMillisecond4.getClass();
        java.lang.Object obj6 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ClassContext", (java.lang.Class) wildcardClass5);
        java.net.URL uRL7 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", (java.lang.Class) wildcardClass5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Object obj10 = null;
        boolean boolean11 = fixedMillisecond9.equals(obj10);
        java.util.Date date12 = fixedMillisecond9.getStart();
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance(date12);
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date12, timeZone14);
        int int16 = day0.compareTo((java.lang.Object) date12);
        int int17 = day0.getYear();
        java.lang.Object obj18 = null;
        boolean boolean19 = day0.equals(obj18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar22 = null;
        long long23 = fixedMillisecond21.getMiddleMillisecond(calendar22);
        java.util.Date date24 = fixedMillisecond21.getTime();
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance(date24);
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar28 = null;
        long long29 = fixedMillisecond27.getMiddleMillisecond(calendar28);
        java.util.Date date30 = fixedMillisecond27.getTime();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date30);
        long long32 = year31.getLastMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass37 = fixedMillisecond36.getClass();
        java.lang.Object obj38 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ClassContext", (java.lang.Class) wildcardClass37);
        java.net.URL uRL39 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", (java.lang.Class) wildcardClass37);
        int int40 = year31.compareTo((java.lang.Object) wildcardClass37);
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date24, (java.lang.Class) wildcardClass37);
        int int42 = timeSeries41.getMaximumItemCount();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener43 = null;
        timeSeries41.removeChangeListener(seriesChangeListener43);
        timeSeries41.setDomainDescription("ERROR : Relative To String");
        int int47 = day0.compareTo((java.lang.Object) timeSeries41);
        int int48 = day0.getMonth();
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(obj6);
        org.junit.Assert.assertNotNull(uRL7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 100L + "'", long23 == 100L);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 100L + "'", long29 == 100L);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 28799999L + "'", long32 == 28799999L);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertNull(obj38);
        org.junit.Assert.assertNotNull(uRL39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 2147483647 + "'", int42 == 2147483647);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 6 + "'", int48 == 6);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getMiddleMillisecond(calendar8);
        java.util.Date date10 = fixedMillisecond7.getTime();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date10);
        long long12 = year11.getLastMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass17 = fixedMillisecond16.getClass();
        java.lang.Object obj18 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ClassContext", (java.lang.Class) wildcardClass17);
        java.net.URL uRL19 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", (java.lang.Class) wildcardClass17);
        int int20 = year11.compareTo((java.lang.Object) wildcardClass17);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass17);
        int int22 = timeSeries21.getMaximumItemCount();
        timeSeries21.setDomainDescription("Tuesday");
        timeSeries21.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28799999L + "'", long12 == 28799999L);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNull(obj18);
        org.junit.Assert.assertNotNull(uRL19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2147483647 + "'", int22 == 2147483647);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(11, 6, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getMiddleMillisecond(calendar8);
        java.util.Date date10 = fixedMillisecond7.getTime();
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(date10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond13.getMiddleMillisecond(calendar14);
        java.util.Date date16 = fixedMillisecond13.getTime();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
        long long18 = year17.getLastMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass23 = fixedMillisecond22.getClass();
        java.lang.Object obj24 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ClassContext", (java.lang.Class) wildcardClass23);
        java.net.URL uRL25 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", (java.lang.Class) wildcardClass23);
        int int26 = year17.compareTo((java.lang.Object) wildcardClass23);
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date10, (java.lang.Class) wildcardClass23);
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date10, timeZone28);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(date4, timeZone28);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 100L + "'", long15 == 100L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 28799999L + "'", long18 == 28799999L);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNull(obj24);
        org.junit.Assert.assertNotNull(uRL25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(timeZone28);
    }

//    @Test
//    public void test037() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test037");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(100L);
//        java.lang.Class<?> wildcardClass5 = fixedMillisecond4.getClass();
//        java.lang.Object obj6 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ClassContext", (java.lang.Class) wildcardClass5);
//        java.net.URL uRL7 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", (java.lang.Class) wildcardClass5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(100L);
//        java.lang.Object obj10 = null;
//        boolean boolean11 = fixedMillisecond9.equals(obj10);
//        java.util.Date date12 = fixedMillisecond9.getStart();
//        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance(date12);
//        java.util.TimeZone timeZone14 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date12, timeZone14);
//        int int16 = day0.compareTo((java.lang.Object) date12);
//        long long17 = day0.getSerialIndex();
//        long long18 = day0.getFirstMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(100L);
//        java.lang.Class<?> wildcardClass23 = fixedMillisecond22.getClass();
//        java.lang.Object obj24 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ClassContext", (java.lang.Class) wildcardClass23);
//        java.net.URL uRL25 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", (java.lang.Class) wildcardClass23);
//        int int26 = day0.compareTo((java.lang.Object) wildcardClass23);
//        java.lang.String str27 = day0.toString();
//        int int28 = day0.getMonth();
//        java.util.Date date29 = day0.getEnd();
//        java.util.Calendar calendar30 = null;
//        try {
//            day0.peg(calendar30);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNull(obj6);
//        org.junit.Assert.assertNotNull(uRL7);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 43629L + "'", long17 == 43629L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560409200000L + "'", long18 == 1560409200000L);
//        org.junit.Assert.assertNotNull(wildcardClass23);
//        org.junit.Assert.assertNull(obj24);
//        org.junit.Assert.assertNotNull(uRL25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "13-June-2019" + "'", str27.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 6 + "'", int28 == 6);
//        org.junit.Assert.assertNotNull(date29);
//    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        long long6 = year5.getLastMillisecond();
        long long7 = year5.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 12);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 28799999L + "'", long6 == 28799999L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-31507200000L) + "'", long7 == (-31507200000L));
    }

//    @Test
//    public void test039() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test039");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
//        int int2 = spreadsheetDate1.getMonth();
//        int int3 = spreadsheetDate1.getMonth();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.Object obj5 = null;
//        int int6 = day4.compareTo(obj5);
//        java.lang.String str7 = day4.toString();
//        org.jfree.data.time.SerialDate serialDate8 = day4.getSerialDate();
//        boolean boolean9 = spreadsheetDate1.isOn(serialDate8);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(3);
//        int int12 = spreadsheetDate11.getMonth();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(100L);
//        java.lang.Class<?> wildcardClass15 = fixedMillisecond14.getClass();
//        java.lang.ClassLoader classLoader16 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass15);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(100L);
//        java.util.Calendar calendar19 = null;
//        long long20 = fixedMillisecond18.getMiddleMillisecond(calendar19);
//        java.util.Date date21 = fixedMillisecond18.getTime();
//        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date21, timeZone22);
//        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance(date21);
//        boolean boolean25 = spreadsheetDate11.isOnOrBefore(serialDate24);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(3);
//        int int28 = spreadsheetDate27.getMonth();
//        int int29 = spreadsheetDate27.getDayOfWeek();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond(100L);
//        java.util.Calendar calendar33 = null;
//        long long34 = fixedMillisecond32.getMiddleMillisecond(calendar33);
//        java.util.Date date35 = fixedMillisecond32.getTime();
//        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.createInstance(date35);
//        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.addDays(28, serialDate36);
//        boolean boolean39 = spreadsheetDate11.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate27, serialDate37, (int) 'a');
//        int int40 = spreadsheetDate27.getMonth();
//        boolean boolean41 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate27);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "13-June-2019" + "'", str7.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertNotNull(classLoader16);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 100L + "'", long20 == 100L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(timeZone22);
//        org.junit.Assert.assertNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 3 + "'", int29 == 3);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 100L + "'", long34 == 100L);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertNotNull(serialDate37);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
//    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(3);
        int int3 = spreadsheetDate2.getMonth();
        int int4 = spreadsheetDate2.getMonth();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance((int) (short) 10);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addDays((int) ' ', serialDate7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Object obj11 = null;
        boolean boolean12 = fixedMillisecond10.equals(obj11);
        java.util.Date date13 = fixedMillisecond10.getStart();
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(date13);
        org.jfree.data.time.SerialDate serialDate15 = serialDate8.getEndOfCurrentMonth(serialDate14);
        java.lang.String str16 = serialDate8.getDescription();
        boolean boolean17 = spreadsheetDate2.isOnOrBefore(serialDate8);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.createInstance((int) (short) 10);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addDays((int) ' ', serialDate22);
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Object obj26 = null;
        boolean boolean27 = fixedMillisecond25.equals(obj26);
        java.util.Date date28 = fixedMillisecond25.getStart();
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.createInstance(date28);
        org.jfree.data.time.SerialDate serialDate30 = serialDate23.getEndOfCurrentMonth(serialDate29);
        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate30);
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.addDays((int) (short) 10, serialDate31);
        boolean boolean33 = spreadsheetDate2.isBefore(serialDate32);
        spreadsheetDate2.setDescription("Wed Dec 31 16:00:00 PST 1969");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(3);
        int int38 = spreadsheetDate37.getMonth();
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass41 = fixedMillisecond40.getClass();
        java.lang.ClassLoader classLoader42 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass41);
        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar45 = null;
        long long46 = fixedMillisecond44.getMiddleMillisecond(calendar45);
        java.util.Date date47 = fixedMillisecond44.getTime();
        java.util.TimeZone timeZone48 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass41, date47, timeZone48);
        org.jfree.data.time.SerialDate serialDate50 = org.jfree.data.time.SerialDate.createInstance(date47);
        boolean boolean51 = spreadsheetDate37.isOnOrBefore(serialDate50);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate53 = new org.jfree.data.time.SpreadsheetDate(3);
        int int54 = spreadsheetDate53.getMonth();
        int int55 = spreadsheetDate53.getDayOfWeek();
        org.jfree.data.time.FixedMillisecond fixedMillisecond58 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar59 = null;
        long long60 = fixedMillisecond58.getMiddleMillisecond(calendar59);
        java.util.Date date61 = fixedMillisecond58.getTime();
        org.jfree.data.time.SerialDate serialDate62 = org.jfree.data.time.SerialDate.createInstance(date61);
        org.jfree.data.time.SerialDate serialDate63 = org.jfree.data.time.SerialDate.addDays(28, serialDate62);
        boolean boolean65 = spreadsheetDate37.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate53, serialDate63, (int) 'a');
        int int66 = spreadsheetDate53.getMonth();
        int int67 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate53);
        try {
            org.jfree.data.time.SerialDate serialDate68 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(2958465, (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(wildcardClass41);
        org.junit.Assert.assertNotNull(classLoader42);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 100L + "'", long46 == 100L);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(timeZone48);
        org.junit.Assert.assertNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 3 + "'", int55 == 3);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 100L + "'", long60 == 100L);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertNotNull(serialDate62);
        org.junit.Assert.assertNotNull(serialDate63);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 1 + "'", int66 == 1);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass2 = fixedMillisecond1.getClass();
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, class3);
        java.lang.Comparable comparable5 = timeSeries4.getKey();
        boolean boolean6 = timeSeries4.getNotify();
        timeSeries4.removeAgedItems(false);
        java.lang.Comparable comparable9 = timeSeries4.getKey();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeries4);
        java.lang.String str11 = timeSeries4.getDescription();
        java.lang.String str12 = timeSeries4.getDomainDescription();
        long long13 = timeSeries4.getMaximumItemAge();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(comparable5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(comparable9);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Time" + "'", str12.equals("Time"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 9223372036854775807L + "'", long13 == 9223372036854775807L);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        int int2 = spreadsheetDate1.getMonth();
        int int3 = spreadsheetDate1.getDayOfWeek();
        java.util.Date date4 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(3);
        int int8 = spreadsheetDate7.getMonth();
        int int9 = spreadsheetDate7.getDayOfWeek();
        java.util.Date date10 = spreadsheetDate7.toDate();
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addYears(0, (org.jfree.data.time.SerialDate) spreadsheetDate7);
        int int12 = spreadsheetDate7.getYYYY();
        boolean boolean13 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate7);
        java.lang.String str14 = spreadsheetDate1.toString();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1900 + "'", int12 == 1900);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2-January-1900" + "'", str14.equals("2-January-1900"));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass2 = fixedMillisecond1.getClass();
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, class3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond6.getMiddleMillisecond(calendar7);
        java.util.Date date9 = fixedMillisecond6.getTime();
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond6.getFirstMillisecond(calendar10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 10.0f);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond6);
        java.lang.Object obj15 = timeSeries14.clone();
        boolean boolean16 = timeSeries14.getNotify();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = timeSeries14.getTimePeriod(2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2019, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Object obj6 = null;
        boolean boolean7 = fixedMillisecond5.equals(obj6);
        java.util.Date date8 = fixedMillisecond5.getStart();
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date8);
        int int10 = fixedMillisecond1.compareTo((java.lang.Object) serialDate9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond1.previous();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        java.lang.Object obj15 = null;
        int int16 = day14.compareTo(obj15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass19 = fixedMillisecond18.getClass();
        java.lang.ClassLoader classLoader20 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass19);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar23 = null;
        long long24 = fixedMillisecond22.getMiddleMillisecond(calendar23);
        java.util.Date date25 = fixedMillisecond22.getTime();
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date25, timeZone26);
        boolean boolean28 = day14.equals((java.lang.Object) date25);
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass36 = fixedMillisecond35.getClass();
        java.lang.ClassLoader classLoader37 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass36);
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar40 = null;
        long long41 = fixedMillisecond39.getMiddleMillisecond(calendar40);
        java.util.Date date42 = fixedMillisecond39.getTime();
        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date42, timeZone43);
        java.io.InputStream inputStream45 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass36);
        java.io.InputStream inputStream46 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("org.jfree.data.general.SeriesChangeEvent[source=7]", (java.lang.Class) wildcardClass36);
        java.io.InputStream inputStream47 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("June", (java.lang.Class) wildcardClass36);
        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean28, "Sunday", "Second", (java.lang.Class) wildcardClass36);
        java.net.URL uRL49 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", (java.lang.Class) wildcardClass36);
        java.lang.Class class50 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass36);
        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass55 = fixedMillisecond54.getClass();
        java.lang.Object obj56 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ClassContext", (java.lang.Class) wildcardClass55);
        java.net.URL uRL57 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", (java.lang.Class) wildcardClass55);
        java.lang.Object obj58 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("June 2019", (java.lang.Class) wildcardClass36, (java.lang.Class) wildcardClass55);
        org.jfree.data.time.TimeSeries timeSeries59 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod11, (java.lang.Class) wildcardClass36);
        int int60 = timeSeries59.getItemCount();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(classLoader20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 100L + "'", long24 == 100L);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNotNull(classLoader37);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 100L + "'", long41 == 100L);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(timeZone43);
        org.junit.Assert.assertNull(regularTimePeriod44);
        org.junit.Assert.assertNotNull(inputStream45);
        org.junit.Assert.assertNull(inputStream46);
        org.junit.Assert.assertNull(inputStream47);
        org.junit.Assert.assertNull(uRL49);
        org.junit.Assert.assertNotNull(class50);
        org.junit.Assert.assertNotNull(wildcardClass55);
        org.junit.Assert.assertNull(obj56);
        org.junit.Assert.assertNotNull(uRL57);
        org.junit.Assert.assertNull(obj58);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        int int2 = spreadsheetDate1.getMonth();
        int int3 = spreadsheetDate1.toSerial();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) (short) 10);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addDays((int) ' ', serialDate6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Object obj10 = null;
        boolean boolean11 = fixedMillisecond9.equals(obj10);
        java.util.Date date12 = fixedMillisecond9.getStart();
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance(date12);
        org.jfree.data.time.SerialDate serialDate14 = serialDate7.getEndOfCurrentMonth(serialDate13);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond18.getMiddleMillisecond(calendar19);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Object obj23 = null;
        boolean boolean24 = fixedMillisecond22.equals(obj23);
        java.util.Date date25 = fixedMillisecond22.getStart();
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.createInstance(date25);
        int int27 = fixedMillisecond18.compareTo((java.lang.Object) serialDate26);
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(7, serialDate26);
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.addMonths(12, serialDate26);
        boolean boolean31 = spreadsheetDate1.isInRange(serialDate13, serialDate29, 11);
        int int32 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 100L + "'", long20 == 100L);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1900 + "'", int32 == 1900);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass5 = fixedMillisecond4.getClass();
        java.lang.Object obj6 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ClassContext", (java.lang.Class) wildcardClass5);
        java.net.URL uRL7 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", (java.lang.Class) wildcardClass5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Object obj10 = null;
        boolean boolean11 = fixedMillisecond9.equals(obj10);
        java.util.Date date12 = fixedMillisecond9.getStart();
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance(date12);
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date12, timeZone14);
        int int16 = day0.compareTo((java.lang.Object) date12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day0.next();
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(obj6);
        org.junit.Assert.assertNotNull(uRL7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        long long6 = year5.getLastMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass11 = fixedMillisecond10.getClass();
        java.lang.Object obj12 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ClassContext", (java.lang.Class) wildcardClass11);
        java.net.URL uRL13 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", (java.lang.Class) wildcardClass11);
        int int14 = year5.compareTo((java.lang.Object) wildcardClass11);
        long long15 = year5.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) 43629L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = timeSeriesDataItem17.getPeriod();
        java.lang.Object obj19 = timeSeriesDataItem17.clone();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 28799999L + "'", long6 == 28799999L);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNull(obj12);
        org.junit.Assert.assertNotNull(uRL13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 28799999L + "'", long15 == 28799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(obj19);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass11 = fixedMillisecond10.getClass();
        java.lang.ClassLoader classLoader12 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond14.getMiddleMillisecond(calendar15);
        java.util.Date date17 = fixedMillisecond14.getTime();
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date17, timeZone18);
        java.io.InputStream inputStream20 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass11);
        java.io.InputStream inputStream21 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("org.jfree.data.general.SeriesChangeEvent[source=7]", (java.lang.Class) wildcardClass11);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod4, "org.jfree.data.general.SeriesChangeEvent[source=7]", "org.jfree.data.general.SeriesChangeEvent[source=7]", (java.lang.Class) wildcardClass11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond24.getMiddleMillisecond(calendar25);
        java.util.Date date27 = fixedMillisecond24.getTime();
        java.util.Calendar calendar28 = null;
        long long29 = fixedMillisecond24.getFirstMillisecond(calendar28);
        java.util.Calendar calendar30 = null;
        fixedMillisecond24.peg(calendar30);
        long long32 = fixedMillisecond24.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries22.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass36 = fixedMillisecond35.getClass();
        java.lang.Class class37 = null;
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond35, class37);
        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries22.addAndOrUpdate(timeSeries38);
        int int40 = timeSeries39.getMaximumItemCount();
        java.beans.PropertyChangeListener propertyChangeListener41 = null;
        timeSeries39.removePropertyChangeListener(propertyChangeListener41);
        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass47 = fixedMillisecond46.getClass();
        java.lang.Object obj48 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ClassContext", (java.lang.Class) wildcardClass47);
        java.net.URL uRL49 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", (java.lang.Class) wildcardClass47);
        org.jfree.data.time.FixedMillisecond fixedMillisecond51 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Object obj52 = null;
        boolean boolean53 = fixedMillisecond51.equals(obj52);
        java.util.Date date54 = fixedMillisecond51.getStart();
        org.jfree.data.time.SerialDate serialDate55 = org.jfree.data.time.SerialDate.createInstance(date54);
        java.util.TimeZone timeZone56 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass47, date54, timeZone56);
        java.lang.ClassLoader classLoader58 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass47);
        org.jfree.data.time.FixedMillisecond fixedMillisecond62 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass63 = fixedMillisecond62.getClass();
        java.lang.Object obj64 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ClassContext", (java.lang.Class) wildcardClass63);
        java.net.URL uRL65 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", (java.lang.Class) wildcardClass63);
        org.jfree.data.time.FixedMillisecond fixedMillisecond67 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Object obj68 = null;
        boolean boolean69 = fixedMillisecond67.equals(obj68);
        java.util.Date date70 = fixedMillisecond67.getStart();
        org.jfree.data.time.SerialDate serialDate71 = org.jfree.data.time.SerialDate.createInstance(date70);
        java.util.TimeZone timeZone72 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass63, date70, timeZone72);
        org.jfree.data.time.FixedMillisecond fixedMillisecond75 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar76 = null;
        long long77 = fixedMillisecond75.getMiddleMillisecond(calendar76);
        java.util.Date date78 = fixedMillisecond75.getTime();
        org.jfree.data.time.SerialDate serialDate79 = org.jfree.data.time.SerialDate.createInstance(date78);
        org.jfree.data.time.FixedMillisecond fixedMillisecond81 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar82 = null;
        long long83 = fixedMillisecond81.getMiddleMillisecond(calendar82);
        java.util.Date date84 = fixedMillisecond81.getTime();
        org.jfree.data.time.Year year85 = new org.jfree.data.time.Year(date84);
        long long86 = year85.getLastMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond90 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass91 = fixedMillisecond90.getClass();
        java.lang.Object obj92 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ClassContext", (java.lang.Class) wildcardClass91);
        java.net.URL uRL93 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", (java.lang.Class) wildcardClass91);
        int int94 = year85.compareTo((java.lang.Object) wildcardClass91);
        org.jfree.data.time.TimeSeries timeSeries95 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date78, (java.lang.Class) wildcardClass91);
        java.util.TimeZone timeZone96 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day97 = new org.jfree.data.time.Day(date78, timeZone96);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod98 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass47, date70, timeZone96);
        try {
            timeSeries39.setKey((java.lang.Comparable) regularTimePeriod98);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(classLoader12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 100L + "'", long16 == 100L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(inputStream20);
        org.junit.Assert.assertNull(inputStream21);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 100L + "'", long26 == 100L);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 100L + "'", long29 == 100L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 100L + "'", long32 == 100L);
        org.junit.Assert.assertNull(timeSeriesDataItem33);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNotNull(timeSeries39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2147483647 + "'", int40 == 2147483647);
        org.junit.Assert.assertNotNull(wildcardClass47);
        org.junit.Assert.assertNull(obj48);
        org.junit.Assert.assertNotNull(uRL49);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertNotNull(serialDate55);
        org.junit.Assert.assertNull(regularTimePeriod57);
        org.junit.Assert.assertNotNull(classLoader58);
        org.junit.Assert.assertNotNull(wildcardClass63);
        org.junit.Assert.assertNull(obj64);
        org.junit.Assert.assertNotNull(uRL65);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(date70);
        org.junit.Assert.assertNotNull(serialDate71);
        org.junit.Assert.assertNull(regularTimePeriod73);
        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 100L + "'", long77 == 100L);
        org.junit.Assert.assertNotNull(date78);
        org.junit.Assert.assertNotNull(serialDate79);
        org.junit.Assert.assertTrue("'" + long83 + "' != '" + 100L + "'", long83 == 100L);
        org.junit.Assert.assertNotNull(date84);
        org.junit.Assert.assertTrue("'" + long86 + "' != '" + 28799999L + "'", long86 == 28799999L);
        org.junit.Assert.assertNotNull(wildcardClass91);
        org.junit.Assert.assertNull(obj92);
        org.junit.Assert.assertNotNull(uRL93);
        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 1 + "'", int94 == 1);
        org.junit.Assert.assertNotNull(timeZone96);
        org.junit.Assert.assertNull(regularTimePeriod98);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getMiddleMillisecond(calendar8);
        java.util.Date date10 = fixedMillisecond7.getTime();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date10);
        long long12 = year11.getLastMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass17 = fixedMillisecond16.getClass();
        java.lang.Object obj18 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ClassContext", (java.lang.Class) wildcardClass17);
        java.net.URL uRL19 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", (java.lang.Class) wildcardClass17);
        int int20 = year11.compareTo((java.lang.Object) wildcardClass17);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass17);
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date4, timeZone22);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(date4);
        long long25 = fixedMillisecond24.getMiddleMillisecond();
        long long26 = fixedMillisecond24.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28799999L + "'", long12 == 28799999L);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNull(obj18);
        org.junit.Assert.assertNotNull(uRL19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 100L + "'", long25 == 100L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 100L + "'", long26 == 100L);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass8 = fixedMillisecond7.getClass();
        java.lang.ClassLoader classLoader9 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar12 = null;
        long long13 = fixedMillisecond11.getMiddleMillisecond(calendar12);
        java.util.Date date14 = fixedMillisecond11.getTime();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date14, timeZone15);
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date14, timeZone17);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date4, timeZone17);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(date4);
        long long21 = month20.getSerialIndex();
        java.util.Calendar calendar22 = null;
        try {
            long long23 = month20.getLastMillisecond(calendar22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(classLoader9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 100L + "'", long13 == 100L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 23640L + "'", long21 == 23640L);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) (short) 10);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addDays((int) ' ', serialDate2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Object obj6 = null;
        boolean boolean7 = fixedMillisecond5.equals(obj6);
        java.util.Date date8 = fixedMillisecond5.getStart();
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date8);
        org.jfree.data.time.SerialDate serialDate10 = serialDate3.getEndOfCurrentMonth(serialDate9);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance((int) (short) 10);
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.addDays((int) ' ', serialDate14);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate15);
        org.jfree.data.time.SerialDate serialDate17 = serialDate10.getEndOfCurrentMonth(serialDate16);
        try {
            org.jfree.data.time.SerialDate serialDate19 = serialDate17.getFollowingDayOfWeek(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate17);
    }

//    @Test
//    public void test052() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test052");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(100L);
//        java.lang.Class<?> wildcardClass5 = fixedMillisecond4.getClass();
//        java.lang.Object obj6 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ClassContext", (java.lang.Class) wildcardClass5);
//        java.net.URL uRL7 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", (java.lang.Class) wildcardClass5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(100L);
//        java.lang.Object obj10 = null;
//        boolean boolean11 = fixedMillisecond9.equals(obj10);
//        java.util.Date date12 = fixedMillisecond9.getStart();
//        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance(date12);
//        java.util.TimeZone timeZone14 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date12, timeZone14);
//        int int16 = day0.compareTo((java.lang.Object) date12);
//        long long17 = day0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day0.next();
//        int int20 = day0.compareTo((java.lang.Object) 7);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNull(obj6);
//        org.junit.Assert.assertNotNull(uRL7);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 43629L + "'", long17 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//    }

//    @Test
//    public void test053() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test053");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
//        java.lang.Class<?> wildcardClass2 = fixedMillisecond1.getClass();
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, class3);
//        java.lang.Comparable comparable5 = timeSeries4.getKey();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(100L);
//        java.lang.Class<?> wildcardClass11 = fixedMillisecond10.getClass();
//        java.lang.Object obj12 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ClassContext", (java.lang.Class) wildcardClass11);
//        java.net.URL uRL13 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", (java.lang.Class) wildcardClass11);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(100L);
//        java.lang.Object obj16 = null;
//        boolean boolean17 = fixedMillisecond15.equals(obj16);
//        java.util.Date date18 = fixedMillisecond15.getStart();
//        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(date18);
//        java.util.TimeZone timeZone20 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date18, timeZone20);
//        int int22 = day6.compareTo((java.lang.Object) date18);
//        long long23 = day6.getSerialIndex();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond(100L);
//        java.util.Calendar calendar26 = null;
//        long long27 = fixedMillisecond25.getMiddleMillisecond(calendar26);
//        java.util.Date date28 = fixedMillisecond25.getTime();
//        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date28);
//        long long30 = year29.getLastMillisecond();
//        long long31 = year29.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) day6, (org.jfree.data.time.RegularTimePeriod) year29);
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond(100L);
//        java.lang.Class<?> wildcardClass37 = fixedMillisecond36.getClass();
//        java.lang.ClassLoader classLoader38 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass37);
//        java.io.InputStream inputStream39 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("31-December-1969", (java.lang.Class) wildcardClass37);
//        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day33, (java.lang.Class) wildcardClass37);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) day33);
//        timeSeries4.clear();
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(comparable5);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNull(obj12);
//        org.junit.Assert.assertNotNull(uRL13);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 43629L + "'", long23 == 43629L);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 100L + "'", long27 == 100L);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 28799999L + "'", long30 == 28799999L);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-31507200000L) + "'", long31 == (-31507200000L));
//        org.junit.Assert.assertNotNull(timeSeries32);
//        org.junit.Assert.assertNotNull(wildcardClass37);
//        org.junit.Assert.assertNotNull(classLoader38);
//        org.junit.Assert.assertNull(inputStream39);
//        org.junit.Assert.assertNull(timeSeriesDataItem41);
//    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass2 = fixedMillisecond1.getClass();
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, class3);
        int int5 = timeSeries4.getMaximumItemCount();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass8 = fixedMillisecond7.getClass();
        java.lang.Class class9 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond7, class9);
        timeSeries10.setDescription("31-December-1969");
        long long13 = timeSeries10.getMaximumItemAge();
        java.util.Collection collection14 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass17 = fixedMillisecond16.getClass();
        java.lang.ClassLoader classLoader18 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar21 = null;
        long long22 = fixedMillisecond20.getMiddleMillisecond(calendar21);
        java.util.Date date23 = fixedMillisecond20.getTime();
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date23, timeZone24);
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date23, timeZone26);
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar30 = null;
        long long31 = fixedMillisecond29.getMiddleMillisecond(calendar30);
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Object obj34 = null;
        boolean boolean35 = fixedMillisecond33.equals(obj34);
        java.util.Date date36 = fixedMillisecond33.getStart();
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.createInstance(date36);
        int int38 = fixedMillisecond29.compareTo((java.lang.Object) serialDate37);
        int int39 = year27.compareTo((java.lang.Object) serialDate37);
        long long40 = year27.getLastMillisecond();
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) year27);
        timeSeries4.fireSeriesChanged();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 9223372036854775807L + "'", long13 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection14);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(classLoader18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 100L + "'", long22 == 100L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 100L + "'", long31 == 100L);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 28799999L + "'", long40 == 28799999L);
    }

//    @Test
//    public void test055() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test055");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
//        java.lang.Class<?> wildcardClass2 = fixedMillisecond1.getClass();
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, class3);
//        java.lang.Comparable comparable5 = timeSeries4.getKey();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(100L);
//        java.lang.Class<?> wildcardClass11 = fixedMillisecond10.getClass();
//        java.lang.Object obj12 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ClassContext", (java.lang.Class) wildcardClass11);
//        java.net.URL uRL13 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", (java.lang.Class) wildcardClass11);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(100L);
//        java.lang.Object obj16 = null;
//        boolean boolean17 = fixedMillisecond15.equals(obj16);
//        java.util.Date date18 = fixedMillisecond15.getStart();
//        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(date18);
//        java.util.TimeZone timeZone20 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date18, timeZone20);
//        int int22 = day6.compareTo((java.lang.Object) date18);
//        long long23 = day6.getSerialIndex();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond(100L);
//        java.util.Calendar calendar26 = null;
//        long long27 = fixedMillisecond25.getMiddleMillisecond(calendar26);
//        java.util.Date date28 = fixedMillisecond25.getTime();
//        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date28);
//        long long30 = year29.getLastMillisecond();
//        long long31 = year29.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) day6, (org.jfree.data.time.RegularTimePeriod) year29);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond(100L);
//        java.util.Calendar calendar35 = null;
//        long long36 = fixedMillisecond34.getMiddleMillisecond(calendar35);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = fixedMillisecond34.previous();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond(100L);
//        java.lang.Class<?> wildcardClass44 = fixedMillisecond43.getClass();
//        java.lang.ClassLoader classLoader45 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass44);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond(100L);
//        java.util.Calendar calendar48 = null;
//        long long49 = fixedMillisecond47.getMiddleMillisecond(calendar48);
//        java.util.Date date50 = fixedMillisecond47.getTime();
//        java.util.TimeZone timeZone51 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass44, date50, timeZone51);
//        java.io.InputStream inputStream53 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass44);
//        java.io.InputStream inputStream54 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("org.jfree.data.general.SeriesChangeEvent[source=7]", (java.lang.Class) wildcardClass44);
//        org.jfree.data.time.TimeSeries timeSeries55 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod37, "org.jfree.data.general.SeriesChangeEvent[source=7]", "org.jfree.data.general.SeriesChangeEvent[source=7]", (java.lang.Class) wildcardClass44);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond57 = new org.jfree.data.time.FixedMillisecond(100L);
//        java.util.Calendar calendar58 = null;
//        long long59 = fixedMillisecond57.getMiddleMillisecond(calendar58);
//        java.util.Date date60 = fixedMillisecond57.getTime();
//        java.util.Calendar calendar61 = null;
//        long long62 = fixedMillisecond57.getFirstMillisecond(calendar61);
//        java.util.Calendar calendar63 = null;
//        fixedMillisecond57.peg(calendar63);
//        long long65 = fixedMillisecond57.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem66 = timeSeries55.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond57);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond68 = new org.jfree.data.time.FixedMillisecond(100L);
//        java.lang.Class<?> wildcardClass69 = fixedMillisecond68.getClass();
//        java.lang.Class class70 = null;
//        org.jfree.data.time.TimeSeries timeSeries71 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond68, class70);
//        org.jfree.data.time.TimeSeries timeSeries72 = timeSeries55.addAndOrUpdate(timeSeries71);
//        java.util.List list73 = timeSeries72.getItems();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond75 = new org.jfree.data.time.FixedMillisecond((long) 0);
//        long long76 = fixedMillisecond75.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem78 = timeSeries72.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond75, (java.lang.Number) 3);
//        java.lang.Number number79 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond75);
//        java.util.Calendar calendar80 = null;
//        long long81 = fixedMillisecond75.getLastMillisecond(calendar80);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(comparable5);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNull(obj12);
//        org.junit.Assert.assertNotNull(uRL13);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 43629L + "'", long23 == 43629L);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 100L + "'", long27 == 100L);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 28799999L + "'", long30 == 28799999L);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-31507200000L) + "'", long31 == (-31507200000L));
//        org.junit.Assert.assertNotNull(timeSeries32);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 100L + "'", long36 == 100L);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertNotNull(wildcardClass44);
//        org.junit.Assert.assertNotNull(classLoader45);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 100L + "'", long49 == 100L);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertNotNull(timeZone51);
//        org.junit.Assert.assertNull(regularTimePeriod52);
//        org.junit.Assert.assertNotNull(inputStream53);
//        org.junit.Assert.assertNull(inputStream54);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 100L + "'", long59 == 100L);
//        org.junit.Assert.assertNotNull(date60);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 100L + "'", long62 == 100L);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 100L + "'", long65 == 100L);
//        org.junit.Assert.assertNull(timeSeriesDataItem66);
//        org.junit.Assert.assertNotNull(wildcardClass69);
//        org.junit.Assert.assertNotNull(timeSeries72);
//        org.junit.Assert.assertNotNull(list73);
//        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 0L + "'", long76 == 0L);
//        org.junit.Assert.assertNull(timeSeriesDataItem78);
//        org.junit.Assert.assertNull(number79);
//        org.junit.Assert.assertTrue("'" + long81 + "' != '" + 0L + "'", long81 == 0L);
//    }

//    @Test
//    public void test056() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test056");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(100L);
//        java.lang.Class<?> wildcardClass5 = fixedMillisecond4.getClass();
//        java.lang.Object obj6 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ClassContext", (java.lang.Class) wildcardClass5);
//        java.net.URL uRL7 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", (java.lang.Class) wildcardClass5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(100L);
//        java.lang.Object obj10 = null;
//        boolean boolean11 = fixedMillisecond9.equals(obj10);
//        java.util.Date date12 = fixedMillisecond9.getStart();
//        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance(date12);
//        java.util.TimeZone timeZone14 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date12, timeZone14);
//        int int16 = day0.compareTo((java.lang.Object) date12);
//        long long17 = day0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day0.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod18, (java.lang.Number) 2147483647);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(100L);
//        java.util.Calendar calendar23 = null;
//        long long24 = fixedMillisecond22.getMiddleMillisecond(calendar23);
//        java.util.Date date25 = fixedMillisecond22.getTime();
//        java.util.Calendar calendar26 = null;
//        long long27 = fixedMillisecond22.getFirstMillisecond(calendar26);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = fixedMillisecond22.next();
//        java.lang.String str29 = fixedMillisecond22.toString();
//        java.util.Calendar calendar30 = null;
//        fixedMillisecond22.peg(calendar30);
//        boolean boolean32 = timeSeriesDataItem20.equals((java.lang.Object) calendar30);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNull(obj6);
//        org.junit.Assert.assertNotNull(uRL7);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 43629L + "'", long17 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 100L + "'", long24 == 100L);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 100L + "'", long27 == 100L);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str29.equals("Wed Dec 31 16:00:00 PST 1969"));
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass2 = fixedMillisecond1.getClass();
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, class3);
        int int5 = timeSeries4.getMaximumItemCount();
        boolean boolean6 = timeSeries4.isEmpty();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getMiddleMillisecond(calendar8);
        java.util.Date date10 = fixedMillisecond7.getTime();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date10);
        long long12 = year11.getLastMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass17 = fixedMillisecond16.getClass();
        java.lang.Object obj18 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ClassContext", (java.lang.Class) wildcardClass17);
        java.net.URL uRL19 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", (java.lang.Class) wildcardClass17);
        int int20 = year11.compareTo((java.lang.Object) wildcardClass17);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass17);
        int int22 = timeSeries21.getMaximumItemCount();
        timeSeries21.setDomainDescription("Tuesday");
        timeSeries21.setMaximumItemCount(30);
        timeSeries21.fireSeriesChanged();
        java.util.Collection collection28 = timeSeries21.getTimePeriods();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28799999L + "'", long12 == 28799999L);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNull(obj18);
        org.junit.Assert.assertNotNull(uRL19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2147483647 + "'", int22 == 2147483647);
        org.junit.Assert.assertNotNull(collection28);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass2 = fixedMillisecond1.getClass();
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, class3);
        java.util.List list5 = timeSeries4.getItems();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(list5);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass2 = fixedMillisecond1.getClass();
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, class3);
        timeSeries4.setDescription("31-December-1969");
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass9 = fixedMillisecond8.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (double) 0);
        java.lang.Number number12 = timeSeriesDataItem11.getValue();
        timeSeries4.setKey((java.lang.Comparable) timeSeriesDataItem11);
        java.util.Collection collection14 = timeSeries4.getTimePeriods();
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass17 = fixedMillisecond16.getClass();
        java.lang.Class class18 = null;
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond16, class18);
        timeSeries19.setDescription("31-December-1969");
        java.lang.Class class22 = timeSeries19.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond24.getMiddleMillisecond(calendar25);
        java.util.Date date27 = fixedMillisecond24.getTime();
        java.util.Calendar calendar28 = null;
        fixedMillisecond24.peg(calendar28);
        int int30 = timeSeries19.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
        long long31 = fixedMillisecond24.getLastMillisecond();
        try {
            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (double) 1969L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 0.0d + "'", number12.equals(0.0d));
        org.junit.Assert.assertNotNull(collection14);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNull(class22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 100L + "'", long26 == 100L);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 100L + "'", long31 == 100L);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass11 = fixedMillisecond10.getClass();
        java.lang.ClassLoader classLoader12 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond14.getMiddleMillisecond(calendar15);
        java.util.Date date17 = fixedMillisecond14.getTime();
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date17, timeZone18);
        java.io.InputStream inputStream20 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass11);
        java.io.InputStream inputStream21 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("org.jfree.data.general.SeriesChangeEvent[source=7]", (java.lang.Class) wildcardClass11);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod4, "org.jfree.data.general.SeriesChangeEvent[source=7]", "org.jfree.data.general.SeriesChangeEvent[source=7]", (java.lang.Class) wildcardClass11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond24.getMiddleMillisecond(calendar25);
        java.util.Date date27 = fixedMillisecond24.getTime();
        java.util.Calendar calendar28 = null;
        long long29 = fixedMillisecond24.getFirstMillisecond(calendar28);
        java.util.Calendar calendar30 = null;
        fixedMillisecond24.peg(calendar30);
        long long32 = fixedMillisecond24.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries22.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass36 = fixedMillisecond35.getClass();
        java.lang.Class class37 = null;
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond35, class37);
        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries22.addAndOrUpdate(timeSeries38);
        timeSeries38.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=7]");
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(classLoader12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 100L + "'", long16 == 100L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(inputStream20);
        org.junit.Assert.assertNull(inputStream21);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 100L + "'", long26 == 100L);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 100L + "'", long29 == 100L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 100L + "'", long32 == 100L);
        org.junit.Assert.assertNull(timeSeriesDataItem33);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNotNull(timeSeries39);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        java.lang.Class class1 = null;
        java.lang.Class class2 = null;
        java.lang.Object obj3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("10-February-1900", class1, class2);
        org.junit.Assert.assertNull(obj3);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass11 = fixedMillisecond10.getClass();
        java.lang.ClassLoader classLoader12 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond14.getMiddleMillisecond(calendar15);
        java.util.Date date17 = fixedMillisecond14.getTime();
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date17, timeZone18);
        java.io.InputStream inputStream20 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass11);
        java.io.InputStream inputStream21 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("org.jfree.data.general.SeriesChangeEvent[source=7]", (java.lang.Class) wildcardClass11);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod4, "org.jfree.data.general.SeriesChangeEvent[source=7]", "org.jfree.data.general.SeriesChangeEvent[source=7]", (java.lang.Class) wildcardClass11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond24.getMiddleMillisecond(calendar25);
        java.util.Date date27 = fixedMillisecond24.getTime();
        java.util.Calendar calendar28 = null;
        long long29 = fixedMillisecond24.getFirstMillisecond(calendar28);
        java.util.Calendar calendar30 = null;
        fixedMillisecond24.peg(calendar30);
        long long32 = fixedMillisecond24.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries22.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass36 = fixedMillisecond35.getClass();
        java.lang.Class class37 = null;
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond35, class37);
        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries22.addAndOrUpdate(timeSeries38);
        java.lang.Class class40 = timeSeries39.getTimePeriodClass();
        boolean boolean41 = timeSeries39.isEmpty();
        timeSeries39.setDescription("1969");
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(classLoader12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 100L + "'", long16 == 100L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(inputStream20);
        org.junit.Assert.assertNull(inputStream21);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 100L + "'", long26 == 100L);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 100L + "'", long29 == 100L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 100L + "'", long32 == 100L);
        org.junit.Assert.assertNull(timeSeriesDataItem33);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNotNull(timeSeries39);
        org.junit.Assert.assertNull(class40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
    }

//    @Test
//    public void test064() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test064");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(100L);
//        java.lang.Class<?> wildcardClass5 = fixedMillisecond4.getClass();
//        java.lang.Object obj6 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ClassContext", (java.lang.Class) wildcardClass5);
//        java.net.URL uRL7 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", (java.lang.Class) wildcardClass5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(100L);
//        java.lang.Object obj10 = null;
//        boolean boolean11 = fixedMillisecond9.equals(obj10);
//        java.util.Date date12 = fixedMillisecond9.getStart();
//        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance(date12);
//        java.util.TimeZone timeZone14 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date12, timeZone14);
//        int int16 = day0.compareTo((java.lang.Object) date12);
//        long long17 = day0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day0.next();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(100L);
//        java.util.Calendar calendar23 = null;
//        long long24 = fixedMillisecond22.getMiddleMillisecond(calendar23);
//        java.util.Date date25 = fixedMillisecond22.getTime();
//        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.createInstance(date25);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond(100L);
//        java.util.Calendar calendar29 = null;
//        long long30 = fixedMillisecond28.getMiddleMillisecond(calendar29);
//        java.util.Date date31 = fixedMillisecond28.getTime();
//        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date31);
//        long long33 = year32.getLastMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond(100L);
//        java.lang.Class<?> wildcardClass38 = fixedMillisecond37.getClass();
//        java.lang.Object obj39 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ClassContext", (java.lang.Class) wildcardClass38);
//        java.net.URL uRL40 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", (java.lang.Class) wildcardClass38);
//        int int41 = year32.compareTo((java.lang.Object) wildcardClass38);
//        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date25, (java.lang.Class) wildcardClass38);
//        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "Tuesday", "org.jfree.data.general.SeriesChangeEvent[source=100]", (java.lang.Class) wildcardClass38);
//        timeSeries43.setDomainDescription("1969");
//        java.util.List list46 = timeSeries43.getItems();
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNull(obj6);
//        org.junit.Assert.assertNotNull(uRL7);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 43629L + "'", long17 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 100L + "'", long24 == 100L);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 100L + "'", long30 == 100L);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 28799999L + "'", long33 == 28799999L);
//        org.junit.Assert.assertNotNull(wildcardClass38);
//        org.junit.Assert.assertNull(obj39);
//        org.junit.Assert.assertNotNull(uRL40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
//        org.junit.Assert.assertNotNull(list46);
//    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass2 = fixedMillisecond1.getClass();
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, class3);
        timeSeries4.setDescription("31-December-1969");
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass9 = fixedMillisecond8.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (double) 0);
        java.lang.Number number12 = timeSeriesDataItem11.getValue();
        timeSeries4.setKey((java.lang.Comparable) timeSeriesDataItem11);
        java.util.Collection collection14 = timeSeries4.getTimePeriods();
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass17 = fixedMillisecond16.getClass();
        java.lang.Class class18 = null;
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond16, class18);
        java.lang.Comparable comparable20 = timeSeries19.getKey();
        boolean boolean21 = timeSeries19.getNotify();
        timeSeries19.removeAgedItems(false);
        java.lang.String str24 = timeSeries19.getRangeDescription();
        boolean boolean25 = timeSeries19.isEmpty();
        boolean boolean26 = timeSeries4.equals((java.lang.Object) timeSeries19);
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Object obj29 = null;
        boolean boolean30 = fixedMillisecond28.equals(obj29);
        java.util.Date date31 = fixedMillisecond28.getStart();
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(date31);
        long long33 = month32.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = month32.previous();
        boolean boolean35 = timeSeries19.equals((java.lang.Object) regularTimePeriod34);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 0.0d + "'", number12.equals(0.0d));
        org.junit.Assert.assertNotNull(collection14);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(comparable20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Value" + "'", str24.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 28799999L + "'", long33 == 28799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getMiddleMillisecond(calendar8);
        java.util.Date date10 = fixedMillisecond7.getTime();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date10);
        long long12 = year11.getLastMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass17 = fixedMillisecond16.getClass();
        java.lang.Object obj18 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ClassContext", (java.lang.Class) wildcardClass17);
        java.net.URL uRL19 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", (java.lang.Class) wildcardClass17);
        int int20 = year11.compareTo((java.lang.Object) wildcardClass17);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Object obj24 = null;
        boolean boolean25 = fixedMillisecond23.equals(obj24);
        java.util.Date date26 = fixedMillisecond23.getStart();
        timeSeries21.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, (java.lang.Number) 10L);
        java.util.List list29 = timeSeries21.getItems();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28799999L + "'", long12 == 28799999L);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNull(obj18);
        org.junit.Assert.assertNotNull(uRL19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(list29);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass11 = fixedMillisecond10.getClass();
        java.lang.ClassLoader classLoader12 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond14.getMiddleMillisecond(calendar15);
        java.util.Date date17 = fixedMillisecond14.getTime();
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date17, timeZone18);
        java.io.InputStream inputStream20 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass11);
        java.io.InputStream inputStream21 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("org.jfree.data.general.SeriesChangeEvent[source=7]", (java.lang.Class) wildcardClass11);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod4, "org.jfree.data.general.SeriesChangeEvent[source=7]", "org.jfree.data.general.SeriesChangeEvent[source=7]", (java.lang.Class) wildcardClass11);
        timeSeries22.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=100]");
        long long25 = timeSeries22.getMaximumItemAge();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(classLoader12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 100L + "'", long16 == 100L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(inputStream20);
        org.junit.Assert.assertNull(inputStream21);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 9223372036854775807L + "'", long25 == 9223372036854775807L);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        int int2 = spreadsheetDate1.getMonth();
        int int3 = spreadsheetDate1.getDayOfWeek();
        java.util.Date date4 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(3);
        int int8 = spreadsheetDate7.getMonth();
        int int9 = spreadsheetDate7.getDayOfWeek();
        java.util.Date date10 = spreadsheetDate7.toDate();
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addYears(0, (org.jfree.data.time.SerialDate) spreadsheetDate7);
        int int12 = spreadsheetDate7.getYYYY();
        boolean boolean13 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(3);
        int int18 = spreadsheetDate17.getMonth();
        int int19 = spreadsheetDate17.getDayOfWeek();
        java.util.Date date20 = spreadsheetDate17.toDate();
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addYears(0, (org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, (org.jfree.data.time.SerialDate) spreadsheetDate17);
        java.lang.Object obj23 = null;
        boolean boolean24 = spreadsheetDate17.equals(obj23);
        boolean boolean25 = spreadsheetDate7.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate17);
        int int26 = spreadsheetDate7.getDayOfWeek();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1900 + "'", int12 == 1900);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 3 + "'", int19 == 3);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 3 + "'", int26 == 3);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass2 = fixedMillisecond1.getClass();
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, class3);
        timeSeries4.setDescription("31-December-1969");
        java.lang.Class class7 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getMiddleMillisecond(calendar10);
        java.util.Date date12 = fixedMillisecond9.getTime();
        java.util.Calendar calendar13 = null;
        fixedMillisecond9.peg(calendar13);
        int int15 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        try {
            timeSeries4.update(10, (java.lang.Number) 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass4 = fixedMillisecond3.getClass();
        java.lang.ClassLoader classLoader5 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass4);
        java.io.InputStream inputStream6 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("31-December-1969", (java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, (java.lang.Class) wildcardClass4);
        java.lang.String str8 = timeSeries7.getRangeDescription();
        java.lang.Object obj9 = timeSeries7.clone();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(classLoader5);
        org.junit.Assert.assertNull(inputStream6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Value" + "'", str8.equals("Value"));
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass5 = fixedMillisecond4.getClass();
        java.lang.Object obj6 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ClassContext", (java.lang.Class) wildcardClass5);
        java.net.URL uRL7 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", (java.lang.Class) wildcardClass5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Object obj10 = null;
        boolean boolean11 = fixedMillisecond9.equals(obj10);
        java.util.Date date12 = fixedMillisecond9.getStart();
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance(date12);
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date12, timeZone14);
        java.lang.ClassLoader classLoader16 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass5);
        java.io.InputStream inputStream17 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", (java.lang.Class) wildcardClass5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar20 = null;
        long long21 = fixedMillisecond19.getMiddleMillisecond(calendar20);
        java.util.Date date22 = fixedMillisecond19.getTime();
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.createInstance(date22);
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar26 = null;
        long long27 = fixedMillisecond25.getMiddleMillisecond(calendar26);
        java.util.Date date28 = fixedMillisecond25.getTime();
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date28);
        long long30 = year29.getLastMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass35 = fixedMillisecond34.getClass();
        java.lang.Object obj36 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ClassContext", (java.lang.Class) wildcardClass35);
        java.net.URL uRL37 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", (java.lang.Class) wildcardClass35);
        int int38 = year29.compareTo((java.lang.Object) wildcardClass35);
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date22, (java.lang.Class) wildcardClass35);
        java.util.TimeZone timeZone40 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date22, timeZone40);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(obj6);
        org.junit.Assert.assertNotNull(uRL7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(classLoader16);
        org.junit.Assert.assertNotNull(inputStream17);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100L + "'", long21 == 100L);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 100L + "'", long27 == 100L);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 28799999L + "'", long30 == 28799999L);
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertNull(obj36);
        org.junit.Assert.assertNotNull(uRL37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNull(regularTimePeriod41);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Object obj6 = null;
        boolean boolean7 = fixedMillisecond5.equals(obj6);
        java.util.Date date8 = fixedMillisecond5.getStart();
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date8);
        int int10 = fixedMillisecond1.compareTo((java.lang.Object) serialDate9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond1.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond13.getMiddleMillisecond(calendar14);
        java.util.Date date16 = fixedMillisecond13.getTime();
        java.util.Calendar calendar17 = null;
        fixedMillisecond13.peg(calendar17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = fixedMillisecond13.next();
        int int20 = fixedMillisecond1.compareTo((java.lang.Object) fixedMillisecond13);
        long long21 = fixedMillisecond13.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 100L + "'", long15 == 100L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100L + "'", long21 == 100L);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) (short) 10);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addDays((int) ' ', serialDate2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Object obj6 = null;
        boolean boolean7 = fixedMillisecond5.equals(obj6);
        java.util.Date date8 = fixedMillisecond5.getStart();
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date8);
        org.jfree.data.time.SerialDate serialDate10 = serialDate3.getEndOfCurrentMonth(serialDate9);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance((int) (short) 10);
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.addDays((int) ' ', serialDate14);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate15);
        org.jfree.data.time.SerialDate serialDate17 = serialDate10.getEndOfCurrentMonth(serialDate16);
        try {
            org.jfree.data.time.SerialDate serialDate19 = serialDate17.getFollowingDayOfWeek(11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate17);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass2 = fixedMillisecond1.getClass();
        java.lang.ClassLoader classLoader3 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
        java.util.Date date8 = fixedMillisecond5.getTime();
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date8, timeZone9);
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date8, timeZone11);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        java.lang.Object obj14 = null;
        int int15 = day13.compareTo(obj14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass18 = fixedMillisecond17.getClass();
        java.lang.ClassLoader classLoader19 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar22 = null;
        long long23 = fixedMillisecond21.getMiddleMillisecond(calendar22);
        java.util.Date date24 = fixedMillisecond21.getTime();
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date24, timeZone25);
        boolean boolean27 = day13.equals((java.lang.Object) date24);
        int int28 = year12.compareTo((java.lang.Object) day13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year12.previous();
        long long30 = year12.getFirstMillisecond();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(3);
        int int33 = spreadsheetDate32.getMonth();
        int int34 = spreadsheetDate32.getDayOfWeek();
        java.util.Date date35 = spreadsheetDate32.toDate();
        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.createInstance((int) (short) 10);
        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.addDays((int) ' ', serialDate39);
        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Object obj43 = null;
        boolean boolean44 = fixedMillisecond42.equals(obj43);
        java.util.Date date45 = fixedMillisecond42.getStart();
        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.createInstance(date45);
        org.jfree.data.time.SerialDate serialDate47 = serialDate40.getEndOfCurrentMonth(serialDate46);
        org.jfree.data.time.SerialDate serialDate48 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate47);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate(3);
        int int51 = spreadsheetDate50.getMonth();
        int int52 = spreadsheetDate50.toSerial();
        org.jfree.data.time.SerialDate serialDate55 = org.jfree.data.time.SerialDate.createInstance((int) (short) 10);
        org.jfree.data.time.SerialDate serialDate56 = org.jfree.data.time.SerialDate.addDays((int) ' ', serialDate55);
        org.jfree.data.time.FixedMillisecond fixedMillisecond58 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Object obj59 = null;
        boolean boolean60 = fixedMillisecond58.equals(obj59);
        java.util.Date date61 = fixedMillisecond58.getStart();
        org.jfree.data.time.SerialDate serialDate62 = org.jfree.data.time.SerialDate.createInstance(date61);
        org.jfree.data.time.SerialDate serialDate63 = serialDate56.getEndOfCurrentMonth(serialDate62);
        org.jfree.data.time.FixedMillisecond fixedMillisecond67 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar68 = null;
        long long69 = fixedMillisecond67.getMiddleMillisecond(calendar68);
        org.jfree.data.time.FixedMillisecond fixedMillisecond71 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Object obj72 = null;
        boolean boolean73 = fixedMillisecond71.equals(obj72);
        java.util.Date date74 = fixedMillisecond71.getStart();
        org.jfree.data.time.SerialDate serialDate75 = org.jfree.data.time.SerialDate.createInstance(date74);
        int int76 = fixedMillisecond67.compareTo((java.lang.Object) serialDate75);
        org.jfree.data.time.SerialDate serialDate77 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(7, serialDate75);
        org.jfree.data.time.SerialDate serialDate78 = org.jfree.data.time.SerialDate.addMonths(12, serialDate75);
        boolean boolean80 = spreadsheetDate50.isInRange(serialDate62, serialDate78, 11);
        boolean boolean81 = spreadsheetDate32.isInRange(serialDate47, serialDate78);
        int int82 = year12.compareTo((java.lang.Object) serialDate78);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(classLoader3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(classLoader19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 100L + "'", long23 == 100L);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-31507200000L) + "'", long30 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 3 + "'", int34 == 3);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 3 + "'", int52 == 3);
        org.junit.Assert.assertNotNull(serialDate55);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertNotNull(serialDate62);
        org.junit.Assert.assertNotNull(serialDate63);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 100L + "'", long69 == 100L);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(date74);
        org.junit.Assert.assertNotNull(serialDate75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 1 + "'", int76 == 1);
        org.junit.Assert.assertNotNull(serialDate77);
        org.junit.Assert.assertNotNull(serialDate78);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 1 + "'", int82 == 1);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        java.text.DateFormatSymbols dateFormatSymbols2 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        int int3 = month0.compareTo((java.lang.Object) dateFormatSymbols2);
        long long4 = month0.getSerialIndex();
        java.lang.String str5 = month0.toString();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getMiddleMillisecond(calendar8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond7.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass17 = fixedMillisecond16.getClass();
        java.lang.ClassLoader classLoader18 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar21 = null;
        long long22 = fixedMillisecond20.getMiddleMillisecond(calendar21);
        java.util.Date date23 = fixedMillisecond20.getTime();
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date23, timeZone24);
        java.io.InputStream inputStream26 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass17);
        java.io.InputStream inputStream27 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("org.jfree.data.general.SeriesChangeEvent[source=7]", (java.lang.Class) wildcardClass17);
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod10, "org.jfree.data.general.SeriesChangeEvent[source=7]", "org.jfree.data.general.SeriesChangeEvent[source=7]", (java.lang.Class) wildcardClass17);
        int int29 = timeSeries28.getItemCount();
        java.lang.String str30 = timeSeries28.getDomainDescription();
        boolean boolean31 = month0.equals((java.lang.Object) timeSeries28);
        int int32 = month0.getYearValue();
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
        int int34 = day33.getYear();
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day33);
        int int36 = month0.compareTo((java.lang.Object) day33);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertNotNull(dateFormatSymbols2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 24234L + "'", long4 == 24234L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "June 2019" + "'", str5.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(classLoader18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 100L + "'", long22 == 100L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(inputStream26);
        org.junit.Assert.assertNull(inputStream27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=7]" + "'", str30.equals("org.jfree.data.general.SeriesChangeEvent[source=7]"));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2019 + "'", int32 == 2019);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 2019 + "'", int34 == 2019);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Object obj6 = null;
        boolean boolean7 = fixedMillisecond5.equals(obj6);
        java.util.Date date8 = fixedMillisecond5.getStart();
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date8);
        int int10 = fixedMillisecond1.compareTo((java.lang.Object) serialDate9);
        long long11 = fixedMillisecond1.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("13-June-2019");
        java.lang.String str2 = seriesException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: 13-June-2019" + "'", str2.equals("org.jfree.data.general.SeriesException: 13-June-2019"));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass2 = fixedMillisecond1.getClass();
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy(2, (int) (short) 100);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries7.getDataItem((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(timeSeries7);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        int int2 = spreadsheetDate1.getMonth();
        int int3 = spreadsheetDate1.getDayOfWeek();
        java.util.Date date4 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(3);
        int int8 = spreadsheetDate7.getMonth();
        int int9 = spreadsheetDate7.getDayOfWeek();
        java.util.Date date10 = spreadsheetDate7.toDate();
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addYears(0, (org.jfree.data.time.SerialDate) spreadsheetDate7);
        int int12 = spreadsheetDate7.getYYYY();
        boolean boolean13 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate7);
        try {
            int int15 = spreadsheetDate7.compareTo((java.lang.Object) 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Long cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1900 + "'", int12 == 1900);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(3, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass4 = fixedMillisecond3.getClass();
        java.lang.ClassLoader classLoader5 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass4);
        java.io.InputStream inputStream6 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("31-December-1969", (java.lang.Class) wildcardClass4);
        java.net.URL uRL7 = org.jfree.chart.util.ObjectUtilities.getResource("9-January-1900", (java.lang.Class) wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(classLoader5);
        org.junit.Assert.assertNull(inputStream6);
        org.junit.Assert.assertNull(uRL7);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass2 = fixedMillisecond1.getClass();
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy(2, (int) (short) 100);
        timeSeries7.fireSeriesChanged();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(timeSeries7);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("org.jfree.data.general.SeriesException: ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Object obj2 = null;
        boolean boolean3 = fixedMillisecond1.equals(obj2);
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date4);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond8.getMiddleMillisecond(calendar9);
        java.util.Date date11 = fixedMillisecond8.getTime();
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance(date11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond14.getMiddleMillisecond(calendar15);
        java.util.Date date17 = fixedMillisecond14.getTime();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date17);
        long long19 = year18.getLastMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass24 = fixedMillisecond23.getClass();
        java.lang.Object obj25 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ClassContext", (java.lang.Class) wildcardClass24);
        java.net.URL uRL26 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", (java.lang.Class) wildcardClass24);
        int int27 = year18.compareTo((java.lang.Object) wildcardClass24);
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date11, (java.lang.Class) wildcardClass24);
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date11, timeZone29);
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date4, timeZone29);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 100L + "'", long16 == 100L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 28799999L + "'", long19 == 28799999L);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNull(obj25);
        org.junit.Assert.assertNotNull(uRL26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(timeZone29);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass2 = fixedMillisecond1.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) 0);
        timeSeriesDataItem4.setValue((java.lang.Number) (byte) 0);
        java.lang.Object obj7 = null;
        int int8 = timeSeriesDataItem4.compareTo(obj7);
        boolean boolean10 = timeSeriesDataItem4.equals((java.lang.Object) "October");
        timeSeriesDataItem4.setValue((java.lang.Number) 31);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (java.lang.Number) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = timeSeriesDataItem3.getPeriod();
        java.lang.Number number5 = timeSeriesDataItem3.getValue();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1 + "'", number5.equals(1));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass11 = fixedMillisecond10.getClass();
        java.lang.ClassLoader classLoader12 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond14.getMiddleMillisecond(calendar15);
        java.util.Date date17 = fixedMillisecond14.getTime();
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date17, timeZone18);
        java.io.InputStream inputStream20 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass11);
        java.io.InputStream inputStream21 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("org.jfree.data.general.SeriesChangeEvent[source=7]", (java.lang.Class) wildcardClass11);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod4, "org.jfree.data.general.SeriesChangeEvent[source=7]", "org.jfree.data.general.SeriesChangeEvent[source=7]", (java.lang.Class) wildcardClass11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond24.getMiddleMillisecond(calendar25);
        java.util.Date date27 = fixedMillisecond24.getTime();
        java.util.Calendar calendar28 = null;
        long long29 = fixedMillisecond24.getFirstMillisecond(calendar28);
        java.util.Calendar calendar30 = null;
        fixedMillisecond24.peg(calendar30);
        long long32 = fixedMillisecond24.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries22.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass36 = fixedMillisecond35.getClass();
        java.lang.Class class37 = null;
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond35, class37);
        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries22.addAndOrUpdate(timeSeries38);
        java.util.List list40 = timeSeries39.getItems();
        java.util.List list41 = timeSeries39.getItems();
        timeSeries39.removeAgedItems(true);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(classLoader12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 100L + "'", long16 == 100L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(inputStream20);
        org.junit.Assert.assertNull(inputStream21);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 100L + "'", long26 == 100L);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 100L + "'", long29 == 100L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 100L + "'", long32 == 100L);
        org.junit.Assert.assertNull(timeSeriesDataItem33);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNotNull(timeSeries39);
        org.junit.Assert.assertNotNull(list40);
        org.junit.Assert.assertNotNull(list41);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getMiddleMillisecond(calendar8);
        java.util.Date date10 = fixedMillisecond7.getTime();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date10);
        long long12 = year11.getLastMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass17 = fixedMillisecond16.getClass();
        java.lang.Object obj18 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ClassContext", (java.lang.Class) wildcardClass17);
        java.net.URL uRL19 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", (java.lang.Class) wildcardClass17);
        int int20 = year11.compareTo((java.lang.Object) wildcardClass17);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass17);
        int int22 = timeSeries21.getMaximumItemCount();
        timeSeries21.setDomainDescription("Tuesday");
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = month25.previous();
        org.jfree.data.time.Year year27 = month25.getYear();
        int int28 = month25.getYearValue();
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = day29.previous();
        int int31 = day29.getMonth();
        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries21.createCopy((org.jfree.data.time.RegularTimePeriod) month25, (org.jfree.data.time.RegularTimePeriod) day29);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28799999L + "'", long12 == 28799999L);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNull(obj18);
        org.junit.Assert.assertNotNull(uRL19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2147483647 + "'", int22 == 2147483647);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(year27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2019 + "'", int28 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 6 + "'", int31 == 6);
        org.junit.Assert.assertNotNull(timeSeries32);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("13-June-2019");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        java.lang.String str3 = seriesException1.toString();
        java.lang.Throwable[] throwableArray4 = seriesException1.getSuppressed();
        java.lang.Throwable[] throwableArray5 = seriesException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesException: 13-June-2019" + "'", str3.equals("org.jfree.data.general.SeriesException: 13-June-2019"));
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Object obj2 = null;
        boolean boolean3 = fixedMillisecond1.equals(obj2);
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date4);
        long long6 = month5.getLastMillisecond();
        int int7 = month5.getMonth();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 28799999L + "'", long6 == 28799999L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month1.previous();
        org.jfree.data.time.Year year3 = month1.getYear();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(11, year3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass7 = fixedMillisecond6.getClass();
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond6, class8);
        boolean boolean10 = month4.equals((java.lang.Object) fixedMillisecond6);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getYear();
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0);
        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
        org.jfree.data.time.SerialDate serialDate5 = serialDate3.getNearestDayOfWeek(7);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate5);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Object obj3 = null;
        boolean boolean4 = fixedMillisecond2.equals(obj3);
        java.util.Date date5 = fixedMillisecond2.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass10 = fixedMillisecond9.getClass();
        java.lang.Object obj11 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ClassContext", (java.lang.Class) wildcardClass10);
        java.net.URL uRL12 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", (java.lang.Class) wildcardClass10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Object obj15 = null;
        boolean boolean16 = fixedMillisecond14.equals(obj15);
        java.util.Date date17 = fixedMillisecond14.getStart();
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance(date17);
        java.util.TimeZone timeZone19 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date17, timeZone19);
        java.lang.ClassLoader classLoader21 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass26 = fixedMillisecond25.getClass();
        java.lang.Object obj27 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ClassContext", (java.lang.Class) wildcardClass26);
        java.net.URL uRL28 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", (java.lang.Class) wildcardClass26);
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Object obj31 = null;
        boolean boolean32 = fixedMillisecond30.equals(obj31);
        java.util.Date date33 = fixedMillisecond30.getStart();
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.createInstance(date33);
        java.util.TimeZone timeZone35 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass26, date33, timeZone35);
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar39 = null;
        long long40 = fixedMillisecond38.getMiddleMillisecond(calendar39);
        java.util.Date date41 = fixedMillisecond38.getTime();
        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.createInstance(date41);
        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar45 = null;
        long long46 = fixedMillisecond44.getMiddleMillisecond(calendar45);
        java.util.Date date47 = fixedMillisecond44.getTime();
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year(date47);
        long long49 = year48.getLastMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond53 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass54 = fixedMillisecond53.getClass();
        java.lang.Object obj55 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ClassContext", (java.lang.Class) wildcardClass54);
        java.net.URL uRL56 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", (java.lang.Class) wildcardClass54);
        int int57 = year48.compareTo((java.lang.Object) wildcardClass54);
        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date41, (java.lang.Class) wildcardClass54);
        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day(date41, timeZone59);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date33, timeZone59);
        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year(date5, timeZone59);
        org.jfree.data.time.Month month63 = new org.jfree.data.time.Month(12, year62);
        java.util.Calendar calendar64 = null;
        try {
            long long65 = month63.getLastMillisecond(calendar64);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertNotNull(uRL12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(classLoader21);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNull(obj27);
        org.junit.Assert.assertNotNull(uRL28);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNull(regularTimePeriod36);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 100L + "'", long40 == 100L);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 100L + "'", long46 == 100L);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 28799999L + "'", long49 == 28799999L);
        org.junit.Assert.assertNotNull(wildcardClass54);
        org.junit.Assert.assertNull(obj55);
        org.junit.Assert.assertNotNull(uRL56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
        org.junit.Assert.assertNotNull(timeZone59);
        org.junit.Assert.assertNull(regularTimePeriod61);
    }

//    @Test
//    public void test095() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test095");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(100L);
//        java.lang.Class<?> wildcardClass5 = fixedMillisecond4.getClass();
//        java.lang.Object obj6 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ClassContext", (java.lang.Class) wildcardClass5);
//        java.net.URL uRL7 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", (java.lang.Class) wildcardClass5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(100L);
//        java.lang.Object obj10 = null;
//        boolean boolean11 = fixedMillisecond9.equals(obj10);
//        java.util.Date date12 = fixedMillisecond9.getStart();
//        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance(date12);
//        java.util.TimeZone timeZone14 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date12, timeZone14);
//        int int16 = day0.compareTo((java.lang.Object) date12);
//        long long17 = day0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day0.next();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(100L);
//        java.util.Calendar calendar23 = null;
//        long long24 = fixedMillisecond22.getMiddleMillisecond(calendar23);
//        java.util.Date date25 = fixedMillisecond22.getTime();
//        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.createInstance(date25);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond(100L);
//        java.util.Calendar calendar29 = null;
//        long long30 = fixedMillisecond28.getMiddleMillisecond(calendar29);
//        java.util.Date date31 = fixedMillisecond28.getTime();
//        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date31);
//        long long33 = year32.getLastMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond(100L);
//        java.lang.Class<?> wildcardClass38 = fixedMillisecond37.getClass();
//        java.lang.Object obj39 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ClassContext", (java.lang.Class) wildcardClass38);
//        java.net.URL uRL40 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", (java.lang.Class) wildcardClass38);
//        int int41 = year32.compareTo((java.lang.Object) wildcardClass38);
//        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date25, (java.lang.Class) wildcardClass38);
//        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "Tuesday", "org.jfree.data.general.SeriesChangeEvent[source=100]", (java.lang.Class) wildcardClass38);
//        timeSeries43.setNotify(false);
//        java.lang.Object obj46 = timeSeries43.clone();
//        java.beans.PropertyChangeListener propertyChangeListener47 = null;
//        timeSeries43.addPropertyChangeListener(propertyChangeListener47);
//        java.beans.PropertyChangeListener propertyChangeListener49 = null;
//        timeSeries43.removePropertyChangeListener(propertyChangeListener49);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNull(obj6);
//        org.junit.Assert.assertNotNull(uRL7);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 43629L + "'", long17 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 100L + "'", long24 == 100L);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 100L + "'", long30 == 100L);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 28799999L + "'", long33 == 28799999L);
//        org.junit.Assert.assertNotNull(wildcardClass38);
//        org.junit.Assert.assertNull(obj39);
//        org.junit.Assert.assertNotNull(uRL40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
//        org.junit.Assert.assertNotNull(obj46);
//    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass2 = fixedMillisecond1.getClass();
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, class3);
        timeSeries4.setDescription("31-December-1969");
        java.lang.Class class7 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getMiddleMillisecond(calendar10);
        java.util.Date date12 = fixedMillisecond9.getTime();
        java.util.Calendar calendar13 = null;
        fixedMillisecond9.peg(calendar13);
        int int15 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        java.lang.Comparable comparable16 = timeSeries4.getKey();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(comparable16);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.previous();
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond1.getFirstMillisecond(calendar5);
        java.util.Date date7 = fixedMillisecond1.getTime();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (31) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        long long6 = year5.getLastMillisecond();
        int int7 = year5.getYear();
        long long8 = year5.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 28799999L + "'", long6 == 28799999L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1969 + "'", int7 == 1969);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-31507200000L) + "'", long8 == (-31507200000L));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass2 = fixedMillisecond1.getClass();
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, class3);
        java.lang.Comparable comparable5 = timeSeries4.getKey();
        boolean boolean6 = timeSeries4.getNotify();
        timeSeries4.removeAgedItems(false);
        java.lang.String str9 = timeSeries4.getRangeDescription();
        boolean boolean10 = timeSeries4.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond13.getMiddleMillisecond(calendar14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Object obj18 = null;
        boolean boolean19 = fixedMillisecond17.equals(obj18);
        java.util.Date date20 = fixedMillisecond17.getStart();
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance(date20);
        int int22 = fixedMillisecond13.compareTo((java.lang.Object) serialDate21);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(7, serialDate21);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(serialDate23);
        int int25 = day24.getDayOfMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = day24.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) day24);
        java.lang.String str28 = day24.toString();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(comparable5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Value" + "'", str9.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 100L + "'", long15 == 100L);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 3 + "'", int25 == 3);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNull(timeSeriesDataItem27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "3-January-1970" + "'", str28.equals("3-January-1970"));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass11 = fixedMillisecond10.getClass();
        java.lang.ClassLoader classLoader12 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond14.getMiddleMillisecond(calendar15);
        java.util.Date date17 = fixedMillisecond14.getTime();
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date17, timeZone18);
        java.io.InputStream inputStream20 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass11);
        java.io.InputStream inputStream21 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("org.jfree.data.general.SeriesChangeEvent[source=7]", (java.lang.Class) wildcardClass11);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod4, "org.jfree.data.general.SeriesChangeEvent[source=7]", "org.jfree.data.general.SeriesChangeEvent[source=7]", (java.lang.Class) wildcardClass11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond24.getMiddleMillisecond(calendar25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond24.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass34 = fixedMillisecond33.getClass();
        java.lang.ClassLoader classLoader35 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass34);
        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar38 = null;
        long long39 = fixedMillisecond37.getMiddleMillisecond(calendar38);
        java.util.Date date40 = fixedMillisecond37.getTime();
        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass34, date40, timeZone41);
        java.io.InputStream inputStream43 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass34);
        java.io.InputStream inputStream44 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("org.jfree.data.general.SeriesChangeEvent[source=7]", (java.lang.Class) wildcardClass34);
        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod27, "org.jfree.data.general.SeriesChangeEvent[source=7]", "org.jfree.data.general.SeriesChangeEvent[source=7]", (java.lang.Class) wildcardClass34);
        java.util.List list46 = timeSeries45.getItems();
        java.util.Collection collection47 = timeSeries22.getTimePeriodsUniqueToOtherSeries(timeSeries45);
        java.lang.String str48 = timeSeries22.getRangeDescription();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(classLoader12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 100L + "'", long16 == 100L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(inputStream20);
        org.junit.Assert.assertNull(inputStream21);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 100L + "'", long26 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertNotNull(classLoader35);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 100L + "'", long39 == 100L);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(timeZone41);
        org.junit.Assert.assertNull(regularTimePeriod42);
        org.junit.Assert.assertNotNull(inputStream43);
        org.junit.Assert.assertNull(inputStream44);
        org.junit.Assert.assertNotNull(list46);
        org.junit.Assert.assertNotNull(collection47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=7]" + "'", str48.equals("org.jfree.data.general.SeriesChangeEvent[source=7]"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass2 = fixedMillisecond1.getClass();
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, class3);
        java.util.Collection collection5 = timeSeries4.getTimePeriods();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(collection5);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance((int) (short) 10);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addDays((int) ' ', serialDate4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Object obj8 = null;
        boolean boolean9 = fixedMillisecond7.equals(obj8);
        java.util.Date date10 = fixedMillisecond7.getStart();
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(date10);
        org.jfree.data.time.SerialDate serialDate12 = serialDate5.getEndOfCurrentMonth(serialDate11);
        java.lang.String str13 = serialDate5.getDescription();
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addMonths((int) 'a', serialDate5);
        org.jfree.data.time.SerialDate serialDate16 = serialDate5.getNearestDayOfWeek(5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(3);
        int int19 = spreadsheetDate18.getMonth();
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass22 = fixedMillisecond21.getClass();
        java.lang.ClassLoader classLoader23 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass22);
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar26 = null;
        long long27 = fixedMillisecond25.getMiddleMillisecond(calendar26);
        java.util.Date date28 = fixedMillisecond25.getTime();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass22, date28, timeZone29);
        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.createInstance(date28);
        boolean boolean32 = spreadsheetDate18.isOnOrBefore(serialDate31);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate(3);
        int int35 = spreadsheetDate34.getMonth();
        int int36 = spreadsheetDate34.getDayOfWeek();
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar40 = null;
        long long41 = fixedMillisecond39.getMiddleMillisecond(calendar40);
        java.util.Date date42 = fixedMillisecond39.getTime();
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.createInstance(date42);
        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.addDays(28, serialDate43);
        boolean boolean46 = spreadsheetDate18.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate34, serialDate44, (int) 'a');
        org.jfree.data.time.SerialDate serialDate47 = serialDate16.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate34);
        org.jfree.data.time.SerialDate serialDate51 = org.jfree.data.time.SerialDate.createInstance((int) (short) 10);
        org.jfree.data.time.SerialDate serialDate52 = org.jfree.data.time.SerialDate.addDays((int) ' ', serialDate51);
        org.jfree.data.time.SerialDate serialDate53 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate52);
        org.jfree.data.time.SerialDate serialDate54 = serialDate16.getEndOfCurrentMonth(serialDate53);
        try {
            org.jfree.data.time.SerialDate serialDate55 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((-39), serialDate54);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(classLoader23);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 100L + "'", long27 == 100L);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 3 + "'", int36 == 3);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 100L + "'", long41 == 100L);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertNotNull(serialDate52);
        org.junit.Assert.assertNotNull(serialDate53);
        org.junit.Assert.assertNotNull(serialDate54);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass11 = fixedMillisecond10.getClass();
        java.lang.ClassLoader classLoader12 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond14.getMiddleMillisecond(calendar15);
        java.util.Date date17 = fixedMillisecond14.getTime();
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date17, timeZone18);
        java.io.InputStream inputStream20 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass11);
        java.io.InputStream inputStream21 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("org.jfree.data.general.SeriesChangeEvent[source=7]", (java.lang.Class) wildcardClass11);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod4, "org.jfree.data.general.SeriesChangeEvent[source=7]", "org.jfree.data.general.SeriesChangeEvent[source=7]", (java.lang.Class) wildcardClass11);
        java.util.List list23 = timeSeries22.getItems();
        timeSeries22.setDescription("Tuesday");
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar28 = null;
        long long29 = fixedMillisecond27.getMiddleMillisecond(calendar28);
        java.util.Date date30 = fixedMillisecond27.getTime();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date30);
        long long32 = year31.getLastMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass37 = fixedMillisecond36.getClass();
        java.lang.Object obj38 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ClassContext", (java.lang.Class) wildcardClass37);
        java.net.URL uRL39 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", (java.lang.Class) wildcardClass37);
        int int40 = year31.compareTo((java.lang.Object) wildcardClass37);
        long long41 = year31.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year31, (double) 43629L);
        java.lang.Number number44 = timeSeriesDataItem43.getValue();
        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar47 = null;
        long long48 = fixedMillisecond46.getMiddleMillisecond(calendar47);
        java.util.Date date49 = fixedMillisecond46.getTime();
        java.util.Calendar calendar50 = null;
        fixedMillisecond46.peg(calendar50);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = fixedMillisecond46.next();
        long long53 = fixedMillisecond46.getSerialIndex();
        int int54 = timeSeriesDataItem43.compareTo((java.lang.Object) long53);
        int int56 = timeSeriesDataItem43.compareTo((java.lang.Object) "Last");
        java.lang.Number number57 = timeSeriesDataItem43.getValue();
        try {
            timeSeries22.add(timeSeriesDataItem43, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.FixedMillisecond.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(classLoader12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 100L + "'", long16 == 100L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(inputStream20);
        org.junit.Assert.assertNull(inputStream21);
        org.junit.Assert.assertNotNull(list23);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 100L + "'", long29 == 100L);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 28799999L + "'", long32 == 28799999L);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertNull(obj38);
        org.junit.Assert.assertNotNull(uRL39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 28799999L + "'", long41 == 28799999L);
        org.junit.Assert.assertTrue("'" + number44 + "' != '" + 43629.0d + "'", number44.equals(43629.0d));
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 100L + "'", long48 == 100L);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(regularTimePeriod52);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 100L + "'", long53 == 100L);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
        org.junit.Assert.assertTrue("'" + number57 + "' != '" + 43629.0d + "'", number57.equals(43629.0d));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(9);
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass11 = fixedMillisecond10.getClass();
        java.lang.ClassLoader classLoader12 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond14.getMiddleMillisecond(calendar15);
        java.util.Date date17 = fixedMillisecond14.getTime();
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date17, timeZone18);
        java.io.InputStream inputStream20 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass11);
        java.io.InputStream inputStream21 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("org.jfree.data.general.SeriesChangeEvent[source=7]", (java.lang.Class) wildcardClass11);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod4, "org.jfree.data.general.SeriesChangeEvent[source=7]", "org.jfree.data.general.SeriesChangeEvent[source=7]", (java.lang.Class) wildcardClass11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond24.getMiddleMillisecond(calendar25);
        java.util.Date date27 = fixedMillisecond24.getTime();
        java.util.Calendar calendar28 = null;
        long long29 = fixedMillisecond24.getFirstMillisecond(calendar28);
        java.util.Calendar calendar30 = null;
        fixedMillisecond24.peg(calendar30);
        long long32 = fixedMillisecond24.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries22.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
        timeSeries22.setRangeDescription("9-January-1900");
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(classLoader12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 100L + "'", long16 == 100L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(inputStream20);
        org.junit.Assert.assertNull(inputStream21);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 100L + "'", long26 == 100L);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 100L + "'", long29 == 100L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 100L + "'", long32 == 100L);
        org.junit.Assert.assertNull(timeSeriesDataItem33);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) (short) 10);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addDays((int) ' ', serialDate2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Object obj6 = null;
        boolean boolean7 = fixedMillisecond5.equals(obj6);
        java.util.Date date8 = fixedMillisecond5.getStart();
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date8);
        org.jfree.data.time.SerialDate serialDate10 = serialDate3.getEndOfCurrentMonth(serialDate9);
        java.lang.String str11 = serialDate3.getDescription();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(serialDate3);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNull(str11);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(3);
        int int4 = spreadsheetDate3.getMonth();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass7 = fixedMillisecond6.getClass();
        java.lang.ClassLoader classLoader8 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar11 = null;
        long long12 = fixedMillisecond10.getMiddleMillisecond(calendar11);
        java.util.Date date13 = fixedMillisecond10.getTime();
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date13, timeZone14);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.createInstance(date13);
        boolean boolean17 = spreadsheetDate3.isOnOrBefore(serialDate16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass20 = fixedMillisecond19.getClass();
        java.lang.Class class21 = null;
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond19, class21);
        timeSeries22.setDescription("31-December-1969");
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass27 = fixedMillisecond26.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, (double) 0);
        java.lang.Number number30 = timeSeriesDataItem29.getValue();
        timeSeries22.setKey((java.lang.Comparable) timeSeriesDataItem29);
        java.util.Collection collection32 = timeSeries22.getTimePeriods();
        boolean boolean33 = spreadsheetDate3.equals((java.lang.Object) timeSeries22);
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.addMonths((int) (short) 100, serialDate34);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(classLoader8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 100L + "'", long12 == 100L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertTrue("'" + number30 + "' != '" + 0.0d + "'", number30.equals(0.0d));
        org.junit.Assert.assertNotNull(collection32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNotNull(serialDate35);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (java.lang.Number) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month0.next();
        int int5 = month0.getMonth();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
        org.jfree.data.time.Year year2 = month0.getYear();
        int int3 = month0.getYearValue();
        long long4 = month0.getMiddleMillisecond();
        java.lang.String str5 = month0.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560668399999L + "'", long4 == 1560668399999L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "June 2019" + "'", str5.equals("June 2019"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        long long6 = year5.getLastMillisecond();
        long long7 = year5.getFirstMillisecond();
        int int9 = year5.compareTo((java.lang.Object) '4');
        boolean boolean11 = year5.equals((java.lang.Object) "July 2019");
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 28799999L + "'", long6 == 28799999L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-31507200000L) + "'", long7 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getMiddleMillisecond(calendar8);
        java.util.Date date10 = fixedMillisecond7.getTime();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date10);
        long long12 = year11.getLastMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass17 = fixedMillisecond16.getClass();
        java.lang.Object obj18 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ClassContext", (java.lang.Class) wildcardClass17);
        java.net.URL uRL19 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", (java.lang.Class) wildcardClass17);
        int int20 = year11.compareTo((java.lang.Object) wildcardClass17);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass17);
        int int22 = timeSeries21.getMaximumItemCount();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener23 = null;
        timeSeries21.removeChangeListener(seriesChangeListener23);
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass27 = fixedMillisecond26.getClass();
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond26, class28);
        timeSeries29.setDescription("31-December-1969");
        java.lang.Class class32 = timeSeries29.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar35 = null;
        long long36 = fixedMillisecond34.getMiddleMillisecond(calendar35);
        java.util.Date date37 = fixedMillisecond34.getTime();
        java.util.Calendar calendar38 = null;
        fixedMillisecond34.peg(calendar38);
        int int40 = timeSeries29.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
        int int41 = timeSeries29.getItemCount();
        boolean boolean43 = timeSeries29.equals((java.lang.Object) 12);
        java.util.Collection collection44 = timeSeries21.getTimePeriodsUniqueToOtherSeries(timeSeries29);
        java.lang.String str45 = timeSeries21.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass48 = fixedMillisecond47.getClass();
        java.lang.Class class49 = null;
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond47, class49);
        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar53 = null;
        long long54 = fixedMillisecond52.getMiddleMillisecond(calendar53);
        java.util.Date date55 = fixedMillisecond52.getTime();
        java.util.Calendar calendar56 = null;
        long long57 = fixedMillisecond52.getFirstMillisecond(calendar56);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem59 = timeSeries50.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond52, (java.lang.Number) 10.0f);
        timeSeries50.setMaximumItemAge((long) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = timeSeries50.getNextTimePeriod();
        timeSeries21.setKey((java.lang.Comparable) regularTimePeriod62);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28799999L + "'", long12 == 28799999L);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNull(obj18);
        org.junit.Assert.assertNotNull(uRL19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2147483647 + "'", int22 == 2147483647);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNull(class32);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 100L + "'", long36 == 100L);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(collection44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "Time" + "'", str45.equals("Time"));
        org.junit.Assert.assertNotNull(wildcardClass48);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 100L + "'", long54 == 100L);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 100L + "'", long57 == 100L);
        org.junit.Assert.assertNull(timeSeriesDataItem59);
        org.junit.Assert.assertNotNull(regularTimePeriod62);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        int int2 = spreadsheetDate1.getMonth();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass5 = fixedMillisecond4.getClass();
        java.lang.ClassLoader classLoader6 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond8.getMiddleMillisecond(calendar9);
        java.util.Date date11 = fixedMillisecond8.getTime();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date11, timeZone12);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(date11);
        boolean boolean15 = spreadsheetDate1.isOnOrBefore(serialDate14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(3);
        int int18 = spreadsheetDate17.getMonth();
        int int19 = spreadsheetDate17.getDayOfWeek();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar23 = null;
        long long24 = fixedMillisecond22.getMiddleMillisecond(calendar23);
        java.util.Date date25 = fixedMillisecond22.getTime();
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.createInstance(date25);
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.addDays(28, serialDate26);
        boolean boolean29 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate17, serialDate27, (int) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass32 = fixedMillisecond31.getClass();
        java.lang.ClassLoader classLoader33 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass32);
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar36 = null;
        long long37 = fixedMillisecond35.getMiddleMillisecond(calendar36);
        java.util.Date date38 = fixedMillisecond35.getTime();
        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass32, date38, timeZone39);
        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year(date38, timeZone41);
        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
        java.lang.Object obj44 = null;
        int int45 = day43.compareTo(obj44);
        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass48 = fixedMillisecond47.getClass();
        java.lang.ClassLoader classLoader49 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass48);
        org.jfree.data.time.FixedMillisecond fixedMillisecond51 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar52 = null;
        long long53 = fixedMillisecond51.getMiddleMillisecond(calendar52);
        java.util.Date date54 = fixedMillisecond51.getTime();
        java.util.TimeZone timeZone55 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass48, date54, timeZone55);
        boolean boolean57 = day43.equals((java.lang.Object) date54);
        int int58 = year42.compareTo((java.lang.Object) day43);
        org.jfree.data.time.SerialDate serialDate59 = day43.getSerialDate();
        boolean boolean60 = spreadsheetDate1.isOn(serialDate59);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(classLoader6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 3 + "'", int19 == 3);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 100L + "'", long24 == 100L);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertNotNull(classLoader33);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 100L + "'", long37 == 100L);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(timeZone39);
        org.junit.Assert.assertNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(timeZone41);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertNotNull(wildcardClass48);
        org.junit.Assert.assertNotNull(classLoader49);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 100L + "'", long53 == 100L);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertNotNull(timeZone55);
        org.junit.Assert.assertNull(regularTimePeriod56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertNotNull(serialDate59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getMiddleMillisecond(calendar8);
        java.util.Date date10 = fixedMillisecond7.getTime();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date10);
        long long12 = year11.getLastMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass17 = fixedMillisecond16.getClass();
        java.lang.Object obj18 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ClassContext", (java.lang.Class) wildcardClass17);
        java.net.URL uRL19 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", (java.lang.Class) wildcardClass17);
        int int20 = year11.compareTo((java.lang.Object) wildcardClass17);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass17);
        int int22 = timeSeries21.getMaximumItemCount();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener23 = null;
        timeSeries21.removeChangeListener(seriesChangeListener23);
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass27 = fixedMillisecond26.getClass();
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond26, class28);
        timeSeries29.setDescription("31-December-1969");
        java.lang.Class class32 = timeSeries29.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar35 = null;
        long long36 = fixedMillisecond34.getMiddleMillisecond(calendar35);
        java.util.Date date37 = fixedMillisecond34.getTime();
        java.util.Calendar calendar38 = null;
        fixedMillisecond34.peg(calendar38);
        int int40 = timeSeries29.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
        int int41 = timeSeries29.getItemCount();
        boolean boolean43 = timeSeries29.equals((java.lang.Object) 12);
        java.util.Collection collection44 = timeSeries21.getTimePeriodsUniqueToOtherSeries(timeSeries29);
        timeSeries29.removeAgedItems(true);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28799999L + "'", long12 == 28799999L);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNull(obj18);
        org.junit.Assert.assertNotNull(uRL19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2147483647 + "'", int22 == 2147483647);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNull(class32);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 100L + "'", long36 == 100L);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(collection44);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: SerialDate.weekInMonthToString(): invalid code." + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Calendar calendar4 = null;
        fixedMillisecond1.peg(calendar4);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond1.getFirstMillisecond(calendar6);
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond1.getMiddleMillisecond(calendar8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond1.previous();
        long long11 = fixedMillisecond1.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass2 = fixedMillisecond1.getClass();
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, class3);
        timeSeries4.setDescription("31-December-1969");
        java.lang.Class class7 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getMiddleMillisecond(calendar10);
        java.util.Date date12 = fixedMillisecond9.getTime();
        java.util.Calendar calendar13 = null;
        fixedMillisecond9.peg(calendar13);
        int int15 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        java.util.Date date16 = fixedMillisecond9.getTime();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date16);
        org.jfree.data.general.SeriesException seriesException20 = new org.jfree.data.general.SeriesException("");
        boolean boolean21 = day18.equals((java.lang.Object) "");
        long long22 = day18.getSerialIndex();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 25568L + "'", long22 == 25568L);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) (short) 10);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addDays((int) ' ', serialDate6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Object obj10 = null;
        boolean boolean11 = fixedMillisecond9.equals(obj10);
        java.util.Date date12 = fixedMillisecond9.getStart();
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance(date12);
        org.jfree.data.time.SerialDate serialDate14 = serialDate7.getEndOfCurrentMonth(serialDate13);
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate14);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addDays((int) '4', serialDate15);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.addYears((int) (byte) 1, serialDate15);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addYears(13, serialDate15);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate18);
    }

//    @Test
//    public void test119() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test119");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(100L);
//        java.lang.Class<?> wildcardClass5 = fixedMillisecond4.getClass();
//        java.lang.Object obj6 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ClassContext", (java.lang.Class) wildcardClass5);
//        java.net.URL uRL7 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", (java.lang.Class) wildcardClass5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(100L);
//        java.lang.Object obj10 = null;
//        boolean boolean11 = fixedMillisecond9.equals(obj10);
//        java.util.Date date12 = fixedMillisecond9.getStart();
//        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance(date12);
//        java.util.TimeZone timeZone14 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date12, timeZone14);
//        int int16 = day0.compareTo((java.lang.Object) date12);
//        long long17 = day0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day0.next();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(100L);
//        java.util.Calendar calendar23 = null;
//        long long24 = fixedMillisecond22.getMiddleMillisecond(calendar23);
//        java.util.Date date25 = fixedMillisecond22.getTime();
//        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.createInstance(date25);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond(100L);
//        java.util.Calendar calendar29 = null;
//        long long30 = fixedMillisecond28.getMiddleMillisecond(calendar29);
//        java.util.Date date31 = fixedMillisecond28.getTime();
//        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date31);
//        long long33 = year32.getLastMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond(100L);
//        java.lang.Class<?> wildcardClass38 = fixedMillisecond37.getClass();
//        java.lang.Object obj39 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ClassContext", (java.lang.Class) wildcardClass38);
//        java.net.URL uRL40 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", (java.lang.Class) wildcardClass38);
//        int int41 = year32.compareTo((java.lang.Object) wildcardClass38);
//        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date25, (java.lang.Class) wildcardClass38);
//        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "Tuesday", "org.jfree.data.general.SeriesChangeEvent[source=100]", (java.lang.Class) wildcardClass38);
//        long long44 = day0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = day0.previous();
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNull(obj6);
//        org.junit.Assert.assertNotNull(uRL7);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 43629L + "'", long17 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 100L + "'", long24 == 100L);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 100L + "'", long30 == 100L);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 28799999L + "'", long33 == 28799999L);
//        org.junit.Assert.assertNotNull(wildcardClass38);
//        org.junit.Assert.assertNull(obj39);
//        org.junit.Assert.assertNotNull(uRL40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1560495599999L + "'", long44 == 1560495599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond1.getFirstMillisecond(calendar5);
        java.util.Calendar calendar7 = null;
        fixedMillisecond1.peg(calendar7);
        long long9 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond1.getFirstMillisecond(calendar10);
        java.lang.String str12 = fixedMillisecond1.toString();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str12.equals("Wed Dec 31 16:00:00 PST 1969"));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass2 = fixedMillisecond1.getClass();
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, class3);
        int int5 = timeSeries4.getMaximumItemCount();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass8 = fixedMillisecond7.getClass();
        java.lang.Class class9 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond7, class9);
        timeSeries10.setDescription("31-December-1969");
        long long13 = timeSeries10.getMaximumItemAge();
        java.util.Collection collection14 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries10);
        java.lang.String str15 = timeSeries4.getDomainDescription();
        boolean boolean16 = timeSeries4.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener17);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 9223372036854775807L + "'", long13 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Time" + "'", str15.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        java.text.DateFormatSymbols dateFormatSymbols2 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        int int3 = month0.compareTo((java.lang.Object) dateFormatSymbols2);
        long long4 = month0.getSerialIndex();
        java.lang.String str5 = month0.toString();
        long long6 = month0.getSerialIndex();
        int int7 = month0.getMonth();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertNotNull(dateFormatSymbols2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 24234L + "'", long4 == 24234L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "June 2019" + "'", str5.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 24234L + "'", long6 == 24234L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass2 = fixedMillisecond1.getClass();
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, class3);
        java.lang.Comparable comparable5 = timeSeries4.getKey();
        timeSeries4.removeAgedItems(true);
        int int8 = timeSeries4.getItemCount();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(comparable5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Object obj2 = null;
        boolean boolean3 = fixedMillisecond1.equals(obj2);
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date4);
        long long6 = month5.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month5.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month5.previous();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = month5.getLastMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 28799999L + "'", long6 == 28799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        int int2 = spreadsheetDate1.getMonth();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass5 = fixedMillisecond4.getClass();
        java.lang.ClassLoader classLoader6 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond8.getMiddleMillisecond(calendar9);
        java.util.Date date11 = fixedMillisecond8.getTime();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date11, timeZone12);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(date11);
        boolean boolean15 = spreadsheetDate1.isOnOrBefore(serialDate14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(3);
        int int18 = spreadsheetDate17.getMonth();
        int int19 = spreadsheetDate17.getDayOfWeek();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar23 = null;
        long long24 = fixedMillisecond22.getMiddleMillisecond(calendar23);
        java.util.Date date25 = fixedMillisecond22.getTime();
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.createInstance(date25);
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.addDays(28, serialDate26);
        boolean boolean29 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate17, serialDate27, (int) 'a');
        int int30 = spreadsheetDate17.getMonth();
        int int31 = spreadsheetDate17.getDayOfMonth();
        java.util.Date date32 = spreadsheetDate17.toDate();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(classLoader6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 3 + "'", int19 == 3);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 100L + "'", long24 == 100L);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2 + "'", int31 == 2);
        org.junit.Assert.assertNotNull(date32);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass2 = fixedMillisecond1.getClass();
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, class3);
        timeSeries4.setDescription("31-December-1969");
        java.lang.Class class7 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getMiddleMillisecond(calendar10);
        java.util.Date date12 = fixedMillisecond9.getTime();
        java.util.Calendar calendar13 = null;
        fixedMillisecond9.peg(calendar13);
        int int15 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar18 = null;
        long long19 = fixedMillisecond17.getMiddleMillisecond(calendar18);
        java.util.Date date20 = fixedMillisecond17.getTime();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        long long22 = year21.getLastMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass27 = fixedMillisecond26.getClass();
        java.lang.Object obj28 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ClassContext", (java.lang.Class) wildcardClass27);
        java.net.URL uRL29 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", (java.lang.Class) wildcardClass27);
        int int30 = year21.compareTo((java.lang.Object) wildcardClass27);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year21.next();
        long long32 = year21.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) year21);
        java.beans.PropertyChangeListener propertyChangeListener34 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener34);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 100L + "'", long19 == 100L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 28799999L + "'", long22 == 28799999L);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNull(obj28);
        org.junit.Assert.assertNotNull(uRL29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 28799999L + "'", long32 == 28799999L);
        org.junit.Assert.assertNull(timeSeriesDataItem33);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        int int2 = spreadsheetDate1.getMonth();
        java.lang.Class<?> wildcardClass3 = spreadsheetDate1.getClass();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(3);
        int int6 = spreadsheetDate5.getMonth();
        int int7 = spreadsheetDate5.getDayOfWeek();
        java.util.Date date8 = spreadsheetDate5.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(3);
        int int12 = spreadsheetDate11.getMonth();
        int int13 = spreadsheetDate11.getDayOfWeek();
        java.util.Date date14 = spreadsheetDate11.toDate();
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.addYears(0, (org.jfree.data.time.SerialDate) spreadsheetDate11);
        int int16 = spreadsheetDate11.getYYYY();
        boolean boolean17 = spreadsheetDate5.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(3);
        int int22 = spreadsheetDate21.getMonth();
        int int23 = spreadsheetDate21.getDayOfWeek();
        java.util.Date date24 = spreadsheetDate21.toDate();
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.addYears(0, (org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, (org.jfree.data.time.SerialDate) spreadsheetDate21);
        java.lang.Object obj27 = null;
        boolean boolean28 = spreadsheetDate21.equals(obj27);
        boolean boolean29 = spreadsheetDate11.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate21);
        boolean boolean30 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.createInstance((int) (short) 10);
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.addDays((int) ' ', serialDate33);
        serialDate34.setDescription("First");
        boolean boolean37 = spreadsheetDate1.isOnOrAfter(serialDate34);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 3 + "'", int13 == 3);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1900 + "'", int16 == 1900);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 3 + "'", int23 == 3);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getMiddleMillisecond(calendar8);
        java.util.Date date10 = fixedMillisecond7.getTime();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date10);
        long long12 = year11.getLastMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass17 = fixedMillisecond16.getClass();
        java.lang.Object obj18 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ClassContext", (java.lang.Class) wildcardClass17);
        java.net.URL uRL19 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", (java.lang.Class) wildcardClass17);
        int int20 = year11.compareTo((java.lang.Object) wildcardClass17);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass17);
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date4, timeZone22);
        long long24 = day23.getFirstMillisecond();
        java.util.Date date25 = day23.getEnd();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28799999L + "'", long12 == 28799999L);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNull(obj18);
        org.junit.Assert.assertNotNull(uRL19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-57600000L) + "'", long24 == (-57600000L));
        org.junit.Assert.assertNotNull(date25);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass2 = fixedMillisecond1.getClass();
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, class3);
        timeSeries4.setDescription("31-December-1969");
        java.lang.Class class7 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getMiddleMillisecond(calendar10);
        java.util.Date date12 = fixedMillisecond9.getTime();
        java.util.Calendar calendar13 = null;
        fixedMillisecond9.peg(calendar13);
        int int15 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass18 = fixedMillisecond17.getClass();
        java.lang.Class class19 = null;
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond17, class19);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, (double) 6);
        java.util.Calendar calendar23 = null;
        long long24 = fixedMillisecond17.getLastMillisecond(calendar23);
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond17.getLastMillisecond(calendar25);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 100L + "'", long24 == 100L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 100L + "'", long26 == 100L);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass11 = fixedMillisecond10.getClass();
        java.lang.ClassLoader classLoader12 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond14.getMiddleMillisecond(calendar15);
        java.util.Date date17 = fixedMillisecond14.getTime();
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date17, timeZone18);
        java.io.InputStream inputStream20 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass11);
        java.io.InputStream inputStream21 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("org.jfree.data.general.SeriesChangeEvent[source=7]", (java.lang.Class) wildcardClass11);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod4, "org.jfree.data.general.SeriesChangeEvent[source=7]", "org.jfree.data.general.SeriesChangeEvent[source=7]", (java.lang.Class) wildcardClass11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond24.getMiddleMillisecond(calendar25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond24.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass34 = fixedMillisecond33.getClass();
        java.lang.ClassLoader classLoader35 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass34);
        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar38 = null;
        long long39 = fixedMillisecond37.getMiddleMillisecond(calendar38);
        java.util.Date date40 = fixedMillisecond37.getTime();
        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass34, date40, timeZone41);
        java.io.InputStream inputStream43 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass34);
        java.io.InputStream inputStream44 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("org.jfree.data.general.SeriesChangeEvent[source=7]", (java.lang.Class) wildcardClass34);
        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod27, "org.jfree.data.general.SeriesChangeEvent[source=7]", "org.jfree.data.general.SeriesChangeEvent[source=7]", (java.lang.Class) wildcardClass34);
        java.util.List list46 = timeSeries45.getItems();
        java.util.Collection collection47 = timeSeries22.getTimePeriodsUniqueToOtherSeries(timeSeries45);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries45.getDataItem(8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(classLoader12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 100L + "'", long16 == 100L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(inputStream20);
        org.junit.Assert.assertNull(inputStream21);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 100L + "'", long26 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertNotNull(classLoader35);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 100L + "'", long39 == 100L);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(timeZone41);
        org.junit.Assert.assertNull(regularTimePeriod42);
        org.junit.Assert.assertNotNull(inputStream43);
        org.junit.Assert.assertNull(inputStream44);
        org.junit.Assert.assertNotNull(list46);
        org.junit.Assert.assertNotNull(collection47);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass2 = fixedMillisecond1.getClass();
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, class3);
        int int5 = timeSeries4.getMaximumItemCount();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass8 = fixedMillisecond7.getClass();
        java.lang.Class class9 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond7, class9);
        timeSeries10.setDescription("31-December-1969");
        long long13 = timeSeries10.getMaximumItemAge();
        java.util.Collection collection14 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries10);
        java.lang.String str15 = timeSeries4.getDomainDescription();
        boolean boolean16 = timeSeries4.isEmpty();
        try {
            timeSeries4.removeAgedItems((long) (byte) 1, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 9223372036854775807L + "'", long13 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Time" + "'", str15.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        int int2 = spreadsheetDate1.getMonth();
        int int3 = spreadsheetDate1.getMonth();
        spreadsheetDate1.setDescription("hi!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date4);
        java.util.Calendar calendar8 = null;
        try {
            long long9 = month7.getFirstMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass4 = fixedMillisecond3.getClass();
        java.lang.ClassLoader classLoader5 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getMiddleMillisecond(calendar8);
        java.util.Date date10 = fixedMillisecond7.getTime();
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date10, timeZone11);
        java.io.InputStream inputStream13 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass4);
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        java.lang.Class class15 = null;
        java.lang.Object obj16 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("13-June-2019", (java.lang.Class) wildcardClass4, class15);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(classLoader5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(inputStream13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNull(obj16);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass2 = fixedMillisecond1.getClass();
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, class3);
        timeSeries4.setDescription("31-December-1969");
        java.lang.Class class7 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getMiddleMillisecond(calendar10);
        java.util.Date date12 = fixedMillisecond9.getTime();
        java.util.Calendar calendar13 = null;
        fixedMillisecond9.peg(calendar13);
        int int15 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass18 = fixedMillisecond17.getClass();
        java.lang.Class class19 = null;
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond17, class19);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, (double) 6);
        timeSeries4.update(0, (java.lang.Number) (-1));
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass2 = fixedMillisecond1.getClass();
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, class3);
        timeSeries4.setDescription("31-December-1969");
        java.lang.Class class7 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getMiddleMillisecond(calendar10);
        java.util.Date date12 = fixedMillisecond9.getTime();
        java.util.Calendar calendar13 = null;
        fixedMillisecond9.peg(calendar13);
        int int15 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar18 = null;
        long long19 = fixedMillisecond17.getMiddleMillisecond(calendar18);
        java.util.Date date20 = fixedMillisecond17.getTime();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        long long22 = year21.getLastMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass27 = fixedMillisecond26.getClass();
        java.lang.Object obj28 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ClassContext", (java.lang.Class) wildcardClass27);
        java.net.URL uRL29 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", (java.lang.Class) wildcardClass27);
        int int30 = year21.compareTo((java.lang.Object) wildcardClass27);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year21.next();
        long long32 = year21.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) year21);
        java.util.Collection collection34 = timeSeries4.getTimePeriods();
        java.lang.Comparable comparable35 = timeSeries4.getKey();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 100L + "'", long19 == 100L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 28799999L + "'", long22 == 28799999L);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNull(obj28);
        org.junit.Assert.assertNotNull(uRL29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 28799999L + "'", long32 == 28799999L);
        org.junit.Assert.assertNull(timeSeriesDataItem33);
        org.junit.Assert.assertNotNull(collection34);
        org.junit.Assert.assertNotNull(comparable35);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (short) 10);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addDays((int) ' ', serialDate3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Object obj7 = null;
        boolean boolean8 = fixedMillisecond6.equals(obj7);
        java.util.Date date9 = fixedMillisecond6.getStart();
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date9);
        org.jfree.data.time.SerialDate serialDate11 = serialDate4.getEndOfCurrentMonth(serialDate10);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(serialDate10);
        try {
            org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addYears(2147483647, serialDate10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate11);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass2 = fixedMillisecond1.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) 0);
        timeSeriesDataItem4.setValue((java.lang.Number) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = timeSeriesDataItem4.getPeriod();
        java.lang.Object obj8 = timeSeriesDataItem4.clone();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getMiddleMillisecond(calendar8);
        java.util.Date date10 = fixedMillisecond7.getTime();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date10);
        long long12 = year11.getLastMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass17 = fixedMillisecond16.getClass();
        java.lang.Object obj18 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ClassContext", (java.lang.Class) wildcardClass17);
        java.net.URL uRL19 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", (java.lang.Class) wildcardClass17);
        int int20 = year11.compareTo((java.lang.Object) wildcardClass17);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass17);
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date4, timeZone22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date4);
        long long25 = year24.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28799999L + "'", long12 == 28799999L);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNull(obj18);
        org.junit.Assert.assertNotNull(uRL19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1969L + "'", long25 == 1969L);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(1900, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test141() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test141");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(100L);
//        java.lang.Class<?> wildcardClass5 = fixedMillisecond4.getClass();
//        java.lang.Object obj6 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ClassContext", (java.lang.Class) wildcardClass5);
//        java.net.URL uRL7 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", (java.lang.Class) wildcardClass5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(100L);
//        java.lang.Object obj10 = null;
//        boolean boolean11 = fixedMillisecond9.equals(obj10);
//        java.util.Date date12 = fixedMillisecond9.getStart();
//        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance(date12);
//        java.util.TimeZone timeZone14 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date12, timeZone14);
//        int int16 = day0.compareTo((java.lang.Object) date12);
//        long long17 = day0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day0.next();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(100L);
//        java.util.Calendar calendar23 = null;
//        long long24 = fixedMillisecond22.getMiddleMillisecond(calendar23);
//        java.util.Date date25 = fixedMillisecond22.getTime();
//        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.createInstance(date25);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond(100L);
//        java.util.Calendar calendar29 = null;
//        long long30 = fixedMillisecond28.getMiddleMillisecond(calendar29);
//        java.util.Date date31 = fixedMillisecond28.getTime();
//        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date31);
//        long long33 = year32.getLastMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond(100L);
//        java.lang.Class<?> wildcardClass38 = fixedMillisecond37.getClass();
//        java.lang.Object obj39 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ClassContext", (java.lang.Class) wildcardClass38);
//        java.net.URL uRL40 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", (java.lang.Class) wildcardClass38);
//        int int41 = year32.compareTo((java.lang.Object) wildcardClass38);
//        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date25, (java.lang.Class) wildcardClass38);
//        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "Tuesday", "org.jfree.data.general.SeriesChangeEvent[source=100]", (java.lang.Class) wildcardClass38);
//        int int44 = timeSeries43.getMaximumItemCount();
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond(100L);
//        java.lang.Class<?> wildcardClass49 = fixedMillisecond48.getClass();
//        java.lang.ClassLoader classLoader50 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass49);
//        java.io.InputStream inputStream51 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("31-December-1969", (java.lang.Class) wildcardClass49);
//        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day45, (java.lang.Class) wildcardClass49);
//        java.lang.String str53 = timeSeries52.getRangeDescription();
//        org.jfree.data.time.TimeSeries timeSeries54 = timeSeries43.addAndOrUpdate(timeSeries52);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNull(obj6);
//        org.junit.Assert.assertNotNull(uRL7);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 43629L + "'", long17 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 100L + "'", long24 == 100L);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 100L + "'", long30 == 100L);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 28799999L + "'", long33 == 28799999L);
//        org.junit.Assert.assertNotNull(wildcardClass38);
//        org.junit.Assert.assertNull(obj39);
//        org.junit.Assert.assertNotNull(uRL40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 2147483647 + "'", int44 == 2147483647);
//        org.junit.Assert.assertNotNull(wildcardClass49);
//        org.junit.Assert.assertNotNull(classLoader50);
//        org.junit.Assert.assertNull(inputStream51);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "Value" + "'", str53.equals("Value"));
//        org.junit.Assert.assertNotNull(timeSeries54);
//    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        java.text.DateFormatSymbols dateFormatSymbols2 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        int int3 = month0.compareTo((java.lang.Object) dateFormatSymbols2);
        long long4 = month0.getSerialIndex();
        java.lang.String str5 = month0.toString();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getMiddleMillisecond(calendar8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond7.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass17 = fixedMillisecond16.getClass();
        java.lang.ClassLoader classLoader18 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar21 = null;
        long long22 = fixedMillisecond20.getMiddleMillisecond(calendar21);
        java.util.Date date23 = fixedMillisecond20.getTime();
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date23, timeZone24);
        java.io.InputStream inputStream26 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass17);
        java.io.InputStream inputStream27 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("org.jfree.data.general.SeriesChangeEvent[source=7]", (java.lang.Class) wildcardClass17);
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod10, "org.jfree.data.general.SeriesChangeEvent[source=7]", "org.jfree.data.general.SeriesChangeEvent[source=7]", (java.lang.Class) wildcardClass17);
        int int29 = timeSeries28.getItemCount();
        java.lang.String str30 = timeSeries28.getDomainDescription();
        boolean boolean31 = month0.equals((java.lang.Object) timeSeries28);
        int int32 = month0.getYearValue();
        int int33 = month0.getYearValue();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertNotNull(dateFormatSymbols2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 24234L + "'", long4 == 24234L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "June 2019" + "'", str5.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(classLoader18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 100L + "'", long22 == 100L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(inputStream26);
        org.junit.Assert.assertNull(inputStream27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=7]" + "'", str30.equals("org.jfree.data.general.SeriesChangeEvent[source=7]"));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2019 + "'", int32 == 2019);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2019 + "'", int33 == 2019);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Object obj6 = null;
        boolean boolean7 = fixedMillisecond5.equals(obj6);
        java.util.Date date8 = fixedMillisecond5.getStart();
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date8);
        int int10 = fixedMillisecond1.compareTo((java.lang.Object) serialDate9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond1.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass18 = fixedMillisecond17.getClass();
        java.lang.ClassLoader classLoader19 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar22 = null;
        long long23 = fixedMillisecond21.getMiddleMillisecond(calendar22);
        java.util.Date date24 = fixedMillisecond21.getTime();
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date24, timeZone25);
        java.io.InputStream inputStream27 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass18);
        java.io.InputStream inputStream28 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("org.jfree.data.general.SeriesChangeEvent[source=7]", (java.lang.Class) wildcardClass18);
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, "", "", (java.lang.Class) wildcardClass18);
        java.lang.Class class30 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass18);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent31 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) class30);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(classLoader19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 100L + "'", long23 == 100L);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(inputStream27);
        org.junit.Assert.assertNull(inputStream28);
        org.junit.Assert.assertNotNull(class30);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass11 = fixedMillisecond10.getClass();
        java.lang.ClassLoader classLoader12 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond14.getMiddleMillisecond(calendar15);
        java.util.Date date17 = fixedMillisecond14.getTime();
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date17, timeZone18);
        java.io.InputStream inputStream20 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass11);
        java.io.InputStream inputStream21 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("org.jfree.data.general.SeriesChangeEvent[source=7]", (java.lang.Class) wildcardClass11);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod4, "org.jfree.data.general.SeriesChangeEvent[source=7]", "org.jfree.data.general.SeriesChangeEvent[source=7]", (java.lang.Class) wildcardClass11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond24.getMiddleMillisecond(calendar25);
        java.util.Date date27 = fixedMillisecond24.getTime();
        java.util.Calendar calendar28 = null;
        long long29 = fixedMillisecond24.getFirstMillisecond(calendar28);
        java.util.Calendar calendar30 = null;
        fixedMillisecond24.peg(calendar30);
        long long32 = fixedMillisecond24.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries22.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass36 = fixedMillisecond35.getClass();
        java.lang.Class class37 = null;
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond35, class37);
        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries22.addAndOrUpdate(timeSeries38);
        int int40 = timeSeries39.getMaximumItemCount();
        java.beans.PropertyChangeListener propertyChangeListener41 = null;
        timeSeries39.removePropertyChangeListener(propertyChangeListener41);
        java.lang.Comparable comparable43 = timeSeries39.getKey();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(classLoader12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 100L + "'", long16 == 100L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(inputStream20);
        org.junit.Assert.assertNull(inputStream21);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 100L + "'", long26 == 100L);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 100L + "'", long29 == 100L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 100L + "'", long32 == 100L);
        org.junit.Assert.assertNull(timeSeriesDataItem33);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNotNull(timeSeries39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2147483647 + "'", int40 == 2147483647);
        org.junit.Assert.assertTrue("'" + comparable43 + "' != '" + "Overwritten values from: Wed Dec 31 16:00:00 PST 1969" + "'", comparable43.equals("Overwritten values from: Wed Dec 31 16:00:00 PST 1969"));
    }

//    @Test
//    public void test145() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test145");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
//        java.lang.Class<?> wildcardClass2 = fixedMillisecond1.getClass();
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, class3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(100L);
//        java.util.Calendar calendar7 = null;
//        long long8 = fixedMillisecond6.getMiddleMillisecond(calendar7);
//        java.util.Date date9 = fixedMillisecond6.getTime();
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond6.getFirstMillisecond(calendar10);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 10.0f);
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond6);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond(100L);
//        java.util.Calendar calendar17 = null;
//        long long18 = fixedMillisecond16.getMiddleMillisecond(calendar17);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = fixedMillisecond16.previous();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond(100L);
//        java.lang.Class<?> wildcardClass26 = fixedMillisecond25.getClass();
//        java.lang.ClassLoader classLoader27 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass26);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond(100L);
//        java.util.Calendar calendar30 = null;
//        long long31 = fixedMillisecond29.getMiddleMillisecond(calendar30);
//        java.util.Date date32 = fixedMillisecond29.getTime();
//        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass26, date32, timeZone33);
//        java.io.InputStream inputStream35 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass26);
//        java.io.InputStream inputStream36 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("org.jfree.data.general.SeriesChangeEvent[source=7]", (java.lang.Class) wildcardClass26);
//        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod19, "org.jfree.data.general.SeriesChangeEvent[source=7]", "org.jfree.data.general.SeriesChangeEvent[source=7]", (java.lang.Class) wildcardClass26);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond(100L);
//        java.util.Calendar calendar40 = null;
//        long long41 = fixedMillisecond39.getMiddleMillisecond(calendar40);
//        java.util.Date date42 = fixedMillisecond39.getTime();
//        java.util.Calendar calendar43 = null;
//        long long44 = fixedMillisecond39.getFirstMillisecond(calendar43);
//        java.util.Calendar calendar45 = null;
//        fixedMillisecond39.peg(calendar45);
//        long long47 = fixedMillisecond39.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = timeSeries37.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39);
//        java.util.Collection collection49 = timeSeries14.getTimePeriodsUniqueToOtherSeries(timeSeries37);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond51 = new org.jfree.data.time.FixedMillisecond(100L);
//        java.lang.Class<?> wildcardClass52 = fixedMillisecond51.getClass();
//        java.lang.Class class53 = null;
//        org.jfree.data.time.TimeSeries timeSeries54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond51, class53);
//        java.lang.Comparable comparable55 = timeSeries54.getKey();
//        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond60 = new org.jfree.data.time.FixedMillisecond(100L);
//        java.lang.Class<?> wildcardClass61 = fixedMillisecond60.getClass();
//        java.lang.Object obj62 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ClassContext", (java.lang.Class) wildcardClass61);
//        java.net.URL uRL63 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", (java.lang.Class) wildcardClass61);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond65 = new org.jfree.data.time.FixedMillisecond(100L);
//        java.lang.Object obj66 = null;
//        boolean boolean67 = fixedMillisecond65.equals(obj66);
//        java.util.Date date68 = fixedMillisecond65.getStart();
//        org.jfree.data.time.SerialDate serialDate69 = org.jfree.data.time.SerialDate.createInstance(date68);
//        java.util.TimeZone timeZone70 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass61, date68, timeZone70);
//        int int72 = day56.compareTo((java.lang.Object) date68);
//        long long73 = day56.getSerialIndex();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond75 = new org.jfree.data.time.FixedMillisecond(100L);
//        java.util.Calendar calendar76 = null;
//        long long77 = fixedMillisecond75.getMiddleMillisecond(calendar76);
//        java.util.Date date78 = fixedMillisecond75.getTime();
//        org.jfree.data.time.Year year79 = new org.jfree.data.time.Year(date78);
//        long long80 = year79.getLastMillisecond();
//        long long81 = year79.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries82 = timeSeries54.createCopy((org.jfree.data.time.RegularTimePeriod) day56, (org.jfree.data.time.RegularTimePeriod) year79);
//        org.jfree.data.time.TimeSeries timeSeries83 = timeSeries14.addAndOrUpdate(timeSeries82);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
//        org.junit.Assert.assertNull(timeSeriesDataItem13);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 100L + "'", long18 == 100L);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(classLoader27);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 100L + "'", long31 == 100L);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(timeZone33);
//        org.junit.Assert.assertNull(regularTimePeriod34);
//        org.junit.Assert.assertNotNull(inputStream35);
//        org.junit.Assert.assertNull(inputStream36);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 100L + "'", long41 == 100L);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 100L + "'", long44 == 100L);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 100L + "'", long47 == 100L);
//        org.junit.Assert.assertNull(timeSeriesDataItem48);
//        org.junit.Assert.assertNotNull(collection49);
//        org.junit.Assert.assertNotNull(wildcardClass52);
//        org.junit.Assert.assertNotNull(comparable55);
//        org.junit.Assert.assertNotNull(wildcardClass61);
//        org.junit.Assert.assertNull(obj62);
//        org.junit.Assert.assertNotNull(uRL63);
//        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
//        org.junit.Assert.assertNotNull(date68);
//        org.junit.Assert.assertNotNull(serialDate69);
//        org.junit.Assert.assertNull(regularTimePeriod71);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 1 + "'", int72 == 1);
//        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 43629L + "'", long73 == 43629L);
//        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 100L + "'", long77 == 100L);
//        org.junit.Assert.assertNotNull(date78);
//        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 28799999L + "'", long80 == 28799999L);
//        org.junit.Assert.assertTrue("'" + long81 + "' != '" + (-31507200000L) + "'", long81 == (-31507200000L));
//        org.junit.Assert.assertNotNull(timeSeries82);
//        org.junit.Assert.assertNotNull(timeSeries83);
//    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond2.getMiddleMillisecond(calendar3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Object obj7 = null;
        boolean boolean8 = fixedMillisecond6.equals(obj7);
        java.util.Date date9 = fixedMillisecond6.getStart();
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date9);
        int int11 = fixedMillisecond2.compareTo((java.lang.Object) serialDate10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = fixedMillisecond2.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass19 = fixedMillisecond18.getClass();
        java.lang.ClassLoader classLoader20 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass19);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar23 = null;
        long long24 = fixedMillisecond22.getMiddleMillisecond(calendar23);
        java.util.Date date25 = fixedMillisecond22.getTime();
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date25, timeZone26);
        java.io.InputStream inputStream28 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass19);
        java.io.InputStream inputStream29 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("org.jfree.data.general.SeriesChangeEvent[source=7]", (java.lang.Class) wildcardClass19);
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond2, "", "", (java.lang.Class) wildcardClass19);
        java.lang.Class class31 = timeSeries30.getTimePeriodClass();
        java.net.URL uRL32 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("org.jfree.data.general.SeriesException: ", class31);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(classLoader20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 100L + "'", long24 == 100L);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(inputStream28);
        org.junit.Assert.assertNull(inputStream29);
        org.junit.Assert.assertNotNull(class31);
        org.junit.Assert.assertNull(uRL32);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) (short) 10);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addDays((int) ' ', serialDate2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Object obj6 = null;
        boolean boolean7 = fixedMillisecond5.equals(obj6);
        java.util.Date date8 = fixedMillisecond5.getStart();
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date8);
        org.jfree.data.time.SerialDate serialDate10 = serialDate3.getEndOfCurrentMonth(serialDate9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate9);
        org.jfree.data.time.SerialDate serialDate12 = day11.getSerialDate();
        int int13 = day11.getDayOfMonth();
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 31 + "'", int13 == 31);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass2 = fixedMillisecond1.getClass();
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, class3);
        java.lang.Comparable comparable5 = timeSeries4.getKey();
        boolean boolean6 = timeSeries4.getNotify();
        timeSeries4.removeAgedItems(false);
        java.lang.Class class9 = timeSeries4.getTimePeriodClass();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(comparable5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(class9);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass2 = fixedMillisecond1.getClass();
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, class3);
        java.lang.Comparable comparable5 = timeSeries4.getKey();
        boolean boolean6 = timeSeries4.getNotify();
        timeSeries4.removeAgedItems(false);
        java.lang.String str9 = timeSeries4.getRangeDescription();
        try {
            timeSeries4.removeAgedItems((long) 11, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(comparable5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Value" + "'", str9.equals("Value"));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) (short) 10);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addDays((int) ' ', serialDate2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Object obj6 = null;
        boolean boolean7 = fixedMillisecond5.equals(obj6);
        java.util.Date date8 = fixedMillisecond5.getStart();
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date8);
        org.jfree.data.time.SerialDate serialDate10 = serialDate3.getEndOfCurrentMonth(serialDate9);
        try {
            org.jfree.data.time.SerialDate serialDate12 = serialDate3.getNearestDayOfWeek((-39));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass11 = fixedMillisecond10.getClass();
        java.lang.ClassLoader classLoader12 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond14.getMiddleMillisecond(calendar15);
        java.util.Date date17 = fixedMillisecond14.getTime();
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date17, timeZone18);
        java.io.InputStream inputStream20 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass11);
        java.io.InputStream inputStream21 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("org.jfree.data.general.SeriesChangeEvent[source=7]", (java.lang.Class) wildcardClass11);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod4, "org.jfree.data.general.SeriesChangeEvent[source=7]", "org.jfree.data.general.SeriesChangeEvent[source=7]", (java.lang.Class) wildcardClass11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond24.getMiddleMillisecond(calendar25);
        java.util.Date date27 = fixedMillisecond24.getTime();
        java.util.Calendar calendar28 = null;
        long long29 = fixedMillisecond24.getFirstMillisecond(calendar28);
        java.util.Calendar calendar30 = null;
        fixedMillisecond24.peg(calendar30);
        long long32 = fixedMillisecond24.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries22.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass36 = fixedMillisecond35.getClass();
        java.lang.Class class37 = null;
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond35, class37);
        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries22.addAndOrUpdate(timeSeries38);
        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar42 = null;
        long long43 = fixedMillisecond41.getMiddleMillisecond(calendar42);
        java.util.Date date44 = fixedMillisecond41.getTime();
        java.util.Calendar calendar45 = null;
        fixedMillisecond41.peg(calendar45);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = fixedMillisecond41.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries22.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond41, (double) (byte) 10);
        org.jfree.data.time.Month month50 = new org.jfree.data.time.Month();
        long long51 = month50.getLastMillisecond();
        java.text.DateFormatSymbols dateFormatSymbols52 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        int int53 = month50.compareTo((java.lang.Object) dateFormatSymbols52);
        long long54 = month50.getSerialIndex();
        java.lang.String str55 = month50.toString();
        org.jfree.data.time.FixedMillisecond fixedMillisecond57 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar58 = null;
        long long59 = fixedMillisecond57.getMiddleMillisecond(calendar58);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = fixedMillisecond57.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond66 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass67 = fixedMillisecond66.getClass();
        java.lang.ClassLoader classLoader68 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass67);
        org.jfree.data.time.FixedMillisecond fixedMillisecond70 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar71 = null;
        long long72 = fixedMillisecond70.getMiddleMillisecond(calendar71);
        java.util.Date date73 = fixedMillisecond70.getTime();
        java.util.TimeZone timeZone74 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass67, date73, timeZone74);
        java.io.InputStream inputStream76 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass67);
        java.io.InputStream inputStream77 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("org.jfree.data.general.SeriesChangeEvent[source=7]", (java.lang.Class) wildcardClass67);
        org.jfree.data.time.TimeSeries timeSeries78 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod60, "org.jfree.data.general.SeriesChangeEvent[source=7]", "org.jfree.data.general.SeriesChangeEvent[source=7]", (java.lang.Class) wildcardClass67);
        int int79 = timeSeries78.getItemCount();
        java.lang.String str80 = timeSeries78.getDomainDescription();
        boolean boolean81 = month50.equals((java.lang.Object) timeSeries78);
        timeSeries78.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries83 = timeSeries22.addAndOrUpdate(timeSeries78);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod84 = timeSeries78.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(classLoader12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 100L + "'", long16 == 100L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(inputStream20);
        org.junit.Assert.assertNull(inputStream21);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 100L + "'", long26 == 100L);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 100L + "'", long29 == 100L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 100L + "'", long32 == 100L);
        org.junit.Assert.assertNull(timeSeriesDataItem33);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNotNull(timeSeries39);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 100L + "'", long43 == 100L);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(regularTimePeriod47);
        org.junit.Assert.assertNull(timeSeriesDataItem49);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1561964399999L + "'", long51 == 1561964399999L);
        org.junit.Assert.assertNotNull(dateFormatSymbols52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 24234L + "'", long54 == 24234L);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "June 2019" + "'", str55.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 100L + "'", long59 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod60);
        org.junit.Assert.assertNotNull(wildcardClass67);
        org.junit.Assert.assertNotNull(classLoader68);
        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 100L + "'", long72 == 100L);
        org.junit.Assert.assertNotNull(date73);
        org.junit.Assert.assertNotNull(timeZone74);
        org.junit.Assert.assertNull(regularTimePeriod75);
        org.junit.Assert.assertNotNull(inputStream76);
        org.junit.Assert.assertNull(inputStream77);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 0 + "'", int79 == 0);
        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=7]" + "'", str80.equals("org.jfree.data.general.SeriesChangeEvent[source=7]"));
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNotNull(timeSeries83);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass2 = fixedMillisecond1.getClass();
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, class3);
        int int5 = timeSeries4.getMaximumItemCount();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass8 = fixedMillisecond7.getClass();
        java.lang.Class class9 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond7, class9);
        timeSeries10.setDescription("31-December-1969");
        long long13 = timeSeries10.getMaximumItemAge();
        java.util.Collection collection14 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass17 = fixedMillisecond16.getClass();
        java.lang.ClassLoader classLoader18 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar21 = null;
        long long22 = fixedMillisecond20.getMiddleMillisecond(calendar21);
        java.util.Date date23 = fixedMillisecond20.getTime();
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date23, timeZone24);
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date23, timeZone26);
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar30 = null;
        long long31 = fixedMillisecond29.getMiddleMillisecond(calendar30);
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Object obj34 = null;
        boolean boolean35 = fixedMillisecond33.equals(obj34);
        java.util.Date date36 = fixedMillisecond33.getStart();
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.createInstance(date36);
        int int38 = fixedMillisecond29.compareTo((java.lang.Object) serialDate37);
        int int39 = year27.compareTo((java.lang.Object) serialDate37);
        long long40 = year27.getLastMillisecond();
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) year27);
        java.util.Calendar calendar42 = null;
        try {
            year27.peg(calendar42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 9223372036854775807L + "'", long13 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection14);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(classLoader18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 100L + "'", long22 == 100L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 100L + "'", long31 == 100L);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 28799999L + "'", long40 == 28799999L);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond6.getMiddleMillisecond(calendar7);
        java.util.Date date9 = fixedMillisecond6.getTime();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date9);
        long long11 = year10.getLastMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass16 = fixedMillisecond15.getClass();
        java.lang.Object obj17 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ClassContext", (java.lang.Class) wildcardClass16);
        java.net.URL uRL18 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", (java.lang.Class) wildcardClass16);
        int int19 = year10.compareTo((java.lang.Object) wildcardClass16);
        java.lang.Object obj20 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("hi!", (java.lang.Class) wildcardClass16);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "2-January-1900", "ThreadContext", (java.lang.Class) wildcardClass16);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28799999L + "'", long11 == 28799999L);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNull(obj17);
        org.junit.Assert.assertNotNull(uRL18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNull(obj20);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        long long6 = year5.getLastMillisecond();
        long long7 = year5.getFirstMillisecond();
        int int9 = year5.compareTo((java.lang.Object) '4');
        long long10 = year5.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 28799999L + "'", long6 == 28799999L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-31507200000L) + "'", long7 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1969L + "'", long10 == 1969L);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getMiddleMillisecond(calendar8);
        java.util.Date date10 = fixedMillisecond7.getTime();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date10);
        long long12 = year11.getLastMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass17 = fixedMillisecond16.getClass();
        java.lang.Object obj18 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ClassContext", (java.lang.Class) wildcardClass17);
        java.net.URL uRL19 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", (java.lang.Class) wildcardClass17);
        int int20 = year11.compareTo((java.lang.Object) wildcardClass17);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass17);
        int int22 = timeSeries21.getMaximumItemCount();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener23 = null;
        timeSeries21.removeChangeListener(seriesChangeListener23);
        timeSeries21.setDomainDescription("ERROR : Relative To String");
        timeSeries21.setDescription("July 2019");
        java.util.Collection collection29 = timeSeries21.getTimePeriods();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28799999L + "'", long12 == 28799999L);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNull(obj18);
        org.junit.Assert.assertNotNull(uRL19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2147483647 + "'", int22 == 2147483647);
        org.junit.Assert.assertNotNull(collection29);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((int) ' ');
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond1.getFirstMillisecond(calendar5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond1.next();
        java.lang.String str8 = fixedMillisecond1.toString();
        java.util.Calendar calendar9 = null;
        fixedMillisecond1.peg(calendar9);
        java.lang.String str11 = fixedMillisecond1.toString();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str8.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str11.equals("Wed Dec 31 16:00:00 PST 1969"));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass11 = fixedMillisecond10.getClass();
        java.lang.ClassLoader classLoader12 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond14.getMiddleMillisecond(calendar15);
        java.util.Date date17 = fixedMillisecond14.getTime();
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date17, timeZone18);
        java.io.InputStream inputStream20 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass11);
        java.io.InputStream inputStream21 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("org.jfree.data.general.SeriesChangeEvent[source=7]", (java.lang.Class) wildcardClass11);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod4, "org.jfree.data.general.SeriesChangeEvent[source=7]", "org.jfree.data.general.SeriesChangeEvent[source=7]", (java.lang.Class) wildcardClass11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries22.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (java.lang.Number) 1561964399999L);
        java.beans.PropertyChangeListener propertyChangeListener27 = null;
        timeSeries22.removePropertyChangeListener(propertyChangeListener27);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(classLoader12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 100L + "'", long16 == 100L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(inputStream20);
        org.junit.Assert.assertNull(inputStream21);
        org.junit.Assert.assertNull(timeSeriesDataItem26);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Object obj6 = null;
        boolean boolean7 = fixedMillisecond5.equals(obj6);
        java.util.Date date8 = fixedMillisecond5.getStart();
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date8);
        int int10 = fixedMillisecond1.compareTo((java.lang.Object) serialDate9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond1.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass18 = fixedMillisecond17.getClass();
        java.lang.ClassLoader classLoader19 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar22 = null;
        long long23 = fixedMillisecond21.getMiddleMillisecond(calendar22);
        java.util.Date date24 = fixedMillisecond21.getTime();
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date24, timeZone25);
        java.io.InputStream inputStream27 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass18);
        java.io.InputStream inputStream28 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("org.jfree.data.general.SeriesChangeEvent[source=7]", (java.lang.Class) wildcardClass18);
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, "", "", (java.lang.Class) wildcardClass18);
        java.lang.Class class30 = timeSeries29.getTimePeriodClass();
        java.lang.ClassLoader classLoader31 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class30);
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader31);
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader31);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(classLoader19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 100L + "'", long23 == 100L);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(inputStream27);
        org.junit.Assert.assertNull(inputStream28);
        org.junit.Assert.assertNotNull(class30);
        org.junit.Assert.assertNotNull(classLoader31);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Object obj6 = null;
        boolean boolean7 = fixedMillisecond5.equals(obj6);
        java.util.Date date8 = fixedMillisecond5.getStart();
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date8);
        int int10 = fixedMillisecond1.compareTo((java.lang.Object) serialDate9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond1.previous();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        java.lang.Object obj15 = null;
        int int16 = day14.compareTo(obj15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass19 = fixedMillisecond18.getClass();
        java.lang.ClassLoader classLoader20 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass19);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar23 = null;
        long long24 = fixedMillisecond22.getMiddleMillisecond(calendar23);
        java.util.Date date25 = fixedMillisecond22.getTime();
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date25, timeZone26);
        boolean boolean28 = day14.equals((java.lang.Object) date25);
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass36 = fixedMillisecond35.getClass();
        java.lang.ClassLoader classLoader37 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass36);
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar40 = null;
        long long41 = fixedMillisecond39.getMiddleMillisecond(calendar40);
        java.util.Date date42 = fixedMillisecond39.getTime();
        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date42, timeZone43);
        java.io.InputStream inputStream45 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass36);
        java.io.InputStream inputStream46 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("org.jfree.data.general.SeriesChangeEvent[source=7]", (java.lang.Class) wildcardClass36);
        java.io.InputStream inputStream47 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("June", (java.lang.Class) wildcardClass36);
        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean28, "Sunday", "Second", (java.lang.Class) wildcardClass36);
        java.net.URL uRL49 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", (java.lang.Class) wildcardClass36);
        java.lang.Class class50 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass36);
        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond(100L);
        java.lang.Class<?> wildcardClass55 = fixedMillisecond54.getClass();
        java.lang.Object obj56 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ClassContext", (java.lang.Class) wildcardClass55);
        java.net.URL uRL57 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", (java.lang.Class) wildcardClass55);
        java.lang.Object obj58 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("June 2019", (java.lang.Class) wildcardClass36, (java.lang.Class) wildcardClass55);
        org.jfree.data.time.TimeSeries timeSeries59 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod11, (java.lang.Class) wildcardClass36);
        java.util.Collection collection60 = timeSeries59.getTimePeriods();
        java.util.List list61 = timeSeries59.getItems();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(classLoader20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 100L + "'", long24 == 100L);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNotNull(classLoader37);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 100L + "'", long41 == 100L);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(timeZone43);
        org.junit.Assert.assertNull(regularTimePeriod44);
        org.junit.Assert.assertNotNull(inputStream45);
        org.junit.Assert.assertNull(inputStream46);
        org.junit.Assert.assertNull(inputStream47);
        org.junit.Assert.assertNull(uRL49);
        org.junit.Assert.assertNotNull(class50);
        org.junit.Assert.assertNotNull(wildcardClass55);
        org.junit.Assert.assertNull(obj56);
        org.junit.Assert.assertNotNull(uRL57);
        org.junit.Assert.assertNull(obj58);
        org.junit.Assert.assertNotNull(collection60);
        org.junit.Assert.assertNotNull(list61);
    }
}

