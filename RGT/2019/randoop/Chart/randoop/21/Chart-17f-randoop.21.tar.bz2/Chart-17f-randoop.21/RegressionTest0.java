import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        int int0 = org.jfree.data.time.SerialDate.MONDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addMonths((-1), serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        int int0 = org.jfree.data.time.SerialDate.TUESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = null;
        try {
            timeSeries4.add(timeSeriesDataItem5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries4.getDataItem((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        int int0 = org.jfree.data.time.SerialDate.LAST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("");
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.CLASS_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ClassContext" + "'", str0.equals("ClassContext"));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        int int0 = org.jfree.data.time.SerialDate.FIRST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "" + "'", str0.equals(""));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(100, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((int) (short) 10);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries4.getDataItem(regularTimePeriod8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.clear();
        timeSeries4.setKey((java.lang.Comparable) 100);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        int int0 = org.jfree.data.time.SerialDate.MINIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1900 + "'", int0 == 1900);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(100, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        java.lang.Class class1 = null;
        java.lang.Object obj2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ClassContext", class1);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        int int0 = org.jfree.data.time.SerialDate.NEAREST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addMonths(1, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        java.lang.ClassLoader classLoader0 = null;
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) '#', serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((-1), serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        java.lang.Class class0 = null;
        try {
            java.lang.ClassLoader classLoader1 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = null;
        try {
            timeSeries4.add(regularTimePeriod8, (double) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = null;
        try {
            timeSeries4.delete(regularTimePeriod5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.clear();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        try {
            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) year6, (double) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        java.lang.ClassLoader classLoader0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
        org.junit.Assert.assertNull(classLoader0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        int int0 = org.jfree.data.time.SerialDate.FOURTH_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries4.getDataItem(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_BOTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-460) + "'", int1 == (-460));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_UPPER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2958465 + "'", int0 == 2958465);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries2.removeChangeListener(seriesChangeListener5);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResource("", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str5 = timeSeries2.getDescription();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        try {
            timeSeries2.update((org.jfree.data.time.RegularTimePeriod) year6, (java.lang.Number) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str5.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ClassContext", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = null;
        try {
            timeSeries4.add(timeSeriesDataItem11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem10);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(1, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        java.util.Collection collection0 = null;
        try {
            java.util.Collection collection1 = org.jfree.chart.util.ObjectUtilities.deepClone(collection0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'collection' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        int int0 = org.jfree.data.time.SerialDate.WEDNESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Calendar calendar1 = null;
        try {
            year0.peg(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries2.setDomainDescription("");
        java.lang.String str7 = timeSeries2.getDomainDescription();
        timeSeries2.setDescription("hi!");
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        try {
            timeSeries2.add((org.jfree.data.time.RegularTimePeriod) year10, (double) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "October" + "'", str1.equals("October"));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        try {
            java.lang.Number number12 = timeSeries4.getValue((-460));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem10);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_FIRST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(8);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 8");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries4.addChangeListener(seriesChangeListener6);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        int int10 = year8.compareTo((java.lang.Object) "");
        try {
            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) year8, (java.lang.Number) 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.THREAD_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (byte) 1, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        java.util.Date date11 = fixedMillisecond9.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        java.util.Calendar calendar13 = null;
        try {
            long long14 = day12.getFirstMillisecond(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNotNull(date11);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(0, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        int int13 = year11.compareTo((java.lang.Object) "");
        long long14 = year11.getFirstMillisecond();
        int int15 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) year11);
        timeSeries4.setDomainDescription("org.jfree.data.general.SeriesException: ");
        java.lang.Class class21 = null;
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class21);
        timeSeries22.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timeSeries22.addPropertyChangeListener(propertyChangeListener24);
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries22.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
        try {
            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, (-1.0d), true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem28);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year0.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        java.util.Date date11 = fixedMillisecond9.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        java.util.Calendar calendar13 = null;
        try {
            day12.peg(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNotNull(date11);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3, 0.0d, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(class2);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        int int0 = org.jfree.data.time.SerialDate.THURSDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((-460));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(6, (-460), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class8);
        timeSeries9.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries9.addPropertyChangeListener(propertyChangeListener11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
        try {
            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (java.lang.Number) 9, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem15);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addMonths((int) 'a', serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(4);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Fourth" + "'", str1.equals("Fourth"));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear((int) '#');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10, 10, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        java.util.Calendar calendar4 = null;
        try {
            long long5 = month3.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        java.util.Date date11 = fixedMillisecond9.getEnd();
        java.util.Date date12 = fixedMillisecond9.getTime();
        java.util.TimeZone timeZone13 = null;
        try {
            org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date12, timeZone13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date12);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(2019);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 29 + "'", int1 == 29);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries2.removePropertyChangeListener(propertyChangeListener3);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        try {
            timeSeries2.add((org.jfree.data.time.RegularTimePeriod) year5, (double) 1.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((int) (short) 100, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        int int13 = year11.compareTo((java.lang.Object) "");
        long long14 = year11.getFirstMillisecond();
        int int15 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) year11);
        timeSeries4.setDomainDescription("org.jfree.data.general.SeriesException: ");
        try {
            timeSeries4.update((int) 'a', (java.lang.Number) 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        java.lang.String[] strArray0 = org.jfree.data.time.SerialDate.getMonths();
        org.junit.Assert.assertNotNull(strArray0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (byte) 10);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries2.setDomainDescription("");
        java.lang.Class class7 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class12);
        timeSeries13.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        int int22 = year20.compareTo((java.lang.Object) "");
        long long23 = year20.getFirstMillisecond();
        int int24 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) year20);
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class28);
        timeSeries29.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timeSeries29.addPropertyChangeListener(propertyChangeListener31);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
        java.util.Date date36 = fixedMillisecond34.getEnd();
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date36);
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) year20, (org.jfree.data.time.RegularTimePeriod) day37);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = timeSeries38.getTimePeriod((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1546329600000L + "'", long23 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeSeries38);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries2.setDomainDescription("");
        java.lang.String str7 = timeSeries2.getDomainDescription();
        timeSeries2.setDescription("hi!");
        try {
            timeSeries2.delete((-1), (-460));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(2);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(1);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Following" + "'", str1.equals("Following"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        boolean boolean0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        int int0 = org.jfree.data.time.SerialDate.FOLLOWING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries2.setDomainDescription("");
        java.lang.Class class7 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class12);
        timeSeries13.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        int int22 = year20.compareTo((java.lang.Object) "");
        long long23 = year20.getFirstMillisecond();
        int int24 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) year20);
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class28);
        timeSeries29.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timeSeries29.addPropertyChangeListener(propertyChangeListener31);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
        java.util.Date date36 = fixedMillisecond34.getEnd();
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date36);
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) year20, (org.jfree.data.time.RegularTimePeriod) day37);
        java.lang.Class class41 = null;
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class41);
        java.lang.Class<?> wildcardClass43 = timeSeries42.getClass();
        java.util.Date date44 = null;
        java.util.TimeZone timeZone45 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass43, date44, timeZone45);
        java.lang.ClassLoader classLoader47 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass43);
        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2, (java.lang.Class) wildcardClass43);
        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day37, (java.lang.Class) wildcardClass43);
        long long50 = day37.getLastMillisecond();
        java.util.Calendar calendar51 = null;
        try {
            day37.peg(calendar51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1546329600000L + "'", long23 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeSeries38);
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertNull(regularTimePeriod46);
        org.junit.Assert.assertNotNull(classLoader47);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 28799999L + "'", long50 == 28799999L);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) "");
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year0.getMiddleMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        boolean boolean8 = timeSeries4.isEmpty();
        try {
            timeSeries4.update(5, (java.lang.Number) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((-1), false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = year0.getMiddleMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        try {
            timeSeries1.update(29, (java.lang.Number) 25568L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 29, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        java.lang.Class class4 = null;
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class6);
        java.lang.Class<?> wildcardClass8 = timeSeries7.getClass();
        java.lang.Object obj9 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ClassContext", class4, (java.lang.Class) wildcardClass8);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "org.jfree.data.general.SeriesChangeEvent[source=SerialDate.weekInMonthToString(): invalid code.]", class4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNull(obj9);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.clear();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries4.addChangeListener(seriesChangeListener6);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class2);
        java.lang.Class<?> wildcardClass4 = timeSeries3.getClass();
        java.util.Date date5 = null;
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date5, timeZone6);
        java.lang.ClassLoader classLoader8 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass4);
        java.net.URL uRL9 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ClassContext", (java.lang.Class) wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(classLoader8);
        org.junit.Assert.assertNull(uRL9);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class4);
        timeSeries5.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries5.addPropertyChangeListener(propertyChangeListener7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries5.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        int int14 = year12.compareTo((java.lang.Object) "");
        long long15 = year12.getFirstMillisecond();
        int int16 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) year12);
        try {
            org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(0, year12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1546329600000L + "'", long15 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str5 = timeSeries2.getDescription();
        timeSeries2.setMaximumItemAge((long) 11);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        long long9 = year8.getLastMillisecond();
        java.util.Date date10 = year8.getStart();
        try {
            timeSeries2.add((org.jfree.data.time.RegularTimePeriod) year8, (java.lang.Number) (byte) 0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str5.equals("SerialDate.weekInMonthToString(): invalid code."));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertNotNull(date10);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear((-1));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((int) '#');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-451) + "'", int1 == (-451));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries2.setDomainDescription("");
        java.lang.Class class7 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class12);
        timeSeries13.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        int int22 = year20.compareTo((java.lang.Object) "");
        long long23 = year20.getFirstMillisecond();
        int int24 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) year20);
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class28);
        timeSeries29.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timeSeries29.addPropertyChangeListener(propertyChangeListener31);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
        java.util.Date date36 = fixedMillisecond34.getEnd();
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date36);
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) year20, (org.jfree.data.time.RegularTimePeriod) day37);
        org.jfree.data.time.SerialDate serialDate39 = day37.getSerialDate();
        try {
            org.jfree.data.time.SerialDate serialDate41 = serialDate39.getFollowingDayOfWeek((-451));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1546329600000L + "'", long23 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeSeries38);
        org.junit.Assert.assertNotNull(serialDate39);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class2);
        timeSeries3.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries3.setDomainDescription("");
        java.lang.Class class8 = timeSeries3.getTimePeriodClass();
        timeSeries3.clear();
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class13);
        timeSeries14.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries14.addPropertyChangeListener(propertyChangeListener16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries14.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        int int23 = year21.compareTo((java.lang.Object) "");
        long long24 = year21.getFirstMillisecond();
        int int25 = timeSeries14.getIndex((org.jfree.data.time.RegularTimePeriod) year21);
        java.lang.Class class29 = null;
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class29);
        timeSeries30.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener32 = null;
        timeSeries30.addPropertyChangeListener(propertyChangeListener32);
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries30.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
        java.util.Date date37 = fixedMillisecond35.getEnd();
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date37);
        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year21, (org.jfree.data.time.RegularTimePeriod) day38);
        org.jfree.data.time.SerialDate serialDate40 = day38.getSerialDate();
        try {
            org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(0, serialDate40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1546329600000L + "'", long24 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(timeSeries39);
        org.junit.Assert.assertNotNull(serialDate40);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        int int0 = org.jfree.data.time.SerialDate.SECOND_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 32");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(10);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries2.setDomainDescription("");
        java.lang.Class class7 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class12);
        timeSeries13.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        int int22 = year20.compareTo((java.lang.Object) "");
        long long23 = year20.getFirstMillisecond();
        int int24 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) year20);
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class28);
        timeSeries29.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timeSeries29.addPropertyChangeListener(propertyChangeListener31);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
        java.util.Date date36 = fixedMillisecond34.getEnd();
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date36);
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) year20, (org.jfree.data.time.RegularTimePeriod) day37);
        try {
            timeSeries2.update(0, (java.lang.Number) 11);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1546329600000L + "'", long23 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeSeries38);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries2.setDomainDescription("");
        java.lang.Class class7 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class12);
        timeSeries13.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        int int22 = year20.compareTo((java.lang.Object) "");
        long long23 = year20.getFirstMillisecond();
        int int24 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) year20);
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class28);
        timeSeries29.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timeSeries29.addPropertyChangeListener(propertyChangeListener31);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
        java.util.Date date36 = fixedMillisecond34.getEnd();
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date36);
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) year20, (org.jfree.data.time.RegularTimePeriod) day37);
        org.jfree.data.time.SerialDate serialDate39 = day37.getSerialDate();
        try {
            org.jfree.data.time.SerialDate serialDate41 = serialDate39.getFollowingDayOfWeek(12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1546329600000L + "'", long23 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeSeries38);
        org.junit.Assert.assertNotNull(serialDate39);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths(true);
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries4.addChangeListener(seriesChangeListener6);
        java.lang.Class class9 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class9);
        timeSeries10.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries10.setDomainDescription("");
        java.lang.Class class15 = timeSeries10.getTimePeriodClass();
        timeSeries10.clear();
        java.lang.Class class20 = null;
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class20);
        timeSeries21.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener23 = null;
        timeSeries21.addPropertyChangeListener(propertyChangeListener23);
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries21.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        int int30 = year28.compareTo((java.lang.Object) "");
        long long31 = year28.getFirstMillisecond();
        int int32 = timeSeries21.getIndex((org.jfree.data.time.RegularTimePeriod) year28);
        java.lang.Class class36 = null;
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class36);
        timeSeries37.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener39 = null;
        timeSeries37.addPropertyChangeListener(propertyChangeListener39);
        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries37.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond42);
        java.util.Date date44 = fixedMillisecond42.getEnd();
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date44);
        org.jfree.data.time.TimeSeries timeSeries46 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) year28, (org.jfree.data.time.RegularTimePeriod) day45);
        long long47 = day45.getFirstMillisecond();
        boolean boolean49 = day45.equals((java.lang.Object) 1577865599999L);
        long long50 = day45.getSerialIndex();
        try {
            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) day45, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(class15);
        org.junit.Assert.assertNull(timeSeriesDataItem27);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1546329600000L + "'", long31 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem43);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(timeSeries46);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + (-57600000L) + "'", long47 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 25568L + "'", long50 == 25568L);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("SerialDate.weekInMonthToString(): invalid code.");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-459) + "'", int1 == (-459));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.clear();
        java.lang.Class class9 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class9);
        timeSeries10.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries10.addPropertyChangeListener(propertyChangeListener12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries10.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.util.Date date17 = fixedMillisecond15.getEnd();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        long long19 = year18.getLastMillisecond();
        boolean boolean20 = fixedMillisecond15.equals((java.lang.Object) year18);
        int int22 = fixedMillisecond15.compareTo((java.lang.Object) 1577865599999L);
        java.lang.Number number23 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.lang.Class class27 = null;
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class27);
        java.lang.Class class32 = null;
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class32);
        timeSeries33.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener35 = null;
        timeSeries33.addPropertyChangeListener(propertyChangeListener35);
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries33.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond38);
        java.util.Date date40 = fixedMillisecond38.getEnd();
        java.util.Date date41 = fixedMillisecond38.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries28.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond38, (double) 2958465);
        try {
            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond38, (double) (byte) 1, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1577865599999L + "'", long19 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNull(number23);
        org.junit.Assert.assertNull(timeSeriesDataItem39);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNull(timeSeriesDataItem43);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_LOWER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str5 = timeSeries2.getDescription();
        timeSeries2.setMaximumItemAge((long) 11);
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries2.removePropertyChangeListener(propertyChangeListener8);
        try {
            timeSeries2.update(8, (java.lang.Number) 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str5.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        int int0 = org.jfree.data.time.SerialDate.SATURDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries2.setDomainDescription("");
        java.lang.Class class7 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class12);
        timeSeries13.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        int int22 = year20.compareTo((java.lang.Object) "");
        long long23 = year20.getFirstMillisecond();
        int int24 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) year20);
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class28);
        timeSeries29.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timeSeries29.addPropertyChangeListener(propertyChangeListener31);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
        java.util.Date date36 = fixedMillisecond34.getEnd();
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date36);
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) year20, (org.jfree.data.time.RegularTimePeriod) day37);
        org.jfree.data.time.SerialDate serialDate39 = day37.getSerialDate();
        try {
            org.jfree.data.time.SerialDate serialDate41 = serialDate39.getNearestDayOfWeek((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1546329600000L + "'", long23 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeSeries38);
        org.junit.Assert.assertNotNull(serialDate39);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = null;
        try {
            timeSeries1.add(timeSeriesDataItem2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("ERROR : Relative To String");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries4.addChangeListener(seriesChangeListener6);
        try {
            timeSeries4.removeAgedItems((long) (byte) 0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str5 = timeSeries2.getDescription();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getLastMillisecond();
        long long8 = year6.getSerialIndex();
        int int9 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) year6);
        java.util.Calendar calendar10 = null;
        try {
            long long11 = year6.getLastMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str5.equals("SerialDate.weekInMonthToString(): invalid code."));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        int int13 = year11.compareTo((java.lang.Object) "");
        long long14 = year11.getFirstMillisecond();
        int int15 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) year11);
        java.lang.String str16 = timeSeries4.getDomainDescription();
        timeSeries4.setMaximumItemCount((int) (byte) 10);
        long long19 = timeSeries4.getMaximumItemAge();
        java.lang.Class class23 = null;
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class23);
        timeSeries24.clear();
        java.lang.Class class29 = null;
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class29);
        timeSeries30.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener32 = null;
        timeSeries30.addPropertyChangeListener(propertyChangeListener32);
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries30.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
        java.util.Date date37 = fixedMillisecond35.getEnd();
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
        long long39 = year38.getLastMillisecond();
        boolean boolean40 = fixedMillisecond35.equals((java.lang.Object) year38);
        int int42 = fixedMillisecond35.compareTo((java.lang.Object) 1577865599999L);
        java.lang.Number number43 = timeSeries24.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35, 10.0d);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = null;
        try {
            timeSeries4.add(timeSeriesDataItem46, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 9223372036854775807L + "'", long19 == 9223372036854775807L);
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1577865599999L + "'", long39 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertNull(number43);
        org.junit.Assert.assertNull(timeSeriesDataItem45);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class2);
        timeSeries3.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries3.setDomainDescription("");
        java.lang.Class class8 = timeSeries3.getTimePeriodClass();
        timeSeries3.clear();
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class13);
        timeSeries14.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries14.addPropertyChangeListener(propertyChangeListener16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries14.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        int int23 = year21.compareTo((java.lang.Object) "");
        long long24 = year21.getFirstMillisecond();
        int int25 = timeSeries14.getIndex((org.jfree.data.time.RegularTimePeriod) year21);
        java.lang.Class class29 = null;
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class29);
        timeSeries30.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener32 = null;
        timeSeries30.addPropertyChangeListener(propertyChangeListener32);
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries30.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
        java.util.Date date37 = fixedMillisecond35.getEnd();
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date37);
        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year21, (org.jfree.data.time.RegularTimePeriod) day38);
        org.jfree.data.time.SerialDate serialDate40 = day38.getSerialDate();
        org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.addMonths(29, serialDate40);
        try {
            org.jfree.data.time.SerialDate serialDate43 = serialDate41.getNearestDayOfWeek(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1546329600000L + "'", long24 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(timeSeries39);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertNotNull(serialDate41);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((int) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries2.setDomainDescription("");
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        int int9 = year7.compareTo((java.lang.Object) "");
        long long10 = year7.getFirstMillisecond();
        try {
            timeSeries2.add((org.jfree.data.time.RegularTimePeriod) year7, (double) (byte) 1, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries6 = null;
        try {
            java.util.Collection collection7 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(2019, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        java.util.Date date11 = fixedMillisecond9.getEnd();
        int int13 = fixedMillisecond9.compareTo((java.lang.Object) "SerialDate.weekInMonthToString(): invalid code.");
        long long14 = fixedMillisecond9.getFirstMillisecond();
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        java.lang.Class class1 = null;
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class3);
        java.lang.Class<?> wildcardClass5 = timeSeries4.getClass();
        java.lang.Object obj6 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ClassContext", class1, (java.lang.Class) wildcardClass5);
        java.util.Date date7 = null;
        java.util.TimeZone timeZone8 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance(class1, date7, timeZone8);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(obj6);
        org.junit.Assert.assertNull(regularTimePeriod9);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ERROR : Relative To String", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(11, (int) (short) -1, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_SECOND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        java.text.DateFormatSymbols dateFormatSymbols0 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        org.junit.Assert.assertNotNull(dateFormatSymbols0);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        boolean boolean8 = timeSeries4.isEmpty();
        boolean boolean9 = timeSeries4.getNotify();
        try {
            timeSeries4.setMaximumItemCount((-460));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'maximum' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries2.setDomainDescription("");
        java.lang.Class class7 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class12);
        timeSeries13.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        int int22 = year20.compareTo((java.lang.Object) "");
        long long23 = year20.getFirstMillisecond();
        int int24 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) year20);
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class28);
        timeSeries29.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timeSeries29.addPropertyChangeListener(propertyChangeListener31);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
        java.util.Date date36 = fixedMillisecond34.getEnd();
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date36);
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) year20, (org.jfree.data.time.RegularTimePeriod) day37);
        int int39 = timeSeries2.getItemCount();
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1546329600000L + "'", long23 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeSeries38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(2019, 29);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2019");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        java.util.TimeZone timeZone3 = null;
        try {
            org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date2, timeZone3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries4.addChangeListener(seriesChangeListener6);
        java.lang.Class class8 = null;
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class12);
        timeSeries13.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        java.util.Date date20 = fixedMillisecond18.getEnd();
        java.util.TimeZone timeZone21 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class8, date20, timeZone21);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond(date20);
        try {
            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, (java.lang.Number) 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNull(regularTimePeriod22);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        java.util.Date date11 = fixedMillisecond9.getEnd();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getLastMillisecond();
        boolean boolean14 = fixedMillisecond9.equals((java.lang.Object) year12);
        java.util.Calendar calendar15 = null;
        try {
            long long16 = year12.getFirstMillisecond(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addDays((int) (short) -1, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries2.setDomainDescription("");
        java.lang.String str7 = timeSeries2.getDomainDescription();
        timeSeries2.setDescription("hi!");
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries2.getDataItem(7);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        java.lang.String str3 = year0.toString();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year0.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(2, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28 + "'", int2 == 28);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(9);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class5);
        timeSeries6.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries6.setDomainDescription("");
        java.lang.Class class11 = timeSeries6.getTimePeriodClass();
        timeSeries6.clear();
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class16);
        timeSeries17.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timeSeries17.addPropertyChangeListener(propertyChangeListener19);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries17.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        int int26 = year24.compareTo((java.lang.Object) "");
        long long27 = year24.getFirstMillisecond();
        int int28 = timeSeries17.getIndex((org.jfree.data.time.RegularTimePeriod) year24);
        java.lang.Class class32 = null;
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class32);
        timeSeries33.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener35 = null;
        timeSeries33.addPropertyChangeListener(propertyChangeListener35);
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries33.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond38);
        java.util.Date date40 = fixedMillisecond38.getEnd();
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date40);
        org.jfree.data.time.TimeSeries timeSeries42 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) year24, (org.jfree.data.time.RegularTimePeriod) day41);
        org.jfree.data.time.SerialDate serialDate43 = day41.getSerialDate();
        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.addMonths(29, serialDate43);
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(3, serialDate44);
        java.lang.String str46 = serialDate45.getDescription();
        org.jfree.data.time.SerialDate serialDate47 = org.jfree.data.time.SerialDate.addMonths((int) (short) 100, serialDate45);
        try {
            org.jfree.data.time.SerialDate serialDate48 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) '4', serialDate45);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(class11);
        org.junit.Assert.assertNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1546329600000L + "'", long27 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem39);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(timeSeries42);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertNull(str46);
        org.junit.Assert.assertNotNull(serialDate47);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.Class class7 = timeSeries6.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod2, "", "org.jfree.data.general.SeriesChangeEvent[source=SerialDate.weekInMonthToString(): invalid code.]", class7);
        java.lang.String str9 = regularTimePeriod2.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2018" + "'", str9.equals("2018"));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) 'a', 2, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(2958465, 2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2958465");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(8);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "August" + "'", str1.equals("August"));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str5 = timeSeries2.getDescription();
        timeSeries2.setMaximumItemAge((long) 11);
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries2.removePropertyChangeListener(propertyChangeListener8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        try {
            timeSeries2.add((org.jfree.data.time.RegularTimePeriod) year10, (double) 1546329600000L, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str5.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-460) + "'", int1 == (-460));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((int) (short) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-457) + "'", int1 == (-457));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        java.lang.Class class1 = null;
        java.lang.Object obj2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("hi!", class1);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class12);
        timeSeries13.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries13.setDomainDescription("");
        java.lang.Class class18 = timeSeries13.getTimePeriodClass();
        timeSeries13.clear();
        java.lang.Class class23 = null;
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class23);
        timeSeries24.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener26 = null;
        timeSeries24.addPropertyChangeListener(propertyChangeListener26);
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries24.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        int int33 = year31.compareTo((java.lang.Object) "");
        long long34 = year31.getFirstMillisecond();
        int int35 = timeSeries24.getIndex((org.jfree.data.time.RegularTimePeriod) year31);
        java.lang.Class class39 = null;
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class39);
        timeSeries40.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener42 = null;
        timeSeries40.addPropertyChangeListener(propertyChangeListener42);
        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = timeSeries40.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond45);
        java.util.Date date47 = fixedMillisecond45.getEnd();
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date47);
        org.jfree.data.time.TimeSeries timeSeries49 = timeSeries13.createCopy((org.jfree.data.time.RegularTimePeriod) year31, (org.jfree.data.time.RegularTimePeriod) day48);
        org.jfree.data.time.SerialDate serialDate50 = day48.getSerialDate();
        java.util.Date date51 = day48.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day48, (java.lang.Number) 1900);
        java.lang.Class class55 = null;
        org.jfree.data.time.TimeSeries timeSeries56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class55);
        timeSeries56.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str59 = timeSeries56.getDescription();
        timeSeries56.setMaximumItemAge((long) 11);
        java.beans.PropertyChangeListener propertyChangeListener62 = null;
        timeSeries56.removePropertyChangeListener(propertyChangeListener62);
        boolean boolean64 = timeSeriesDataItem53.equals((java.lang.Object) propertyChangeListener62);
        java.lang.Object obj65 = timeSeriesDataItem53.clone();
        try {
            timeSeries4.add(timeSeriesDataItem53);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNull(class18);
        org.junit.Assert.assertNull(timeSeriesDataItem30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1546329600000L + "'", long34 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem46);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(timeSeries49);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str59.equals("SerialDate.weekInMonthToString(): invalid code."));
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(obj65);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class2);
        timeSeries3.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries3.setDomainDescription("");
        java.lang.Class class8 = timeSeries3.getTimePeriodClass();
        timeSeries3.clear();
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class13);
        timeSeries14.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries14.addPropertyChangeListener(propertyChangeListener16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries14.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        int int23 = year21.compareTo((java.lang.Object) "");
        long long24 = year21.getFirstMillisecond();
        int int25 = timeSeries14.getIndex((org.jfree.data.time.RegularTimePeriod) year21);
        java.lang.Class class29 = null;
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class29);
        timeSeries30.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener32 = null;
        timeSeries30.addPropertyChangeListener(propertyChangeListener32);
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries30.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
        java.util.Date date37 = fixedMillisecond35.getEnd();
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date37);
        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year21, (org.jfree.data.time.RegularTimePeriod) day38);
        org.jfree.data.time.SerialDate serialDate40 = day38.getSerialDate();
        try {
            org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((-460), serialDate40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1546329600000L + "'", long24 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(timeSeries39);
        org.junit.Assert.assertNotNull(serialDate40);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        int int13 = year11.compareTo((java.lang.Object) "");
        long long14 = year11.getFirstMillisecond();
        int int15 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) year11);
        java.util.Calendar calendar16 = null;
        try {
            long long17 = year11.getLastMillisecond(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        java.lang.Class class0 = null;
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class4);
        timeSeries5.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries5.addPropertyChangeListener(propertyChangeListener7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries5.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
        java.util.Date date12 = fixedMillisecond10.getEnd();
        java.util.TimeZone timeZone13 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date12, timeZone13);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(date12);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date12);
        long long17 = year16.getFirstMillisecond();
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-31507200000L) + "'", long17 == (-31507200000L));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries2.setDomainDescription("");
        java.lang.Class class7 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class12);
        timeSeries13.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        int int22 = year20.compareTo((java.lang.Object) "");
        long long23 = year20.getFirstMillisecond();
        int int24 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) year20);
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class28);
        timeSeries29.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timeSeries29.addPropertyChangeListener(propertyChangeListener31);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
        java.util.Date date36 = fixedMillisecond34.getEnd();
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date36);
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) year20, (org.jfree.data.time.RegularTimePeriod) day37);
        long long39 = day37.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = day37.previous();
        java.util.Calendar calendar41 = null;
        try {
            long long42 = day37.getLastMillisecond(calendar41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1546329600000L + "'", long23 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeSeries38);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-57600000L) + "'", long39 == (-57600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod40);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) 'a', 7, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries2.setDomainDescription("");
        java.lang.Class class7 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class12);
        timeSeries13.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        int int22 = year20.compareTo((java.lang.Object) "");
        long long23 = year20.getFirstMillisecond();
        int int24 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) year20);
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class28);
        timeSeries29.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timeSeries29.addPropertyChangeListener(propertyChangeListener31);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
        java.util.Date date36 = fixedMillisecond34.getEnd();
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date36);
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) year20, (org.jfree.data.time.RegularTimePeriod) day37);
        java.util.Calendar calendar39 = null;
        try {
            long long40 = day37.getFirstMillisecond(calendar39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1546329600000L + "'", long23 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeSeries38);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        int int13 = year11.compareTo((java.lang.Object) "");
        long long14 = year11.getFirstMillisecond();
        int int15 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) year11);
        timeSeries4.setDomainDescription("org.jfree.data.general.SeriesException: ");
        boolean boolean18 = timeSeries4.isEmpty();
        java.lang.Class class20 = null;
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class20);
        timeSeries21.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries21.setDomainDescription("");
        java.lang.Class class26 = timeSeries21.getTimePeriodClass();
        timeSeries21.clear();
        java.lang.Class class31 = null;
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class31);
        timeSeries32.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener34 = null;
        timeSeries32.addPropertyChangeListener(propertyChangeListener34);
        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries32.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond37);
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
        int int41 = year39.compareTo((java.lang.Object) "");
        long long42 = year39.getFirstMillisecond();
        int int43 = timeSeries32.getIndex((org.jfree.data.time.RegularTimePeriod) year39);
        java.lang.Class class47 = null;
        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class47);
        timeSeries48.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener50 = null;
        timeSeries48.addPropertyChangeListener(propertyChangeListener50);
        org.jfree.data.time.FixedMillisecond fixedMillisecond53 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem54 = timeSeries48.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond53);
        java.util.Date date55 = fixedMillisecond53.getEnd();
        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day(date55);
        org.jfree.data.time.TimeSeries timeSeries57 = timeSeries21.createCopy((org.jfree.data.time.RegularTimePeriod) year39, (org.jfree.data.time.RegularTimePeriod) day56);
        org.jfree.data.time.SerialDate serialDate58 = day56.getSerialDate();
        java.util.Date date59 = day56.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem61 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day56, (java.lang.Number) 1900);
        java.lang.Class class63 = null;
        org.jfree.data.time.TimeSeries timeSeries64 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class63);
        timeSeries64.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str67 = timeSeries64.getDescription();
        timeSeries64.setMaximumItemAge((long) 11);
        java.beans.PropertyChangeListener propertyChangeListener70 = null;
        timeSeries64.removePropertyChangeListener(propertyChangeListener70);
        boolean boolean72 = timeSeriesDataItem61.equals((java.lang.Object) propertyChangeListener70);
        int int74 = timeSeriesDataItem61.compareTo((java.lang.Object) "October");
        try {
            timeSeries4.add(timeSeriesDataItem61, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNull(class26);
        org.junit.Assert.assertNull(timeSeriesDataItem38);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1546329600000L + "'", long42 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem54);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(timeSeries57);
        org.junit.Assert.assertNotNull(serialDate58);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str67.equals("SerialDate.weekInMonthToString(): invalid code."));
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 1 + "'", int74 == 1);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(7);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-458) + "'", int1 == (-458));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        java.util.Date date11 = fixedMillisecond9.getEnd();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getLastMillisecond();
        boolean boolean14 = fixedMillisecond9.equals((java.lang.Object) year12);
        int int16 = fixedMillisecond9.compareTo((java.lang.Object) 1577865599999L);
        int int18 = fixedMillisecond9.compareTo((java.lang.Object) 9);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class4);
        timeSeries5.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries5.setDomainDescription("");
        java.lang.Class class10 = timeSeries5.getTimePeriodClass();
        timeSeries5.clear();
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class15);
        timeSeries16.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timeSeries16.addPropertyChangeListener(propertyChangeListener18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries16.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        int int25 = year23.compareTo((java.lang.Object) "");
        long long26 = year23.getFirstMillisecond();
        int int27 = timeSeries16.getIndex((org.jfree.data.time.RegularTimePeriod) year23);
        java.lang.Class class31 = null;
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class31);
        timeSeries32.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener34 = null;
        timeSeries32.addPropertyChangeListener(propertyChangeListener34);
        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries32.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond37);
        java.util.Date date39 = fixedMillisecond37.getEnd();
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date39);
        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) year23, (org.jfree.data.time.RegularTimePeriod) day40);
        org.jfree.data.time.SerialDate serialDate42 = day40.getSerialDate();
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.addMonths(29, serialDate42);
        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(3, serialDate43);
        java.lang.String str45 = serialDate44.getDescription();
        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.addMonths((int) (short) 100, serialDate44);
        try {
            org.jfree.data.time.SerialDate serialDate48 = serialDate46.getFollowingDayOfWeek((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(class10);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1546329600000L + "'", long26 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem38);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(timeSeries41);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNull(str45);
        org.junit.Assert.assertNotNull(serialDate46);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class2);
        timeSeries3.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str6 = timeSeries3.getDescription();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getLastMillisecond();
        long long9 = year7.getSerialIndex();
        int int10 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) year7);
        java.lang.Class class18 = null;
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class18);
        java.lang.Class<?> wildcardClass20 = timeSeries19.getClass();
        java.util.Date date21 = null;
        java.util.TimeZone timeZone22 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass20, date21, timeZone22);
        java.lang.ClassLoader classLoader24 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass20);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2, (java.lang.Class) wildcardClass20);
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, "ThreadContext", "org.jfree.data.general.SeriesException: ", (java.lang.Class) wildcardClass20);
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year7, "Following", "Fourth", (java.lang.Class) wildcardClass20);
        try {
            org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(2147483647, year7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str6.equals("SerialDate.weekInMonthToString(): invalid code."));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2019L + "'", long9 == 2019L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(classLoader24);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str5 = timeSeries2.getDescription();
        try {
            timeSeries2.delete(7, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str5.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries2.setDomainDescription("");
        java.lang.Class class7 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class12);
        timeSeries13.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        int int22 = year20.compareTo((java.lang.Object) "");
        long long23 = year20.getFirstMillisecond();
        int int24 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) year20);
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class28);
        timeSeries29.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timeSeries29.addPropertyChangeListener(propertyChangeListener31);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
        java.util.Date date36 = fixedMillisecond34.getEnd();
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date36);
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) year20, (org.jfree.data.time.RegularTimePeriod) day37);
        java.lang.String str39 = day37.toString();
        int int40 = day37.getDayOfMonth();
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1546329600000L + "'", long23 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeSeries38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "31-December-1969" + "'", str39.equals("31-December-1969"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 31 + "'", int40 == 31);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(2958465);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        int int0 = org.jfree.data.time.SerialDate.THIRD_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_NONE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        java.util.Date date11 = fixedMillisecond9.getEnd();
        java.util.Date date12 = fixedMillisecond9.getTime();
        java.util.TimeZone timeZone13 = null;
        try {
            org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date12, timeZone13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date12);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond9.previous();
        java.lang.Number number11 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, number11);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = null;
        try {
            timeSeries4.add(timeSeriesDataItem13, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) "");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.next();
        int int5 = year0.compareTo((java.lang.Object) (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(29, 2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class2);
        timeSeries3.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries3.setDomainDescription("");
        java.lang.Class class8 = timeSeries3.getTimePeriodClass();
        timeSeries3.clear();
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class13);
        timeSeries14.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries14.addPropertyChangeListener(propertyChangeListener16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries14.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        int int23 = year21.compareTo((java.lang.Object) "");
        long long24 = year21.getFirstMillisecond();
        int int25 = timeSeries14.getIndex((org.jfree.data.time.RegularTimePeriod) year21);
        java.lang.Class class29 = null;
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class29);
        timeSeries30.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener32 = null;
        timeSeries30.addPropertyChangeListener(propertyChangeListener32);
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries30.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
        java.util.Date date37 = fixedMillisecond35.getEnd();
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date37);
        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year21, (org.jfree.data.time.RegularTimePeriod) day38);
        org.jfree.data.time.SerialDate serialDate40 = day38.getSerialDate();
        org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.addMonths(29, serialDate40);
        try {
            org.jfree.data.time.SerialDate serialDate43 = serialDate41.getPreviousDayOfWeek(1900);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1546329600000L + "'", long24 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(timeSeries39);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertNotNull(serialDate41);
    }

//    @Test
//    public void test193() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test193");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560441401245L + "'", long1 == 1560441401245L);
//    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        int int0 = org.jfree.data.time.SerialDate.MAXIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9999 + "'", int0 == 9999);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond9.previous();
        java.lang.Number number11 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, number11);
        try {
            timeSeries4.update(2147483647, (java.lang.Number) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2147483647, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        timeSeries1.setDescription("2019");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        int int6 = year4.compareTo((java.lang.Object) "");
        long long7 = year4.getFirstMillisecond();
        long long8 = year4.getSerialIndex();
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year4, (double) 5);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond9.previous();
        java.lang.Number number11 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, number11);
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class14);
        timeSeries15.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries15.setDomainDescription("");
        java.lang.Class class20 = timeSeries15.getTimePeriodClass();
        timeSeries15.clear();
        java.lang.Class class25 = null;
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class25);
        timeSeries26.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener28 = null;
        timeSeries26.addPropertyChangeListener(propertyChangeListener28);
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries26.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond31);
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        int int35 = year33.compareTo((java.lang.Object) "");
        long long36 = year33.getFirstMillisecond();
        int int37 = timeSeries26.getIndex((org.jfree.data.time.RegularTimePeriod) year33);
        java.lang.Class class41 = null;
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class41);
        timeSeries42.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener44 = null;
        timeSeries42.addPropertyChangeListener(propertyChangeListener44);
        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = timeSeries42.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond47);
        java.util.Date date49 = fixedMillisecond47.getEnd();
        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(date49);
        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) year33, (org.jfree.data.time.RegularTimePeriod) day50);
        long long52 = day50.getFirstMillisecond();
        try {
            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) day50, (java.lang.Number) 12, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNull(class20);
        org.junit.Assert.assertNull(timeSeriesDataItem32);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1546329600000L + "'", long36 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem48);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(timeSeries51);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + (-57600000L) + "'", long52 == (-57600000L));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths(false);
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class8);
        timeSeries9.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries9.addPropertyChangeListener(propertyChangeListener11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
        java.util.Date date16 = fixedMillisecond14.getEnd();
        java.util.Date date17 = fixedMillisecond14.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (double) 2958465);
        int int21 = fixedMillisecond14.compareTo((java.lang.Object) 29);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        int int9 = month8.getMonth();
        java.lang.String str10 = month8.toString();
        try {
            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) month8, (double) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "June 2019" + "'", str10.equals("June 2019"));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        timeSeries1.setDescription("2019");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener4);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        int int4 = month3.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addYears(1, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((-451));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        int int0 = org.jfree.data.time.SerialDate.SUNDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        int int0 = org.jfree.data.time.SerialDate.FRIDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(11);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-460), "October", "2019", class3);
        int int5 = timeSeries4.getItemCount();
        java.lang.String str6 = timeSeries4.getDescription();
        try {
            org.jfree.data.time.TimeSeries timeSeries9 = timeSeries4.createCopy((int) (short) -1, 9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((int) (short) 0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (byte) -1, (int) (byte) 0, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("org.jfree.data.general.SeriesChangeEvent[source=SerialDate.weekInMonthToString(): invalid code.]");
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        int int0 = org.jfree.data.time.SerialDate.PRECEDING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod2, (double) (short) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("Wed Dec 31 16:00:00 PST 1969");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) (short) 100, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        try {
            java.lang.Object obj1 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) 3);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        int int13 = year11.compareTo((java.lang.Object) "");
        long long14 = year11.getFirstMillisecond();
        int int15 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) year11);
        java.util.Calendar calendar16 = null;
        try {
            year11.peg(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (short) 10, (int) (byte) 10, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10, 11, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class5);
        timeSeries6.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries6.setDomainDescription("");
        java.lang.Class class11 = timeSeries6.getTimePeriodClass();
        timeSeries6.clear();
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class16);
        timeSeries17.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timeSeries17.addPropertyChangeListener(propertyChangeListener19);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries17.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        int int26 = year24.compareTo((java.lang.Object) "");
        long long27 = year24.getFirstMillisecond();
        int int28 = timeSeries17.getIndex((org.jfree.data.time.RegularTimePeriod) year24);
        java.lang.Class class32 = null;
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class32);
        timeSeries33.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener35 = null;
        timeSeries33.addPropertyChangeListener(propertyChangeListener35);
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries33.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond38);
        java.util.Date date40 = fixedMillisecond38.getEnd();
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date40);
        org.jfree.data.time.TimeSeries timeSeries42 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) year24, (org.jfree.data.time.RegularTimePeriod) day41);
        org.jfree.data.time.SerialDate serialDate43 = day41.getSerialDate();
        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.addMonths(29, serialDate43);
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(3, serialDate44);
        java.lang.String str46 = serialDate45.getDescription();
        org.jfree.data.time.SerialDate serialDate47 = org.jfree.data.time.SerialDate.addMonths((int) (short) 100, serialDate45);
        try {
            org.jfree.data.time.SerialDate serialDate48 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((-1), serialDate47);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(class11);
        org.junit.Assert.assertNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1546329600000L + "'", long27 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem39);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(timeSeries42);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertNull(str46);
        org.junit.Assert.assertNotNull(serialDate47);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((-460));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class2);
        timeSeries3.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries3.setDomainDescription("");
        java.lang.Class class8 = timeSeries3.getTimePeriodClass();
        timeSeries3.clear();
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class13);
        timeSeries14.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries14.addPropertyChangeListener(propertyChangeListener16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries14.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        int int23 = year21.compareTo((java.lang.Object) "");
        long long24 = year21.getFirstMillisecond();
        int int25 = timeSeries14.getIndex((org.jfree.data.time.RegularTimePeriod) year21);
        java.lang.Class class29 = null;
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class29);
        timeSeries30.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener32 = null;
        timeSeries30.addPropertyChangeListener(propertyChangeListener32);
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries30.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
        java.util.Date date37 = fixedMillisecond35.getEnd();
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date37);
        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year21, (org.jfree.data.time.RegularTimePeriod) day38);
        org.jfree.data.time.SerialDate serialDate40 = day38.getSerialDate();
        try {
            org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(0, serialDate40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1546329600000L + "'", long24 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(timeSeries39);
        org.junit.Assert.assertNotNull(serialDate40);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(2147483647, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2147483647");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(12);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 12");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class2);
        java.lang.Class<?> wildcardClass4 = timeSeries3.getClass();
        java.util.Date date5 = null;
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date5, timeZone6);
        java.net.URL uRL8 = org.jfree.chart.util.ObjectUtilities.getResource("ClassContext", (java.lang.Class) wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertNull(uRL8);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-460), "October", "2019", class3);
        int int5 = timeSeries4.getItemCount();
        java.lang.String str6 = timeSeries4.getDescription();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = null;
        try {
            int int8 = timeSeries4.getIndex(regularTimePeriod7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(3);
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(2019, serialDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries2.setDomainDescription("");
        java.lang.String str7 = timeSeries2.getDomainDescription();
        boolean boolean8 = timeSeries2.isEmpty();
        timeSeries2.setMaximumItemCount((int) ' ');
        try {
            java.lang.Number number12 = timeSeries2.getValue(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries2.setDomainDescription("");
        java.lang.Class class7 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class12);
        timeSeries13.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        int int22 = year20.compareTo((java.lang.Object) "");
        long long23 = year20.getFirstMillisecond();
        int int24 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) year20);
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class28);
        timeSeries29.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timeSeries29.addPropertyChangeListener(propertyChangeListener31);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
        java.util.Date date36 = fixedMillisecond34.getEnd();
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date36);
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) year20, (org.jfree.data.time.RegularTimePeriod) day37);
        java.lang.Class class41 = null;
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class41);
        java.lang.Class<?> wildcardClass43 = timeSeries42.getClass();
        java.util.Date date44 = null;
        java.util.TimeZone timeZone45 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass43, date44, timeZone45);
        java.lang.ClassLoader classLoader47 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass43);
        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2, (java.lang.Class) wildcardClass43);
        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day37, (java.lang.Class) wildcardClass43);
        long long50 = day37.getLastMillisecond();
        java.util.Calendar calendar51 = null;
        try {
            long long52 = day37.getFirstMillisecond(calendar51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1546329600000L + "'", long23 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeSeries38);
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertNull(regularTimePeriod46);
        org.junit.Assert.assertNotNull(classLoader47);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 28799999L + "'", long50 == 28799999L);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("2019");
        org.junit.Assert.assertNotNull(year1);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries2.setDomainDescription("");
        java.lang.String str7 = timeSeries2.getDomainDescription();
        java.lang.Comparable comparable8 = timeSeries2.getKey();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = timeSeries2.getTimePeriod(9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9999, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + '4' + "'", comparable8.equals('4'));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Class class8 = timeSeries4.getTimePeriodClass();
        org.junit.Assert.assertNull(class8);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries2.setDomainDescription("");
        java.lang.Class class7 = timeSeries2.getTimePeriodClass();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries2.removeChangeListener(seriesChangeListener8);
        timeSeries2.removeAgedItems(false);
        org.junit.Assert.assertNull(class7);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries2.setDomainDescription("");
        java.lang.Class class7 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class12);
        timeSeries13.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        int int22 = year20.compareTo((java.lang.Object) "");
        long long23 = year20.getFirstMillisecond();
        int int24 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) year20);
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class28);
        timeSeries29.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timeSeries29.addPropertyChangeListener(propertyChangeListener31);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
        java.util.Date date36 = fixedMillisecond34.getEnd();
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date36);
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) year20, (org.jfree.data.time.RegularTimePeriod) day37);
        java.lang.Class class41 = null;
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class41);
        java.lang.Class<?> wildcardClass43 = timeSeries42.getClass();
        java.util.Date date44 = null;
        java.util.TimeZone timeZone45 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass43, date44, timeZone45);
        java.lang.ClassLoader classLoader47 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass43);
        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2, (java.lang.Class) wildcardClass43);
        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day37, (java.lang.Class) wildcardClass43);
        java.lang.Class class53 = null;
        org.jfree.data.time.TimeSeries timeSeries54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class53);
        timeSeries54.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener56 = null;
        timeSeries54.addPropertyChangeListener(propertyChangeListener56);
        org.jfree.data.time.FixedMillisecond fixedMillisecond59 = new org.jfree.data.time.FixedMillisecond((long) (short) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = fixedMillisecond59.previous();
        java.lang.Number number61 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem62 = timeSeries54.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond59, number61);
        try {
            timeSeries49.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond59, (java.lang.Number) 29);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.TimeSeries.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1546329600000L + "'", long23 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeSeries38);
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertNull(regularTimePeriod46);
        org.junit.Assert.assertNotNull(classLoader47);
        org.junit.Assert.assertNotNull(regularTimePeriod60);
        org.junit.Assert.assertNull(timeSeriesDataItem62);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries2.setDomainDescription("");
        java.lang.Class class7 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class12);
        timeSeries13.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        int int22 = year20.compareTo((java.lang.Object) "");
        long long23 = year20.getFirstMillisecond();
        int int24 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) year20);
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class28);
        timeSeries29.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timeSeries29.addPropertyChangeListener(propertyChangeListener31);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
        java.util.Date date36 = fixedMillisecond34.getEnd();
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date36);
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) year20, (org.jfree.data.time.RegularTimePeriod) day37);
        java.lang.Class class41 = null;
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class41);
        java.lang.Class<?> wildcardClass43 = timeSeries42.getClass();
        java.util.Date date44 = null;
        java.util.TimeZone timeZone45 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass43, date44, timeZone45);
        java.lang.ClassLoader classLoader47 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass43);
        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2, (java.lang.Class) wildcardClass43);
        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day37, (java.lang.Class) wildcardClass43);
        int int50 = timeSeries49.getMaximumItemCount();
        timeSeries49.setMaximumItemCount((int) (short) 100);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1546329600000L + "'", long23 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeSeries38);
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertNull(regularTimePeriod46);
        org.junit.Assert.assertNotNull(classLoader47);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 2147483647 + "'", int50 == 2147483647);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.clear();
        try {
            timeSeries4.removeAgedItems(25568L, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        boolean boolean8 = timeSeries4.isEmpty();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class10);
        timeSeries11.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries11.setDomainDescription("");
        java.lang.Class class16 = timeSeries11.getTimePeriodClass();
        timeSeries11.clear();
        java.lang.Class class21 = null;
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class21);
        timeSeries22.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timeSeries22.addPropertyChangeListener(propertyChangeListener24);
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries22.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
        int int31 = year29.compareTo((java.lang.Object) "");
        long long32 = year29.getFirstMillisecond();
        int int33 = timeSeries22.getIndex((org.jfree.data.time.RegularTimePeriod) year29);
        java.lang.Class class37 = null;
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class37);
        timeSeries38.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener40 = null;
        timeSeries38.addPropertyChangeListener(propertyChangeListener40);
        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries38.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond43);
        java.util.Date date45 = fixedMillisecond43.getEnd();
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date45);
        org.jfree.data.time.TimeSeries timeSeries47 = timeSeries11.createCopy((org.jfree.data.time.RegularTimePeriod) year29, (org.jfree.data.time.RegularTimePeriod) day46);
        java.lang.String str48 = day46.toString();
        try {
            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) day46, 0.0d, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(class16);
        org.junit.Assert.assertNull(timeSeriesDataItem28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1546329600000L + "'", long32 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem44);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(timeSeries47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "31-December-1969" + "'", str48.equals("31-December-1969"));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.clear();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = timeSeries4.getTimePeriod((-460));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(8, 2147483647);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        java.lang.Comparable comparable0 = null;
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class5);
        timeSeries6.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str9 = timeSeries6.getDescription();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getLastMillisecond();
        long long12 = year10.getSerialIndex();
        int int13 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) year10);
        java.lang.Class class21 = null;
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class21);
        java.lang.Class<?> wildcardClass23 = timeSeries22.getClass();
        java.util.Date date24 = null;
        java.util.TimeZone timeZone25 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date24, timeZone25);
        java.lang.ClassLoader classLoader27 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass23);
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2, (java.lang.Class) wildcardClass23);
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, "ThreadContext", "org.jfree.data.general.SeriesException: ", (java.lang.Class) wildcardClass23);
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year10, "Following", "Fourth", (java.lang.Class) wildcardClass23);
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), (java.lang.Class) wildcardClass23);
        try {
            org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries(comparable0, "June 2019", "", (java.lang.Class) wildcardClass23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str9.equals("SerialDate.weekInMonthToString(): invalid code."));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2019L + "'", long12 == 2019L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(classLoader27);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (52) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries2.setDomainDescription("");
        java.lang.Class class7 = timeSeries2.getTimePeriodClass();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries2.removeChangeListener(seriesChangeListener8);
        int int10 = timeSeries2.getMaximumItemCount();
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries2.clear();
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries2.setDomainDescription("");
        java.lang.Class class7 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class12);
        timeSeries13.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        int int22 = year20.compareTo((java.lang.Object) "");
        long long23 = year20.getFirstMillisecond();
        int int24 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) year20);
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class28);
        timeSeries29.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timeSeries29.addPropertyChangeListener(propertyChangeListener31);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
        java.util.Date date36 = fixedMillisecond34.getEnd();
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date36);
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) year20, (org.jfree.data.time.RegularTimePeriod) day37);
        long long39 = day37.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = day37.previous();
        int int41 = day37.getDayOfMonth();
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1546329600000L + "'", long23 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeSeries38);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-57600000L) + "'", long39 == (-57600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 31 + "'", int41 == 31);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class8);
        timeSeries9.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries9.addPropertyChangeListener(propertyChangeListener11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
        java.util.Date date16 = fixedMillisecond14.getEnd();
        java.util.Date date17 = fixedMillisecond14.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (double) 2958465);
        boolean boolean20 = timeSeries4.getNotify();
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.next();
        long long4 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.previous();
        try {
            java.lang.Object obj6 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) regularTimePeriod5);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(0, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries2.setDomainDescription("");
        java.lang.Class class7 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class12);
        timeSeries13.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        int int22 = year20.compareTo((java.lang.Object) "");
        long long23 = year20.getFirstMillisecond();
        int int24 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) year20);
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class28);
        timeSeries29.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timeSeries29.addPropertyChangeListener(propertyChangeListener31);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
        java.util.Date date36 = fixedMillisecond34.getEnd();
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date36);
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) year20, (org.jfree.data.time.RegularTimePeriod) day37);
        long long39 = day37.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = day37.previous();
        long long41 = day37.getLastMillisecond();
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1546329600000L + "'", long23 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeSeries38);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-57600000L) + "'", long39 == (-57600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 28799999L + "'", long41 == 28799999L);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("August");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        int int4 = month3.getMonth();
        int int5 = month3.getYearValue();
        int int6 = month3.getYearValue();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = month3.getLastMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(29, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 29");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries2.removePropertyChangeListener(propertyChangeListener3);
        java.util.List list5 = timeSeries2.getItems();
        org.junit.Assert.assertNotNull(list5);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 1);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((-451));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("August");
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class8);
        timeSeries9.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries9.addPropertyChangeListener(propertyChangeListener11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
        java.util.Date date16 = fixedMillisecond14.getEnd();
        java.util.Date date17 = fixedMillisecond14.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (double) 2958465);
        java.lang.String str20 = timeSeries4.getDomainDescription();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        int int23 = year21.compareTo((java.lang.Object) "");
        long long24 = year21.getSerialIndex();
        try {
            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) year21, (double) (-458), false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hi!" + "'", str20.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 2019L + "'", long24 == 2019L);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        long long2 = month0.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24234L + "'", long2 == 24234L);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries2.setDomainDescription("");
        java.lang.Class class7 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class12);
        timeSeries13.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        int int22 = year20.compareTo((java.lang.Object) "");
        long long23 = year20.getFirstMillisecond();
        int int24 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) year20);
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class28);
        timeSeries29.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timeSeries29.addPropertyChangeListener(propertyChangeListener31);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
        java.util.Date date36 = fixedMillisecond34.getEnd();
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date36);
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) year20, (org.jfree.data.time.RegularTimePeriod) day37);
        org.jfree.data.time.SerialDate serialDate39 = day37.getSerialDate();
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(serialDate39);
        long long41 = day40.getSerialIndex();
        long long42 = day40.getLastMillisecond();
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1546329600000L + "'", long23 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeSeries38);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 25568L + "'", long41 == 25568L);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 28799999L + "'", long42 == 28799999L);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        int int13 = year11.compareTo((java.lang.Object) "");
        long long14 = year11.getFirstMillisecond();
        int int15 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) year11);
        java.lang.Object obj16 = timeSeries4.clone();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = timeSeries4.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(obj16);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(29);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: ClassContext");
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(1);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "January" + "'", str1.equals("January"));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(9999, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("January");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class2);
        java.lang.Class<?> wildcardClass4 = timeSeries3.getClass();
        java.util.Date date5 = null;
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date5, timeZone6);
        java.lang.ClassLoader classLoader8 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2, (java.lang.Class) wildcardClass4);
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class11);
        timeSeries12.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries12.setDomainDescription("");
        java.lang.Class class17 = timeSeries12.getTimePeriodClass();
        timeSeries12.clear();
        java.lang.Class class22 = null;
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class22);
        timeSeries23.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener25 = null;
        timeSeries23.addPropertyChangeListener(propertyChangeListener25);
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries23.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        int int32 = year30.compareTo((java.lang.Object) "");
        long long33 = year30.getFirstMillisecond();
        int int34 = timeSeries23.getIndex((org.jfree.data.time.RegularTimePeriod) year30);
        java.lang.Class class38 = null;
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class38);
        timeSeries39.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener41 = null;
        timeSeries39.addPropertyChangeListener(propertyChangeListener41);
        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = timeSeries39.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond44);
        java.util.Date date46 = fixedMillisecond44.getEnd();
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(date46);
        org.jfree.data.time.TimeSeries timeSeries48 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) year30, (org.jfree.data.time.RegularTimePeriod) day47);
        org.jfree.data.time.SerialDate serialDate49 = day47.getSerialDate();
        java.util.Date date50 = day47.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem52 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day47, (java.lang.Number) 1900);
        try {
            timeSeries9.add(timeSeriesDataItem52, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Day, but the TimeSeries is expecting an instance of org.jfree.data.time.TimeSeries.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(classLoader8);
        org.junit.Assert.assertNull(class17);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1546329600000L + "'", long33 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem45);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(timeSeries48);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertNotNull(date50);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries2.setDomainDescription("");
        java.lang.Class class7 = timeSeries2.getTimePeriodClass();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries2.removeChangeListener(seriesChangeListener8);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        int int11 = month10.getMonth();
        java.lang.String str12 = month10.toString();
        try {
            timeSeries2.add((org.jfree.data.time.RegularTimePeriod) month10, (double) (-459), true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "June 2019" + "'", str12.equals("June 2019"));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        long long3 = year2.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year2.previous();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.Class class9 = timeSeries8.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod4, "", "org.jfree.data.general.SeriesChangeEvent[source=SerialDate.weekInMonthToString(): invalid code.]", class9);
        java.io.InputStream inputStream11 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("SerialDate.weekInMonthToString(): invalid code.", class9);
        java.io.InputStream inputStream12 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("31-December-1969", class9);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertNull(inputStream11);
        org.junit.Assert.assertNull(inputStream12);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        timeSeries1.setDescription("2019");
        java.lang.Class class4 = timeSeries1.getTimePeriodClass();
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class8);
        timeSeries9.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries9.addPropertyChangeListener(propertyChangeListener11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        int int18 = year16.compareTo((java.lang.Object) "");
        long long19 = year16.getFirstMillisecond();
        int int20 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) year16);
        java.lang.String str21 = timeSeries9.getDomainDescription();
        timeSeries9.setMaximumItemCount((int) (byte) 10);
        long long24 = timeSeries9.getMaximumItemAge();
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class28);
        timeSeries29.clear();
        java.lang.Class class34 = null;
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class34);
        timeSeries35.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener37 = null;
        timeSeries35.addPropertyChangeListener(propertyChangeListener37);
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries35.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40);
        java.util.Date date42 = fixedMillisecond40.getEnd();
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year();
        long long44 = year43.getLastMillisecond();
        boolean boolean45 = fixedMillisecond40.equals((java.lang.Object) year43);
        int int47 = fixedMillisecond40.compareTo((java.lang.Object) 1577865599999L);
        java.lang.Number number48 = timeSeries29.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40, 10.0d);
        java.lang.Class class54 = null;
        org.jfree.data.time.TimeSeries timeSeries55 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class54);
        timeSeries55.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener57 = null;
        timeSeries55.addPropertyChangeListener(propertyChangeListener57);
        timeSeries55.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
        int int61 = fixedMillisecond40.compareTo((java.lang.Object) "SerialDate.weekInMonthToString(): invalid code.");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = fixedMillisecond40.next();
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40, (double) (-1.0f), true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(class4);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1546329600000L + "'", long19 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertNull(timeSeriesDataItem41);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1577865599999L + "'", long44 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertNull(number48);
        org.junit.Assert.assertNull(timeSeriesDataItem50);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1 + "'", int61 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod62);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries2.setDomainDescription("");
        java.lang.Class class7 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class12);
        timeSeries13.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        int int22 = year20.compareTo((java.lang.Object) "");
        long long23 = year20.getFirstMillisecond();
        int int24 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) year20);
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class28);
        timeSeries29.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timeSeries29.addPropertyChangeListener(propertyChangeListener31);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
        java.util.Date date36 = fixedMillisecond34.getEnd();
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date36);
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) year20, (org.jfree.data.time.RegularTimePeriod) day37);
        long long39 = year20.getLastMillisecond();
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1546329600000L + "'", long23 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeSeries38);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1577865599999L + "'", long39 == 1577865599999L);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries2.setDomainDescription("");
        java.lang.Class class7 = timeSeries2.getTimePeriodClass();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        int int10 = year8.compareTo((java.lang.Object) "");
        long long11 = year8.getSerialIndex();
        try {
            timeSeries2.add((org.jfree.data.time.RegularTimePeriod) year8, (java.lang.Number) (-460));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("January 2019");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class8);
        timeSeries9.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries9.addPropertyChangeListener(propertyChangeListener11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
        java.util.Date date16 = fixedMillisecond14.getEnd();
        java.util.Date date17 = fixedMillisecond14.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (double) 2958465);
        java.util.Calendar calendar20 = null;
        fixedMillisecond14.peg(calendar20);
        java.util.Date date22 = fixedMillisecond14.getTime();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
        int int24 = day23.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day23.next();
        int int26 = day23.getDayOfMonth();
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 12 + "'", int24 == 12);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 31 + "'", int26 == 31);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(31);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("August");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class4);
        java.lang.Class class9 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class9);
        timeSeries10.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries10.addPropertyChangeListener(propertyChangeListener12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries10.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.util.Date date17 = fixedMillisecond15.getEnd();
        java.util.Date date18 = fixedMillisecond15.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (double) 2958465);
        java.util.Calendar calendar21 = null;
        fixedMillisecond15.peg(calendar21);
        java.util.Date date23 = fixedMillisecond15.getTime();
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance(date23);
        try {
            org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((-459), serialDate24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(serialDate24);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        timeSeries1.setDescription("2019");
        java.lang.Class class7 = null;
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class7);
        timeSeries8.clear();
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class13);
        timeSeries14.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries14.addPropertyChangeListener(propertyChangeListener16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries14.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
        java.util.Date date21 = fixedMillisecond19.getEnd();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        long long23 = year22.getLastMillisecond();
        boolean boolean24 = fixedMillisecond19.equals((java.lang.Object) year22);
        int int26 = fixedMillisecond19.compareTo((java.lang.Object) 1577865599999L);
        java.lang.Number number27 = timeSeries8.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries1.addAndOrUpdate(timeSeries8);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1577865599999L + "'", long23 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNull(number27);
        org.junit.Assert.assertNotNull(timeSeries28);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setNotify(true);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        int int7 = year5.compareTo((java.lang.Object) "");
        long long8 = year5.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year5.next();
        try {
            timeSeries2.add(regularTimePeriod9, (java.lang.Number) 9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546329600000L + "'", long8 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        java.lang.String str3 = timeSeries2.getRangeDescription();
        timeSeries2.setNotify(true);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries2.getDataItem(7);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Value" + "'", str3.equals("Value"));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.lang.String str2 = month0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.previous();
        int int4 = month0.getMonth();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = month0.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "June 2019" + "'", str2.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        int int13 = year11.compareTo((java.lang.Object) "");
        long long14 = year11.getFirstMillisecond();
        int int15 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) year11);
        java.lang.String str16 = timeSeries4.getDomainDescription();
        timeSeries4.setMaximumItemCount((int) (byte) 10);
        long long19 = timeSeries4.getMaximumItemAge();
        java.lang.String str20 = timeSeries4.getDomainDescription();
        java.lang.Class class22 = null;
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class22);
        timeSeries23.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries23.setDomainDescription("");
        java.lang.Class class28 = timeSeries23.getTimePeriodClass();
        timeSeries23.clear();
        java.lang.Class class33 = null;
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class33);
        timeSeries34.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener36 = null;
        timeSeries34.addPropertyChangeListener(propertyChangeListener36);
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries34.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39);
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
        int int43 = year41.compareTo((java.lang.Object) "");
        long long44 = year41.getFirstMillisecond();
        int int45 = timeSeries34.getIndex((org.jfree.data.time.RegularTimePeriod) year41);
        java.lang.Class class49 = null;
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class49);
        timeSeries50.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener52 = null;
        timeSeries50.addPropertyChangeListener(propertyChangeListener52);
        org.jfree.data.time.FixedMillisecond fixedMillisecond55 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem56 = timeSeries50.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond55);
        java.util.Date date57 = fixedMillisecond55.getEnd();
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(date57);
        org.jfree.data.time.TimeSeries timeSeries59 = timeSeries23.createCopy((org.jfree.data.time.RegularTimePeriod) year41, (org.jfree.data.time.RegularTimePeriod) day58);
        org.jfree.data.time.SerialDate serialDate60 = day58.getSerialDate();
        java.util.Date date61 = day58.getStart();
        try {
            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) day58, (java.lang.Number) 2147483647, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 9223372036854775807L + "'", long19 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hi!" + "'", str20.equals("hi!"));
        org.junit.Assert.assertNull(class28);
        org.junit.Assert.assertNull(timeSeriesDataItem40);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1546329600000L + "'", long44 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem56);
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertNotNull(timeSeries59);
        org.junit.Assert.assertNotNull(serialDate60);
        org.junit.Assert.assertNotNull(date61);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("June 2019");
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.data.time.Year year2 = org.jfree.data.time.Year.parseYear("2018");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(9, year2);
        java.util.Calendar calendar4 = null;
        try {
            long long5 = month3.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year2);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("2019");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond9.previous();
        java.lang.Number number11 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, number11);
        java.util.List list13 = timeSeries4.getItems();
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class16);
        java.lang.Class<?> wildcardClass18 = timeSeries17.getClass();
        java.util.Date date19 = null;
        java.util.TimeZone timeZone20 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date19, timeZone20);
        java.lang.ClassLoader classLoader22 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass18);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2, (java.lang.Class) wildcardClass18);
        java.lang.Class class27 = null;
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class27);
        timeSeries28.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener30 = null;
        timeSeries28.addPropertyChangeListener(propertyChangeListener30);
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries28.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond33);
        java.util.Date date35 = fixedMillisecond33.getEnd();
        java.util.Date date36 = fixedMillisecond33.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries23.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond33, (java.lang.Number) 2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = fixedMillisecond33.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod39, (double) 11);
        try {
            timeSeries4.add(timeSeriesDataItem41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(classLoader22);
        org.junit.Assert.assertNull(timeSeriesDataItem34);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNull(timeSeriesDataItem38);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class2);
        java.lang.Class<?> wildcardClass4 = timeSeries3.getClass();
        java.util.Date date5 = null;
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date5, timeZone6);
        java.lang.ClassLoader classLoader8 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2, (java.lang.Class) wildcardClass4);
        timeSeries9.removeAgedItems(false);
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class13);
        timeSeries14.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries14.setDomainDescription("");
        java.lang.Class class19 = timeSeries14.getTimePeriodClass();
        timeSeries14.clear();
        java.lang.Class class24 = null;
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class24);
        timeSeries25.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener27 = null;
        timeSeries25.addPropertyChangeListener(propertyChangeListener27);
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries25.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        int int34 = year32.compareTo((java.lang.Object) "");
        long long35 = year32.getFirstMillisecond();
        int int36 = timeSeries25.getIndex((org.jfree.data.time.RegularTimePeriod) year32);
        java.lang.Class class40 = null;
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class40);
        timeSeries41.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener43 = null;
        timeSeries41.addPropertyChangeListener(propertyChangeListener43);
        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = timeSeries41.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond46);
        java.util.Date date48 = fixedMillisecond46.getEnd();
        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day(date48);
        org.jfree.data.time.TimeSeries timeSeries50 = timeSeries14.createCopy((org.jfree.data.time.RegularTimePeriod) year32, (org.jfree.data.time.RegularTimePeriod) day49);
        org.jfree.data.time.SerialDate serialDate51 = day49.getSerialDate();
        java.util.Date date52 = day49.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem54 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day49, (java.lang.Number) 1900);
        java.lang.Class class56 = null;
        org.jfree.data.time.TimeSeries timeSeries57 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class56);
        timeSeries57.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str60 = timeSeries57.getDescription();
        timeSeries57.setMaximumItemAge((long) 11);
        java.beans.PropertyChangeListener propertyChangeListener63 = null;
        timeSeries57.removePropertyChangeListener(propertyChangeListener63);
        boolean boolean65 = timeSeriesDataItem54.equals((java.lang.Object) propertyChangeListener63);
        java.lang.Object obj66 = timeSeriesDataItem54.clone();
        try {
            timeSeries9.add(timeSeriesDataItem54);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Day, but the TimeSeries is expecting an instance of org.jfree.data.time.TimeSeries.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(classLoader8);
        org.junit.Assert.assertNull(class19);
        org.junit.Assert.assertNull(timeSeriesDataItem31);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1546329600000L + "'", long35 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem47);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(timeSeries50);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str60.equals("SerialDate.weekInMonthToString(): invalid code."));
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(obj66);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(12);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((int) '4');
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(31, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(2958465);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class8);
        timeSeries9.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries9.addPropertyChangeListener(propertyChangeListener11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
        java.util.Date date16 = fixedMillisecond14.getEnd();
        java.util.Date date17 = fixedMillisecond14.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (double) 2958465);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries4.removeChangeListener(seriesChangeListener20);
        java.lang.Class class23 = null;
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class23);
        timeSeries24.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries24.setDomainDescription("");
        java.lang.Class class29 = timeSeries24.getTimePeriodClass();
        timeSeries24.clear();
        java.lang.Class class34 = null;
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class34);
        timeSeries35.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener37 = null;
        timeSeries35.addPropertyChangeListener(propertyChangeListener37);
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries35.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40);
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
        int int44 = year42.compareTo((java.lang.Object) "");
        long long45 = year42.getFirstMillisecond();
        int int46 = timeSeries35.getIndex((org.jfree.data.time.RegularTimePeriod) year42);
        java.lang.Class class50 = null;
        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class50);
        timeSeries51.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener53 = null;
        timeSeries51.addPropertyChangeListener(propertyChangeListener53);
        org.jfree.data.time.FixedMillisecond fixedMillisecond56 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem57 = timeSeries51.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond56);
        java.util.Date date58 = fixedMillisecond56.getEnd();
        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day(date58);
        org.jfree.data.time.TimeSeries timeSeries60 = timeSeries24.createCopy((org.jfree.data.time.RegularTimePeriod) year42, (org.jfree.data.time.RegularTimePeriod) day59);
        long long61 = day59.getFirstMillisecond();
        boolean boolean63 = day59.equals((java.lang.Object) 1577865599999L);
        timeSeries4.setKey((java.lang.Comparable) boolean63);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem66 = timeSeries4.getDataItem(0);
        try {
            org.jfree.data.time.TimeSeries timeSeries69 = timeSeries4.createCopy(0, 9999);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertNull(class29);
        org.junit.Assert.assertNull(timeSeriesDataItem41);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1546329600000L + "'", long45 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem57);
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertNotNull(timeSeries60);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + (-57600000L) + "'", long61 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem66);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class2);
        timeSeries3.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str6 = timeSeries3.getDescription();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getLastMillisecond();
        long long9 = year7.getSerialIndex();
        int int10 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) year7);
        long long11 = year7.getLastMillisecond();
        try {
            org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((-457), year7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str6.equals("SerialDate.weekInMonthToString(): invalid code."));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2019L + "'", long9 == 2019L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((-458));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((-458));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Nearest" + "'", str1.equals("Nearest"));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries2.setDomainDescription("");
        java.lang.Class class7 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class12);
        timeSeries13.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        int int22 = year20.compareTo((java.lang.Object) "");
        long long23 = year20.getFirstMillisecond();
        int int24 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) year20);
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class28);
        timeSeries29.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timeSeries29.addPropertyChangeListener(propertyChangeListener31);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
        java.util.Date date36 = fixedMillisecond34.getEnd();
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date36);
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) year20, (org.jfree.data.time.RegularTimePeriod) day37);
        java.lang.Class class41 = null;
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class41);
        java.lang.Class<?> wildcardClass43 = timeSeries42.getClass();
        java.util.Date date44 = null;
        java.util.TimeZone timeZone45 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass43, date44, timeZone45);
        java.lang.ClassLoader classLoader47 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass43);
        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2, (java.lang.Class) wildcardClass43);
        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day37, (java.lang.Class) wildcardClass43);
        java.lang.Comparable comparable50 = timeSeries49.getKey();
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1546329600000L + "'", long23 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeSeries38);
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertNull(regularTimePeriod46);
        org.junit.Assert.assertNotNull(classLoader47);
        org.junit.Assert.assertNotNull(comparable50);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        java.lang.Object obj0 = null;
        try {
            java.lang.Object obj1 = org.jfree.chart.util.ObjectUtilities.clone(obj0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'object' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) 0, 0, (-459));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        java.lang.Class<?> wildcardClass3 = timeSeries2.getClass();
        try {
            org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.createCopy((int) ' ', 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries2.setDomainDescription("");
        java.lang.Class class7 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class12);
        timeSeries13.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        int int22 = year20.compareTo((java.lang.Object) "");
        long long23 = year20.getFirstMillisecond();
        int int24 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) year20);
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class28);
        timeSeries29.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timeSeries29.addPropertyChangeListener(propertyChangeListener31);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
        java.util.Date date36 = fixedMillisecond34.getEnd();
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date36);
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) year20, (org.jfree.data.time.RegularTimePeriod) day37);
        long long39 = day37.getFirstMillisecond();
        boolean boolean41 = day37.equals((java.lang.Object) 1577865599999L);
        long long42 = day37.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = day37.next();
        long long44 = day37.getSerialIndex();
        long long45 = day37.getLastMillisecond();
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1546329600000L + "'", long23 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeSeries38);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-57600000L) + "'", long39 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 25568L + "'", long42 == 25568L);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 25568L + "'", long44 == 25568L);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 28799999L + "'", long45 == 28799999L);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        java.lang.String str4 = month3.toString();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = month3.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "January 2019" + "'", str4.equals("January 2019"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("ClassContext");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.String str3 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: ClassContext" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: ClassContext"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: ClassContext" + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: ClassContext"));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries2.setDomainDescription("");
        java.lang.Class class7 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class12);
        timeSeries13.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        int int22 = year20.compareTo((java.lang.Object) "");
        long long23 = year20.getFirstMillisecond();
        int int24 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) year20);
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class28);
        timeSeries29.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timeSeries29.addPropertyChangeListener(propertyChangeListener31);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
        java.util.Date date36 = fixedMillisecond34.getEnd();
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date36);
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) year20, (org.jfree.data.time.RegularTimePeriod) day37);
        long long39 = day37.getFirstMillisecond();
        boolean boolean41 = day37.equals((java.lang.Object) 1577865599999L);
        long long42 = day37.getSerialIndex();
        java.util.Calendar calendar43 = null;
        try {
            day37.peg(calendar43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1546329600000L + "'", long23 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeSeries38);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-57600000L) + "'", long39 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 25568L + "'", long42 == 25568L);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.removeAgedItems(false);
        java.lang.Class class5 = timeSeries2.getTimePeriodClass();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = timeSeries2.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(class5);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        boolean boolean8 = timeSeries4.isEmpty();
        boolean boolean9 = timeSeries4.isEmpty();
        timeSeries4.setMaximumItemCount(0);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        int int14 = year12.compareTo((java.lang.Object) "");
        long long15 = year12.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year12.next();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.Class class19 = timeSeries18.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod16, class19);
        try {
            timeSeries4.add(regularTimePeriod16, (java.lang.Number) 7, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1546329600000L + "'", long15 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(class19);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Following" + "'", str1.equals("Following"));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.removeAgedItems(false);
        boolean boolean6 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) timeSeries2, (java.lang.Object) 1900);
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class10);
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class15);
        timeSeries16.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timeSeries16.addPropertyChangeListener(propertyChangeListener18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries16.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21);
        java.util.Date date23 = fixedMillisecond21.getEnd();
        java.util.Date date24 = fixedMillisecond21.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, (double) 2958465);
        java.util.Calendar calendar27 = null;
        fixedMillisecond21.peg(calendar27);
        java.util.Date date29 = fixedMillisecond21.getTime();
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date29);
        int int31 = day30.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = day30.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = day30.previous();
        timeSeries2.delete(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNull(timeSeriesDataItem26);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 12 + "'", int31 == 12);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        java.lang.Class<?> wildcardClass3 = timeSeries2.getClass();
        java.lang.Class class7 = null;
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class7);
        timeSeries8.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries8.addPropertyChangeListener(propertyChangeListener10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries8.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        int int17 = year15.compareTo((java.lang.Object) "");
        long long18 = year15.getFirstMillisecond();
        int int19 = timeSeries8.getIndex((org.jfree.data.time.RegularTimePeriod) year15);
        java.lang.String str20 = timeSeries8.getDomainDescription();
        timeSeries8.setMaximumItemCount((int) (byte) 10);
        long long23 = timeSeries8.getMaximumItemAge();
        java.lang.Class class27 = null;
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class27);
        timeSeries28.clear();
        java.lang.Class class33 = null;
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class33);
        timeSeries34.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener36 = null;
        timeSeries34.addPropertyChangeListener(propertyChangeListener36);
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries34.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39);
        java.util.Date date41 = fixedMillisecond39.getEnd();
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
        long long43 = year42.getLastMillisecond();
        boolean boolean44 = fixedMillisecond39.equals((java.lang.Object) year42);
        int int46 = fixedMillisecond39.compareTo((java.lang.Object) 1577865599999L);
        java.lang.Number number47 = timeSeries28.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, 10.0d);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (double) 2019L);
        timeSeries2.setNotify(false);
        timeSeries2.setDomainDescription("Wed Dec 31 16:00:00 PST 1969");
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1546329600000L + "'", long18 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hi!" + "'", str20.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 9223372036854775807L + "'", long23 == 9223372036854775807L);
        org.junit.Assert.assertNull(timeSeriesDataItem40);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1577865599999L + "'", long43 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
        org.junit.Assert.assertNull(number47);
        org.junit.Assert.assertNull(timeSeriesDataItem49);
        org.junit.Assert.assertNull(timeSeriesDataItem51);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries2.setDomainDescription("");
        java.lang.Class class7 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class12);
        timeSeries13.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        int int22 = year20.compareTo((java.lang.Object) "");
        long long23 = year20.getFirstMillisecond();
        int int24 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) year20);
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class28);
        timeSeries29.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timeSeries29.addPropertyChangeListener(propertyChangeListener31);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
        java.util.Date date36 = fixedMillisecond34.getEnd();
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date36);
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) year20, (org.jfree.data.time.RegularTimePeriod) day37);
        org.jfree.data.time.SerialDate serialDate39 = day37.getSerialDate();
        java.util.Date date40 = day37.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day37, (java.lang.Number) 1900);
        java.lang.Class class44 = null;
        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class44);
        timeSeries45.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str48 = timeSeries45.getDescription();
        timeSeries45.setMaximumItemAge((long) 11);
        java.beans.PropertyChangeListener propertyChangeListener51 = null;
        timeSeries45.removePropertyChangeListener(propertyChangeListener51);
        boolean boolean53 = timeSeriesDataItem42.equals((java.lang.Object) propertyChangeListener51);
        java.lang.Class class57 = null;
        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class57);
        timeSeries58.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener60 = null;
        timeSeries58.addPropertyChangeListener(propertyChangeListener60);
        org.jfree.data.time.FixedMillisecond fixedMillisecond63 = new org.jfree.data.time.FixedMillisecond((long) (short) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = fixedMillisecond63.previous();
        java.lang.Number number65 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem66 = timeSeries58.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond63, number65);
        java.util.List list67 = timeSeries58.getItems();
        int int68 = timeSeriesDataItem42.compareTo((java.lang.Object) timeSeries58);
        java.lang.Object obj69 = timeSeriesDataItem42.clone();
        java.lang.Object obj70 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) timeSeriesDataItem42);
        java.lang.Class class72 = null;
        org.jfree.data.time.TimeSeries timeSeries73 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class72);
        timeSeries73.setNotify(true);
        int int76 = timeSeriesDataItem42.compareTo((java.lang.Object) timeSeries73);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = timeSeriesDataItem42.getPeriod();
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1546329600000L + "'", long23 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeSeries38);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str48.equals("SerialDate.weekInMonthToString(): invalid code."));
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod64);
        org.junit.Assert.assertNull(timeSeriesDataItem66);
        org.junit.Assert.assertNotNull(list67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 1 + "'", int68 == 1);
        org.junit.Assert.assertNotNull(obj69);
        org.junit.Assert.assertNotNull(obj70);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 1 + "'", int76 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod77);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-460), "October", "2019", class3);
        try {
            java.lang.Number number6 = timeSeries4.getValue(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class2);
        java.lang.Class<?> wildcardClass4 = timeSeries3.getClass();
        java.io.InputStream inputStream5 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("2018", (java.lang.Class) wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(inputStream5);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        java.lang.Class class0 = null;
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class4);
        timeSeries5.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries5.addPropertyChangeListener(propertyChangeListener7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries5.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
        java.util.Date date12 = fixedMillisecond10.getEnd();
        java.util.TimeZone timeZone13 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date12, timeZone13);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(date12);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date12);
        long long17 = year16.getLastMillisecond();
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 28799999L + "'", long17 == 28799999L);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class2);
        java.lang.Class<?> wildcardClass4 = timeSeries3.getClass();
        java.util.Date date5 = null;
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date5, timeZone6);
        java.lang.ClassLoader classLoader8 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2, (java.lang.Class) wildcardClass4);
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class13);
        timeSeries14.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries14.addPropertyChangeListener(propertyChangeListener16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries14.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
        java.util.Date date21 = fixedMillisecond19.getEnd();
        java.util.Date date22 = fixedMillisecond19.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (java.lang.Number) 2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = fixedMillisecond19.next();
        java.util.Calendar calendar26 = null;
        long long27 = fixedMillisecond19.getLastMillisecond(calendar26);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(classLoader8);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
    }

//    @Test
//    public void test318() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test318");
//        java.lang.Class class1 = null;
//        java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("org.jfree.data.general.SeriesChangeEvent[source=SerialDate.weekInMonthToString(): invalid code.]", class1);
//        org.junit.Assert.assertNull(inputStream2);
//    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries2.setDomainDescription("");
        java.lang.Class class7 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class12);
        timeSeries13.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        int int22 = year20.compareTo((java.lang.Object) "");
        long long23 = year20.getFirstMillisecond();
        int int24 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) year20);
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class28);
        timeSeries29.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timeSeries29.addPropertyChangeListener(propertyChangeListener31);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
        java.util.Date date36 = fixedMillisecond34.getEnd();
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date36);
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) year20, (org.jfree.data.time.RegularTimePeriod) day37);
        org.jfree.data.time.SerialDate serialDate39 = day37.getSerialDate();
        java.util.Date date40 = day37.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day37, (java.lang.Number) 1900);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = timeSeriesDataItem42.getPeriod();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod43, (double) 2958465);
        java.lang.Class class47 = null;
        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class47);
        timeSeries48.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str51 = timeSeries48.getDescription();
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year();
        long long53 = year52.getLastMillisecond();
        long long54 = year52.getSerialIndex();
        int int55 = timeSeries48.getIndex((org.jfree.data.time.RegularTimePeriod) year52);
        java.lang.Class class63 = null;
        org.jfree.data.time.TimeSeries timeSeries64 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class63);
        java.lang.Class<?> wildcardClass65 = timeSeries64.getClass();
        java.util.Date date66 = null;
        java.util.TimeZone timeZone67 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass65, date66, timeZone67);
        java.lang.ClassLoader classLoader69 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass65);
        org.jfree.data.time.TimeSeries timeSeries70 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2, (java.lang.Class) wildcardClass65);
        org.jfree.data.time.TimeSeries timeSeries71 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, "ThreadContext", "org.jfree.data.general.SeriesException: ", (java.lang.Class) wildcardClass65);
        org.jfree.data.time.TimeSeries timeSeries72 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year52, "Following", "Fourth", (java.lang.Class) wildcardClass65);
        org.jfree.data.time.TimeSeries timeSeries73 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod43, (java.lang.Class) wildcardClass65);
        java.lang.ClassLoader classLoader74 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass65);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1546329600000L + "'", long23 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeSeries38);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str51.equals("SerialDate.weekInMonthToString(): invalid code."));
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 1577865599999L + "'", long53 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 2019L + "'", long54 == 2019L);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-1) + "'", int55 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass65);
        org.junit.Assert.assertNull(regularTimePeriod68);
        org.junit.Assert.assertNotNull(classLoader69);
        org.junit.Assert.assertNotNull(classLoader74);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((int) ' ');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-452) + "'", int1 == (-452));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date2);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date2);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class3);
        timeSeries4.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries4.setDomainDescription("");
        java.lang.Class class9 = timeSeries4.getTimePeriodClass();
        timeSeries4.clear();
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class14);
        timeSeries15.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries15.addPropertyChangeListener(propertyChangeListener17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries15.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        int int24 = year22.compareTo((java.lang.Object) "");
        long long25 = year22.getFirstMillisecond();
        int int26 = timeSeries15.getIndex((org.jfree.data.time.RegularTimePeriod) year22);
        java.lang.Class class30 = null;
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class30);
        timeSeries31.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener33 = null;
        timeSeries31.addPropertyChangeListener(propertyChangeListener33);
        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries31.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond36);
        java.util.Date date38 = fixedMillisecond36.getEnd();
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date38);
        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) year22, (org.jfree.data.time.RegularTimePeriod) day39);
        org.jfree.data.time.SerialDate serialDate41 = day39.getSerialDate();
        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.addMonths(29, serialDate41);
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(3, serialDate42);
        java.lang.Class class46 = null;
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class46);
        timeSeries47.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries47.setDomainDescription("");
        java.lang.Class class52 = timeSeries47.getTimePeriodClass();
        timeSeries47.clear();
        java.lang.Class class57 = null;
        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class57);
        timeSeries58.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener60 = null;
        timeSeries58.addPropertyChangeListener(propertyChangeListener60);
        org.jfree.data.time.FixedMillisecond fixedMillisecond63 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem64 = timeSeries58.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond63);
        org.jfree.data.time.Year year65 = new org.jfree.data.time.Year();
        int int67 = year65.compareTo((java.lang.Object) "");
        long long68 = year65.getFirstMillisecond();
        int int69 = timeSeries58.getIndex((org.jfree.data.time.RegularTimePeriod) year65);
        java.lang.Class class73 = null;
        org.jfree.data.time.TimeSeries timeSeries74 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class73);
        timeSeries74.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener76 = null;
        timeSeries74.addPropertyChangeListener(propertyChangeListener76);
        org.jfree.data.time.FixedMillisecond fixedMillisecond79 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem80 = timeSeries74.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond79);
        java.util.Date date81 = fixedMillisecond79.getEnd();
        org.jfree.data.time.Day day82 = new org.jfree.data.time.Day(date81);
        org.jfree.data.time.TimeSeries timeSeries83 = timeSeries47.createCopy((org.jfree.data.time.RegularTimePeriod) year65, (org.jfree.data.time.RegularTimePeriod) day82);
        org.jfree.data.time.SerialDate serialDate84 = day82.getSerialDate();
        org.jfree.data.time.SerialDate serialDate85 = org.jfree.data.time.SerialDate.addMonths(29, serialDate84);
        org.jfree.data.time.SerialDate serialDate86 = serialDate42.getEndOfCurrentMonth(serialDate85);
        serialDate85.setDescription("");
        try {
            org.jfree.data.time.SerialDate serialDate90 = serialDate85.getFollowingDayOfWeek(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(class9);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1546329600000L + "'", long25 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem37);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(timeSeries40);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNull(class52);
        org.junit.Assert.assertNull(timeSeriesDataItem64);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1 + "'", int67 == 1);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 1546329600000L + "'", long68 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + (-1) + "'", int69 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem80);
        org.junit.Assert.assertNotNull(date81);
        org.junit.Assert.assertNotNull(timeSeries83);
        org.junit.Assert.assertNotNull(serialDate84);
        org.junit.Assert.assertNotNull(serialDate85);
        org.junit.Assert.assertNotNull(serialDate86);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        java.util.Date date11 = fixedMillisecond9.getEnd();
        java.util.Date date12 = fixedMillisecond9.getTime();
        boolean boolean14 = fixedMillisecond9.equals((java.lang.Object) 100);
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond9.getFirstMillisecond(calendar15);
        boolean boolean18 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) fixedMillisecond9, (java.lang.Object) "August");
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond9.getMiddleMillisecond(calendar19);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        int int13 = year11.compareTo((java.lang.Object) "");
        long long14 = year11.getFirstMillisecond();
        int int15 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) year11);
        java.lang.String str16 = timeSeries4.getDomainDescription();
        timeSeries4.setMaximumItemCount((int) (byte) 10);
        java.lang.String str19 = timeSeries4.getDomainDescription();
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) "");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.next();
        try {
            java.lang.Object obj4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) year0);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        java.util.Date date11 = fixedMillisecond9.getEnd();
        java.util.Date date12 = fixedMillisecond9.getTime();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date12);
        java.util.Calendar calendar14 = null;
        try {
            long long15 = month13.getFirstMillisecond(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date12);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.removeAgedItems(false);
        timeSeries2.setMaximumItemCount((int) 'a');
        boolean boolean7 = timeSeries2.isEmpty();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(9, (int) (byte) 0);
        int int3 = month2.getYearValue();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        int int13 = year11.compareTo((java.lang.Object) "");
        long long14 = year11.getFirstMillisecond();
        int int15 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) year11);
        java.lang.String str16 = timeSeries4.getDomainDescription();
        timeSeries4.setMaximumItemCount((int) (byte) 10);
        try {
            timeSeries4.removeAgedItems((long) 2958465, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("ERROR : Relative To String");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        java.util.Date date0 = null;
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class2);
        timeSeries3.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries3.setDomainDescription("");
        java.lang.Class class8 = timeSeries3.getTimePeriodClass();
        timeSeries3.clear();
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class13);
        timeSeries14.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries14.addPropertyChangeListener(propertyChangeListener16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries14.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        int int23 = year21.compareTo((java.lang.Object) "");
        long long24 = year21.getFirstMillisecond();
        int int25 = timeSeries14.getIndex((org.jfree.data.time.RegularTimePeriod) year21);
        java.lang.Class class29 = null;
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class29);
        timeSeries30.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener32 = null;
        timeSeries30.addPropertyChangeListener(propertyChangeListener32);
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries30.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
        java.util.Date date37 = fixedMillisecond35.getEnd();
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date37);
        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year21, (org.jfree.data.time.RegularTimePeriod) day38);
        long long40 = day38.getFirstMillisecond();
        boolean boolean42 = day38.equals((java.lang.Object) 1577865599999L);
        long long43 = day38.getSerialIndex();
        java.util.Date date44 = day38.getStart();
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date44);
        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(date44, timeZone46);
        try {
            org.jfree.data.time.Month month48 = new org.jfree.data.time.Month(date0, timeZone46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1546329600000L + "'", long24 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(timeSeries39);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-57600000L) + "'", long40 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 25568L + "'", long43 == 25568L);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(timeZone46);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class2);
        java.lang.Class<?> wildcardClass4 = timeSeries3.getClass();
        java.util.Date date5 = null;
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date5, timeZone6);
        java.lang.ClassLoader classLoader8 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2, (java.lang.Class) wildcardClass4);
        java.lang.ClassLoader classLoader10 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass4);
        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(classLoader8);
        org.junit.Assert.assertNotNull(classLoader10);
        org.junit.Assert.assertNotNull(class11);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class8);
        timeSeries9.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries9.addPropertyChangeListener(propertyChangeListener11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
        java.util.Date date16 = fixedMillisecond14.getEnd();
        java.util.Date date17 = fixedMillisecond14.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (double) 2958465);
        java.lang.String str20 = timeSeries4.getDomainDescription();
        try {
            timeSeries4.removeAgedItems((long) '#', false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hi!" + "'", str20.equals("hi!"));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries2.setDomainDescription("");
        java.lang.Class class7 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class12);
        timeSeries13.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        int int22 = year20.compareTo((java.lang.Object) "");
        long long23 = year20.getFirstMillisecond();
        int int24 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) year20);
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class28);
        timeSeries29.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timeSeries29.addPropertyChangeListener(propertyChangeListener31);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
        java.util.Date date36 = fixedMillisecond34.getEnd();
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date36);
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) year20, (org.jfree.data.time.RegularTimePeriod) day37);
        org.jfree.data.time.SerialDate serialDate39 = day37.getSerialDate();
        java.util.Date date40 = day37.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day37, (java.lang.Number) 1900);
        java.lang.Class class44 = null;
        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class44);
        timeSeries45.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str48 = timeSeries45.getDescription();
        timeSeries45.setMaximumItemAge((long) 11);
        java.beans.PropertyChangeListener propertyChangeListener51 = null;
        timeSeries45.removePropertyChangeListener(propertyChangeListener51);
        boolean boolean53 = timeSeriesDataItem42.equals((java.lang.Object) propertyChangeListener51);
        java.lang.Class class57 = null;
        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class57);
        timeSeries58.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener60 = null;
        timeSeries58.addPropertyChangeListener(propertyChangeListener60);
        org.jfree.data.time.FixedMillisecond fixedMillisecond63 = new org.jfree.data.time.FixedMillisecond((long) (short) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = fixedMillisecond63.previous();
        java.lang.Number number65 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem66 = timeSeries58.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond63, number65);
        java.util.List list67 = timeSeries58.getItems();
        int int68 = timeSeriesDataItem42.compareTo((java.lang.Object) timeSeries58);
        java.lang.Object obj69 = timeSeriesDataItem42.clone();
        timeSeriesDataItem42.setValue((java.lang.Number) (short) 100);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1546329600000L + "'", long23 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeSeries38);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str48.equals("SerialDate.weekInMonthToString(): invalid code."));
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod64);
        org.junit.Assert.assertNull(timeSeriesDataItem66);
        org.junit.Assert.assertNotNull(list67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 1 + "'", int68 == 1);
        org.junit.Assert.assertNotNull(obj69);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class4);
        java.lang.Class class9 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class9);
        timeSeries10.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries10.addPropertyChangeListener(propertyChangeListener12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries10.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.util.Date date17 = fixedMillisecond15.getEnd();
        java.util.Date date18 = fixedMillisecond15.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (double) 2958465);
        java.util.Calendar calendar21 = null;
        fixedMillisecond15.peg(calendar21);
        java.util.Date date23 = fixedMillisecond15.getTime();
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance(date23);
        try {
            org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2147483647, serialDate24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(serialDate24);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setNotify(true);
        java.lang.Class class5 = null;
        java.lang.Class class9 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class9);
        timeSeries10.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries10.addPropertyChangeListener(propertyChangeListener12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries10.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.util.Date date17 = fixedMillisecond15.getEnd();
        java.util.TimeZone timeZone18 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date17, timeZone18);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date17);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) day20);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        int int24 = year22.compareTo((java.lang.Object) "");
        long long25 = year22.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year22.next();
        long long27 = year22.getLastMillisecond();
        boolean boolean28 = day20.equals((java.lang.Object) long27);
        long long29 = day20.getMiddleMillisecond();
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1546329600000L + "'", long25 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1577865599999L + "'", long27 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-14400001L) + "'", long29 == (-14400001L));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        java.lang.String str4 = month3.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = regularTimePeriod5.getMiddleMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "January 2019" + "'", str4.equals("January 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(4);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "April" + "'", str1.equals("April"));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100, (int) (short) 0, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) "");
        long long3 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.Class class7 = timeSeries6.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod4, class7);
        try {
            timeSeries8.delete(2, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(class7);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((int) (short) 100);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        java.util.Date date11 = fixedMillisecond9.getEnd();
        long long12 = fixedMillisecond9.getMiddleMillisecond();
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        java.lang.Class class1 = null;
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class5);
        timeSeries6.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries6.addPropertyChangeListener(propertyChangeListener8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries6.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11);
        java.util.Date date13 = fixedMillisecond11.getEnd();
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance(class1, date13, timeZone14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond(date13);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year17.previous();
        try {
            org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((-452), year17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class6);
        timeSeries7.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries7.setDomainDescription("");
        java.lang.Class class12 = timeSeries7.getTimePeriodClass();
        timeSeries7.clear();
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class17);
        timeSeries18.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timeSeries18.addPropertyChangeListener(propertyChangeListener20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries18.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        int int27 = year25.compareTo((java.lang.Object) "");
        long long28 = year25.getFirstMillisecond();
        int int29 = timeSeries18.getIndex((org.jfree.data.time.RegularTimePeriod) year25);
        java.lang.Class class33 = null;
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class33);
        timeSeries34.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener36 = null;
        timeSeries34.addPropertyChangeListener(propertyChangeListener36);
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries34.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39);
        java.util.Date date41 = fixedMillisecond39.getEnd();
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(date41);
        org.jfree.data.time.TimeSeries timeSeries43 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) year25, (org.jfree.data.time.RegularTimePeriod) day42);
        java.lang.Class class46 = null;
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class46);
        java.lang.Class<?> wildcardClass48 = timeSeries47.getClass();
        java.util.Date date49 = null;
        java.util.TimeZone timeZone50 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass48, date49, timeZone50);
        java.lang.ClassLoader classLoader52 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass48);
        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2, (java.lang.Class) wildcardClass48);
        org.jfree.data.time.TimeSeries timeSeries54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day42, (java.lang.Class) wildcardClass48);
        int int55 = timeSeries54.getMaximumItemCount();
        boolean boolean56 = fixedMillisecond1.equals((java.lang.Object) int55);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = fixedMillisecond1.next();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1L + "'", long4 == 1L);
        org.junit.Assert.assertNull(class12);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1546329600000L + "'", long28 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem40);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(timeSeries43);
        org.junit.Assert.assertNotNull(wildcardClass48);
        org.junit.Assert.assertNull(regularTimePeriod51);
        org.junit.Assert.assertNotNull(classLoader52);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 2147483647 + "'", int55 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod57);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries2.setDomainDescription("");
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries2.addPropertyChangeListener(propertyChangeListener7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getLastMillisecond();
        java.util.Date date11 = year9.getStart();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(date11);
        int int13 = month12.getYearValue();
        org.jfree.data.time.Year year14 = month12.getYear();
        org.jfree.data.time.Year year15 = month12.getYear();
        try {
            timeSeries2.add((org.jfree.data.time.RegularTimePeriod) year15, 0.0d, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertNotNull(year14);
        org.junit.Assert.assertNotNull(year15);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str5 = timeSeries2.getDescription();
        boolean boolean6 = timeSeries2.getNotify();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str5.equals("SerialDate.weekInMonthToString(): invalid code."));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.clear();
        timeSeries4.removeAgedItems(false);
        boolean boolean8 = timeSeries4.getNotify();
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        int int2 = year0.getYear();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class2);
        timeSeries3.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries3.setDomainDescription("");
        java.lang.Class class8 = timeSeries3.getTimePeriodClass();
        timeSeries3.clear();
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class13);
        timeSeries14.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries14.addPropertyChangeListener(propertyChangeListener16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries14.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        int int23 = year21.compareTo((java.lang.Object) "");
        long long24 = year21.getFirstMillisecond();
        int int25 = timeSeries14.getIndex((org.jfree.data.time.RegularTimePeriod) year21);
        java.lang.Class class29 = null;
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class29);
        timeSeries30.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener32 = null;
        timeSeries30.addPropertyChangeListener(propertyChangeListener32);
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries30.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
        java.util.Date date37 = fixedMillisecond35.getEnd();
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date37);
        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year21, (org.jfree.data.time.RegularTimePeriod) day38);
        org.jfree.data.time.SerialDate serialDate40 = day38.getSerialDate();
        org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.addMonths(29, serialDate40);
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(serialDate40);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1546329600000L + "'", long24 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(timeSeries39);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertNotNull(serialDate41);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 1);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
        java.io.InputStream inputStream4 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("June 2019", class3);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertNull(inputStream4);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class8);
        timeSeries9.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries9.addPropertyChangeListener(propertyChangeListener11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
        java.util.Date date16 = fixedMillisecond14.getEnd();
        java.util.Date date17 = fixedMillisecond14.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (double) 2958465);
        java.util.Calendar calendar20 = null;
        fixedMillisecond14.peg(calendar20);
        java.util.Date date22 = fixedMillisecond14.getTime();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
        int int24 = day23.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day23.previous();
        int int26 = day23.getDayOfMonth();
        long long27 = day23.getLastMillisecond();
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 12 + "'", int24 == 12);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 31 + "'", int26 == 31);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 28799999L + "'", long27 == 28799999L);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-460), "October", "2019", class3);
        int int5 = timeSeries4.getItemCount();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 4);
        timeSeries4.setKey((java.lang.Comparable) fixedMillisecond9);
        java.util.Calendar calendar11 = null;
        long long12 = fixedMillisecond9.getFirstMillisecond(calendar11);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 4L + "'", long12 == 4L);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries2.setDomainDescription("");
        java.lang.Class class7 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class12);
        timeSeries13.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        int int22 = year20.compareTo((java.lang.Object) "");
        long long23 = year20.getFirstMillisecond();
        int int24 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) year20);
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class28);
        timeSeries29.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timeSeries29.addPropertyChangeListener(propertyChangeListener31);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
        java.util.Date date36 = fixedMillisecond34.getEnd();
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date36);
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) year20, (org.jfree.data.time.RegularTimePeriod) day37);
        java.util.Calendar calendar39 = null;
        try {
            day37.peg(calendar39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1546329600000L + "'", long23 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeSeries38);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class8);
        timeSeries9.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries9.addPropertyChangeListener(propertyChangeListener11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
        java.util.Date date16 = fixedMillisecond14.getEnd();
        java.util.Date date17 = fixedMillisecond14.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (double) 2958465);
        java.util.Calendar calendar20 = null;
        fixedMillisecond14.peg(calendar20);
        java.util.Date date22 = fixedMillisecond14.getTime();
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.createInstance(date22);
        serialDate23.setDescription("ThreadContext");
        java.lang.String str26 = serialDate23.getDescription();
        try {
            org.jfree.data.time.SerialDate serialDate28 = serialDate23.getNearestDayOfWeek((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "ThreadContext" + "'", str26.equals("ThreadContext"));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        long long3 = year2.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year2.previous();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.Class class9 = timeSeries8.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod4, "", "org.jfree.data.general.SeriesChangeEvent[source=SerialDate.weekInMonthToString(): invalid code.]", class9);
        java.io.InputStream inputStream11 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("SerialDate.weekInMonthToString(): invalid code.", class9);
        java.lang.ClassLoader classLoader12 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class9);
        java.net.URL uRL13 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("Value", class9);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertNull(inputStream11);
        org.junit.Assert.assertNotNull(classLoader12);
        org.junit.Assert.assertNull(uRL13);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        timeSeries4.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries4.addChangeListener(seriesChangeListener10);
        timeSeries4.setDomainDescription("SerialDate.weekInMonthToString(): invalid code.");
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((-1));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        long long11 = fixedMillisecond9.getFirstMillisecond();
        long long12 = fixedMillisecond9.getLastMillisecond();
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str5 = timeSeries2.getDescription();
        timeSeries2.removeAgedItems(false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = null;
        try {
            int int9 = timeSeries2.getIndex(regularTimePeriod8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str5.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.lang.String str2 = month0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.previous();
        int int4 = month0.getMonth();
        java.lang.String str5 = month0.toString();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "June 2019" + "'", str2.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "June 2019" + "'", str5.equals("June 2019"));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        int int13 = year11.compareTo((java.lang.Object) "");
        long long14 = year11.getFirstMillisecond();
        int int15 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) year11);
        java.lang.String str16 = timeSeries4.getDomainDescription();
        timeSeries4.setMaximumItemCount((int) (byte) 10);
        long long19 = timeSeries4.getMaximumItemAge();
        java.lang.Class class23 = null;
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class23);
        timeSeries24.clear();
        java.lang.Class class29 = null;
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class29);
        timeSeries30.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener32 = null;
        timeSeries30.addPropertyChangeListener(propertyChangeListener32);
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries30.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
        java.util.Date date37 = fixedMillisecond35.getEnd();
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
        long long39 = year38.getLastMillisecond();
        boolean boolean40 = fixedMillisecond35.equals((java.lang.Object) year38);
        int int42 = fixedMillisecond35.compareTo((java.lang.Object) 1577865599999L);
        java.lang.Number number43 = timeSeries24.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35, 10.0d);
        java.lang.Class class49 = null;
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class49);
        timeSeries50.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener52 = null;
        timeSeries50.addPropertyChangeListener(propertyChangeListener52);
        timeSeries50.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
        int int56 = fixedMillisecond35.compareTo((java.lang.Object) "SerialDate.weekInMonthToString(): invalid code.");
        long long57 = fixedMillisecond35.getLastMillisecond();
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 9223372036854775807L + "'", long19 == 9223372036854775807L);
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1577865599999L + "'", long39 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertNull(number43);
        org.junit.Assert.assertNull(timeSeriesDataItem45);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 0L + "'", long57 == 0L);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class8);
        timeSeries9.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries9.addPropertyChangeListener(propertyChangeListener11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
        java.util.Date date16 = fixedMillisecond14.getEnd();
        java.util.Date date17 = fixedMillisecond14.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (double) 2958465);
        java.util.Calendar calendar20 = null;
        fixedMillisecond14.peg(calendar20);
        java.util.Date date22 = fixedMillisecond14.getTime();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month(date22, timeZone24);
        java.lang.Class class29 = null;
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class29);
        java.lang.Class class34 = null;
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class34);
        timeSeries35.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener37 = null;
        timeSeries35.addPropertyChangeListener(propertyChangeListener37);
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries35.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40);
        java.util.Date date42 = fixedMillisecond40.getEnd();
        java.util.Date date43 = fixedMillisecond40.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = timeSeries30.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40, (double) 2958465);
        java.util.Calendar calendar46 = null;
        fixedMillisecond40.peg(calendar46);
        java.util.Date date48 = fixedMillisecond40.getTime();
        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day(date48);
        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month(date48, timeZone50);
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year(date22, timeZone50);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(timeSeriesDataItem41);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNull(timeSeriesDataItem45);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(timeZone50);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(2019);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        int int4 = month3.getMonth();
        int int5 = month3.getYearValue();
        long long6 = month3.getSerialIndex();
        boolean boolean8 = month3.equals((java.lang.Object) 100);
        int int9 = month3.getMonth();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 24229L + "'", long6 == 24229L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 1);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        long long4 = fixedMillisecond1.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.Class class9 = timeSeries8.getTimePeriodClass();
        java.lang.ClassLoader classLoader10 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class9);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, "Fourth", "", class9);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries11.removeChangeListener(seriesChangeListener12);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1L + "'", long4 == 1L);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertNotNull(classLoader10);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        java.lang.Class<?> wildcardClass3 = timeSeries2.getClass();
        java.lang.Class class7 = null;
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class7);
        timeSeries8.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries8.addPropertyChangeListener(propertyChangeListener10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries8.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        int int17 = year15.compareTo((java.lang.Object) "");
        long long18 = year15.getFirstMillisecond();
        int int19 = timeSeries8.getIndex((org.jfree.data.time.RegularTimePeriod) year15);
        java.lang.String str20 = timeSeries8.getDomainDescription();
        timeSeries8.setMaximumItemCount((int) (byte) 10);
        long long23 = timeSeries8.getMaximumItemAge();
        java.lang.Class class27 = null;
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class27);
        timeSeries28.clear();
        java.lang.Class class33 = null;
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class33);
        timeSeries34.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener36 = null;
        timeSeries34.addPropertyChangeListener(propertyChangeListener36);
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries34.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39);
        java.util.Date date41 = fixedMillisecond39.getEnd();
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
        long long43 = year42.getLastMillisecond();
        boolean boolean44 = fixedMillisecond39.equals((java.lang.Object) year42);
        int int46 = fixedMillisecond39.compareTo((java.lang.Object) 1577865599999L);
        java.lang.Number number47 = timeSeries28.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, 10.0d);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (double) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = fixedMillisecond39.next();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1546329600000L + "'", long18 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hi!" + "'", str20.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 9223372036854775807L + "'", long23 == 9223372036854775807L);
        org.junit.Assert.assertNull(timeSeriesDataItem40);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1577865599999L + "'", long43 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
        org.junit.Assert.assertNull(number47);
        org.junit.Assert.assertNull(timeSeriesDataItem49);
        org.junit.Assert.assertNull(timeSeriesDataItem51);
        org.junit.Assert.assertNotNull(regularTimePeriod52);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.removeAgedItems(false);
        timeSeries2.setMaximumItemCount((int) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        int int9 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        try {
            timeSeries2.delete((int) (short) 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class4);
        timeSeries5.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries5.setDomainDescription("");
        java.lang.Class class10 = timeSeries5.getTimePeriodClass();
        timeSeries5.clear();
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class15);
        timeSeries16.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timeSeries16.addPropertyChangeListener(propertyChangeListener18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries16.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        int int25 = year23.compareTo((java.lang.Object) "");
        long long26 = year23.getFirstMillisecond();
        int int27 = timeSeries16.getIndex((org.jfree.data.time.RegularTimePeriod) year23);
        java.lang.Class class31 = null;
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class31);
        timeSeries32.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener34 = null;
        timeSeries32.addPropertyChangeListener(propertyChangeListener34);
        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries32.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond37);
        java.util.Date date39 = fixedMillisecond37.getEnd();
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date39);
        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) year23, (org.jfree.data.time.RegularTimePeriod) day40);
        org.jfree.data.time.SerialDate serialDate42 = day40.getSerialDate();
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.addMonths(29, serialDate42);
        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(3, serialDate43);
        java.lang.Class class47 = null;
        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class47);
        timeSeries48.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries48.setDomainDescription("");
        java.lang.Class class53 = timeSeries48.getTimePeriodClass();
        timeSeries48.clear();
        java.lang.Class class58 = null;
        org.jfree.data.time.TimeSeries timeSeries59 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class58);
        timeSeries59.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener61 = null;
        timeSeries59.addPropertyChangeListener(propertyChangeListener61);
        org.jfree.data.time.FixedMillisecond fixedMillisecond64 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem65 = timeSeries59.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond64);
        org.jfree.data.time.Year year66 = new org.jfree.data.time.Year();
        int int68 = year66.compareTo((java.lang.Object) "");
        long long69 = year66.getFirstMillisecond();
        int int70 = timeSeries59.getIndex((org.jfree.data.time.RegularTimePeriod) year66);
        java.lang.Class class74 = null;
        org.jfree.data.time.TimeSeries timeSeries75 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class74);
        timeSeries75.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener77 = null;
        timeSeries75.addPropertyChangeListener(propertyChangeListener77);
        org.jfree.data.time.FixedMillisecond fixedMillisecond80 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem81 = timeSeries75.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond80);
        java.util.Date date82 = fixedMillisecond80.getEnd();
        org.jfree.data.time.Day day83 = new org.jfree.data.time.Day(date82);
        org.jfree.data.time.TimeSeries timeSeries84 = timeSeries48.createCopy((org.jfree.data.time.RegularTimePeriod) year66, (org.jfree.data.time.RegularTimePeriod) day83);
        org.jfree.data.time.SerialDate serialDate85 = day83.getSerialDate();
        org.jfree.data.time.SerialDate serialDate86 = org.jfree.data.time.SerialDate.addMonths(29, serialDate85);
        org.jfree.data.time.SerialDate serialDate87 = serialDate43.getEndOfCurrentMonth(serialDate86);
        org.jfree.data.time.SerialDate serialDate89 = serialDate87.getPreviousDayOfWeek(7);
        try {
            org.jfree.data.time.SerialDate serialDate90 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(11, serialDate87);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(class10);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1546329600000L + "'", long26 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem38);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(timeSeries41);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNull(class53);
        org.junit.Assert.assertNull(timeSeriesDataItem65);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 1 + "'", int68 == 1);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 1546329600000L + "'", long69 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + (-1) + "'", int70 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem81);
        org.junit.Assert.assertNotNull(date82);
        org.junit.Assert.assertNotNull(timeSeries84);
        org.junit.Assert.assertNotNull(serialDate85);
        org.junit.Assert.assertNotNull(serialDate86);
        org.junit.Assert.assertNotNull(serialDate87);
        org.junit.Assert.assertNotNull(serialDate89);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year0.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) "");
        long long3 = year0.getSerialIndex();
        java.util.Calendar calendar4 = null;
        try {
            year0.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str5 = timeSeries2.getDescription();
        timeSeries2.setDescription("2019");
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        long long9 = year8.getLastMillisecond();
        java.util.Date date10 = year8.getStart();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
        java.lang.String str12 = month11.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month11.next();
        timeSeries2.setKey((java.lang.Comparable) month11);
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class16);
        timeSeries17.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries17.setDomainDescription("");
        java.lang.Class class22 = timeSeries17.getTimePeriodClass();
        timeSeries17.clear();
        java.lang.Class class27 = null;
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class27);
        timeSeries28.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener30 = null;
        timeSeries28.addPropertyChangeListener(propertyChangeListener30);
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries28.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond33);
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
        int int37 = year35.compareTo((java.lang.Object) "");
        long long38 = year35.getFirstMillisecond();
        int int39 = timeSeries28.getIndex((org.jfree.data.time.RegularTimePeriod) year35);
        java.lang.Class class43 = null;
        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class43);
        timeSeries44.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener46 = null;
        timeSeries44.addPropertyChangeListener(propertyChangeListener46);
        org.jfree.data.time.FixedMillisecond fixedMillisecond49 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = timeSeries44.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond49);
        java.util.Date date51 = fixedMillisecond49.getEnd();
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(date51);
        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) year35, (org.jfree.data.time.RegularTimePeriod) day52);
        try {
            timeSeries2.add((org.jfree.data.time.RegularTimePeriod) year35, (java.lang.Number) 11, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str5.equals("SerialDate.weekInMonthToString(): invalid code."));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "January 2019" + "'", str12.equals("January 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(class22);
        org.junit.Assert.assertNull(timeSeriesDataItem34);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1546329600000L + "'", long38 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem50);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNotNull(timeSeries53);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class8);
        timeSeries9.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries9.addPropertyChangeListener(propertyChangeListener11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
        java.util.Date date16 = fixedMillisecond14.getEnd();
        java.util.Date date17 = fixedMillisecond14.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (double) 2958465);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries4.removeChangeListener(seriesChangeListener20);
        java.lang.Class class23 = null;
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class23);
        timeSeries24.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries24.setDomainDescription("");
        java.lang.Class class29 = timeSeries24.getTimePeriodClass();
        timeSeries24.clear();
        java.lang.Class class34 = null;
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class34);
        timeSeries35.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener37 = null;
        timeSeries35.addPropertyChangeListener(propertyChangeListener37);
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries35.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40);
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
        int int44 = year42.compareTo((java.lang.Object) "");
        long long45 = year42.getFirstMillisecond();
        int int46 = timeSeries35.getIndex((org.jfree.data.time.RegularTimePeriod) year42);
        java.lang.Class class50 = null;
        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class50);
        timeSeries51.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener53 = null;
        timeSeries51.addPropertyChangeListener(propertyChangeListener53);
        org.jfree.data.time.FixedMillisecond fixedMillisecond56 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem57 = timeSeries51.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond56);
        java.util.Date date58 = fixedMillisecond56.getEnd();
        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day(date58);
        org.jfree.data.time.TimeSeries timeSeries60 = timeSeries24.createCopy((org.jfree.data.time.RegularTimePeriod) year42, (org.jfree.data.time.RegularTimePeriod) day59);
        long long61 = day59.getFirstMillisecond();
        boolean boolean63 = day59.equals((java.lang.Object) 1577865599999L);
        timeSeries4.setKey((java.lang.Comparable) boolean63);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem66 = timeSeries4.getDataItem(0);
        java.lang.Object obj67 = timeSeriesDataItem66.clone();
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertNull(class29);
        org.junit.Assert.assertNull(timeSeriesDataItem41);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1546329600000L + "'", long45 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem57);
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertNotNull(timeSeries60);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + (-57600000L) + "'", long61 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem66);
        org.junit.Assert.assertNotNull(obj67);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-460), "October", "2019", class3);
        int int5 = timeSeries4.getItemCount();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        timeSeries4.clear();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class12);
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class17);
        timeSeries18.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timeSeries18.addPropertyChangeListener(propertyChangeListener20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries18.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23);
        java.util.Date date25 = fixedMillisecond23.getEnd();
        java.util.Date date26 = fixedMillisecond23.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, (double) 2958465);
        java.util.Calendar calendar29 = null;
        fixedMillisecond23.peg(calendar29);
        java.util.Date date31 = fixedMillisecond23.getTime();
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date31);
        int int33 = day32.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = day32.previous();
        try {
            timeSeries4.add(regularTimePeriod34, (double) (-31507200000L), true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNull(timeSeriesDataItem28);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 12 + "'", int33 == 12);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        java.util.Date date11 = fixedMillisecond9.getEnd();
        int int13 = fixedMillisecond9.compareTo((java.lang.Object) "SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str14 = fixedMillisecond9.toString();
        long long15 = fixedMillisecond9.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond9.previous();
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str14.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        java.util.Calendar calendar3 = null;
        fixedMillisecond1.peg(calendar3);
        long long5 = fixedMillisecond1.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.lang.String str2 = month0.toString();
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class4);
        timeSeries5.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries5.setDomainDescription("");
        java.lang.Class class10 = timeSeries5.getTimePeriodClass();
        timeSeries5.clear();
        boolean boolean13 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) timeSeries5, (java.lang.Object) "January 2019");
        boolean boolean14 = month0.equals((java.lang.Object) timeSeries5);
        long long15 = month0.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "June 2019" + "'", str2.equals("June 2019"));
        org.junit.Assert.assertNull(class10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1561964399999L + "'", long15 == 1561964399999L);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        java.lang.String str4 = month3.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year6.previous();
        int int9 = month3.compareTo((java.lang.Object) year6);
        long long10 = year6.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "January 2019" + "'", str4.equals("January 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("Time");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-460), "October", "2019", class3);
        int int5 = timeSeries4.getItemCount();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries4.addChangeListener(seriesChangeListener8);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) "SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str6 = seriesChangeEvent5.toString();
        java.lang.Object obj7 = seriesChangeEvent5.getSource();
        java.lang.Object obj8 = seriesChangeEvent5.getSource();
        java.lang.Object obj9 = seriesChangeEvent5.getSource();
        java.lang.String str10 = seriesChangeEvent5.toString();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=SerialDate.weekInMonthToString(): invalid code.]" + "'", str6.equals("org.jfree.data.general.SeriesChangeEvent[source=SerialDate.weekInMonthToString(): invalid code.]"));
        org.junit.Assert.assertTrue("'" + obj7 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", obj7.equals("SerialDate.weekInMonthToString(): invalid code."));
        org.junit.Assert.assertTrue("'" + obj8 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", obj8.equals("SerialDate.weekInMonthToString(): invalid code."));
        org.junit.Assert.assertTrue("'" + obj9 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", obj9.equals("SerialDate.weekInMonthToString(): invalid code."));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=SerialDate.weekInMonthToString(): invalid code.]" + "'", str10.equals("org.jfree.data.general.SeriesChangeEvent[source=SerialDate.weekInMonthToString(): invalid code.]"));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        int int4 = month3.getYearValue();
        org.jfree.data.time.Year year5 = month3.getYear();
        long long6 = month3.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1549007999999L + "'", long6 == 1549007999999L);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class3);
        java.lang.Class<?> wildcardClass5 = timeSeries4.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        java.lang.ClassLoader classLoader9 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass5);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2, (java.lang.Class) wildcardClass5);
        java.net.URL uRL11 = org.jfree.chart.util.ObjectUtilities.getResource("", (java.lang.Class) wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(classLoader9);
        org.junit.Assert.assertNotNull(uRL11);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries2.setDomainDescription("");
        java.lang.String str7 = timeSeries2.getDomainDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        int int11 = year9.compareTo((java.lang.Object) "");
        long long12 = year9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year9.next();
        java.lang.String str14 = year9.toString();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(9, year9);
        java.lang.Number number16 = null;
        try {
            timeSeries2.add((org.jfree.data.time.RegularTimePeriod) year9, number16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1546329600000L + "'", long12 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019" + "'", str14.equals("2019"));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class4);
        timeSeries5.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries5.setDomainDescription("");
        java.lang.Class class10 = timeSeries5.getTimePeriodClass();
        timeSeries5.clear();
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class15);
        timeSeries16.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timeSeries16.addPropertyChangeListener(propertyChangeListener18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries16.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        int int25 = year23.compareTo((java.lang.Object) "");
        long long26 = year23.getFirstMillisecond();
        int int27 = timeSeries16.getIndex((org.jfree.data.time.RegularTimePeriod) year23);
        java.lang.Class class31 = null;
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class31);
        timeSeries32.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener34 = null;
        timeSeries32.addPropertyChangeListener(propertyChangeListener34);
        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries32.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond37);
        java.util.Date date39 = fixedMillisecond37.getEnd();
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date39);
        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) year23, (org.jfree.data.time.RegularTimePeriod) day40);
        org.jfree.data.time.SerialDate serialDate42 = day40.getSerialDate();
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.addMonths(29, serialDate42);
        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.addYears((int) (byte) -1, serialDate43);
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.addMonths((-459), serialDate44);
        org.jfree.data.time.SerialDate serialDate47 = serialDate44.getPreviousDayOfWeek(4);
        java.lang.Class class51 = null;
        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class51);
        timeSeries52.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries52.setDomainDescription("");
        java.lang.Class class57 = timeSeries52.getTimePeriodClass();
        timeSeries52.clear();
        java.lang.Class class62 = null;
        org.jfree.data.time.TimeSeries timeSeries63 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class62);
        timeSeries63.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener65 = null;
        timeSeries63.addPropertyChangeListener(propertyChangeListener65);
        org.jfree.data.time.FixedMillisecond fixedMillisecond68 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem69 = timeSeries63.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond68);
        org.jfree.data.time.Year year70 = new org.jfree.data.time.Year();
        int int72 = year70.compareTo((java.lang.Object) "");
        long long73 = year70.getFirstMillisecond();
        int int74 = timeSeries63.getIndex((org.jfree.data.time.RegularTimePeriod) year70);
        java.lang.Class class78 = null;
        org.jfree.data.time.TimeSeries timeSeries79 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class78);
        timeSeries79.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener81 = null;
        timeSeries79.addPropertyChangeListener(propertyChangeListener81);
        org.jfree.data.time.FixedMillisecond fixedMillisecond84 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem85 = timeSeries79.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond84);
        java.util.Date date86 = fixedMillisecond84.getEnd();
        org.jfree.data.time.Day day87 = new org.jfree.data.time.Day(date86);
        org.jfree.data.time.TimeSeries timeSeries88 = timeSeries52.createCopy((org.jfree.data.time.RegularTimePeriod) year70, (org.jfree.data.time.RegularTimePeriod) day87);
        org.jfree.data.time.SerialDate serialDate89 = day87.getSerialDate();
        org.jfree.data.time.SerialDate serialDate90 = org.jfree.data.time.SerialDate.addMonths(29, serialDate89);
        org.jfree.data.time.SerialDate serialDate91 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(3, serialDate90);
        java.lang.String str92 = serialDate91.getDescription();
        java.lang.String str93 = serialDate91.getDescription();
        org.jfree.data.time.SerialDate serialDate94 = serialDate47.getEndOfCurrentMonth(serialDate91);
        try {
            org.jfree.data.time.SerialDate serialDate96 = serialDate91.getNearestDayOfWeek(8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(class10);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1546329600000L + "'", long26 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem38);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(timeSeries41);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertNull(class57);
        org.junit.Assert.assertNull(timeSeriesDataItem69);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 1 + "'", int72 == 1);
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 1546329600000L + "'", long73 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + (-1) + "'", int74 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem85);
        org.junit.Assert.assertNotNull(date86);
        org.junit.Assert.assertNotNull(timeSeries88);
        org.junit.Assert.assertNotNull(serialDate89);
        org.junit.Assert.assertNotNull(serialDate90);
        org.junit.Assert.assertNotNull(serialDate91);
        org.junit.Assert.assertNull(str92);
        org.junit.Assert.assertNull(str93);
        org.junit.Assert.assertNotNull(serialDate94);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries2.setDomainDescription("");
        java.lang.Class class7 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class12);
        timeSeries13.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        int int22 = year20.compareTo((java.lang.Object) "");
        long long23 = year20.getFirstMillisecond();
        int int24 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) year20);
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class28);
        timeSeries29.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timeSeries29.addPropertyChangeListener(propertyChangeListener31);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
        java.util.Date date36 = fixedMillisecond34.getEnd();
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date36);
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) year20, (org.jfree.data.time.RegularTimePeriod) day37);
        long long39 = day37.getFirstMillisecond();
        boolean boolean41 = day37.equals((java.lang.Object) 1577865599999L);
        long long42 = day37.getSerialIndex();
        java.util.Date date43 = day37.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = day37.previous();
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1546329600000L + "'", long23 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeSeries38);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-57600000L) + "'", long39 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 25568L + "'", long42 == 25568L);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        int int4 = month3.getMonth();
        int int5 = month3.getYearValue();
        java.lang.String str6 = month3.toString();
        org.jfree.data.time.Year year7 = month3.getYear();
        boolean boolean9 = year7.equals((java.lang.Object) "31-December-1969");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "January 2019" + "'", str6.equals("January 2019"));
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.Class class7 = timeSeries6.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod2, "", "org.jfree.data.general.SeriesChangeEvent[source=SerialDate.weekInMonthToString(): invalid code.]", class7);
        timeSeries8.removeAgedItems(false);
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class13);
        java.lang.Class<?> wildcardClass15 = timeSeries14.getClass();
        java.util.Date date16 = null;
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date16, timeZone17);
        java.lang.ClassLoader classLoader19 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass15);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2, (java.lang.Class) wildcardClass15);
        java.lang.Class class24 = null;
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class24);
        timeSeries25.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener27 = null;
        timeSeries25.addPropertyChangeListener(propertyChangeListener27);
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries25.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30);
        java.util.Date date32 = fixedMillisecond30.getEnd();
        java.util.Date date33 = fixedMillisecond30.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (java.lang.Number) 2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = fixedMillisecond30.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod36, (double) 11);
        try {
            timeSeries8.add(regularTimePeriod36, (java.lang.Number) 9);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(classLoader19);
        org.junit.Assert.assertNull(timeSeriesDataItem31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        timeSeries1.setDescription("2019");
        try {
            java.lang.Number number5 = timeSeries1.getValue((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 1);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        long long4 = fixedMillisecond1.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.Class class9 = timeSeries8.getTimePeriodClass();
        java.lang.ClassLoader classLoader10 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class9);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, "Fourth", "", class9);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (short) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond14.previous();
        boolean boolean16 = timeSeries12.equals((java.lang.Object) fixedMillisecond14);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1L + "'", long4 == 1L);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertNotNull(classLoader10);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("ThreadContext");
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((-458));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class4);
        java.lang.Class<?> wildcardClass6 = timeSeries5.getClass();
        java.util.Date date7 = null;
        java.util.TimeZone timeZone8 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date7, timeZone8);
        java.lang.ClassLoader classLoader10 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass6);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2, (java.lang.Class) wildcardClass6);
        java.lang.ClassLoader classLoader12 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass6);
        java.net.URL uRL13 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("August", (java.lang.Class) wildcardClass6);
        java.io.InputStream inputStream14 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("April", (java.lang.Class) wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(classLoader10);
        org.junit.Assert.assertNotNull(classLoader12);
        org.junit.Assert.assertNull(uRL13);
        org.junit.Assert.assertNull(inputStream14);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((-451));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class8);
        timeSeries9.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries9.addPropertyChangeListener(propertyChangeListener11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
        java.util.Date date16 = fixedMillisecond14.getEnd();
        java.util.Date date17 = fixedMillisecond14.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (double) 2958465);
        java.util.Calendar calendar20 = null;
        fixedMillisecond14.peg(calendar20);
        java.util.Date date22 = fixedMillisecond14.getTime();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
        int int24 = day23.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day23.previous();
        org.jfree.data.time.SerialDate serialDate26 = day23.getSerialDate();
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 12 + "'", int24 == 12);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(serialDate26);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        long long3 = year2.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year2.previous();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.Class class9 = timeSeries8.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod4, "", "org.jfree.data.general.SeriesChangeEvent[source=SerialDate.weekInMonthToString(): invalid code.]", class9);
        java.io.InputStream inputStream11 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("SerialDate.weekInMonthToString(): invalid code.", class9);
        java.lang.ClassLoader classLoader12 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class9);
        java.io.InputStream inputStream13 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", class9);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertNull(inputStream11);
        org.junit.Assert.assertNotNull(classLoader12);
        org.junit.Assert.assertNotNull(inputStream13);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str5 = timeSeries2.getDescription();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getLastMillisecond();
        long long8 = year6.getSerialIndex();
        int int9 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) year6);
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class17);
        java.lang.Class<?> wildcardClass19 = timeSeries18.getClass();
        java.util.Date date20 = null;
        java.util.TimeZone timeZone21 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date20, timeZone21);
        java.lang.ClassLoader classLoader23 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass19);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2, (java.lang.Class) wildcardClass19);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, "ThreadContext", "org.jfree.data.general.SeriesException: ", (java.lang.Class) wildcardClass19);
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year6, "Following", "Fourth", (java.lang.Class) wildcardClass19);
        java.lang.Class class30 = null;
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class30);
        timeSeries31.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener33 = null;
        timeSeries31.addPropertyChangeListener(propertyChangeListener33);
        boolean boolean35 = timeSeries31.isEmpty();
        boolean boolean36 = timeSeries31.isEmpty();
        java.util.Collection collection37 = timeSeries26.getTimePeriodsUniqueToOtherSeries(timeSeries31);
        java.lang.Class class41 = null;
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class41);
        timeSeries42.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener44 = null;
        timeSeries42.addPropertyChangeListener(propertyChangeListener44);
        boolean boolean46 = timeSeries42.isEmpty();
        boolean boolean47 = timeSeries42.getNotify();
        java.util.Collection collection48 = timeSeries26.getTimePeriodsUniqueToOtherSeries(timeSeries42);
        java.util.Collection collection49 = org.jfree.chart.util.ObjectUtilities.deepClone(collection48);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str5.equals("SerialDate.weekInMonthToString(): invalid code."));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(classLoader23);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(collection37);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(collection48);
        org.junit.Assert.assertNotNull(collection49);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        java.lang.String str4 = month3.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year6.previous();
        int int9 = month3.compareTo((java.lang.Object) year6);
        int int11 = month3.compareTo((java.lang.Object) 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "January 2019" + "'", str4.equals("January 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str5 = timeSeries2.getDescription();
        timeSeries2.setMaximumItemAge((long) 11);
        org.jfree.data.time.TimeSeries timeSeries8 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries9 = timeSeries2.addAndOrUpdate(timeSeries8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str5.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 1);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        long long4 = fixedMillisecond1.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.Class class9 = timeSeries8.getTimePeriodClass();
        java.lang.ClassLoader classLoader10 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class9);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, "Fourth", "", class9);
        java.util.Calendar calendar12 = null;
        fixedMillisecond1.peg(calendar12);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1L + "'", long4 == 1L);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertNotNull(classLoader10);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        int int13 = year11.compareTo((java.lang.Object) "");
        long long14 = year11.getFirstMillisecond();
        int int15 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) year11);
        java.lang.String str16 = timeSeries4.getDomainDescription();
        timeSeries4.setMaximumItemCount((int) (byte) 10);
        long long19 = timeSeries4.getMaximumItemAge();
        java.lang.Number number21 = null;
        try {
            timeSeries4.update(0, number21);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 9223372036854775807L + "'", long19 == 9223372036854775807L);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class8);
        timeSeries9.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries9.addPropertyChangeListener(propertyChangeListener11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
        java.util.Date date16 = fixedMillisecond14.getEnd();
        java.util.Date date17 = fixedMillisecond14.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (double) 2958465);
        timeSeries4.clear();
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        java.util.Date date11 = fixedMillisecond9.getEnd();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getLastMillisecond();
        boolean boolean14 = fixedMillisecond9.equals((java.lang.Object) year12);
        int int16 = fixedMillisecond9.compareTo((java.lang.Object) 1577865599999L);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getLastMillisecond();
        java.util.Date date19 = year17.getStart();
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(date19);
        boolean boolean21 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) int16, (java.lang.Object) month20);
        java.lang.String str22 = month20.toString();
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577865599999L + "'", long18 == 1577865599999L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "January 2019" + "'", str22.equals("January 2019"));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        boolean boolean8 = timeSeries4.isEmpty();
        boolean boolean9 = timeSeries4.getNotify();
        boolean boolean10 = timeSeries4.getNotify();
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((int) (byte) 10, false);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "October" + "'", str2.equals("October"));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class6);
        timeSeries7.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener9);
        boolean boolean11 = timeSeries7.isEmpty();
        boolean boolean12 = timeSeries7.isEmpty();
        timeSeries7.setMaximumItemCount(0);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        long long16 = year15.getLastMillisecond();
        java.util.Date date17 = year15.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year15.next();
        long long19 = year15.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year15.previous();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) year15);
        boolean boolean22 = year0.equals((java.lang.Object) year15);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1577865599999L + "'", long16 == 1577865599999L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1577865599999L + "'", long19 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setNotify(true);
        timeSeries2.setMaximumItemCount((int) '#');
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getLastMillisecond();
        java.util.Date date9 = year7.getStart();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date9);
        java.lang.String str11 = month10.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month10.next();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year13.previous();
        int int16 = month10.compareTo((java.lang.Object) year13);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month10, (double) 'a');
        java.lang.Object obj19 = null;
        int int20 = month10.compareTo(obj19);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "January 2019" + "'", str11.equals("January 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        java.lang.Class<?> wildcardClass3 = timeSeries2.getClass();
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries2.removePropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries2.createCopy(29, 31);
        java.util.Collection collection9 = timeSeries2.getTimePeriods();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertNotNull(collection9);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date1, timeZone2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date1);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        java.lang.String str3 = timeSeries2.getRangeDescription();
        java.lang.String str4 = timeSeries2.getDomainDescription();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class6);
        timeSeries7.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries7.setDomainDescription("");
        java.lang.Class class12 = timeSeries7.getTimePeriodClass();
        timeSeries7.clear();
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class17);
        timeSeries18.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timeSeries18.addPropertyChangeListener(propertyChangeListener20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries18.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        int int27 = year25.compareTo((java.lang.Object) "");
        long long28 = year25.getFirstMillisecond();
        int int29 = timeSeries18.getIndex((org.jfree.data.time.RegularTimePeriod) year25);
        java.lang.Class class33 = null;
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class33);
        timeSeries34.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener36 = null;
        timeSeries34.addPropertyChangeListener(propertyChangeListener36);
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries34.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39);
        java.util.Date date41 = fixedMillisecond39.getEnd();
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(date41);
        org.jfree.data.time.TimeSeries timeSeries43 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) year25, (org.jfree.data.time.RegularTimePeriod) day42);
        long long44 = day42.getFirstMillisecond();
        boolean boolean46 = day42.equals((java.lang.Object) 1577865599999L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day42, (java.lang.Number) (-31507200000L));
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) day42);
        long long50 = day42.getSerialIndex();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Value" + "'", str3.equals("Value"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
        org.junit.Assert.assertNull(class12);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1546329600000L + "'", long28 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem40);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(timeSeries43);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-57600000L) + "'", long44 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 25568L + "'", long50 == 25568L);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("ClassContext");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.lang.String str2 = month0.toString();
        java.util.Calendar calendar3 = null;
        try {
            month0.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "June 2019" + "'", str2.equals("June 2019"));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(5, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        int int2 = month0.getMonth();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("ClassContext");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(11);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        java.util.Date date11 = fixedMillisecond9.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        int int13 = day12.getMonth();
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class17);
        timeSeries18.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timeSeries18.addPropertyChangeListener(propertyChangeListener20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries18.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23);
        long long25 = fixedMillisecond23.getLastMillisecond();
        boolean boolean26 = day12.equals((java.lang.Object) fixedMillisecond23);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 12 + "'", int13 == 12);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries2.setDomainDescription("");
        java.lang.Class class7 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class12);
        timeSeries13.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        int int22 = year20.compareTo((java.lang.Object) "");
        long long23 = year20.getFirstMillisecond();
        int int24 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) year20);
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class28);
        timeSeries29.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timeSeries29.addPropertyChangeListener(propertyChangeListener31);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
        java.util.Date date36 = fixedMillisecond34.getEnd();
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date36);
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) year20, (org.jfree.data.time.RegularTimePeriod) day37);
        org.jfree.data.time.SerialDate serialDate39 = day37.getSerialDate();
        java.util.Date date40 = day37.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day37, (java.lang.Number) 1900);
        java.lang.Class class46 = null;
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class46);
        timeSeries47.clear();
        java.lang.Class class52 = null;
        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class52);
        timeSeries53.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener55 = null;
        timeSeries53.addPropertyChangeListener(propertyChangeListener55);
        org.jfree.data.time.FixedMillisecond fixedMillisecond58 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem59 = timeSeries53.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond58);
        java.util.Date date60 = fixedMillisecond58.getEnd();
        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year();
        long long62 = year61.getLastMillisecond();
        boolean boolean63 = fixedMillisecond58.equals((java.lang.Object) year61);
        int int65 = fixedMillisecond58.compareTo((java.lang.Object) 1577865599999L);
        java.lang.Number number66 = timeSeries47.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond58);
        boolean boolean67 = day37.equals((java.lang.Object) timeSeries47);
        java.lang.Object obj68 = timeSeries47.clone();
        java.lang.String str69 = timeSeries47.getDescription();
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1546329600000L + "'", long23 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeSeries38);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNull(timeSeriesDataItem59);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 1577865599999L + "'", long62 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1 + "'", int65 == 1);
        org.junit.Assert.assertNull(number66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(obj68);
        org.junit.Assert.assertNull(str69);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        timeSeries3.setDescription("2019");
        java.lang.Class class6 = timeSeries3.getTimePeriodClass();
        java.lang.ClassLoader classLoader7 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class6);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.Class class10 = timeSeries9.getTimePeriodClass();
        java.lang.ClassLoader classLoader11 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class10);
        java.lang.Object obj12 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("January", class6, class10);
        java.io.InputStream inputStream13 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("Nearest", class10);
        org.junit.Assert.assertNotNull(class6);
        org.junit.Assert.assertNotNull(classLoader7);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertNotNull(classLoader11);
        org.junit.Assert.assertNull(obj12);
        org.junit.Assert.assertNull(inputStream13);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class2);
        timeSeries3.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str6 = timeSeries3.getDescription();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getLastMillisecond();
        long long9 = year7.getSerialIndex();
        int int10 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) year7);
        java.lang.Class class18 = null;
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class18);
        java.lang.Class<?> wildcardClass20 = timeSeries19.getClass();
        java.util.Date date21 = null;
        java.util.TimeZone timeZone22 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass20, date21, timeZone22);
        java.lang.ClassLoader classLoader24 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass20);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2, (java.lang.Class) wildcardClass20);
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, "ThreadContext", "org.jfree.data.general.SeriesException: ", (java.lang.Class) wildcardClass20);
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year7, "Following", "Fourth", (java.lang.Class) wildcardClass20);
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), (java.lang.Class) wildcardClass20);
        try {
            timeSeries28.delete((-460), 31);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -460");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str6.equals("SerialDate.weekInMonthToString(): invalid code."));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2019L + "'", long9 == 2019L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(classLoader24);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class8);
        timeSeries9.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries9.addPropertyChangeListener(propertyChangeListener11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
        java.util.Date date16 = fixedMillisecond14.getEnd();
        java.util.Date date17 = fixedMillisecond14.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (double) 2958465);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries4.removeChangeListener(seriesChangeListener20);
        java.lang.Class class23 = null;
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class23);
        timeSeries24.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries24.setDomainDescription("");
        java.lang.Class class29 = timeSeries24.getTimePeriodClass();
        timeSeries24.clear();
        java.lang.Class class34 = null;
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class34);
        timeSeries35.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener37 = null;
        timeSeries35.addPropertyChangeListener(propertyChangeListener37);
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries35.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40);
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
        int int44 = year42.compareTo((java.lang.Object) "");
        long long45 = year42.getFirstMillisecond();
        int int46 = timeSeries35.getIndex((org.jfree.data.time.RegularTimePeriod) year42);
        java.lang.Class class50 = null;
        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class50);
        timeSeries51.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener53 = null;
        timeSeries51.addPropertyChangeListener(propertyChangeListener53);
        org.jfree.data.time.FixedMillisecond fixedMillisecond56 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem57 = timeSeries51.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond56);
        java.util.Date date58 = fixedMillisecond56.getEnd();
        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day(date58);
        org.jfree.data.time.TimeSeries timeSeries60 = timeSeries24.createCopy((org.jfree.data.time.RegularTimePeriod) year42, (org.jfree.data.time.RegularTimePeriod) day59);
        long long61 = day59.getFirstMillisecond();
        boolean boolean63 = day59.equals((java.lang.Object) 1577865599999L);
        timeSeries4.setKey((java.lang.Comparable) boolean63);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem66 = timeSeries4.getDataItem(0);
        java.lang.Number number67 = timeSeriesDataItem66.getValue();
        timeSeriesDataItem66.setValue((java.lang.Number) 100);
        java.lang.Class class73 = null;
        org.jfree.data.time.TimeSeries timeSeries74 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class73);
        timeSeries74.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener76 = null;
        timeSeries74.addPropertyChangeListener(propertyChangeListener76);
        boolean boolean78 = timeSeries74.isEmpty();
        boolean boolean79 = timeSeries74.getNotify();
        boolean boolean80 = timeSeriesDataItem66.equals((java.lang.Object) boolean79);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertNull(class29);
        org.junit.Assert.assertNull(timeSeriesDataItem41);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1546329600000L + "'", long45 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem57);
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertNotNull(timeSeries60);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + (-57600000L) + "'", long61 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem66);
        org.junit.Assert.assertTrue("'" + number67 + "' != '" + 2958465.0d + "'", number67.equals(2958465.0d));
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + true + "'", boolean79 == true);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries2.setDomainDescription("");
        java.lang.Class class7 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class12);
        timeSeries13.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        int int22 = year20.compareTo((java.lang.Object) "");
        long long23 = year20.getFirstMillisecond();
        int int24 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) year20);
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class28);
        timeSeries29.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timeSeries29.addPropertyChangeListener(propertyChangeListener31);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
        java.util.Date date36 = fixedMillisecond34.getEnd();
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date36);
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) year20, (org.jfree.data.time.RegularTimePeriod) day37);
        long long39 = day37.getFirstMillisecond();
        boolean boolean41 = day37.equals((java.lang.Object) 1577865599999L);
        long long42 = day37.getSerialIndex();
        java.lang.String str43 = day37.toString();
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1546329600000L + "'", long23 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeSeries38);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-57600000L) + "'", long39 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 25568L + "'", long42 == 25568L);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "31-December-1969" + "'", str43.equals("31-December-1969"));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        int int13 = year11.compareTo((java.lang.Object) "");
        long long14 = year11.getFirstMillisecond();
        int int15 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) year11);
        timeSeries4.setDomainDescription("org.jfree.data.general.SeriesException: ");
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener18);
        timeSeries4.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        java.lang.ClassLoader classLoader3 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class2);
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader3);
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertNotNull(classLoader3);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class4);
        timeSeries5.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries5.setDomainDescription("");
        java.lang.Class class10 = timeSeries5.getTimePeriodClass();
        timeSeries5.clear();
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class15);
        timeSeries16.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timeSeries16.addPropertyChangeListener(propertyChangeListener18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries16.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        int int25 = year23.compareTo((java.lang.Object) "");
        long long26 = year23.getFirstMillisecond();
        int int27 = timeSeries16.getIndex((org.jfree.data.time.RegularTimePeriod) year23);
        java.lang.Class class31 = null;
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class31);
        timeSeries32.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener34 = null;
        timeSeries32.addPropertyChangeListener(propertyChangeListener34);
        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries32.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond37);
        java.util.Date date39 = fixedMillisecond37.getEnd();
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date39);
        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) year23, (org.jfree.data.time.RegularTimePeriod) day40);
        org.jfree.data.time.SerialDate serialDate42 = day40.getSerialDate();
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.addMonths(29, serialDate42);
        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.addYears((int) (byte) -1, serialDate43);
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.addMonths((-459), serialDate44);
        org.jfree.data.time.SerialDate serialDate47 = serialDate44.getPreviousDayOfWeek(4);
        java.lang.String str48 = serialDate44.getDescription();
        org.junit.Assert.assertNull(class10);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1546329600000L + "'", long26 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem38);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(timeSeries41);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertNull(str48);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        int int4 = year2.compareTo((java.lang.Object) "");
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("");
        java.lang.String str7 = seriesException6.toString();
        boolean boolean8 = year2.equals((java.lang.Object) seriesException6);
        java.lang.String str9 = seriesException6.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException6);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str7.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str9.equals("org.jfree.data.general.SeriesException: "));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries2.setDomainDescription("");
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries2.addPropertyChangeListener(propertyChangeListener7);
        boolean boolean9 = timeSeries2.getNotify();
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries2.addPropertyChangeListener(propertyChangeListener10);
        java.util.List list12 = timeSeries2.getItems();
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(list12);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.removeAgedItems(false);
        boolean boolean6 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) timeSeries2, (java.lang.Object) 1900);
        try {
            timeSeries2.delete(11, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 11, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        long long3 = year2.getLastMillisecond();
        java.util.Date date4 = year2.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year2.next();
        long long6 = year2.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year2.previous();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod7, "October", "", class12);
        java.net.URL uRL14 = org.jfree.chart.util.ObjectUtilities.getResource("Fourth", class12);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        timeSeries17.setDescription("2019");
        java.lang.Class class20 = timeSeries17.getTimePeriodClass();
        java.lang.ClassLoader classLoader21 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class20);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.Class class24 = timeSeries23.getTimePeriodClass();
        java.lang.ClassLoader classLoader25 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class24);
        java.lang.Object obj26 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("January", class20, class24);
        java.lang.Object obj27 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ClassContext", class12, class24);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertNull(uRL14);
        org.junit.Assert.assertNotNull(class20);
        org.junit.Assert.assertNotNull(classLoader21);
        org.junit.Assert.assertNotNull(class24);
        org.junit.Assert.assertNotNull(classLoader25);
        org.junit.Assert.assertNull(obj26);
        org.junit.Assert.assertNull(obj27);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        java.lang.Class class1 = null;
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class5);
        java.lang.Class<?> wildcardClass7 = timeSeries6.getClass();
        java.util.Date date8 = null;
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date8, timeZone9);
        java.lang.ClassLoader classLoader11 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass7);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2, (java.lang.Class) wildcardClass7);
        java.io.InputStream inputStream13 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("org.jfree.data.time.TimePeriodFormatException: ClassContext", (java.lang.Class) wildcardClass7);
        java.lang.ClassLoader classLoader14 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass7);
        java.lang.Object obj15 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("SerialDate.weekInMonthToString(): invalid code.", class1, (java.lang.Class) wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(classLoader11);
        org.junit.Assert.assertNull(inputStream13);
        org.junit.Assert.assertNotNull(classLoader14);
        org.junit.Assert.assertNull(obj15);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class2);
        java.lang.Class<?> wildcardClass4 = timeSeries3.getClass();
        java.util.Date date5 = null;
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date5, timeZone6);
        java.lang.ClassLoader classLoader8 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2, (java.lang.Class) wildcardClass4);
        timeSeries9.removeAgedItems(false);
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-460), "October", "2019", class15);
        int int17 = timeSeries16.getItemCount();
        java.lang.Class class19 = null;
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class19);
        timeSeries20.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries20.setDomainDescription("");
        java.lang.Class class25 = timeSeries20.getTimePeriodClass();
        timeSeries20.clear();
        java.lang.Class class30 = null;
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class30);
        timeSeries31.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener33 = null;
        timeSeries31.addPropertyChangeListener(propertyChangeListener33);
        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries31.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond36);
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
        int int40 = year38.compareTo((java.lang.Object) "");
        long long41 = year38.getFirstMillisecond();
        int int42 = timeSeries31.getIndex((org.jfree.data.time.RegularTimePeriod) year38);
        java.lang.Class class46 = null;
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class46);
        timeSeries47.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener49 = null;
        timeSeries47.addPropertyChangeListener(propertyChangeListener49);
        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = timeSeries47.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond52);
        java.util.Date date54 = fixedMillisecond52.getEnd();
        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day(date54);
        org.jfree.data.time.TimeSeries timeSeries56 = timeSeries20.createCopy((org.jfree.data.time.RegularTimePeriod) year38, (org.jfree.data.time.RegularTimePeriod) day55);
        long long57 = day55.getFirstMillisecond();
        boolean boolean59 = day55.equals((java.lang.Object) 1577865599999L);
        long long60 = day55.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = day55.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = day55.previous();
        timeSeries16.setKey((java.lang.Comparable) regularTimePeriod62);
        try {
            timeSeries9.update(regularTimePeriod62, (java.lang.Number) 10.0f);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(classLoader8);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNull(class25);
        org.junit.Assert.assertNull(timeSeriesDataItem37);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1546329600000L + "'", long41 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem53);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertNotNull(timeSeries56);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + (-57600000L) + "'", long57 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 25568L + "'", long60 == 25568L);
        org.junit.Assert.assertNotNull(regularTimePeriod61);
        org.junit.Assert.assertNotNull(regularTimePeriod62);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-460), "October", "2019", class3);
        int int5 = timeSeries4.getItemCount();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        timeSeries4.clear();
        java.lang.Object obj9 = timeSeries4.clone();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class5);
        timeSeries6.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries6.setDomainDescription("");
        java.lang.Class class11 = timeSeries6.getTimePeriodClass();
        timeSeries6.clear();
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class16);
        timeSeries17.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timeSeries17.addPropertyChangeListener(propertyChangeListener19);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries17.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        int int26 = year24.compareTo((java.lang.Object) "");
        long long27 = year24.getFirstMillisecond();
        int int28 = timeSeries17.getIndex((org.jfree.data.time.RegularTimePeriod) year24);
        java.lang.Class class32 = null;
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class32);
        timeSeries33.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener35 = null;
        timeSeries33.addPropertyChangeListener(propertyChangeListener35);
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries33.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond38);
        java.util.Date date40 = fixedMillisecond38.getEnd();
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date40);
        org.jfree.data.time.TimeSeries timeSeries42 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) year24, (org.jfree.data.time.RegularTimePeriod) day41);
        org.jfree.data.time.SerialDate serialDate43 = day41.getSerialDate();
        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.addMonths(29, serialDate43);
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(3, serialDate44);
        java.lang.String str46 = serialDate45.getDescription();
        org.jfree.data.time.SerialDate serialDate47 = org.jfree.data.time.SerialDate.addMonths((int) (short) 100, serialDate45);
        java.lang.String str48 = serialDate45.getDescription();
        try {
            org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (short) 0, serialDate45);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(class11);
        org.junit.Assert.assertNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1546329600000L + "'", long27 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem39);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(timeSeries42);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertNull(str46);
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertNull(str48);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.lang.String str2 = month0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.previous();
        int int5 = month0.compareTo((java.lang.Object) 3);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "June 2019" + "'", str2.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(8, true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Aug" + "'", str2.equals("Aug"));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        int int13 = year11.compareTo((java.lang.Object) "");
        long long14 = year11.getFirstMillisecond();
        int int15 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) year11);
        java.lang.String str16 = timeSeries4.getDomainDescription();
        timeSeries4.setMaximumItemCount((int) (byte) 10);
        long long19 = timeSeries4.getMaximumItemAge();
        timeSeries4.setMaximumItemAge(1L);
        java.util.Collection collection22 = timeSeries4.getTimePeriods();
        timeSeries4.setRangeDescription("2019");
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 9223372036854775807L + "'", long19 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection22);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond9.previous();
        java.lang.Number number11 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, number11);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries4.removeChangeListener(seriesChangeListener13);
        timeSeries4.setDescription("ClassContext");
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("ThreadContext");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond9.previous();
        java.lang.Number number11 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, number11);
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class16);
        timeSeries17.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timeSeries17.addPropertyChangeListener(propertyChangeListener19);
        boolean boolean21 = timeSeries17.isEmpty();
        boolean boolean22 = timeSeries17.isEmpty();
        timeSeries17.setMaximumItemCount(0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((long) (short) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond26.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries17.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26);
        boolean boolean29 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) fixedMillisecond9, (java.lang.Object) timeSeriesDataItem28);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNull(timeSeriesDataItem28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        java.util.Date date11 = fixedMillisecond9.getEnd();
        java.util.Date date12 = fixedMillisecond9.getTime();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date16 = fixedMillisecond15.getTime();
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date16, timeZone17);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date12, timeZone17);
        java.util.Calendar calendar20 = null;
        try {
            day19.peg(calendar20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeZone17);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("October");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        java.lang.Class class0 = null;
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class4);
        timeSeries5.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries5.addPropertyChangeListener(propertyChangeListener7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries5.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
        java.util.Date date12 = fixedMillisecond10.getEnd();
        java.util.TimeZone timeZone13 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date12, timeZone13);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date12);
        int int16 = day15.getDayOfMonth();
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 31 + "'", int16 == 31);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, 100, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.lang.String str2 = month0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.previous();
        java.util.Calendar calendar4 = null;
        try {
            month0.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "June 2019" + "'", str2.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("ClassContext");
        int int5 = year0.compareTo((java.lang.Object) "ClassContext");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(100);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(9999);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-460), "October", "2019", class3);
        int int5 = timeSeries4.getItemCount();
        java.lang.String str6 = timeSeries4.getDescription();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class10);
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class15);
        timeSeries16.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timeSeries16.addPropertyChangeListener(propertyChangeListener18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries16.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21);
        java.util.Date date23 = fixedMillisecond21.getEnd();
        java.util.Date date24 = fixedMillisecond21.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, (double) 2958465);
        java.util.Calendar calendar27 = null;
        fixedMillisecond21.peg(calendar27);
        java.util.Calendar calendar29 = null;
        long long30 = fixedMillisecond21.getMiddleMillisecond(calendar29);
        try {
            timeSeries4.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, (java.lang.Number) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNull(timeSeriesDataItem26);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries2.setDomainDescription("");
        java.lang.Class class7 = timeSeries2.getTimePeriodClass();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries2.removeChangeListener(seriesChangeListener8);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries2.addChangeListener(seriesChangeListener10);
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class15);
        timeSeries16.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timeSeries16.addPropertyChangeListener(propertyChangeListener18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries16.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21);
        java.util.Date date23 = fixedMillisecond21.getEnd();
        java.util.Date date24 = fixedMillisecond21.getTime();
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month(date24);
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond(date24);
        try {
            timeSeries2.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, (double) 7, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(date24);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str5 = timeSeries2.getDescription();
        timeSeries2.setDescription("2019");
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        long long9 = year8.getLastMillisecond();
        java.util.Date date10 = year8.getStart();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
        java.lang.String str12 = month11.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month11.next();
        timeSeries2.setKey((java.lang.Comparable) month11);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = timeSeries2.getTimePeriod(29);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 29, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str5.equals("SerialDate.weekInMonthToString(): invalid code."));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "January 2019" + "'", str12.equals("January 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries2.setDomainDescription("");
        java.lang.Class class7 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class12);
        timeSeries13.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        int int22 = year20.compareTo((java.lang.Object) "");
        long long23 = year20.getFirstMillisecond();
        int int24 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) year20);
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class28);
        timeSeries29.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timeSeries29.addPropertyChangeListener(propertyChangeListener31);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
        java.util.Date date36 = fixedMillisecond34.getEnd();
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date36);
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) year20, (org.jfree.data.time.RegularTimePeriod) day37);
        org.jfree.data.time.SerialDate serialDate39 = day37.getSerialDate();
        java.util.Date date40 = day37.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day37, (java.lang.Number) 1900);
        java.lang.Class class44 = null;
        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class44);
        timeSeries45.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str48 = timeSeries45.getDescription();
        timeSeries45.setMaximumItemAge((long) 11);
        java.beans.PropertyChangeListener propertyChangeListener51 = null;
        timeSeries45.removePropertyChangeListener(propertyChangeListener51);
        boolean boolean53 = timeSeriesDataItem42.equals((java.lang.Object) propertyChangeListener51);
        int int55 = timeSeriesDataItem42.compareTo((java.lang.Object) "October");
        try {
            java.lang.Object obj56 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) "October");
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1546329600000L + "'", long23 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeSeries38);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str48.equals("SerialDate.weekInMonthToString(): invalid code."));
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str5 = timeSeries2.getDescription();
        timeSeries2.setRangeDescription("Nearest");
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str5.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        java.lang.Class class0 = null;
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class2);
        timeSeries3.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries3.setDomainDescription("");
        java.lang.Class class8 = timeSeries3.getTimePeriodClass();
        timeSeries3.clear();
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class13);
        timeSeries14.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries14.addPropertyChangeListener(propertyChangeListener16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries14.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        int int23 = year21.compareTo((java.lang.Object) "");
        long long24 = year21.getFirstMillisecond();
        int int25 = timeSeries14.getIndex((org.jfree.data.time.RegularTimePeriod) year21);
        java.lang.Class class29 = null;
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class29);
        timeSeries30.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener32 = null;
        timeSeries30.addPropertyChangeListener(propertyChangeListener32);
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries30.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
        java.util.Date date37 = fixedMillisecond35.getEnd();
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date37);
        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year21, (org.jfree.data.time.RegularTimePeriod) day38);
        long long40 = day38.getFirstMillisecond();
        boolean boolean42 = day38.equals((java.lang.Object) 1577865599999L);
        long long43 = day38.getSerialIndex();
        java.util.Date date44 = day38.getStart();
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date44);
        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(date44, timeZone46);
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year();
        long long49 = year48.getLastMillisecond();
        java.util.Date date50 = year48.getStart();
        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month(date50);
        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date53 = fixedMillisecond52.getTime();
        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year(date53, timeZone54);
        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day(date50, timeZone54);
        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year();
        long long58 = year57.getLastMillisecond();
        java.util.Date date59 = year57.getStart();
        org.jfree.data.time.Month month60 = new org.jfree.data.time.Month(date59);
        org.jfree.data.time.FixedMillisecond fixedMillisecond61 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date62 = fixedMillisecond61.getTime();
        java.util.TimeZone timeZone63 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year64 = new org.jfree.data.time.Year(date62, timeZone63);
        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day(date59, timeZone63);
        org.jfree.data.time.Year year66 = new org.jfree.data.time.Year(date50, timeZone63);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date44, timeZone63);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1546329600000L + "'", long24 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(timeSeries39);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-57600000L) + "'", long40 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 25568L + "'", long43 == 25568L);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(timeZone46);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1577865599999L + "'", long49 == 1577865599999L);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertNotNull(timeZone54);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1577865599999L + "'", long58 == 1577865599999L);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertNotNull(date62);
        org.junit.Assert.assertNotNull(timeZone63);
        org.junit.Assert.assertNull(regularTimePeriod67);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        java.lang.Object obj4 = null;
        int int5 = month3.compareTo(obj4);
        long long6 = month3.getLastMillisecond();
        int int7 = month3.getYearValue();
        java.lang.Class class9 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class9);
        timeSeries10.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str13 = timeSeries10.getDescription();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        long long15 = year14.getLastMillisecond();
        long long16 = year14.getSerialIndex();
        int int17 = timeSeries10.getIndex((org.jfree.data.time.RegularTimePeriod) year14);
        java.lang.Class class25 = null;
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class25);
        java.lang.Class<?> wildcardClass27 = timeSeries26.getClass();
        java.util.Date date28 = null;
        java.util.TimeZone timeZone29 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass27, date28, timeZone29);
        java.lang.ClassLoader classLoader31 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass27);
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2, (java.lang.Class) wildcardClass27);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, "ThreadContext", "org.jfree.data.general.SeriesException: ", (java.lang.Class) wildcardClass27);
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year14, "Following", "Fourth", (java.lang.Class) wildcardClass27);
        java.lang.Class class38 = null;
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class38);
        timeSeries39.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener41 = null;
        timeSeries39.addPropertyChangeListener(propertyChangeListener41);
        boolean boolean43 = timeSeries39.isEmpty();
        boolean boolean44 = timeSeries39.isEmpty();
        java.util.Collection collection45 = timeSeries34.getTimePeriodsUniqueToOtherSeries(timeSeries39);
        java.lang.Class class49 = null;
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class49);
        timeSeries50.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener52 = null;
        timeSeries50.addPropertyChangeListener(propertyChangeListener52);
        boolean boolean54 = timeSeries50.isEmpty();
        boolean boolean55 = timeSeries50.getNotify();
        java.util.Collection collection56 = timeSeries34.getTimePeriodsUniqueToOtherSeries(timeSeries50);
        int int57 = month3.compareTo((java.lang.Object) timeSeries50);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1549007999999L + "'", long6 == 1549007999999L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str13.equals("SerialDate.weekInMonthToString(): invalid code."));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(classLoader31);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(collection45);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(collection56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        int int13 = year11.compareTo((java.lang.Object) "");
        long long14 = year11.getFirstMillisecond();
        int int15 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) year11);
        java.lang.String str16 = timeSeries4.getDomainDescription();
        timeSeries4.setMaximumItemCount((int) (byte) 10);
        timeSeries4.setDomainDescription("31-December-1969");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener21 = null;
        timeSeries4.addChangeListener(seriesChangeListener21);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class8);
        timeSeries9.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries9.addPropertyChangeListener(propertyChangeListener11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
        java.util.Date date16 = fixedMillisecond14.getEnd();
        java.util.Date date17 = fixedMillisecond14.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (double) 2958465);
        java.lang.Class class23 = null;
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class23);
        timeSeries24.fireSeriesChanged();
        java.util.Collection collection26 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries24);
        java.lang.Class class30 = null;
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class30);
        java.lang.Class class35 = null;
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class35);
        timeSeries36.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener38 = null;
        timeSeries36.addPropertyChangeListener(propertyChangeListener38);
        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries36.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond41);
        java.util.Date date43 = fixedMillisecond41.getEnd();
        java.util.Date date44 = fixedMillisecond41.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = timeSeries31.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond41, (double) 2958465);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener47 = null;
        timeSeries31.removeChangeListener(seriesChangeListener47);
        java.lang.Class class50 = null;
        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class50);
        timeSeries51.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries51.setDomainDescription("");
        java.lang.Class class56 = timeSeries51.getTimePeriodClass();
        timeSeries51.clear();
        java.lang.Class class61 = null;
        org.jfree.data.time.TimeSeries timeSeries62 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class61);
        timeSeries62.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener64 = null;
        timeSeries62.addPropertyChangeListener(propertyChangeListener64);
        org.jfree.data.time.FixedMillisecond fixedMillisecond67 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem68 = timeSeries62.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond67);
        org.jfree.data.time.Year year69 = new org.jfree.data.time.Year();
        int int71 = year69.compareTo((java.lang.Object) "");
        long long72 = year69.getFirstMillisecond();
        int int73 = timeSeries62.getIndex((org.jfree.data.time.RegularTimePeriod) year69);
        java.lang.Class class77 = null;
        org.jfree.data.time.TimeSeries timeSeries78 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class77);
        timeSeries78.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener80 = null;
        timeSeries78.addPropertyChangeListener(propertyChangeListener80);
        org.jfree.data.time.FixedMillisecond fixedMillisecond83 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem84 = timeSeries78.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond83);
        java.util.Date date85 = fixedMillisecond83.getEnd();
        org.jfree.data.time.Day day86 = new org.jfree.data.time.Day(date85);
        org.jfree.data.time.TimeSeries timeSeries87 = timeSeries51.createCopy((org.jfree.data.time.RegularTimePeriod) year69, (org.jfree.data.time.RegularTimePeriod) day86);
        long long88 = day86.getFirstMillisecond();
        boolean boolean90 = day86.equals((java.lang.Object) 1577865599999L);
        timeSeries31.setKey((java.lang.Comparable) boolean90);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem93 = timeSeries31.getDataItem(0);
        try {
            timeSeries4.add(timeSeriesDataItem93);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(collection26);
        org.junit.Assert.assertNull(timeSeriesDataItem42);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNull(timeSeriesDataItem46);
        org.junit.Assert.assertNull(class56);
        org.junit.Assert.assertNull(timeSeriesDataItem68);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 1 + "'", int71 == 1);
        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 1546329600000L + "'", long72 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + (-1) + "'", int73 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem84);
        org.junit.Assert.assertNotNull(date85);
        org.junit.Assert.assertNotNull(timeSeries87);
        org.junit.Assert.assertTrue("'" + long88 + "' != '" + (-57600000L) + "'", long88 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem93);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("Aug");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("Time");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(31, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries2.setDomainDescription("");
        java.lang.Class class7 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class12);
        timeSeries13.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        int int22 = year20.compareTo((java.lang.Object) "");
        long long23 = year20.getFirstMillisecond();
        int int24 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) year20);
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class28);
        timeSeries29.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timeSeries29.addPropertyChangeListener(propertyChangeListener31);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
        java.util.Date date36 = fixedMillisecond34.getEnd();
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date36);
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) year20, (org.jfree.data.time.RegularTimePeriod) day37);
        org.jfree.data.time.SerialDate serialDate39 = day37.getSerialDate();
        java.util.Date date40 = day37.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day37, (java.lang.Number) 1900);
        java.lang.Class class44 = null;
        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class44);
        timeSeries45.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str48 = timeSeries45.getDescription();
        timeSeries45.setMaximumItemAge((long) 11);
        java.beans.PropertyChangeListener propertyChangeListener51 = null;
        timeSeries45.removePropertyChangeListener(propertyChangeListener51);
        boolean boolean53 = timeSeriesDataItem42.equals((java.lang.Object) propertyChangeListener51);
        java.lang.Class class57 = null;
        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class57);
        timeSeries58.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener60 = null;
        timeSeries58.addPropertyChangeListener(propertyChangeListener60);
        org.jfree.data.time.FixedMillisecond fixedMillisecond63 = new org.jfree.data.time.FixedMillisecond((long) (short) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = fixedMillisecond63.previous();
        java.lang.Number number65 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem66 = timeSeries58.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond63, number65);
        java.util.List list67 = timeSeries58.getItems();
        int int68 = timeSeriesDataItem42.compareTo((java.lang.Object) timeSeries58);
        java.lang.Object obj69 = timeSeriesDataItem42.clone();
        java.lang.Object obj70 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) timeSeriesDataItem42);
        java.lang.Class class72 = null;
        org.jfree.data.time.TimeSeries timeSeries73 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class72);
        timeSeries73.setNotify(true);
        int int76 = timeSeriesDataItem42.compareTo((java.lang.Object) timeSeries73);
        java.lang.Number number77 = timeSeriesDataItem42.getValue();
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1546329600000L + "'", long23 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeSeries38);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str48.equals("SerialDate.weekInMonthToString(): invalid code."));
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod64);
        org.junit.Assert.assertNull(timeSeriesDataItem66);
        org.junit.Assert.assertNotNull(list67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 1 + "'", int68 == 1);
        org.junit.Assert.assertNotNull(obj69);
        org.junit.Assert.assertNotNull(obj70);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 1 + "'", int76 == 1);
        org.junit.Assert.assertTrue("'" + number77 + "' != '" + 1900 + "'", number77.equals(1900));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
        java.net.URL uRL4 = org.jfree.chart.util.ObjectUtilities.getResource("Following", class3);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class8);
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class13);
        timeSeries14.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries14.addPropertyChangeListener(propertyChangeListener16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries14.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
        java.util.Date date21 = fixedMillisecond19.getEnd();
        java.util.Date date22 = fixedMillisecond19.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (double) 2958465);
        java.util.Calendar calendar25 = null;
        fixedMillisecond19.peg(calendar25);
        java.util.Date date27 = fixedMillisecond19.getTime();
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.createInstance(date27);
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date30 = fixedMillisecond29.getTime();
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date30, timeZone31);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance(class3, date27, timeZone31);
        java.lang.Class class34 = org.jfree.data.time.RegularTimePeriod.downsize(class3);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertNull(uRL4);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(class34);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class2);
        java.lang.Class<?> wildcardClass4 = timeSeries3.getClass();
        java.util.Date date5 = null;
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date5, timeZone6);
        java.lang.ClassLoader classLoader8 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2, (java.lang.Class) wildcardClass4);
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class13);
        timeSeries14.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries14.addPropertyChangeListener(propertyChangeListener16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries14.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
        java.util.Date date21 = fixedMillisecond19.getEnd();
        java.util.Date date22 = fixedMillisecond19.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (java.lang.Number) 2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = fixedMillisecond19.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod25, (double) 11);
        java.lang.Object obj28 = timeSeriesDataItem27.clone();
        java.lang.Object obj29 = timeSeriesDataItem27.clone();
        java.lang.Number number30 = timeSeriesDataItem27.getValue();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(classLoader8);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertNotNull(obj29);
        org.junit.Assert.assertTrue("'" + number30 + "' != '" + 11.0d + "'", number30.equals(11.0d));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries2.setDomainDescription("");
        java.lang.Class class7 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class12);
        timeSeries13.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        int int22 = year20.compareTo((java.lang.Object) "");
        long long23 = year20.getFirstMillisecond();
        int int24 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) year20);
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class28);
        timeSeries29.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timeSeries29.addPropertyChangeListener(propertyChangeListener31);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
        java.util.Date date36 = fixedMillisecond34.getEnd();
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date36);
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) year20, (org.jfree.data.time.RegularTimePeriod) day37);
        java.lang.Class class41 = null;
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class41);
        java.lang.Class<?> wildcardClass43 = timeSeries42.getClass();
        java.util.Date date44 = null;
        java.util.TimeZone timeZone45 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass43, date44, timeZone45);
        java.lang.ClassLoader classLoader47 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass43);
        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2, (java.lang.Class) wildcardClass43);
        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day37, (java.lang.Class) wildcardClass43);
        java.lang.Class class50 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass43);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1546329600000L + "'", long23 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeSeries38);
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertNull(regularTimePeriod46);
        org.junit.Assert.assertNotNull(classLoader47);
        org.junit.Assert.assertNotNull(class50);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        java.lang.String str4 = month3.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year6.previous();
        int int9 = month3.compareTo((java.lang.Object) year6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month3.previous();
        java.util.Calendar calendar11 = null;
        try {
            long long12 = month3.getMiddleMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "January 2019" + "'", str4.equals("January 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class8);
        timeSeries9.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries9.addPropertyChangeListener(propertyChangeListener11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
        java.util.Date date16 = fixedMillisecond14.getEnd();
        java.util.Date date17 = fixedMillisecond14.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (double) 2958465);
        java.util.Calendar calendar20 = null;
        fixedMillisecond14.peg(calendar20);
        java.util.Date date22 = fixedMillisecond14.getTime();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
        int int24 = day23.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day23.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = day23.previous();
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class28);
        timeSeries29.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str32 = timeSeries29.getDescription();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        long long34 = year33.getLastMillisecond();
        long long35 = year33.getSerialIndex();
        int int36 = timeSeries29.getIndex((org.jfree.data.time.RegularTimePeriod) year33);
        java.lang.Class class44 = null;
        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class44);
        java.lang.Class<?> wildcardClass46 = timeSeries45.getClass();
        java.util.Date date47 = null;
        java.util.TimeZone timeZone48 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass46, date47, timeZone48);
        java.lang.ClassLoader classLoader50 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass46);
        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2, (java.lang.Class) wildcardClass46);
        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, "ThreadContext", "org.jfree.data.general.SeriesException: ", (java.lang.Class) wildcardClass46);
        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year33, "Following", "Fourth", (java.lang.Class) wildcardClass46);
        java.lang.Class class57 = null;
        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class57);
        timeSeries58.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener60 = null;
        timeSeries58.addPropertyChangeListener(propertyChangeListener60);
        boolean boolean62 = timeSeries58.isEmpty();
        boolean boolean63 = timeSeries58.isEmpty();
        java.util.Collection collection64 = timeSeries53.getTimePeriodsUniqueToOtherSeries(timeSeries58);
        java.lang.Class class66 = null;
        org.jfree.data.time.TimeSeries timeSeries67 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class66);
        java.lang.String str68 = timeSeries67.getRangeDescription();
        timeSeries67.setNotify(true);
        java.util.Collection collection71 = timeSeries53.getTimePeriodsUniqueToOtherSeries(timeSeries67);
        boolean boolean72 = day23.equals((java.lang.Object) timeSeries53);
        try {
            java.lang.Number number74 = timeSeries53.getValue(1969);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1969, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 12 + "'", int24 == 12);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str32.equals("SerialDate.weekInMonthToString(): invalid code."));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1577865599999L + "'", long34 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 2019L + "'", long35 == 2019L);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass46);
        org.junit.Assert.assertNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(classLoader50);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNotNull(collection64);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "Value" + "'", str68.equals("Value"));
        org.junit.Assert.assertNotNull(collection71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) "");
        long long3 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        java.lang.String str5 = year0.toString();
        long long6 = year0.getMiddleMillisecond();
        long long7 = year0.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1562097599999L + "'", long6 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((-458));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -458");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 9);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class8);
        timeSeries9.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries9.addPropertyChangeListener(propertyChangeListener11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
        java.util.Date date16 = fixedMillisecond14.getEnd();
        java.util.Date date17 = fixedMillisecond14.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (double) 2958465);
        java.util.Calendar calendar20 = null;
        fixedMillisecond14.peg(calendar20);
        org.jfree.data.time.Year year23 = org.jfree.data.time.Year.parseYear("2018");
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date25 = fixedMillisecond24.getTime();
        boolean boolean26 = year23.equals((java.lang.Object) fixedMillisecond24);
        int int27 = fixedMillisecond14.compareTo((java.lang.Object) fixedMillisecond24);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (double) (byte) 0);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(year23);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class2);
        java.lang.Class<?> wildcardClass4 = timeSeries3.getClass();
        java.util.Date date5 = null;
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date5, timeZone6);
        java.lang.ClassLoader classLoader8 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2, (java.lang.Class) wildcardClass4);
        timeSeries9.removeAgedItems(false);
        java.lang.String str12 = timeSeries9.getDomainDescription();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = null;
        try {
            timeSeries9.add(regularTimePeriod13, (double) (byte) 1, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(classLoader8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Time" + "'", str12.equals("Time"));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((-452));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries2.setDomainDescription("");
        java.lang.Class class7 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class12);
        timeSeries13.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        int int22 = year20.compareTo((java.lang.Object) "");
        long long23 = year20.getFirstMillisecond();
        int int24 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) year20);
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class28);
        timeSeries29.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timeSeries29.addPropertyChangeListener(propertyChangeListener31);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
        java.util.Date date36 = fixedMillisecond34.getEnd();
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date36);
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) year20, (org.jfree.data.time.RegularTimePeriod) day37);
        long long39 = day37.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = day37.previous();
        long long41 = day37.getSerialIndex();
        long long42 = day37.getLastMillisecond();
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1546329600000L + "'", long23 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeSeries38);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-57600000L) + "'", long39 == (-57600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 25568L + "'", long41 == 25568L);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 28799999L + "'", long42 == 28799999L);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 1);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        long long3 = year2.getLastMillisecond();
        java.util.Date date4 = year2.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year2.next();
        java.util.Date date6 = year2.getStart();
        int int7 = fixedMillisecond1.compareTo((java.lang.Object) year2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class2);
        java.lang.Class<?> wildcardClass4 = timeSeries3.getClass();
        java.util.Date date5 = null;
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date5, timeZone6);
        java.lang.ClassLoader classLoader8 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2, (java.lang.Class) wildcardClass4);
        timeSeries9.removeAgedItems(false);
        timeSeries9.setNotify(false);
        timeSeries9.clear();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(classLoader8);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((-451));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        java.util.Date date11 = fixedMillisecond9.getEnd();
        java.util.Calendar calendar12 = null;
        long long13 = fixedMillisecond9.getFirstMillisecond(calendar12);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        int int13 = year11.compareTo((java.lang.Object) "");
        long long14 = year11.getFirstMillisecond();
        int int15 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) year11);
        java.lang.String str16 = timeSeries4.getDomainDescription();
        timeSeries4.setMaximumItemCount((int) (byte) 10);
        long long19 = timeSeries4.getMaximumItemAge();
        java.lang.Class class23 = null;
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class23);
        timeSeries24.clear();
        java.lang.Class class29 = null;
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class29);
        timeSeries30.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener32 = null;
        timeSeries30.addPropertyChangeListener(propertyChangeListener32);
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries30.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
        java.util.Date date37 = fixedMillisecond35.getEnd();
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
        long long39 = year38.getLastMillisecond();
        boolean boolean40 = fixedMillisecond35.equals((java.lang.Object) year38);
        int int42 = fixedMillisecond35.compareTo((java.lang.Object) 1577865599999L);
        java.lang.Number number43 = timeSeries24.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35, 10.0d);
        java.lang.Class class49 = null;
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class49);
        timeSeries50.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener52 = null;
        timeSeries50.addPropertyChangeListener(propertyChangeListener52);
        timeSeries50.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
        int int56 = fixedMillisecond35.compareTo((java.lang.Object) "SerialDate.weekInMonthToString(): invalid code.");
        long long57 = fixedMillisecond35.getFirstMillisecond();
        long long58 = fixedMillisecond35.getSerialIndex();
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 9223372036854775807L + "'", long19 == 9223372036854775807L);
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1577865599999L + "'", long39 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertNull(number43);
        org.junit.Assert.assertNull(timeSeriesDataItem45);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 0L + "'", long57 == 0L);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 0L + "'", long58 == 0L);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class2);
        java.lang.Class<?> wildcardClass4 = timeSeries3.getClass();
        java.util.Date date5 = null;
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date5, timeZone6);
        java.lang.ClassLoader classLoader8 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2, (java.lang.Class) wildcardClass4);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class12);
        java.lang.Class<?> wildcardClass14 = timeSeries13.getClass();
        java.util.Date date15 = null;
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass14, date15, timeZone16);
        java.lang.ClassLoader classLoader18 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass14);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2, (java.lang.Class) wildcardClass14);
        java.lang.Class class23 = null;
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class23);
        timeSeries24.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener26 = null;
        timeSeries24.addPropertyChangeListener(propertyChangeListener26);
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries24.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
        java.util.Date date31 = fixedMillisecond29.getEnd();
        java.util.Date date32 = fixedMillisecond29.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries19.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29, (java.lang.Number) 2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = fixedMillisecond29.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod35, (double) 11);
        java.lang.Object obj38 = timeSeriesDataItem37.clone();
        try {
            timeSeries9.add(timeSeriesDataItem37, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.TimeSeries.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(classLoader8);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(classLoader18);
        org.junit.Assert.assertNull(timeSeriesDataItem30);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNull(timeSeriesDataItem34);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(obj38);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str5 = timeSeries2.getDescription();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getLastMillisecond();
        long long8 = year6.getSerialIndex();
        int int9 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) year6);
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class17);
        java.lang.Class<?> wildcardClass19 = timeSeries18.getClass();
        java.util.Date date20 = null;
        java.util.TimeZone timeZone21 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date20, timeZone21);
        java.lang.ClassLoader classLoader23 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass19);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2, (java.lang.Class) wildcardClass19);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, "ThreadContext", "org.jfree.data.general.SeriesException: ", (java.lang.Class) wildcardClass19);
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year6, "Following", "Fourth", (java.lang.Class) wildcardClass19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year6.next();
        java.lang.Class class29 = null;
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class29);
        timeSeries30.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries30.setDomainDescription("");
        java.lang.Class class35 = timeSeries30.getTimePeriodClass();
        timeSeries30.clear();
        java.lang.Class class40 = null;
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class40);
        timeSeries41.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener43 = null;
        timeSeries41.addPropertyChangeListener(propertyChangeListener43);
        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = timeSeries41.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond46);
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year();
        int int50 = year48.compareTo((java.lang.Object) "");
        long long51 = year48.getFirstMillisecond();
        int int52 = timeSeries41.getIndex((org.jfree.data.time.RegularTimePeriod) year48);
        java.lang.Class class56 = null;
        org.jfree.data.time.TimeSeries timeSeries57 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class56);
        timeSeries57.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener59 = null;
        timeSeries57.addPropertyChangeListener(propertyChangeListener59);
        org.jfree.data.time.FixedMillisecond fixedMillisecond62 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem63 = timeSeries57.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond62);
        java.util.Date date64 = fixedMillisecond62.getEnd();
        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day(date64);
        org.jfree.data.time.TimeSeries timeSeries66 = timeSeries30.createCopy((org.jfree.data.time.RegularTimePeriod) year48, (org.jfree.data.time.RegularTimePeriod) day65);
        java.lang.String str67 = day65.toString();
        int int68 = year6.compareTo((java.lang.Object) str67);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str5.equals("SerialDate.weekInMonthToString(): invalid code."));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(classLoader23);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNull(class35);
        org.junit.Assert.assertNull(timeSeriesDataItem47);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1546329600000L + "'", long51 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem63);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertNotNull(timeSeries66);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "31-December-1969" + "'", str67.equals("31-December-1969"));
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 1 + "'", int68 == 1);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(1900);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        long long11 = fixedMillisecond9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = fixedMillisecond9.next();
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("org.jfree.data.general.SeriesException: ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class4);
        timeSeries5.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries5.setDomainDescription("");
        java.lang.Class class10 = timeSeries5.getTimePeriodClass();
        timeSeries5.clear();
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class15);
        timeSeries16.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timeSeries16.addPropertyChangeListener(propertyChangeListener18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries16.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        int int25 = year23.compareTo((java.lang.Object) "");
        long long26 = year23.getFirstMillisecond();
        int int27 = timeSeries16.getIndex((org.jfree.data.time.RegularTimePeriod) year23);
        java.lang.Class class31 = null;
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class31);
        timeSeries32.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener34 = null;
        timeSeries32.addPropertyChangeListener(propertyChangeListener34);
        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries32.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond37);
        java.util.Date date39 = fixedMillisecond37.getEnd();
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date39);
        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) year23, (org.jfree.data.time.RegularTimePeriod) day40);
        org.jfree.data.time.SerialDate serialDate42 = day40.getSerialDate();
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.addMonths(29, serialDate42);
        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.addYears(2019, serialDate43);
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.addDays(9, serialDate44);
        serialDate45.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        org.junit.Assert.assertNull(class10);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1546329600000L + "'", long26 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem38);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(timeSeries41);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(serialDate45);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) 'a', (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 97");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(29, (int) (byte) -1, 29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class4);
        timeSeries5.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries5.addPropertyChangeListener(propertyChangeListener7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries5.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        int int14 = year12.compareTo((java.lang.Object) "");
        long long15 = year12.getFirstMillisecond();
        int int16 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) year12);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(3, year12);
        java.util.Calendar calendar18 = null;
        try {
            long long19 = year12.getLastMillisecond(calendar18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1546329600000L + "'", long15 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        java.lang.String str4 = month3.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year6.previous();
        int int9 = month3.compareTo((java.lang.Object) year6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month3.previous();
        java.util.Date date11 = month3.getEnd();
        java.util.Date date12 = month3.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month3.previous();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "January 2019" + "'", str4.equals("January 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int3 = year1.compareTo((java.lang.Object) "");
        long long4 = year1.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year1.next();
        java.lang.String str6 = year1.toString();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(9, year1);
        java.lang.String str8 = month7.toString();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "September 2019" + "'", str8.equals("September 2019"));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries2.setDomainDescription("");
        java.lang.Class class7 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class12);
        timeSeries13.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        int int22 = year20.compareTo((java.lang.Object) "");
        long long23 = year20.getFirstMillisecond();
        int int24 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) year20);
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class28);
        timeSeries29.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timeSeries29.addPropertyChangeListener(propertyChangeListener31);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
        java.util.Date date36 = fixedMillisecond34.getEnd();
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date36);
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) year20, (org.jfree.data.time.RegularTimePeriod) day37);
        long long39 = day37.getFirstMillisecond();
        boolean boolean41 = day37.equals((java.lang.Object) 1577865599999L);
        long long42 = day37.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = day37.next();
        long long44 = day37.getSerialIndex();
        java.util.Calendar calendar45 = null;
        try {
            long long46 = day37.getFirstMillisecond(calendar45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1546329600000L + "'", long23 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeSeries38);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-57600000L) + "'", long39 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 25568L + "'", long42 == 25568L);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 25568L + "'", long44 == 25568L);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries2.setDomainDescription("");
        java.lang.Class class7 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class12);
        timeSeries13.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        int int22 = year20.compareTo((java.lang.Object) "");
        long long23 = year20.getFirstMillisecond();
        int int24 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) year20);
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class28);
        timeSeries29.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timeSeries29.addPropertyChangeListener(propertyChangeListener31);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
        java.util.Date date36 = fixedMillisecond34.getEnd();
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date36);
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) year20, (org.jfree.data.time.RegularTimePeriod) day37);
        java.lang.Class class41 = null;
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class41);
        java.lang.Class<?> wildcardClass43 = timeSeries42.getClass();
        java.util.Date date44 = null;
        java.util.TimeZone timeZone45 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass43, date44, timeZone45);
        java.lang.ClassLoader classLoader47 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass43);
        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2, (java.lang.Class) wildcardClass43);
        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day37, (java.lang.Class) wildcardClass43);
        int int50 = day37.getDayOfMonth();
        long long51 = day37.getLastMillisecond();
        int int52 = day37.getDayOfMonth();
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1546329600000L + "'", long23 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeSeries38);
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertNull(regularTimePeriod46);
        org.junit.Assert.assertNotNull(classLoader47);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 31 + "'", int50 == 31);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 28799999L + "'", long51 == 28799999L);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 31 + "'", int52 == 31);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries2.setDomainDescription("");
        java.lang.Class class7 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class12);
        timeSeries13.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        int int22 = year20.compareTo((java.lang.Object) "");
        long long23 = year20.getFirstMillisecond();
        int int24 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) year20);
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class28);
        timeSeries29.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timeSeries29.addPropertyChangeListener(propertyChangeListener31);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
        java.util.Date date36 = fixedMillisecond34.getEnd();
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date36);
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) year20, (org.jfree.data.time.RegularTimePeriod) day37);
        org.jfree.data.time.SerialDate serialDate39 = day37.getSerialDate();
        java.util.Date date40 = day37.getStart();
        long long41 = day37.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = day37.next();
        long long43 = day37.getFirstMillisecond();
        java.util.Calendar calendar44 = null;
        try {
            long long45 = day37.getMiddleMillisecond(calendar44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1546329600000L + "'", long23 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeSeries38);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-57600000L) + "'", long41 == (-57600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + (-57600000L) + "'", long43 == (-57600000L));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries2.setDomainDescription("");
        java.lang.Class class7 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class12);
        timeSeries13.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        int int22 = year20.compareTo((java.lang.Object) "");
        long long23 = year20.getFirstMillisecond();
        int int24 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) year20);
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class28);
        timeSeries29.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timeSeries29.addPropertyChangeListener(propertyChangeListener31);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
        java.util.Date date36 = fixedMillisecond34.getEnd();
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date36);
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) year20, (org.jfree.data.time.RegularTimePeriod) day37);
        java.lang.Class class41 = null;
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class41);
        java.lang.Class<?> wildcardClass43 = timeSeries42.getClass();
        java.util.Date date44 = null;
        java.util.TimeZone timeZone45 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass43, date44, timeZone45);
        java.lang.ClassLoader classLoader47 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass43);
        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2, (java.lang.Class) wildcardClass43);
        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day37, (java.lang.Class) wildcardClass43);
        java.lang.Class class51 = null;
        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class51);
        timeSeries52.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str55 = timeSeries52.getDescription();
        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year();
        long long57 = year56.getLastMillisecond();
        long long58 = year56.getSerialIndex();
        int int59 = timeSeries52.getIndex((org.jfree.data.time.RegularTimePeriod) year56);
        java.lang.Class class67 = null;
        org.jfree.data.time.TimeSeries timeSeries68 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class67);
        java.lang.Class<?> wildcardClass69 = timeSeries68.getClass();
        java.util.Date date70 = null;
        java.util.TimeZone timeZone71 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass69, date70, timeZone71);
        java.lang.ClassLoader classLoader73 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass69);
        org.jfree.data.time.TimeSeries timeSeries74 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2, (java.lang.Class) wildcardClass69);
        org.jfree.data.time.TimeSeries timeSeries75 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, "ThreadContext", "org.jfree.data.general.SeriesException: ", (java.lang.Class) wildcardClass69);
        org.jfree.data.time.TimeSeries timeSeries76 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year56, "Following", "Fourth", (java.lang.Class) wildcardClass69);
        int int77 = day37.compareTo((java.lang.Object) "Following");
        java.util.Calendar calendar78 = null;
        try {
            long long79 = day37.getLastMillisecond(calendar78);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1546329600000L + "'", long23 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeSeries38);
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertNull(regularTimePeriod46);
        org.junit.Assert.assertNotNull(classLoader47);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str55.equals("SerialDate.weekInMonthToString(): invalid code."));
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 1577865599999L + "'", long57 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 2019L + "'", long58 == 2019L);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-1) + "'", int59 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass69);
        org.junit.Assert.assertNull(regularTimePeriod72);
        org.junit.Assert.assertNotNull(classLoader73);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 1 + "'", int77 == 1);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        boolean boolean8 = timeSeries4.isEmpty();
        boolean boolean9 = timeSeries4.isEmpty();
        timeSeries4.setMaximumItemCount(0);
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-460), "October", "2019", class15);
        boolean boolean17 = timeSeries16.getNotify();
        java.util.Collection collection18 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries16);
        java.lang.Class class19 = timeSeries4.getTimePeriodClass();
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(collection18);
        org.junit.Assert.assertNull(class19);
    }
}

