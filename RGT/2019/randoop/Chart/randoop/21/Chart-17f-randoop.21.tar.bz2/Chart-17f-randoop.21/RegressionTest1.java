import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        try {
            timeSeries4.removeAgedItems((long) (-451), false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem10);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Nearest" + "'", str1.equals("Nearest"));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        java.lang.Comparable comparable0 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries(comparable0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class5);
        timeSeries6.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries6.setDomainDescription("");
        java.lang.Class class11 = timeSeries6.getTimePeriodClass();
        timeSeries6.clear();
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class16);
        timeSeries17.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timeSeries17.addPropertyChangeListener(propertyChangeListener19);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries17.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        int int26 = year24.compareTo((java.lang.Object) "");
        long long27 = year24.getFirstMillisecond();
        int int28 = timeSeries17.getIndex((org.jfree.data.time.RegularTimePeriod) year24);
        java.lang.Class class32 = null;
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class32);
        timeSeries33.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener35 = null;
        timeSeries33.addPropertyChangeListener(propertyChangeListener35);
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries33.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond38);
        java.util.Date date40 = fixedMillisecond38.getEnd();
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date40);
        org.jfree.data.time.TimeSeries timeSeries42 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) year24, (org.jfree.data.time.RegularTimePeriod) day41);
        org.jfree.data.time.SerialDate serialDate43 = day41.getSerialDate();
        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.addMonths(29, serialDate43);
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.addYears((int) (byte) -1, serialDate44);
        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.addMonths((-459), serialDate45);
        org.jfree.data.time.SerialDate serialDate48 = serialDate45.getPreviousDayOfWeek(4);
        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.addDays(1900, serialDate45);
        try {
            org.jfree.data.time.SerialDate serialDate51 = serialDate45.getNearestDayOfWeek(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(class11);
        org.junit.Assert.assertNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1546329600000L + "'", long27 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem39);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(timeSeries42);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertNotNull(serialDate49);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        java.lang.Class class0 = null;
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class4);
        timeSeries5.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries5.addPropertyChangeListener(propertyChangeListener7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries5.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
        java.util.Date date12 = fixedMillisecond10.getEnd();
        java.util.TimeZone timeZone13 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date12, timeZone13);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(date12);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year16.previous();
        long long18 = year16.getFirstMillisecond();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        long long20 = year19.getLastMillisecond();
        java.util.Date date21 = year19.getStart();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(date21);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date24 = fixedMillisecond23.getTime();
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(date24, timeZone25);
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date21, timeZone25);
        boolean boolean28 = year16.equals((java.lang.Object) day27);
        java.util.Calendar calendar29 = null;
        try {
            long long30 = day27.getLastMillisecond(calendar29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-31507200000L) + "'", long18 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1577865599999L + "'", long20 == 1577865599999L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(0, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries2.setDomainDescription("");
        java.lang.String str7 = timeSeries2.getDomainDescription();
        boolean boolean8 = timeSeries2.isEmpty();
        timeSeries2.setMaximumItemCount((int) ' ');
        java.lang.String str11 = timeSeries2.getDescription();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str11.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-460), "October", "2019", class3);
        int int5 = timeSeries4.getItemCount();
        java.lang.Class class7 = null;
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class7);
        timeSeries8.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries8.setDomainDescription("");
        java.lang.Class class13 = timeSeries8.getTimePeriodClass();
        timeSeries8.clear();
        java.lang.Class class18 = null;
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class18);
        timeSeries19.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timeSeries19.addPropertyChangeListener(propertyChangeListener21);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries19.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        int int28 = year26.compareTo((java.lang.Object) "");
        long long29 = year26.getFirstMillisecond();
        int int30 = timeSeries19.getIndex((org.jfree.data.time.RegularTimePeriod) year26);
        java.lang.Class class34 = null;
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class34);
        timeSeries35.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener37 = null;
        timeSeries35.addPropertyChangeListener(propertyChangeListener37);
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries35.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40);
        java.util.Date date42 = fixedMillisecond40.getEnd();
        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(date42);
        org.jfree.data.time.TimeSeries timeSeries44 = timeSeries8.createCopy((org.jfree.data.time.RegularTimePeriod) year26, (org.jfree.data.time.RegularTimePeriod) day43);
        long long45 = day43.getFirstMillisecond();
        boolean boolean47 = day43.equals((java.lang.Object) 1577865599999L);
        long long48 = day43.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = day43.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = day43.previous();
        timeSeries4.setKey((java.lang.Comparable) regularTimePeriod50);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener52 = null;
        timeSeries4.addChangeListener(seriesChangeListener52);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(class13);
        org.junit.Assert.assertNull(timeSeriesDataItem25);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1546329600000L + "'", long29 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem41);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(timeSeries44);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-57600000L) + "'", long45 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 25568L + "'", long48 == 25568L);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        java.lang.String str4 = month3.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year6.previous();
        int int9 = month3.compareTo((java.lang.Object) year6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month3.previous();
        java.util.Date date11 = month3.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond(date11);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "January 2019" + "'", str4.equals("January 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(date11);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) (byte) 1, 31);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setNotify(true);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class8);
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class13);
        timeSeries14.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries14.addPropertyChangeListener(propertyChangeListener16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries14.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
        java.util.Date date21 = fixedMillisecond19.getEnd();
        java.util.Date date22 = fixedMillisecond19.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (double) 2958465);
        java.util.Calendar calendar25 = null;
        fixedMillisecond19.peg(calendar25);
        java.util.Date date27 = fixedMillisecond19.getTime();
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date27);
        int int29 = day28.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = day28.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = day28.previous();
        java.lang.Class class33 = null;
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class33);
        timeSeries34.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str37 = timeSeries34.getDescription();
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
        long long39 = year38.getLastMillisecond();
        long long40 = year38.getSerialIndex();
        int int41 = timeSeries34.getIndex((org.jfree.data.time.RegularTimePeriod) year38);
        java.lang.Class class49 = null;
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class49);
        java.lang.Class<?> wildcardClass51 = timeSeries50.getClass();
        java.util.Date date52 = null;
        java.util.TimeZone timeZone53 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass51, date52, timeZone53);
        java.lang.ClassLoader classLoader55 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass51);
        org.jfree.data.time.TimeSeries timeSeries56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2, (java.lang.Class) wildcardClass51);
        org.jfree.data.time.TimeSeries timeSeries57 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, "ThreadContext", "org.jfree.data.general.SeriesException: ", (java.lang.Class) wildcardClass51);
        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year38, "Following", "Fourth", (java.lang.Class) wildcardClass51);
        java.lang.Class class62 = null;
        org.jfree.data.time.TimeSeries timeSeries63 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class62);
        timeSeries63.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener65 = null;
        timeSeries63.addPropertyChangeListener(propertyChangeListener65);
        boolean boolean67 = timeSeries63.isEmpty();
        boolean boolean68 = timeSeries63.isEmpty();
        java.util.Collection collection69 = timeSeries58.getTimePeriodsUniqueToOtherSeries(timeSeries63);
        java.lang.Class class71 = null;
        org.jfree.data.time.TimeSeries timeSeries72 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class71);
        java.lang.String str73 = timeSeries72.getRangeDescription();
        timeSeries72.setNotify(true);
        java.util.Collection collection76 = timeSeries58.getTimePeriodsUniqueToOtherSeries(timeSeries72);
        boolean boolean77 = day28.equals((java.lang.Object) timeSeries58);
        long long78 = day28.getFirstMillisecond();
        int int79 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) day28);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = day28.previous();
        int int81 = day28.getMonth();
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 12 + "'", int29 == 12);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str37.equals("SerialDate.weekInMonthToString(): invalid code."));
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1577865599999L + "'", long39 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 2019L + "'", long40 == 2019L);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass51);
        org.junit.Assert.assertNull(regularTimePeriod54);
        org.junit.Assert.assertNotNull(classLoader55);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertNotNull(collection69);
        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "Value" + "'", str73.equals("Value"));
        org.junit.Assert.assertNotNull(collection76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + long78 + "' != '" + (-57600000L) + "'", long78 == (-57600000L));
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + (-1) + "'", int79 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod80);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 12 + "'", int81 == 12);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setNotify(true);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class8);
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class13);
        timeSeries14.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries14.addPropertyChangeListener(propertyChangeListener16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries14.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
        java.util.Date date21 = fixedMillisecond19.getEnd();
        java.util.Date date22 = fixedMillisecond19.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (double) 2958465);
        java.util.Calendar calendar25 = null;
        fixedMillisecond19.peg(calendar25);
        java.util.Date date27 = fixedMillisecond19.getTime();
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date27);
        int int29 = day28.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = day28.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = day28.previous();
        java.lang.Class class33 = null;
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class33);
        timeSeries34.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str37 = timeSeries34.getDescription();
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
        long long39 = year38.getLastMillisecond();
        long long40 = year38.getSerialIndex();
        int int41 = timeSeries34.getIndex((org.jfree.data.time.RegularTimePeriod) year38);
        java.lang.Class class49 = null;
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class49);
        java.lang.Class<?> wildcardClass51 = timeSeries50.getClass();
        java.util.Date date52 = null;
        java.util.TimeZone timeZone53 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass51, date52, timeZone53);
        java.lang.ClassLoader classLoader55 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass51);
        org.jfree.data.time.TimeSeries timeSeries56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2, (java.lang.Class) wildcardClass51);
        org.jfree.data.time.TimeSeries timeSeries57 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, "ThreadContext", "org.jfree.data.general.SeriesException: ", (java.lang.Class) wildcardClass51);
        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year38, "Following", "Fourth", (java.lang.Class) wildcardClass51);
        java.lang.Class class62 = null;
        org.jfree.data.time.TimeSeries timeSeries63 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class62);
        timeSeries63.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener65 = null;
        timeSeries63.addPropertyChangeListener(propertyChangeListener65);
        boolean boolean67 = timeSeries63.isEmpty();
        boolean boolean68 = timeSeries63.isEmpty();
        java.util.Collection collection69 = timeSeries58.getTimePeriodsUniqueToOtherSeries(timeSeries63);
        java.lang.Class class71 = null;
        org.jfree.data.time.TimeSeries timeSeries72 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class71);
        java.lang.String str73 = timeSeries72.getRangeDescription();
        timeSeries72.setNotify(true);
        java.util.Collection collection76 = timeSeries58.getTimePeriodsUniqueToOtherSeries(timeSeries72);
        boolean boolean77 = day28.equals((java.lang.Object) timeSeries58);
        long long78 = day28.getFirstMillisecond();
        int int79 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) day28);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = day28.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = day28.previous();
        int int82 = day28.getDayOfMonth();
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 12 + "'", int29 == 12);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str37.equals("SerialDate.weekInMonthToString(): invalid code."));
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1577865599999L + "'", long39 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 2019L + "'", long40 == 2019L);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass51);
        org.junit.Assert.assertNull(regularTimePeriod54);
        org.junit.Assert.assertNotNull(classLoader55);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertNotNull(collection69);
        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "Value" + "'", str73.equals("Value"));
        org.junit.Assert.assertNotNull(collection76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + long78 + "' != '" + (-57600000L) + "'", long78 == (-57600000L));
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + (-1) + "'", int79 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod80);
        org.junit.Assert.assertNotNull(regularTimePeriod81);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 31 + "'", int82 == 31);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class2);
        timeSeries3.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries3.setDomainDescription("");
        java.lang.Class class8 = timeSeries3.getTimePeriodClass();
        timeSeries3.clear();
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class13);
        timeSeries14.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries14.addPropertyChangeListener(propertyChangeListener16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries14.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        int int23 = year21.compareTo((java.lang.Object) "");
        long long24 = year21.getFirstMillisecond();
        int int25 = timeSeries14.getIndex((org.jfree.data.time.RegularTimePeriod) year21);
        java.lang.Class class29 = null;
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class29);
        timeSeries30.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener32 = null;
        timeSeries30.addPropertyChangeListener(propertyChangeListener32);
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries30.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
        java.util.Date date37 = fixedMillisecond35.getEnd();
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date37);
        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year21, (org.jfree.data.time.RegularTimePeriod) day38);
        org.jfree.data.time.SerialDate serialDate40 = day38.getSerialDate();
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(serialDate40);
        try {
            org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (short) 0, serialDate40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1546329600000L + "'", long24 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(timeSeries39);
        org.junit.Assert.assertNotNull(serialDate40);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond9.previous();
        java.lang.Number number11 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, number11);
        int int13 = timeSeries4.getMaximumItemCount();
        java.lang.String str14 = timeSeries4.getDomainDescription();
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2147483647 + "'", int13 == 2147483647);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 97");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        int int4 = month3.getYearValue();
        org.jfree.data.time.Year year5 = month3.getYear();
        org.jfree.data.time.Year year6 = month3.getYear();
        java.lang.String str7 = year6.toString();
        long long8 = year6.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546329600000L + "'", long8 == 1546329600000L);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) "SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str6 = seriesChangeEvent5.toString();
        java.lang.String str7 = seriesChangeEvent5.toString();
        java.lang.String str8 = seriesChangeEvent5.toString();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=SerialDate.weekInMonthToString(): invalid code.]" + "'", str6.equals("org.jfree.data.general.SeriesChangeEvent[source=SerialDate.weekInMonthToString(): invalid code.]"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=SerialDate.weekInMonthToString(): invalid code.]" + "'", str7.equals("org.jfree.data.general.SeriesChangeEvent[source=SerialDate.weekInMonthToString(): invalid code.]"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=SerialDate.weekInMonthToString(): invalid code.]" + "'", str8.equals("org.jfree.data.general.SeriesChangeEvent[source=SerialDate.weekInMonthToString(): invalid code.]"));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.String str2 = seriesException1.toString();
        java.lang.Throwable[] throwableArray3 = seriesException1.getSuppressed();
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("");
        java.lang.String str6 = seriesException5.toString();
        java.lang.String str7 = seriesException5.toString();
        java.lang.String str8 = seriesException5.toString();
        seriesException1.addSuppressed((java.lang.Throwable) seriesException5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str2.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str6.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str7.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str8.equals("org.jfree.data.general.SeriesException: "));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries2.setDomainDescription("");
        java.lang.Class class7 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class12);
        timeSeries13.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        int int22 = year20.compareTo((java.lang.Object) "");
        long long23 = year20.getFirstMillisecond();
        int int24 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) year20);
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class28);
        timeSeries29.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timeSeries29.addPropertyChangeListener(propertyChangeListener31);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
        java.util.Date date36 = fixedMillisecond34.getEnd();
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date36);
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) year20, (org.jfree.data.time.RegularTimePeriod) day37);
        long long39 = day37.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = day37.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = day37.previous();
        int int42 = day37.getDayOfMonth();
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1546329600000L + "'", long23 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeSeries38);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-57600000L) + "'", long39 == (-57600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 31 + "'", int42 == 31);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("Following");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        java.lang.Class<?> wildcardClass3 = timeSeries2.getClass();
        java.lang.Class class7 = null;
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class7);
        timeSeries8.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries8.addPropertyChangeListener(propertyChangeListener10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries8.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        int int17 = year15.compareTo((java.lang.Object) "");
        long long18 = year15.getFirstMillisecond();
        int int19 = timeSeries8.getIndex((org.jfree.data.time.RegularTimePeriod) year15);
        java.lang.String str20 = timeSeries8.getDomainDescription();
        timeSeries8.setMaximumItemCount((int) (byte) 10);
        long long23 = timeSeries8.getMaximumItemAge();
        java.lang.Class class27 = null;
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class27);
        timeSeries28.clear();
        java.lang.Class class33 = null;
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class33);
        timeSeries34.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener36 = null;
        timeSeries34.addPropertyChangeListener(propertyChangeListener36);
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries34.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39);
        java.util.Date date41 = fixedMillisecond39.getEnd();
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
        long long43 = year42.getLastMillisecond();
        boolean boolean44 = fixedMillisecond39.equals((java.lang.Object) year42);
        int int46 = fixedMillisecond39.compareTo((java.lang.Object) 1577865599999L);
        java.lang.Number number47 = timeSeries28.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, 10.0d);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (double) 2019L);
        timeSeries2.setNotify(false);
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year();
        long long55 = year54.getLastMillisecond();
        java.util.Date date56 = year54.getStart();
        org.jfree.data.time.Month month57 = new org.jfree.data.time.Month(date56);
        int int58 = month57.getYearValue();
        java.lang.String str59 = month57.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem60 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) month57);
        int int61 = timeSeries2.getMaximumItemCount();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1546329600000L + "'", long18 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hi!" + "'", str20.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 9223372036854775807L + "'", long23 == 9223372036854775807L);
        org.junit.Assert.assertNull(timeSeriesDataItem40);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1577865599999L + "'", long43 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
        org.junit.Assert.assertNull(number47);
        org.junit.Assert.assertNull(timeSeriesDataItem49);
        org.junit.Assert.assertNull(timeSeriesDataItem51);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1577865599999L + "'", long55 == 1577865599999L);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 2019 + "'", int58 == 2019);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "January 2019" + "'", str59.equals("January 2019"));
        org.junit.Assert.assertNotNull(timeSeriesDataItem60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 2147483647 + "'", int61 == 2147483647);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setNotify(true);
        java.lang.Class class5 = null;
        java.lang.Class class9 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class9);
        timeSeries10.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries10.addPropertyChangeListener(propertyChangeListener12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries10.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.util.Date date17 = fixedMillisecond15.getEnd();
        java.util.TimeZone timeZone18 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date17, timeZone18);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date17);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) day20);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        int int24 = year22.compareTo((java.lang.Object) "");
        long long25 = year22.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year22.next();
        long long27 = year22.getLastMillisecond();
        boolean boolean28 = day20.equals((java.lang.Object) long27);
        org.jfree.data.time.Year year30 = org.jfree.data.time.Year.parseYear("2018");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year30.next();
        int int32 = day20.compareTo((java.lang.Object) year30);
        java.util.Calendar calendar33 = null;
        try {
            day20.peg(calendar33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1546329600000L + "'", long25 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1577865599999L + "'", long27 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(year30);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        try {
            timeSeries1.setMaximumItemAge((-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'periods' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(class2);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("October");
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries2.setDomainDescription("");
        java.lang.Class class7 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class12);
        timeSeries13.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        int int22 = year20.compareTo((java.lang.Object) "");
        long long23 = year20.getFirstMillisecond();
        int int24 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) year20);
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class28);
        timeSeries29.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timeSeries29.addPropertyChangeListener(propertyChangeListener31);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
        java.util.Date date36 = fixedMillisecond34.getEnd();
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date36);
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) year20, (org.jfree.data.time.RegularTimePeriod) day37);
        long long39 = day37.getFirstMillisecond();
        boolean boolean41 = day37.equals((java.lang.Object) 1577865599999L);
        long long42 = day37.getSerialIndex();
        java.util.Date date43 = day37.getStart();
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date43);
        java.util.TimeZone timeZone45 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date43, timeZone45);
        int int47 = day46.getYear();
        java.util.Calendar calendar48 = null;
        try {
            long long49 = day46.getFirstMillisecond(calendar48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1546329600000L + "'", long23 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeSeries38);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-57600000L) + "'", long39 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 25568L + "'", long42 == 25568L);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(timeZone45);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1969 + "'", int47 == 1969);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class5);
        timeSeries6.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries6.setDomainDescription("");
        java.lang.Class class11 = timeSeries6.getTimePeriodClass();
        timeSeries6.clear();
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class16);
        timeSeries17.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timeSeries17.addPropertyChangeListener(propertyChangeListener19);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries17.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        int int26 = year24.compareTo((java.lang.Object) "");
        long long27 = year24.getFirstMillisecond();
        int int28 = timeSeries17.getIndex((org.jfree.data.time.RegularTimePeriod) year24);
        java.lang.Class class32 = null;
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class32);
        timeSeries33.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener35 = null;
        timeSeries33.addPropertyChangeListener(propertyChangeListener35);
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries33.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond38);
        java.util.Date date40 = fixedMillisecond38.getEnd();
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date40);
        org.jfree.data.time.TimeSeries timeSeries42 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) year24, (org.jfree.data.time.RegularTimePeriod) day41);
        org.jfree.data.time.SerialDate serialDate43 = day41.getSerialDate();
        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.addMonths(29, serialDate43);
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(3, serialDate44);
        java.lang.String str46 = serialDate45.getDescription();
        org.jfree.data.time.SerialDate serialDate47 = org.jfree.data.time.SerialDate.addMonths((int) (short) 100, serialDate45);
        java.lang.String str48 = serialDate45.getDescription();
        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate45);
        org.junit.Assert.assertNull(class11);
        org.junit.Assert.assertNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1546329600000L + "'", long27 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem39);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(timeSeries42);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertNull(str46);
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertNotNull(serialDate49);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class4);
        timeSeries5.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries5.addPropertyChangeListener(propertyChangeListener7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries5.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
        java.util.Date date12 = fixedMillisecond10.getEnd();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getLastMillisecond();
        boolean boolean15 = fixedMillisecond10.equals((java.lang.Object) year13);
        int int17 = fixedMillisecond10.compareTo((java.lang.Object) 1577865599999L);
        java.util.Calendar calendar18 = null;
        long long19 = fixedMillisecond10.getFirstMillisecond(calendar18);
        java.lang.Class class25 = null;
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class25);
        timeSeries26.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str29 = timeSeries26.getDescription();
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        long long31 = year30.getLastMillisecond();
        long long32 = year30.getSerialIndex();
        int int33 = timeSeries26.getIndex((org.jfree.data.time.RegularTimePeriod) year30);
        java.lang.Class class41 = null;
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class41);
        java.lang.Class<?> wildcardClass43 = timeSeries42.getClass();
        java.util.Date date44 = null;
        java.util.TimeZone timeZone45 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass43, date44, timeZone45);
        java.lang.ClassLoader classLoader47 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass43);
        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2, (java.lang.Class) wildcardClass43);
        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, "ThreadContext", "org.jfree.data.general.SeriesException: ", (java.lang.Class) wildcardClass43);
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year30, "Following", "Fourth", (java.lang.Class) wildcardClass43);
        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), (java.lang.Class) wildcardClass43);
        java.net.URL uRL52 = org.jfree.chart.util.ObjectUtilities.getResource("2018", (java.lang.Class) wildcardClass43);
        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond10, "Wed Dec 31 16:00:00 PST 1969", "Wed Dec 31 16:00:00 PST 1969", (java.lang.Class) wildcardClass43);
        org.jfree.data.time.TimeSeries timeSeries56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.Class class57 = timeSeries56.getTimePeriodClass();
        java.net.URL uRL58 = org.jfree.chart.util.ObjectUtilities.getResource("Following", class57);
        java.lang.Class class62 = null;
        org.jfree.data.time.TimeSeries timeSeries63 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class62);
        java.lang.Class class67 = null;
        org.jfree.data.time.TimeSeries timeSeries68 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class67);
        timeSeries68.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener70 = null;
        timeSeries68.addPropertyChangeListener(propertyChangeListener70);
        org.jfree.data.time.FixedMillisecond fixedMillisecond73 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem74 = timeSeries68.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond73);
        java.util.Date date75 = fixedMillisecond73.getEnd();
        java.util.Date date76 = fixedMillisecond73.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem78 = timeSeries63.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond73, (double) 2958465);
        java.util.Calendar calendar79 = null;
        fixedMillisecond73.peg(calendar79);
        java.util.Date date81 = fixedMillisecond73.getTime();
        org.jfree.data.time.SerialDate serialDate82 = org.jfree.data.time.SerialDate.createInstance(date81);
        org.jfree.data.time.FixedMillisecond fixedMillisecond83 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date84 = fixedMillisecond83.getTime();
        java.util.TimeZone timeZone85 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year86 = new org.jfree.data.time.Year(date84, timeZone85);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod87 = org.jfree.data.time.RegularTimePeriod.createInstance(class57, date81, timeZone85);
        java.lang.Object obj88 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("October", (java.lang.Class) wildcardClass43, class57);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str29.equals("SerialDate.weekInMonthToString(): invalid code."));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1577865599999L + "'", long31 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 2019L + "'", long32 == 2019L);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertNull(regularTimePeriod46);
        org.junit.Assert.assertNotNull(classLoader47);
        org.junit.Assert.assertNull(uRL52);
        org.junit.Assert.assertNotNull(class57);
        org.junit.Assert.assertNull(uRL58);
        org.junit.Assert.assertNull(timeSeriesDataItem74);
        org.junit.Assert.assertNotNull(date75);
        org.junit.Assert.assertNotNull(date76);
        org.junit.Assert.assertNull(timeSeriesDataItem78);
        org.junit.Assert.assertNotNull(date81);
        org.junit.Assert.assertNotNull(serialDate82);
        org.junit.Assert.assertNotNull(date84);
        org.junit.Assert.assertNotNull(timeZone85);
        org.junit.Assert.assertNotNull(regularTimePeriod87);
        org.junit.Assert.assertNull(obj88);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries4.addChangeListener(seriesChangeListener6);
        long long8 = timeSeries4.getMaximumItemAge();
        long long9 = timeSeries4.getMaximumItemAge();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getLastMillisecond();
        java.util.Date date12 = year10.getStart();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date12);
        int int14 = month13.getMonth();
        int int15 = month13.getYearValue();
        long long16 = month13.getSerialIndex();
        long long17 = month13.getFirstMillisecond();
        java.lang.Number number18 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month13);
        long long19 = month13.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9223372036854775807L + "'", long8 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 24229L + "'", long16 == 24229L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1546329600000L + "'", long17 == 1546329600000L);
        org.junit.Assert.assertNull(number18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1546329600000L + "'", long19 == 1546329600000L);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        int int4 = month3.getYearValue();
        org.jfree.data.time.Year year5 = month3.getYear();
        java.lang.String str6 = month3.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "January 2019" + "'", str6.equals("January 2019"));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        java.lang.Class<?> wildcardClass3 = timeSeries2.getClass();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        java.util.Date date6 = year4.getStart();
        java.lang.String str7 = year4.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year4, (java.lang.Number) 2019);
        timeSeries2.removeAgedItems(true);
        java.lang.Comparable comparable12 = timeSeries2.getKey();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + '4' + "'", comparable12.equals('4'));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(9);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int3 = year1.compareTo((java.lang.Object) "");
        long long4 = year1.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year1.next();
        long long6 = year1.getLastMillisecond();
        try {
            org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((-460), year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int3 = year1.compareTo((java.lang.Object) "");
        long long4 = year1.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year1.next();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getLastMillisecond();
        long long8 = year6.getLastMillisecond();
        int int9 = year1.compareTo((java.lang.Object) long8);
        try {
            org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(0, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class2);
        java.lang.Class<?> wildcardClass4 = timeSeries3.getClass();
        java.util.Date date5 = null;
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date5, timeZone6);
        java.lang.ClassLoader classLoader8 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2, (java.lang.Class) wildcardClass4);
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class13);
        timeSeries14.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries14.addPropertyChangeListener(propertyChangeListener16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries14.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
        java.util.Date date21 = fixedMillisecond19.getEnd();
        java.util.Date date22 = fixedMillisecond19.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (java.lang.Number) 2019);
        java.util.Collection collection25 = timeSeries9.getTimePeriods();
        java.lang.String str26 = timeSeries9.getRangeDescription();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(classLoader8);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertNotNull(collection25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Value" + "'", str26.equals("Value"));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class2);
        java.lang.Class<?> wildcardClass4 = timeSeries3.getClass();
        java.util.Date date5 = null;
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date5, timeZone6);
        java.lang.ClassLoader classLoader8 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2, (java.lang.Class) wildcardClass4);
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class13);
        timeSeries14.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries14.addPropertyChangeListener(propertyChangeListener16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries14.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
        java.util.Date date21 = fixedMillisecond19.getEnd();
        java.util.Date date22 = fixedMillisecond19.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (java.lang.Number) 2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = fixedMillisecond19.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod25, (double) 11);
        org.jfree.data.general.SeriesException seriesException29 = new org.jfree.data.general.SeriesException("");
        java.lang.String str30 = seriesException29.toString();
        int int31 = timeSeriesDataItem27.compareTo((java.lang.Object) seriesException29);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(classLoader8);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str30.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
    }

//    @Test
//    public void test036() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test036");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (double) 11);
//        long long3 = fixedMillisecond0.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560441450794L + "'", long3 == 1560441450794L);
//    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class2);
        java.lang.Class<?> wildcardClass4 = timeSeries3.getClass();
        java.util.Date date5 = null;
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date5, timeZone6);
        java.lang.ClassLoader classLoader8 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2, (java.lang.Class) wildcardClass4);
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class13);
        timeSeries14.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries14.addPropertyChangeListener(propertyChangeListener16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries14.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
        java.util.Date date21 = fixedMillisecond19.getEnd();
        java.util.Date date22 = fixedMillisecond19.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (java.lang.Number) 2019);
        java.lang.Class class25 = null;
        java.lang.Class class29 = null;
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class29);
        timeSeries30.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener32 = null;
        timeSeries30.addPropertyChangeListener(propertyChangeListener32);
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries30.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
        java.util.Date date37 = fixedMillisecond35.getEnd();
        java.util.TimeZone timeZone38 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance(class25, date37, timeZone38);
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond(date37);
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year(date37);
        try {
            timeSeries9.add((org.jfree.data.time.RegularTimePeriod) year41, (double) (-57600000L));
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.TimeSeries.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(classLoader8);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNull(regularTimePeriod39);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        int int13 = year11.compareTo((java.lang.Object) "");
        long long14 = year11.getFirstMillisecond();
        int int15 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) year11);
        timeSeries4.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: ClassContext");
        java.lang.Object obj18 = timeSeries4.clone();
        java.util.List list19 = timeSeries4.getItems();
        java.lang.Class class20 = null;
        java.lang.Class class24 = null;
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class24);
        timeSeries25.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener27 = null;
        timeSeries25.addPropertyChangeListener(propertyChangeListener27);
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries25.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30);
        java.util.Date date32 = fixedMillisecond30.getEnd();
        java.util.TimeZone timeZone33 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance(class20, date32, timeZone33);
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(date32);
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date32);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) day36);
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date39 = fixedMillisecond38.getTime();
        java.util.TimeZone timeZone40 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year(date39, timeZone40);
        boolean boolean42 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) timeSeries4, (java.lang.Object) timeZone40);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNull(timeSeriesDataItem31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNull(regularTimePeriod34);
        org.junit.Assert.assertNull(timeSeriesDataItem37);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(timeZone40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((int) 'a', false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        java.util.Calendar calendar4 = null;
        try {
            month3.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 1);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        long long4 = fixedMillisecond1.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.Class class9 = timeSeries8.getTimePeriodClass();
        java.lang.ClassLoader classLoader10 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class9);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, "Fourth", "", class9);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        java.lang.String str13 = timeSeries12.getRangeDescription();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1L + "'", long4 == 1L);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertNotNull(classLoader10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Value" + "'", str13.equals("Value"));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.lang.String str2 = month0.toString();
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class4);
        timeSeries5.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries5.setDomainDescription("");
        java.lang.Class class10 = timeSeries5.getTimePeriodClass();
        timeSeries5.clear();
        boolean boolean13 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) timeSeries5, (java.lang.Object) "January 2019");
        boolean boolean14 = month0.equals((java.lang.Object) timeSeries5);
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class16);
        timeSeries17.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries17.setDomainDescription("");
        java.lang.Class class22 = timeSeries17.getTimePeriodClass();
        timeSeries17.clear();
        java.lang.Class class27 = null;
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class27);
        timeSeries28.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener30 = null;
        timeSeries28.addPropertyChangeListener(propertyChangeListener30);
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries28.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond33);
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
        int int37 = year35.compareTo((java.lang.Object) "");
        long long38 = year35.getFirstMillisecond();
        int int39 = timeSeries28.getIndex((org.jfree.data.time.RegularTimePeriod) year35);
        java.lang.Class class43 = null;
        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class43);
        timeSeries44.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener46 = null;
        timeSeries44.addPropertyChangeListener(propertyChangeListener46);
        org.jfree.data.time.FixedMillisecond fixedMillisecond49 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = timeSeries44.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond49);
        java.util.Date date51 = fixedMillisecond49.getEnd();
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(date51);
        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) year35, (org.jfree.data.time.RegularTimePeriod) day52);
        org.jfree.data.time.SerialDate serialDate54 = day52.getSerialDate();
        java.util.Date date55 = day52.getStart();
        org.jfree.data.time.Month month56 = new org.jfree.data.time.Month(date55);
        int int57 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) month56);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "June 2019" + "'", str2.equals("June 2019"));
        org.junit.Assert.assertNull(class10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(class22);
        org.junit.Assert.assertNull(timeSeriesDataItem34);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1546329600000L + "'", long38 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem50);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNotNull(timeSeries53);
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-1) + "'", int57 == (-1));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str5 = timeSeries2.getDescription();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getLastMillisecond();
        long long8 = year6.getSerialIndex();
        int int9 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) year6);
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class13);
        timeSeries14.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries14.addPropertyChangeListener(propertyChangeListener16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) (short) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = fixedMillisecond19.previous();
        java.lang.Number number21 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, number21);
        timeSeries14.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries2.addAndOrUpdate(timeSeries14);
        java.beans.PropertyChangeListener propertyChangeListener25 = null;
        timeSeries2.addPropertyChangeListener(propertyChangeListener25);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str5.equals("SerialDate.weekInMonthToString(): invalid code."));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertNotNull(timeSeries24);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class2);
        java.lang.Class<?> wildcardClass4 = timeSeries3.getClass();
        java.util.Date date5 = null;
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date5, timeZone6);
        java.lang.ClassLoader classLoader8 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2, (java.lang.Class) wildcardClass4);
        timeSeries9.removeAgedItems(false);
        timeSeries9.setNotify(false);
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries9.removePropertyChangeListener(propertyChangeListener14);
        java.util.List list16 = timeSeries9.getItems();
        java.lang.Class class18 = null;
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class18);
        timeSeries19.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str22 = timeSeries19.getDescription();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        long long24 = year23.getLastMillisecond();
        long long25 = year23.getSerialIndex();
        int int26 = timeSeries19.getIndex((org.jfree.data.time.RegularTimePeriod) year23);
        java.lang.Class class34 = null;
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class34);
        java.lang.Class<?> wildcardClass36 = timeSeries35.getClass();
        java.util.Date date37 = null;
        java.util.TimeZone timeZone38 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date37, timeZone38);
        java.lang.ClassLoader classLoader40 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass36);
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2, (java.lang.Class) wildcardClass36);
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, "ThreadContext", "org.jfree.data.general.SeriesException: ", (java.lang.Class) wildcardClass36);
        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year23, "Following", "Fourth", (java.lang.Class) wildcardClass36);
        java.lang.Class class47 = null;
        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class47);
        timeSeries48.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener50 = null;
        timeSeries48.addPropertyChangeListener(propertyChangeListener50);
        boolean boolean52 = timeSeries48.isEmpty();
        boolean boolean53 = timeSeries48.isEmpty();
        java.util.Collection collection54 = timeSeries43.getTimePeriodsUniqueToOtherSeries(timeSeries48);
        org.jfree.data.time.TimeSeries timeSeries55 = timeSeries9.addAndOrUpdate(timeSeries43);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(classLoader8);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str22.equals("SerialDate.weekInMonthToString(): invalid code."));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1577865599999L + "'", long24 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 2019L + "'", long25 == 2019L);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNull(regularTimePeriod39);
        org.junit.Assert.assertNotNull(classLoader40);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertNotNull(collection54);
        org.junit.Assert.assertNotNull(timeSeries55);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) 'a', 29);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 97");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        java.lang.String str4 = month3.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
        java.lang.String str6 = month3.toString();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class10);
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class15);
        timeSeries16.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timeSeries16.addPropertyChangeListener(propertyChangeListener18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries16.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21);
        java.util.Date date23 = fixedMillisecond21.getEnd();
        java.util.Date date24 = fixedMillisecond21.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, (double) 2958465);
        java.util.Calendar calendar27 = null;
        fixedMillisecond21.peg(calendar27);
        java.util.Date date29 = fixedMillisecond21.getTime();
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date29);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date29);
        boolean boolean32 = month3.equals((java.lang.Object) date29);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "January 2019" + "'", str4.equals("January 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "January 2019" + "'", str6.equals("January 2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNull(timeSeriesDataItem26);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class5);
        java.lang.Class<?> wildcardClass7 = timeSeries6.getClass();
        java.util.Date date8 = null;
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date8, timeZone9);
        java.lang.ClassLoader classLoader11 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass7);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2, (java.lang.Class) wildcardClass7);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, "ThreadContext", "org.jfree.data.general.SeriesException: ", (java.lang.Class) wildcardClass7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries13.removeChangeListener(seriesChangeListener14);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(classLoader11);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        int int13 = year11.compareTo((java.lang.Object) "");
        long long14 = year11.getFirstMillisecond();
        int int15 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) year11);
        java.lang.String str16 = timeSeries4.getDomainDescription();
        timeSeries4.setMaximumItemCount((int) (byte) 10);
        long long19 = timeSeries4.getMaximumItemAge();
        java.lang.Class class23 = null;
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class23);
        timeSeries24.clear();
        java.lang.Class class29 = null;
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class29);
        timeSeries30.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener32 = null;
        timeSeries30.addPropertyChangeListener(propertyChangeListener32);
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries30.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
        java.util.Date date37 = fixedMillisecond35.getEnd();
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
        long long39 = year38.getLastMillisecond();
        boolean boolean40 = fixedMillisecond35.equals((java.lang.Object) year38);
        int int42 = fixedMillisecond35.compareTo((java.lang.Object) 1577865599999L);
        java.lang.Number number43 = timeSeries24.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35, 10.0d);
        java.lang.Class class46 = null;
        java.lang.Class class50 = null;
        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class50);
        timeSeries51.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener53 = null;
        timeSeries51.addPropertyChangeListener(propertyChangeListener53);
        org.jfree.data.time.FixedMillisecond fixedMillisecond56 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem57 = timeSeries51.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond56);
        java.util.Date date58 = fixedMillisecond56.getEnd();
        java.util.TimeZone timeZone59 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = org.jfree.data.time.RegularTimePeriod.createInstance(class46, date58, timeZone59);
        org.jfree.data.time.FixedMillisecond fixedMillisecond61 = new org.jfree.data.time.FixedMillisecond(date58);
        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year(date58);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = year62.previous();
        timeSeries4.update((org.jfree.data.time.RegularTimePeriod) year62, (java.lang.Number) 9223372036854775807L);
        timeSeries4.removeAgedItems(false);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 9223372036854775807L + "'", long19 == 9223372036854775807L);
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1577865599999L + "'", long39 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertNull(number43);
        org.junit.Assert.assertNull(timeSeriesDataItem45);
        org.junit.Assert.assertNull(timeSeriesDataItem57);
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertNull(regularTimePeriod60);
        org.junit.Assert.assertNotNull(regularTimePeriod63);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1535785200000L);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries2.setDomainDescription("");
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries2.addPropertyChangeListener(propertyChangeListener7);
        boolean boolean9 = timeSeries2.isEmpty();
        timeSeries2.setDescription("January 2019");
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        int int4 = month3.getYearValue();
        org.jfree.data.time.Year year5 = month3.getYear();
        org.jfree.data.time.Year year6 = month3.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, 0.0d);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        int int11 = year9.compareTo((java.lang.Object) "");
        long long12 = year9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year9.next();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.Class class16 = timeSeries15.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod13, class16);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year6, class16);
        java.lang.Class class22 = null;
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class22);
        timeSeries23.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener25 = null;
        timeSeries23.addPropertyChangeListener(propertyChangeListener25);
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries23.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28);
        java.util.Date date30 = fixedMillisecond28.getEnd();
        java.util.Date date31 = fixedMillisecond28.getTime();
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        long long33 = year32.getLastMillisecond();
        java.util.Date date34 = year32.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = year32.next();
        java.util.Date date36 = year32.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date38 = fixedMillisecond37.getTime();
        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year(date38, timeZone39);
        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month(date36, timeZone39);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date31, timeZone39);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1546329600000L + "'", long12 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(class16);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1577865599999L + "'", long33 == 1577865599999L);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(timeZone39);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setNotify(true);
        timeSeries2.setMaximumItemCount((int) '#');
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getLastMillisecond();
        java.util.Date date9 = year7.getStart();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date9);
        java.lang.String str11 = month10.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month10.next();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year13.previous();
        int int16 = month10.compareTo((java.lang.Object) year13);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month10, (double) 'a');
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        int int21 = year19.compareTo((java.lang.Object) "");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year19.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries2.addOrUpdate(regularTimePeriod22, (double) 3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "January 2019" + "'", str11.equals("January 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(timeSeriesDataItem24);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str5 = timeSeries2.getDescription();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getLastMillisecond();
        long long8 = year6.getSerialIndex();
        int int9 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) year6);
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class17);
        java.lang.Class<?> wildcardClass19 = timeSeries18.getClass();
        java.util.Date date20 = null;
        java.util.TimeZone timeZone21 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date20, timeZone21);
        java.lang.ClassLoader classLoader23 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass19);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2, (java.lang.Class) wildcardClass19);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, "ThreadContext", "org.jfree.data.general.SeriesException: ", (java.lang.Class) wildcardClass19);
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year6, "Following", "Fourth", (java.lang.Class) wildcardClass19);
        try {
            timeSeries26.delete(6, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str5.equals("SerialDate.weekInMonthToString(): invalid code."));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(classLoader23);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        int int13 = year11.compareTo((java.lang.Object) "");
        long long14 = year11.getFirstMillisecond();
        int int15 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) year11);
        timeSeries4.setDomainDescription("org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        long long19 = year18.getLastMillisecond();
        java.util.Date date20 = year18.getStart();
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(date20);
        java.lang.String str22 = month21.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month21.next();
        java.lang.String str24 = month21.toString();
        try {
            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) month21, (double) 1560441401245L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1577865599999L + "'", long19 == 1577865599999L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "January 2019" + "'", str22.equals("January 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "January 2019" + "'", str24.equals("January 2019"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((-458));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (-458) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 1);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        long long4 = fixedMillisecond1.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.Class class9 = timeSeries8.getTimePeriodClass();
        java.lang.ClassLoader classLoader10 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class9);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, "Fourth", "", class9);
        try {
            timeSeries11.update(7, (java.lang.Number) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1L + "'", long4 == 1L);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertNotNull(classLoader10);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        java.lang.String str4 = month3.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year6.previous();
        int int9 = month3.compareTo((java.lang.Object) year6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month3.previous();
        java.util.Date date11 = month3.getEnd();
        java.util.Date date12 = month3.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month3.next();
        java.util.Calendar calendar14 = null;
        try {
            long long15 = regularTimePeriod13.getMiddleMillisecond(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "January 2019" + "'", str4.equals("January 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 1);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        long long4 = fixedMillisecond1.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.Class class9 = timeSeries8.getTimePeriodClass();
        java.lang.ClassLoader classLoader10 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class9);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, "Fourth", "", class9);
        java.util.Calendar calendar12 = null;
        long long13 = fixedMillisecond1.getLastMillisecond(calendar12);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1L + "'", long4 == 1L);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertNotNull(classLoader10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class4);
        timeSeries5.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries5.setDomainDescription("");
        java.lang.Class class10 = timeSeries5.getTimePeriodClass();
        timeSeries5.clear();
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class15);
        timeSeries16.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timeSeries16.addPropertyChangeListener(propertyChangeListener18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries16.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        int int25 = year23.compareTo((java.lang.Object) "");
        long long26 = year23.getFirstMillisecond();
        int int27 = timeSeries16.getIndex((org.jfree.data.time.RegularTimePeriod) year23);
        java.lang.Class class31 = null;
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class31);
        timeSeries32.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener34 = null;
        timeSeries32.addPropertyChangeListener(propertyChangeListener34);
        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries32.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond37);
        java.util.Date date39 = fixedMillisecond37.getEnd();
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date39);
        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) year23, (org.jfree.data.time.RegularTimePeriod) day40);
        org.jfree.data.time.SerialDate serialDate42 = day40.getSerialDate();
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.addMonths(29, serialDate42);
        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(3, serialDate43);
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.addMonths(10, serialDate43);
        try {
            org.jfree.data.time.SerialDate serialDate47 = serialDate45.getNearestDayOfWeek(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(class10);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1546329600000L + "'", long26 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem38);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(timeSeries41);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(serialDate45);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        java.lang.String str3 = timeSeries2.getRangeDescription();
        int int4 = timeSeries2.getItemCount();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Value" + "'", str3.equals("Value"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        java.lang.Class<?> wildcardClass3 = timeSeries2.getClass();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        java.util.Date date6 = year4.getStart();
        java.lang.String str7 = year4.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year4, (java.lang.Number) 2019);
        java.lang.String str10 = timeSeries2.getDomainDescription();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Time" + "'", str10.equals("Time"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class3);
        java.lang.Class<?> wildcardClass5 = timeSeries4.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        java.lang.ClassLoader classLoader9 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass5);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2, (java.lang.Class) wildcardClass5);
        java.lang.ClassLoader classLoader11 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass5);
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class13);
        timeSeries14.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries14.setDomainDescription("");
        java.lang.Class class19 = timeSeries14.getTimePeriodClass();
        timeSeries14.clear();
        java.lang.Class class24 = null;
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class24);
        timeSeries25.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener27 = null;
        timeSeries25.addPropertyChangeListener(propertyChangeListener27);
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries25.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        int int34 = year32.compareTo((java.lang.Object) "");
        long long35 = year32.getFirstMillisecond();
        int int36 = timeSeries25.getIndex((org.jfree.data.time.RegularTimePeriod) year32);
        java.lang.Class class40 = null;
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class40);
        timeSeries41.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener43 = null;
        timeSeries41.addPropertyChangeListener(propertyChangeListener43);
        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = timeSeries41.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond46);
        java.util.Date date48 = fixedMillisecond46.getEnd();
        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day(date48);
        org.jfree.data.time.TimeSeries timeSeries50 = timeSeries14.createCopy((org.jfree.data.time.RegularTimePeriod) year32, (org.jfree.data.time.RegularTimePeriod) day49);
        org.jfree.data.time.SerialDate serialDate51 = day49.getSerialDate();
        java.util.Date date52 = day49.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem54 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day49, (java.lang.Number) 1900);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = timeSeriesDataItem54.getPeriod();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem57 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod55, (double) 2958465);
        java.lang.Class class59 = null;
        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class59);
        timeSeries60.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str63 = timeSeries60.getDescription();
        org.jfree.data.time.Year year64 = new org.jfree.data.time.Year();
        long long65 = year64.getLastMillisecond();
        long long66 = year64.getSerialIndex();
        int int67 = timeSeries60.getIndex((org.jfree.data.time.RegularTimePeriod) year64);
        java.lang.Class class75 = null;
        org.jfree.data.time.TimeSeries timeSeries76 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class75);
        java.lang.Class<?> wildcardClass77 = timeSeries76.getClass();
        java.util.Date date78 = null;
        java.util.TimeZone timeZone79 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass77, date78, timeZone79);
        java.lang.ClassLoader classLoader81 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass77);
        org.jfree.data.time.TimeSeries timeSeries82 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2, (java.lang.Class) wildcardClass77);
        org.jfree.data.time.TimeSeries timeSeries83 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, "ThreadContext", "org.jfree.data.general.SeriesException: ", (java.lang.Class) wildcardClass77);
        org.jfree.data.time.TimeSeries timeSeries84 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year64, "Following", "Fourth", (java.lang.Class) wildcardClass77);
        org.jfree.data.time.TimeSeries timeSeries85 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod55, (java.lang.Class) wildcardClass77);
        java.lang.Class class86 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass77);
        java.lang.Object obj87 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Wed Dec 31 16:00:00 PST 1969", (java.lang.Class) wildcardClass5, (java.lang.Class) wildcardClass77);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(classLoader9);
        org.junit.Assert.assertNotNull(classLoader11);
        org.junit.Assert.assertNull(class19);
        org.junit.Assert.assertNull(timeSeriesDataItem31);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1546329600000L + "'", long35 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem47);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(timeSeries50);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertNotNull(regularTimePeriod55);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str63.equals("SerialDate.weekInMonthToString(): invalid code."));
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 1577865599999L + "'", long65 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 2019L + "'", long66 == 2019L);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + (-1) + "'", int67 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass77);
        org.junit.Assert.assertNull(regularTimePeriod80);
        org.junit.Assert.assertNotNull(classLoader81);
        org.junit.Assert.assertNotNull(class86);
        org.junit.Assert.assertNull(obj87);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class2);
        java.lang.Class<?> wildcardClass4 = timeSeries3.getClass();
        java.util.Date date5 = null;
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date5, timeZone6);
        java.lang.ClassLoader classLoader8 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2, (java.lang.Class) wildcardClass4);
        java.lang.ClassLoader classLoader10 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass4);
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader10);
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader10);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(classLoader8);
        org.junit.Assert.assertNotNull(classLoader10);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        int int4 = month3.getYearValue();
        org.jfree.data.time.Year year5 = month3.getYear();
        org.jfree.data.time.Year year6 = month3.getYear();
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class8);
        timeSeries9.setNotify(true);
        java.lang.Class class12 = null;
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class16);
        timeSeries17.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timeSeries17.addPropertyChangeListener(propertyChangeListener19);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries17.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        java.util.Date date24 = fixedMillisecond22.getEnd();
        java.util.TimeZone timeZone25 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date24, timeZone25);
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date24);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) day27);
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
        int int31 = year29.compareTo((java.lang.Object) "");
        long long32 = year29.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year29.next();
        long long34 = year29.getLastMillisecond();
        boolean boolean35 = day27.equals((java.lang.Object) long34);
        int int36 = year6.compareTo((java.lang.Object) boolean35);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertNull(timeSeriesDataItem23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertNull(timeSeriesDataItem28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1546329600000L + "'", long32 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1577865599999L + "'", long34 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        java.lang.String str4 = month3.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year6.previous();
        int int9 = month3.compareTo((java.lang.Object) year6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month3.previous();
        java.util.Date date11 = month3.getEnd();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "January 2019" + "'", str4.equals("January 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(date11);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(13);
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class5);
        timeSeries6.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries6.addPropertyChangeListener(propertyChangeListener8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries6.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11);
        java.util.Date date13 = fixedMillisecond11.getEnd();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        long long15 = year14.getLastMillisecond();
        boolean boolean16 = fixedMillisecond11.equals((java.lang.Object) year14);
        long long17 = fixedMillisecond11.getSerialIndex();
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) (short) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = fixedMillisecond19.previous();
        boolean boolean21 = fixedMillisecond11.equals((java.lang.Object) regularTimePeriod20);
        java.util.Calendar calendar22 = null;
        long long23 = fixedMillisecond11.getLastMillisecond(calendar22);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (java.lang.Number) 1.0d);
        boolean boolean26 = spreadsheetDate1.equals((java.lang.Object) timeSeriesDataItem25);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        int int6 = year4.compareTo((java.lang.Object) "");
        long long7 = year4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.next();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.Class class11 = timeSeries10.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod8, class11);
        java.net.URL uRL13 = org.jfree.chart.util.ObjectUtilities.getResource("Wed Dec 31 16:00:00 PST 1969", class11);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "", "org.jfree.data.time.TimePeriodFormatException: ClassContext", class11);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertNull(uRL13);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) '4', 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 52");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

//    @Test
//    public void test069() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test069");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = day0.getFirstMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertNotNull(serialDate3);
//    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        java.lang.Class class0 = null;
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class4);
        timeSeries5.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries5.addPropertyChangeListener(propertyChangeListener7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries5.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
        java.util.Date date12 = fixedMillisecond10.getEnd();
        java.util.TimeZone timeZone13 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date12, timeZone13);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date12);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond(date12);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date12);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(regularTimePeriod14);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str5 = timeSeries2.getDescription();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getLastMillisecond();
        long long8 = year6.getSerialIndex();
        int int9 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) year6);
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class17);
        java.lang.Class<?> wildcardClass19 = timeSeries18.getClass();
        java.util.Date date20 = null;
        java.util.TimeZone timeZone21 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date20, timeZone21);
        java.lang.ClassLoader classLoader23 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass19);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2, (java.lang.Class) wildcardClass19);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, "ThreadContext", "org.jfree.data.general.SeriesException: ", (java.lang.Class) wildcardClass19);
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year6, "Following", "Fourth", (java.lang.Class) wildcardClass19);
        java.lang.Class class30 = null;
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class30);
        timeSeries31.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener33 = null;
        timeSeries31.addPropertyChangeListener(propertyChangeListener33);
        boolean boolean35 = timeSeries31.isEmpty();
        boolean boolean36 = timeSeries31.isEmpty();
        java.util.Collection collection37 = timeSeries26.getTimePeriodsUniqueToOtherSeries(timeSeries31);
        java.util.Collection collection38 = org.jfree.chart.util.ObjectUtilities.deepClone(collection37);
        java.util.Collection collection39 = org.jfree.chart.util.ObjectUtilities.deepClone(collection37);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str5.equals("SerialDate.weekInMonthToString(): invalid code."));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(classLoader23);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(collection37);
        org.junit.Assert.assertNotNull(collection38);
        org.junit.Assert.assertNotNull(collection39);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        java.lang.Class<?> wildcardClass3 = timeSeries2.getClass();
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries2.removePropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries2.getMaximumItemAge();
        java.lang.String str7 = timeSeries2.getDescription();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class4);
        timeSeries5.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries5.setDomainDescription("");
        java.lang.Class class10 = timeSeries5.getTimePeriodClass();
        timeSeries5.clear();
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class15);
        timeSeries16.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timeSeries16.addPropertyChangeListener(propertyChangeListener18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries16.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        int int25 = year23.compareTo((java.lang.Object) "");
        long long26 = year23.getFirstMillisecond();
        int int27 = timeSeries16.getIndex((org.jfree.data.time.RegularTimePeriod) year23);
        java.lang.Class class31 = null;
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class31);
        timeSeries32.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener34 = null;
        timeSeries32.addPropertyChangeListener(propertyChangeListener34);
        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries32.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond37);
        java.util.Date date39 = fixedMillisecond37.getEnd();
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date39);
        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) year23, (org.jfree.data.time.RegularTimePeriod) day40);
        org.jfree.data.time.SerialDate serialDate42 = day40.getSerialDate();
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.addMonths(29, serialDate42);
        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.addYears((int) (byte) -1, serialDate43);
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.addMonths((-459), serialDate44);
        java.lang.String str46 = serialDate45.toString();
        java.lang.String str47 = serialDate45.getDescription();
        org.junit.Assert.assertNull(class10);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1546329600000L + "'", long26 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem38);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(timeSeries41);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "28-February-1933" + "'", str46.equals("28-February-1933"));
        org.junit.Assert.assertNull(str47);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        java.util.Date date11 = fixedMillisecond9.getEnd();
        int int13 = fixedMillisecond9.compareTo((java.lang.Object) "SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str14 = fixedMillisecond9.toString();
        long long15 = fixedMillisecond9.getSerialIndex();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent16 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) long15);
        java.lang.Object obj17 = seriesChangeEvent16.getSource();
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str14.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + obj17 + "' != '" + 0L + "'", obj17.equals(0L));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class2);
        java.lang.Class<?> wildcardClass4 = timeSeries3.getClass();
        java.util.Date date5 = null;
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date5, timeZone6);
        java.lang.ClassLoader classLoader8 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2, (java.lang.Class) wildcardClass4);
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class13);
        timeSeries14.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries14.addPropertyChangeListener(propertyChangeListener16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries14.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
        java.util.Date date21 = fixedMillisecond19.getEnd();
        java.util.Date date22 = fixedMillisecond19.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (java.lang.Number) 2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = fixedMillisecond19.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod25, (double) 11);
        timeSeriesDataItem27.setValue((java.lang.Number) 43629L);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(classLoader8);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries2.setDomainDescription("");
        java.lang.Class class7 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class12);
        timeSeries13.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        int int22 = year20.compareTo((java.lang.Object) "");
        long long23 = year20.getFirstMillisecond();
        int int24 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) year20);
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class28);
        timeSeries29.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timeSeries29.addPropertyChangeListener(propertyChangeListener31);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
        java.util.Date date36 = fixedMillisecond34.getEnd();
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date36);
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) year20, (org.jfree.data.time.RegularTimePeriod) day37);
        long long39 = day37.getFirstMillisecond();
        boolean boolean41 = day37.equals((java.lang.Object) 1577865599999L);
        long long42 = day37.getSerialIndex();
        java.util.Date date43 = day37.getStart();
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date43);
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year();
        long long46 = year45.getLastMillisecond();
        java.util.Date date47 = year45.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = year45.next();
        java.util.Date date49 = year45.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond50 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date51 = fixedMillisecond50.getTime();
        java.util.TimeZone timeZone52 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year(date51, timeZone52);
        org.jfree.data.time.Month month54 = new org.jfree.data.time.Month(date49, timeZone52);
        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day(date43, timeZone52);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1546329600000L + "'", long23 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeSeries38);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-57600000L) + "'", long39 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 25568L + "'", long42 == 25568L);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1577865599999L + "'", long46 == 1577865599999L);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNotNull(timeZone52);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("2019");
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        java.lang.Class class0 = null;
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class4);
        timeSeries5.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries5.addPropertyChangeListener(propertyChangeListener7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries5.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
        java.util.Date date12 = fixedMillisecond10.getEnd();
        java.util.TimeZone timeZone13 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date12, timeZone13);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(date12);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date12);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(regularTimePeriod14);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(6);
        try {
            org.jfree.data.time.SerialDate serialDate3 = serialDate1.getPreviousDayOfWeek(31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((-458));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("ClassContext");
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries2.setDomainDescription("");
        java.lang.Class class7 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class12);
        timeSeries13.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        int int22 = year20.compareTo((java.lang.Object) "");
        long long23 = year20.getFirstMillisecond();
        int int24 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) year20);
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class28);
        timeSeries29.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timeSeries29.addPropertyChangeListener(propertyChangeListener31);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
        java.util.Date date36 = fixedMillisecond34.getEnd();
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date36);
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) year20, (org.jfree.data.time.RegularTimePeriod) day37);
        java.lang.Class class40 = null;
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class40);
        timeSeries41.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries41.setDomainDescription("");
        java.lang.Class class46 = timeSeries41.getTimePeriodClass();
        timeSeries41.clear();
        java.lang.Class class51 = null;
        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class51);
        timeSeries52.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener54 = null;
        timeSeries52.addPropertyChangeListener(propertyChangeListener54);
        org.jfree.data.time.FixedMillisecond fixedMillisecond57 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem58 = timeSeries52.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond57);
        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year();
        int int61 = year59.compareTo((java.lang.Object) "");
        long long62 = year59.getFirstMillisecond();
        int int63 = timeSeries52.getIndex((org.jfree.data.time.RegularTimePeriod) year59);
        java.lang.Class class67 = null;
        org.jfree.data.time.TimeSeries timeSeries68 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class67);
        timeSeries68.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener70 = null;
        timeSeries68.addPropertyChangeListener(propertyChangeListener70);
        org.jfree.data.time.FixedMillisecond fixedMillisecond73 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem74 = timeSeries68.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond73);
        java.util.Date date75 = fixedMillisecond73.getEnd();
        org.jfree.data.time.Day day76 = new org.jfree.data.time.Day(date75);
        org.jfree.data.time.TimeSeries timeSeries77 = timeSeries41.createCopy((org.jfree.data.time.RegularTimePeriod) year59, (org.jfree.data.time.RegularTimePeriod) day76);
        long long78 = day76.getFirstMillisecond();
        boolean boolean80 = day76.equals((java.lang.Object) 1577865599999L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem82 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day76, (java.lang.Number) (-31507200000L));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod83 = timeSeriesDataItem82.getPeriod();
        java.lang.Object obj84 = timeSeriesDataItem82.clone();
        try {
            timeSeries38.add(timeSeriesDataItem82, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1546329600000L + "'", long23 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeSeries38);
        org.junit.Assert.assertNull(class46);
        org.junit.Assert.assertNull(timeSeriesDataItem58);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1 + "'", int61 == 1);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 1546329600000L + "'", long62 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-1) + "'", int63 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem74);
        org.junit.Assert.assertNotNull(date75);
        org.junit.Assert.assertNotNull(timeSeries77);
        org.junit.Assert.assertTrue("'" + long78 + "' != '" + (-57600000L) + "'", long78 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod83);
        org.junit.Assert.assertNotNull(obj84);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        long long5 = timeSeries2.getMaximumItemAge();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.Class class7 = timeSeries6.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod2, "", "org.jfree.data.general.SeriesChangeEvent[source=SerialDate.weekInMonthToString(): invalid code.]", class7);
        timeSeries8.removeAgedItems(false);
        int int11 = timeSeries8.getMaximumItemCount();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2147483647 + "'", int11 == 2147483647);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries2.removePropertyChangeListener(propertyChangeListener3);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class8);
        timeSeries9.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries9.addPropertyChangeListener(propertyChangeListener11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
        java.util.Date date16 = fixedMillisecond14.getEnd();
        java.util.Date date17 = fixedMillisecond14.getTime();
        boolean boolean19 = fixedMillisecond14.equals((java.lang.Object) 100);
        boolean boolean20 = timeSeries2.equals((java.lang.Object) fixedMillisecond14);
        long long21 = fixedMillisecond14.getMiddleMillisecond();
        java.lang.Class class25 = null;
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class25);
        timeSeries26.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str29 = timeSeries26.getDescription();
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        long long31 = year30.getLastMillisecond();
        long long32 = year30.getSerialIndex();
        int int33 = timeSeries26.getIndex((org.jfree.data.time.RegularTimePeriod) year30);
        java.lang.Class class41 = null;
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class41);
        java.lang.Class<?> wildcardClass43 = timeSeries42.getClass();
        java.util.Date date44 = null;
        java.util.TimeZone timeZone45 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass43, date44, timeZone45);
        java.lang.ClassLoader classLoader47 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass43);
        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2, (java.lang.Class) wildcardClass43);
        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, "ThreadContext", "org.jfree.data.general.SeriesException: ", (java.lang.Class) wildcardClass43);
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year30, "Following", "Fourth", (java.lang.Class) wildcardClass43);
        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1), (java.lang.Class) wildcardClass43);
        java.net.URL uRL52 = org.jfree.chart.util.ObjectUtilities.getResource("2018", (java.lang.Class) wildcardClass43);
        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long21, (java.lang.Class) wildcardClass43);
        timeSeries53.setMaximumItemAge(0L);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str29.equals("SerialDate.weekInMonthToString(): invalid code."));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1577865599999L + "'", long31 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 2019L + "'", long32 == 2019L);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertNull(regularTimePeriod46);
        org.junit.Assert.assertNotNull(classLoader47);
        org.junit.Assert.assertNull(uRL52);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.clear();
        java.lang.Class class9 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class9);
        timeSeries10.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries10.addPropertyChangeListener(propertyChangeListener12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries10.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.util.Date date17 = fixedMillisecond15.getEnd();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        long long19 = year18.getLastMillisecond();
        boolean boolean20 = fixedMillisecond15.equals((java.lang.Object) year18);
        int int22 = fixedMillisecond15.compareTo((java.lang.Object) 1577865599999L);
        java.lang.Number number23 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.util.Calendar calendar24 = null;
        long long25 = fixedMillisecond15.getMiddleMillisecond(calendar24);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1577865599999L + "'", long19 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNull(number23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str5 = timeSeries2.getDescription();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getLastMillisecond();
        long long8 = year6.getSerialIndex();
        int int9 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) year6);
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class17);
        java.lang.Class<?> wildcardClass19 = timeSeries18.getClass();
        java.util.Date date20 = null;
        java.util.TimeZone timeZone21 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date20, timeZone21);
        java.lang.ClassLoader classLoader23 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass19);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2, (java.lang.Class) wildcardClass19);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, "ThreadContext", "org.jfree.data.general.SeriesException: ", (java.lang.Class) wildcardClass19);
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year6, "Following", "Fourth", (java.lang.Class) wildcardClass19);
        java.util.Calendar calendar27 = null;
        try {
            long long28 = year6.getFirstMillisecond(calendar27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str5.equals("SerialDate.weekInMonthToString(): invalid code."));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(classLoader23);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-460), "October", "2019", class3);
        try {
            timeSeries4.removeAgedItems(4L, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries2.setDomainDescription("");
        java.lang.Class class7 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class12);
        timeSeries13.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        int int22 = year20.compareTo((java.lang.Object) "");
        long long23 = year20.getFirstMillisecond();
        int int24 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) year20);
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class28);
        timeSeries29.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timeSeries29.addPropertyChangeListener(propertyChangeListener31);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
        java.util.Date date36 = fixedMillisecond34.getEnd();
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date36);
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) year20, (org.jfree.data.time.RegularTimePeriod) day37);
        long long39 = day37.getFirstMillisecond();
        boolean boolean41 = day37.equals((java.lang.Object) 1577865599999L);
        long long42 = day37.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = day37.next();
        java.util.Calendar calendar44 = null;
        try {
            day37.peg(calendar44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1546329600000L + "'", long23 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeSeries38);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-57600000L) + "'", long39 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 25568L + "'", long42 == 25568L);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        java.util.Date date11 = fixedMillisecond9.getEnd();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getLastMillisecond();
        boolean boolean14 = fixedMillisecond9.equals((java.lang.Object) year12);
        int int16 = fixedMillisecond9.compareTo((java.lang.Object) 1577865599999L);
        long long17 = fixedMillisecond9.getSerialIndex();
        java.util.Calendar calendar18 = null;
        long long19 = fixedMillisecond9.getMiddleMillisecond(calendar18);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        int int4 = month3.getYearValue();
        java.lang.String str5 = month3.toString();
        int int6 = month3.getMonth();
        long long7 = month3.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "January 2019" + "'", str5.equals("January 2019"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1549007999999L + "'", long7 == 1549007999999L);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond9.previous();
        java.lang.Number number11 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, number11);
        java.util.List list13 = timeSeries4.getItems();
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class15);
        timeSeries16.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries16.setDomainDescription("");
        java.lang.Class class21 = timeSeries16.getTimePeriodClass();
        timeSeries16.clear();
        java.lang.Class class26 = null;
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class26);
        timeSeries27.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timeSeries27.addPropertyChangeListener(propertyChangeListener29);
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries27.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        int int36 = year34.compareTo((java.lang.Object) "");
        long long37 = year34.getFirstMillisecond();
        int int38 = timeSeries27.getIndex((org.jfree.data.time.RegularTimePeriod) year34);
        java.lang.Class class42 = null;
        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class42);
        timeSeries43.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener45 = null;
        timeSeries43.addPropertyChangeListener(propertyChangeListener45);
        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries43.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond48);
        java.util.Date date50 = fixedMillisecond48.getEnd();
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date50);
        org.jfree.data.time.TimeSeries timeSeries52 = timeSeries16.createCopy((org.jfree.data.time.RegularTimePeriod) year34, (org.jfree.data.time.RegularTimePeriod) day51);
        java.lang.Class class55 = null;
        org.jfree.data.time.TimeSeries timeSeries56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class55);
        java.lang.Class<?> wildcardClass57 = timeSeries56.getClass();
        java.util.Date date58 = null;
        java.util.TimeZone timeZone59 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass57, date58, timeZone59);
        java.lang.ClassLoader classLoader61 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass57);
        org.jfree.data.time.TimeSeries timeSeries62 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2, (java.lang.Class) wildcardClass57);
        org.jfree.data.time.TimeSeries timeSeries63 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day51, (java.lang.Class) wildcardClass57);
        timeSeries4.update((org.jfree.data.time.RegularTimePeriod) day51, (java.lang.Number) 11);
        java.lang.Class class66 = null;
        java.lang.Class class70 = null;
        org.jfree.data.time.TimeSeries timeSeries71 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class70);
        timeSeries71.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener73 = null;
        timeSeries71.addPropertyChangeListener(propertyChangeListener73);
        org.jfree.data.time.FixedMillisecond fixedMillisecond76 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem77 = timeSeries71.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond76);
        java.util.Date date78 = fixedMillisecond76.getEnd();
        java.util.TimeZone timeZone79 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = org.jfree.data.time.RegularTimePeriod.createInstance(class66, date78, timeZone79);
        org.jfree.data.time.Day day81 = new org.jfree.data.time.Day(date78);
        org.jfree.data.time.Day day82 = new org.jfree.data.time.Day(date78);
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day82);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNull(class21);
        org.junit.Assert.assertNull(timeSeriesDataItem33);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1546329600000L + "'", long37 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem49);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertNotNull(timeSeries52);
        org.junit.Assert.assertNotNull(wildcardClass57);
        org.junit.Assert.assertNull(regularTimePeriod60);
        org.junit.Assert.assertNotNull(classLoader61);
        org.junit.Assert.assertNull(timeSeriesDataItem77);
        org.junit.Assert.assertNotNull(date78);
        org.junit.Assert.assertNull(regularTimePeriod80);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(100, 1, (-452));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-460), "October", "2019", class3);
        int int5 = timeSeries4.getItemCount();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        timeSeries4.clear();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getLastMillisecond();
        java.util.Date date11 = year9.getStart();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(date11);
        int int13 = month12.getMonth();
        int int14 = month12.getYearValue();
        java.lang.String str15 = month12.toString();
        int int16 = month12.getMonth();
        try {
            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) month12, 11.0d, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "January 2019" + "'", str15.equals("January 2019"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str5 = timeSeries2.getDescription();
        timeSeries2.setDescription("2019");
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        long long9 = year8.getLastMillisecond();
        java.util.Date date10 = year8.getStart();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
        java.lang.String str12 = month11.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month11.next();
        timeSeries2.setKey((java.lang.Comparable) month11);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        int int16 = month15.getMonth();
        long long17 = month15.getMiddleMillisecond();
        org.jfree.data.time.Year year18 = month15.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = month15.previous();
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) month15);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str5.equals("SerialDate.weekInMonthToString(): invalid code."));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "January 2019" + "'", str12.equals("January 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560668399999L + "'", long17 == 1560668399999L);
        org.junit.Assert.assertNotNull(year18);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setNotify(true);
        java.lang.Class class5 = null;
        java.lang.Class class9 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class9);
        timeSeries10.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries10.addPropertyChangeListener(propertyChangeListener12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries10.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.util.Date date17 = fixedMillisecond15.getEnd();
        java.util.TimeZone timeZone18 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date17, timeZone18);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date17);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) day20);
        java.lang.String str22 = day20.toString();
        java.util.Calendar calendar23 = null;
        try {
            day20.peg(calendar23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "31-December-1969" + "'", str22.equals("31-December-1969"));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class8);
        timeSeries9.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries9.addPropertyChangeListener(propertyChangeListener11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
        java.util.Date date16 = fixedMillisecond14.getEnd();
        java.util.Date date17 = fixedMillisecond14.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (double) 2958465);
        java.util.Calendar calendar20 = null;
        fixedMillisecond14.peg(calendar20);
        java.util.Date date22 = fixedMillisecond14.getTime();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
        java.lang.String str24 = day23.toString();
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "31-December-1969" + "'", str24.equals("31-December-1969"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond9.previous();
        java.lang.Number number11 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, number11);
        try {
            java.lang.Class<?> wildcardClass13 = timeSeriesDataItem12.getClass();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class8);
        timeSeries9.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries9.addPropertyChangeListener(propertyChangeListener11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
        java.util.Date date16 = fixedMillisecond14.getEnd();
        java.util.Date date17 = fixedMillisecond14.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (double) 2958465);
        java.util.Calendar calendar20 = null;
        fixedMillisecond14.peg(calendar20);
        java.util.Date date22 = fixedMillisecond14.getTime();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
        int int24 = day23.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day23.next();
        long long26 = day23.getLastMillisecond();
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 12 + "'", int24 == 12);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 28799999L + "'", long26 == 28799999L);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str5 = timeSeries2.getDescription();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getLastMillisecond();
        long long8 = year6.getSerialIndex();
        int int9 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) year6);
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class17);
        java.lang.Class<?> wildcardClass19 = timeSeries18.getClass();
        java.util.Date date20 = null;
        java.util.TimeZone timeZone21 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date20, timeZone21);
        java.lang.ClassLoader classLoader23 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass19);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2, (java.lang.Class) wildcardClass19);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, "ThreadContext", "org.jfree.data.general.SeriesException: ", (java.lang.Class) wildcardClass19);
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year6, "Following", "Fourth", (java.lang.Class) wildcardClass19);
        java.lang.Class class30 = null;
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class30);
        timeSeries31.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener33 = null;
        timeSeries31.addPropertyChangeListener(propertyChangeListener33);
        boolean boolean35 = timeSeries31.isEmpty();
        boolean boolean36 = timeSeries31.isEmpty();
        java.util.Collection collection37 = timeSeries26.getTimePeriodsUniqueToOtherSeries(timeSeries31);
        java.lang.Class class39 = null;
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class39);
        java.lang.String str41 = timeSeries40.getRangeDescription();
        timeSeries40.setNotify(true);
        java.util.Collection collection44 = timeSeries26.getTimePeriodsUniqueToOtherSeries(timeSeries40);
        timeSeries40.setNotify(false);
        java.lang.Class class50 = null;
        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class50);
        java.lang.Class class55 = null;
        org.jfree.data.time.TimeSeries timeSeries56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class55);
        timeSeries56.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener58 = null;
        timeSeries56.addPropertyChangeListener(propertyChangeListener58);
        org.jfree.data.time.FixedMillisecond fixedMillisecond61 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem62 = timeSeries56.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond61);
        java.util.Date date63 = fixedMillisecond61.getEnd();
        java.util.Date date64 = fixedMillisecond61.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem66 = timeSeries51.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond61, (double) 2958465);
        java.util.Calendar calendar67 = null;
        fixedMillisecond61.peg(calendar67);
        org.jfree.data.time.Year year70 = org.jfree.data.time.Year.parseYear("2018");
        org.jfree.data.time.FixedMillisecond fixedMillisecond71 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date72 = fixedMillisecond71.getTime();
        boolean boolean73 = year70.equals((java.lang.Object) fixedMillisecond71);
        int int74 = fixedMillisecond61.compareTo((java.lang.Object) fixedMillisecond71);
        try {
            timeSeries40.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond71, (double) 9, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str5.equals("SerialDate.weekInMonthToString(): invalid code."));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(classLoader23);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(collection37);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "Value" + "'", str41.equals("Value"));
        org.junit.Assert.assertNotNull(collection44);
        org.junit.Assert.assertNull(timeSeriesDataItem62);
        org.junit.Assert.assertNotNull(date63);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertNull(timeSeriesDataItem66);
        org.junit.Assert.assertNotNull(year70);
        org.junit.Assert.assertNotNull(date72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + (-1) + "'", int74 == (-1));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries2.setDomainDescription("");
        java.lang.String str7 = timeSeries2.getDomainDescription();
        java.lang.Comparable comparable8 = timeSeries2.getKey();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class12);
        timeSeries13.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (short) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = fixedMillisecond18.previous();
        java.lang.Number number20 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, number20);
        java.util.List list22 = timeSeries13.getItems();
        java.lang.Class class24 = null;
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class24);
        timeSeries25.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries25.setDomainDescription("");
        java.lang.Class class30 = timeSeries25.getTimePeriodClass();
        timeSeries25.clear();
        java.lang.Class class35 = null;
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class35);
        timeSeries36.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener38 = null;
        timeSeries36.addPropertyChangeListener(propertyChangeListener38);
        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries36.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond41);
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year();
        int int45 = year43.compareTo((java.lang.Object) "");
        long long46 = year43.getFirstMillisecond();
        int int47 = timeSeries36.getIndex((org.jfree.data.time.RegularTimePeriod) year43);
        java.lang.Class class51 = null;
        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class51);
        timeSeries52.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener54 = null;
        timeSeries52.addPropertyChangeListener(propertyChangeListener54);
        org.jfree.data.time.FixedMillisecond fixedMillisecond57 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem58 = timeSeries52.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond57);
        java.util.Date date59 = fixedMillisecond57.getEnd();
        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day(date59);
        org.jfree.data.time.TimeSeries timeSeries61 = timeSeries25.createCopy((org.jfree.data.time.RegularTimePeriod) year43, (org.jfree.data.time.RegularTimePeriod) day60);
        java.lang.Class class64 = null;
        org.jfree.data.time.TimeSeries timeSeries65 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class64);
        java.lang.Class<?> wildcardClass66 = timeSeries65.getClass();
        java.util.Date date67 = null;
        java.util.TimeZone timeZone68 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass66, date67, timeZone68);
        java.lang.ClassLoader classLoader70 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass66);
        org.jfree.data.time.TimeSeries timeSeries71 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2, (java.lang.Class) wildcardClass66);
        org.jfree.data.time.TimeSeries timeSeries72 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day60, (java.lang.Class) wildcardClass66);
        timeSeries13.update((org.jfree.data.time.RegularTimePeriod) day60, (java.lang.Number) 11);
        org.jfree.data.time.Year year75 = new org.jfree.data.time.Year();
        long long76 = year75.getLastMillisecond();
        timeSeries13.setKey((java.lang.Comparable) year75);
        int int78 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) year75);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + '4' + "'", comparable8.equals('4'));
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertNotNull(list22);
        org.junit.Assert.assertNull(class30);
        org.junit.Assert.assertNull(timeSeriesDataItem42);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1546329600000L + "'", long46 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem58);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertNotNull(timeSeries61);
        org.junit.Assert.assertNotNull(wildcardClass66);
        org.junit.Assert.assertNull(regularTimePeriod69);
        org.junit.Assert.assertNotNull(classLoader70);
        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 1577865599999L + "'", long76 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + (-1) + "'", int78 == (-1));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        int int4 = month3.getMonth();
        int int5 = month3.getYearValue();
        java.lang.String str6 = month3.toString();
        java.lang.String str7 = month3.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "January 2019" + "'", str6.equals("January 2019"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "January 2019" + "'", str7.equals("January 2019"));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries2.setDomainDescription("");
        java.lang.Class class7 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class12);
        timeSeries13.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        int int22 = year20.compareTo((java.lang.Object) "");
        long long23 = year20.getFirstMillisecond();
        int int24 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) year20);
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class28);
        timeSeries29.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timeSeries29.addPropertyChangeListener(propertyChangeListener31);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
        java.util.Date date36 = fixedMillisecond34.getEnd();
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date36);
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) year20, (org.jfree.data.time.RegularTimePeriod) day37);
        java.lang.Class class41 = null;
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class41);
        java.lang.Class<?> wildcardClass43 = timeSeries42.getClass();
        java.util.Date date44 = null;
        java.util.TimeZone timeZone45 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass43, date44, timeZone45);
        java.lang.ClassLoader classLoader47 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass43);
        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2, (java.lang.Class) wildcardClass43);
        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day37, (java.lang.Class) wildcardClass43);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day37, (double) 24234L);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1546329600000L + "'", long23 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeSeries38);
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertNull(regularTimePeriod46);
        org.junit.Assert.assertNotNull(classLoader47);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str5 = timeSeries2.getDescription();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getLastMillisecond();
        long long8 = year6.getSerialIndex();
        int int9 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) year6);
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class13);
        timeSeries14.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries14.addPropertyChangeListener(propertyChangeListener16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries14.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
        java.util.Date date21 = fixedMillisecond19.getEnd();
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date21);
        long long23 = day22.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) day22);
        int int25 = day22.getMonth();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str5.equals("SerialDate.weekInMonthToString(): invalid code."));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 25568L + "'", long23 == 25568L);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 12 + "'", int25 == 12);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries2.setDomainDescription("");
        java.lang.Class class7 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class12);
        timeSeries13.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        int int22 = year20.compareTo((java.lang.Object) "");
        long long23 = year20.getFirstMillisecond();
        int int24 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) year20);
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class28);
        timeSeries29.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timeSeries29.addPropertyChangeListener(propertyChangeListener31);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
        java.util.Date date36 = fixedMillisecond34.getEnd();
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date36);
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) year20, (org.jfree.data.time.RegularTimePeriod) day37);
        org.jfree.data.time.SerialDate serialDate39 = day37.getSerialDate();
        java.util.Date date40 = day37.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day37, (java.lang.Number) 1900);
        java.lang.Class class44 = null;
        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class44);
        timeSeries45.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str48 = timeSeries45.getDescription();
        timeSeries45.setMaximumItemAge((long) 11);
        java.beans.PropertyChangeListener propertyChangeListener51 = null;
        timeSeries45.removePropertyChangeListener(propertyChangeListener51);
        boolean boolean53 = timeSeriesDataItem42.equals((java.lang.Object) propertyChangeListener51);
        java.lang.Class class57 = null;
        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class57);
        timeSeries58.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener60 = null;
        timeSeries58.addPropertyChangeListener(propertyChangeListener60);
        org.jfree.data.time.FixedMillisecond fixedMillisecond63 = new org.jfree.data.time.FixedMillisecond((long) (short) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = fixedMillisecond63.previous();
        java.lang.Number number65 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem66 = timeSeries58.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond63, number65);
        java.util.List list67 = timeSeries58.getItems();
        int int68 = timeSeriesDataItem42.compareTo((java.lang.Object) timeSeries58);
        java.lang.Object obj69 = timeSeriesDataItem42.clone();
        java.lang.Object obj70 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) timeSeriesDataItem42);
        java.lang.Class class72 = null;
        org.jfree.data.time.TimeSeries timeSeries73 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class72);
        timeSeries73.setNotify(true);
        int int76 = timeSeriesDataItem42.compareTo((java.lang.Object) timeSeries73);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener77 = null;
        timeSeries73.removeChangeListener(seriesChangeListener77);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener79 = null;
        timeSeries73.addChangeListener(seriesChangeListener79);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1546329600000L + "'", long23 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeSeries38);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str48.equals("SerialDate.weekInMonthToString(): invalid code."));
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod64);
        org.junit.Assert.assertNull(timeSeriesDataItem66);
        org.junit.Assert.assertNotNull(list67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 1 + "'", int68 == 1);
        org.junit.Assert.assertNotNull(obj69);
        org.junit.Assert.assertNotNull(obj70);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 1 + "'", int76 == 1);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.next();
        java.util.Date date4 = year0.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date6 = fixedMillisecond5.getTime();
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date6, timeZone7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date4, timeZone7);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(serialDate10);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        java.lang.Class class0 = null;
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class4);
        timeSeries5.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries5.addPropertyChangeListener(propertyChangeListener7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries5.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
        java.util.Date date12 = fixedMillisecond10.getEnd();
        java.util.TimeZone timeZone13 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date12, timeZone13);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date12);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond(date12);
        java.util.Date date18 = fixedMillisecond17.getStart();
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date18);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        int int13 = year11.compareTo((java.lang.Object) "");
        long long14 = year11.getFirstMillisecond();
        int int15 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) year11);
        timeSeries4.setDomainDescription("org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries4.createCopy((int) (byte) 10, (int) '#');
        try {
            timeSeries20.update(1969, (java.lang.Number) 10.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1969, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(timeSeries20);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class2);
        java.lang.Class<?> wildcardClass4 = timeSeries3.getClass();
        java.util.Date date5 = null;
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date5, timeZone6);
        java.lang.ClassLoader classLoader8 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2, (java.lang.Class) wildcardClass4);
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class13);
        timeSeries14.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries14.addPropertyChangeListener(propertyChangeListener16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries14.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
        java.util.Date date21 = fixedMillisecond19.getEnd();
        java.util.Date date22 = fixedMillisecond19.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (java.lang.Number) 2019);
        long long25 = fixedMillisecond19.getSerialIndex();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(classLoader8);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries2.setDomainDescription("");
        java.lang.Class class7 = timeSeries2.getTimePeriodClass();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries2.removeChangeListener(seriesChangeListener8);
        int int10 = timeSeries2.getItemCount();
        timeSeries2.fireSeriesChanged();
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class5);
        timeSeries6.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str9 = timeSeries6.getDescription();
        timeSeries6.setDescription("2019");
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getLastMillisecond();
        java.util.Date date14 = year12.getStart();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        java.lang.String str16 = month15.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month15.next();
        timeSeries6.setKey((java.lang.Comparable) month15);
        boolean boolean19 = fixedMillisecond1.equals((java.lang.Object) timeSeries6);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str9.equals("SerialDate.weekInMonthToString(): invalid code."));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "January 2019" + "'", str16.equals("January 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        java.lang.Class<?> wildcardClass3 = timeSeries2.getClass();
        java.util.Date date4 = null;
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date4, timeZone5);
        java.lang.ClassLoader classLoader7 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass3);
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) classLoader7);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(classLoader7);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.lang.String str2 = month0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.previous();
        int int4 = month0.getMonth();
        org.jfree.data.time.Year year5 = month0.getYear();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "June 2019" + "'", str2.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertNotNull(year5);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(9, (int) (byte) -1, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries2.setDomainDescription("");
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries2.addPropertyChangeListener(propertyChangeListener7);
        boolean boolean9 = timeSeries2.getNotify();
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries2.addPropertyChangeListener(propertyChangeListener10);
        timeSeries2.clear();
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class14);
        timeSeries15.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str18 = timeSeries15.getDescription();
        java.util.Collection collection19 = timeSeries2.getTimePeriodsUniqueToOtherSeries(timeSeries15);
        java.lang.Class class22 = null;
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class22);
        java.lang.Class<?> wildcardClass24 = timeSeries23.getClass();
        java.util.Date date25 = null;
        java.util.TimeZone timeZone26 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date25, timeZone26);
        java.lang.ClassLoader classLoader28 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass24);
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2, (java.lang.Class) wildcardClass24);
        java.lang.Class class33 = null;
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class33);
        timeSeries34.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener36 = null;
        timeSeries34.addPropertyChangeListener(propertyChangeListener36);
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries34.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39);
        java.util.Date date41 = fixedMillisecond39.getEnd();
        java.util.Date date42 = fixedMillisecond39.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries29.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (java.lang.Number) 2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = fixedMillisecond39.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod45, (double) 11);
        java.lang.Object obj48 = timeSeriesDataItem47.clone();
        try {
            timeSeries2.add(timeSeriesDataItem47, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str18.equals("SerialDate.weekInMonthToString(): invalid code."));
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(classLoader28);
        org.junit.Assert.assertNull(timeSeriesDataItem40);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNull(timeSeriesDataItem44);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(obj48);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        timeSeries1.setDescription("2019");
        java.lang.Class class7 = null;
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-460), "October", "2019", class7);
        int int9 = timeSeries8.getItemCount();
        java.lang.String str10 = timeSeries8.getDescription();
        boolean boolean11 = timeSeries1.equals((java.lang.Object) timeSeries8);
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener12);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        long long2 = year0.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1562097599999L + "'", long2 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond9.previous();
        java.lang.Number number11 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, number11);
        java.util.List list13 = timeSeries4.getItems();
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class15);
        timeSeries16.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries16.setDomainDescription("");
        java.lang.Class class21 = timeSeries16.getTimePeriodClass();
        timeSeries16.clear();
        java.lang.Class class26 = null;
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class26);
        timeSeries27.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timeSeries27.addPropertyChangeListener(propertyChangeListener29);
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries27.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        int int36 = year34.compareTo((java.lang.Object) "");
        long long37 = year34.getFirstMillisecond();
        int int38 = timeSeries27.getIndex((org.jfree.data.time.RegularTimePeriod) year34);
        java.lang.Class class42 = null;
        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class42);
        timeSeries43.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener45 = null;
        timeSeries43.addPropertyChangeListener(propertyChangeListener45);
        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries43.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond48);
        java.util.Date date50 = fixedMillisecond48.getEnd();
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date50);
        org.jfree.data.time.TimeSeries timeSeries52 = timeSeries16.createCopy((org.jfree.data.time.RegularTimePeriod) year34, (org.jfree.data.time.RegularTimePeriod) day51);
        java.lang.Class class55 = null;
        org.jfree.data.time.TimeSeries timeSeries56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class55);
        java.lang.Class<?> wildcardClass57 = timeSeries56.getClass();
        java.util.Date date58 = null;
        java.util.TimeZone timeZone59 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass57, date58, timeZone59);
        java.lang.ClassLoader classLoader61 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass57);
        org.jfree.data.time.TimeSeries timeSeries62 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2, (java.lang.Class) wildcardClass57);
        org.jfree.data.time.TimeSeries timeSeries63 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day51, (java.lang.Class) wildcardClass57);
        timeSeries4.update((org.jfree.data.time.RegularTimePeriod) day51, (java.lang.Number) 11);
        int int66 = day51.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem68 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day51, (java.lang.Number) (byte) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = timeSeriesDataItem68.getPeriod();
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNull(class21);
        org.junit.Assert.assertNull(timeSeriesDataItem33);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1546329600000L + "'", long37 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem49);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertNotNull(timeSeries52);
        org.junit.Assert.assertNotNull(wildcardClass57);
        org.junit.Assert.assertNull(regularTimePeriod60);
        org.junit.Assert.assertNotNull(classLoader61);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 12 + "'", int66 == 12);
        org.junit.Assert.assertNotNull(regularTimePeriod69);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries2.setDomainDescription("");
        java.lang.Class class7 = timeSeries2.getTimePeriodClass();
        long long8 = timeSeries2.getMaximumItemAge();
        boolean boolean9 = timeSeries2.isEmpty();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getLastMillisecond();
        java.util.Date date12 = year10.getStart();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date12);
        int int14 = month13.getMonth();
        int int15 = month13.getYearValue();
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class17);
        timeSeries18.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries18.setDomainDescription("");
        java.lang.Class class23 = timeSeries18.getTimePeriodClass();
        timeSeries18.clear();
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class28);
        timeSeries29.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timeSeries29.addPropertyChangeListener(propertyChangeListener31);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        int int38 = year36.compareTo((java.lang.Object) "");
        long long39 = year36.getFirstMillisecond();
        int int40 = timeSeries29.getIndex((org.jfree.data.time.RegularTimePeriod) year36);
        java.lang.Class class44 = null;
        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class44);
        timeSeries45.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener47 = null;
        timeSeries45.addPropertyChangeListener(propertyChangeListener47);
        org.jfree.data.time.FixedMillisecond fixedMillisecond50 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = timeSeries45.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond50);
        java.util.Date date52 = fixedMillisecond50.getEnd();
        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day(date52);
        org.jfree.data.time.TimeSeries timeSeries54 = timeSeries18.createCopy((org.jfree.data.time.RegularTimePeriod) year36, (org.jfree.data.time.RegularTimePeriod) day53);
        org.jfree.data.time.SerialDate serialDate55 = day53.getSerialDate();
        java.util.Date date56 = day53.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem58 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day53, (java.lang.Number) 1900);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = timeSeriesDataItem58.getPeriod();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem61 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod59, (double) 2958465);
        java.lang.Object obj62 = null;
        int int63 = timeSeriesDataItem61.compareTo(obj62);
        boolean boolean64 = month13.equals((java.lang.Object) timeSeriesDataItem61);
        try {
            timeSeries2.add(timeSeriesDataItem61);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9223372036854775807L + "'", long8 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertNull(class23);
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1546329600000L + "'", long39 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem51);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertNotNull(timeSeries54);
        org.junit.Assert.assertNotNull(serialDate55);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertNotNull(regularTimePeriod59);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        int int13 = year11.compareTo((java.lang.Object) "");
        long long14 = year11.getFirstMillisecond();
        int int15 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) year11);
        java.lang.String str16 = timeSeries4.getDescription();
        java.lang.String str17 = timeSeries4.getRangeDescription();
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        int int4 = month3.getYearValue();
        org.jfree.data.time.Year year5 = month3.getYear();
        java.lang.String str6 = year5.toString();
        long long7 = year5.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries2.setDomainDescription("");
        java.lang.Class class7 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class12);
        timeSeries13.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        int int22 = year20.compareTo((java.lang.Object) "");
        long long23 = year20.getFirstMillisecond();
        int int24 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) year20);
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class28);
        timeSeries29.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timeSeries29.addPropertyChangeListener(propertyChangeListener31);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
        java.util.Date date36 = fixedMillisecond34.getEnd();
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date36);
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) year20, (org.jfree.data.time.RegularTimePeriod) day37);
        org.jfree.data.time.SerialDate serialDate39 = day37.getSerialDate();
        java.util.Date date40 = day37.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day37, (java.lang.Number) 1900);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = timeSeriesDataItem42.getPeriod();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod43, (double) 2958465);
        java.lang.Object obj46 = timeSeriesDataItem45.clone();
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1546329600000L + "'", long23 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeSeries38);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertNotNull(obj46);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        long long11 = fixedMillisecond9.getFirstMillisecond();
        java.util.Calendar calendar12 = null;
        long long13 = fixedMillisecond9.getFirstMillisecond(calendar12);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class4);
        java.lang.Class<?> wildcardClass6 = timeSeries5.getClass();
        java.util.Date date7 = null;
        java.util.TimeZone timeZone8 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date7, timeZone8);
        java.lang.ClassLoader classLoader10 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass6);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2, (java.lang.Class) wildcardClass6);
        java.lang.ClassLoader classLoader12 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass6);
        java.net.URL uRL13 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("August", (java.lang.Class) wildcardClass6);
        java.io.InputStream inputStream14 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", (java.lang.Class) wildcardClass6);
        java.lang.ClassLoader classLoader15 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(classLoader10);
        org.junit.Assert.assertNotNull(classLoader12);
        org.junit.Assert.assertNull(uRL13);
        org.junit.Assert.assertNotNull(inputStream14);
        org.junit.Assert.assertNotNull(classLoader15);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class8);
        timeSeries9.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries9.addPropertyChangeListener(propertyChangeListener11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
        java.util.Date date16 = fixedMillisecond14.getEnd();
        java.util.Date date17 = fixedMillisecond14.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (double) 2958465);
        java.util.Calendar calendar20 = null;
        fixedMillisecond14.peg(calendar20);
        java.util.Date date22 = fixedMillisecond14.getTime();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
        int int24 = day23.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day23.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = day23.previous();
        java.lang.String str27 = day23.toString();
        long long28 = day23.getSerialIndex();
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 12 + "'", int24 == 12);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "31-December-1969" + "'", str27.equals("31-December-1969"));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 25568L + "'", long28 == 25568L);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        java.util.Date date11 = fixedMillisecond9.getEnd();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getLastMillisecond();
        boolean boolean14 = fixedMillisecond9.equals((java.lang.Object) year12);
        long long15 = fixedMillisecond9.getSerialIndex();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) (short) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = fixedMillisecond17.previous();
        boolean boolean19 = fixedMillisecond9.equals((java.lang.Object) regularTimePeriod18);
        java.util.Calendar calendar20 = null;
        long long21 = fixedMillisecond9.getLastMillisecond(calendar20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (java.lang.Number) 1.0d);
        try {
            java.lang.Object obj24 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) fixedMillisecond9);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class8);
        timeSeries9.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries9.addPropertyChangeListener(propertyChangeListener11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
        java.util.Date date16 = fixedMillisecond14.getEnd();
        java.util.Date date17 = fixedMillisecond14.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (double) 2958465);
        java.util.Calendar calendar20 = null;
        fixedMillisecond14.peg(calendar20);
        java.util.Date date22 = fixedMillisecond14.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (java.lang.Number) 10L);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(date22);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries2.setDomainDescription("");
        java.lang.Class class7 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class12);
        timeSeries13.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        int int22 = year20.compareTo((java.lang.Object) "");
        long long23 = year20.getFirstMillisecond();
        int int24 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) year20);
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class28);
        timeSeries29.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timeSeries29.addPropertyChangeListener(propertyChangeListener31);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
        java.util.Date date36 = fixedMillisecond34.getEnd();
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date36);
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) year20, (org.jfree.data.time.RegularTimePeriod) day37);
        org.jfree.data.time.SerialDate serialDate39 = day37.getSerialDate();
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(serialDate39);
        long long41 = day40.getSerialIndex();
        int int42 = day40.getYear();
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1546329600000L + "'", long23 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeSeries38);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 25568L + "'", long41 == 25568L);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1969 + "'", int42 == 1969);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        int int13 = year11.compareTo((java.lang.Object) "");
        long long14 = year11.getFirstMillisecond();
        int int15 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) year11);
        java.lang.String str16 = timeSeries4.getDomainDescription();
        timeSeries4.setMaximumItemCount((int) (byte) 10);
        timeSeries4.setDomainDescription("31-December-1969");
        java.lang.Class class24 = null;
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class24);
        timeSeries25.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener27 = null;
        timeSeries25.addPropertyChangeListener(propertyChangeListener27);
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries25.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30);
        java.util.Date date32 = fixedMillisecond30.getEnd();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        long long34 = year33.getLastMillisecond();
        boolean boolean35 = fixedMillisecond30.equals((java.lang.Object) year33);
        int int37 = fixedMillisecond30.compareTo((java.lang.Object) 1577865599999L);
        java.util.Calendar calendar38 = null;
        long long39 = fixedMillisecond30.getFirstMillisecond(calendar38);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = fixedMillisecond30.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond((long) (short) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = fixedMillisecond42.previous();
        java.util.Calendar calendar44 = null;
        long long45 = fixedMillisecond42.getMiddleMillisecond(calendar44);
        org.jfree.data.time.TimeSeries timeSeries46 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond42);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond42, (java.lang.Number) 1560668399999L);
        java.lang.Class class50 = null;
        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class50);
        timeSeries51.removeAgedItems(false);
        boolean boolean55 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) timeSeries51, (java.lang.Object) 1900);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener56 = null;
        timeSeries51.addChangeListener(seriesChangeListener56);
        boolean boolean58 = timeSeriesDataItem48.equals((java.lang.Object) timeSeries51);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertNull(timeSeriesDataItem31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1577865599999L + "'", long34 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1L + "'", long45 == 1L);
        org.junit.Assert.assertNotNull(timeSeries46);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries2.setDomainDescription("");
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries2.addPropertyChangeListener(propertyChangeListener7);
        boolean boolean9 = timeSeries2.getNotify();
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries2.addPropertyChangeListener(propertyChangeListener10);
        timeSeries2.clear();
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class16);
        java.lang.Class class21 = null;
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class21);
        timeSeries22.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timeSeries22.addPropertyChangeListener(propertyChangeListener24);
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries22.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
        java.util.Date date29 = fixedMillisecond27.getEnd();
        java.util.Date date30 = fixedMillisecond27.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries17.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, (double) 2958465);
        java.util.Calendar calendar33 = null;
        fixedMillisecond27.peg(calendar33);
        java.util.Date date35 = fixedMillisecond27.getTime();
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date35);
        int int37 = day36.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = day36.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = day36.previous();
        try {
            timeSeries2.add((org.jfree.data.time.RegularTimePeriod) day36, (java.lang.Number) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(timeSeriesDataItem28);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNull(timeSeriesDataItem32);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 12 + "'", int37 == 12);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("ClassContext");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.String str3 = timePeriodFormatException1.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: ClassContext" + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: ClassContext"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond9.previous();
        java.lang.Number number11 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, number11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeries4.getNextTimePeriod();
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        int int13 = year11.compareTo((java.lang.Object) "");
        long long14 = year11.getFirstMillisecond();
        int int15 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) year11);
        java.lang.String str16 = timeSeries4.getDomainDescription();
        timeSeries4.setMaximumItemCount((int) (byte) 10);
        long long19 = timeSeries4.getMaximumItemAge();
        timeSeries4.setMaximumItemAge(1L);
        java.util.Collection collection22 = timeSeries4.getTimePeriods();
        java.lang.String str23 = timeSeries4.getRangeDescription();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        long long25 = year24.getLastMillisecond();
        try {
            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) year24, (java.lang.Number) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 9223372036854775807L + "'", long19 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "" + "'", str23.equals(""));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1577865599999L + "'", long25 == 1577865599999L);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        java.lang.Class class0 = null;
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class4);
        timeSeries5.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries5.addPropertyChangeListener(propertyChangeListener7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries5.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
        java.util.Date date12 = fixedMillisecond10.getEnd();
        java.util.TimeZone timeZone13 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date12, timeZone13);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(date12);
        long long16 = fixedMillisecond15.getFirstMillisecond();
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries2.setDomainDescription("");
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries2.addPropertyChangeListener(propertyChangeListener7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timeSeries2.removeChangeListener(seriesChangeListener9);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        int int13 = year11.compareTo((java.lang.Object) "");
        long long14 = year11.getFirstMillisecond();
        int int15 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) year11);
        java.lang.String str16 = timeSeries4.getDomainDescription();
        timeSeries4.setMaximumItemCount((int) (byte) 10);
        long long19 = timeSeries4.getMaximumItemAge();
        java.lang.String str20 = timeSeries4.getDomainDescription();
        try {
            java.lang.Number number22 = timeSeries4.getValue(31);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 31, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 9223372036854775807L + "'", long19 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hi!" + "'", str20.equals("hi!"));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.removeAgedItems(false);
        boolean boolean6 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) timeSeries2, (java.lang.Object) 1900);
        java.lang.String str7 = timeSeries2.getDescription();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class11);
        timeSeries12.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries12.addPropertyChangeListener(propertyChangeListener14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) (short) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = fixedMillisecond17.previous();
        java.lang.Number number19 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, number19);
        java.util.List list21 = timeSeries12.getItems();
        java.lang.Class class23 = null;
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class23);
        timeSeries24.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries24.setDomainDescription("");
        java.lang.Class class29 = timeSeries24.getTimePeriodClass();
        timeSeries24.clear();
        java.lang.Class class34 = null;
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class34);
        timeSeries35.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener37 = null;
        timeSeries35.addPropertyChangeListener(propertyChangeListener37);
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries35.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40);
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
        int int44 = year42.compareTo((java.lang.Object) "");
        long long45 = year42.getFirstMillisecond();
        int int46 = timeSeries35.getIndex((org.jfree.data.time.RegularTimePeriod) year42);
        java.lang.Class class50 = null;
        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class50);
        timeSeries51.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener53 = null;
        timeSeries51.addPropertyChangeListener(propertyChangeListener53);
        org.jfree.data.time.FixedMillisecond fixedMillisecond56 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem57 = timeSeries51.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond56);
        java.util.Date date58 = fixedMillisecond56.getEnd();
        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day(date58);
        org.jfree.data.time.TimeSeries timeSeries60 = timeSeries24.createCopy((org.jfree.data.time.RegularTimePeriod) year42, (org.jfree.data.time.RegularTimePeriod) day59);
        java.lang.Class class63 = null;
        org.jfree.data.time.TimeSeries timeSeries64 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class63);
        java.lang.Class<?> wildcardClass65 = timeSeries64.getClass();
        java.util.Date date66 = null;
        java.util.TimeZone timeZone67 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass65, date66, timeZone67);
        java.lang.ClassLoader classLoader69 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass65);
        org.jfree.data.time.TimeSeries timeSeries70 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2, (java.lang.Class) wildcardClass65);
        org.jfree.data.time.TimeSeries timeSeries71 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day59, (java.lang.Class) wildcardClass65);
        timeSeries12.update((org.jfree.data.time.RegularTimePeriod) day59, (java.lang.Number) 11);
        long long74 = day59.getSerialIndex();
        try {
            timeSeries2.add((org.jfree.data.time.RegularTimePeriod) day59, (java.lang.Number) (byte) -1, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNull(class29);
        org.junit.Assert.assertNull(timeSeriesDataItem41);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1546329600000L + "'", long45 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem57);
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertNotNull(timeSeries60);
        org.junit.Assert.assertNotNull(wildcardClass65);
        org.junit.Assert.assertNull(regularTimePeriod68);
        org.junit.Assert.assertNotNull(classLoader69);
        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 25568L + "'", long74 == 25568L);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries2.setDomainDescription("");
        java.lang.Class class7 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class10);
        timeSeries11.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str14 = timeSeries11.getDescription();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        long long16 = year15.getLastMillisecond();
        long long17 = year15.getSerialIndex();
        int int18 = timeSeries11.getIndex((org.jfree.data.time.RegularTimePeriod) year15);
        java.lang.Class class26 = null;
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class26);
        java.lang.Class<?> wildcardClass28 = timeSeries27.getClass();
        java.util.Date date29 = null;
        java.util.TimeZone timeZone30 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass28, date29, timeZone30);
        java.lang.ClassLoader classLoader32 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass28);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2, (java.lang.Class) wildcardClass28);
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, "ThreadContext", "org.jfree.data.general.SeriesException: ", (java.lang.Class) wildcardClass28);
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year15, "Following", "Fourth", (java.lang.Class) wildcardClass28);
        java.lang.Class class39 = null;
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class39);
        timeSeries40.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener42 = null;
        timeSeries40.addPropertyChangeListener(propertyChangeListener42);
        boolean boolean44 = timeSeries40.isEmpty();
        boolean boolean45 = timeSeries40.isEmpty();
        java.util.Collection collection46 = timeSeries35.getTimePeriodsUniqueToOtherSeries(timeSeries40);
        java.lang.Class class50 = null;
        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class50);
        timeSeries51.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener53 = null;
        timeSeries51.addPropertyChangeListener(propertyChangeListener53);
        boolean boolean55 = timeSeries51.isEmpty();
        boolean boolean56 = timeSeries51.getNotify();
        java.util.Collection collection57 = timeSeries35.getTimePeriodsUniqueToOtherSeries(timeSeries51);
        timeSeries35.setDescription("org.jfree.data.time.TimePeriodFormatException: ClassContext");
        java.util.Collection collection60 = timeSeries2.getTimePeriodsUniqueToOtherSeries(timeSeries35);
        java.lang.Class class64 = null;
        org.jfree.data.time.TimeSeries timeSeries65 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class64);
        timeSeries65.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener67 = null;
        timeSeries65.addPropertyChangeListener(propertyChangeListener67);
        org.jfree.data.time.FixedMillisecond fixedMillisecond70 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem71 = timeSeries65.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond70);
        java.util.Date date72 = fixedMillisecond70.getEnd();
        java.util.Date date73 = fixedMillisecond70.getTime();
        boolean boolean75 = fixedMillisecond70.equals((java.lang.Object) 100);
        java.util.Calendar calendar76 = null;
        long long77 = fixedMillisecond70.getFirstMillisecond(calendar76);
        boolean boolean79 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) fixedMillisecond70, (java.lang.Object) "August");
        java.lang.Number number80 = timeSeries2.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond70);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str14.equals("SerialDate.weekInMonthToString(): invalid code."));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1577865599999L + "'", long16 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2019L + "'", long17 == 2019L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(classLoader32);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(collection46);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertNotNull(collection57);
        org.junit.Assert.assertNotNull(collection60);
        org.junit.Assert.assertNull(timeSeriesDataItem71);
        org.junit.Assert.assertNotNull(date72);
        org.junit.Assert.assertNotNull(date73);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 0L + "'", long77 == 0L);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNull(number80);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class5);
        timeSeries6.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries6.addPropertyChangeListener(propertyChangeListener8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries6.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11);
        java.util.Date date13 = fixedMillisecond11.getEnd();
        int int15 = fixedMillisecond11.compareTo((java.lang.Object) "SerialDate.weekInMonthToString(): invalid code.");
        boolean boolean16 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) fixedMillisecond1, (java.lang.Object) "SerialDate.weekInMonthToString(): invalid code.");
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class8);
        timeSeries9.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries9.addPropertyChangeListener(propertyChangeListener11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
        java.util.Date date16 = fixedMillisecond14.getEnd();
        java.util.Date date17 = fixedMillisecond14.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (double) 2958465);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries4.removeChangeListener(seriesChangeListener20);
        java.lang.Class class23 = null;
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class23);
        timeSeries24.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries24.setDomainDescription("");
        java.lang.Class class29 = timeSeries24.getTimePeriodClass();
        timeSeries24.clear();
        java.lang.Class class34 = null;
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class34);
        timeSeries35.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener37 = null;
        timeSeries35.addPropertyChangeListener(propertyChangeListener37);
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries35.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40);
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
        int int44 = year42.compareTo((java.lang.Object) "");
        long long45 = year42.getFirstMillisecond();
        int int46 = timeSeries35.getIndex((org.jfree.data.time.RegularTimePeriod) year42);
        java.lang.Class class50 = null;
        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class50);
        timeSeries51.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener53 = null;
        timeSeries51.addPropertyChangeListener(propertyChangeListener53);
        org.jfree.data.time.FixedMillisecond fixedMillisecond56 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem57 = timeSeries51.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond56);
        java.util.Date date58 = fixedMillisecond56.getEnd();
        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day(date58);
        org.jfree.data.time.TimeSeries timeSeries60 = timeSeries24.createCopy((org.jfree.data.time.RegularTimePeriod) year42, (org.jfree.data.time.RegularTimePeriod) day59);
        long long61 = day59.getFirstMillisecond();
        boolean boolean63 = day59.equals((java.lang.Object) 1577865599999L);
        timeSeries4.setKey((java.lang.Comparable) boolean63);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem66 = timeSeries4.getDataItem(0);
        org.jfree.data.time.Year year67 = new org.jfree.data.time.Year();
        long long68 = year67.getLastMillisecond();
        java.util.Date date69 = year67.getStart();
        org.jfree.data.time.Month month70 = new org.jfree.data.time.Month(date69);
        int int71 = month70.getMonth();
        int int72 = month70.getYearValue();
        boolean boolean73 = timeSeriesDataItem66.equals((java.lang.Object) month70);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertNull(class29);
        org.junit.Assert.assertNull(timeSeriesDataItem41);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1546329600000L + "'", long45 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem57);
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertNotNull(timeSeries60);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + (-57600000L) + "'", long61 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem66);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 1577865599999L + "'", long68 == 1577865599999L);
        org.junit.Assert.assertNotNull(date69);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 1 + "'", int71 == 1);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 2019 + "'", int72 == 2019);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 1);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        long long4 = fixedMillisecond1.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.Class class9 = timeSeries8.getTimePeriodClass();
        java.lang.ClassLoader classLoader10 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class9);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, "Fourth", "", class9);
        java.util.Date date12 = fixedMillisecond1.getTime();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1L + "'", long4 == 1L);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertNotNull(classLoader10);
        org.junit.Assert.assertNotNull(date12);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class2);
        timeSeries3.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries3.setDomainDescription("");
        java.lang.Class class8 = timeSeries3.getTimePeriodClass();
        timeSeries3.clear();
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class13);
        timeSeries14.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries14.addPropertyChangeListener(propertyChangeListener16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries14.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        int int23 = year21.compareTo((java.lang.Object) "");
        long long24 = year21.getFirstMillisecond();
        int int25 = timeSeries14.getIndex((org.jfree.data.time.RegularTimePeriod) year21);
        java.lang.Class class29 = null;
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class29);
        timeSeries30.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener32 = null;
        timeSeries30.addPropertyChangeListener(propertyChangeListener32);
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries30.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
        java.util.Date date37 = fixedMillisecond35.getEnd();
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date37);
        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year21, (org.jfree.data.time.RegularTimePeriod) day38);
        long long40 = day38.getFirstMillisecond();
        boolean boolean42 = day38.equals((java.lang.Object) 1577865599999L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day38, (java.lang.Number) (-31507200000L));
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.Class class51 = timeSeries50.getTimePeriodClass();
        java.net.URL uRL52 = org.jfree.chart.util.ObjectUtilities.getResource("Following", class51);
        org.jfree.data.time.TimeSeries timeSeries55 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.Class class56 = timeSeries55.getTimePeriodClass();
        java.net.URL uRL57 = org.jfree.chart.util.ObjectUtilities.getResource("Following", class56);
        java.lang.Object obj58 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ThreadContext", class51, class56);
        org.jfree.data.time.TimeSeries timeSeries59 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day38, "October", "ERROR : Relative To String", class56);
        boolean boolean60 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 1535785200000L, (java.lang.Object) timeSeries59);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1546329600000L + "'", long24 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(timeSeries39);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-57600000L) + "'", long40 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(class51);
        org.junit.Assert.assertNull(uRL52);
        org.junit.Assert.assertNotNull(class56);
        org.junit.Assert.assertNull(uRL57);
        org.junit.Assert.assertNull(obj58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        int int13 = year11.compareTo((java.lang.Object) "");
        long long14 = year11.getFirstMillisecond();
        int int15 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) year11);
        timeSeries4.setDomainDescription("org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries4.createCopy((int) (byte) 10, (int) '#');
        boolean boolean21 = timeSeries4.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener22);
        java.lang.Class class27 = null;
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class27);
        timeSeries28.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener30 = null;
        timeSeries28.addPropertyChangeListener(propertyChangeListener30);
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries28.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond33);
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
        int int37 = year35.compareTo((java.lang.Object) "");
        long long38 = year35.getFirstMillisecond();
        int int39 = timeSeries28.getIndex((org.jfree.data.time.RegularTimePeriod) year35);
        java.lang.String str40 = timeSeries28.getDomainDescription();
        timeSeries28.setMaximumItemCount((int) (byte) 10);
        long long43 = timeSeries28.getMaximumItemAge();
        java.lang.Class class47 = null;
        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class47);
        timeSeries48.clear();
        java.lang.Class class53 = null;
        org.jfree.data.time.TimeSeries timeSeries54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class53);
        timeSeries54.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener56 = null;
        timeSeries54.addPropertyChangeListener(propertyChangeListener56);
        org.jfree.data.time.FixedMillisecond fixedMillisecond59 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem60 = timeSeries54.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond59);
        java.util.Date date61 = fixedMillisecond59.getEnd();
        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year();
        long long63 = year62.getLastMillisecond();
        boolean boolean64 = fixedMillisecond59.equals((java.lang.Object) year62);
        int int66 = fixedMillisecond59.compareTo((java.lang.Object) 1577865599999L);
        java.lang.Number number67 = timeSeries48.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond59);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem69 = timeSeries28.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond59, 10.0d);
        java.lang.Class class73 = null;
        org.jfree.data.time.TimeSeries timeSeries74 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class73);
        timeSeries74.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener76 = null;
        timeSeries74.addPropertyChangeListener(propertyChangeListener76);
        timeSeries74.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
        int int80 = fixedMillisecond59.compareTo((java.lang.Object) "SerialDate.weekInMonthToString(): invalid code.");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = fixedMillisecond59.next();
        try {
            timeSeries4.add(regularTimePeriod81, (java.lang.Number) 1560441401245L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(timeSeriesDataItem34);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1546329600000L + "'", long38 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "hi!" + "'", str40.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 9223372036854775807L + "'", long43 == 9223372036854775807L);
        org.junit.Assert.assertNull(timeSeriesDataItem60);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 1577865599999L + "'", long63 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 1 + "'", int66 == 1);
        org.junit.Assert.assertNull(number67);
        org.junit.Assert.assertNull(timeSeriesDataItem69);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 1 + "'", int80 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod81);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("September 2019");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        int int4 = month3.getYearValue();
        org.jfree.data.time.Year year5 = month3.getYear();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = year5.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(year5);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        int int13 = year11.compareTo((java.lang.Object) "");
        long long14 = year11.getFirstMillisecond();
        int int15 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) year11);
        java.lang.String str16 = timeSeries4.getDomainDescription();
        timeSeries4.setMaximumItemCount((int) (byte) 10);
        long long19 = timeSeries4.getMaximumItemAge();
        java.lang.Class class23 = null;
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class23);
        timeSeries24.clear();
        java.lang.Class class29 = null;
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class29);
        timeSeries30.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener32 = null;
        timeSeries30.addPropertyChangeListener(propertyChangeListener32);
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries30.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
        java.util.Date date37 = fixedMillisecond35.getEnd();
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
        long long39 = year38.getLastMillisecond();
        boolean boolean40 = fixedMillisecond35.equals((java.lang.Object) year38);
        int int42 = fixedMillisecond35.compareTo((java.lang.Object) 1577865599999L);
        java.lang.Number number43 = timeSeries24.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35, 10.0d);
        java.util.Date date46 = fixedMillisecond35.getTime();
        long long47 = fixedMillisecond35.getFirstMillisecond();
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 9223372036854775807L + "'", long19 == 9223372036854775807L);
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1577865599999L + "'", long39 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertNull(number43);
        org.junit.Assert.assertNull(timeSeriesDataItem45);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 0L + "'", long47 == 0L);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        int int13 = year11.compareTo((java.lang.Object) "");
        long long14 = year11.getFirstMillisecond();
        int int15 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) year11);
        java.lang.String str16 = timeSeries4.getDomainDescription();
        timeSeries4.setMaximumItemCount((int) (byte) 10);
        timeSeries4.setDomainDescription("31-December-1969");
        java.lang.Class class24 = null;
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class24);
        timeSeries25.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener27 = null;
        timeSeries25.addPropertyChangeListener(propertyChangeListener27);
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries25.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30);
        java.util.Date date32 = fixedMillisecond30.getEnd();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        long long34 = year33.getLastMillisecond();
        boolean boolean35 = fixedMillisecond30.equals((java.lang.Object) year33);
        int int37 = fixedMillisecond30.compareTo((java.lang.Object) 1577865599999L);
        java.util.Calendar calendar38 = null;
        long long39 = fixedMillisecond30.getFirstMillisecond(calendar38);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = fixedMillisecond30.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond((long) (short) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = fixedMillisecond42.previous();
        java.util.Calendar calendar44 = null;
        long long45 = fixedMillisecond42.getMiddleMillisecond(calendar44);
        org.jfree.data.time.TimeSeries timeSeries46 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond42);
        boolean boolean47 = timeSeries4.getNotify();
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertNull(timeSeriesDataItem31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1577865599999L + "'", long34 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1L + "'", long45 == 1L);
        org.junit.Assert.assertNotNull(timeSeries46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        int int13 = year11.compareTo((java.lang.Object) "");
        long long14 = year11.getFirstMillisecond();
        int int15 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) year11);
        int int16 = timeSeries4.getMaximumItemCount();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = null;
        try {
            timeSeries4.add(regularTimePeriod17, (java.lang.Number) 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2147483647 + "'", int16 == 2147483647);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries2.setDomainDescription("");
        java.lang.Class class7 = timeSeries2.getTimePeriodClass();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries2.removeChangeListener(seriesChangeListener8);
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class11);
        timeSeries12.removeAgedItems(false);
        timeSeries12.setMaximumItemCount((int) 'a');
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries2.addAndOrUpdate(timeSeries12);
        int int18 = timeSeries12.getItemCount();
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) "");
        long long3 = year0.getFirstMillisecond();
        long long4 = year0.getSerialIndex();
        long long5 = year0.getLastMillisecond();
        int int6 = year0.getYear();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-460), "October", "2019", class3);
        java.lang.String str5 = timeSeries4.getDescription();
        timeSeries4.setDomainDescription("31-December-1969");
        java.util.Collection collection8 = timeSeries4.getTimePeriods();
        timeSeries4.setDescription("");
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(collection8);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class2);
        java.lang.Class<?> wildcardClass4 = timeSeries3.getClass();
        java.util.Date date5 = null;
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date5, timeZone6);
        java.lang.ClassLoader classLoader8 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2, (java.lang.Class) wildcardClass4);
        timeSeries9.removeAgedItems(false);
        timeSeries9.setNotify(false);
        boolean boolean14 = timeSeries9.isEmpty();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(classLoader8);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        int int5 = fixedMillisecond1.compareTo((java.lang.Object) 25568L);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond1.getLastMillisecond(calendar6);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class4);
        java.lang.Class class9 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class9);
        timeSeries10.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries10.addPropertyChangeListener(propertyChangeListener12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries10.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.util.Date date17 = fixedMillisecond15.getEnd();
        java.util.Date date18 = fixedMillisecond15.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (double) 2958465);
        java.util.Calendar calendar21 = null;
        fixedMillisecond15.peg(calendar21);
        java.util.Date date23 = fixedMillisecond15.getTime();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date23);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance(date23);
        java.lang.Class class29 = null;
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class29);
        java.lang.Class class34 = null;
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class34);
        timeSeries35.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener37 = null;
        timeSeries35.addPropertyChangeListener(propertyChangeListener37);
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries35.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40);
        java.util.Date date42 = fixedMillisecond40.getEnd();
        java.util.Date date43 = fixedMillisecond40.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = timeSeries30.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40, (double) 2958465);
        java.util.Calendar calendar46 = null;
        fixedMillisecond40.peg(calendar46);
        java.util.Date date48 = fixedMillisecond40.getTime();
        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.createInstance(date48);
        serialDate49.setDescription("ThreadContext");
        java.lang.String str52 = serialDate49.getDescription();
        org.jfree.data.time.SerialDate serialDate53 = serialDate25.getEndOfCurrentMonth(serialDate49);
        org.jfree.data.time.SerialDate serialDate54 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(3, serialDate25);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNull(timeSeriesDataItem41);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNull(timeSeriesDataItem45);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "ThreadContext" + "'", str52.equals("ThreadContext"));
        org.junit.Assert.assertNotNull(serialDate53);
        org.junit.Assert.assertNotNull(serialDate54);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        java.lang.String str3 = timeSeries2.getRangeDescription();
        java.lang.String str4 = timeSeries2.getDomainDescription();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class6);
        timeSeries7.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries7.setDomainDescription("");
        java.lang.Class class12 = timeSeries7.getTimePeriodClass();
        timeSeries7.clear();
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class17);
        timeSeries18.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timeSeries18.addPropertyChangeListener(propertyChangeListener20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries18.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        int int27 = year25.compareTo((java.lang.Object) "");
        long long28 = year25.getFirstMillisecond();
        int int29 = timeSeries18.getIndex((org.jfree.data.time.RegularTimePeriod) year25);
        java.lang.Class class33 = null;
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class33);
        timeSeries34.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener36 = null;
        timeSeries34.addPropertyChangeListener(propertyChangeListener36);
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries34.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39);
        java.util.Date date41 = fixedMillisecond39.getEnd();
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(date41);
        org.jfree.data.time.TimeSeries timeSeries43 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) year25, (org.jfree.data.time.RegularTimePeriod) day42);
        long long44 = day42.getFirstMillisecond();
        boolean boolean46 = day42.equals((java.lang.Object) 1577865599999L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day42, (java.lang.Number) (-31507200000L));
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) day42);
        timeSeries2.setDescription("28-February-1933");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Value" + "'", str3.equals("Value"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
        org.junit.Assert.assertNull(class12);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1546329600000L + "'", long28 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem40);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(timeSeries43);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-57600000L) + "'", long44 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries2.setDomainDescription("");
        java.lang.Class class7 = timeSeries2.getTimePeriodClass();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries2.removeChangeListener(seriesChangeListener8);
        int int10 = timeSeries2.getItemCount();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries2.addChangeListener(seriesChangeListener11);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries2.setDomainDescription("");
        java.lang.Class class7 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class12);
        timeSeries13.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        int int22 = year20.compareTo((java.lang.Object) "");
        long long23 = year20.getFirstMillisecond();
        int int24 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) year20);
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class28);
        timeSeries29.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timeSeries29.addPropertyChangeListener(propertyChangeListener31);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
        java.util.Date date36 = fixedMillisecond34.getEnd();
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date36);
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) year20, (org.jfree.data.time.RegularTimePeriod) day37);
        org.jfree.data.time.SerialDate serialDate39 = day37.getSerialDate();
        java.util.Date date40 = day37.getStart();
        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month(date40);
        long long42 = month41.getLastMillisecond();
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year();
        int int45 = year43.compareTo((java.lang.Object) "");
        long long46 = year43.getFirstMillisecond();
        int int47 = month41.compareTo((java.lang.Object) long46);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1546329600000L + "'", long23 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeSeries38);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 28799999L + "'", long42 == 28799999L);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1546329600000L + "'", long46 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        long long3 = year2.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year2.previous();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.Class class9 = timeSeries8.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod4, "", "org.jfree.data.general.SeriesChangeEvent[source=SerialDate.weekInMonthToString(): invalid code.]", class9);
        java.io.InputStream inputStream11 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("SerialDate.weekInMonthToString(): invalid code.", class9);
        java.lang.ClassLoader classLoader12 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class9);
        java.net.URL uRL13 = org.jfree.chart.util.ObjectUtilities.getResource("June 2019", class9);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertNull(inputStream11);
        org.junit.Assert.assertNotNull(classLoader12);
        org.junit.Assert.assertNull(uRL13);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((-451));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-569) + "'", int1 == (-569));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class2);
        java.lang.Class<?> wildcardClass4 = timeSeries3.getClass();
        java.util.Date date5 = null;
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date5, timeZone6);
        java.lang.ClassLoader classLoader8 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2, (java.lang.Class) wildcardClass4);
        timeSeries9.removeAgedItems(false);
        timeSeries9.setNotify(false);
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries9.removePropertyChangeListener(propertyChangeListener14);
        java.lang.String str16 = timeSeries9.getRangeDescription();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(classLoader8);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Value" + "'", str16.equals("Value"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        java.util.Date date11 = fixedMillisecond9.getEnd();
        java.util.Date date12 = fixedMillisecond9.getTime();
        boolean boolean14 = fixedMillisecond9.equals((java.lang.Object) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond9.previous();
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries2.setDomainDescription("");
        java.lang.Class class7 = timeSeries2.getTimePeriodClass();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries2.removeChangeListener(seriesChangeListener8);
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class11);
        timeSeries12.removeAgedItems(false);
        timeSeries12.setMaximumItemCount((int) 'a');
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries2.addAndOrUpdate(timeSeries12);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries17.addChangeListener(seriesChangeListener18);
        java.lang.Class class24 = null;
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class24);
        timeSeries25.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries25.setDomainDescription("");
        java.lang.Class class30 = timeSeries25.getTimePeriodClass();
        timeSeries25.clear();
        java.lang.Class class35 = null;
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class35);
        timeSeries36.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener38 = null;
        timeSeries36.addPropertyChangeListener(propertyChangeListener38);
        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries36.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond41);
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year();
        int int45 = year43.compareTo((java.lang.Object) "");
        long long46 = year43.getFirstMillisecond();
        int int47 = timeSeries36.getIndex((org.jfree.data.time.RegularTimePeriod) year43);
        java.lang.Class class51 = null;
        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class51);
        timeSeries52.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener54 = null;
        timeSeries52.addPropertyChangeListener(propertyChangeListener54);
        org.jfree.data.time.FixedMillisecond fixedMillisecond57 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem58 = timeSeries52.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond57);
        java.util.Date date59 = fixedMillisecond57.getEnd();
        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day(date59);
        org.jfree.data.time.TimeSeries timeSeries61 = timeSeries25.createCopy((org.jfree.data.time.RegularTimePeriod) year43, (org.jfree.data.time.RegularTimePeriod) day60);
        org.jfree.data.time.SerialDate serialDate62 = day60.getSerialDate();
        org.jfree.data.time.SerialDate serialDate63 = org.jfree.data.time.SerialDate.addMonths(29, serialDate62);
        org.jfree.data.time.SerialDate serialDate64 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(3, serialDate63);
        java.lang.String str65 = serialDate64.getDescription();
        org.jfree.data.time.SerialDate serialDate66 = org.jfree.data.time.SerialDate.addMonths((int) (short) 100, serialDate64);
        boolean boolean67 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) timeSeries17, (java.lang.Object) serialDate64);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNull(class30);
        org.junit.Assert.assertNull(timeSeriesDataItem42);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1546329600000L + "'", long46 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem58);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertNotNull(timeSeries61);
        org.junit.Assert.assertNotNull(serialDate62);
        org.junit.Assert.assertNotNull(serialDate63);
        org.junit.Assert.assertNotNull(serialDate64);
        org.junit.Assert.assertNull(str65);
        org.junit.Assert.assertNotNull(serialDate66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        int int4 = month3.getMonth();
        int int5 = month3.getYearValue();
        long long6 = month3.getSerialIndex();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class10);
        timeSeries11.fireSeriesChanged();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries11.addChangeListener(seriesChangeListener13);
        int int15 = month3.compareTo((java.lang.Object) timeSeries11);
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class17);
        timeSeries18.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries18.setDomainDescription("");
        java.lang.Class class23 = timeSeries18.getTimePeriodClass();
        timeSeries18.clear();
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class28);
        timeSeries29.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timeSeries29.addPropertyChangeListener(propertyChangeListener31);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        int int38 = year36.compareTo((java.lang.Object) "");
        long long39 = year36.getFirstMillisecond();
        int int40 = timeSeries29.getIndex((org.jfree.data.time.RegularTimePeriod) year36);
        java.lang.Class class44 = null;
        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class44);
        timeSeries45.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener47 = null;
        timeSeries45.addPropertyChangeListener(propertyChangeListener47);
        org.jfree.data.time.FixedMillisecond fixedMillisecond50 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = timeSeries45.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond50);
        java.util.Date date52 = fixedMillisecond50.getEnd();
        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day(date52);
        org.jfree.data.time.TimeSeries timeSeries54 = timeSeries18.createCopy((org.jfree.data.time.RegularTimePeriod) year36, (org.jfree.data.time.RegularTimePeriod) day53);
        org.jfree.data.time.SerialDate serialDate55 = day53.getSerialDate();
        java.util.Date date56 = day53.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem58 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day53, (java.lang.Number) 1900);
        try {
            timeSeries11.add(timeSeriesDataItem58);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 24229L + "'", long6 == 24229L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNull(class23);
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1546329600000L + "'", long39 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem51);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertNotNull(timeSeries54);
        org.junit.Assert.assertNotNull(serialDate55);
        org.junit.Assert.assertNotNull(date56);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("2018");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 1);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.previous();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class6);
        timeSeries7.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries7.setDomainDescription("");
        java.lang.Class class12 = timeSeries7.getTimePeriodClass();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries7.removeChangeListener(seriesChangeListener13);
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class16);
        timeSeries17.removeAgedItems(false);
        timeSeries17.setMaximumItemCount((int) 'a');
        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries7.addAndOrUpdate(timeSeries17);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener23 = null;
        timeSeries22.addChangeListener(seriesChangeListener23);
        boolean boolean25 = fixedMillisecond1.equals((java.lang.Object) seriesChangeListener23);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNull(class12);
        org.junit.Assert.assertNotNull(timeSeries22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        int int4 = month3.getMonth();
        int int5 = month3.getYearValue();
        long long6 = month3.getSerialIndex();
        boolean boolean8 = month3.equals((java.lang.Object) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month3.previous();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 24229L + "'", long6 == 24229L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

//    @Test
//    public void test170() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test170");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (double) 11);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        long long4 = day3.getSerialIndex();
//        int int5 = day3.getDayOfMonth();
//        int int6 = timeSeriesDataItem2.compareTo((java.lang.Object) int5);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43629L + "'", long4 == 43629L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        java.lang.Class class0 = null;
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class2);
        timeSeries3.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries3.setDomainDescription("");
        java.lang.Class class8 = timeSeries3.getTimePeriodClass();
        timeSeries3.clear();
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class13);
        timeSeries14.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries14.addPropertyChangeListener(propertyChangeListener16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries14.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        int int23 = year21.compareTo((java.lang.Object) "");
        long long24 = year21.getFirstMillisecond();
        int int25 = timeSeries14.getIndex((org.jfree.data.time.RegularTimePeriod) year21);
        java.lang.Class class29 = null;
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class29);
        timeSeries30.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener32 = null;
        timeSeries30.addPropertyChangeListener(propertyChangeListener32);
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries30.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
        java.util.Date date37 = fixedMillisecond35.getEnd();
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date37);
        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year21, (org.jfree.data.time.RegularTimePeriod) day38);
        long long40 = day38.getFirstMillisecond();
        boolean boolean42 = day38.equals((java.lang.Object) 1577865599999L);
        long long43 = day38.getSerialIndex();
        java.util.Date date44 = day38.getStart();
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.createInstance(date44);
        java.lang.Class class49 = null;
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class49);
        java.lang.Class class54 = null;
        org.jfree.data.time.TimeSeries timeSeries55 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class54);
        timeSeries55.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener57 = null;
        timeSeries55.addPropertyChangeListener(propertyChangeListener57);
        org.jfree.data.time.FixedMillisecond fixedMillisecond60 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem61 = timeSeries55.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond60);
        java.util.Date date62 = fixedMillisecond60.getEnd();
        java.util.Date date63 = fixedMillisecond60.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem65 = timeSeries50.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond60, (double) 2958465);
        java.util.Calendar calendar66 = null;
        fixedMillisecond60.peg(calendar66);
        java.util.Date date68 = fixedMillisecond60.getTime();
        org.jfree.data.time.Day day69 = new org.jfree.data.time.Day(date68);
        java.util.TimeZone timeZone70 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month71 = new org.jfree.data.time.Month(date68, timeZone70);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date44, timeZone70);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1546329600000L + "'", long24 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(timeSeries39);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-57600000L) + "'", long40 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 25568L + "'", long43 == 25568L);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertNull(timeSeriesDataItem61);
        org.junit.Assert.assertNotNull(date62);
        org.junit.Assert.assertNotNull(date63);
        org.junit.Assert.assertNull(timeSeriesDataItem65);
        org.junit.Assert.assertNotNull(date68);
        org.junit.Assert.assertNotNull(timeZone70);
        org.junit.Assert.assertNull(regularTimePeriod72);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries2.setDomainDescription("");
        java.lang.Class class7 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class12);
        timeSeries13.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        int int22 = year20.compareTo((java.lang.Object) "");
        long long23 = year20.getFirstMillisecond();
        int int24 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) year20);
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class28);
        timeSeries29.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timeSeries29.addPropertyChangeListener(propertyChangeListener31);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
        java.util.Date date36 = fixedMillisecond34.getEnd();
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date36);
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) year20, (org.jfree.data.time.RegularTimePeriod) day37);
        java.lang.Class class40 = null;
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class40);
        timeSeries41.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries41.setDomainDescription("");
        java.lang.Class class46 = timeSeries41.getTimePeriodClass();
        timeSeries41.clear();
        java.lang.Class class51 = null;
        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class51);
        timeSeries52.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener54 = null;
        timeSeries52.addPropertyChangeListener(propertyChangeListener54);
        org.jfree.data.time.FixedMillisecond fixedMillisecond57 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem58 = timeSeries52.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond57);
        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year();
        int int61 = year59.compareTo((java.lang.Object) "");
        long long62 = year59.getFirstMillisecond();
        int int63 = timeSeries52.getIndex((org.jfree.data.time.RegularTimePeriod) year59);
        java.lang.Class class67 = null;
        org.jfree.data.time.TimeSeries timeSeries68 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class67);
        timeSeries68.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener70 = null;
        timeSeries68.addPropertyChangeListener(propertyChangeListener70);
        org.jfree.data.time.FixedMillisecond fixedMillisecond73 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem74 = timeSeries68.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond73);
        java.util.Date date75 = fixedMillisecond73.getEnd();
        org.jfree.data.time.Day day76 = new org.jfree.data.time.Day(date75);
        org.jfree.data.time.TimeSeries timeSeries77 = timeSeries41.createCopy((org.jfree.data.time.RegularTimePeriod) year59, (org.jfree.data.time.RegularTimePeriod) day76);
        long long78 = day76.getFirstMillisecond();
        boolean boolean80 = day76.equals((java.lang.Object) 1577865599999L);
        long long81 = day76.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod82 = day76.next();
        long long83 = day76.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem85 = timeSeries38.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day76, (double) 1549007999999L);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1546329600000L + "'", long23 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeSeries38);
        org.junit.Assert.assertNull(class46);
        org.junit.Assert.assertNull(timeSeriesDataItem58);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1 + "'", int61 == 1);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 1546329600000L + "'", long62 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-1) + "'", int63 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem74);
        org.junit.Assert.assertNotNull(date75);
        org.junit.Assert.assertNotNull(timeSeries77);
        org.junit.Assert.assertTrue("'" + long78 + "' != '" + (-57600000L) + "'", long78 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + long81 + "' != '" + 25568L + "'", long81 == 25568L);
        org.junit.Assert.assertNotNull(regularTimePeriod82);
        org.junit.Assert.assertTrue("'" + long83 + "' != '" + 25568L + "'", long83 == 25568L);
        org.junit.Assert.assertNull(timeSeriesDataItem85);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries2.setDomainDescription("");
        java.lang.Class class7 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class12);
        timeSeries13.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        int int22 = year20.compareTo((java.lang.Object) "");
        long long23 = year20.getFirstMillisecond();
        int int24 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) year20);
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class28);
        timeSeries29.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timeSeries29.addPropertyChangeListener(propertyChangeListener31);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
        java.util.Date date36 = fixedMillisecond34.getEnd();
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date36);
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) year20, (org.jfree.data.time.RegularTimePeriod) day37);
        org.jfree.data.time.SerialDate serialDate39 = day37.getSerialDate();
        java.util.Date date40 = day37.getStart();
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year(date40);
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
        long long43 = year42.getLastMillisecond();
        java.util.Date date44 = year42.getStart();
        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month(date44);
        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date47 = fixedMillisecond46.getTime();
        java.util.TimeZone timeZone48 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year(date47, timeZone48);
        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(date44, timeZone48);
        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year(date44);
        int int52 = year41.compareTo((java.lang.Object) date44);
        org.jfree.data.time.TimeSeries timeSeries55 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.Class class56 = timeSeries55.getTimePeriodClass();
        java.net.URL uRL57 = org.jfree.chart.util.ObjectUtilities.getResource("Following", class56);
        java.lang.Class class61 = null;
        org.jfree.data.time.TimeSeries timeSeries62 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class61);
        java.lang.Class class66 = null;
        org.jfree.data.time.TimeSeries timeSeries67 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class66);
        timeSeries67.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener69 = null;
        timeSeries67.addPropertyChangeListener(propertyChangeListener69);
        org.jfree.data.time.FixedMillisecond fixedMillisecond72 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem73 = timeSeries67.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond72);
        java.util.Date date74 = fixedMillisecond72.getEnd();
        java.util.Date date75 = fixedMillisecond72.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem77 = timeSeries62.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond72, (double) 2958465);
        java.util.Calendar calendar78 = null;
        fixedMillisecond72.peg(calendar78);
        java.util.Date date80 = fixedMillisecond72.getTime();
        org.jfree.data.time.SerialDate serialDate81 = org.jfree.data.time.SerialDate.createInstance(date80);
        org.jfree.data.time.FixedMillisecond fixedMillisecond82 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date83 = fixedMillisecond82.getTime();
        java.util.TimeZone timeZone84 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year85 = new org.jfree.data.time.Year(date83, timeZone84);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod86 = org.jfree.data.time.RegularTimePeriod.createInstance(class56, date80, timeZone84);
        org.jfree.data.time.Day day87 = new org.jfree.data.time.Day(date44, timeZone84);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1546329600000L + "'", long23 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeSeries38);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1577865599999L + "'", long43 == 1577865599999L);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(timeZone48);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
        org.junit.Assert.assertNotNull(class56);
        org.junit.Assert.assertNull(uRL57);
        org.junit.Assert.assertNull(timeSeriesDataItem73);
        org.junit.Assert.assertNotNull(date74);
        org.junit.Assert.assertNotNull(date75);
        org.junit.Assert.assertNull(timeSeriesDataItem77);
        org.junit.Assert.assertNotNull(date80);
        org.junit.Assert.assertNotNull(serialDate81);
        org.junit.Assert.assertNotNull(date83);
        org.junit.Assert.assertNotNull(timeZone84);
        org.junit.Assert.assertNotNull(regularTimePeriod86);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries2.setDomainDescription("");
        java.lang.String str7 = timeSeries2.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) 1);
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getMiddleMillisecond(calendar10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = fixedMillisecond9.previous();
        java.lang.String str13 = regularTimePeriod12.toString();
        try {
            timeSeries2.add(regularTimePeriod12, (java.lang.Number) (-460));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str13.equals("Wed Dec 31 16:00:00 PST 1969"));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("October");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class2);
        timeSeries3.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries3.setDomainDescription("");
        java.lang.Class class8 = timeSeries3.getTimePeriodClass();
        timeSeries3.clear();
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class13);
        timeSeries14.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries14.addPropertyChangeListener(propertyChangeListener16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries14.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        int int23 = year21.compareTo((java.lang.Object) "");
        long long24 = year21.getFirstMillisecond();
        int int25 = timeSeries14.getIndex((org.jfree.data.time.RegularTimePeriod) year21);
        java.lang.Class class29 = null;
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class29);
        timeSeries30.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener32 = null;
        timeSeries30.addPropertyChangeListener(propertyChangeListener32);
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries30.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
        java.util.Date date37 = fixedMillisecond35.getEnd();
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date37);
        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year21, (org.jfree.data.time.RegularTimePeriod) day38);
        java.lang.Class class42 = null;
        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class42);
        java.lang.Class<?> wildcardClass44 = timeSeries43.getClass();
        java.util.Date date45 = null;
        java.util.TimeZone timeZone46 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass44, date45, timeZone46);
        java.lang.ClassLoader classLoader48 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass44);
        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2, (java.lang.Class) wildcardClass44);
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day38, (java.lang.Class) wildcardClass44);
        java.io.InputStream inputStream51 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("org.jfree.data.general.SeriesChangeEvent[source=SerialDate.weekInMonthToString(): invalid code.]", (java.lang.Class) wildcardClass44);
        java.lang.ClassLoader classLoader52 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass44);
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader52);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1546329600000L + "'", long24 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(timeSeries39);
        org.junit.Assert.assertNotNull(wildcardClass44);
        org.junit.Assert.assertNull(regularTimePeriod47);
        org.junit.Assert.assertNotNull(classLoader48);
        org.junit.Assert.assertNull(inputStream51);
        org.junit.Assert.assertNotNull(classLoader52);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries2.setDomainDescription("");
        java.lang.Class class7 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class12);
        timeSeries13.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        int int22 = year20.compareTo((java.lang.Object) "");
        long long23 = year20.getFirstMillisecond();
        int int24 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) year20);
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class28);
        timeSeries29.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timeSeries29.addPropertyChangeListener(propertyChangeListener31);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
        java.util.Date date36 = fixedMillisecond34.getEnd();
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date36);
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) year20, (org.jfree.data.time.RegularTimePeriod) day37);
        long long39 = day37.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = day37.previous();
        long long41 = day37.getSerialIndex();
        java.lang.String str42 = day37.toString();
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year();
        long long44 = year43.getLastMillisecond();
        java.util.Date date45 = year43.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = year43.next();
        long long47 = year43.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = year43.previous();
        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.Class class53 = timeSeries52.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod48, "October", "", class53);
        int int55 = day37.compareTo((java.lang.Object) class53);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1546329600000L + "'", long23 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeSeries38);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-57600000L) + "'", long39 == (-57600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 25568L + "'", long41 == 25568L);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "31-December-1969" + "'", str42.equals("31-December-1969"));
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1577865599999L + "'", long44 == 1577865599999L);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1577865599999L + "'", long47 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
        org.junit.Assert.assertNotNull(class53);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(13);
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class6);
        timeSeries7.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries7.setDomainDescription("");
        java.lang.Class class12 = timeSeries7.getTimePeriodClass();
        timeSeries7.clear();
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class17);
        timeSeries18.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timeSeries18.addPropertyChangeListener(propertyChangeListener20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries18.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        int int27 = year25.compareTo((java.lang.Object) "");
        long long28 = year25.getFirstMillisecond();
        int int29 = timeSeries18.getIndex((org.jfree.data.time.RegularTimePeriod) year25);
        java.lang.Class class33 = null;
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class33);
        timeSeries34.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener36 = null;
        timeSeries34.addPropertyChangeListener(propertyChangeListener36);
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries34.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39);
        java.util.Date date41 = fixedMillisecond39.getEnd();
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(date41);
        org.jfree.data.time.TimeSeries timeSeries43 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) year25, (org.jfree.data.time.RegularTimePeriod) day42);
        org.jfree.data.time.SerialDate serialDate44 = day42.getSerialDate();
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.addMonths(29, serialDate44);
        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(3, serialDate45);
        org.jfree.data.time.SerialDate serialDate47 = org.jfree.data.time.SerialDate.addMonths(10, serialDate45);
        java.lang.Class class52 = null;
        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class52);
        timeSeries53.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries53.setDomainDescription("");
        java.lang.Class class58 = timeSeries53.getTimePeriodClass();
        timeSeries53.clear();
        java.lang.Class class63 = null;
        org.jfree.data.time.TimeSeries timeSeries64 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class63);
        timeSeries64.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener66 = null;
        timeSeries64.addPropertyChangeListener(propertyChangeListener66);
        org.jfree.data.time.FixedMillisecond fixedMillisecond69 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem70 = timeSeries64.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond69);
        org.jfree.data.time.Year year71 = new org.jfree.data.time.Year();
        int int73 = year71.compareTo((java.lang.Object) "");
        long long74 = year71.getFirstMillisecond();
        int int75 = timeSeries64.getIndex((org.jfree.data.time.RegularTimePeriod) year71);
        java.lang.Class class79 = null;
        org.jfree.data.time.TimeSeries timeSeries80 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class79);
        timeSeries80.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener82 = null;
        timeSeries80.addPropertyChangeListener(propertyChangeListener82);
        org.jfree.data.time.FixedMillisecond fixedMillisecond85 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem86 = timeSeries80.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond85);
        java.util.Date date87 = fixedMillisecond85.getEnd();
        org.jfree.data.time.Day day88 = new org.jfree.data.time.Day(date87);
        org.jfree.data.time.TimeSeries timeSeries89 = timeSeries53.createCopy((org.jfree.data.time.RegularTimePeriod) year71, (org.jfree.data.time.RegularTimePeriod) day88);
        org.jfree.data.time.SerialDate serialDate90 = day88.getSerialDate();
        org.jfree.data.time.SerialDate serialDate91 = org.jfree.data.time.SerialDate.addMonths(29, serialDate90);
        org.jfree.data.time.SerialDate serialDate92 = org.jfree.data.time.SerialDate.addYears(2019, serialDate91);
        org.jfree.data.time.SerialDate serialDate93 = org.jfree.data.time.SerialDate.addDays(2, serialDate91);
        boolean boolean94 = spreadsheetDate1.isInRange(serialDate45, serialDate91);
        int int95 = spreadsheetDate1.getMonth();
        int int96 = spreadsheetDate1.getYYYY();
        java.lang.String str97 = spreadsheetDate1.toString();
        org.junit.Assert.assertNull(class12);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1546329600000L + "'", long28 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem40);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(timeSeries43);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertNull(class58);
        org.junit.Assert.assertNull(timeSeriesDataItem70);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 1 + "'", int73 == 1);
        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 1546329600000L + "'", long74 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + (-1) + "'", int75 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem86);
        org.junit.Assert.assertNotNull(date87);
        org.junit.Assert.assertNotNull(timeSeries89);
        org.junit.Assert.assertNotNull(serialDate90);
        org.junit.Assert.assertNotNull(serialDate91);
        org.junit.Assert.assertNotNull(serialDate92);
        org.junit.Assert.assertNotNull(serialDate93);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
        org.junit.Assert.assertTrue("'" + int95 + "' != '" + 1 + "'", int95 == 1);
        org.junit.Assert.assertTrue("'" + int96 + "' != '" + 1900 + "'", int96 == 1900);
        org.junit.Assert.assertTrue("'" + str97 + "' != '" + "12-January-1900" + "'", str97.equals("12-January-1900"));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries2.setDomainDescription("");
        java.lang.Class class7 = timeSeries2.getTimePeriodClass();
        long long8 = timeSeries2.getMaximumItemAge();
        long long9 = timeSeries2.getMaximumItemAge();
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9223372036854775807L + "'", long8 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str5 = timeSeries2.getDescription();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getLastMillisecond();
        long long8 = year6.getSerialIndex();
        int int9 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) year6);
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class17);
        java.lang.Class<?> wildcardClass19 = timeSeries18.getClass();
        java.util.Date date20 = null;
        java.util.TimeZone timeZone21 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date20, timeZone21);
        java.lang.ClassLoader classLoader23 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass19);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2, (java.lang.Class) wildcardClass19);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, "ThreadContext", "org.jfree.data.general.SeriesException: ", (java.lang.Class) wildcardClass19);
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year6, "Following", "Fourth", (java.lang.Class) wildcardClass19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year6.next();
        java.lang.Object obj28 = null;
        int int29 = year6.compareTo(obj28);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str5.equals("SerialDate.weekInMonthToString(): invalid code."));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(classLoader23);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        timeSeries4.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries4.addChangeListener(seriesChangeListener10);
        timeSeries4.clear();
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class14);
        timeSeries15.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries15.setDomainDescription("");
        java.lang.Class class20 = timeSeries15.getTimePeriodClass();
        timeSeries15.clear();
        java.lang.Class class25 = null;
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class25);
        timeSeries26.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener28 = null;
        timeSeries26.addPropertyChangeListener(propertyChangeListener28);
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries26.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond31);
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        int int35 = year33.compareTo((java.lang.Object) "");
        long long36 = year33.getFirstMillisecond();
        int int37 = timeSeries26.getIndex((org.jfree.data.time.RegularTimePeriod) year33);
        java.lang.Class class41 = null;
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class41);
        timeSeries42.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener44 = null;
        timeSeries42.addPropertyChangeListener(propertyChangeListener44);
        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = timeSeries42.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond47);
        java.util.Date date49 = fixedMillisecond47.getEnd();
        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(date49);
        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) year33, (org.jfree.data.time.RegularTimePeriod) day50);
        org.jfree.data.time.SerialDate serialDate52 = day50.getSerialDate();
        java.util.Date date53 = day50.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem55 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day50, (java.lang.Number) 1900);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = timeSeriesDataItem55.getPeriod();
        java.lang.Number number57 = timeSeriesDataItem55.getValue();
        java.lang.Number number58 = timeSeriesDataItem55.getValue();
        try {
            timeSeries4.add(timeSeriesDataItem55);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(class20);
        org.junit.Assert.assertNull(timeSeriesDataItem32);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1546329600000L + "'", long36 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem48);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(timeSeries51);
        org.junit.Assert.assertNotNull(serialDate52);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertNotNull(regularTimePeriod56);
        org.junit.Assert.assertTrue("'" + number57 + "' != '" + 1900 + "'", number57.equals(1900));
        org.junit.Assert.assertTrue("'" + number58 + "' != '" + 1900 + "'", number58.equals(1900));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class2);
        timeSeries3.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries3.setDomainDescription("");
        java.lang.Class class8 = timeSeries3.getTimePeriodClass();
        timeSeries3.clear();
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class13);
        timeSeries14.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries14.addPropertyChangeListener(propertyChangeListener16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries14.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        int int23 = year21.compareTo((java.lang.Object) "");
        long long24 = year21.getFirstMillisecond();
        int int25 = timeSeries14.getIndex((org.jfree.data.time.RegularTimePeriod) year21);
        java.lang.Class class29 = null;
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class29);
        timeSeries30.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener32 = null;
        timeSeries30.addPropertyChangeListener(propertyChangeListener32);
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries30.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
        java.util.Date date37 = fixedMillisecond35.getEnd();
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date37);
        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year21, (org.jfree.data.time.RegularTimePeriod) day38);
        org.jfree.data.time.SerialDate serialDate40 = day38.getSerialDate();
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(serialDate40);
        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.addYears(28, serialDate40);
        try {
            org.jfree.data.time.SerialDate serialDate44 = serialDate42.getFollowingDayOfWeek((-459));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1546329600000L + "'", long24 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(timeSeries39);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertNotNull(serialDate42);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries2.setDomainDescription("");
        java.lang.Class class7 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class12);
        timeSeries13.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        int int22 = year20.compareTo((java.lang.Object) "");
        long long23 = year20.getFirstMillisecond();
        int int24 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) year20);
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class28);
        timeSeries29.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timeSeries29.addPropertyChangeListener(propertyChangeListener31);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
        java.util.Date date36 = fixedMillisecond34.getEnd();
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date36);
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) year20, (org.jfree.data.time.RegularTimePeriod) day37);
        org.jfree.data.time.SerialDate serialDate39 = day37.getSerialDate();
        java.util.Date date40 = day37.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day37, (java.lang.Number) 1900);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = timeSeriesDataItem42.getPeriod();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod43, (double) 2958465);
        java.lang.Class class47 = null;
        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class47);
        timeSeries48.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str51 = timeSeries48.getDescription();
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year();
        long long53 = year52.getLastMillisecond();
        long long54 = year52.getSerialIndex();
        int int55 = timeSeries48.getIndex((org.jfree.data.time.RegularTimePeriod) year52);
        java.lang.Class class63 = null;
        org.jfree.data.time.TimeSeries timeSeries64 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class63);
        java.lang.Class<?> wildcardClass65 = timeSeries64.getClass();
        java.util.Date date66 = null;
        java.util.TimeZone timeZone67 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass65, date66, timeZone67);
        java.lang.ClassLoader classLoader69 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass65);
        org.jfree.data.time.TimeSeries timeSeries70 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2, (java.lang.Class) wildcardClass65);
        org.jfree.data.time.TimeSeries timeSeries71 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, "ThreadContext", "org.jfree.data.general.SeriesException: ", (java.lang.Class) wildcardClass65);
        org.jfree.data.time.TimeSeries timeSeries72 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year52, "Following", "Fourth", (java.lang.Class) wildcardClass65);
        org.jfree.data.time.TimeSeries timeSeries73 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod43, (java.lang.Class) wildcardClass65);
        java.lang.String str74 = timeSeries73.getDomainDescription();
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1546329600000L + "'", long23 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeSeries38);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str51.equals("SerialDate.weekInMonthToString(): invalid code."));
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 1577865599999L + "'", long53 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 2019L + "'", long54 == 2019L);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-1) + "'", int55 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass65);
        org.junit.Assert.assertNull(regularTimePeriod68);
        org.junit.Assert.assertNotNull(classLoader69);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "Time" + "'", str74.equals("Time"));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2019, (int) ' ', (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class2);
        timeSeries3.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries3.setDomainDescription("");
        java.lang.Class class8 = timeSeries3.getTimePeriodClass();
        timeSeries3.clear();
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class13);
        timeSeries14.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries14.addPropertyChangeListener(propertyChangeListener16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries14.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        int int23 = year21.compareTo((java.lang.Object) "");
        long long24 = year21.getFirstMillisecond();
        int int25 = timeSeries14.getIndex((org.jfree.data.time.RegularTimePeriod) year21);
        java.lang.Class class29 = null;
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class29);
        timeSeries30.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener32 = null;
        timeSeries30.addPropertyChangeListener(propertyChangeListener32);
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries30.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
        java.util.Date date37 = fixedMillisecond35.getEnd();
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date37);
        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year21, (org.jfree.data.time.RegularTimePeriod) day38);
        org.jfree.data.time.SerialDate serialDate40 = day38.getSerialDate();
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(serialDate40);
        org.jfree.data.time.SerialDate serialDate42 = day41.getSerialDate();
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.addMonths(0, serialDate42);
        java.lang.String str44 = serialDate43.getDescription();
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1546329600000L + "'", long24 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(timeSeries39);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNull(str44);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("January");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: January" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: January"));
        org.junit.Assert.assertNotNull(throwableArray3);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries2.setDomainDescription("");
        java.lang.Class class7 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class12);
        timeSeries13.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        int int22 = year20.compareTo((java.lang.Object) "");
        long long23 = year20.getFirstMillisecond();
        int int24 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) year20);
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class28);
        timeSeries29.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timeSeries29.addPropertyChangeListener(propertyChangeListener31);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
        java.util.Date date36 = fixedMillisecond34.getEnd();
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date36);
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) year20, (org.jfree.data.time.RegularTimePeriod) day37);
        org.jfree.data.time.SerialDate serialDate39 = day37.getSerialDate();
        java.util.Date date40 = day37.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day37, (java.lang.Number) 1900);
        java.lang.Class class44 = null;
        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class44);
        timeSeries45.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str48 = timeSeries45.getDescription();
        timeSeries45.setMaximumItemAge((long) 11);
        java.beans.PropertyChangeListener propertyChangeListener51 = null;
        timeSeries45.removePropertyChangeListener(propertyChangeListener51);
        boolean boolean53 = timeSeriesDataItem42.equals((java.lang.Object) propertyChangeListener51);
        java.lang.Object obj54 = timeSeriesDataItem42.clone();
        java.lang.Class class58 = null;
        org.jfree.data.time.TimeSeries timeSeries59 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class58);
        java.lang.Class class63 = null;
        org.jfree.data.time.TimeSeries timeSeries64 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class63);
        timeSeries64.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener66 = null;
        timeSeries64.addPropertyChangeListener(propertyChangeListener66);
        org.jfree.data.time.FixedMillisecond fixedMillisecond69 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem70 = timeSeries64.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond69);
        java.util.Date date71 = fixedMillisecond69.getEnd();
        java.util.Date date72 = fixedMillisecond69.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem74 = timeSeries59.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond69, (double) 2958465);
        java.util.Calendar calendar75 = null;
        fixedMillisecond69.peg(calendar75);
        java.util.Date date77 = fixedMillisecond69.getTime();
        org.jfree.data.time.Day day78 = new org.jfree.data.time.Day(date77);
        org.jfree.data.time.Year year79 = new org.jfree.data.time.Year(date77);
        int int80 = timeSeriesDataItem42.compareTo((java.lang.Object) date77);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1546329600000L + "'", long23 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeSeries38);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str48.equals("SerialDate.weekInMonthToString(): invalid code."));
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(obj54);
        org.junit.Assert.assertNull(timeSeriesDataItem70);
        org.junit.Assert.assertNotNull(date71);
        org.junit.Assert.assertNotNull(date72);
        org.junit.Assert.assertNull(timeSeriesDataItem74);
        org.junit.Assert.assertNotNull(date77);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 1 + "'", int80 == 1);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.data.time.SerialDate serialDate0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(serialDate0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'serialDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.data.time.Year year2 = org.jfree.data.time.Year.parseYear("2018");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(9, year2);
        long long4 = month3.getFirstMillisecond();
        int int5 = month3.getMonth();
        long long6 = month3.getSerialIndex();
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1535785200000L + "'", long4 == 1535785200000L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 24225L + "'", long6 == 24225L);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries2.setDomainDescription("");
        java.lang.Class class7 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class12);
        timeSeries13.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        int int22 = year20.compareTo((java.lang.Object) "");
        long long23 = year20.getFirstMillisecond();
        int int24 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) year20);
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class28);
        timeSeries29.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timeSeries29.addPropertyChangeListener(propertyChangeListener31);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
        java.util.Date date36 = fixedMillisecond34.getEnd();
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date36);
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) year20, (org.jfree.data.time.RegularTimePeriod) day37);
        org.jfree.data.time.SerialDate serialDate39 = day37.getSerialDate();
        java.util.Date date40 = day37.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day37, (java.lang.Number) 1900);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = timeSeriesDataItem42.getPeriod();
        java.lang.Number number44 = timeSeriesDataItem42.getValue();
        java.lang.Number number45 = timeSeriesDataItem42.getValue();
        java.lang.Object obj46 = timeSeriesDataItem42.clone();
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1546329600000L + "'", long23 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeSeries38);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertTrue("'" + number44 + "' != '" + 1900 + "'", number44.equals(1900));
        org.junit.Assert.assertTrue("'" + number45 + "' != '" + 1900 + "'", number45.equals(1900));
        org.junit.Assert.assertNotNull(obj46);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getFirstMillisecond(calendar4);
        long long6 = fixedMillisecond1.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries2.setDomainDescription("");
        java.lang.Class class7 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class12);
        timeSeries13.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        int int22 = year20.compareTo((java.lang.Object) "");
        long long23 = year20.getFirstMillisecond();
        int int24 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) year20);
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class28);
        timeSeries29.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timeSeries29.addPropertyChangeListener(propertyChangeListener31);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
        java.util.Date date36 = fixedMillisecond34.getEnd();
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date36);
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) year20, (org.jfree.data.time.RegularTimePeriod) day37);
        long long39 = day37.getFirstMillisecond();
        boolean boolean41 = day37.equals((java.lang.Object) 1577865599999L);
        long long42 = day37.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = day37.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = day37.previous();
        boolean boolean46 = day37.equals((java.lang.Object) false);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1546329600000L + "'", long23 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeSeries38);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-57600000L) + "'", long39 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 25568L + "'", long42 == 25568L);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        java.util.Date date11 = fixedMillisecond9.getEnd();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getLastMillisecond();
        boolean boolean14 = fixedMillisecond9.equals((java.lang.Object) year12);
        long long15 = fixedMillisecond9.getSerialIndex();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) (short) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = fixedMillisecond17.previous();
        boolean boolean19 = fixedMillisecond9.equals((java.lang.Object) regularTimePeriod18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        long long21 = year20.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year20.previous();
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.Class class27 = timeSeries26.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod22, "", "org.jfree.data.general.SeriesChangeEvent[source=SerialDate.weekInMonthToString(): invalid code.]", class27);
        int int29 = fixedMillisecond9.compareTo((java.lang.Object) timeSeries28);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        long long31 = year30.getLastMillisecond();
        java.util.Date date32 = year30.getStart();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(date32);
        int int34 = month33.getYearValue();
        org.jfree.data.time.Year year35 = month33.getYear();
        org.jfree.data.time.Year year36 = month33.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year36, 0.0d);
        try {
            timeSeries28.add(timeSeriesDataItem38, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1577865599999L + "'", long21 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(class27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1577865599999L + "'", long31 == 1577865599999L);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 2019 + "'", int34 == 2019);
        org.junit.Assert.assertNotNull(year35);
        org.junit.Assert.assertNotNull(year36);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) "");
        long long3 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        long long6 = year5.getLastMillisecond();
        long long7 = year5.getLastMillisecond();
        int int8 = year0.compareTo((java.lang.Object) long7);
        java.util.Calendar calendar9 = null;
        try {
            year0.peg(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str5 = timeSeries2.getDescription();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries2.getDataItem(2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2958465, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str5.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class5);
        java.lang.Class<?> wildcardClass7 = timeSeries6.getClass();
        java.util.Date date8 = null;
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date8, timeZone9);
        java.lang.ClassLoader classLoader11 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass7);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2, (java.lang.Class) wildcardClass7);
        java.io.InputStream inputStream13 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("org.jfree.data.time.TimePeriodFormatException: ClassContext", (java.lang.Class) wildcardClass7);
        int int14 = fixedMillisecond1.compareTo((java.lang.Object) wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(classLoader11);
        org.junit.Assert.assertNull(inputStream13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-460), "October", "2019", class3);
        int int5 = timeSeries4.getItemCount();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries4.addChangeListener(seriesChangeListener6);
        java.lang.Class class8 = timeSeries4.getTimePeriodClass();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(class8);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-460), "October", "2019", class3);
        java.lang.String str5 = timeSeries4.getDescription();
        timeSeries4.setDomainDescription("31-December-1969");
        java.util.Collection collection8 = timeSeries4.getTimePeriods();
        timeSeries4.fireSeriesChanged();
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(collection8);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.removeAgedItems(false);
        java.lang.Class class5 = null;
        java.lang.Class class9 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class9);
        timeSeries10.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries10.addPropertyChangeListener(propertyChangeListener12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries10.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.util.Date date17 = fixedMillisecond15.getEnd();
        java.util.TimeZone timeZone18 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date17, timeZone18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond(date17);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year21.previous();
        long long23 = year21.getFirstMillisecond();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        long long25 = year24.getLastMillisecond();
        java.util.Date date26 = year24.getStart();
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(date26);
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date29 = fixedMillisecond28.getTime();
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date29, timeZone30);
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date26, timeZone30);
        boolean boolean33 = year21.equals((java.lang.Object) day32);
        timeSeries2.setKey((java.lang.Comparable) day32);
        java.lang.Class class36 = null;
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class36);
        timeSeries37.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries37.setDomainDescription("");
        java.lang.Class class42 = timeSeries37.getTimePeriodClass();
        timeSeries37.clear();
        java.lang.Class class47 = null;
        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class47);
        timeSeries48.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener50 = null;
        timeSeries48.addPropertyChangeListener(propertyChangeListener50);
        org.jfree.data.time.FixedMillisecond fixedMillisecond53 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem54 = timeSeries48.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond53);
        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year();
        int int57 = year55.compareTo((java.lang.Object) "");
        long long58 = year55.getFirstMillisecond();
        int int59 = timeSeries48.getIndex((org.jfree.data.time.RegularTimePeriod) year55);
        java.lang.Class class63 = null;
        org.jfree.data.time.TimeSeries timeSeries64 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class63);
        timeSeries64.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener66 = null;
        timeSeries64.addPropertyChangeListener(propertyChangeListener66);
        org.jfree.data.time.FixedMillisecond fixedMillisecond69 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem70 = timeSeries64.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond69);
        java.util.Date date71 = fixedMillisecond69.getEnd();
        org.jfree.data.time.Day day72 = new org.jfree.data.time.Day(date71);
        org.jfree.data.time.TimeSeries timeSeries73 = timeSeries37.createCopy((org.jfree.data.time.RegularTimePeriod) year55, (org.jfree.data.time.RegularTimePeriod) day72);
        long long74 = day72.getFirstMillisecond();
        boolean boolean76 = day72.equals((java.lang.Object) 1577865599999L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem78 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day72, (java.lang.Number) (-31507200000L));
        try {
            timeSeries2.add(timeSeriesDataItem78);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-31507200000L) + "'", long23 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1577865599999L + "'", long25 == 1577865599999L);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(class42);
        org.junit.Assert.assertNull(timeSeriesDataItem54);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1546329600000L + "'", long58 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-1) + "'", int59 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem70);
        org.junit.Assert.assertNotNull(date71);
        org.junit.Assert.assertNotNull(timeSeries73);
        org.junit.Assert.assertTrue("'" + long74 + "' != '" + (-57600000L) + "'", long74 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str5 = timeSeries2.getDescription();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getLastMillisecond();
        long long8 = year6.getSerialIndex();
        int int9 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) year6);
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class17);
        java.lang.Class<?> wildcardClass19 = timeSeries18.getClass();
        java.util.Date date20 = null;
        java.util.TimeZone timeZone21 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date20, timeZone21);
        java.lang.ClassLoader classLoader23 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass19);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2, (java.lang.Class) wildcardClass19);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, "ThreadContext", "org.jfree.data.general.SeriesException: ", (java.lang.Class) wildcardClass19);
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year6, "Following", "Fourth", (java.lang.Class) wildcardClass19);
        int int27 = year6.getYear();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str5.equals("SerialDate.weekInMonthToString(): invalid code."));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(classLoader23);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class8);
        timeSeries9.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries9.addPropertyChangeListener(propertyChangeListener11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
        java.util.Date date16 = fixedMillisecond14.getEnd();
        java.util.Date date17 = fixedMillisecond14.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (double) 2958465);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries4.removeChangeListener(seriesChangeListener20);
        java.lang.Class class23 = null;
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class23);
        timeSeries24.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries24.setDomainDescription("");
        java.lang.Class class29 = timeSeries24.getTimePeriodClass();
        timeSeries24.clear();
        java.lang.Class class34 = null;
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class34);
        timeSeries35.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener37 = null;
        timeSeries35.addPropertyChangeListener(propertyChangeListener37);
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries35.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40);
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
        int int44 = year42.compareTo((java.lang.Object) "");
        long long45 = year42.getFirstMillisecond();
        int int46 = timeSeries35.getIndex((org.jfree.data.time.RegularTimePeriod) year42);
        java.lang.Class class50 = null;
        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class50);
        timeSeries51.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener53 = null;
        timeSeries51.addPropertyChangeListener(propertyChangeListener53);
        org.jfree.data.time.FixedMillisecond fixedMillisecond56 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem57 = timeSeries51.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond56);
        java.util.Date date58 = fixedMillisecond56.getEnd();
        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day(date58);
        org.jfree.data.time.TimeSeries timeSeries60 = timeSeries24.createCopy((org.jfree.data.time.RegularTimePeriod) year42, (org.jfree.data.time.RegularTimePeriod) day59);
        long long61 = day59.getFirstMillisecond();
        boolean boolean63 = day59.equals((java.lang.Object) 1577865599999L);
        timeSeries4.setKey((java.lang.Comparable) boolean63);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem66 = timeSeries4.getDataItem(0);
        java.lang.Number number67 = timeSeriesDataItem66.getValue();
        timeSeriesDataItem66.setValue((java.lang.Number) 100);
        java.lang.Number number70 = timeSeriesDataItem66.getValue();
        org.jfree.data.time.Year year72 = new org.jfree.data.time.Year();
        long long73 = year72.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = year72.previous();
        org.jfree.data.time.TimeSeries timeSeries78 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.Class class79 = timeSeries78.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries80 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod74, "", "org.jfree.data.general.SeriesChangeEvent[source=SerialDate.weekInMonthToString(): invalid code.]", class79);
        java.io.InputStream inputStream81 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("SerialDate.weekInMonthToString(): invalid code.", class79);
        int int82 = timeSeriesDataItem66.compareTo((java.lang.Object) "SerialDate.weekInMonthToString(): invalid code.");
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertNull(class29);
        org.junit.Assert.assertNull(timeSeriesDataItem41);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1546329600000L + "'", long45 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem57);
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertNotNull(timeSeries60);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + (-57600000L) + "'", long61 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem66);
        org.junit.Assert.assertTrue("'" + number67 + "' != '" + 2958465.0d + "'", number67.equals(2958465.0d));
        org.junit.Assert.assertTrue("'" + number70 + "' != '" + 100 + "'", number70.equals(100));
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 1577865599999L + "'", long73 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod74);
        org.junit.Assert.assertNotNull(class79);
        org.junit.Assert.assertNull(inputStream81);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 1 + "'", int82 == 1);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 1);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) (-57600000L));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        java.util.Date date11 = fixedMillisecond9.getEnd();
        java.util.Date date12 = fixedMillisecond9.getTime();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(date12);
        long long15 = fixedMillisecond14.getLastMillisecond();
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.data.time.Year year2 = org.jfree.data.time.Year.parseYear("2018");
        try {
            org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(1969, year2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(year2);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(2, (int) '#', (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class8);
        timeSeries9.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries9.addPropertyChangeListener(propertyChangeListener11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
        java.util.Date date16 = fixedMillisecond14.getEnd();
        java.util.Date date17 = fixedMillisecond14.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (double) 2958465);
        java.util.Calendar calendar20 = null;
        fixedMillisecond14.peg(calendar20);
        java.util.Date date22 = fixedMillisecond14.getTime();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance(date22);
        java.lang.String str25 = serialDate24.getDescription();
        serialDate24.setDescription("ERROR : Relative To String");
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(serialDate24);
        long long29 = day28.getFirstMillisecond();
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-57600000L) + "'", long29 == (-57600000L));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(13);
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class6);
        timeSeries7.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries7.setDomainDescription("");
        java.lang.Class class12 = timeSeries7.getTimePeriodClass();
        timeSeries7.clear();
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class17);
        timeSeries18.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timeSeries18.addPropertyChangeListener(propertyChangeListener20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries18.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        int int27 = year25.compareTo((java.lang.Object) "");
        long long28 = year25.getFirstMillisecond();
        int int29 = timeSeries18.getIndex((org.jfree.data.time.RegularTimePeriod) year25);
        java.lang.Class class33 = null;
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class33);
        timeSeries34.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener36 = null;
        timeSeries34.addPropertyChangeListener(propertyChangeListener36);
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries34.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39);
        java.util.Date date41 = fixedMillisecond39.getEnd();
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(date41);
        org.jfree.data.time.TimeSeries timeSeries43 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) year25, (org.jfree.data.time.RegularTimePeriod) day42);
        org.jfree.data.time.SerialDate serialDate44 = day42.getSerialDate();
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.addMonths(29, serialDate44);
        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.addYears((int) (byte) -1, serialDate45);
        org.jfree.data.time.SerialDate serialDate47 = org.jfree.data.time.SerialDate.addMonths((-459), serialDate46);
        org.jfree.data.time.SerialDate serialDate49 = serialDate46.getPreviousDayOfWeek(4);
        boolean boolean50 = spreadsheetDate1.isBefore(serialDate49);
        java.lang.String str51 = spreadsheetDate1.toString();
        java.lang.Class class56 = null;
        org.jfree.data.time.TimeSeries timeSeries57 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class56);
        timeSeries57.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries57.setDomainDescription("");
        java.lang.Class class62 = timeSeries57.getTimePeriodClass();
        timeSeries57.clear();
        java.lang.Class class67 = null;
        org.jfree.data.time.TimeSeries timeSeries68 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class67);
        timeSeries68.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener70 = null;
        timeSeries68.addPropertyChangeListener(propertyChangeListener70);
        org.jfree.data.time.FixedMillisecond fixedMillisecond73 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem74 = timeSeries68.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond73);
        org.jfree.data.time.Year year75 = new org.jfree.data.time.Year();
        int int77 = year75.compareTo((java.lang.Object) "");
        long long78 = year75.getFirstMillisecond();
        int int79 = timeSeries68.getIndex((org.jfree.data.time.RegularTimePeriod) year75);
        java.lang.Class class83 = null;
        org.jfree.data.time.TimeSeries timeSeries84 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class83);
        timeSeries84.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener86 = null;
        timeSeries84.addPropertyChangeListener(propertyChangeListener86);
        org.jfree.data.time.FixedMillisecond fixedMillisecond89 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem90 = timeSeries84.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond89);
        java.util.Date date91 = fixedMillisecond89.getEnd();
        org.jfree.data.time.Day day92 = new org.jfree.data.time.Day(date91);
        org.jfree.data.time.TimeSeries timeSeries93 = timeSeries57.createCopy((org.jfree.data.time.RegularTimePeriod) year75, (org.jfree.data.time.RegularTimePeriod) day92);
        org.jfree.data.time.SerialDate serialDate94 = day92.getSerialDate();
        org.jfree.data.time.SerialDate serialDate95 = org.jfree.data.time.SerialDate.addMonths(29, serialDate94);
        org.jfree.data.time.SerialDate serialDate96 = org.jfree.data.time.SerialDate.addYears((int) (byte) -1, serialDate95);
        org.jfree.data.time.SerialDate serialDate97 = org.jfree.data.time.SerialDate.addMonths((-459), serialDate96);
        boolean boolean98 = spreadsheetDate1.isOnOrAfter(serialDate97);
        org.junit.Assert.assertNull(class12);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1546329600000L + "'", long28 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem40);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(timeSeries43);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "12-January-1900" + "'", str51.equals("12-January-1900"));
        org.junit.Assert.assertNull(class62);
        org.junit.Assert.assertNull(timeSeriesDataItem74);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 1 + "'", int77 == 1);
        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 1546329600000L + "'", long78 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + (-1) + "'", int79 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem90);
        org.junit.Assert.assertNotNull(date91);
        org.junit.Assert.assertNotNull(timeSeries93);
        org.junit.Assert.assertNotNull(serialDate94);
        org.junit.Assert.assertNotNull(serialDate95);
        org.junit.Assert.assertNotNull(serialDate96);
        org.junit.Assert.assertNotNull(serialDate97);
        org.junit.Assert.assertTrue("'" + boolean98 + "' != '" + false + "'", boolean98 == false);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond9.previous();
        java.lang.Number number11 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, number11);
        timeSeries4.fireSeriesChanged();
        int int14 = timeSeries4.getItemCount();
        java.lang.Comparable comparable15 = timeSeries4.getKey();
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + comparable15 + "' != '" + '#' + "'", comparable15.equals('#'));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("org.jfree.data.general.SeriesException: ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str5 = timeSeries2.getDescription();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getLastMillisecond();
        long long8 = year6.getSerialIndex();
        int int9 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) year6);
        long long10 = year6.getLastMillisecond();
        java.lang.String str11 = year6.toString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str5.equals("SerialDate.weekInMonthToString(): invalid code."));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2019" + "'", str11.equals("2019"));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries2.setDomainDescription("");
        java.lang.Class class7 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class12);
        timeSeries13.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        int int22 = year20.compareTo((java.lang.Object) "");
        long long23 = year20.getFirstMillisecond();
        int int24 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) year20);
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class28);
        timeSeries29.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timeSeries29.addPropertyChangeListener(propertyChangeListener31);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
        java.util.Date date36 = fixedMillisecond34.getEnd();
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date36);
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) year20, (org.jfree.data.time.RegularTimePeriod) day37);
        long long39 = day37.getFirstMillisecond();
        boolean boolean41 = day37.equals((java.lang.Object) 1577865599999L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day37, (java.lang.Number) (-31507200000L));
        java.util.Calendar calendar44 = null;
        try {
            long long45 = day37.getFirstMillisecond(calendar44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1546329600000L + "'", long23 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeSeries38);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-57600000L) + "'", long39 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        timeSeries2.setDescription("2019");
        java.lang.Class class5 = timeSeries2.getTimePeriodClass();
        java.lang.ClassLoader classLoader6 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class5);
        java.io.InputStream inputStream7 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("October", class5);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(classLoader6);
        org.junit.Assert.assertNull(inputStream7);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        boolean boolean8 = timeSeries4.isEmpty();
        boolean boolean9 = timeSeries4.isEmpty();
        timeSeries4.setMaximumItemCount(0);
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-460), "October", "2019", class15);
        boolean boolean17 = timeSeries16.getNotify();
        java.util.Collection collection18 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries16);
        timeSeries16.removeAgedItems(true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(collection18);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class4);
        timeSeries5.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries5.setDomainDescription("");
        java.lang.Class class10 = timeSeries5.getTimePeriodClass();
        timeSeries5.clear();
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class15);
        timeSeries16.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timeSeries16.addPropertyChangeListener(propertyChangeListener18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries16.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        int int25 = year23.compareTo((java.lang.Object) "");
        long long26 = year23.getFirstMillisecond();
        int int27 = timeSeries16.getIndex((org.jfree.data.time.RegularTimePeriod) year23);
        java.lang.Class class31 = null;
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class31);
        timeSeries32.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener34 = null;
        timeSeries32.addPropertyChangeListener(propertyChangeListener34);
        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries32.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond37);
        java.util.Date date39 = fixedMillisecond37.getEnd();
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date39);
        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) year23, (org.jfree.data.time.RegularTimePeriod) day40);
        org.jfree.data.time.SerialDate serialDate42 = day40.getSerialDate();
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.addMonths(29, serialDate42);
        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(3, serialDate43);
        java.lang.String str45 = serialDate44.getDescription();
        java.lang.String str46 = serialDate44.getDescription();
        org.jfree.data.time.SerialDate serialDate47 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(2, serialDate44);
        org.junit.Assert.assertNull(class10);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1546329600000L + "'", long26 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem38);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(timeSeries41);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNull(str45);
        org.junit.Assert.assertNull(str46);
        org.junit.Assert.assertNotNull(serialDate47);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class3);
        timeSeries4.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries4.setDomainDescription("");
        java.lang.Class class9 = timeSeries4.getTimePeriodClass();
        timeSeries4.clear();
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class14);
        timeSeries15.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries15.addPropertyChangeListener(propertyChangeListener17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries15.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        int int24 = year22.compareTo((java.lang.Object) "");
        long long25 = year22.getFirstMillisecond();
        int int26 = timeSeries15.getIndex((org.jfree.data.time.RegularTimePeriod) year22);
        java.lang.Class class30 = null;
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class30);
        timeSeries31.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener33 = null;
        timeSeries31.addPropertyChangeListener(propertyChangeListener33);
        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries31.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond36);
        java.util.Date date38 = fixedMillisecond36.getEnd();
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date38);
        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) year22, (org.jfree.data.time.RegularTimePeriod) day39);
        org.jfree.data.time.SerialDate serialDate41 = day39.getSerialDate();
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(serialDate41);
        org.jfree.data.time.SerialDate serialDate43 = day42.getSerialDate();
        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.addMonths(0, serialDate43);
        try {
            org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (byte) 100, serialDate44);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(class9);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1546329600000L + "'", long25 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem37);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(timeSeries40);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNotNull(serialDate44);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries2.removePropertyChangeListener(propertyChangeListener3);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class8);
        timeSeries9.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries9.addPropertyChangeListener(propertyChangeListener11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
        java.util.Date date16 = fixedMillisecond14.getEnd();
        java.util.Date date17 = fixedMillisecond14.getTime();
        boolean boolean19 = fixedMillisecond14.equals((java.lang.Object) 100);
        boolean boolean20 = timeSeries2.equals((java.lang.Object) fixedMillisecond14);
        long long21 = fixedMillisecond14.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond14.previous();
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-460), "October", "2019", class3);
        int int5 = timeSeries4.getItemCount();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 4);
        timeSeries4.setKey((java.lang.Comparable) fixedMillisecond9);
        java.util.Calendar calendar11 = null;
        long long12 = fixedMillisecond9.getMiddleMillisecond(calendar11);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.Class class15 = timeSeries14.getTimePeriodClass();
        java.lang.Class class16 = timeSeries14.getTimePeriodClass();
        boolean boolean17 = fixedMillisecond9.equals((java.lang.Object) class16);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 4L + "'", long12 == 4L);
        org.junit.Assert.assertNotNull(class15);
        org.junit.Assert.assertNotNull(class16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(9, 100, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(13);
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class6);
        timeSeries7.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries7.setDomainDescription("");
        java.lang.Class class12 = timeSeries7.getTimePeriodClass();
        timeSeries7.clear();
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class17);
        timeSeries18.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timeSeries18.addPropertyChangeListener(propertyChangeListener20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries18.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        int int27 = year25.compareTo((java.lang.Object) "");
        long long28 = year25.getFirstMillisecond();
        int int29 = timeSeries18.getIndex((org.jfree.data.time.RegularTimePeriod) year25);
        java.lang.Class class33 = null;
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class33);
        timeSeries34.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener36 = null;
        timeSeries34.addPropertyChangeListener(propertyChangeListener36);
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries34.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39);
        java.util.Date date41 = fixedMillisecond39.getEnd();
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(date41);
        org.jfree.data.time.TimeSeries timeSeries43 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) year25, (org.jfree.data.time.RegularTimePeriod) day42);
        org.jfree.data.time.SerialDate serialDate44 = day42.getSerialDate();
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.addMonths(29, serialDate44);
        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(3, serialDate45);
        java.lang.Class class49 = null;
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class49);
        timeSeries50.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries50.setDomainDescription("");
        java.lang.Class class55 = timeSeries50.getTimePeriodClass();
        timeSeries50.clear();
        java.lang.Class class60 = null;
        org.jfree.data.time.TimeSeries timeSeries61 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class60);
        timeSeries61.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener63 = null;
        timeSeries61.addPropertyChangeListener(propertyChangeListener63);
        org.jfree.data.time.FixedMillisecond fixedMillisecond66 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem67 = timeSeries61.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond66);
        org.jfree.data.time.Year year68 = new org.jfree.data.time.Year();
        int int70 = year68.compareTo((java.lang.Object) "");
        long long71 = year68.getFirstMillisecond();
        int int72 = timeSeries61.getIndex((org.jfree.data.time.RegularTimePeriod) year68);
        java.lang.Class class76 = null;
        org.jfree.data.time.TimeSeries timeSeries77 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class76);
        timeSeries77.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener79 = null;
        timeSeries77.addPropertyChangeListener(propertyChangeListener79);
        org.jfree.data.time.FixedMillisecond fixedMillisecond82 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem83 = timeSeries77.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond82);
        java.util.Date date84 = fixedMillisecond82.getEnd();
        org.jfree.data.time.Day day85 = new org.jfree.data.time.Day(date84);
        org.jfree.data.time.TimeSeries timeSeries86 = timeSeries50.createCopy((org.jfree.data.time.RegularTimePeriod) year68, (org.jfree.data.time.RegularTimePeriod) day85);
        org.jfree.data.time.SerialDate serialDate87 = day85.getSerialDate();
        org.jfree.data.time.SerialDate serialDate88 = org.jfree.data.time.SerialDate.addMonths(29, serialDate87);
        org.jfree.data.time.SerialDate serialDate89 = serialDate45.getEndOfCurrentMonth(serialDate88);
        org.jfree.data.time.SerialDate serialDate90 = org.jfree.data.time.SerialDate.addDays(10, serialDate89);
        boolean boolean91 = spreadsheetDate1.isOnOrBefore(serialDate90);
        int int92 = spreadsheetDate1.getDayOfWeek();
        org.junit.Assert.assertNull(class12);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1546329600000L + "'", long28 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem40);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(timeSeries43);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertNull(class55);
        org.junit.Assert.assertNull(timeSeriesDataItem67);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 1 + "'", int70 == 1);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 1546329600000L + "'", long71 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + (-1) + "'", int72 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem83);
        org.junit.Assert.assertNotNull(date84);
        org.junit.Assert.assertNotNull(timeSeries86);
        org.junit.Assert.assertNotNull(serialDate87);
        org.junit.Assert.assertNotNull(serialDate88);
        org.junit.Assert.assertNotNull(serialDate89);
        org.junit.Assert.assertNotNull(serialDate90);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + true + "'", boolean91 == true);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 6 + "'", int92 == 6);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class4);
        timeSeries5.removeAgedItems(false);
        timeSeries5.setMaximumItemCount((int) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        int int12 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11);
        java.util.Date date13 = fixedMillisecond11.getStart();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.Class class16 = timeSeries15.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date18 = fixedMillisecond17.getTime();
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date18, timeZone19);
        java.lang.Class class22 = null;
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class22);
        timeSeries23.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries23.setDomainDescription("");
        java.lang.Class class28 = timeSeries23.getTimePeriodClass();
        timeSeries23.clear();
        java.lang.Class class33 = null;
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class33);
        timeSeries34.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener36 = null;
        timeSeries34.addPropertyChangeListener(propertyChangeListener36);
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries34.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39);
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
        int int43 = year41.compareTo((java.lang.Object) "");
        long long44 = year41.getFirstMillisecond();
        int int45 = timeSeries34.getIndex((org.jfree.data.time.RegularTimePeriod) year41);
        java.lang.Class class49 = null;
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class49);
        timeSeries50.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener52 = null;
        timeSeries50.addPropertyChangeListener(propertyChangeListener52);
        org.jfree.data.time.FixedMillisecond fixedMillisecond55 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem56 = timeSeries50.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond55);
        java.util.Date date57 = fixedMillisecond55.getEnd();
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(date57);
        org.jfree.data.time.TimeSeries timeSeries59 = timeSeries23.createCopy((org.jfree.data.time.RegularTimePeriod) year41, (org.jfree.data.time.RegularTimePeriod) day58);
        long long60 = day58.getFirstMillisecond();
        boolean boolean62 = day58.equals((java.lang.Object) 1577865599999L);
        long long63 = day58.getSerialIndex();
        java.util.Date date64 = day58.getStart();
        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day(date64);
        java.util.TimeZone timeZone66 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day67 = new org.jfree.data.time.Day(date64, timeZone66);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date18, timeZone66);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date13, timeZone66);
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(class16);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNull(class28);
        org.junit.Assert.assertNull(timeSeriesDataItem40);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1546329600000L + "'", long44 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem56);
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertNotNull(timeSeries59);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + (-57600000L) + "'", long60 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 25568L + "'", long63 == 25568L);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertNotNull(timeZone66);
        org.junit.Assert.assertNotNull(regularTimePeriod68);
        org.junit.Assert.assertNotNull(regularTimePeriod69);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) "");
        long long3 = year0.getSerialIndex();
        boolean boolean5 = year0.equals((java.lang.Object) (-452));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setNotify(true);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class8);
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class13);
        timeSeries14.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries14.addPropertyChangeListener(propertyChangeListener16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries14.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
        java.util.Date date21 = fixedMillisecond19.getEnd();
        java.util.Date date22 = fixedMillisecond19.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (double) 2958465);
        java.util.Calendar calendar25 = null;
        fixedMillisecond19.peg(calendar25);
        java.util.Date date27 = fixedMillisecond19.getTime();
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date27);
        int int29 = day28.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = day28.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = day28.previous();
        java.lang.Class class33 = null;
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class33);
        timeSeries34.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str37 = timeSeries34.getDescription();
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
        long long39 = year38.getLastMillisecond();
        long long40 = year38.getSerialIndex();
        int int41 = timeSeries34.getIndex((org.jfree.data.time.RegularTimePeriod) year38);
        java.lang.Class class49 = null;
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class49);
        java.lang.Class<?> wildcardClass51 = timeSeries50.getClass();
        java.util.Date date52 = null;
        java.util.TimeZone timeZone53 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass51, date52, timeZone53);
        java.lang.ClassLoader classLoader55 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass51);
        org.jfree.data.time.TimeSeries timeSeries56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2, (java.lang.Class) wildcardClass51);
        org.jfree.data.time.TimeSeries timeSeries57 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, "ThreadContext", "org.jfree.data.general.SeriesException: ", (java.lang.Class) wildcardClass51);
        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year38, "Following", "Fourth", (java.lang.Class) wildcardClass51);
        java.lang.Class class62 = null;
        org.jfree.data.time.TimeSeries timeSeries63 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class62);
        timeSeries63.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener65 = null;
        timeSeries63.addPropertyChangeListener(propertyChangeListener65);
        boolean boolean67 = timeSeries63.isEmpty();
        boolean boolean68 = timeSeries63.isEmpty();
        java.util.Collection collection69 = timeSeries58.getTimePeriodsUniqueToOtherSeries(timeSeries63);
        java.lang.Class class71 = null;
        org.jfree.data.time.TimeSeries timeSeries72 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class71);
        java.lang.String str73 = timeSeries72.getRangeDescription();
        timeSeries72.setNotify(true);
        java.util.Collection collection76 = timeSeries58.getTimePeriodsUniqueToOtherSeries(timeSeries72);
        boolean boolean77 = day28.equals((java.lang.Object) timeSeries58);
        long long78 = day28.getFirstMillisecond();
        int int79 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) day28);
        timeSeries2.setRangeDescription("Value");
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 12 + "'", int29 == 12);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str37.equals("SerialDate.weekInMonthToString(): invalid code."));
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1577865599999L + "'", long39 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 2019L + "'", long40 == 2019L);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass51);
        org.junit.Assert.assertNull(regularTimePeriod54);
        org.junit.Assert.assertNotNull(classLoader55);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertNotNull(collection69);
        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "Value" + "'", str73.equals("Value"));
        org.junit.Assert.assertNotNull(collection76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + long78 + "' != '" + (-57600000L) + "'", long78 == (-57600000L));
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + (-1) + "'", int79 == (-1));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(13);
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class6);
        timeSeries7.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries7.setDomainDescription("");
        java.lang.Class class12 = timeSeries7.getTimePeriodClass();
        timeSeries7.clear();
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class17);
        timeSeries18.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timeSeries18.addPropertyChangeListener(propertyChangeListener20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries18.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        int int27 = year25.compareTo((java.lang.Object) "");
        long long28 = year25.getFirstMillisecond();
        int int29 = timeSeries18.getIndex((org.jfree.data.time.RegularTimePeriod) year25);
        java.lang.Class class33 = null;
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class33);
        timeSeries34.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener36 = null;
        timeSeries34.addPropertyChangeListener(propertyChangeListener36);
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries34.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39);
        java.util.Date date41 = fixedMillisecond39.getEnd();
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(date41);
        org.jfree.data.time.TimeSeries timeSeries43 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) year25, (org.jfree.data.time.RegularTimePeriod) day42);
        org.jfree.data.time.SerialDate serialDate44 = day42.getSerialDate();
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.addMonths(29, serialDate44);
        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.addYears((int) (byte) -1, serialDate45);
        org.jfree.data.time.SerialDate serialDate47 = org.jfree.data.time.SerialDate.addMonths((-459), serialDate46);
        org.jfree.data.time.SerialDate serialDate49 = serialDate46.getPreviousDayOfWeek(4);
        boolean boolean50 = spreadsheetDate1.isBefore(serialDate49);
        java.lang.Class class54 = null;
        org.jfree.data.time.TimeSeries timeSeries55 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class54);
        java.lang.Class class59 = null;
        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class59);
        timeSeries60.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener62 = null;
        timeSeries60.addPropertyChangeListener(propertyChangeListener62);
        org.jfree.data.time.FixedMillisecond fixedMillisecond65 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem66 = timeSeries60.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond65);
        java.util.Date date67 = fixedMillisecond65.getEnd();
        java.util.Date date68 = fixedMillisecond65.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem70 = timeSeries55.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond65, (double) 2958465);
        java.util.Calendar calendar71 = null;
        fixedMillisecond65.peg(calendar71);
        java.util.Date date73 = fixedMillisecond65.getTime();
        org.jfree.data.time.Day day74 = new org.jfree.data.time.Day(date73);
        org.jfree.data.time.SerialDate serialDate75 = org.jfree.data.time.SerialDate.createInstance(date73);
        java.lang.String str76 = serialDate75.getDescription();
        serialDate75.setDescription("ERROR : Relative To String");
        org.jfree.data.time.Day day79 = new org.jfree.data.time.Day(serialDate75);
        org.jfree.data.time.SerialDate serialDate81 = org.jfree.data.time.SerialDate.createInstance(3);
        boolean boolean82 = spreadsheetDate1.isInRange(serialDate75, serialDate81);
        org.junit.Assert.assertNull(class12);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1546329600000L + "'", long28 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem40);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(timeSeries43);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNull(timeSeriesDataItem66);
        org.junit.Assert.assertNotNull(date67);
        org.junit.Assert.assertNotNull(date68);
        org.junit.Assert.assertNull(timeSeriesDataItem70);
        org.junit.Assert.assertNotNull(date73);
        org.junit.Assert.assertNotNull(serialDate75);
        org.junit.Assert.assertNull(str76);
        org.junit.Assert.assertNotNull(serialDate81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + true + "'", boolean82 == true);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-460), "October", "2019", class3);
        int int5 = timeSeries4.getItemCount();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 4);
        timeSeries4.setKey((java.lang.Comparable) fixedMillisecond9);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class12);
        timeSeries13.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries13.setDomainDescription("");
        java.lang.Class class18 = timeSeries13.getTimePeriodClass();
        timeSeries13.clear();
        java.lang.Class class23 = null;
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class23);
        timeSeries24.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener26 = null;
        timeSeries24.addPropertyChangeListener(propertyChangeListener26);
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries24.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        int int33 = year31.compareTo((java.lang.Object) "");
        long long34 = year31.getFirstMillisecond();
        int int35 = timeSeries24.getIndex((org.jfree.data.time.RegularTimePeriod) year31);
        java.lang.Class class39 = null;
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class39);
        timeSeries40.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener42 = null;
        timeSeries40.addPropertyChangeListener(propertyChangeListener42);
        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = timeSeries40.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond45);
        java.util.Date date47 = fixedMillisecond45.getEnd();
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date47);
        org.jfree.data.time.TimeSeries timeSeries49 = timeSeries13.createCopy((org.jfree.data.time.RegularTimePeriod) year31, (org.jfree.data.time.RegularTimePeriod) day48);
        org.jfree.data.time.SerialDate serialDate50 = day48.getSerialDate();
        java.util.Date date51 = day48.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day48, (java.lang.Number) 1900);
        java.lang.Class class57 = null;
        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class57);
        timeSeries58.clear();
        java.lang.Class class63 = null;
        org.jfree.data.time.TimeSeries timeSeries64 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class63);
        timeSeries64.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener66 = null;
        timeSeries64.addPropertyChangeListener(propertyChangeListener66);
        org.jfree.data.time.FixedMillisecond fixedMillisecond69 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem70 = timeSeries64.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond69);
        java.util.Date date71 = fixedMillisecond69.getEnd();
        org.jfree.data.time.Year year72 = new org.jfree.data.time.Year();
        long long73 = year72.getLastMillisecond();
        boolean boolean74 = fixedMillisecond69.equals((java.lang.Object) year72);
        int int76 = fixedMillisecond69.compareTo((java.lang.Object) 1577865599999L);
        java.lang.Number number77 = timeSeries58.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond69);
        boolean boolean78 = day48.equals((java.lang.Object) timeSeries58);
        java.lang.Object obj79 = timeSeries58.clone();
        boolean boolean80 = fixedMillisecond9.equals(obj79);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(class18);
        org.junit.Assert.assertNull(timeSeriesDataItem30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1546329600000L + "'", long34 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem46);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(timeSeries49);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNull(timeSeriesDataItem70);
        org.junit.Assert.assertNotNull(date71);
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 1577865599999L + "'", long73 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 1 + "'", int76 == 1);
        org.junit.Assert.assertNull(number77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(obj79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        long long2 = year1.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year1.previous();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod3, "", "org.jfree.data.general.SeriesChangeEvent[source=SerialDate.weekInMonthToString(): invalid code.]", class8);
        java.lang.Object obj10 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Aug", class8);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(class8);
        org.junit.Assert.assertNull(obj10);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class6);
        timeSeries7.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries7.setDomainDescription("");
        java.lang.Class class12 = timeSeries7.getTimePeriodClass();
        timeSeries7.clear();
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class17);
        timeSeries18.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timeSeries18.addPropertyChangeListener(propertyChangeListener20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries18.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        int int27 = year25.compareTo((java.lang.Object) "");
        long long28 = year25.getFirstMillisecond();
        int int29 = timeSeries18.getIndex((org.jfree.data.time.RegularTimePeriod) year25);
        java.lang.Class class33 = null;
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class33);
        timeSeries34.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener36 = null;
        timeSeries34.addPropertyChangeListener(propertyChangeListener36);
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries34.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39);
        java.util.Date date41 = fixedMillisecond39.getEnd();
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(date41);
        org.jfree.data.time.TimeSeries timeSeries43 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) year25, (org.jfree.data.time.RegularTimePeriod) day42);
        org.jfree.data.time.SerialDate serialDate44 = day42.getSerialDate();
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.addMonths(29, serialDate44);
        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(3, serialDate45);
        java.lang.String str47 = serialDate46.getDescription();
        org.jfree.data.time.SerialDate serialDate48 = org.jfree.data.time.SerialDate.addMonths((int) (short) 100, serialDate46);
        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.addDays(0, serialDate46);
        java.lang.String str50 = serialDate49.getDescription();
        org.jfree.data.time.SerialDate serialDate51 = org.jfree.data.time.SerialDate.addMonths(12, serialDate49);
        try {
            org.jfree.data.time.SerialDate serialDate53 = serialDate51.getPreviousDayOfWeek(29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(class12);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1546329600000L + "'", long28 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem40);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(timeSeries43);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertNull(str47);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertNull(str50);
        org.junit.Assert.assertNotNull(serialDate51);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(13);
        int int2 = spreadsheetDate1.getMonth();
        java.lang.Object obj3 = null;
        try {
            int int4 = spreadsheetDate1.compareTo(obj3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str5 = timeSeries2.getDescription();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getLastMillisecond();
        long long8 = year6.getSerialIndex();
        int int9 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) year6);
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class17);
        java.lang.Class<?> wildcardClass19 = timeSeries18.getClass();
        java.util.Date date20 = null;
        java.util.TimeZone timeZone21 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date20, timeZone21);
        java.lang.ClassLoader classLoader23 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass19);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2, (java.lang.Class) wildcardClass19);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, "ThreadContext", "org.jfree.data.general.SeriesException: ", (java.lang.Class) wildcardClass19);
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year6, "Following", "Fourth", (java.lang.Class) wildcardClass19);
        java.lang.Class class30 = null;
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class30);
        timeSeries31.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener33 = null;
        timeSeries31.addPropertyChangeListener(propertyChangeListener33);
        boolean boolean35 = timeSeries31.isEmpty();
        boolean boolean36 = timeSeries31.isEmpty();
        java.util.Collection collection37 = timeSeries26.getTimePeriodsUniqueToOtherSeries(timeSeries31);
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.Class class40 = timeSeries39.getTimePeriodClass();
        java.lang.Class class41 = timeSeries39.getTimePeriodClass();
        java.lang.String str42 = timeSeries39.getRangeDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener43 = null;
        timeSeries39.removeChangeListener(seriesChangeListener43);
        timeSeries39.setMaximumItemCount(100);
        org.jfree.data.time.TimeSeries timeSeries47 = timeSeries31.addAndOrUpdate(timeSeries39);
        timeSeries31.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str5.equals("SerialDate.weekInMonthToString(): invalid code."));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(classLoader23);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(collection37);
        org.junit.Assert.assertNotNull(class40);
        org.junit.Assert.assertNotNull(class41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "Value" + "'", str42.equals("Value"));
        org.junit.Assert.assertNotNull(timeSeries47);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date5 = fixedMillisecond4.getTime();
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5, timeZone6);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date2, timeZone6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
        long long10 = day8.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546415999999L + "'", long10 == 1546415999999L);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        int int13 = year11.compareTo((java.lang.Object) "");
        long long14 = year11.getFirstMillisecond();
        int int15 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) year11);
        java.lang.String str16 = timeSeries4.getDomainDescription();
        java.util.Collection collection17 = timeSeries4.getTimePeriods();
        int int18 = timeSeries4.getMaximumItemCount();
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2147483647 + "'", int18 == 2147483647);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        timeSeries1.setDomainDescription("September 2019");
        org.junit.Assert.assertNotNull(class2);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.time.TimePeriodFormatException: ClassContext");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.removeAgedItems(false);
        timeSeries2.setMaximumItemCount((int) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        int int9 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        timeSeries2.setNotify(false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("Wed Dec 31 16:00:00 PST 1969");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond9.previous();
        java.lang.Number number11 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, number11);
        java.util.List list13 = timeSeries4.getItems();
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class15);
        timeSeries16.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries16.setDomainDescription("");
        java.lang.Class class21 = timeSeries16.getTimePeriodClass();
        timeSeries16.clear();
        java.lang.Class class26 = null;
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class26);
        timeSeries27.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timeSeries27.addPropertyChangeListener(propertyChangeListener29);
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries27.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        int int36 = year34.compareTo((java.lang.Object) "");
        long long37 = year34.getFirstMillisecond();
        int int38 = timeSeries27.getIndex((org.jfree.data.time.RegularTimePeriod) year34);
        java.lang.Class class42 = null;
        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class42);
        timeSeries43.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener45 = null;
        timeSeries43.addPropertyChangeListener(propertyChangeListener45);
        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries43.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond48);
        java.util.Date date50 = fixedMillisecond48.getEnd();
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date50);
        org.jfree.data.time.TimeSeries timeSeries52 = timeSeries16.createCopy((org.jfree.data.time.RegularTimePeriod) year34, (org.jfree.data.time.RegularTimePeriod) day51);
        java.lang.Class class55 = null;
        org.jfree.data.time.TimeSeries timeSeries56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class55);
        java.lang.Class<?> wildcardClass57 = timeSeries56.getClass();
        java.util.Date date58 = null;
        java.util.TimeZone timeZone59 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass57, date58, timeZone59);
        java.lang.ClassLoader classLoader61 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass57);
        org.jfree.data.time.TimeSeries timeSeries62 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2, (java.lang.Class) wildcardClass57);
        org.jfree.data.time.TimeSeries timeSeries63 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day51, (java.lang.Class) wildcardClass57);
        timeSeries4.update((org.jfree.data.time.RegularTimePeriod) day51, (java.lang.Number) 11);
        int int66 = day51.getMonth();
        long long67 = day51.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNull(class21);
        org.junit.Assert.assertNull(timeSeriesDataItem33);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1546329600000L + "'", long37 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem49);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertNotNull(timeSeries52);
        org.junit.Assert.assertNotNull(wildcardClass57);
        org.junit.Assert.assertNull(regularTimePeriod60);
        org.junit.Assert.assertNotNull(classLoader61);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 12 + "'", int66 == 12);
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 25568L + "'", long67 == 25568L);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("12-January-1900");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(4);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.String str2 = seriesException1.toString();
        java.lang.String str3 = seriesException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("Value");
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException5.getSuppressed();
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        java.lang.Throwable[] throwableArray8 = seriesException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str2.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str3.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray8);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 1);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond1.next();
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond1.getLastMillisecond(calendar6);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(2);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-459) + "'", int1 == (-459));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class4);
        timeSeries5.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries5.setDomainDescription("");
        java.lang.Class class10 = timeSeries5.getTimePeriodClass();
        timeSeries5.clear();
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class15);
        timeSeries16.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timeSeries16.addPropertyChangeListener(propertyChangeListener18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries16.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        int int25 = year23.compareTo((java.lang.Object) "");
        long long26 = year23.getFirstMillisecond();
        int int27 = timeSeries16.getIndex((org.jfree.data.time.RegularTimePeriod) year23);
        java.lang.Class class31 = null;
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class31);
        timeSeries32.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener34 = null;
        timeSeries32.addPropertyChangeListener(propertyChangeListener34);
        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries32.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond37);
        java.util.Date date39 = fixedMillisecond37.getEnd();
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date39);
        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) year23, (org.jfree.data.time.RegularTimePeriod) day40);
        org.jfree.data.time.SerialDate serialDate42 = day40.getSerialDate();
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.addMonths(29, serialDate42);
        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.addYears(2019, serialDate43);
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.addDays(2, serialDate43);
        try {
            org.jfree.data.time.SerialDate serialDate47 = serialDate43.getFollowingDayOfWeek((-451));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(class10);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1546329600000L + "'", long26 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem38);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(timeSeries41);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(serialDate45);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class5);
        timeSeries6.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries6.setDomainDescription("");
        java.lang.Class class11 = timeSeries6.getTimePeriodClass();
        timeSeries6.clear();
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class16);
        timeSeries17.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timeSeries17.addPropertyChangeListener(propertyChangeListener19);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries17.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        int int26 = year24.compareTo((java.lang.Object) "");
        long long27 = year24.getFirstMillisecond();
        int int28 = timeSeries17.getIndex((org.jfree.data.time.RegularTimePeriod) year24);
        java.lang.Class class32 = null;
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class32);
        timeSeries33.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener35 = null;
        timeSeries33.addPropertyChangeListener(propertyChangeListener35);
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries33.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond38);
        java.util.Date date40 = fixedMillisecond38.getEnd();
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date40);
        org.jfree.data.time.TimeSeries timeSeries42 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) year24, (org.jfree.data.time.RegularTimePeriod) day41);
        org.jfree.data.time.SerialDate serialDate43 = day41.getSerialDate();
        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.addMonths(29, serialDate43);
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(3, serialDate44);
        java.lang.String str46 = serialDate45.getDescription();
        org.jfree.data.time.SerialDate serialDate47 = org.jfree.data.time.SerialDate.addMonths((int) (short) 100, serialDate45);
        java.lang.String str48 = serialDate45.getDescription();
        org.jfree.data.time.SerialDate serialDate50 = serialDate45.getFollowingDayOfWeek(3);
        org.jfree.data.time.SerialDate serialDate51 = org.jfree.data.time.SerialDate.addMonths((int) 'a', serialDate50);
        org.junit.Assert.assertNull(class11);
        org.junit.Assert.assertNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1546329600000L + "'", long27 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem39);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(timeSeries42);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertNull(str46);
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertNotNull(serialDate51);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        java.lang.Class<?> wildcardClass3 = timeSeries2.getClass();
        java.lang.Class class7 = null;
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class7);
        timeSeries8.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries8.addPropertyChangeListener(propertyChangeListener10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries8.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        int int17 = year15.compareTo((java.lang.Object) "");
        long long18 = year15.getFirstMillisecond();
        int int19 = timeSeries8.getIndex((org.jfree.data.time.RegularTimePeriod) year15);
        java.lang.String str20 = timeSeries8.getDomainDescription();
        timeSeries8.setMaximumItemCount((int) (byte) 10);
        long long23 = timeSeries8.getMaximumItemAge();
        java.lang.Class class27 = null;
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class27);
        timeSeries28.clear();
        java.lang.Class class33 = null;
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class33);
        timeSeries34.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener36 = null;
        timeSeries34.addPropertyChangeListener(propertyChangeListener36);
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries34.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39);
        java.util.Date date41 = fixedMillisecond39.getEnd();
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
        long long43 = year42.getLastMillisecond();
        boolean boolean44 = fixedMillisecond39.equals((java.lang.Object) year42);
        int int46 = fixedMillisecond39.compareTo((java.lang.Object) 1577865599999L);
        java.lang.Number number47 = timeSeries28.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, 10.0d);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (double) 2019L);
        timeSeries2.setNotify(false);
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year();
        long long55 = year54.getLastMillisecond();
        java.util.Date date56 = year54.getStart();
        org.jfree.data.time.Month month57 = new org.jfree.data.time.Month(date56);
        int int58 = month57.getYearValue();
        java.lang.String str59 = month57.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem60 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) month57);
        int int61 = month57.getMonth();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1546329600000L + "'", long18 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hi!" + "'", str20.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 9223372036854775807L + "'", long23 == 9223372036854775807L);
        org.junit.Assert.assertNull(timeSeriesDataItem40);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1577865599999L + "'", long43 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
        org.junit.Assert.assertNull(number47);
        org.junit.Assert.assertNull(timeSeriesDataItem49);
        org.junit.Assert.assertNull(timeSeriesDataItem51);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1577865599999L + "'", long55 == 1577865599999L);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 2019 + "'", int58 == 2019);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "January 2019" + "'", str59.equals("January 2019"));
        org.junit.Assert.assertNotNull(timeSeriesDataItem60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1 + "'", int61 == 1);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class1);
        timeSeries2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries2.setDomainDescription("");
        java.lang.Class class7 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class12);
        timeSeries13.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        int int22 = year20.compareTo((java.lang.Object) "");
        long long23 = year20.getFirstMillisecond();
        int int24 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) year20);
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class28);
        timeSeries29.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timeSeries29.addPropertyChangeListener(propertyChangeListener31);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
        java.util.Date date36 = fixedMillisecond34.getEnd();
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date36);
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) year20, (org.jfree.data.time.RegularTimePeriod) day37);
        long long39 = day37.getFirstMillisecond();
        boolean boolean41 = day37.equals((java.lang.Object) 1577865599999L);
        long long42 = day37.getSerialIndex();
        java.util.Date date43 = day37.getStart();
        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.createInstance(date43);
        try {
            org.jfree.data.time.SerialDate serialDate46 = serialDate44.getNearestDayOfWeek(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1546329600000L + "'", long23 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeSeries38);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-57600000L) + "'", long39 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 25568L + "'", long42 == 25568L);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(serialDate44);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((-451), (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -451");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        int int4 = month3.getMonth();
        int int5 = month3.getYearValue();
        java.lang.String str6 = month3.toString();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getLastMillisecond();
        java.util.Date date9 = year7.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year7.next();
        long long11 = year7.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year7.previous();
        java.lang.Class<?> wildcardClass13 = regularTimePeriod12.getClass();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month3, (java.lang.Class) wildcardClass13);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "January 2019" + "'", str6.equals("January 2019"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(13);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        long long3 = year2.getLastMillisecond();
        java.util.Date date4 = year2.getStart();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        boolean boolean7 = spreadsheetDate1.isOnOrBefore(serialDate5);
        int int8 = spreadsheetDate1.toSerial();
        int int9 = spreadsheetDate1.getDayOfWeek();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 13 + "'", int8 == 13);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class2);
        timeSeries3.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries3.setDomainDescription("");
        java.lang.Class class8 = timeSeries3.getTimePeriodClass();
        timeSeries3.clear();
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class13);
        timeSeries14.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries14.addPropertyChangeListener(propertyChangeListener16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries14.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        int int23 = year21.compareTo((java.lang.Object) "");
        long long24 = year21.getFirstMillisecond();
        int int25 = timeSeries14.getIndex((org.jfree.data.time.RegularTimePeriod) year21);
        java.lang.Class class29 = null;
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class29);
        timeSeries30.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener32 = null;
        timeSeries30.addPropertyChangeListener(propertyChangeListener32);
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries30.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
        java.util.Date date37 = fixedMillisecond35.getEnd();
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date37);
        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year21, (org.jfree.data.time.RegularTimePeriod) day38);
        java.lang.Class class42 = null;
        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class42);
        java.lang.Class<?> wildcardClass44 = timeSeries43.getClass();
        java.util.Date date45 = null;
        java.util.TimeZone timeZone46 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass44, date45, timeZone46);
        java.lang.ClassLoader classLoader48 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass44);
        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2, (java.lang.Class) wildcardClass44);
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day38, (java.lang.Class) wildcardClass44);
        java.net.URL uRL51 = org.jfree.chart.util.ObjectUtilities.getResource("org.jfree.data.general.SeriesChangeEvent[source=SerialDate.weekInMonthToString(): invalid code.]", (java.lang.Class) wildcardClass44);
        java.lang.Class class52 = null;
        java.lang.Class class56 = null;
        org.jfree.data.time.TimeSeries timeSeries57 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class56);
        timeSeries57.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener59 = null;
        timeSeries57.addPropertyChangeListener(propertyChangeListener59);
        org.jfree.data.time.FixedMillisecond fixedMillisecond62 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem63 = timeSeries57.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond62);
        java.util.Date date64 = fixedMillisecond62.getEnd();
        java.util.TimeZone timeZone65 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = org.jfree.data.time.RegularTimePeriod.createInstance(class52, date64, timeZone65);
        org.jfree.data.time.FixedMillisecond fixedMillisecond67 = new org.jfree.data.time.FixedMillisecond(date64);
        org.jfree.data.time.Year year68 = new org.jfree.data.time.Year(date64);
        org.jfree.data.time.Year year69 = new org.jfree.data.time.Year();
        long long70 = year69.getLastMillisecond();
        java.util.Date date71 = year69.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = year69.next();
        java.util.Date date73 = year69.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond74 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date75 = fixedMillisecond74.getTime();
        java.util.TimeZone timeZone76 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year77 = new org.jfree.data.time.Year(date75, timeZone76);
        org.jfree.data.time.Month month78 = new org.jfree.data.time.Month(date73, timeZone76);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass44, date64, timeZone76);
        java.lang.Class class80 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass44);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1546329600000L + "'", long24 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(timeSeries39);
        org.junit.Assert.assertNotNull(wildcardClass44);
        org.junit.Assert.assertNull(regularTimePeriod47);
        org.junit.Assert.assertNotNull(classLoader48);
        org.junit.Assert.assertNull(uRL51);
        org.junit.Assert.assertNull(timeSeriesDataItem63);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertNull(regularTimePeriod66);
        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 1577865599999L + "'", long70 == 1577865599999L);
        org.junit.Assert.assertNotNull(date71);
        org.junit.Assert.assertNotNull(regularTimePeriod72);
        org.junit.Assert.assertNotNull(date73);
        org.junit.Assert.assertNotNull(date75);
        org.junit.Assert.assertNotNull(timeZone76);
        org.junit.Assert.assertNull(regularTimePeriod79);
        org.junit.Assert.assertNotNull(class80);
    }
}

