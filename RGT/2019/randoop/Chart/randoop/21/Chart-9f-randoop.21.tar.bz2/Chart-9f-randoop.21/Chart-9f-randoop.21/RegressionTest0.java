import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        int int0 = org.jfree.data.time.SerialDate.THURSDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod0 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod0, (java.lang.Number) 1.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(0, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_SECOND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_BOTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        java.lang.String[] strArray0 = org.jfree.data.time.SerialDate.getMonths();
        org.junit.Assert.assertNotNull(strArray0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        int int0 = org.jfree.data.time.SerialDate.FOLLOWING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addDays(0, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((int) (short) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-460) + "'", int1 == (-460));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addMonths((int) (short) 10, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        int int0 = org.jfree.data.time.SerialDate.FIRST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 0, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        int int0 = org.jfree.data.time.SerialDate.MAXIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9999 + "'", int0 == 9999);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
        timeSeries4.setMaximumItemCount((int) (byte) 0);
        boolean boolean7 = timeSeries4.getNotify();
        try {
            timeSeries4.delete(5, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(100);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-460) + "'", int1 == (-460));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("ERROR : Relative To String");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((int) (short) 1);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "January" + "'", str1.equals("January"));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        int int0 = org.jfree.data.time.SerialDate.FRIDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        int int0 = org.jfree.data.time.SerialDate.MINIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1900 + "'", int0 == 1900);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
        timeSeries4.setMaximumItemCount((int) (byte) 0);
        boolean boolean7 = timeSeries4.getNotify();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        try {
            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) day8, (double) 2, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (byte) 0, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
        timeSeries4.setMaximumItemCount((int) (byte) 0);
        boolean boolean7 = timeSeries4.getNotify();
        timeSeries4.setKey((java.lang.Comparable) 10.0d);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries12 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) day10, regularTimePeriod11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'end' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        int int0 = org.jfree.data.time.SerialDate.LAST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

//    @Test
//    public void test027() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test027");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setMaximumItemCount((int) (byte) 0);
//        boolean boolean7 = timeSeries4.getNotify();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.lang.String str9 = day8.toString();
//        try {
//            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) day8, (double) (byte) 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("10-June-2019");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(2, true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Feb" + "'", str2.equals("Feb"));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

//    @Test
//    public void test032() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test032");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day5);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.util.Date date9 = day8.getEnd();
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date9);
//        try {
//            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) (short) -1);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date9);
//    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(0, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        int int0 = org.jfree.data.time.SerialDate.MONDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        int int0 = org.jfree.data.time.SerialDate.NEAREST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (short) 0, (int) ' ', (-460));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_FIRST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_LOWER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(10);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

//    @Test
//    public void test042() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test042");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day5);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = null;
//        try {
//            timeSeries4.add(timeSeriesDataItem8, false);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = month2.getMiddleMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        int int0 = org.jfree.data.time.SerialDate.THIRD_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(0, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths(true);
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(11, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        java.util.TimeZone timeZone2 = null;
        try {
            org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date1, timeZone2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        java.util.TimeZone timeZone3 = null;
        try {
            org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date1, timeZone3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
        timeSeries4.setMaximumItemCount((int) (byte) 0);
        boolean boolean7 = timeSeries4.getNotify();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.addOrUpdate(regularTimePeriod8, (double) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(1, (int) (byte) 0, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(0, (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
        timeSeries4.setMaximumItemCount((int) (byte) 0);
        boolean boolean7 = timeSeries4.getNotify();
        timeSeries4.setKey((java.lang.Comparable) 10.0d);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = null;
        try {
            timeSeries4.add(timeSeriesDataItem10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addMonths(1900, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(8, (int) (byte) 100, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        java.util.Calendar calendar2 = null;
        try {
            day0.peg(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

//    @Test
//    public void test059() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test059");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        java.util.Date date2 = day0.getStart();
//        long long3 = day0.getLastMillisecond();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = day0.getFirstMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560236399999L + "'", long3 == 1560236399999L);
//    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addYears(1, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
        timeSeries4.setDomainDescription("hi!");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        java.util.Date date8 = day7.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) 0);
        timeSeries4.setDescription("");
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries4.getDataItem(9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9999, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
        timeSeries4.setDomainDescription("hi!");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        java.util.Date date8 = day7.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) 0);
        java.lang.Object obj11 = null;
        boolean boolean12 = timeSeries4.equals(obj11);
        try {
            timeSeries4.delete(100, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(1900, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1900");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(9);
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(9999, serialDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
        timeSeries4.setMaximumItemCount((int) (byte) 0);
        boolean boolean7 = timeSeries4.getNotify();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class11);
        timeSeries12.setDomainDescription("hi!");
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        java.util.Date date16 = day15.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day15, (java.lang.Number) 0);
        java.lang.Object obj19 = null;
        boolean boolean20 = timeSeries12.equals(obj19);
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries4.addAndOrUpdate(timeSeries12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = null;
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
        java.util.Date date24 = day23.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond(date24);
        try {
            org.jfree.data.time.TimeSeries timeSeries26 = timeSeries4.createCopy(regularTimePeriod22, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'start' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(timeSeries21);
        org.junit.Assert.assertNotNull(date24);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("Feb");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("January");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(9);
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (byte) 100, serialDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
    }

//    @Test
//    public void test070() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test070");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day5);
//        timeSeries4.fireSeriesChanged();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.util.Date date10 = day9.getEnd();
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
//        java.lang.Number number12 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month11);
//        java.lang.Class class16 = null;
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class16);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        java.lang.String str19 = day18.toString();
//        timeSeries17.delete((org.jfree.data.time.RegularTimePeriod) day18);
//        boolean boolean21 = timeSeries4.equals((java.lang.Object) day18);
//        try {
//            org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = timeSeries4.getNextTimePeriod();
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNull(number12);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "10-June-2019" + "'", str19.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

//    @Test
//    public void test072() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test072");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day5);
//        timeSeries4.setRangeDescription("January");
//        timeSeries4.setMaximumItemCount((int) (short) 0);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        int int0 = org.jfree.data.time.SerialDate.PRECEDING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

//    @Test
//    public void test075() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test075");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day5);
//        timeSeries4.fireSeriesChanged();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.util.Date date10 = day9.getEnd();
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
//        java.lang.Number number12 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month11);
//        java.lang.Class class16 = null;
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class16);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        java.lang.String str19 = day18.toString();
//        timeSeries17.delete((org.jfree.data.time.RegularTimePeriod) day18);
//        boolean boolean21 = timeSeries4.equals((java.lang.Object) day18);
//        java.util.Calendar calendar22 = null;
//        try {
//            long long23 = day18.getLastMillisecond(calendar22);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNull(number12);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "10-June-2019" + "'", str19.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
        timeSeries4.setDomainDescription("hi!");
        java.lang.Object obj7 = timeSeries4.clone();
        timeSeries4.setRangeDescription("10-June-2019");
        try {
            java.lang.Number number11 = timeSeries4.getValue(1900);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1900, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(0, 0, (-460));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test078() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test078");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day5);
//        timeSeries4.fireSeriesChanged();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.util.Date date10 = day9.getEnd();
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
//        java.lang.Number number12 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month11);
//        try {
//            org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeries4.getNextTimePeriod();
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNull(number12);
//    }

//    @Test
//    public void test079() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test079");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        java.util.Calendar calendar2 = null;
//        try {
//            long long3 = day0.getFirstMillisecond(calendar2);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
        timeSeries4.setDomainDescription("hi!");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        java.util.Date date8 = day7.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries4.getDataItem(regularTimePeriod11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        int int0 = org.jfree.data.time.SerialDate.SUNDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
        timeSeries4.setMaximumItemCount((int) (byte) 0);
        boolean boolean7 = timeSeries4.getNotify();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class11);
        timeSeries12.setDomainDescription("hi!");
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        java.util.Date date16 = day15.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day15, (java.lang.Number) 0);
        java.lang.Object obj19 = null;
        boolean boolean20 = timeSeries12.equals(obj19);
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries4.addAndOrUpdate(timeSeries12);
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(9, (int) (byte) 0);
        try {
            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) month24, (java.lang.Number) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(timeSeries21);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560150000000L);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        java.lang.String str3 = month2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        long long5 = month2.getMiddleMillisecond();
        long long6 = month2.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560668399999L + "'", long5 == 1560668399999L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1559372400000L + "'", long6 == 1559372400000L);
    }

//    @Test
//    public void test085() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test085");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setDomainDescription("hi!");
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        java.util.Date date8 = day7.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) 0);
//        long long11 = day7.getLastMillisecond();
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(timeSeriesDataItem10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560236399999L + "'", long11 == 1560236399999L);
//    }

//    @Test
//    public void test086() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test086");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setMaximumItemCount((int) (byte) 0);
//        boolean boolean7 = timeSeries4.getNotify();
//        java.util.List list8 = timeSeries4.getItems();
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class12);
//        timeSeries13.setMaximumItemCount((int) (byte) 0);
//        boolean boolean16 = timeSeries13.getNotify();
//        java.util.List list17 = timeSeries13.getItems();
//        java.util.Collection collection18 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries13);
//        java.util.List list19 = timeSeries4.getItems();
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        java.util.Date date21 = day20.getEnd();
//        int int23 = day20.compareTo((java.lang.Object) (-1L));
//        java.lang.Class class27 = null;
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class27);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        java.lang.String str30 = day29.toString();
//        timeSeries28.delete((org.jfree.data.time.RegularTimePeriod) day29);
//        timeSeries28.fireSeriesChanged();
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        java.util.Date date34 = day33.getEnd();
//        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(date34);
//        java.lang.Number number36 = timeSeries28.getValue((org.jfree.data.time.RegularTimePeriod) month35);
//        java.lang.Class class40 = null;
//        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class40);
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
//        java.lang.String str43 = day42.toString();
//        timeSeries41.delete((org.jfree.data.time.RegularTimePeriod) day42);
//        boolean boolean45 = timeSeries28.equals((java.lang.Object) day42);
//        boolean boolean46 = day20.equals((java.lang.Object) timeSeries28);
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
//        java.lang.String str48 = day47.toString();
//        java.util.Date date49 = day47.getStart();
//        long long50 = day47.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) day20, (org.jfree.data.time.RegularTimePeriod) day47);
//        timeSeries4.setKey((java.lang.Comparable) 0L);
//        try {
//            timeSeries4.removeAgedItems((long) (short) -1, true);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(list8);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNotNull(list17);
//        org.junit.Assert.assertNotNull(collection18);
//        org.junit.Assert.assertNotNull(list19);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "10-June-2019" + "'", str30.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNull(number36);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "10-June-2019" + "'", str43.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "10-June-2019" + "'", str48.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1560236399999L + "'", long50 == 1560236399999L);
//        org.junit.Assert.assertNotNull(timeSeries51);
//    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate5 = serialDate2.getEndOfCurrentMonth(serialDate4);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate4);
        try {
            org.jfree.data.time.SerialDate serialDate8 = serialDate6.getNearestDayOfWeek(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((-1));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(3, 0, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        java.lang.String str3 = month2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        long long5 = month2.getMiddleMillisecond();
        java.util.Calendar calendar6 = null;
        try {
            month2.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560668399999L + "'", long5 == 1560668399999L);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        int int0 = org.jfree.data.time.SerialDate.FOURTH_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate4 = serialDate1.getEndOfCurrentMonth(serialDate3);
        try {
            org.jfree.data.time.SerialDate serialDate6 = serialDate1.getFollowingDayOfWeek((-460));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("June 2019");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
        timeSeries4.setMaximumItemCount((int) (byte) 0);
        try {
            timeSeries4.update(0, (java.lang.Number) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (2) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(1900);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 0, 0, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        java.lang.String str3 = month2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (double) (short) 100);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        java.util.Date date8 = day7.getEnd();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date8);
        java.lang.String str10 = month9.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month9, (double) (short) 100);
        int int14 = timeSeriesDataItem6.compareTo((java.lang.Object) month9);
        java.lang.String str15 = month9.toString();
        java.util.Calendar calendar16 = null;
        try {
            long long17 = month9.getLastMillisecond(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "June 2019" + "'", str10.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "June 2019" + "'", str15.equals("June 2019"));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        try {
            org.jfree.data.time.SerialDate serialDate3 = spreadsheetDate1.getPreviousDayOfWeek((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_NONE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

//    @Test
//    public void test104() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test104");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        java.util.Date date2 = day0.getStart();
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
//        java.lang.Object obj4 = null;
//        int int5 = year3.compareTo(obj4);
//        int int6 = year3.getYear();
//        java.util.Calendar calendar7 = null;
//        try {
//            year3.peg(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//    }

//    @Test
//    public void test105() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test105");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        int int3 = day0.compareTo((java.lang.Object) (-1L));
//        java.lang.Class class7 = null;
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class7);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.lang.String str10 = day9.toString();
//        timeSeries8.delete((org.jfree.data.time.RegularTimePeriod) day9);
//        timeSeries8.fireSeriesChanged();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.util.Date date14 = day13.getEnd();
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
//        java.lang.Number number16 = timeSeries8.getValue((org.jfree.data.time.RegularTimePeriod) month15);
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class20);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.lang.String str23 = day22.toString();
//        timeSeries21.delete((org.jfree.data.time.RegularTimePeriod) day22);
//        boolean boolean25 = timeSeries8.equals((java.lang.Object) day22);
//        boolean boolean26 = day0.equals((java.lang.Object) timeSeries8);
//        timeSeries8.clear();
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        java.util.Date date29 = day28.getEnd();
//        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month(date29);
//        java.lang.String str31 = month30.toString();
//        int int32 = month30.getMonth();
//        try {
//            timeSeries8.add((org.jfree.data.time.RegularTimePeriod) month30, (java.lang.Number) 1546329600000L, false);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "10-June-2019" + "'", str23.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "June 2019" + "'", str31.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 6 + "'", int32 == 6);
//    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-460) + "'", int1 == (-460));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        java.text.DateFormatSymbols dateFormatSymbols0 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        org.junit.Assert.assertNotNull(dateFormatSymbols0);
    }

//    @Test
//    public void test108() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test108");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        java.util.Date date2 = day0.getStart();
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year3.previous();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = year3.getLastMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7, "10-June-2019", "ERROR : Relative To String", class3);
        java.lang.String str5 = timeSeries4.getRangeDescription();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ERROR : Relative To String" + "'", str5.equals("ERROR : Relative To String"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(1);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Sunday" + "'", str1.equals("Sunday"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        int int0 = org.jfree.data.time.SerialDate.SECOND_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate5 = serialDate2.getEndOfCurrentMonth(serialDate4);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addDays(0, serialDate5);
        java.lang.String str7 = serialDate6.getDescription();
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate7 = serialDate4.getEndOfCurrentMonth(serialDate6);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean11 = spreadsheetDate1.isInRange(serialDate6, (org.jfree.data.time.SerialDate) spreadsheetDate10);
        try {
            org.jfree.data.time.SerialDate serialDate13 = spreadsheetDate1.getPreviousDayOfWeek((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

//    @Test
//    public void test115() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test115");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        java.util.Date date2 = day0.getStart();
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
//        java.lang.Object obj4 = null;
//        int int5 = year3.compareTo(obj4);
//        long long6 = year3.getSerialIndex();
//        java.util.Calendar calendar7 = null;
//        try {
//            year3.peg(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
//    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(6);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
        timeSeries4.setMaximumItemCount((int) (byte) 0);
        boolean boolean7 = timeSeries4.getNotify();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class11);
        timeSeries12.setDomainDescription("hi!");
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        java.util.Date date16 = day15.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day15, (java.lang.Number) 0);
        java.lang.Object obj19 = null;
        boolean boolean20 = timeSeries12.equals(obj19);
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries4.addAndOrUpdate(timeSeries12);
        try {
            timeSeries4.removeAgedItems((long) (short) 10, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(timeSeries21);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        java.lang.String str3 = month2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (double) (short) 100);
        long long7 = month2.getMiddleMillisecond();
        long long8 = month2.getSerialIndex();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560668399999L + "'", long7 == 1560668399999L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 24234L + "'", long8 == 24234L);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate5 = serialDate2.getEndOfCurrentMonth(serialDate4);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate4);
        try {
            org.jfree.data.time.SerialDate serialDate8 = serialDate6.getPreviousDayOfWeek(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
    }

//    @Test
//    public void test120() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test120");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day5);
//        timeSeries4.setRangeDescription("January");
//        java.lang.Class class13 = null;
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class13);
//        timeSeries14.setMaximumItemCount((int) (byte) 0);
//        boolean boolean17 = timeSeries14.getNotify();
//        java.util.List list18 = timeSeries14.getItems();
//        java.lang.Class class22 = null;
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class22);
//        timeSeries23.setMaximumItemCount((int) (byte) 0);
//        boolean boolean26 = timeSeries23.getNotify();
//        java.util.List list27 = timeSeries23.getItems();
//        java.util.Collection collection28 = timeSeries14.getTimePeriodsUniqueToOtherSeries(timeSeries23);
//        java.util.List list29 = timeSeries14.getItems();
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        java.util.Date date31 = day30.getEnd();
//        int int33 = day30.compareTo((java.lang.Object) (-1L));
//        java.lang.Class class37 = null;
//        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class37);
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day();
//        java.lang.String str40 = day39.toString();
//        timeSeries38.delete((org.jfree.data.time.RegularTimePeriod) day39);
//        timeSeries38.fireSeriesChanged();
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
//        java.util.Date date44 = day43.getEnd();
//        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month(date44);
//        java.lang.Number number46 = timeSeries38.getValue((org.jfree.data.time.RegularTimePeriod) month45);
//        java.lang.Class class50 = null;
//        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class50);
//        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day();
//        java.lang.String str53 = day52.toString();
//        timeSeries51.delete((org.jfree.data.time.RegularTimePeriod) day52);
//        boolean boolean55 = timeSeries38.equals((java.lang.Object) day52);
//        boolean boolean56 = day30.equals((java.lang.Object) timeSeries38);
//        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day();
//        java.lang.String str58 = day57.toString();
//        java.util.Date date59 = day57.getStart();
//        long long60 = day57.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries61 = timeSeries14.createCopy((org.jfree.data.time.RegularTimePeriod) day30, (org.jfree.data.time.RegularTimePeriod) day57);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = null;
//        try {
//            org.jfree.data.time.TimeSeries timeSeries63 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) day57, regularTimePeriod62);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'end' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertNotNull(list18);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
//        org.junit.Assert.assertNotNull(list27);
//        org.junit.Assert.assertNotNull(collection28);
//        org.junit.Assert.assertNotNull(list29);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "10-June-2019" + "'", str40.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertNull(number46);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "10-June-2019" + "'", str53.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "10-June-2019" + "'", str58.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date59);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1560236399999L + "'", long60 == 1560236399999L);
//        org.junit.Assert.assertNotNull(timeSeries61);
//    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths(false);
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
        timeSeries4.setMaximumItemCount((int) (byte) 0);
        boolean boolean7 = timeSeries4.getNotify();
        java.util.List list8 = timeSeries4.getItems();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class12);
        timeSeries13.setMaximumItemCount((int) (byte) 0);
        boolean boolean16 = timeSeries13.getNotify();
        java.util.List list17 = timeSeries13.getItems();
        java.util.Collection collection18 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        boolean boolean19 = timeSeries4.isEmpty();
        timeSeries4.setDomainDescription("2019");
        try {
            java.lang.Number number23 = timeSeries4.getValue((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(list17);
        org.junit.Assert.assertNotNull(collection18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
        timeSeries4.setMaximumItemCount((int) (byte) 0);
        boolean boolean7 = timeSeries4.getNotify();
        java.lang.Comparable comparable8 = timeSeries4.getKey();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener9);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries4.getTimePeriod((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0f) + "'", comparable8.equals((-1.0f)));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("ERROR : Relative To String");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        java.lang.String str3 = month2.toString();
        int int4 = month2.getMonth();
        java.util.Calendar calendar5 = null;
        try {
            month2.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(9);
        boolean boolean4 = spreadsheetDate1.isOnOrAfter(serialDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate12 = serialDate9.getEndOfCurrentMonth(serialDate11);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean16 = spreadsheetDate6.isInRange(serialDate11, (org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SerialDate serialDate18 = serialDate11.getPreviousDayOfWeek(7);
        org.jfree.data.time.SerialDate serialDate19 = null;
        try {
            boolean boolean21 = spreadsheetDate1.isInRange(serialDate11, serialDate19, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(serialDate18);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
        timeSeries4.setMaximumItemCount((int) (byte) 0);
        boolean boolean7 = timeSeries4.getNotify();
        java.util.List list8 = timeSeries4.getItems();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class12);
        timeSeries13.setMaximumItemCount((int) (byte) 0);
        boolean boolean16 = timeSeries13.getNotify();
        java.util.List list17 = timeSeries13.getItems();
        java.util.Collection collection18 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        try {
            java.lang.Number number20 = timeSeries13.getValue(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(list17);
        org.junit.Assert.assertNotNull(collection18);
    }

//    @Test
//    public void test128() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test128");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.util.Date date6 = day5.getEnd();
//        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class11);
//        timeSeries12.setMaximumItemCount((int) (byte) 0);
//        boolean boolean15 = timeSeries12.getNotify();
//        timeSeries12.setKey((java.lang.Comparable) 10.0d);
//        java.lang.Class<?> wildcardClass18 = timeSeries12.getClass();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        java.lang.String str20 = day19.toString();
//        java.util.Date date21 = day19.getStart();
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date21);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        java.util.Date date24 = day23.getEnd();
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month(date24);
//        java.lang.String str26 = month25.toString();
//        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean28 = month25.equals((java.lang.Object) timeZone27);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date21, timeZone27);
//        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month(date6, timeZone27);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = null;
//        try {
//            org.jfree.data.time.TimeSeries timeSeries32 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) month30, regularTimePeriod31);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'end' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "10-June-2019" + "'", str20.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "June 2019" + "'", str26.equals("June 2019"));
//        org.junit.Assert.assertNotNull(timeZone27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNull(regularTimePeriod29);
//    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) '4');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test130() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test130");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setMaximumItemCount((int) (byte) 0);
//        boolean boolean7 = timeSeries4.getNotify();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class11);
//        timeSeries12.setDomainDescription("hi!");
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        java.util.Date date16 = day15.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day15, (java.lang.Number) 0);
//        java.lang.Object obj19 = null;
//        boolean boolean20 = timeSeries12.equals(obj19);
//        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries4.addAndOrUpdate(timeSeries12);
//        java.lang.Class class25 = null;
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class25);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        java.lang.String str28 = day27.toString();
//        timeSeries26.delete((org.jfree.data.time.RegularTimePeriod) day27);
//        timeSeries26.fireSeriesChanged();
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        java.util.Date date32 = day31.getEnd();
//        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(date32);
//        java.lang.Number number34 = timeSeries26.getValue((org.jfree.data.time.RegularTimePeriod) month33);
//        int int35 = month33.getMonth();
//        int int36 = month33.getMonth();
//        try {
//            timeSeries4.update((org.jfree.data.time.RegularTimePeriod) month33, (java.lang.Number) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNull(timeSeriesDataItem18);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(timeSeries21);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "10-June-2019" + "'", str28.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNull(number34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 6 + "'", int35 == 6);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 6 + "'", int36 == 6);
//    }

//    @Test
//    public void test131() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test131");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
//        java.util.Date date3 = fixedMillisecond2.getTime();
//        long long4 = fixedMillisecond2.getSerialIndex();
//        long long5 = fixedMillisecond2.getFirstMillisecond();
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond2.getMiddleMillisecond(calendar6);
//        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate13 = serialDate10.getEndOfCurrentMonth(serialDate12);
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate12);
//        boolean boolean15 = fixedMillisecond2.equals((java.lang.Object) serialDate12);
//        try {
//            org.jfree.data.time.SerialDate serialDate17 = serialDate12.getFollowingDayOfWeek((int) 'a');
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560236399999L + "'", long5 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560236399999L + "'", long7 == 1560236399999L);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_UPPER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2958465 + "'", int0 == 2958465);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 100, 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test135() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test135");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day5);
//        timeSeries4.fireSeriesChanged();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.util.Date date10 = day9.getEnd();
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
//        java.lang.Number number12 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month11);
//        int int13 = month11.getMonth();
//        long long14 = month11.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNull(number12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 24234L + "'", long14 == 24234L);
//    }

//    @Test
//    public void test136() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test136");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setMaximumItemCount((int) (byte) 0);
//        boolean boolean7 = timeSeries4.getNotify();
//        java.util.List list8 = timeSeries4.getItems();
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class12);
//        timeSeries13.setMaximumItemCount((int) (byte) 0);
//        boolean boolean16 = timeSeries13.getNotify();
//        java.util.List list17 = timeSeries13.getItems();
//        java.util.Collection collection18 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries13);
//        java.util.List list19 = timeSeries4.getItems();
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        java.util.Date date21 = day20.getEnd();
//        int int23 = day20.compareTo((java.lang.Object) (-1L));
//        java.lang.Class class27 = null;
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class27);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        java.lang.String str30 = day29.toString();
//        timeSeries28.delete((org.jfree.data.time.RegularTimePeriod) day29);
//        timeSeries28.fireSeriesChanged();
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        java.util.Date date34 = day33.getEnd();
//        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(date34);
//        java.lang.Number number36 = timeSeries28.getValue((org.jfree.data.time.RegularTimePeriod) month35);
//        java.lang.Class class40 = null;
//        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class40);
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
//        java.lang.String str43 = day42.toString();
//        timeSeries41.delete((org.jfree.data.time.RegularTimePeriod) day42);
//        boolean boolean45 = timeSeries28.equals((java.lang.Object) day42);
//        boolean boolean46 = day20.equals((java.lang.Object) timeSeries28);
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
//        java.lang.String str48 = day47.toString();
//        java.util.Date date49 = day47.getStart();
//        long long50 = day47.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) day20, (org.jfree.data.time.RegularTimePeriod) day47);
//        timeSeries4.setKey((java.lang.Comparable) 0L);
//        timeSeries4.clear();
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(list8);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNotNull(list17);
//        org.junit.Assert.assertNotNull(collection18);
//        org.junit.Assert.assertNotNull(list19);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "10-June-2019" + "'", str30.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNull(number36);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "10-June-2019" + "'", str43.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "10-June-2019" + "'", str48.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1560236399999L + "'", long50 == 1560236399999L);
//        org.junit.Assert.assertNotNull(timeSeries51);
//    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
        timeSeries4.setMaximumItemCount((int) (byte) 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries4.removeChangeListener(seriesChangeListener7);
        try {
            timeSeries4.update((int) (short) 0, (java.lang.Number) (-1.0f));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 0, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test139() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test139");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        java.util.Date date2 = day0.getStart();
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
//        java.lang.Object obj4 = null;
//        int int5 = year3.compareTo(obj4);
//        java.lang.String str6 = year3.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year3.previous();
//        java.util.Calendar calendar8 = null;
//        try {
//            year3.peg(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((int) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
        timeSeries4.setMaximumItemCount((int) (byte) 0);
        boolean boolean7 = timeSeries4.getNotify();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class11);
        timeSeries12.setDomainDescription("hi!");
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        java.util.Date date16 = day15.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day15, (java.lang.Number) 0);
        java.lang.Object obj19 = null;
        boolean boolean20 = timeSeries12.equals(obj19);
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries4.addAndOrUpdate(timeSeries12);
        timeSeries21.setNotify(true);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
        java.util.Date date25 = day24.getEnd();
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(date25);
        java.lang.String str27 = month26.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = month26.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month26, (double) (short) 100);
        long long31 = month26.getMiddleMillisecond();
        try {
            timeSeries21.add((org.jfree.data.time.RegularTimePeriod) month26, (java.lang.Number) 4, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(timeSeries21);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "June 2019" + "'", str27.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560668399999L + "'", long31 == 1560668399999L);
    }

//    @Test
//    public void test142() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test142");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        int int3 = day0.compareTo((java.lang.Object) (-1L));
//        java.lang.Class class7 = null;
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class7);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.lang.String str10 = day9.toString();
//        timeSeries8.delete((org.jfree.data.time.RegularTimePeriod) day9);
//        timeSeries8.fireSeriesChanged();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.util.Date date14 = day13.getEnd();
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
//        java.lang.Number number16 = timeSeries8.getValue((org.jfree.data.time.RegularTimePeriod) month15);
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class20);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.lang.String str23 = day22.toString();
//        timeSeries21.delete((org.jfree.data.time.RegularTimePeriod) day22);
//        boolean boolean25 = timeSeries8.equals((java.lang.Object) day22);
//        boolean boolean26 = day0.equals((java.lang.Object) timeSeries8);
//        timeSeries8.clear();
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        java.util.Date date29 = day28.getEnd();
//        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month(date29);
//        java.lang.String str31 = month30.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = month30.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month30, (double) (short) 100);
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        java.util.Date date36 = day35.getEnd();
//        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month(date36);
//        java.lang.String str38 = month37.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = month37.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month37, (double) (short) 100);
//        int int42 = timeSeriesDataItem34.compareTo((java.lang.Object) month37);
//        timeSeriesDataItem34.setValue((java.lang.Number) 6);
//        org.jfree.data.time.SerialDate serialDate47 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate50 = serialDate47.getEndOfCurrentMonth(serialDate49);
//        org.jfree.data.time.SerialDate serialDate51 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate49);
//        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(serialDate51);
//        boolean boolean53 = timeSeriesDataItem34.equals((java.lang.Object) serialDate51);
//        try {
//            timeSeries8.add(timeSeriesDataItem34, true);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "10-June-2019" + "'", str23.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "June 2019" + "'", str31.equals("June 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "June 2019" + "'", str38.equals("June 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
//        org.junit.Assert.assertNotNull(serialDate47);
//        org.junit.Assert.assertNotNull(serialDate49);
//        org.junit.Assert.assertNotNull(serialDate50);
//        org.junit.Assert.assertNotNull(serialDate51);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//    }

//    @Test
//    public void test143() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test143");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setMaximumItemCount((int) (byte) 0);
//        boolean boolean7 = timeSeries4.getNotify();
//        java.util.List list8 = timeSeries4.getItems();
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class12);
//        timeSeries13.setMaximumItemCount((int) (byte) 0);
//        boolean boolean16 = timeSeries13.getNotify();
//        java.util.List list17 = timeSeries13.getItems();
//        java.util.Collection collection18 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries13);
//        java.util.List list19 = timeSeries4.getItems();
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        java.util.Date date21 = day20.getEnd();
//        int int23 = day20.compareTo((java.lang.Object) (-1L));
//        java.lang.Class class27 = null;
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class27);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        java.lang.String str30 = day29.toString();
//        timeSeries28.delete((org.jfree.data.time.RegularTimePeriod) day29);
//        timeSeries28.fireSeriesChanged();
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        java.util.Date date34 = day33.getEnd();
//        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(date34);
//        java.lang.Number number36 = timeSeries28.getValue((org.jfree.data.time.RegularTimePeriod) month35);
//        java.lang.Class class40 = null;
//        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class40);
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
//        java.lang.String str43 = day42.toString();
//        timeSeries41.delete((org.jfree.data.time.RegularTimePeriod) day42);
//        boolean boolean45 = timeSeries28.equals((java.lang.Object) day42);
//        boolean boolean46 = day20.equals((java.lang.Object) timeSeries28);
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
//        java.lang.String str48 = day47.toString();
//        java.util.Date date49 = day47.getStart();
//        long long50 = day47.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) day20, (org.jfree.data.time.RegularTimePeriod) day47);
//        java.util.Calendar calendar52 = null;
//        try {
//            day20.peg(calendar52);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(list8);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNotNull(list17);
//        org.junit.Assert.assertNotNull(collection18);
//        org.junit.Assert.assertNotNull(list19);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "10-June-2019" + "'", str30.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNull(number36);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "10-June-2019" + "'", str43.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "10-June-2019" + "'", str48.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1560236399999L + "'", long50 == 1560236399999L);
//        org.junit.Assert.assertNotNull(timeSeries51);
//    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7, "10-June-2019", "ERROR : Relative To String", class3);
        try {
            timeSeries4.update(11, (java.lang.Number) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 11, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate5 = serialDate2.getEndOfCurrentMonth(serialDate4);
        java.lang.String str6 = serialDate4.toString();
        try {
            org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(8, serialDate4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "8-January-1900" + "'", str6.equals("8-January-1900"));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        int int0 = org.jfree.data.time.SerialDate.SATURDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

//    @Test
//    public void test148() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test148");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        java.util.Date date2 = day0.getStart();
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
//        java.lang.Object obj4 = null;
//        int int5 = year3.compareTo(obj4);
//        java.lang.String str6 = year3.toString();
//        java.util.Calendar calendar7 = null;
//        try {
//            long long8 = year3.getFirstMillisecond(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
//    }

//    @Test
//    public void test149() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test149");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        int int3 = day0.compareTo((java.lang.Object) (-1L));
//        java.lang.Class class7 = null;
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class7);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.lang.String str10 = day9.toString();
//        timeSeries8.delete((org.jfree.data.time.RegularTimePeriod) day9);
//        timeSeries8.fireSeriesChanged();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.util.Date date14 = day13.getEnd();
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
//        java.lang.Number number16 = timeSeries8.getValue((org.jfree.data.time.RegularTimePeriod) month15);
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class20);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.lang.String str23 = day22.toString();
//        timeSeries21.delete((org.jfree.data.time.RegularTimePeriod) day22);
//        boolean boolean25 = timeSeries8.equals((java.lang.Object) day22);
//        boolean boolean26 = day0.equals((java.lang.Object) timeSeries8);
//        timeSeries8.setDomainDescription("ERROR : Relative To String");
//        timeSeries8.setMaximumItemCount(3);
//        java.lang.Class class31 = timeSeries8.getTimePeriodClass();
//        try {
//            java.lang.Number number33 = timeSeries8.getValue((int) (byte) 10);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "10-June-2019" + "'", str23.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNull(class31);
//    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        int int0 = org.jfree.data.time.SerialDate.WEDNESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
        timeSeries4.setDomainDescription("hi!");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        java.util.Date date8 = day7.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) 0);
        java.lang.Object obj11 = null;
        boolean boolean12 = timeSeries4.equals(obj11);
        try {
            timeSeries4.update(9, (java.lang.Number) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

//    @Test
//    public void test152() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test152");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day5);
//        timeSeries4.fireSeriesChanged();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.util.Date date10 = day9.getEnd();
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
//        java.lang.Number number12 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month11);
//        java.util.Calendar calendar13 = null;
//        try {
//            long long14 = month11.getLastMillisecond(calendar13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNull(number12);
//    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
        timeSeries4.setDomainDescription("hi!");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        java.util.Date date8 = day7.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) 0);
        timeSeries4.setDescription("");
        try {
            java.lang.Number number14 = timeSeries4.getValue(11);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 11, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test154");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        long long2 = day0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//    }

//    @Test
//    public void test155() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test155");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        java.util.Date date2 = day0.getStart();
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
//        java.lang.Object obj4 = null;
//        int int5 = year3.compareTo(obj4);
//        int int6 = year3.getYear();
//        long long7 = year3.getSerialIndex();
//        java.util.Calendar calendar8 = null;
//        try {
//            long long9 = year3.getFirstMillisecond(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
//    }

//    @Test
//    public void test156() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test156");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
//        java.util.Date date3 = fixedMillisecond2.getTime();
//        long long4 = fixedMillisecond2.getSerialIndex();
//        long long5 = fixedMillisecond2.getFirstMillisecond();
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond2.getMiddleMillisecond(calendar6);
//        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate13 = serialDate10.getEndOfCurrentMonth(serialDate12);
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate12);
//        boolean boolean15 = fixedMillisecond2.equals((java.lang.Object) serialDate12);
//        try {
//            org.jfree.data.time.SerialDate serialDate17 = serialDate12.getPreviousDayOfWeek((int) ' ');
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560236399999L + "'", long5 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560236399999L + "'", long7 == 1560236399999L);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//    }

//    @Test
//    public void test157() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test157");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
//        java.util.Date date2 = spreadsheetDate1.toDate();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class6);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.lang.String str9 = day8.toString();
//        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) day8);
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries7.createCopy(1, (int) (short) 100);
//        try {
//            int int14 = spreadsheetDate1.compareTo((java.lang.Object) timeSeries13);
//            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.TimeSeries cannot be cast to org.jfree.data.time.SerialDate");
//        } catch (java.lang.ClassCastException e) {
//        }
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(timeSeries13);
//    }

//    @Test
//    public void test158() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test158");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setMaximumItemCount((int) (byte) 0);
//        boolean boolean7 = timeSeries4.getNotify();
//        java.util.List list8 = timeSeries4.getItems();
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class12);
//        timeSeries13.setMaximumItemCount((int) (byte) 0);
//        boolean boolean16 = timeSeries13.getNotify();
//        java.util.List list17 = timeSeries13.getItems();
//        java.util.Collection collection18 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries13);
//        boolean boolean19 = timeSeries4.isEmpty();
//        timeSeries4.setDomainDescription("2019");
//        java.lang.Class class25 = null;
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class25);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        java.lang.String str28 = day27.toString();
//        timeSeries26.delete((org.jfree.data.time.RegularTimePeriod) day27);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        java.util.Date date31 = day30.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond(date31);
//        java.util.Date date33 = fixedMillisecond32.getTime();
//        long long34 = fixedMillisecond32.getSerialIndex();
//        long long35 = fixedMillisecond32.getFirstMillisecond();
//        java.util.Calendar calendar36 = null;
//        long long37 = fixedMillisecond32.getMiddleMillisecond(calendar36);
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) day27, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond32);
//        java.util.Collection collection39 = timeSeries4.getTimePeriods();
//        int int40 = timeSeries4.getMaximumItemCount();
//        java.lang.Class class41 = timeSeries4.getTimePeriodClass();
//        java.lang.Object obj42 = timeSeries4.clone();
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(list8);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNotNull(list17);
//        org.junit.Assert.assertNotNull(collection18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "10-June-2019" + "'", str28.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560236399999L + "'", long34 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560236399999L + "'", long35 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560236399999L + "'", long37 == 1560236399999L);
//        org.junit.Assert.assertNotNull(timeSeries38);
//        org.junit.Assert.assertNotNull(collection39);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
//        org.junit.Assert.assertNull(class41);
//        org.junit.Assert.assertNotNull(obj42);
//    }

//    @Test
//    public void test159() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test159");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setMaximumItemCount((int) (byte) 0);
//        boolean boolean7 = timeSeries4.getNotify();
//        java.util.List list8 = timeSeries4.getItems();
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class12);
//        timeSeries13.setMaximumItemCount((int) (byte) 0);
//        boolean boolean16 = timeSeries13.getNotify();
//        java.util.List list17 = timeSeries13.getItems();
//        java.util.Collection collection18 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries13);
//        java.util.List list19 = timeSeries4.getItems();
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        java.util.Date date21 = day20.getEnd();
//        int int23 = day20.compareTo((java.lang.Object) (-1L));
//        java.lang.Class class27 = null;
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class27);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        java.lang.String str30 = day29.toString();
//        timeSeries28.delete((org.jfree.data.time.RegularTimePeriod) day29);
//        timeSeries28.fireSeriesChanged();
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        java.util.Date date34 = day33.getEnd();
//        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(date34);
//        java.lang.Number number36 = timeSeries28.getValue((org.jfree.data.time.RegularTimePeriod) month35);
//        java.lang.Class class40 = null;
//        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class40);
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
//        java.lang.String str43 = day42.toString();
//        timeSeries41.delete((org.jfree.data.time.RegularTimePeriod) day42);
//        boolean boolean45 = timeSeries28.equals((java.lang.Object) day42);
//        boolean boolean46 = day20.equals((java.lang.Object) timeSeries28);
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
//        java.lang.String str48 = day47.toString();
//        java.util.Date date49 = day47.getStart();
//        long long50 = day47.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) day20, (org.jfree.data.time.RegularTimePeriod) day47);
//        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day();
//        java.lang.String str53 = day52.toString();
//        java.util.Date date54 = day52.getStart();
//        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year(date54);
//        java.lang.Object obj56 = null;
//        int int57 = year55.compareTo(obj56);
//        int int58 = year55.getYear();
//        long long59 = year55.getSerialIndex();
//        java.lang.Number number60 = null;
//        try {
//            timeSeries4.update((org.jfree.data.time.RegularTimePeriod) year55, number60);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(list8);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNotNull(list17);
//        org.junit.Assert.assertNotNull(collection18);
//        org.junit.Assert.assertNotNull(list19);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "10-June-2019" + "'", str30.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNull(number36);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "10-June-2019" + "'", str43.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "10-June-2019" + "'", str48.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1560236399999L + "'", long50 == 1560236399999L);
//        org.junit.Assert.assertNotNull(timeSeries51);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "10-June-2019" + "'", str53.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 2019 + "'", int58 == 2019);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 2019L + "'", long59 == 2019L);
//    }

//    @Test
//    public void test160() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test160");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
//        java.util.Date date3 = fixedMillisecond2.getTime();
//        long long4 = fixedMillisecond2.getSerialIndex();
//        long long5 = fixedMillisecond2.getFirstMillisecond();
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond2.getFirstMillisecond(calendar6);
//        long long8 = fixedMillisecond2.getSerialIndex();
//        java.util.Calendar calendar9 = null;
//        fixedMillisecond2.peg(calendar9);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560236399999L + "'", long5 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560236399999L + "'", long7 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560236399999L + "'", long8 == 1560236399999L);
//    }

//    @Test
//    public void test161() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test161");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        int int3 = day0.compareTo((java.lang.Object) (-1L));
//        java.lang.Class class7 = null;
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class7);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.lang.String str10 = day9.toString();
//        timeSeries8.delete((org.jfree.data.time.RegularTimePeriod) day9);
//        timeSeries8.fireSeriesChanged();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.util.Date date14 = day13.getEnd();
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
//        java.lang.Number number16 = timeSeries8.getValue((org.jfree.data.time.RegularTimePeriod) month15);
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class20);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.lang.String str23 = day22.toString();
//        timeSeries21.delete((org.jfree.data.time.RegularTimePeriod) day22);
//        boolean boolean25 = timeSeries8.equals((java.lang.Object) day22);
//        boolean boolean26 = day0.equals((java.lang.Object) timeSeries8);
//        try {
//            org.jfree.data.time.TimeSeries timeSeries29 = timeSeries8.createCopy((int) (short) 10, 6);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "10-June-2019" + "'", str23.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//    }

//    @Test
//    public void test162() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test162");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day5);
//        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries4.createCopy(1, (int) (short) 100);
//        try {
//            timeSeries10.removeAgedItems((long) 11, true);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(timeSeries10);
//    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        java.lang.String str3 = month2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        long long5 = month2.getMiddleMillisecond();
        int int6 = month2.getYearValue();
        int int7 = month2.getMonth();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560668399999L + "'", long5 == 1560668399999L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("2019");
        org.junit.Assert.assertNull(day1);
    }

//    @Test
//    public void test166() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test166");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        int int3 = day0.compareTo((java.lang.Object) (-1L));
//        java.lang.Class class7 = null;
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class7);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.lang.String str10 = day9.toString();
//        timeSeries8.delete((org.jfree.data.time.RegularTimePeriod) day9);
//        timeSeries8.fireSeriesChanged();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.util.Date date14 = day13.getEnd();
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
//        java.lang.Number number16 = timeSeries8.getValue((org.jfree.data.time.RegularTimePeriod) month15);
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class20);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.lang.String str23 = day22.toString();
//        timeSeries21.delete((org.jfree.data.time.RegularTimePeriod) day22);
//        boolean boolean25 = timeSeries8.equals((java.lang.Object) day22);
//        boolean boolean26 = day0.equals((java.lang.Object) timeSeries8);
//        timeSeries8.setDomainDescription("ERROR : Relative To String");
//        timeSeries8.removeAgedItems(false);
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries8.getDataItem(9999);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9999, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "10-June-2019" + "'", str23.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//    }

//    @Test
//    public void test167() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test167");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day5);
//        timeSeries4.fireSeriesChanged();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.util.Date date10 = day9.getEnd();
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
//        java.lang.Number number12 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month11);
//        long long13 = month11.getSerialIndex();
//        java.util.Calendar calendar14 = null;
//        try {
//            long long15 = month11.getMiddleMillisecond(calendar14);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNull(number12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 24234L + "'", long13 == 24234L);
//    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
        timeSeries4.setDomainDescription("hi!");
        java.lang.Object obj7 = timeSeries4.clone();
        java.lang.String str8 = timeSeries4.getDescription();
        timeSeries4.setMaximumItemAge((long) 9999);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries4.removeChangeListener(seriesChangeListener11);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
        timeSeries4.setMaximumItemCount((int) (byte) 0);
        boolean boolean7 = timeSeries4.getNotify();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class11);
        timeSeries12.setDomainDescription("hi!");
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        java.util.Date date16 = day15.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day15, (java.lang.Number) 0);
        java.lang.Object obj19 = null;
        boolean boolean20 = timeSeries12.equals(obj19);
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries4.addAndOrUpdate(timeSeries12);
        timeSeries12.removeAgedItems(false);
        try {
            timeSeries12.removeAgedItems(2019L, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(timeSeries21);
    }

//    @Test
//    public void test170() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test170");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setMaximumItemCount((int) (byte) 0);
//        boolean boolean7 = timeSeries4.getNotify();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class11);
//        timeSeries12.setDomainDescription("hi!");
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        java.util.Date date16 = day15.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day15, (java.lang.Number) 0);
//        java.lang.Object obj19 = null;
//        boolean boolean20 = timeSeries12.equals(obj19);
//        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries4.addAndOrUpdate(timeSeries12);
//        timeSeries12.removeAgedItems(false);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        java.util.Date date25 = day24.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond(date25);
//        java.util.Date date27 = fixedMillisecond26.getTime();
//        long long28 = fixedMillisecond26.getSerialIndex();
//        long long29 = fixedMillisecond26.getFirstMillisecond();
//        java.util.Calendar calendar30 = null;
//        long long31 = fixedMillisecond26.getMiddleMillisecond(calendar30);
//        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate37 = serialDate34.getEndOfCurrentMonth(serialDate36);
//        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate36);
//        boolean boolean39 = fixedMillisecond26.equals((java.lang.Object) serialDate36);
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day();
//        java.util.Date date41 = day40.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond(date41);
//        java.util.Date date43 = fixedMillisecond42.getTime();
//        long long44 = fixedMillisecond42.getSerialIndex();
//        long long45 = fixedMillisecond42.getFirstMillisecond();
//        java.util.Calendar calendar46 = null;
//        long long47 = fixedMillisecond42.getMiddleMillisecond(calendar46);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = fixedMillisecond42.next();
//        try {
//            org.jfree.data.time.TimeSeries timeSeries49 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond42);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNull(timeSeriesDataItem18);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(timeSeries21);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560236399999L + "'", long28 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560236399999L + "'", long29 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560236399999L + "'", long31 == 1560236399999L);
//        org.junit.Assert.assertNotNull(serialDate34);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertNotNull(serialDate37);
//        org.junit.Assert.assertNotNull(serialDate38);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1560236399999L + "'", long44 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1560236399999L + "'", long45 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1560236399999L + "'", long47 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod48);
//    }

//    @Test
//    public void test171() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test171");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setMaximumItemCount((int) (byte) 0);
//        boolean boolean7 = timeSeries4.getNotify();
//        java.util.List list8 = timeSeries4.getItems();
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class12);
//        timeSeries13.setMaximumItemCount((int) (byte) 0);
//        boolean boolean16 = timeSeries13.getNotify();
//        java.util.List list17 = timeSeries13.getItems();
//        java.util.Collection collection18 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries13);
//        boolean boolean19 = timeSeries4.isEmpty();
//        timeSeries4.setDomainDescription("2019");
//        java.lang.Class class25 = null;
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class25);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        java.lang.String str28 = day27.toString();
//        timeSeries26.delete((org.jfree.data.time.RegularTimePeriod) day27);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        java.util.Date date31 = day30.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond(date31);
//        java.util.Date date33 = fixedMillisecond32.getTime();
//        long long34 = fixedMillisecond32.getSerialIndex();
//        long long35 = fixedMillisecond32.getFirstMillisecond();
//        java.util.Calendar calendar36 = null;
//        long long37 = fixedMillisecond32.getMiddleMillisecond(calendar36);
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) day27, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond32);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32, (java.lang.Number) 12);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(list8);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNotNull(list17);
//        org.junit.Assert.assertNotNull(collection18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "10-June-2019" + "'", str28.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560236399999L + "'", long34 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560236399999L + "'", long35 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560236399999L + "'", long37 == 1560236399999L);
//        org.junit.Assert.assertNotNull(timeSeries38);
//    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("Sunday");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        java.lang.String str3 = month2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (double) (short) 100);
        long long7 = month2.getMiddleMillisecond();
        long long8 = month2.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560668399999L + "'", long7 == 1560668399999L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1559372400000L + "'", long8 == 1559372400000L);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
        timeSeries4.setMaximumItemCount((int) (byte) 0);
        boolean boolean7 = timeSeries4.getNotify();
        timeSeries4.setKey((java.lang.Comparable) 10.0d);
        try {
            java.lang.Number number11 = timeSeries4.getValue(8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("10-June-2019");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addMonths(9, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test178() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test178");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setDomainDescription("hi!");
//        java.lang.Object obj7 = timeSeries4.clone();
//        java.lang.String str8 = timeSeries4.getDescription();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.lang.String str10 = day9.toString();
//        java.util.Date date11 = day9.getStart();
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
//        long long13 = year12.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year12, (java.lang.Number) 100.0f);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        java.lang.String str17 = day16.toString();
//        java.util.Date date18 = day16.getStart();
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date18);
//        java.lang.Object obj20 = null;
//        int int21 = year19.compareTo(obj20);
//        java.lang.String str22 = year19.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year19.previous();
//        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) year12, (org.jfree.data.time.RegularTimePeriod) year19);
//        java.util.Calendar calendar25 = null;
//        try {
//            long long26 = year12.getFirstMillisecond(calendar25);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(obj7);
//        org.junit.Assert.assertNull(str8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "10-June-2019" + "'", str17.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "2019" + "'", str22.equals("2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(timeSeries24);
//    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((int) (short) 100);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(2);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Monday" + "'", str1.equals("Monday"));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        java.lang.String str3 = month2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (double) (short) 100);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        java.util.Date date8 = day7.getEnd();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date8);
        java.lang.String str10 = month9.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month9, (double) (short) 100);
        int int14 = timeSeriesDataItem6.compareTo((java.lang.Object) month9);
        java.util.Calendar calendar15 = null;
        try {
            long long16 = month9.getLastMillisecond(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "June 2019" + "'", str10.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

//    @Test
//    public void test182() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test182");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setMaximumItemCount((int) (byte) 0);
//        boolean boolean7 = timeSeries4.getNotify();
//        java.lang.Comparable comparable8 = timeSeries4.getKey();
//        timeSeries4.setNotify(false);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        java.lang.String str12 = day11.toString();
//        java.util.Date date13 = day11.getStart();
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date13);
//        java.lang.Object obj15 = null;
//        int int16 = year14.compareTo(obj15);
//        int int17 = year14.getYear();
//        long long18 = year14.getSerialIndex();
//        try {
//            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) year14, (double) 9223372036854775807L);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0f) + "'", comparable8.equals((-1.0f)));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10-June-2019" + "'", str12.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2019L + "'", long18 == 2019L);
//    }

//    @Test
//    public void test183() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test183");
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        java.lang.String str2 = day1.toString();
//        java.util.Date date3 = day1.getStart();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
//        java.lang.Object obj5 = null;
//        int int6 = year4.compareTo(obj5);
//        int int7 = year4.getYear();
//        java.lang.String str8 = year4.toString();
//        try {
//            org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((-1), year4);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10-June-2019" + "'", str2.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
//    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test185() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test185");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
//        java.util.Date date3 = fixedMillisecond2.getTime();
//        long long4 = fixedMillisecond2.getSerialIndex();
//        long long5 = fixedMillisecond2.getFirstMillisecond();
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond2.getMiddleMillisecond(calendar6);
//        boolean boolean9 = fixedMillisecond2.equals((java.lang.Object) 0.0f);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560236399999L + "'", long5 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560236399999L + "'", long7 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        java.lang.String str3 = month2.toString();
        int int4 = month2.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (double) (short) -1);
        long long7 = month2.getLastMillisecond();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1561964399999L + "'", long7 == 1561964399999L);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((int) 'a');
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(1900, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        int int0 = org.jfree.data.time.SerialDate.TUESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

//    @Test
//    public void test190() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test190");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        java.util.Date date2 = day0.getStart();
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
//        java.lang.Object obj4 = null;
//        int int5 = year3.compareTo(obj4);
//        int int6 = year3.getYear();
//        long long7 = year3.getSerialIndex();
//        java.lang.String str8 = year3.toString();
//        long long9 = year3.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
//    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (byte) 100, 3, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test192() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test192");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day5);
//        timeSeries4.fireSeriesChanged();
//        timeSeries4.removeAgedItems(false);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        java.util.Date date12 = day11.getEnd();
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date12);
//        java.lang.String str14 = month13.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month13.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month13, (double) (short) 100);
//        int int18 = month13.getMonth();
//        long long19 = month13.getLastMillisecond();
//        try {
//            timeSeries4.update((org.jfree.data.time.RegularTimePeriod) month13, (java.lang.Number) (short) 10);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "June 2019" + "'", str14.equals("June 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1561964399999L + "'", long19 == 1561964399999L);
//    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate7 = serialDate4.getEndOfCurrentMonth(serialDate6);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean11 = spreadsheetDate1.isInRange(serialDate6, (org.jfree.data.time.SerialDate) spreadsheetDate10);
        int int12 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean15 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate21 = serialDate18.getEndOfCurrentMonth(serialDate20);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addDays(0, serialDate21);
        boolean boolean23 = spreadsheetDate1.isOnOrBefore(serialDate21);
        int int24 = spreadsheetDate1.getYYYY();
        int int25 = spreadsheetDate1.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.createInstance(9);
        boolean boolean30 = spreadsheetDate27.isOnOrAfter(serialDate29);
        boolean boolean31 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate27);
        java.lang.Object obj32 = null;
        try {
            int int33 = spreadsheetDate1.compareTo(obj32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1900 + "'", int12 == 1900);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1900 + "'", int24 == 1900);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2 + "'", int25 == 2);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        java.util.Date date4 = day3.getEnd();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate11 = serialDate8.getEndOfCurrentMonth(serialDate10);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(serialDate8);
        boolean boolean14 = spreadsheetDate1.isInRange(serialDate5, serialDate8, 0);
        java.lang.String str15 = serialDate5.getDescription();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(str15);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
        timeSeries4.setMaximumItemCount((int) (byte) 0);
        boolean boolean7 = timeSeries4.getNotify();
        java.util.List list8 = timeSeries4.getItems();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class12);
        timeSeries13.setMaximumItemCount((int) (byte) 0);
        boolean boolean16 = timeSeries13.getNotify();
        java.util.List list17 = timeSeries13.getItems();
        java.util.Collection collection18 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        timeSeries13.setNotify(false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(list17);
        org.junit.Assert.assertNotNull(collection18);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(2019);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test197() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test197");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day5);
//        timeSeries4.setRangeDescription("January");
//        try {
//            org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = timeSeries4.getNextTimePeriod();
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        java.lang.String str3 = month2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (double) (short) 100);
        long long7 = month2.getMiddleMillisecond();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = month2.getLastMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560668399999L + "'", long7 == 1560668399999L);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate7 = serialDate4.getEndOfCurrentMonth(serialDate6);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean11 = spreadsheetDate1.isInRange(serialDate6, (org.jfree.data.time.SerialDate) spreadsheetDate10);
        int int12 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean15 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
        java.util.Date date17 = day16.getEnd();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(date17);
        java.lang.String str19 = month18.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month18, (double) (short) 100);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
        java.util.Date date24 = day23.getEnd();
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month(date24);
        java.lang.String str26 = month25.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = month25.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month25, (double) (short) 100);
        int int30 = timeSeriesDataItem22.compareTo((java.lang.Object) month25);
        timeSeriesDataItem22.setValue((java.lang.Number) 6);
        try {
            int int33 = spreadsheetDate1.compareTo((java.lang.Object) 6);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Integer cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1900 + "'", int12 == 1900);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "June 2019" + "'", str19.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "June 2019" + "'", str26.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        java.lang.Object obj2 = null;
        boolean boolean3 = day0.equals(obj2);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(9, (int) (byte) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) 3);
        java.util.Calendar calendar5 = null;
        try {
            long long6 = month2.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        java.lang.String str3 = month2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (double) (short) 100);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        java.util.Date date8 = day7.getEnd();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date8);
        java.lang.String str10 = month9.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month9, (double) (short) 100);
        int int14 = timeSeriesDataItem6.compareTo((java.lang.Object) month9);
        timeSeriesDataItem6.setValue((java.lang.Number) 6);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate22 = serialDate19.getEndOfCurrentMonth(serialDate21);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate21);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(serialDate23);
        boolean boolean25 = timeSeriesDataItem6.equals((java.lang.Object) serialDate23);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent26 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeriesDataItem6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = timeSeriesDataItem6.getPeriod();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "June 2019" + "'", str10.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        java.lang.String str3 = month2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (double) (short) 100);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        java.util.Date date8 = day7.getEnd();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date8);
        java.lang.String str10 = month9.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month9, (double) (short) 100);
        int int14 = timeSeriesDataItem6.compareTo((java.lang.Object) month9);
        timeSeriesDataItem6.setValue((java.lang.Number) 100);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = timeSeriesDataItem6.getPeriod();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "June 2019" + "'", str10.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        java.lang.String str3 = month2.toString();
        long long4 = month2.getLastMillisecond();
        long long5 = month2.getLastMillisecond();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1561964399999L + "'", long4 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1561964399999L + "'", long5 == 1561964399999L);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        java.lang.String str3 = month2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (double) (short) 100);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        java.util.Date date8 = day7.getEnd();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date8);
        java.lang.String str10 = month9.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month9, (double) (short) 100);
        int int14 = timeSeriesDataItem6.compareTo((java.lang.Object) month9);
        timeSeriesDataItem6.setValue((java.lang.Number) 6);
        timeSeriesDataItem6.setValue((java.lang.Number) 1561964399999L);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "June 2019" + "'", str10.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date1);
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year3.getMiddleMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        java.lang.String str3 = month2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (double) (short) 100);
        int int7 = month2.getMonth();
        int int8 = month2.getYearValue();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("ERROR : Relative To String");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

//    @Test
//    public void test210() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test210");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setMaximumItemCount((int) (byte) 0);
//        boolean boolean7 = timeSeries4.getNotify();
//        java.util.List list8 = timeSeries4.getItems();
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class12);
//        timeSeries13.setMaximumItemCount((int) (byte) 0);
//        boolean boolean16 = timeSeries13.getNotify();
//        java.util.List list17 = timeSeries13.getItems();
//        java.util.Collection collection18 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries13);
//        boolean boolean19 = timeSeries4.isEmpty();
//        timeSeries4.setDomainDescription("2019");
//        java.lang.Class class25 = null;
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class25);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        java.lang.String str28 = day27.toString();
//        timeSeries26.delete((org.jfree.data.time.RegularTimePeriod) day27);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        java.util.Date date31 = day30.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond(date31);
//        java.util.Date date33 = fixedMillisecond32.getTime();
//        long long34 = fixedMillisecond32.getSerialIndex();
//        long long35 = fixedMillisecond32.getFirstMillisecond();
//        java.util.Calendar calendar36 = null;
//        long long37 = fixedMillisecond32.getMiddleMillisecond(calendar36);
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) day27, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond32);
//        java.util.Collection collection39 = timeSeries4.getTimePeriods();
//        int int40 = timeSeries4.getMaximumItemCount();
//        java.lang.Class class41 = timeSeries4.getTimePeriodClass();
//        try {
//            org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = timeSeries4.getTimePeriod((int) '#');
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(list8);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNotNull(list17);
//        org.junit.Assert.assertNotNull(collection18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "10-June-2019" + "'", str28.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560236399999L + "'", long34 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560236399999L + "'", long35 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560236399999L + "'", long37 == 1560236399999L);
//        org.junit.Assert.assertNotNull(timeSeries38);
//        org.junit.Assert.assertNotNull(collection39);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
//        org.junit.Assert.assertNull(class41);
//    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.SerialDate serialDate3 = null;
        try {
            org.jfree.data.time.SerialDate serialDate4 = spreadsheetDate1.getEndOfCurrentMonth(serialDate3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(9);
        boolean boolean5 = spreadsheetDate2.isOnOrAfter(serialDate4);
        try {
            org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate8 = serialDate5.getEndOfCurrentMonth(serialDate7);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean12 = spreadsheetDate2.isInRange(serialDate7, (org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SerialDate serialDate14 = serialDate7.getPreviousDayOfWeek(7);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate14);
        try {
            org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(12, serialDate14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(serialDate14);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(9999);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate7 = serialDate4.getEndOfCurrentMonth(serialDate6);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean11 = spreadsheetDate1.isInRange(serialDate6, (org.jfree.data.time.SerialDate) spreadsheetDate10);
        int int12 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean15 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate21 = serialDate18.getEndOfCurrentMonth(serialDate20);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addDays(0, serialDate21);
        boolean boolean23 = spreadsheetDate1.isOnOrBefore(serialDate21);
        try {
            org.jfree.data.time.SerialDate serialDate25 = serialDate21.getFollowingDayOfWeek((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1900 + "'", int12 == 1900);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

//    @Test
//    public void test217() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test217");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
//        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(9);
//        boolean boolean4 = spreadsheetDate1.isOnOrAfter(serialDate3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.util.Date date7 = day5.getStart();
//        org.jfree.data.time.SerialDate serialDate8 = day5.getSerialDate();
//        try {
//            int int9 = spreadsheetDate1.compareTo((java.lang.Object) day5);
//            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.Day cannot be cast to org.jfree.data.time.SerialDate");
//        } catch (java.lang.ClassCastException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(serialDate8);
//    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        int int2 = spreadsheetDate1.toSerial();
        int int3 = spreadsheetDate1.getMonth();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

//    @Test
//    public void test219() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test219");
//        java.lang.Comparable comparable0 = null;
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class6);
//        timeSeries7.setMaximumItemCount((int) (byte) 0);
//        boolean boolean10 = timeSeries7.getNotify();
//        timeSeries7.setKey((java.lang.Comparable) 10.0d);
//        java.lang.Class<?> wildcardClass13 = timeSeries7.getClass();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.lang.String str15 = day14.toString();
//        java.util.Date date16 = day14.getStart();
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        java.util.Date date19 = day18.getEnd();
//        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(date19);
//        java.lang.String str21 = month20.toString();
//        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean23 = month20.equals((java.lang.Object) timeZone22);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date16, timeZone22);
//        java.lang.Class class25 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
//        try {
//            org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries(comparable0, "January", "2019", (java.lang.Class) wildcardClass13);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10-June-2019" + "'", str15.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "June 2019" + "'", str21.equals("June 2019"));
//        org.junit.Assert.assertNotNull(timeZone22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(class25);
//    }

//    @Test
//    public void test220() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test220");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getLastMillisecond();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = day0.getFirstMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//    }

//    @Test
//    public void test221() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test221");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setDomainDescription("hi!");
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        java.util.Date date8 = day7.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) 0);
//        long long11 = day7.getFirstMillisecond();
//        java.util.Calendar calendar12 = null;
//        try {
//            day7.peg(calendar12);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(timeSeriesDataItem10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560150000000L + "'", long11 == 1560150000000L);
//    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2147483647");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        java.lang.String str3 = month2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (double) (short) 100);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        java.util.Date date8 = day7.getEnd();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date8);
        java.lang.String str10 = month9.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month9, (double) (short) 100);
        int int14 = timeSeriesDataItem6.compareTo((java.lang.Object) month9);
        timeSeriesDataItem6.setValue((java.lang.Number) 6);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate22 = serialDate19.getEndOfCurrentMonth(serialDate21);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate21);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(serialDate23);
        boolean boolean25 = timeSeriesDataItem6.equals((java.lang.Object) serialDate23);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent26 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeriesDataItem6);
        java.lang.String str27 = seriesChangeEvent26.toString();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "June 2019" + "'", str10.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

//    @Test
//    public void test225() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test225");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setDomainDescription("hi!");
//        java.lang.Object obj7 = timeSeries4.clone();
//        java.lang.String str8 = timeSeries4.getDescription();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.lang.String str10 = day9.toString();
//        java.util.Date date11 = day9.getStart();
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
//        long long13 = year12.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year12, (java.lang.Number) 100.0f);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        java.lang.String str17 = day16.toString();
//        java.util.Date date18 = day16.getStart();
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date18);
//        java.lang.Object obj20 = null;
//        int int21 = year19.compareTo(obj20);
//        java.lang.String str22 = year19.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year19.previous();
//        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) year12, (org.jfree.data.time.RegularTimePeriod) year19);
//        boolean boolean25 = timeSeries4.getNotify();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = null;
//        try {
//            java.lang.Number number27 = timeSeries4.getValue(regularTimePeriod26);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(obj7);
//        org.junit.Assert.assertNull(str8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "10-June-2019" + "'", str17.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "2019" + "'", str22.equals("2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(timeSeries24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//    }

//    @Test
//    public void test226() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test226");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day5);
//        timeSeries4.fireSeriesChanged();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.util.Date date10 = day9.getEnd();
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
//        java.lang.Number number12 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month11);
//        java.lang.Class class16 = null;
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class16);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        java.lang.String str19 = day18.toString();
//        timeSeries17.delete((org.jfree.data.time.RegularTimePeriod) day18);
//        boolean boolean21 = timeSeries4.equals((java.lang.Object) day18);
//        java.lang.String str22 = day18.toString();
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNull(number12);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "10-June-2019" + "'", str19.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "10-June-2019" + "'", str22.equals("10-June-2019"));
//    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7, "10-June-2019", "ERROR : Relative To String", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        java.util.Date date8 = day7.getEnd();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date8);
        java.lang.String str10 = month9.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month9, (double) (short) 100);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        java.util.Date date15 = day14.getEnd();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date15);
        java.lang.String str17 = month16.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month16.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month16, (double) (short) 100);
        int int21 = timeSeriesDataItem13.compareTo((java.lang.Object) month16);
        timeSeriesDataItem13.setValue((java.lang.Number) 6);
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate29 = serialDate26.getEndOfCurrentMonth(serialDate28);
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate28);
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(serialDate30);
        boolean boolean32 = timeSeriesDataItem13.equals((java.lang.Object) serialDate30);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = timeSeriesDataItem13.getPeriod();
        timeSeries4.delete(regularTimePeriod33);
        java.lang.Class class35 = timeSeries4.getTimePeriodClass();
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "June 2019" + "'", str10.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "June 2019" + "'", str17.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNull(class35);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        spreadsheetDate1.setDescription("June 2019");
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(7);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

//    @Test
//    public void test231() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test231");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        int int3 = day0.compareTo((java.lang.Object) (-1L));
//        java.lang.Class class7 = null;
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class7);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.lang.String str10 = day9.toString();
//        timeSeries8.delete((org.jfree.data.time.RegularTimePeriod) day9);
//        timeSeries8.fireSeriesChanged();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.util.Date date14 = day13.getEnd();
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
//        java.lang.Number number16 = timeSeries8.getValue((org.jfree.data.time.RegularTimePeriod) month15);
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class20);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.lang.String str23 = day22.toString();
//        timeSeries21.delete((org.jfree.data.time.RegularTimePeriod) day22);
//        boolean boolean25 = timeSeries8.equals((java.lang.Object) day22);
//        boolean boolean26 = day0.equals((java.lang.Object) timeSeries8);
//        timeSeries8.setDomainDescription("ERROR : Relative To String");
//        java.lang.String str29 = timeSeries8.getRangeDescription();
//        java.lang.String str30 = timeSeries8.getRangeDescription();
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        java.lang.String str32 = day31.toString();
//        long long33 = day31.getFirstMillisecond();
//        java.lang.Number number34 = timeSeries8.getValue((org.jfree.data.time.RegularTimePeriod) day31);
//        java.lang.Class class38 = null;
//        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class38);
//        timeSeries39.setDomainDescription("hi!");
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
//        java.util.Date date43 = day42.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = timeSeries39.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day42, (java.lang.Number) 0);
//        timeSeries39.setDescription("");
//        timeSeries39.setNotify(true);
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day();
//        java.lang.String str51 = day50.toString();
//        java.util.Date date52 = day50.getStart();
//        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year(date52);
//        java.lang.Object obj54 = null;
//        int int55 = year53.compareTo(obj54);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem56 = timeSeries39.getDataItem((org.jfree.data.time.RegularTimePeriod) year53);
//        try {
//            timeSeries8.add(timeSeriesDataItem56, true);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "10-June-2019" + "'", str23.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "hi!" + "'", str29.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "hi!" + "'", str30.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "10-June-2019" + "'", str32.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560150000000L + "'", long33 == 1560150000000L);
//        org.junit.Assert.assertNull(number34);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertNull(timeSeriesDataItem45);
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "10-June-2019" + "'", str51.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem56);
//    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((-1), 1, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("org.jfree.data.general.SeriesChangeEvent[source=10]");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(7);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "July" + "'", str1.equals("July"));
    }

//    @Test
//    public void test235() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test235");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setMaximumItemCount((int) (byte) 0);
//        boolean boolean7 = timeSeries4.getNotify();
//        java.util.List list8 = timeSeries4.getItems();
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class12);
//        timeSeries13.setMaximumItemCount((int) (byte) 0);
//        boolean boolean16 = timeSeries13.getNotify();
//        java.util.List list17 = timeSeries13.getItems();
//        java.util.Collection collection18 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries13);
//        boolean boolean19 = timeSeries4.isEmpty();
//        timeSeries4.setDomainDescription("2019");
//        java.lang.Class class25 = null;
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class25);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        java.lang.String str28 = day27.toString();
//        timeSeries26.delete((org.jfree.data.time.RegularTimePeriod) day27);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        java.util.Date date31 = day30.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond(date31);
//        java.util.Date date33 = fixedMillisecond32.getTime();
//        long long34 = fixedMillisecond32.getSerialIndex();
//        long long35 = fixedMillisecond32.getFirstMillisecond();
//        java.util.Calendar calendar36 = null;
//        long long37 = fixedMillisecond32.getMiddleMillisecond(calendar36);
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) day27, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond32);
//        java.util.Collection collection39 = timeSeries4.getTimePeriods();
//        timeSeries4.removeAgedItems(false);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(list8);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNotNull(list17);
//        org.junit.Assert.assertNotNull(collection18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "10-June-2019" + "'", str28.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560236399999L + "'", long34 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560236399999L + "'", long35 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560236399999L + "'", long37 == 1560236399999L);
//        org.junit.Assert.assertNotNull(timeSeries38);
//        org.junit.Assert.assertNotNull(collection39);
//    }

//    @Test
//    public void test236() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test236");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        java.util.Date date2 = day0.getStart();
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
//        java.lang.Class class7 = null;
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class7);
//        timeSeries8.setMaximumItemCount((int) (byte) 0);
//        boolean boolean11 = timeSeries8.getNotify();
//        java.util.List list12 = timeSeries8.getItems();
//        java.lang.Class class16 = null;
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class16);
//        timeSeries17.setMaximumItemCount((int) (byte) 0);
//        boolean boolean20 = timeSeries17.getNotify();
//        java.util.List list21 = timeSeries17.getItems();
//        java.util.Collection collection22 = timeSeries8.getTimePeriodsUniqueToOtherSeries(timeSeries17);
//        boolean boolean23 = timeSeries8.isEmpty();
//        timeSeries8.setDomainDescription("2019");
//        java.lang.Class<?> wildcardClass26 = timeSeries8.getClass();
//        java.util.Date date27 = null;
//        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass26, date27, timeZone28);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date2, timeZone28);
//        org.jfree.data.time.SerialDate serialDate31 = day30.getSerialDate();
//        java.util.Calendar calendar32 = null;
//        try {
//            day30.peg(calendar32);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertNotNull(list12);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertNotNull(list21);
//        org.junit.Assert.assertNotNull(collection22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(timeZone28);
//        org.junit.Assert.assertNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(serialDate31);
//    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(9);
        boolean boolean4 = spreadsheetDate1.isOnOrAfter(serialDate3);
        try {
            org.jfree.data.time.SerialDate serialDate6 = serialDate3.getNearestDayOfWeek(1900);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear((-1));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (byte) -1, 8, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        java.lang.String str3 = month2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        long long5 = month2.getMiddleMillisecond();
        int int6 = month2.getYearValue();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = month2.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560668399999L + "'", long5 == 1560668399999L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
    }

//    @Test
//    public void test241() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test241");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
//        java.util.Date date3 = fixedMillisecond2.getTime();
//        long long4 = fixedMillisecond2.getSerialIndex();
//        long long5 = fixedMillisecond2.getFirstMillisecond();
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond2.getLastMillisecond(calendar6);
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond2.getMiddleMillisecond(calendar8);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560236399999L + "'", long5 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560236399999L + "'", long7 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560236399999L + "'", long9 == 1560236399999L);
//    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(11, (int) (short) 1, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        java.lang.String str3 = month2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (double) (short) 100);
        int int7 = month2.getMonth();
        long long8 = month2.getLastMillisecond();
        java.util.Calendar calendar9 = null;
        try {
            month2.peg(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1561964399999L + "'", long8 == 1561964399999L);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Nearest" + "'", str1.equals("Nearest"));
    }

//    @Test
//    public void test245() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test245");
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        java.lang.String str2 = day1.toString();
//        java.util.Date date3 = day1.getStart();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
//        java.lang.Class class8 = null;
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class8);
//        timeSeries9.setMaximumItemCount((int) (byte) 0);
//        boolean boolean12 = timeSeries9.getNotify();
//        java.util.List list13 = timeSeries9.getItems();
//        java.lang.Class class17 = null;
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class17);
//        timeSeries18.setMaximumItemCount((int) (byte) 0);
//        boolean boolean21 = timeSeries18.getNotify();
//        java.util.List list22 = timeSeries18.getItems();
//        java.util.Collection collection23 = timeSeries9.getTimePeriodsUniqueToOtherSeries(timeSeries18);
//        boolean boolean24 = timeSeries9.isEmpty();
//        timeSeries9.setDomainDescription("2019");
//        java.lang.Class<?> wildcardClass27 = timeSeries9.getClass();
//        java.util.Date date28 = null;
//        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass27, date28, timeZone29);
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date3, timeZone29);
//        org.jfree.data.time.SerialDate serialDate32 = day31.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 100, serialDate32);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10-June-2019" + "'", str2.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertNotNull(list13);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//        org.junit.Assert.assertNotNull(list22);
//        org.junit.Assert.assertNotNull(collection23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//        org.junit.Assert.assertNotNull(wildcardClass27);
//        org.junit.Assert.assertNotNull(timeZone29);
//        org.junit.Assert.assertNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(serialDate32);
//        org.junit.Assert.assertNotNull(serialDate33);
//    }

//    @Test
//    public void test246() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test246");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setDomainDescription("hi!");
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        java.util.Date date8 = day7.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) 0);
//        timeSeries4.setDescription("");
//        timeSeries4.setNotify(true);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        java.lang.String str16 = day15.toString();
//        java.util.Date date17 = day15.getStart();
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date17);
//        java.lang.Object obj19 = null;
//        int int20 = year18.compareTo(obj19);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) year18);
//        long long22 = year18.getLastMillisecond();
//        java.util.Calendar calendar23 = null;
//        try {
//            long long24 = year18.getLastMillisecond(calendar23);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(timeSeriesDataItem10);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "10-June-2019" + "'", str16.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem21);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1577865599999L + "'", long22 == 1577865599999L);
//    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
        timeSeries4.setDomainDescription("hi!");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        java.util.Date date8 = day7.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) 0);
        java.lang.Object obj11 = null;
        boolean boolean12 = timeSeries4.equals(obj11);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        java.util.Date date14 = day13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        java.lang.String str16 = month15.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month15.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month15, (double) (short) 100);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
        java.util.Date date21 = day20.getEnd();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(date21);
        java.lang.String str23 = month22.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = month22.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month22, (double) (short) 100);
        int int27 = timeSeriesDataItem19.compareTo((java.lang.Object) month22);
        try {
            timeSeries4.add(timeSeriesDataItem19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "June 2019" + "'", str16.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "June 2019" + "'", str23.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(12);
        java.util.Date date3 = spreadsheetDate2.toDate();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getEnd();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date5);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate6);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate12 = serialDate9.getEndOfCurrentMonth(serialDate11);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(serialDate9);
        boolean boolean15 = spreadsheetDate2.isInRange(serialDate6, serialDate9, 0);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (short) 1, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(serialDate16);
    }

//    @Test
//    public void test249() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test249");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day5);
//        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries4.createCopy(1, (int) (short) 100);
//        int int11 = timeSeries10.getMaximumItemCount();
//        java.lang.Object obj12 = timeSeries10.clone();
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(timeSeries10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2147483647 + "'", int11 == 2147483647);
//        org.junit.Assert.assertNotNull(obj12);
//    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
        timeSeries4.setMaximumItemCount((int) (byte) 0);
        boolean boolean7 = timeSeries4.getNotify();
        java.util.List list8 = timeSeries4.getItems();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries4.getDataItem(regularTimePeriod11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(list8);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (short) -1, 0, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test253() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test253");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
//        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(9);
//        boolean boolean4 = spreadsheetDate1.isOnOrAfter(serialDate3);
//        int int5 = spreadsheetDate1.getDayOfWeek();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        java.lang.String str7 = day6.toString();
//        long long8 = day6.getFirstMillisecond();
//        boolean boolean9 = spreadsheetDate1.equals((java.lang.Object) long8);
//        java.lang.Class class13 = null;
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class13);
//        timeSeries14.setDomainDescription("hi!");
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        java.util.Date date18 = day17.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day17, (java.lang.Number) 0);
//        timeSeries14.setDescription("");
//        timeSeries14.setNotify(true);
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        java.lang.String str26 = day25.toString();
//        java.util.Date date27 = day25.getStart();
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date27);
//        java.lang.Object obj29 = null;
//        int int30 = year28.compareTo(obj29);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries14.getDataItem((org.jfree.data.time.RegularTimePeriod) year28);
//        try {
//            int int32 = spreadsheetDate1.compareTo((java.lang.Object) timeSeriesDataItem31);
//            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.TimeSeriesDataItem cannot be cast to org.jfree.data.time.SerialDate");
//        } catch (java.lang.ClassCastException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10-June-2019" + "'", str7.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560150000000L + "'", long8 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNull(timeSeriesDataItem20);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "10-June-2019" + "'", str26.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem31);
//    }

//    @Test
//    public void test254() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test254");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
//        java.util.Date date3 = fixedMillisecond2.getTime();
//        long long4 = fixedMillisecond2.getSerialIndex();
//        long long5 = fixedMillisecond2.getFirstMillisecond();
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond2.getFirstMillisecond(calendar6);
//        long long8 = fixedMillisecond2.getSerialIndex();
//        long long9 = fixedMillisecond2.getLastMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560236399999L + "'", long5 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560236399999L + "'", long7 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560236399999L + "'", long8 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560236399999L + "'", long9 == 1560236399999L);
//    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(3);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Tuesday" + "'", str1.equals("Tuesday"));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        java.lang.String str3 = month2.toString();
        int int4 = month2.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month2.previous();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

//    @Test
//    public void test257() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test257");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setMaximumItemCount((int) (byte) 0);
//        boolean boolean7 = timeSeries4.getNotify();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class11);
//        timeSeries12.setDomainDescription("hi!");
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        java.util.Date date16 = day15.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day15, (java.lang.Number) 0);
//        java.lang.Object obj19 = null;
//        boolean boolean20 = timeSeries12.equals(obj19);
//        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries4.addAndOrUpdate(timeSeries12);
//        timeSeries21.setNotify(true);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        java.util.Date date25 = day24.getEnd();
//        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(date25);
//        java.lang.String str27 = month26.toString();
//        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean29 = month26.equals((java.lang.Object) timeZone28);
//        int int30 = month26.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = month26.previous();
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        java.util.Date date33 = day32.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond(date33);
//        java.util.Date date35 = fixedMillisecond34.getTime();
//        long long36 = fixedMillisecond34.getSerialIndex();
//        long long37 = fixedMillisecond34.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries21.createCopy((org.jfree.data.time.RegularTimePeriod) month26, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day();
//        java.util.Date date40 = day39.getEnd();
//        int int42 = day39.compareTo((java.lang.Object) (-1L));
//        java.lang.Class class46 = null;
//        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class46);
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
//        java.lang.String str49 = day48.toString();
//        timeSeries47.delete((org.jfree.data.time.RegularTimePeriod) day48);
//        timeSeries47.fireSeriesChanged();
//        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day();
//        java.util.Date date53 = day52.getEnd();
//        org.jfree.data.time.Month month54 = new org.jfree.data.time.Month(date53);
//        java.lang.Number number55 = timeSeries47.getValue((org.jfree.data.time.RegularTimePeriod) month54);
//        java.lang.Class class59 = null;
//        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class59);
//        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day();
//        java.lang.String str62 = day61.toString();
//        timeSeries60.delete((org.jfree.data.time.RegularTimePeriod) day61);
//        boolean boolean64 = timeSeries47.equals((java.lang.Object) day61);
//        boolean boolean65 = day39.equals((java.lang.Object) timeSeries47);
//        timeSeries47.setDomainDescription("ERROR : Relative To String");
//        timeSeries47.removeAgedItems(false);
//        java.lang.Comparable comparable70 = timeSeries47.getKey();
//        boolean boolean71 = timeSeries38.equals((java.lang.Object) comparable70);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNull(timeSeriesDataItem18);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(timeSeries21);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "June 2019" + "'", str27.equals("June 2019"));
//        org.junit.Assert.assertNotNull(timeZone28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560236399999L + "'", long36 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560236399999L + "'", long37 == 1560236399999L);
//        org.junit.Assert.assertNotNull(timeSeries38);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "10-June-2019" + "'", str49.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertNull(number55);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "10-June-2019" + "'", str62.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
//        org.junit.Assert.assertTrue("'" + comparable70 + "' != '" + (-1.0f) + "'", comparable70.equals((-1.0f)));
//        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
//    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(4, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear((int) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addMonths((int) (short) -1, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test261() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test261");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
//        java.util.Date date3 = fixedMillisecond2.getTime();
//        long long4 = fixedMillisecond2.getSerialIndex();
//        long long5 = fixedMillisecond2.getFirstMillisecond();
//        long long6 = fixedMillisecond2.getFirstMillisecond();
//        long long7 = fixedMillisecond2.getSerialIndex();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560236399999L + "'", long5 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560236399999L + "'", long6 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560236399999L + "'", long7 == 1560236399999L);
//    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("Monday");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
        timeSeries4.setMaximumItemCount((int) (byte) 0);
        boolean boolean7 = timeSeries4.getNotify();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class11);
        timeSeries12.setDomainDescription("hi!");
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        java.util.Date date16 = day15.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day15, (java.lang.Number) 0);
        java.lang.Object obj19 = null;
        boolean boolean20 = timeSeries12.equals(obj19);
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries4.addAndOrUpdate(timeSeries12);
        long long22 = timeSeries21.getMaximumItemAge();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(timeSeries21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 9223372036854775807L + "'", long22 == 9223372036854775807L);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("Tuesday");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate5 = serialDate2.getEndOfCurrentMonth(serialDate4);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate4);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class12);
        timeSeries13.setMaximumItemCount((int) (byte) 0);
        boolean boolean16 = timeSeries13.getNotify();
        timeSeries13.setKey((java.lang.Comparable) 10.0d);
        java.lang.Class<?> wildcardClass19 = timeSeries13.getClass();
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate6, "org.jfree.data.general.SeriesChangeEvent[source=10]", "July", (java.lang.Class) wildcardClass19);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(wildcardClass19);
    }

//    @Test
//    public void test266() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test266");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day5);
//        timeSeries4.fireSeriesChanged();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.util.Date date10 = day9.getEnd();
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
//        java.lang.Number number12 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month11);
//        int int13 = month11.getMonth();
//        int int14 = month11.getMonth();
//        long long15 = month11.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNull(number12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1559372400000L + "'", long15 == 1559372400000L);
//    }

//    @Test
//    public void test267() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test267");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        int int3 = day0.compareTo((java.lang.Object) (-1L));
//        java.lang.Class class7 = null;
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class7);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.lang.String str10 = day9.toString();
//        timeSeries8.delete((org.jfree.data.time.RegularTimePeriod) day9);
//        timeSeries8.fireSeriesChanged();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.util.Date date14 = day13.getEnd();
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
//        java.lang.Number number16 = timeSeries8.getValue((org.jfree.data.time.RegularTimePeriod) month15);
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class20);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.lang.String str23 = day22.toString();
//        timeSeries21.delete((org.jfree.data.time.RegularTimePeriod) day22);
//        boolean boolean25 = timeSeries8.equals((java.lang.Object) day22);
//        boolean boolean26 = day0.equals((java.lang.Object) timeSeries8);
//        timeSeries8.setDomainDescription("ERROR : Relative To String");
//        timeSeries8.setMaximumItemCount(3);
//        java.lang.Class class31 = timeSeries8.getTimePeriodClass();
//        timeSeries8.setNotify(false);
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        java.lang.String str35 = day34.toString();
//        java.util.Date date36 = day34.getStart();
//        long long37 = day34.getLastMillisecond();
//        int int38 = timeSeries8.getIndex((org.jfree.data.time.RegularTimePeriod) day34);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day34, (java.lang.Number) 1577865599999L);
//        java.lang.Number number41 = timeSeriesDataItem40.getValue();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "10-June-2019" + "'", str23.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNull(class31);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "10-June-2019" + "'", str35.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560236399999L + "'", long37 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
//        org.junit.Assert.assertTrue("'" + number41 + "' != '" + 1577865599999L + "'", number41.equals(1577865599999L));
//    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
        timeSeries4.setMaximumItemCount((int) (byte) 0);
        boolean boolean7 = timeSeries4.getNotify();
        java.lang.Comparable comparable8 = timeSeries4.getKey();
        timeSeries4.setMaximumItemCount(10);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0f) + "'", comparable8.equals((-1.0f)));
    }

//    @Test
//    public void test269() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test269");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day5);
//        timeSeries4.fireSeriesChanged();
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.getDataItem(2019);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2019, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(4);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

//    @Test
//    public void test271() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test271");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day5);
//        timeSeries4.fireSeriesChanged();
//        try {
//            org.jfree.data.time.TimeSeries timeSeries11 = timeSeries4.createCopy(2019, (-460));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//    }

//    @Test
//    public void test272() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test272");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
//        java.util.Date date3 = fixedMillisecond2.getTime();
//        long long4 = fixedMillisecond2.getSerialIndex();
//        long long5 = fixedMillisecond2.getFirstMillisecond();
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond2.getMiddleMillisecond(calendar6);
//        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate13 = serialDate10.getEndOfCurrentMonth(serialDate12);
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate12);
//        boolean boolean15 = fixedMillisecond2.equals((java.lang.Object) serialDate12);
//        long long16 = fixedMillisecond2.getMiddleMillisecond();
//        java.util.Date date17 = fixedMillisecond2.getTime();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560236399999L + "'", long5 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560236399999L + "'", long7 == 1560236399999L);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560236399999L + "'", long16 == 1560236399999L);
//        org.junit.Assert.assertNotNull(date17);
//    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate5 = serialDate2.getEndOfCurrentMonth(serialDate4);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate4);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(9);
        boolean boolean12 = spreadsheetDate9.isOnOrAfter(serialDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate20 = serialDate17.getEndOfCurrentMonth(serialDate19);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate19);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean24 = spreadsheetDate14.isInRange(serialDate19, (org.jfree.data.time.SerialDate) spreadsheetDate23);
        int int25 = spreadsheetDate14.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean28 = spreadsheetDate14.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate27);
        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate34 = serialDate31.getEndOfCurrentMonth(serialDate33);
        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.addDays(0, serialDate34);
        boolean boolean36 = spreadsheetDate14.isOnOrBefore(serialDate34);
        int int37 = spreadsheetDate9.compare((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SerialDate serialDate38 = serialDate6.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate(12);
        java.util.Date date41 = spreadsheetDate40.toDate();
        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.addDays((int) (byte) 1, serialDate44);
        boolean boolean46 = spreadsheetDate40.isAfter(serialDate45);
        boolean boolean47 = spreadsheetDate14.isOnOrBefore(serialDate45);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1900 + "'", int25 == 1900);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(serialDate38);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(12);
        java.util.Date date3 = spreadsheetDate2.toDate();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getEnd();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date5);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate6);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate12 = serialDate9.getEndOfCurrentMonth(serialDate11);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(serialDate9);
        boolean boolean15 = spreadsheetDate2.isInRange(serialDate6, serialDate9, 0);
        try {
            org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(12, serialDate6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate7 = serialDate4.getEndOfCurrentMonth(serialDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(12);
        java.util.Date date10 = spreadsheetDate9.toDate();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        java.util.Date date12 = day11.getEnd();
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance(date12);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(serialDate13);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate19 = serialDate16.getEndOfCurrentMonth(serialDate18);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(serialDate16);
        boolean boolean22 = spreadsheetDate9.isInRange(serialDate13, serialDate16, 0);
        boolean boolean23 = spreadsheetDate2.isInRange(serialDate6, serialDate13);
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.addDays(0, serialDate6);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(serialDate24);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate7 = serialDate4.getEndOfCurrentMonth(serialDate6);
        boolean boolean8 = spreadsheetDate2.isAfter(serialDate7);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addDays(7, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(serialDate9);
    }

//    @Test
//    public void test277() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test277");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setMaximumItemCount((int) (byte) 0);
//        boolean boolean7 = timeSeries4.getNotify();
//        java.util.List list8 = timeSeries4.getItems();
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class12);
//        timeSeries13.setMaximumItemCount((int) (byte) 0);
//        boolean boolean16 = timeSeries13.getNotify();
//        java.util.List list17 = timeSeries13.getItems();
//        java.util.Collection collection18 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries13);
//        boolean boolean19 = timeSeries4.isEmpty();
//        timeSeries4.setDomainDescription("2019");
//        java.lang.Class class25 = null;
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class25);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        java.lang.String str28 = day27.toString();
//        timeSeries26.delete((org.jfree.data.time.RegularTimePeriod) day27);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        java.util.Date date31 = day30.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond(date31);
//        java.util.Date date33 = fixedMillisecond32.getTime();
//        long long34 = fixedMillisecond32.getSerialIndex();
//        long long35 = fixedMillisecond32.getFirstMillisecond();
//        java.util.Calendar calendar36 = null;
//        long long37 = fixedMillisecond32.getMiddleMillisecond(calendar36);
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) day27, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond32);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener39 = null;
//        timeSeries4.addChangeListener(seriesChangeListener39);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(list8);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNotNull(list17);
//        org.junit.Assert.assertNotNull(collection18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "10-June-2019" + "'", str28.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560236399999L + "'", long34 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560236399999L + "'", long35 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560236399999L + "'", long37 == 1560236399999L);
//        org.junit.Assert.assertNotNull(timeSeries38);
//    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        java.lang.String str3 = month2.toString();
        int int4 = month2.getMonth();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = month2.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
    }

//    @Test
//    public void test279() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test279");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getLastMillisecond();
//        java.lang.String str3 = day0.toString();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = day0.getFirstMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10-June-2019" + "'", str3.equals("10-June-2019"));
//    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        java.lang.String str3 = month2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (double) (short) 100);
        int int7 = month2.getMonth();
        long long8 = month2.getLastMillisecond();
        long long9 = month2.getLastMillisecond();
        java.util.Calendar calendar10 = null;
        try {
            long long11 = month2.getFirstMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1561964399999L + "'", long8 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1561964399999L + "'", long9 == 1561964399999L);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
        timeSeries4.setMaximumItemCount((int) (byte) 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries4.removeChangeListener(seriesChangeListener7);
        timeSeries4.setNotify(true);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        java.util.Date date12 = day11.getEnd();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date12);
        java.lang.String str14 = month13.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month13.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month13, (double) (short) 100);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        java.util.Date date19 = day18.getEnd();
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(date19);
        java.lang.String str21 = month20.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month20.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month20, (double) (short) 100);
        int int25 = timeSeriesDataItem17.compareTo((java.lang.Object) month20);
        timeSeriesDataItem17.setValue((java.lang.Number) 6);
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate33 = serialDate30.getEndOfCurrentMonth(serialDate32);
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate32);
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(serialDate34);
        boolean boolean36 = timeSeriesDataItem17.equals((java.lang.Object) serialDate34);
        try {
            timeSeries4.add(timeSeriesDataItem17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "June 2019" + "'", str14.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "June 2019" + "'", str21.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(12, 4, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        java.util.Date date2 = spreadsheetDate1.toDate();
        int int3 = spreadsheetDate1.getMonth();
        org.jfree.data.time.SerialDate serialDate4 = null;
        try {
            boolean boolean5 = spreadsheetDate1.isOnOrBefore(serialDate4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        java.lang.String str3 = month2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (double) (short) 100);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        java.util.Date date8 = day7.getEnd();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date8);
        java.lang.String str10 = month9.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month9, (double) (short) 100);
        int int14 = timeSeriesDataItem6.compareTo((java.lang.Object) month9);
        timeSeriesDataItem6.setValue((java.lang.Number) 100);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate25 = serialDate22.getEndOfCurrentMonth(serialDate24);
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate24);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean29 = spreadsheetDate19.isInRange(serialDate24, (org.jfree.data.time.SerialDate) spreadsheetDate28);
        int int30 = spreadsheetDate19.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean33 = spreadsheetDate19.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate32);
        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate39 = serialDate36.getEndOfCurrentMonth(serialDate38);
        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate38);
        boolean boolean41 = spreadsheetDate32.isOnOrAfter(serialDate38);
        int int42 = spreadsheetDate32.getMonth();
        timeSeries17.setKey((java.lang.Comparable) int42);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "June 2019" + "'", str10.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1900 + "'", int30 == 1900);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertNotNull(serialDate38);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test286() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test286");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
//        java.util.Date date2 = spreadsheetDate1.toDate();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        java.util.Date date4 = day3.getEnd();
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
//        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate11 = serialDate8.getEndOfCurrentMonth(serialDate10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(serialDate8);
//        boolean boolean14 = spreadsheetDate1.isInRange(serialDate5, serialDate8, 0);
//        java.lang.Class class18 = null;
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class18);
//        timeSeries19.setMaximumItemCount((int) (byte) 0);
//        boolean boolean22 = timeSeries19.getNotify();
//        java.util.List list23 = timeSeries19.getItems();
//        java.lang.Class class27 = null;
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class27);
//        timeSeries28.setMaximumItemCount((int) (byte) 0);
//        boolean boolean31 = timeSeries28.getNotify();
//        java.util.List list32 = timeSeries28.getItems();
//        java.util.Collection collection33 = timeSeries19.getTimePeriodsUniqueToOtherSeries(timeSeries28);
//        java.util.List list34 = timeSeries19.getItems();
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        java.util.Date date36 = day35.getEnd();
//        int int38 = day35.compareTo((java.lang.Object) (-1L));
//        java.lang.Class class42 = null;
//        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class42);
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day();
//        java.lang.String str45 = day44.toString();
//        timeSeries43.delete((org.jfree.data.time.RegularTimePeriod) day44);
//        timeSeries43.fireSeriesChanged();
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
//        java.util.Date date49 = day48.getEnd();
//        org.jfree.data.time.Month month50 = new org.jfree.data.time.Month(date49);
//        java.lang.Number number51 = timeSeries43.getValue((org.jfree.data.time.RegularTimePeriod) month50);
//        java.lang.Class class55 = null;
//        org.jfree.data.time.TimeSeries timeSeries56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class55);
//        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day();
//        java.lang.String str58 = day57.toString();
//        timeSeries56.delete((org.jfree.data.time.RegularTimePeriod) day57);
//        boolean boolean60 = timeSeries43.equals((java.lang.Object) day57);
//        boolean boolean61 = day35.equals((java.lang.Object) timeSeries43);
//        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day();
//        java.lang.String str63 = day62.toString();
//        java.util.Date date64 = day62.getStart();
//        long long65 = day62.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries66 = timeSeries19.createCopy((org.jfree.data.time.RegularTimePeriod) day35, (org.jfree.data.time.RegularTimePeriod) day62);
//        java.lang.Object obj67 = timeSeries66.clone();
//        boolean boolean68 = spreadsheetDate1.equals(obj67);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertNotNull(list23);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
//        org.junit.Assert.assertNotNull(list32);
//        org.junit.Assert.assertNotNull(collection33);
//        org.junit.Assert.assertNotNull(list34);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "10-June-2019" + "'", str45.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertNull(number51);
//        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "10-June-2019" + "'", str58.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
//        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "10-June-2019" + "'", str63.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date64);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 1560236399999L + "'", long65 == 1560236399999L);
//        org.junit.Assert.assertNotNull(timeSeries66);
//        org.junit.Assert.assertNotNull(obj67);
//        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
//    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate7 = serialDate4.getEndOfCurrentMonth(serialDate6);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean11 = spreadsheetDate1.isInRange(serialDate6, (org.jfree.data.time.SerialDate) spreadsheetDate10);
        int int12 = spreadsheetDate1.getYYYY();
        java.util.Date date13 = spreadsheetDate1.toDate();
        org.jfree.data.time.SerialDate serialDate14 = null;
        try {
            boolean boolean15 = spreadsheetDate1.isOn(serialDate14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1900 + "'", int12 == 1900);
        org.junit.Assert.assertNotNull(date13);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(9);
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addMonths(2958465, serialDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
        timeSeries4.setMaximumItemCount((int) (byte) 0);
        boolean boolean7 = timeSeries4.getNotify();
        java.lang.Comparable comparable8 = timeSeries4.getKey();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener9);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = timeSeries4.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0f) + "'", comparable8.equals((-1.0f)));
    }

//    @Test
//    public void test290() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test290");
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        java.lang.String str2 = day1.toString();
//        java.util.Date date3 = day1.getStart();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
//        java.lang.Object obj5 = null;
//        int int6 = year4.compareTo(obj5);
//        int int7 = year4.getYear();
//        long long8 = year4.getFirstMillisecond();
//        try {
//            org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) 'a', year4);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10-June-2019" + "'", str2.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546329600000L + "'", long8 == 1546329600000L);
//    }

//    @Test
//    public void test291() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test291");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setDomainDescription("hi!");
//        java.lang.Object obj7 = timeSeries4.clone();
//        java.lang.String str8 = timeSeries4.getDescription();
//        timeSeries4.setMaximumItemAge((long) 9999);
//        java.lang.Class class14 = null;
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class14);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        java.lang.String str17 = day16.toString();
//        timeSeries15.delete((org.jfree.data.time.RegularTimePeriod) day16);
//        timeSeries15.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener20 = null;
//        timeSeries15.addPropertyChangeListener(propertyChangeListener20);
//        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries4.addAndOrUpdate(timeSeries15);
//        java.lang.Class class26 = null;
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class26);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        java.lang.String str29 = day28.toString();
//        timeSeries27.delete((org.jfree.data.time.RegularTimePeriod) day28);
//        try {
//            timeSeries22.update((org.jfree.data.time.RegularTimePeriod) day28, (java.lang.Number) 1560150000000L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(obj7);
//        org.junit.Assert.assertNull(str8);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "10-June-2019" + "'", str17.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(timeSeries22);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "10-June-2019" + "'", str29.equals("10-June-2019"));
//    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

//    @Test
//    public void test293() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test293");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        int int3 = day0.compareTo((java.lang.Object) (-1L));
//        java.lang.Class class7 = null;
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class7);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.lang.String str10 = day9.toString();
//        timeSeries8.delete((org.jfree.data.time.RegularTimePeriod) day9);
//        timeSeries8.fireSeriesChanged();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.util.Date date14 = day13.getEnd();
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
//        java.lang.Number number16 = timeSeries8.getValue((org.jfree.data.time.RegularTimePeriod) month15);
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class20);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.lang.String str23 = day22.toString();
//        timeSeries21.delete((org.jfree.data.time.RegularTimePeriod) day22);
//        boolean boolean25 = timeSeries8.equals((java.lang.Object) day22);
//        boolean boolean26 = day0.equals((java.lang.Object) timeSeries8);
//        timeSeries8.setDomainDescription("ERROR : Relative To String");
//        java.lang.String str29 = timeSeries8.getRangeDescription();
//        try {
//            timeSeries8.delete((int) (byte) -1, 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "10-June-2019" + "'", str23.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "hi!" + "'", str29.equals("hi!"));
//    }

//    @Test
//    public void test294() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test294");
//        java.lang.Class class4 = null;
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class4);
//        timeSeries5.setMaximumItemCount((int) (byte) 0);
//        boolean boolean8 = timeSeries5.getNotify();
//        timeSeries5.setKey((java.lang.Comparable) 10.0d);
//        java.lang.Class<?> wildcardClass11 = timeSeries5.getClass();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        java.lang.String str13 = day12.toString();
//        java.util.Date date14 = day12.getStart();
//        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date14);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        java.util.Date date17 = day16.getEnd();
//        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(date17);
//        java.lang.String str19 = month18.toString();
//        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean21 = month18.equals((java.lang.Object) timeZone20);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date14, timeZone20);
//        java.lang.Class class23 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        java.util.Date date25 = day24.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond(date25);
//        java.util.Date date27 = fixedMillisecond26.getTime();
//        java.lang.Class class31 = null;
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class31);
//        timeSeries32.setMaximumItemCount((int) (byte) 0);
//        boolean boolean35 = timeSeries32.getNotify();
//        timeSeries32.setKey((java.lang.Comparable) 10.0d);
//        java.lang.Class<?> wildcardClass38 = timeSeries32.getClass();
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day();
//        java.lang.String str40 = day39.toString();
//        java.util.Date date41 = day39.getStart();
//        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year(date41);
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
//        java.util.Date date44 = day43.getEnd();
//        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month(date44);
//        java.lang.String str46 = month45.toString();
//        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean48 = month45.equals((java.lang.Object) timeZone47);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass38, date41, timeZone47);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date27, timeZone47);
//        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f, (java.lang.Class) wildcardClass11);
//        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day();
//        java.lang.String str53 = day52.toString();
//        java.util.Date date54 = day52.getStart();
//        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year(date54);
//        long long56 = year55.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem58 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year55, (java.lang.Number) 100.0f);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem59 = timeSeries51.getDataItem((org.jfree.data.time.RegularTimePeriod) year55);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "10-June-2019" + "'", str13.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "June 2019" + "'", str19.equals("June 2019"));
//        org.junit.Assert.assertNotNull(timeZone20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(class23);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
//        org.junit.Assert.assertNotNull(wildcardClass38);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "10-June-2019" + "'", str40.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "June 2019" + "'", str46.equals("June 2019"));
//        org.junit.Assert.assertNotNull(timeZone47);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertNull(regularTimePeriod49);
//        org.junit.Assert.assertNull(regularTimePeriod50);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "10-June-2019" + "'", str53.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1577865599999L + "'", long56 == 1577865599999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem59);
//    }

//    @Test
//    public void test295() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test295");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        java.util.Date date2 = day0.getStart();
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
//        long long4 = year3.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year3, (java.lang.Number) 100.0f);
//        int int8 = timeSeriesDataItem6.compareTo((java.lang.Object) 1560150000000L);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(5);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

//    @Test
//    public void test297() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test297");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day5);
//        timeSeries4.setRangeDescription("January");
//        try {
//            timeSeries4.delete(0, 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(6, (int) (short) 1);
    }

//    @Test
//    public void test299() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test299");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.String str1 = fixedMillisecond0.toString();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Mon Jun 10 11:43:32 PDT 2019" + "'", str1.equals("Mon Jun 10 11:43:32 PDT 2019"));
//    }

//    @Test
//    public void test300() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test300");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day5);
//        timeSeries4.fireSeriesChanged();
//        timeSeries4.removeAgedItems(false);
//        java.lang.Class class14 = null;
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class14);
//        timeSeries15.setMaximumItemCount((int) (byte) 0);
//        boolean boolean18 = timeSeries15.getNotify();
//        java.util.List list19 = timeSeries15.getItems();
//        java.lang.Class class23 = null;
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class23);
//        timeSeries24.setMaximumItemCount((int) (byte) 0);
//        boolean boolean27 = timeSeries24.getNotify();
//        java.util.List list28 = timeSeries24.getItems();
//        java.util.Collection collection29 = timeSeries15.getTimePeriodsUniqueToOtherSeries(timeSeries24);
//        boolean boolean30 = timeSeries15.isEmpty();
//        timeSeries15.setDomainDescription("2019");
//        java.lang.Class class36 = null;
//        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class36);
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
//        java.lang.String str39 = day38.toString();
//        timeSeries37.delete((org.jfree.data.time.RegularTimePeriod) day38);
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
//        java.util.Date date42 = day41.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond(date42);
//        java.util.Date date44 = fixedMillisecond43.getTime();
//        long long45 = fixedMillisecond43.getSerialIndex();
//        long long46 = fixedMillisecond43.getFirstMillisecond();
//        java.util.Calendar calendar47 = null;
//        long long48 = fixedMillisecond43.getMiddleMillisecond(calendar47);
//        org.jfree.data.time.TimeSeries timeSeries49 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) day38, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond43);
//        java.util.Collection collection50 = timeSeries15.getTimePeriods();
//        int int51 = timeSeries15.getMaximumItemCount();
//        java.util.Collection collection52 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries15);
//        try {
//            org.jfree.data.time.TimeSeries timeSeries55 = timeSeries4.createCopy((int) '4', (-460));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertNotNull(list19);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//        org.junit.Assert.assertNotNull(list28);
//        org.junit.Assert.assertNotNull(collection29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "10-June-2019" + "'", str39.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1560236399999L + "'", long45 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1560236399999L + "'", long46 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1560236399999L + "'", long48 == 1560236399999L);
//        org.junit.Assert.assertNotNull(timeSeries49);
//        org.junit.Assert.assertNotNull(collection50);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
//        org.junit.Assert.assertNotNull(collection52);
//    }

//    @Test
//    public void test301() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test301");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        java.util.Date date2 = day0.getStart();
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
//        java.lang.Object obj4 = null;
//        int int5 = year3.compareTo(obj4);
//        int int6 = year3.getYear();
//        java.util.Calendar calendar7 = null;
//        try {
//            long long8 = year3.getFirstMillisecond(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(2958465);
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addYears(9999, serialDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((-460), true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test305() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test305");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
//        java.util.Date date3 = fixedMillisecond2.getTime();
//        long long4 = fixedMillisecond2.getSerialIndex();
//        long long5 = fixedMillisecond2.getFirstMillisecond();
//        java.util.Calendar calendar6 = null;
//        fixedMillisecond2.peg(calendar6);
//        long long8 = fixedMillisecond2.getLastMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560236399999L + "'", long5 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560236399999L + "'", long8 == 1560236399999L);
//    }

//    @Test
//    public void test306() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test306");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getFirstMillisecond();
//        int int3 = day0.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) 100.0d);
//        java.lang.String str6 = day0.toString();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//    }

//    @Test
//    public void test307() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test307");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.next();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, 4, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test309() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test309");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setMaximumItemCount((int) (byte) 0);
//        boolean boolean7 = timeSeries4.getNotify();
//        java.util.List list8 = timeSeries4.getItems();
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class12);
//        timeSeries13.setMaximumItemCount((int) (byte) 0);
//        boolean boolean16 = timeSeries13.getNotify();
//        java.util.List list17 = timeSeries13.getItems();
//        java.util.Collection collection18 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries13);
//        boolean boolean19 = timeSeries4.isEmpty();
//        timeSeries4.setDomainDescription("2019");
//        java.lang.Class class25 = null;
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class25);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        java.lang.String str28 = day27.toString();
//        timeSeries26.delete((org.jfree.data.time.RegularTimePeriod) day27);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        java.util.Date date31 = day30.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond(date31);
//        java.util.Date date33 = fixedMillisecond32.getTime();
//        long long34 = fixedMillisecond32.getSerialIndex();
//        long long35 = fixedMillisecond32.getFirstMillisecond();
//        java.util.Calendar calendar36 = null;
//        long long37 = fixedMillisecond32.getMiddleMillisecond(calendar36);
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) day27, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond32);
//        java.util.Collection collection39 = timeSeries4.getTimePeriods();
//        int int40 = timeSeries4.getMaximumItemCount();
//        java.lang.Class class41 = timeSeries4.getTimePeriodClass();
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
//        java.util.Date date43 = day42.getEnd();
//        int int45 = day42.compareTo((java.lang.Object) (-1L));
//        java.lang.Class class49 = null;
//        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class49);
//        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day();
//        java.lang.String str52 = day51.toString();
//        timeSeries50.delete((org.jfree.data.time.RegularTimePeriod) day51);
//        timeSeries50.fireSeriesChanged();
//        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day();
//        java.util.Date date56 = day55.getEnd();
//        org.jfree.data.time.Month month57 = new org.jfree.data.time.Month(date56);
//        java.lang.Number number58 = timeSeries50.getValue((org.jfree.data.time.RegularTimePeriod) month57);
//        java.lang.Class class62 = null;
//        org.jfree.data.time.TimeSeries timeSeries63 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class62);
//        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day();
//        java.lang.String str65 = day64.toString();
//        timeSeries63.delete((org.jfree.data.time.RegularTimePeriod) day64);
//        boolean boolean67 = timeSeries50.equals((java.lang.Object) day64);
//        boolean boolean68 = day42.equals((java.lang.Object) timeSeries50);
//        timeSeries50.setDomainDescription("ERROR : Relative To String");
//        java.lang.String str71 = timeSeries50.getRangeDescription();
//        java.lang.String str72 = timeSeries50.getRangeDescription();
//        org.jfree.data.time.Day day73 = new org.jfree.data.time.Day();
//        java.lang.String str74 = day73.toString();
//        long long75 = day73.getFirstMillisecond();
//        java.lang.Number number76 = timeSeries50.getValue((org.jfree.data.time.RegularTimePeriod) day73);
//        long long77 = day73.getLastMillisecond();
//        try {
//            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) day73, (java.lang.Number) 43626L, true);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(list8);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNotNull(list17);
//        org.junit.Assert.assertNotNull(collection18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "10-June-2019" + "'", str28.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560236399999L + "'", long34 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560236399999L + "'", long35 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560236399999L + "'", long37 == 1560236399999L);
//        org.junit.Assert.assertNotNull(timeSeries38);
//        org.junit.Assert.assertNotNull(collection39);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
//        org.junit.Assert.assertNull(class41);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "10-June-2019" + "'", str52.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertNull(number58);
//        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "10-June-2019" + "'", str65.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
//        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
//        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "hi!" + "'", str71.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "hi!" + "'", str72.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "10-June-2019" + "'", str74.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 1560150000000L + "'", long75 == 1560150000000L);
//        org.junit.Assert.assertNull(number76);
//        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 1560236399999L + "'", long77 == 1560236399999L);
//    }

//    @Test
//    public void test310() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test310");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
//        java.util.Date date3 = fixedMillisecond2.getTime();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.util.Date date5 = day4.getEnd();
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date5);
//        java.lang.String str7 = month6.toString();
//        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean9 = month6.equals((java.lang.Object) timeZone8);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date3, timeZone8);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.next();
//        long long12 = day10.getFirstMillisecond();
//        java.util.Calendar calendar13 = null;
//        try {
//            long long14 = day10.getFirstMillisecond(calendar13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "June 2019" + "'", str7.equals("June 2019"));
//        org.junit.Assert.assertNotNull(timeZone8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560150000000L + "'", long12 == 1560150000000L);
//    }

//    @Test
//    public void test311() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test311");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setMaximumItemCount((int) (byte) 0);
//        boolean boolean7 = timeSeries4.getNotify();
//        java.util.List list8 = timeSeries4.getItems();
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class12);
//        timeSeries13.setMaximumItemCount((int) (byte) 0);
//        boolean boolean16 = timeSeries13.getNotify();
//        java.util.List list17 = timeSeries13.getItems();
//        java.util.Collection collection18 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries13);
//        java.util.List list19 = timeSeries4.getItems();
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        java.util.Date date21 = day20.getEnd();
//        int int23 = day20.compareTo((java.lang.Object) (-1L));
//        java.lang.Class class27 = null;
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class27);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        java.lang.String str30 = day29.toString();
//        timeSeries28.delete((org.jfree.data.time.RegularTimePeriod) day29);
//        timeSeries28.fireSeriesChanged();
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        java.util.Date date34 = day33.getEnd();
//        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(date34);
//        java.lang.Number number36 = timeSeries28.getValue((org.jfree.data.time.RegularTimePeriod) month35);
//        java.lang.Class class40 = null;
//        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class40);
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
//        java.lang.String str43 = day42.toString();
//        timeSeries41.delete((org.jfree.data.time.RegularTimePeriod) day42);
//        boolean boolean45 = timeSeries28.equals((java.lang.Object) day42);
//        boolean boolean46 = day20.equals((java.lang.Object) timeSeries28);
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
//        java.lang.String str48 = day47.toString();
//        java.util.Date date49 = day47.getStart();
//        long long50 = day47.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) day20, (org.jfree.data.time.RegularTimePeriod) day47);
//        java.lang.String str52 = timeSeries51.getRangeDescription();
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(list8);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNotNull(list17);
//        org.junit.Assert.assertNotNull(collection18);
//        org.junit.Assert.assertNotNull(list19);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "10-June-2019" + "'", str30.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNull(number36);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "10-June-2019" + "'", str43.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "10-June-2019" + "'", str48.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1560236399999L + "'", long50 == 1560236399999L);
//        org.junit.Assert.assertNotNull(timeSeries51);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "hi!" + "'", str52.equals("hi!"));
//    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate7 = serialDate4.getEndOfCurrentMonth(serialDate6);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean11 = spreadsheetDate1.isInRange(serialDate6, (org.jfree.data.time.SerialDate) spreadsheetDate10);
        int int12 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean15 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate14);
        int int16 = spreadsheetDate1.getMonth();
        try {
            org.jfree.data.time.SerialDate serialDate18 = spreadsheetDate1.getNearestDayOfWeek((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1900 + "'", int12 == 1900);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        java.lang.String str3 = month2.toString();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean5 = month2.equals((java.lang.Object) timeZone4);
        int int6 = month2.getYearValue();
        long long7 = month2.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1559372400000L + "'", long7 == 1559372400000L);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(3);
        int int3 = spreadsheetDate2.toSerial();
        try {
            org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
    }

//    @Test
//    public void test315() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test315");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        java.util.Date date2 = day0.getStart();
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
//        java.lang.Object obj4 = null;
//        int int5 = year3.compareTo(obj4);
//        int int6 = year3.getYear();
//        long long7 = year3.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
//    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate7 = serialDate4.getEndOfCurrentMonth(serialDate6);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean11 = spreadsheetDate1.isInRange(serialDate6, (org.jfree.data.time.SerialDate) spreadsheetDate10);
        int int12 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean15 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate21 = serialDate18.getEndOfCurrentMonth(serialDate20);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addDays(0, serialDate21);
        boolean boolean23 = spreadsheetDate1.isOnOrBefore(serialDate21);
        int int24 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(12);
        java.util.Date date27 = spreadsheetDate26.toDate();
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
        java.util.Date date29 = day28.getEnd();
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.createInstance(date29);
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(serialDate30);
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate36 = serialDate33.getEndOfCurrentMonth(serialDate35);
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(serialDate33);
        boolean boolean39 = spreadsheetDate26.isInRange(serialDate30, serialDate33, 0);
        boolean boolean40 = spreadsheetDate1.isOn(serialDate33);
        org.jfree.data.time.SerialDate serialDate42 = serialDate33.getNearestDayOfWeek(4);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1900 + "'", int12 == 1900);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1900 + "'", int24 == 1900);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(serialDate42);
    }

//    @Test
//    public void test317() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test317");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
//        java.util.Date date3 = fixedMillisecond2.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond2.previous();
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond2.getFirstMillisecond(calendar5);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560236399999L + "'", long6 == 1560236399999L);
//    }

//    @Test
//    public void test318() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test318");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        java.util.Date date2 = day0.getStart();
//        int int3 = day0.getMonth();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((int) '#');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test320() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test320");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day5);
//        timeSeries4.fireSeriesChanged();
//        timeSeries4.removeAgedItems(false);
//        java.lang.Number number12 = null;
//        try {
//            timeSeries4.update(6, number12);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(9);
        boolean boolean4 = spreadsheetDate1.isOnOrAfter(serialDate3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        long long6 = day5.getFirstMillisecond();
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-2208873600000L) + "'", long6 == (-2208873600000L));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        java.lang.String str3 = month2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (double) (short) 100);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        java.util.Date date8 = day7.getEnd();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date8);
        java.lang.String str10 = month9.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month9, (double) (short) 100);
        int int14 = timeSeriesDataItem6.compareTo((java.lang.Object) month9);
        timeSeriesDataItem6.setValue((java.lang.Number) 6);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate22 = serialDate19.getEndOfCurrentMonth(serialDate21);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate21);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(serialDate23);
        boolean boolean25 = timeSeriesDataItem6.equals((java.lang.Object) serialDate23);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = timeSeriesDataItem6.getPeriod();
        timeSeriesDataItem6.setValue((java.lang.Number) (short) 0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "June 2019" + "'", str10.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
    }

//    @Test
//    public void test323() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test323");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        int int3 = day0.compareTo((java.lang.Object) (-1L));
//        java.lang.Class class7 = null;
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class7);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.lang.String str10 = day9.toString();
//        timeSeries8.delete((org.jfree.data.time.RegularTimePeriod) day9);
//        timeSeries8.fireSeriesChanged();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.util.Date date14 = day13.getEnd();
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
//        java.lang.Number number16 = timeSeries8.getValue((org.jfree.data.time.RegularTimePeriod) month15);
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class20);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.lang.String str23 = day22.toString();
//        timeSeries21.delete((org.jfree.data.time.RegularTimePeriod) day22);
//        boolean boolean25 = timeSeries8.equals((java.lang.Object) day22);
//        boolean boolean26 = day0.equals((java.lang.Object) timeSeries8);
//        timeSeries8.setDomainDescription("ERROR : Relative To String");
//        timeSeries8.setMaximumItemCount(3);
//        java.lang.Class class31 = timeSeries8.getTimePeriodClass();
//        timeSeries8.setNotify(false);
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        java.lang.String str35 = day34.toString();
//        java.util.Date date36 = day34.getStart();
//        long long37 = day34.getLastMillisecond();
//        int int38 = timeSeries8.getIndex((org.jfree.data.time.RegularTimePeriod) day34);
//        java.util.Calendar calendar39 = null;
//        try {
//            long long40 = day34.getFirstMillisecond(calendar39);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "10-June-2019" + "'", str23.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNull(class31);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "10-June-2019" + "'", str35.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560236399999L + "'", long37 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
//    }

//    @Test
//    public void test324() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test324");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        int int3 = day0.compareTo((java.lang.Object) (-1L));
//        java.lang.Class class7 = null;
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class7);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.lang.String str10 = day9.toString();
//        timeSeries8.delete((org.jfree.data.time.RegularTimePeriod) day9);
//        timeSeries8.fireSeriesChanged();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.util.Date date14 = day13.getEnd();
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
//        java.lang.Number number16 = timeSeries8.getValue((org.jfree.data.time.RegularTimePeriod) month15);
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class20);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.lang.String str23 = day22.toString();
//        timeSeries21.delete((org.jfree.data.time.RegularTimePeriod) day22);
//        boolean boolean25 = timeSeries8.equals((java.lang.Object) day22);
//        boolean boolean26 = day0.equals((java.lang.Object) timeSeries8);
//        timeSeries8.setDomainDescription("ERROR : Relative To String");
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        java.lang.String str30 = day29.toString();
//        java.util.Date date31 = day29.getStart();
//        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date31);
//        long long33 = year32.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = year32.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod34, (java.lang.Number) (short) -1);
//        try {
//            timeSeries8.update(regularTimePeriod34, (java.lang.Number) 10L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "10-June-2019" + "'", str23.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "10-June-2019" + "'", str30.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1577865599999L + "'", long33 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//    }

//    @Test
//    public void test325() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test325");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day5);
//        timeSeries4.fireSeriesChanged();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.util.Date date10 = day9.getEnd();
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
//        java.lang.Number number12 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month11);
//        java.lang.Class class13 = null;
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month11, class13);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        java.lang.String str16 = day15.toString();
//        java.util.Date date17 = day15.getStart();
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date17);
//        long long19 = year18.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year18.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod20, (java.lang.Number) (short) -1);
//        try {
//            timeSeries14.add(timeSeriesDataItem22);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNull(number12);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "10-June-2019" + "'", str16.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1577865599999L + "'", long19 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(9);
        boolean boolean4 = spreadsheetDate1.isOnOrAfter(serialDate3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        java.util.Calendar calendar6 = null;
        try {
            long long7 = day5.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

//    @Test
//    public void test327() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test327");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setMaximumItemCount((int) (byte) 0);
//        boolean boolean7 = timeSeries4.getNotify();
//        java.util.List list8 = timeSeries4.getItems();
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class12);
//        timeSeries13.setMaximumItemCount((int) (byte) 0);
//        boolean boolean16 = timeSeries13.getNotify();
//        java.util.List list17 = timeSeries13.getItems();
//        java.util.Collection collection18 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries13);
//        java.util.List list19 = timeSeries4.getItems();
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        java.util.Date date21 = day20.getEnd();
//        int int23 = day20.compareTo((java.lang.Object) (-1L));
//        java.lang.Class class27 = null;
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class27);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        java.lang.String str30 = day29.toString();
//        timeSeries28.delete((org.jfree.data.time.RegularTimePeriod) day29);
//        timeSeries28.fireSeriesChanged();
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        java.util.Date date34 = day33.getEnd();
//        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(date34);
//        java.lang.Number number36 = timeSeries28.getValue((org.jfree.data.time.RegularTimePeriod) month35);
//        java.lang.Class class40 = null;
//        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class40);
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
//        java.lang.String str43 = day42.toString();
//        timeSeries41.delete((org.jfree.data.time.RegularTimePeriod) day42);
//        boolean boolean45 = timeSeries28.equals((java.lang.Object) day42);
//        boolean boolean46 = day20.equals((java.lang.Object) timeSeries28);
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
//        java.lang.String str48 = day47.toString();
//        java.util.Date date49 = day47.getStart();
//        long long50 = day47.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) day20, (org.jfree.data.time.RegularTimePeriod) day47);
//        java.lang.Object obj52 = timeSeries51.clone();
//        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day();
//        java.util.Date date54 = day53.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond55 = new org.jfree.data.time.FixedMillisecond(date54);
//        java.util.Date date56 = fixedMillisecond55.getTime();
//        long long57 = fixedMillisecond55.getSerialIndex();
//        long long58 = fixedMillisecond55.getFirstMillisecond();
//        java.util.Calendar calendar59 = null;
//        long long60 = fixedMillisecond55.getMiddleMillisecond(calendar59);
//        org.jfree.data.time.SerialDate serialDate63 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate65 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate66 = serialDate63.getEndOfCurrentMonth(serialDate65);
//        org.jfree.data.time.SerialDate serialDate67 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate65);
//        boolean boolean68 = fixedMillisecond55.equals((java.lang.Object) serialDate65);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = fixedMillisecond55.next();
//        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day();
//        java.util.Date date71 = day70.getEnd();
//        org.jfree.data.time.Month month72 = new org.jfree.data.time.Month(date71);
//        java.lang.String str73 = month72.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = month72.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem76 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month72, (double) (short) 100);
//        timeSeriesDataItem76.setValue((java.lang.Number) (-1L));
//        int int79 = fixedMillisecond55.compareTo((java.lang.Object) timeSeriesDataItem76);
//        try {
//            timeSeries51.add(timeSeriesDataItem76);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(list8);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNotNull(list17);
//        org.junit.Assert.assertNotNull(collection18);
//        org.junit.Assert.assertNotNull(list19);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "10-June-2019" + "'", str30.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNull(number36);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "10-June-2019" + "'", str43.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "10-June-2019" + "'", str48.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1560236399999L + "'", long50 == 1560236399999L);
//        org.junit.Assert.assertNotNull(timeSeries51);
//        org.junit.Assert.assertNotNull(obj52);
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 1560236399999L + "'", long57 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1560236399999L + "'", long58 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1560236399999L + "'", long60 == 1560236399999L);
//        org.junit.Assert.assertNotNull(serialDate63);
//        org.junit.Assert.assertNotNull(serialDate65);
//        org.junit.Assert.assertNotNull(serialDate66);
//        org.junit.Assert.assertNotNull(serialDate67);
//        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod69);
//        org.junit.Assert.assertNotNull(date71);
//        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "June 2019" + "'", str73.equals("June 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod74);
//        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 1 + "'", int79 == 1);
//    }

//    @Test
//    public void test328() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test328");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        java.util.Date date2 = day0.getStart();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) 10.0f);
//        java.lang.Number number5 = timeSeriesDataItem4.getValue();
//        timeSeriesDataItem4.setValue((java.lang.Number) (short) 100);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10.0d + "'", number5.equals(10.0d));
//    }

//    @Test
//    public void test329() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test329");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        int int3 = day0.compareTo((java.lang.Object) (-1L));
//        java.lang.Class class7 = null;
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class7);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.lang.String str10 = day9.toString();
//        timeSeries8.delete((org.jfree.data.time.RegularTimePeriod) day9);
//        timeSeries8.fireSeriesChanged();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.util.Date date14 = day13.getEnd();
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
//        java.lang.Number number16 = timeSeries8.getValue((org.jfree.data.time.RegularTimePeriod) month15);
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class20);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.lang.String str23 = day22.toString();
//        timeSeries21.delete((org.jfree.data.time.RegularTimePeriod) day22);
//        boolean boolean25 = timeSeries8.equals((java.lang.Object) day22);
//        boolean boolean26 = day0.equals((java.lang.Object) timeSeries8);
//        timeSeries8.setDomainDescription("ERROR : Relative To String");
//        timeSeries8.removeAgedItems(false);
//        java.lang.Comparable comparable31 = timeSeries8.getKey();
//        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month();
//        java.lang.String str33 = month32.toString();
//        timeSeries8.setKey((java.lang.Comparable) str33);
//        try {
//            timeSeries8.delete((int) ' ', 1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "10-June-2019" + "'", str23.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + comparable31 + "' != '" + (-1.0f) + "'", comparable31.equals((-1.0f)));
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "June 2019" + "'", str33.equals("June 2019"));
//    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesChangeEvent[source=10]");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        int int2 = spreadsheetDate1.getYYYY();
        int int3 = spreadsheetDate1.getDayOfMonth();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1900 + "'", int2 == 1900);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2 + "'", int3 == 2);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate6 = serialDate3.getEndOfCurrentMonth(serialDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(12);
        java.util.Date date9 = spreadsheetDate8.toDate();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        java.util.Date date11 = day10.getEnd();
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance(date11);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(serialDate12);
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate18 = serialDate15.getEndOfCurrentMonth(serialDate17);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(serialDate15);
        boolean boolean21 = spreadsheetDate8.isInRange(serialDate12, serialDate15, 0);
        boolean boolean22 = spreadsheetDate1.isInRange(serialDate5, serialDate12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(3);
        int int25 = spreadsheetDate24.getYYYY();
        org.jfree.data.time.SerialDate serialDate26 = serialDate5.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate24);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1900 + "'", int25 == 1900);
        org.junit.Assert.assertNotNull(serialDate26);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(9);
        boolean boolean4 = spreadsheetDate1.isOnOrAfter(serialDate3);
        int int5 = spreadsheetDate1.getDayOfWeek();
        int int6 = spreadsheetDate1.getDayOfMonth();
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
    }

//    @Test
//    public void test335() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test335");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        java.util.Date date4 = day3.getEnd();
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date4);
//        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(date4);
//        boolean boolean8 = day0.equals((java.lang.Object) serialDate7);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(12);
//        java.util.Date date11 = spreadsheetDate10.toDate();
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.addDays((int) (byte) 1, serialDate14);
//        boolean boolean16 = spreadsheetDate10.isAfter(serialDate15);
//        org.jfree.data.time.SerialDate serialDate17 = serialDate7.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate10);
//        int int18 = spreadsheetDate10.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 11 + "'", int18 == 11);
//    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate6 = serialDate3.getEndOfCurrentMonth(serialDate5);
        boolean boolean7 = spreadsheetDate1.isAfter(serialDate6);
        java.lang.String str8 = spreadsheetDate1.toString();
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "11-January-1900" + "'", str8.equals("11-January-1900"));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addDays((int) (byte) 1, serialDate5);
        boolean boolean7 = spreadsheetDate1.isAfter(serialDate6);
        java.lang.String str8 = spreadsheetDate1.toString();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "11-January-1900" + "'", str8.equals("11-January-1900"));
    }

//    @Test
//    public void test338() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test338");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day5);
//        timeSeries4.fireSeriesChanged();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.util.Date date10 = day9.getEnd();
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
//        java.lang.Number number12 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month11);
//        java.lang.Class class13 = null;
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month11, class13);
//        timeSeries14.setRangeDescription("10-June-2019");
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class20);
//        timeSeries21.setMaximumItemCount((int) (byte) 0);
//        boolean boolean24 = timeSeries21.getNotify();
//        java.util.List list25 = timeSeries21.getItems();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent26 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeries21);
//        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries14.addAndOrUpdate(timeSeries21);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNull(number12);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//        org.junit.Assert.assertNotNull(list25);
//        org.junit.Assert.assertNotNull(timeSeries27);
//    }

//    @Test
//    public void test339() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test339");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day5);
//        timeSeries4.fireSeriesChanged();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.util.Date date10 = day9.getEnd();
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
//        java.lang.Number number12 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month11);
//        java.lang.Class class16 = null;
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class16);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        java.lang.String str19 = day18.toString();
//        timeSeries17.delete((org.jfree.data.time.RegularTimePeriod) day18);
//        boolean boolean21 = timeSeries4.equals((java.lang.Object) day18);
//        java.lang.Class class25 = null;
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class25);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        java.lang.String str28 = day27.toString();
//        timeSeries26.delete((org.jfree.data.time.RegularTimePeriod) day27);
//        timeSeries26.fireSeriesChanged();
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        java.util.Date date32 = day31.getEnd();
//        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(date32);
//        java.lang.Number number34 = timeSeries26.getValue((org.jfree.data.time.RegularTimePeriod) month33);
//        int int35 = month33.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = month33.previous();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) month33);
//        java.lang.Class class41 = null;
//        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class41);
//        timeSeries42.setMaximumItemCount((int) (byte) 0);
//        boolean boolean45 = timeSeries42.getNotify();
//        java.util.List list46 = timeSeries42.getItems();
//        java.lang.Class class50 = null;
//        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class50);
//        timeSeries51.setMaximumItemCount((int) (byte) 0);
//        boolean boolean54 = timeSeries51.getNotify();
//        java.util.List list55 = timeSeries51.getItems();
//        java.util.Collection collection56 = timeSeries42.getTimePeriodsUniqueToOtherSeries(timeSeries51);
//        java.util.List list57 = timeSeries42.getItems();
//        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day();
//        java.util.Date date59 = day58.getEnd();
//        int int61 = day58.compareTo((java.lang.Object) (-1L));
//        java.lang.Class class65 = null;
//        org.jfree.data.time.TimeSeries timeSeries66 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class65);
//        org.jfree.data.time.Day day67 = new org.jfree.data.time.Day();
//        java.lang.String str68 = day67.toString();
//        timeSeries66.delete((org.jfree.data.time.RegularTimePeriod) day67);
//        timeSeries66.fireSeriesChanged();
//        org.jfree.data.time.Day day71 = new org.jfree.data.time.Day();
//        java.util.Date date72 = day71.getEnd();
//        org.jfree.data.time.Month month73 = new org.jfree.data.time.Month(date72);
//        java.lang.Number number74 = timeSeries66.getValue((org.jfree.data.time.RegularTimePeriod) month73);
//        java.lang.Class class78 = null;
//        org.jfree.data.time.TimeSeries timeSeries79 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class78);
//        org.jfree.data.time.Day day80 = new org.jfree.data.time.Day();
//        java.lang.String str81 = day80.toString();
//        timeSeries79.delete((org.jfree.data.time.RegularTimePeriod) day80);
//        boolean boolean83 = timeSeries66.equals((java.lang.Object) day80);
//        boolean boolean84 = day58.equals((java.lang.Object) timeSeries66);
//        org.jfree.data.time.Day day85 = new org.jfree.data.time.Day();
//        java.lang.String str86 = day85.toString();
//        java.util.Date date87 = day85.getStart();
//        long long88 = day85.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries89 = timeSeries42.createCopy((org.jfree.data.time.RegularTimePeriod) day58, (org.jfree.data.time.RegularTimePeriod) day85);
//        timeSeries89.fireSeriesChanged();
//        java.util.Collection collection91 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries89);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNull(number12);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "10-June-2019" + "'", str19.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "10-June-2019" + "'", str28.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNull(number34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 6 + "'", int35 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
//        org.junit.Assert.assertNotNull(list46);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
//        org.junit.Assert.assertNotNull(list55);
//        org.junit.Assert.assertNotNull(collection56);
//        org.junit.Assert.assertNotNull(list57);
//        org.junit.Assert.assertNotNull(date59);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1 + "'", int61 == 1);
//        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "10-June-2019" + "'", str68.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date72);
//        org.junit.Assert.assertNull(number74);
//        org.junit.Assert.assertTrue("'" + str81 + "' != '" + "10-June-2019" + "'", str81.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
//        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
//        org.junit.Assert.assertTrue("'" + str86 + "' != '" + "10-June-2019" + "'", str86.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date87);
//        org.junit.Assert.assertTrue("'" + long88 + "' != '" + 1560236399999L + "'", long88 == 1560236399999L);
//        org.junit.Assert.assertNotNull(timeSeries89);
//        org.junit.Assert.assertNotNull(collection91);
//    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test341() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test341");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setMaximumItemCount((int) (byte) 0);
//        boolean boolean7 = timeSeries4.getNotify();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class11);
//        timeSeries12.setDomainDescription("hi!");
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        java.util.Date date16 = day15.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day15, (java.lang.Number) 0);
//        java.lang.Object obj19 = null;
//        boolean boolean20 = timeSeries12.equals(obj19);
//        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries4.addAndOrUpdate(timeSeries12);
//        timeSeries21.setNotify(true);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        java.util.Date date25 = day24.getEnd();
//        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(date25);
//        java.lang.String str27 = month26.toString();
//        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean29 = month26.equals((java.lang.Object) timeZone28);
//        int int30 = month26.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = month26.previous();
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        java.util.Date date33 = day32.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond(date33);
//        java.util.Date date35 = fixedMillisecond34.getTime();
//        long long36 = fixedMillisecond34.getSerialIndex();
//        long long37 = fixedMillisecond34.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries21.createCopy((org.jfree.data.time.RegularTimePeriod) month26, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
//        java.lang.Object obj39 = new java.lang.Object();
//        boolean boolean40 = fixedMillisecond34.equals(obj39);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNull(timeSeriesDataItem18);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(timeSeries21);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "June 2019" + "'", str27.equals("June 2019"));
//        org.junit.Assert.assertNotNull(timeZone28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560236399999L + "'", long36 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560236399999L + "'", long37 == 1560236399999L);
//        org.junit.Assert.assertNotNull(timeSeries38);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(8);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test344() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test344");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        int int3 = day0.compareTo((java.lang.Object) (-1L));
//        java.lang.Class class7 = null;
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class7);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.lang.String str10 = day9.toString();
//        timeSeries8.delete((org.jfree.data.time.RegularTimePeriod) day9);
//        timeSeries8.fireSeriesChanged();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.util.Date date14 = day13.getEnd();
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
//        java.lang.Number number16 = timeSeries8.getValue((org.jfree.data.time.RegularTimePeriod) month15);
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class20);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.lang.String str23 = day22.toString();
//        timeSeries21.delete((org.jfree.data.time.RegularTimePeriod) day22);
//        boolean boolean25 = timeSeries8.equals((java.lang.Object) day22);
//        boolean boolean26 = day0.equals((java.lang.Object) timeSeries8);
//        timeSeries8.setDomainDescription("ERROR : Relative To String");
//        timeSeries8.setMaximumItemCount(3);
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        java.lang.String str32 = day31.toString();
//        java.util.Date date33 = day31.getStart();
//        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date33);
//        java.lang.Object obj35 = null;
//        int int36 = year34.compareTo(obj35);
//        int int37 = year34.getYear();
//        long long38 = year34.getFirstMillisecond();
//        long long39 = year34.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = year34.next();
//        java.lang.Number number41 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod40, number41);
//        try {
//            timeSeries8.add(timeSeriesDataItem42);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "10-June-2019" + "'", str23.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "10-June-2019" + "'", str32.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 2019 + "'", int37 == 2019);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1546329600000L + "'", long38 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1577865599999L + "'", long39 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod40);
//    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
        timeSeries4.setDomainDescription("hi!");
        java.lang.Object obj7 = timeSeries4.clone();
        java.lang.String str8 = timeSeries4.getDescription();
        timeSeries4.setMaximumItemAge((long) 9999);
        int int11 = timeSeries4.getItemCount();
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(12);
        java.util.Date date6 = spreadsheetDate5.toDate();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        java.util.Date date8 = day7.getEnd();
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(serialDate9);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate15 = serialDate12.getEndOfCurrentMonth(serialDate14);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(serialDate12);
        boolean boolean18 = spreadsheetDate5.isInRange(serialDate9, serialDate12, 0);
        int int19 = year3.compareTo((java.lang.Object) boolean18);
        long long20 = year3.getSerialIndex();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 2019L + "'", long20 == 2019L);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate7 = serialDate4.getEndOfCurrentMonth(serialDate6);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean11 = spreadsheetDate1.isInRange(serialDate6, (org.jfree.data.time.SerialDate) spreadsheetDate10);
        int int12 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean15 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate21 = serialDate18.getEndOfCurrentMonth(serialDate20);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate20);
        boolean boolean23 = spreadsheetDate14.isOnOrAfter(serialDate20);
        int int24 = spreadsheetDate14.getMonth();
        try {
            org.jfree.data.time.SerialDate serialDate26 = spreadsheetDate14.getPreviousDayOfWeek(8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1900 + "'", int12 == 1900);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(9);
        boolean boolean4 = spreadsheetDate1.isOnOrAfter(serialDate3);
        int int5 = spreadsheetDate1.getYYYY();
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1900 + "'", int5 == 1900);
    }

//    @Test
//    public void test349() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test349");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
//        java.util.Date date3 = fixedMillisecond2.getTime();
//        long long4 = fixedMillisecond2.getSerialIndex();
//        long long5 = fixedMillisecond2.getFirstMillisecond();
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond2.getLastMillisecond(calendar6);
//        java.lang.Number number8 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2, number8);
//        java.lang.Number number10 = timeSeriesDataItem9.getValue();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560236399999L + "'", long5 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560236399999L + "'", long7 == 1560236399999L);
//        org.junit.Assert.assertNull(number10);
//    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7, "10-June-2019", "ERROR : Relative To String", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        int int7 = timeSeries4.getItemCount();
        try {
            timeSeries4.removeAgedItems((long) 8, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
        timeSeries4.setDomainDescription("hi!");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        java.util.Date date8 = day7.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) 0);
        java.lang.Object obj11 = null;
        boolean boolean12 = timeSeries4.equals(obj11);
        timeSeries4.setDomainDescription("Overwritten values from: -1.0");
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        java.util.Date date0 = null;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        java.util.Date date2 = day1.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        java.lang.Class class7 = null;
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class7);
        timeSeries8.setMaximumItemCount((int) (byte) 0);
        boolean boolean11 = timeSeries8.getNotify();
        java.util.List list12 = timeSeries8.getItems();
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class16);
        timeSeries17.setMaximumItemCount((int) (byte) 0);
        boolean boolean20 = timeSeries17.getNotify();
        java.util.List list21 = timeSeries17.getItems();
        java.util.Collection collection22 = timeSeries8.getTimePeriodsUniqueToOtherSeries(timeSeries17);
        boolean boolean23 = timeSeries8.isEmpty();
        timeSeries8.setDomainDescription("2019");
        java.lang.Class<?> wildcardClass26 = timeSeries8.getClass();
        java.util.Date date27 = null;
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass26, date27, timeZone28);
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date2, timeZone28);
        try {
            org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date0, timeZone28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNotNull(collection22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertNull(regularTimePeriod29);
    }

//    @Test
//    public void test353() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test353");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day5);
//        timeSeries4.fireSeriesChanged();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.util.Date date10 = day9.getEnd();
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
//        java.lang.Number number12 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month11);
//        java.lang.Class class16 = null;
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class16);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        java.lang.String str19 = day18.toString();
//        timeSeries17.delete((org.jfree.data.time.RegularTimePeriod) day18);
//        boolean boolean21 = timeSeries4.equals((java.lang.Object) day18);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.util.Date date23 = day22.getEnd();
//        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(date23);
//        java.lang.String str25 = month24.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = month24.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month24, (double) (short) 100);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        java.util.Date date30 = day29.getEnd();
//        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month(date30);
//        java.lang.String str32 = month31.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = month31.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month31, (double) (short) 100);
//        int int36 = timeSeriesDataItem28.compareTo((java.lang.Object) month31);
//        timeSeriesDataItem28.setValue((java.lang.Number) 6);
//        java.lang.Object obj39 = new java.lang.Object();
//        int int40 = timeSeriesDataItem28.compareTo(obj39);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = timeSeriesDataItem28.getPeriod();
//        int int42 = day18.compareTo((java.lang.Object) timeSeriesDataItem28);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNull(number12);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "10-June-2019" + "'", str19.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "June 2019" + "'", str25.equals("June 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "June 2019" + "'", str32.equals("June 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
//    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7, "10-June-2019", "ERROR : Relative To String", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries4.addChangeListener(seriesChangeListener7);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        java.lang.String str3 = month2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (double) (short) 100);
        int int7 = month2.getMonth();
        java.lang.String str8 = month2.toString();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "June 2019" + "'", str8.equals("June 2019"));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(9);
        boolean boolean4 = spreadsheetDate1.isOnOrAfter(serialDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate12 = serialDate9.getEndOfCurrentMonth(serialDate11);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean16 = spreadsheetDate6.isInRange(serialDate11, (org.jfree.data.time.SerialDate) spreadsheetDate15);
        int int17 = spreadsheetDate6.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean20 = spreadsheetDate6.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate26 = serialDate23.getEndOfCurrentMonth(serialDate25);
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.addDays(0, serialDate26);
        boolean boolean28 = spreadsheetDate6.isOnOrBefore(serialDate26);
        int int29 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate6);
        int int30 = spreadsheetDate6.getDayOfMonth();
        int int31 = spreadsheetDate6.toSerial();
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.addDays((int) (byte) 1, serialDate34);
        boolean boolean36 = spreadsheetDate6.isAfter(serialDate34);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1900 + "'", int17 == 1900);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2 + "'", int30 == 2);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 3 + "'", int31 == 3);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(8);
        org.junit.Assert.assertNotNull(serialDate1);
    }

//    @Test
//    public void test359() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test359");
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        java.util.Date date2 = day1.getEnd();
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
//        java.lang.String str4 = month3.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month3, (double) (short) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.util.Date date9 = day8.getEnd();
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date9);
//        java.lang.String str11 = month10.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month10.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month10, (double) (short) 100);
//        int int15 = timeSeriesDataItem7.compareTo((java.lang.Object) month10);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        java.lang.String str17 = day16.toString();
//        int int18 = month10.compareTo((java.lang.Object) str17);
//        long long19 = month10.getLastMillisecond();
//        org.jfree.data.time.Year year20 = month10.getYear();
//        long long21 = year20.getFirstMillisecond();
//        long long22 = year20.getFirstMillisecond();
//        try {
//            org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(0, year20);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "June 2019" + "'", str11.equals("June 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "10-June-2019" + "'", str17.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1561964399999L + "'", long19 == 1561964399999L);
//        org.junit.Assert.assertNotNull(year20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1546329600000L + "'", long21 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1546329600000L + "'", long22 == 1546329600000L);
//    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate6 = serialDate3.getEndOfCurrentMonth(serialDate5);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addDays(0, serialDate6);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(3, serialDate7);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
        java.util.Date date3 = fixedMillisecond2.getTime();
        int int5 = fixedMillisecond2.compareTo((java.lang.Object) "June 2019");
        java.util.Date date6 = fixedMillisecond2.getEnd();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(date6);
    }

//    @Test
//    public void test362() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test362");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        int int3 = day0.compareTo((java.lang.Object) (-1L));
//        java.lang.Class class7 = null;
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class7);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.lang.String str10 = day9.toString();
//        timeSeries8.delete((org.jfree.data.time.RegularTimePeriod) day9);
//        timeSeries8.fireSeriesChanged();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.util.Date date14 = day13.getEnd();
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
//        java.lang.Number number16 = timeSeries8.getValue((org.jfree.data.time.RegularTimePeriod) month15);
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class20);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.lang.String str23 = day22.toString();
//        timeSeries21.delete((org.jfree.data.time.RegularTimePeriod) day22);
//        boolean boolean25 = timeSeries8.equals((java.lang.Object) day22);
//        boolean boolean26 = day0.equals((java.lang.Object) timeSeries8);
//        timeSeries8.setDomainDescription("ERROR : Relative To String");
//        java.lang.String str29 = timeSeries8.getRangeDescription();
//        java.lang.String str30 = timeSeries8.getRangeDescription();
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        java.lang.String str32 = day31.toString();
//        long long33 = day31.getFirstMillisecond();
//        java.lang.Number number34 = timeSeries8.getValue((org.jfree.data.time.RegularTimePeriod) day31);
//        long long35 = day31.getLastMillisecond();
//        java.util.Calendar calendar36 = null;
//        try {
//            long long37 = day31.getMiddleMillisecond(calendar36);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "10-June-2019" + "'", str23.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "hi!" + "'", str29.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "hi!" + "'", str30.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "10-June-2019" + "'", str32.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560150000000L + "'", long33 == 1560150000000L);
//        org.junit.Assert.assertNull(number34);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560236399999L + "'", long35 == 1560236399999L);
//    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(4, (-460), 1900);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'month' argument must be in the range 1 to 12.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test364() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test364");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
//        java.util.Date date3 = fixedMillisecond2.getTime();
//        long long4 = fixedMillisecond2.getSerialIndex();
//        long long5 = fixedMillisecond2.getFirstMillisecond();
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond2.getMiddleMillisecond(calendar6);
//        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate13 = serialDate10.getEndOfCurrentMonth(serialDate12);
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate12);
//        boolean boolean15 = fixedMillisecond2.equals((java.lang.Object) serialDate12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond2.next();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        java.util.Date date18 = day17.getEnd();
//        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date18);
//        java.lang.String str20 = month19.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = month19.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month19, (double) (short) 100);
//        timeSeriesDataItem23.setValue((java.lang.Number) (-1L));
//        int int26 = fixedMillisecond2.compareTo((java.lang.Object) timeSeriesDataItem23);
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int26);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560236399999L + "'", long5 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560236399999L + "'", long7 == 1560236399999L);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "June 2019" + "'", str20.equals("June 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
//    }

//    @Test
//    public void test365() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test365");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setDomainDescription("hi!");
//        java.lang.Object obj7 = timeSeries4.clone();
//        java.lang.String str8 = timeSeries4.getDescription();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.lang.String str10 = day9.toString();
//        java.util.Date date11 = day9.getStart();
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
//        long long13 = year12.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year12, (java.lang.Number) 100.0f);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        java.lang.String str17 = day16.toString();
//        java.util.Date date18 = day16.getStart();
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date18);
//        java.lang.Object obj20 = null;
//        int int21 = year19.compareTo(obj20);
//        java.lang.String str22 = year19.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year19.previous();
//        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) year12, (org.jfree.data.time.RegularTimePeriod) year19);
//        int int25 = year12.getYear();
//        long long26 = year12.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(obj7);
//        org.junit.Assert.assertNull(str8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "10-June-2019" + "'", str17.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "2019" + "'", str22.equals("2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(timeSeries24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2019 + "'", int25 == 2019);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1546329600000L + "'", long26 == 1546329600000L);
//    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2, 2147483647, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test367() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test367");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setDomainDescription("hi!");
//        java.lang.Object obj7 = timeSeries4.clone();
//        java.lang.String str8 = timeSeries4.getDescription();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.lang.String str10 = day9.toString();
//        java.util.Date date11 = day9.getStart();
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
//        long long13 = year12.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year12, (java.lang.Number) 100.0f);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        java.lang.String str17 = day16.toString();
//        java.util.Date date18 = day16.getStart();
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date18);
//        java.lang.Object obj20 = null;
//        int int21 = year19.compareTo(obj20);
//        java.lang.String str22 = year19.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year19.previous();
//        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) year12, (org.jfree.data.time.RegularTimePeriod) year19);
//        timeSeries24.setDomainDescription("Sunday");
//        org.junit.Assert.assertNotNull(obj7);
//        org.junit.Assert.assertNull(str8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "10-June-2019" + "'", str17.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "2019" + "'", str22.equals("2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(timeSeries24);
//    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
        timeSeries4.setMaximumItemCount((int) (byte) 0);
        boolean boolean7 = timeSeries4.getNotify();
        java.util.List list8 = timeSeries4.getItems();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class12);
        timeSeries13.setMaximumItemCount((int) (byte) 0);
        boolean boolean16 = timeSeries13.getNotify();
        java.util.List list17 = timeSeries13.getItems();
        java.util.Collection collection18 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        java.lang.String str19 = timeSeries13.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries13.createCopy((int) (short) 1, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(list17);
        org.junit.Assert.assertNotNull(collection18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
        org.junit.Assert.assertNotNull(timeSeries22);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        java.lang.String str3 = month2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (double) (short) 100);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        java.util.Date date8 = day7.getEnd();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date8);
        java.lang.String str10 = month9.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month9, (double) (short) 100);
        int int14 = timeSeriesDataItem6.compareTo((java.lang.Object) month9);
        java.lang.String str15 = month9.toString();
        java.lang.Class class19 = null;
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class19);
        timeSeries20.setMaximumItemCount((int) (byte) 0);
        boolean boolean23 = month9.equals((java.lang.Object) (byte) 0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "June 2019" + "'", str10.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "June 2019" + "'", str15.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        java.lang.String str3 = month2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        long long5 = month2.getMiddleMillisecond();
        java.lang.String str6 = month2.toString();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560668399999L + "'", long5 == 1560668399999L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(9, (int) (byte) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) 100);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
        timeSeries4.setDomainDescription("hi!");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        java.util.Date date8 = day7.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) 0);
        java.lang.Object obj11 = null;
        boolean boolean12 = timeSeries4.equals(obj11);
        timeSeries4.removeAgedItems(false);
        java.lang.Class<?> wildcardClass15 = timeSeries4.getClass();
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

//    @Test
//    public void test373() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test373");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
//        java.lang.String str3 = month2.toString();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean5 = month2.equals((java.lang.Object) timeZone4);
//        int int6 = month2.getYearValue();
//        long long7 = month2.getSerialIndex();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class11);
//        timeSeries12.setMaximumItemCount((int) (byte) 0);
//        boolean boolean15 = timeSeries12.getNotify();
//        java.util.List list16 = timeSeries12.getItems();
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class20);
//        timeSeries21.setMaximumItemCount((int) (byte) 0);
//        boolean boolean24 = timeSeries21.getNotify();
//        java.util.List list25 = timeSeries21.getItems();
//        java.util.Collection collection26 = timeSeries12.getTimePeriodsUniqueToOtherSeries(timeSeries21);
//        java.util.List list27 = timeSeries12.getItems();
//        boolean boolean28 = month2.equals((java.lang.Object) timeSeries12);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        java.lang.String str30 = day29.toString();
//        java.util.Date date31 = day29.getStart();
//        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date31);
//        long long33 = year32.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year32, (java.lang.Number) 100.0f);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = timeSeriesDataItem35.getPeriod();
//        try {
//            timeSeries12.add(timeSeriesDataItem35);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 24234L + "'", long7 == 24234L);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertNotNull(list16);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//        org.junit.Assert.assertNotNull(list25);
//        org.junit.Assert.assertNotNull(collection26);
//        org.junit.Assert.assertNotNull(list27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "10-June-2019" + "'", str30.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1577865599999L + "'", long33 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//    }

//    @Test
//    public void test374() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test374");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        java.util.Date date2 = day0.getStart();
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
//        java.lang.Object obj4 = null;
//        int int5 = year3.compareTo(obj4);
//        int int6 = year3.getYear();
//        java.lang.String str7 = year3.toString();
//        java.util.Calendar calendar8 = null;
//        try {
//            year3.peg(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
//    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        java.util.Date date3 = fixedMillisecond1.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
    }

//    @Test
//    public void test376() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test376");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day5);
//        timeSeries4.fireSeriesChanged();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.util.Date date10 = day9.getEnd();
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
//        java.lang.Number number12 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month11);
//        java.lang.Class class16 = null;
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class16);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        java.lang.String str19 = day18.toString();
//        timeSeries17.delete((org.jfree.data.time.RegularTimePeriod) day18);
//        boolean boolean21 = timeSeries4.equals((java.lang.Object) day18);
//        java.lang.Class class25 = null;
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class25);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        java.lang.String str28 = day27.toString();
//        timeSeries26.delete((org.jfree.data.time.RegularTimePeriod) day27);
//        timeSeries26.fireSeriesChanged();
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        java.util.Date date32 = day31.getEnd();
//        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(date32);
//        java.lang.Number number34 = timeSeries26.getValue((org.jfree.data.time.RegularTimePeriod) month33);
//        int int35 = month33.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = month33.previous();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) month33);
//        try {
//            timeSeries4.removeAgedItems((long) (byte) 100, false);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNull(number12);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "10-June-2019" + "'", str19.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "10-June-2019" + "'", str28.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNull(number34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 6 + "'", int35 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//    }

//    @Test
//    public void test377() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test377");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setMaximumItemCount((int) (byte) 0);
//        boolean boolean7 = timeSeries4.getNotify();
//        java.util.List list8 = timeSeries4.getItems();
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class12);
//        timeSeries13.setMaximumItemCount((int) (byte) 0);
//        boolean boolean16 = timeSeries13.getNotify();
//        java.util.List list17 = timeSeries13.getItems();
//        java.util.Collection collection18 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries13);
//        boolean boolean19 = timeSeries4.isEmpty();
//        timeSeries4.setDomainDescription("2019");
//        java.lang.Class class25 = null;
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class25);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        java.lang.String str28 = day27.toString();
//        timeSeries26.delete((org.jfree.data.time.RegularTimePeriod) day27);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        java.util.Date date31 = day30.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond(date31);
//        java.util.Date date33 = fixedMillisecond32.getTime();
//        long long34 = fixedMillisecond32.getSerialIndex();
//        long long35 = fixedMillisecond32.getFirstMillisecond();
//        java.util.Calendar calendar36 = null;
//        long long37 = fixedMillisecond32.getMiddleMillisecond(calendar36);
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) day27, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond32);
//        long long39 = fixedMillisecond32.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(list8);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNotNull(list17);
//        org.junit.Assert.assertNotNull(collection18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "10-June-2019" + "'", str28.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560236399999L + "'", long34 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560236399999L + "'", long35 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560236399999L + "'", long37 == 1560236399999L);
//        org.junit.Assert.assertNotNull(timeSeries38);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560236399999L + "'", long39 == 1560236399999L);
//    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(9);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-457) + "'", int1 == (-457));
    }

//    @Test
//    public void test379() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test379");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setDomainDescription("hi!");
//        java.lang.Object obj7 = timeSeries4.clone();
//        java.lang.String str8 = timeSeries4.getDescription();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.lang.String str10 = day9.toString();
//        java.util.Date date11 = day9.getStart();
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
//        long long13 = year12.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year12, (java.lang.Number) 100.0f);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        java.lang.String str17 = day16.toString();
//        java.util.Date date18 = day16.getStart();
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date18);
//        java.lang.Object obj20 = null;
//        int int21 = year19.compareTo(obj20);
//        java.lang.String str22 = year19.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year19.previous();
//        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) year12, (org.jfree.data.time.RegularTimePeriod) year19);
//        java.lang.Class class28 = null;
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class28);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        java.lang.String str31 = day30.toString();
//        timeSeries29.delete((org.jfree.data.time.RegularTimePeriod) day30);
//        timeSeries29.fireSeriesChanged();
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        java.util.Date date35 = day34.getEnd();
//        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month(date35);
//        java.lang.Number number37 = timeSeries29.getValue((org.jfree.data.time.RegularTimePeriod) month36);
//        int int38 = month36.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = month36.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries24.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month36, (java.lang.Number) (-460));
//        java.lang.Class class42 = timeSeries24.getTimePeriodClass();
//        org.junit.Assert.assertNotNull(obj7);
//        org.junit.Assert.assertNull(str8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "10-June-2019" + "'", str17.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "2019" + "'", str22.equals("2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(timeSeries24);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "10-June-2019" + "'", str31.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNull(number37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 6 + "'", int38 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertNull(timeSeriesDataItem41);
//        org.junit.Assert.assertNull(class42);
//    }

//    @Test
//    public void test380() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test380");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setMaximumItemCount((int) (byte) 0);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
//        timeSeries4.removeChangeListener(seriesChangeListener7);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.util.Date date10 = day9.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond(date10);
//        java.util.Date date12 = fixedMillisecond11.getTime();
//        long long13 = fixedMillisecond11.getSerialIndex();
//        long long14 = fixedMillisecond11.getFirstMillisecond();
//        java.util.Calendar calendar15 = null;
//        long long16 = fixedMillisecond11.getMiddleMillisecond(calendar15);
//        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate22 = serialDate19.getEndOfCurrentMonth(serialDate21);
//        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate21);
//        boolean boolean24 = fixedMillisecond11.equals((java.lang.Object) serialDate21);
//        long long25 = fixedMillisecond11.getMiddleMillisecond();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(3);
//        java.util.Date date28 = spreadsheetDate27.toDate();
//        int int29 = spreadsheetDate27.getMonth();
//        boolean boolean30 = fixedMillisecond11.equals((java.lang.Object) spreadsheetDate27);
//        try {
//            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 10L, true);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560236399999L + "'", long13 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560236399999L + "'", long14 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560236399999L + "'", long16 == 1560236399999L);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560236399999L + "'", long25 == 1560236399999L);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(2, serialDate2);
        try {
            org.jfree.data.time.SerialDate serialDate5 = serialDate2.getNearestDayOfWeek((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 1, (int) (short) 1, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate7 = serialDate4.getEndOfCurrentMonth(serialDate6);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean11 = spreadsheetDate1.isInRange(serialDate6, (org.jfree.data.time.SerialDate) spreadsheetDate10);
        int int12 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean15 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate14);
        int int16 = spreadsheetDate14.getMonth();
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate22 = serialDate19.getEndOfCurrentMonth(serialDate21);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate21);
        boolean boolean24 = spreadsheetDate14.isOn(serialDate23);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1900 + "'", int12 == 1900);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.String str5 = timePeriodFormatException3.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

//    @Test
//    public void test385() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test385");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
//        java.util.Date date3 = fixedMillisecond2.getTime();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.util.Date date5 = day4.getEnd();
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date5);
//        java.lang.String str7 = month6.toString();
//        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean9 = month6.equals((java.lang.Object) timeZone8);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date3, timeZone8);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.next();
//        long long12 = day10.getFirstMillisecond();
//        long long13 = day10.getSerialIndex();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "June 2019" + "'", str7.equals("June 2019"));
//        org.junit.Assert.assertNotNull(timeZone8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560150000000L + "'", long12 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43626L + "'", long13 == 43626L);
//    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(12);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-457) + "'", int1 == (-457));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
        timeSeries4.setMaximumItemCount((int) (byte) 0);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timeSeries4.removeChangeListener(seriesChangeListener9);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
        timeSeries4.setMaximumItemCount((int) (byte) 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries4.removeChangeListener(seriesChangeListener7);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        java.util.Date date10 = day9.getEnd();
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(date10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond(date10);
        java.util.Date date13 = fixedMillisecond12.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
        try {
            org.jfree.data.time.TimeSeries timeSeries17 = timeSeries4.createCopy((int) (short) 10, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
    }

//    @Test
//    public void test389() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test389");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        java.util.Date date2 = day0.getStart();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) 10.0f);
//        boolean boolean6 = day0.equals((java.lang.Object) (byte) -1);
//        long long7 = day0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560236399999L + "'", long7 == 1560236399999L);
//    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test391() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test391");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setMaximumItemCount((int) (byte) 0);
//        boolean boolean7 = timeSeries4.getNotify();
//        timeSeries4.setKey((java.lang.Comparable) 10.0d);
//        java.lang.Class<?> wildcardClass10 = timeSeries4.getClass();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        java.lang.String str12 = day11.toString();
//        java.util.Date date13 = day11.getStart();
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date13);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        java.util.Date date16 = day15.getEnd();
//        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date16);
//        java.lang.String str18 = month17.toString();
//        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean20 = month17.equals((java.lang.Object) timeZone19);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date13, timeZone19);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.util.Date date23 = day22.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(date23);
//        java.util.Date date25 = fixedMillisecond24.getTime();
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        java.util.Date date27 = day26.getEnd();
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(date27);
//        java.lang.String str29 = month28.toString();
//        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean31 = month28.equals((java.lang.Object) timeZone30);
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date25, timeZone30);
//        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(date13, timeZone30);
//        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.createInstance(date13);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10-June-2019" + "'", str12.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "June 2019" + "'", str18.equals("June 2019"));
//        org.junit.Assert.assertNotNull(timeZone19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "June 2019" + "'", str29.equals("June 2019"));
//        org.junit.Assert.assertNotNull(timeZone30);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNotNull(serialDate34);
//    }

//    @Test
//    public void test392() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test392");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        java.util.Date date2 = day0.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
//        java.lang.Class class7 = null;
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class7);
//        timeSeries8.setMaximumItemCount((int) (byte) 0);
//        boolean boolean11 = timeSeries8.getNotify();
//        java.util.List list12 = timeSeries8.getItems();
//        java.lang.Class class16 = null;
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class16);
//        timeSeries17.setMaximumItemCount((int) (byte) 0);
//        boolean boolean20 = timeSeries17.getNotify();
//        java.util.List list21 = timeSeries17.getItems();
//        java.util.Collection collection22 = timeSeries8.getTimePeriodsUniqueToOtherSeries(timeSeries17);
//        java.util.List list23 = timeSeries8.getItems();
//        boolean boolean24 = fixedMillisecond3.equals((java.lang.Object) timeSeries8);
//        java.lang.Class class28 = null;
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class28);
//        timeSeries29.setMaximumItemCount((int) (byte) 0);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener32 = null;
//        timeSeries29.removeChangeListener(seriesChangeListener32);
//        boolean boolean34 = fixedMillisecond3.equals((java.lang.Object) seriesChangeListener32);
//        long long35 = fixedMillisecond3.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass36 = fixedMillisecond3.getClass();
//        java.util.Calendar calendar37 = null;
//        long long38 = fixedMillisecond3.getLastMillisecond(calendar37);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertNotNull(list12);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertNotNull(list21);
//        org.junit.Assert.assertNotNull(collection22);
//        org.junit.Assert.assertNotNull(list23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560150000000L + "'", long35 == 1560150000000L);
//        org.junit.Assert.assertNotNull(wildcardClass36);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1560150000000L + "'", long38 == 1560150000000L);
//    }

//    @Test
//    public void test393() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test393");
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        java.lang.String str2 = day1.toString();
//        java.util.Date date3 = day1.getStart();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
//        java.lang.Class class8 = null;
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class8);
//        timeSeries9.setMaximumItemCount((int) (byte) 0);
//        boolean boolean12 = timeSeries9.getNotify();
//        java.util.List list13 = timeSeries9.getItems();
//        java.lang.Class class17 = null;
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class17);
//        timeSeries18.setMaximumItemCount((int) (byte) 0);
//        boolean boolean21 = timeSeries18.getNotify();
//        java.util.List list22 = timeSeries18.getItems();
//        java.util.Collection collection23 = timeSeries9.getTimePeriodsUniqueToOtherSeries(timeSeries18);
//        boolean boolean24 = timeSeries9.isEmpty();
//        timeSeries9.setDomainDescription("2019");
//        java.lang.Class<?> wildcardClass27 = timeSeries9.getClass();
//        java.util.Date date28 = null;
//        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass27, date28, timeZone29);
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date3, timeZone29);
//        org.jfree.data.time.SerialDate serialDate32 = day31.getSerialDate();
//        try {
//            org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(11, serialDate32);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10-June-2019" + "'", str2.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertNotNull(list13);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//        org.junit.Assert.assertNotNull(list22);
//        org.junit.Assert.assertNotNull(collection23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//        org.junit.Assert.assertNotNull(wildcardClass27);
//        org.junit.Assert.assertNotNull(timeZone29);
//        org.junit.Assert.assertNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(serialDate32);
//    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(100);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(9, (int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(date1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(serialDate2);
        java.util.Calendar calendar4 = null;
        try {
            day3.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(serialDate2);
    }

//    @Test
//    public void test397() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test397");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond0.getLastMillisecond(calendar2);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560192224226L + "'", long1 == 1560192224226L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560192224226L + "'", long3 == 1560192224226L);
//    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate5 = serialDate2.getEndOfCurrentMonth(serialDate4);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addDays(100, serialDate4);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
    }

//    @Test
//    public void test399() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test399");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
//        java.util.Date date3 = fixedMillisecond2.getTime();
//        long long4 = fixedMillisecond2.getSerialIndex();
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond2.getMiddleMillisecond(calendar5);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560236399999L + "'", long6 == 1560236399999L);
//    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7, "10-June-2019", "ERROR : Relative To String", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        java.util.Date date8 = day7.getEnd();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date8);
        java.lang.String str10 = month9.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month9, (double) (short) 100);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        java.util.Date date15 = day14.getEnd();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date15);
        java.lang.String str17 = month16.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month16.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month16, (double) (short) 100);
        int int21 = timeSeriesDataItem13.compareTo((java.lang.Object) month16);
        timeSeriesDataItem13.setValue((java.lang.Number) 6);
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate29 = serialDate26.getEndOfCurrentMonth(serialDate28);
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate28);
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(serialDate30);
        boolean boolean32 = timeSeriesDataItem13.equals((java.lang.Object) serialDate30);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = timeSeriesDataItem13.getPeriod();
        timeSeries4.delete(regularTimePeriod33);
        timeSeries4.setMaximumItemCount(12);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "June 2019" + "'", str10.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "June 2019" + "'", str17.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
    }

//    @Test
//    public void test401() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test401");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day5);
//        timeSeries4.fireSeriesChanged();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.util.Date date10 = day9.getEnd();
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
//        java.lang.Number number12 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month11);
//        long long13 = month11.getSerialIndex();
//        long long14 = month11.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNull(number12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 24234L + "'", long13 == 24234L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 24234L + "'", long14 == 24234L);
//    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate7 = serialDate4.getEndOfCurrentMonth(serialDate6);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean11 = spreadsheetDate1.isInRange(serialDate6, (org.jfree.data.time.SerialDate) spreadsheetDate10);
        int int12 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean15 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate14);
        int int16 = spreadsheetDate1.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate23 = serialDate20.getEndOfCurrentMonth(serialDate22);
        boolean boolean24 = spreadsheetDate18.isAfter(serialDate23);
        boolean boolean25 = spreadsheetDate1.isBefore(serialDate23);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate33 = serialDate30.getEndOfCurrentMonth(serialDate32);
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate32);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean37 = spreadsheetDate27.isInRange(serialDate32, (org.jfree.data.time.SerialDate) spreadsheetDate36);
        int int38 = spreadsheetDate27.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean41 = spreadsheetDate27.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate40);
        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate47 = serialDate44.getEndOfCurrentMonth(serialDate46);
        org.jfree.data.time.SerialDate serialDate48 = org.jfree.data.time.SerialDate.addDays(0, serialDate47);
        boolean boolean49 = spreadsheetDate27.isOnOrBefore(serialDate47);
        int int50 = spreadsheetDate27.getYYYY();
        int int51 = spreadsheetDate27.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate53 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate55 = org.jfree.data.time.SerialDate.createInstance(9);
        boolean boolean56 = spreadsheetDate53.isOnOrAfter(serialDate55);
        boolean boolean57 = spreadsheetDate27.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate53);
        boolean boolean58 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate27);
        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1900 + "'", int12 == 1900);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1900 + "'", int38 == 1900);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1900 + "'", int50 == 1900);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 2 + "'", int51 == 2);
        org.junit.Assert.assertNotNull(serialDate55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(1, (int) (byte) 100, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test404() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test404");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setDomainDescription("hi!");
//        java.lang.Object obj7 = timeSeries4.clone();
//        java.lang.String str8 = timeSeries4.getDescription();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.lang.String str10 = day9.toString();
//        java.util.Date date11 = day9.getStart();
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
//        long long13 = year12.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year12, (java.lang.Number) 100.0f);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        java.lang.String str17 = day16.toString();
//        java.util.Date date18 = day16.getStart();
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date18);
//        java.lang.Object obj20 = null;
//        int int21 = year19.compareTo(obj20);
//        java.lang.String str22 = year19.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year19.previous();
//        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) year12, (org.jfree.data.time.RegularTimePeriod) year19);
//        boolean boolean25 = timeSeries4.getNotify();
//        try {
//            timeSeries4.delete((int) (short) -1, (-1));
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(obj7);
//        org.junit.Assert.assertNull(str8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "10-June-2019" + "'", str17.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "2019" + "'", str22.equals("2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(timeSeries24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate7 = serialDate4.getEndOfCurrentMonth(serialDate6);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean11 = spreadsheetDate1.isInRange(serialDate6, (org.jfree.data.time.SerialDate) spreadsheetDate10);
        int int12 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean15 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate14);
        int int16 = spreadsheetDate1.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate23 = serialDate20.getEndOfCurrentMonth(serialDate22);
        boolean boolean24 = spreadsheetDate18.isAfter(serialDate23);
        boolean boolean25 = spreadsheetDate1.isBefore(serialDate23);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate33 = serialDate30.getEndOfCurrentMonth(serialDate32);
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate32);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean37 = spreadsheetDate27.isInRange(serialDate32, (org.jfree.data.time.SerialDate) spreadsheetDate36);
        int int38 = spreadsheetDate27.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean41 = spreadsheetDate27.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate40);
        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate47 = serialDate44.getEndOfCurrentMonth(serialDate46);
        org.jfree.data.time.SerialDate serialDate48 = org.jfree.data.time.SerialDate.addDays(0, serialDate47);
        boolean boolean49 = spreadsheetDate27.isOnOrBefore(serialDate47);
        int int50 = spreadsheetDate27.getYYYY();
        int int51 = spreadsheetDate27.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate53 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate55 = org.jfree.data.time.SerialDate.createInstance(9);
        boolean boolean56 = spreadsheetDate53.isOnOrAfter(serialDate55);
        boolean boolean57 = spreadsheetDate27.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate53);
        boolean boolean58 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate27);
        int int59 = spreadsheetDate1.getDayOfWeek();
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1900 + "'", int12 == 1900);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1900 + "'", int38 == 1900);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1900 + "'", int50 == 1900);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 2 + "'", int51 == 2);
        org.junit.Assert.assertNotNull(serialDate55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 3 + "'", int59 == 3);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate6 = serialDate3.getEndOfCurrentMonth(serialDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(12);
        java.util.Date date9 = spreadsheetDate8.toDate();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        java.util.Date date11 = day10.getEnd();
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance(date11);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(serialDate12);
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate18 = serialDate15.getEndOfCurrentMonth(serialDate17);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(serialDate15);
        boolean boolean21 = spreadsheetDate8.isInRange(serialDate12, serialDate15, 0);
        boolean boolean22 = spreadsheetDate1.isInRange(serialDate5, serialDate12);
        int int23 = spreadsheetDate1.getDayOfWeek();
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 5 + "'", int23 == 5);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
        timeSeries4.setDomainDescription("hi!");
        java.lang.Object obj7 = timeSeries4.clone();
        java.lang.String str8 = timeSeries4.getDescription();
        timeSeries4.clear();
        java.util.Collection collection10 = timeSeries4.getTimePeriods();
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(collection10);
    }

//    @Test
//    public void test408() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test408");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setDomainDescription("hi!");
//        java.lang.Object obj7 = timeSeries4.clone();
//        java.lang.String str8 = timeSeries4.getDescription();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.lang.String str10 = day9.toString();
//        java.util.Date date11 = day9.getStart();
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
//        long long13 = year12.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year12, (java.lang.Number) 100.0f);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        java.lang.String str17 = day16.toString();
//        java.util.Date date18 = day16.getStart();
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date18);
//        java.lang.Object obj20 = null;
//        int int21 = year19.compareTo(obj20);
//        java.lang.String str22 = year19.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year19.previous();
//        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) year12, (org.jfree.data.time.RegularTimePeriod) year19);
//        int int25 = year12.getYear();
//        java.util.Calendar calendar26 = null;
//        try {
//            year12.peg(calendar26);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(obj7);
//        org.junit.Assert.assertNull(str8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "10-June-2019" + "'", str17.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "2019" + "'", str22.equals("2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(timeSeries24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2019 + "'", int25 == 2019);
//    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(5);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

//    @Test
//    public void test410() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test410");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setMaximumItemCount((int) (byte) 0);
//        boolean boolean7 = timeSeries4.getNotify();
//        java.util.List list8 = timeSeries4.getItems();
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class12);
//        timeSeries13.setMaximumItemCount((int) (byte) 0);
//        boolean boolean16 = timeSeries13.getNotify();
//        java.util.List list17 = timeSeries13.getItems();
//        java.util.Collection collection18 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries13);
//        java.util.List list19 = timeSeries4.getItems();
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        java.util.Date date21 = day20.getEnd();
//        int int23 = day20.compareTo((java.lang.Object) (-1L));
//        java.lang.Class class27 = null;
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class27);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        java.lang.String str30 = day29.toString();
//        timeSeries28.delete((org.jfree.data.time.RegularTimePeriod) day29);
//        timeSeries28.fireSeriesChanged();
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        java.util.Date date34 = day33.getEnd();
//        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(date34);
//        java.lang.Number number36 = timeSeries28.getValue((org.jfree.data.time.RegularTimePeriod) month35);
//        java.lang.Class class40 = null;
//        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class40);
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
//        java.lang.String str43 = day42.toString();
//        timeSeries41.delete((org.jfree.data.time.RegularTimePeriod) day42);
//        boolean boolean45 = timeSeries28.equals((java.lang.Object) day42);
//        boolean boolean46 = day20.equals((java.lang.Object) timeSeries28);
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
//        java.lang.String str48 = day47.toString();
//        java.util.Date date49 = day47.getStart();
//        long long50 = day47.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) day20, (org.jfree.data.time.RegularTimePeriod) day47);
//        timeSeries4.setKey((java.lang.Comparable) 0L);
//        int int54 = timeSeries4.getItemCount();
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(list8);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNotNull(list17);
//        org.junit.Assert.assertNotNull(collection18);
//        org.junit.Assert.assertNotNull(list19);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "10-June-2019" + "'", str30.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNull(number36);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "10-June-2019" + "'", str43.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "10-June-2019" + "'", str48.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1560236399999L + "'", long50 == 1560236399999L);
//        org.junit.Assert.assertNotNull(timeSeries51);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
//    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("org.jfree.data.general.SeriesChangeEvent[source=10]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1560236399999L);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("8-January-1900");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate8 = serialDate5.getEndOfCurrentMonth(serialDate7);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean12 = spreadsheetDate2.isInRange(serialDate7, (org.jfree.data.time.SerialDate) spreadsheetDate11);
        int int13 = spreadsheetDate2.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean16 = spreadsheetDate2.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate22 = serialDate19.getEndOfCurrentMonth(serialDate21);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate21);
        boolean boolean24 = spreadsheetDate15.isOnOrAfter(serialDate21);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.addYears(0, (org.jfree.data.time.SerialDate) spreadsheetDate15);
        int int26 = spreadsheetDate15.getDayOfMonth();
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1900 + "'", int13 == 1900);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2 + "'", int26 == 2);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        java.lang.String str3 = month2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (double) (short) 100);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        java.util.Date date8 = day7.getEnd();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date8);
        java.lang.String str10 = month9.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month9, (double) (short) 100);
        int int14 = timeSeriesDataItem6.compareTo((java.lang.Object) month9);
        timeSeriesDataItem6.setValue((java.lang.Number) 6);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate22 = serialDate19.getEndOfCurrentMonth(serialDate21);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate21);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(serialDate23);
        boolean boolean25 = timeSeriesDataItem6.equals((java.lang.Object) serialDate23);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent26 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeriesDataItem6);
        java.lang.Object obj27 = seriesChangeEvent26.getSource();
        java.lang.String str28 = seriesChangeEvent26.toString();
        java.lang.String str29 = seriesChangeEvent26.toString();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "June 2019" + "'", str10.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(obj27);
    }

//    @Test
//    public void test417() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test417");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day5);
//        timeSeries4.fireSeriesChanged();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.util.Date date10 = day9.getEnd();
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
//        java.lang.Number number12 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month11);
//        int int13 = month11.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month11.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month11.next();
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNull(number12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//    }

//    @Test
//    public void test418() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test418");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        java.util.Date date2 = day0.getStart();
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
//        java.lang.Object obj4 = null;
//        int int5 = year3.compareTo(obj4);
//        int int6 = year3.getYear();
//        long long7 = year3.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year3.previous();
//        java.util.Calendar calendar9 = null;
//        try {
//            long long10 = year3.getLastMillisecond(calendar9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//    }

//    @Test
//    public void test419() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test419");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        int int3 = day0.compareTo((java.lang.Object) (-1L));
//        java.lang.Class class7 = null;
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class7);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.lang.String str10 = day9.toString();
//        timeSeries8.delete((org.jfree.data.time.RegularTimePeriod) day9);
//        timeSeries8.fireSeriesChanged();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.util.Date date14 = day13.getEnd();
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
//        java.lang.Number number16 = timeSeries8.getValue((org.jfree.data.time.RegularTimePeriod) month15);
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class20);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.lang.String str23 = day22.toString();
//        timeSeries21.delete((org.jfree.data.time.RegularTimePeriod) day22);
//        boolean boolean25 = timeSeries8.equals((java.lang.Object) day22);
//        boolean boolean26 = day0.equals((java.lang.Object) timeSeries8);
//        timeSeries8.setDomainDescription("ERROR : Relative To String");
//        timeSeries8.removeAgedItems(false);
//        java.lang.Comparable comparable31 = timeSeries8.getKey();
//        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month();
//        java.lang.String str33 = month32.toString();
//        timeSeries8.setKey((java.lang.Comparable) str33);
//        try {
//            timeSeries8.update((int) (short) 1, (java.lang.Number) (byte) 100);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "10-June-2019" + "'", str23.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + comparable31 + "' != '" + (-1.0f) + "'", comparable31.equals((-1.0f)));
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "June 2019" + "'", str33.equals("June 2019"));
//    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate4 = serialDate1.getEndOfCurrentMonth(serialDate3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate1);
        long long6 = day5.getFirstMillisecond();
        java.util.Calendar calendar7 = null;
        try {
            day5.peg(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-2208355200000L) + "'", long6 == (-2208355200000L));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
        timeSeries4.setMaximumItemCount((int) (byte) 0);
        timeSeries4.removeAgedItems(false);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        java.util.Date date2 = spreadsheetDate1.toDate();
        int int3 = spreadsheetDate1.getMonth();
        int int4 = spreadsheetDate1.toSerial();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
    }

//    @Test
//    public void test423() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test423");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day5);
//        timeSeries4.fireSeriesChanged();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.util.Date date10 = day9.getEnd();
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
//        java.lang.Number number12 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month11);
//        java.lang.Class class16 = null;
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class16);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        java.lang.String str19 = day18.toString();
//        timeSeries17.delete((org.jfree.data.time.RegularTimePeriod) day18);
//        boolean boolean21 = timeSeries4.equals((java.lang.Object) day18);
//        java.lang.Class class25 = null;
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class25);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        java.lang.String str28 = day27.toString();
//        timeSeries26.delete((org.jfree.data.time.RegularTimePeriod) day27);
//        timeSeries26.fireSeriesChanged();
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        java.util.Date date32 = day31.getEnd();
//        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(date32);
//        java.lang.Number number34 = timeSeries26.getValue((org.jfree.data.time.RegularTimePeriod) month33);
//        int int35 = month33.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = month33.previous();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) month33);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = month33.previous();
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNull(number12);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "10-June-2019" + "'", str19.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "10-June-2019" + "'", str28.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNull(number34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 6 + "'", int35 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate7 = serialDate4.getEndOfCurrentMonth(serialDate6);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean11 = spreadsheetDate1.isInRange(serialDate6, (org.jfree.data.time.SerialDate) spreadsheetDate10);
        int int12 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean15 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate21 = serialDate18.getEndOfCurrentMonth(serialDate20);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addDays(0, serialDate21);
        boolean boolean23 = spreadsheetDate1.isOnOrBefore(serialDate21);
        int int24 = spreadsheetDate1.getYYYY();
        int int25 = spreadsheetDate1.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.createInstance(9);
        boolean boolean30 = spreadsheetDate27.isOnOrAfter(serialDate29);
        boolean boolean31 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate27);
        int int32 = spreadsheetDate1.getYYYY();
        int int33 = spreadsheetDate1.getDayOfMonth();
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1900 + "'", int12 == 1900);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1900 + "'", int24 == 1900);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2 + "'", int25 == 2);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1900 + "'", int32 == 1900);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2 + "'", int33 == 2);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        java.lang.String str3 = month2.toString();
        int int4 = month2.getMonth();
        java.lang.Object obj5 = null;
        boolean boolean6 = month2.equals(obj5);
        long long7 = month2.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1559372400000L + "'", long7 == 1559372400000L);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

//    @Test
//    public void test427() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test427");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setMaximumItemCount((int) (byte) 0);
//        boolean boolean7 = timeSeries4.getNotify();
//        java.util.List list8 = timeSeries4.getItems();
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class12);
//        timeSeries13.setMaximumItemCount((int) (byte) 0);
//        boolean boolean16 = timeSeries13.getNotify();
//        java.util.List list17 = timeSeries13.getItems();
//        java.util.Collection collection18 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries13);
//        java.beans.PropertyChangeListener propertyChangeListener19 = null;
//        timeSeries13.removePropertyChangeListener(propertyChangeListener19);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        java.util.Date date22 = day21.getEnd();
//        int int24 = day21.compareTo((java.lang.Object) (-1L));
//        java.lang.Class class28 = null;
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class28);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        java.lang.String str31 = day30.toString();
//        timeSeries29.delete((org.jfree.data.time.RegularTimePeriod) day30);
//        timeSeries29.fireSeriesChanged();
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        java.util.Date date35 = day34.getEnd();
//        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month(date35);
//        java.lang.Number number37 = timeSeries29.getValue((org.jfree.data.time.RegularTimePeriod) month36);
//        java.lang.Class class41 = null;
//        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class41);
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
//        java.lang.String str44 = day43.toString();
//        timeSeries42.delete((org.jfree.data.time.RegularTimePeriod) day43);
//        boolean boolean46 = timeSeries29.equals((java.lang.Object) day43);
//        boolean boolean47 = day21.equals((java.lang.Object) timeSeries29);
//        timeSeries29.setDomainDescription("ERROR : Relative To String");
//        java.lang.String str50 = timeSeries29.getRangeDescription();
//        java.lang.String str51 = timeSeries29.getRangeDescription();
//        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day();
//        java.lang.String str53 = day52.toString();
//        long long54 = day52.getFirstMillisecond();
//        java.lang.Number number55 = timeSeries29.getValue((org.jfree.data.time.RegularTimePeriod) day52);
//        java.lang.Number number56 = timeSeries13.getValue((org.jfree.data.time.RegularTimePeriod) day52);
//        java.util.Calendar calendar57 = null;
//        try {
//            long long58 = day52.getLastMillisecond(calendar57);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(list8);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNotNull(list17);
//        org.junit.Assert.assertNotNull(collection18);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "10-June-2019" + "'", str31.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNull(number37);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "10-June-2019" + "'", str44.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "hi!" + "'", str50.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "hi!" + "'", str51.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "10-June-2019" + "'", str53.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1560150000000L + "'", long54 == 1560150000000L);
//        org.junit.Assert.assertNull(number55);
//        org.junit.Assert.assertNull(number56);
//    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
        timeSeries4.setMaximumItemCount((int) (byte) 0);
        boolean boolean7 = timeSeries4.getNotify();
        java.util.List list8 = timeSeries4.getItems();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class12);
        timeSeries13.setMaximumItemCount((int) (byte) 0);
        boolean boolean16 = timeSeries13.getNotify();
        java.util.List list17 = timeSeries13.getItems();
        java.util.Collection collection18 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        boolean boolean19 = timeSeries4.isEmpty();
        long long20 = timeSeries4.getMaximumItemAge();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(list17);
        org.junit.Assert.assertNotNull(collection18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 9223372036854775807L + "'", long20 == 9223372036854775807L);
    }

//    @Test
//    public void test430() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test430");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        java.util.Date date4 = day3.getEnd();
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date4);
//        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(date4);
//        boolean boolean8 = day0.equals((java.lang.Object) serialDate7);
//        int int9 = day0.getMonth();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
//    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
        timeSeries4.setMaximumItemCount((int) (byte) 0);
        boolean boolean7 = timeSeries4.getNotify();
        java.lang.Comparable comparable8 = timeSeries4.getKey();
        timeSeries4.setNotify(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries4.addChangeListener(seriesChangeListener11);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0f) + "'", comparable8.equals((-1.0f)));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate8 = serialDate5.getEndOfCurrentMonth(serialDate7);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean12 = spreadsheetDate2.isInRange(serialDate7, (org.jfree.data.time.SerialDate) spreadsheetDate11);
        int int13 = spreadsheetDate2.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean16 = spreadsheetDate2.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate22 = serialDate19.getEndOfCurrentMonth(serialDate21);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate21);
        boolean boolean24 = spreadsheetDate15.isOnOrAfter(serialDate21);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.addYears(0, (org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1900 + "'", int13 == 1900);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(serialDate25);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
        timeSeries4.setDomainDescription("hi!");
        java.lang.Object obj7 = timeSeries4.clone();
        timeSeries4.setRangeDescription("10-June-2019");
        java.lang.Class class10 = timeSeries4.getTimePeriodClass();
        int int11 = timeSeries4.getItemCount();
        long long12 = timeSeries4.getMaximumItemAge();
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNull(class10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 9223372036854775807L + "'", long12 == 9223372036854775807L);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

//    @Test
//    public void test435() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test435");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        java.util.Date date2 = day0.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
//        java.lang.Class class7 = null;
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class7);
//        timeSeries8.setMaximumItemCount((int) (byte) 0);
//        boolean boolean11 = timeSeries8.getNotify();
//        java.util.List list12 = timeSeries8.getItems();
//        java.lang.Class class16 = null;
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class16);
//        timeSeries17.setMaximumItemCount((int) (byte) 0);
//        boolean boolean20 = timeSeries17.getNotify();
//        java.util.List list21 = timeSeries17.getItems();
//        java.util.Collection collection22 = timeSeries8.getTimePeriodsUniqueToOtherSeries(timeSeries17);
//        java.util.List list23 = timeSeries8.getItems();
//        boolean boolean24 = fixedMillisecond3.equals((java.lang.Object) timeSeries8);
//        java.lang.Class class28 = null;
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class28);
//        timeSeries29.setMaximumItemCount((int) (byte) 0);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener32 = null;
//        timeSeries29.removeChangeListener(seriesChangeListener32);
//        boolean boolean34 = fixedMillisecond3.equals((java.lang.Object) seriesChangeListener32);
//        long long35 = fixedMillisecond3.getMiddleMillisecond();
//        long long36 = fixedMillisecond3.getMiddleMillisecond();
//        java.lang.Class class40 = null;
//        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class40);
//        timeSeries41.setMaximumItemCount((int) (byte) 0);
//        boolean boolean44 = timeSeries41.getNotify();
//        java.util.List list45 = timeSeries41.getItems();
//        java.lang.Class class49 = null;
//        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class49);
//        timeSeries50.setMaximumItemCount((int) (byte) 0);
//        boolean boolean53 = timeSeries50.getNotify();
//        java.util.List list54 = timeSeries50.getItems();
//        java.util.Collection collection55 = timeSeries41.getTimePeriodsUniqueToOtherSeries(timeSeries50);
//        boolean boolean56 = timeSeries41.isEmpty();
//        timeSeries41.setDomainDescription("2019");
//        java.lang.Class class62 = null;
//        org.jfree.data.time.TimeSeries timeSeries63 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class62);
//        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day();
//        java.lang.String str65 = day64.toString();
//        timeSeries63.delete((org.jfree.data.time.RegularTimePeriod) day64);
//        org.jfree.data.time.Day day67 = new org.jfree.data.time.Day();
//        java.util.Date date68 = day67.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond69 = new org.jfree.data.time.FixedMillisecond(date68);
//        java.util.Date date70 = fixedMillisecond69.getTime();
//        long long71 = fixedMillisecond69.getSerialIndex();
//        long long72 = fixedMillisecond69.getFirstMillisecond();
//        java.util.Calendar calendar73 = null;
//        long long74 = fixedMillisecond69.getMiddleMillisecond(calendar73);
//        org.jfree.data.time.TimeSeries timeSeries75 = timeSeries41.createCopy((org.jfree.data.time.RegularTimePeriod) day64, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond69);
//        java.util.Collection collection76 = timeSeries41.getTimePeriods();
//        int int77 = timeSeries41.getMaximumItemCount();
//        int int78 = fixedMillisecond3.compareTo((java.lang.Object) int77);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertNotNull(list12);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertNotNull(list21);
//        org.junit.Assert.assertNotNull(collection22);
//        org.junit.Assert.assertNotNull(list23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560150000000L + "'", long35 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560150000000L + "'", long36 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
//        org.junit.Assert.assertNotNull(list45);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
//        org.junit.Assert.assertNotNull(list54);
//        org.junit.Assert.assertNotNull(collection55);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
//        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "10-June-2019" + "'", str65.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date68);
//        org.junit.Assert.assertNotNull(date70);
//        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 1560236399999L + "'", long71 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 1560236399999L + "'", long72 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 1560236399999L + "'", long74 == 1560236399999L);
//        org.junit.Assert.assertNotNull(timeSeries75);
//        org.junit.Assert.assertNotNull(collection76);
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
//        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 1 + "'", int78 == 1);
//    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
        timeSeries4.setDomainDescription("hi!");
        java.lang.Object obj7 = timeSeries4.clone();
        java.lang.String str8 = timeSeries4.getDescription();
        timeSeries4.setMaximumItemAge((long) 9999);
        try {
            timeSeries4.removeAgedItems(2019L, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNull(str8);
    }

//    @Test
//    public void test437() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test437");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
//        java.lang.String str3 = month2.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (double) (short) 100);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        java.util.Date date8 = day7.getEnd();
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date8);
//        java.lang.String str10 = month9.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month9, (double) (short) 100);
//        int int14 = timeSeriesDataItem6.compareTo((java.lang.Object) month9);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        java.lang.String str16 = day15.toString();
//        int int17 = month9.compareTo((java.lang.Object) str16);
//        long long18 = month9.getLastMillisecond();
//        org.jfree.data.time.Year year19 = month9.getYear();
//        long long20 = month9.getSerialIndex();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "June 2019" + "'", str10.equals("June 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "10-June-2019" + "'", str16.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1561964399999L + "'", long18 == 1561964399999L);
//        org.junit.Assert.assertNotNull(year19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 24234L + "'", long20 == 24234L);
//    }

//    @Test
//    public void test438() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test438");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setMaximumItemCount((int) (byte) 0);
//        boolean boolean7 = timeSeries4.getNotify();
//        timeSeries4.setKey((java.lang.Comparable) 10.0d);
//        java.lang.Class<?> wildcardClass10 = timeSeries4.getClass();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        java.lang.String str12 = day11.toString();
//        java.util.Date date13 = day11.getStart();
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date13);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        java.util.Date date16 = day15.getEnd();
//        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date16);
//        java.lang.String str18 = month17.toString();
//        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean20 = month17.equals((java.lang.Object) timeZone19);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date13, timeZone19);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.util.Date date23 = day22.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(date23);
//        java.util.Date date25 = fixedMillisecond24.getTime();
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        java.util.Date date27 = day26.getEnd();
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(date27);
//        java.lang.String str29 = month28.toString();
//        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean31 = month28.equals((java.lang.Object) timeZone30);
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date25, timeZone30);
//        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(date13, timeZone30);
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        java.util.Date date35 = day34.getEnd();
//        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month(date35);
//        java.lang.Class class40 = null;
//        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class40);
//        timeSeries41.setMaximumItemCount((int) (byte) 0);
//        boolean boolean44 = timeSeries41.getNotify();
//        timeSeries41.setKey((java.lang.Comparable) 10.0d);
//        java.lang.Class<?> wildcardClass47 = timeSeries41.getClass();
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
//        java.lang.String str49 = day48.toString();
//        java.util.Date date50 = day48.getStart();
//        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year(date50);
//        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day();
//        java.util.Date date53 = day52.getEnd();
//        org.jfree.data.time.Month month54 = new org.jfree.data.time.Month(date53);
//        java.lang.String str55 = month54.toString();
//        java.util.TimeZone timeZone56 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean57 = month54.equals((java.lang.Object) timeZone56);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass47, date50, timeZone56);
//        org.jfree.data.time.Month month59 = new org.jfree.data.time.Month(date35, timeZone56);
//        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day(date13, timeZone56);
//        int int61 = day60.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10-June-2019" + "'", str12.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "June 2019" + "'", str18.equals("June 2019"));
//        org.junit.Assert.assertNotNull(timeZone19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "June 2019" + "'", str29.equals("June 2019"));
//        org.junit.Assert.assertNotNull(timeZone30);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
//        org.junit.Assert.assertNotNull(wildcardClass47);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "10-June-2019" + "'", str49.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "June 2019" + "'", str55.equals("June 2019"));
//        org.junit.Assert.assertNotNull(timeZone56);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertNull(regularTimePeriod58);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 10 + "'", int61 == 10);
//    }

//    @Test
//    public void test439() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test439");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        java.util.Date date2 = day0.getStart();
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
//        java.lang.Object obj4 = null;
//        int int5 = year3.compareTo(obj4);
//        int int6 = year3.getYear();
//        java.lang.String str7 = year3.toString();
//        long long8 = year3.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
//    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) 0, 1, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test441() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test441");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        int int3 = day0.compareTo((java.lang.Object) (-1L));
//        java.lang.Class class7 = null;
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class7);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.lang.String str10 = day9.toString();
//        timeSeries8.delete((org.jfree.data.time.RegularTimePeriod) day9);
//        timeSeries8.fireSeriesChanged();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.util.Date date14 = day13.getEnd();
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
//        java.lang.Number number16 = timeSeries8.getValue((org.jfree.data.time.RegularTimePeriod) month15);
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class20);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.lang.String str23 = day22.toString();
//        timeSeries21.delete((org.jfree.data.time.RegularTimePeriod) day22);
//        boolean boolean25 = timeSeries8.equals((java.lang.Object) day22);
//        boolean boolean26 = day0.equals((java.lang.Object) timeSeries8);
//        timeSeries8.setDomainDescription("ERROR : Relative To String");
//        timeSeries8.setMaximumItemCount(3);
//        java.lang.Class class31 = timeSeries8.getTimePeriodClass();
//        timeSeries8.setNotify(false);
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        java.lang.String str35 = day34.toString();
//        java.util.Date date36 = day34.getStart();
//        long long37 = day34.getLastMillisecond();
//        int int38 = timeSeries8.getIndex((org.jfree.data.time.RegularTimePeriod) day34);
//        java.lang.String str39 = day34.toString();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "10-June-2019" + "'", str23.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNull(class31);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "10-June-2019" + "'", str35.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560236399999L + "'", long37 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "10-June-2019" + "'", str39.equals("10-June-2019"));
//    }

//    @Test
//    public void test442() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test442");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setDomainDescription("hi!");
//        java.lang.Object obj7 = timeSeries4.clone();
//        java.lang.String str8 = timeSeries4.getDescription();
//        timeSeries4.setMaximumItemAge((long) 9999);
//        java.lang.Class class14 = null;
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class14);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        java.lang.String str17 = day16.toString();
//        timeSeries15.delete((org.jfree.data.time.RegularTimePeriod) day16);
//        timeSeries15.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener20 = null;
//        timeSeries15.addPropertyChangeListener(propertyChangeListener20);
//        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries4.addAndOrUpdate(timeSeries15);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        java.lang.String str24 = day23.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day23.next();
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        java.lang.String str27 = day26.toString();
//        java.util.Date date28 = day26.getStart();
//        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date28);
//        long long30 = year29.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year29, (java.lang.Number) 100.0f);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = timeSeriesDataItem32.getPeriod();
//        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries22.createCopy((org.jfree.data.time.RegularTimePeriod) day23, regularTimePeriod33);
//        int int35 = day23.getMonth();
//        org.junit.Assert.assertNotNull(obj7);
//        org.junit.Assert.assertNull(str8);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "10-June-2019" + "'", str17.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(timeSeries22);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "10-June-2019" + "'", str24.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "10-June-2019" + "'", str27.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1577865599999L + "'", long30 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertNotNull(timeSeries34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 6 + "'", int35 == 6);
//    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = day0.getFirstMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test444() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test444");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day5);
//        timeSeries4.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener9 = null;
//        timeSeries4.addPropertyChangeListener(propertyChangeListener9);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
//        timeSeries4.addChangeListener(seriesChangeListener11);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test446() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test446");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setDomainDescription("hi!");
//        java.lang.Object obj7 = timeSeries4.clone();
//        java.lang.String str8 = timeSeries4.getDescription();
//        timeSeries4.setRangeDescription("June 2019");
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        java.util.Date date12 = day11.getEnd();
//        int int14 = day11.compareTo((java.lang.Object) (-1L));
//        org.jfree.data.time.SerialDate serialDate15 = day11.getSerialDate();
//        long long16 = day11.getLastMillisecond();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        java.lang.String str18 = day17.toString();
//        java.util.Date date19 = day17.getStart();
//        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date19);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year20.previous();
//        java.lang.String str22 = regularTimePeriod21.toString();
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) day11, regularTimePeriod21);
//        timeSeries23.setNotify(true);
//        org.junit.Assert.assertNotNull(obj7);
//        org.junit.Assert.assertNull(str8);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560236399999L + "'", long16 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "10-June-2019" + "'", str18.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "2018" + "'", str22.equals("2018"));
//        org.junit.Assert.assertNotNull(timeSeries23);
//    }

//    @Test
//    public void test447() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test447");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setMaximumItemCount((int) (byte) 0);
//        boolean boolean7 = timeSeries4.getNotify();
//        java.util.List list8 = timeSeries4.getItems();
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class12);
//        timeSeries13.setMaximumItemCount((int) (byte) 0);
//        boolean boolean16 = timeSeries13.getNotify();
//        java.util.List list17 = timeSeries13.getItems();
//        java.util.Collection collection18 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries13);
//        java.util.List list19 = timeSeries4.getItems();
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        java.util.Date date21 = day20.getEnd();
//        int int23 = day20.compareTo((java.lang.Object) (-1L));
//        java.lang.Class class27 = null;
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class27);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        java.lang.String str30 = day29.toString();
//        timeSeries28.delete((org.jfree.data.time.RegularTimePeriod) day29);
//        timeSeries28.fireSeriesChanged();
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        java.util.Date date34 = day33.getEnd();
//        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(date34);
//        java.lang.Number number36 = timeSeries28.getValue((org.jfree.data.time.RegularTimePeriod) month35);
//        java.lang.Class class40 = null;
//        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class40);
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
//        java.lang.String str43 = day42.toString();
//        timeSeries41.delete((org.jfree.data.time.RegularTimePeriod) day42);
//        boolean boolean45 = timeSeries28.equals((java.lang.Object) day42);
//        boolean boolean46 = day20.equals((java.lang.Object) timeSeries28);
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
//        java.lang.String str48 = day47.toString();
//        java.util.Date date49 = day47.getStart();
//        long long50 = day47.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) day20, (org.jfree.data.time.RegularTimePeriod) day47);
//        java.lang.Object obj52 = timeSeries51.clone();
//        java.lang.Class class53 = timeSeries51.getTimePeriodClass();
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(list8);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNotNull(list17);
//        org.junit.Assert.assertNotNull(collection18);
//        org.junit.Assert.assertNotNull(list19);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "10-June-2019" + "'", str30.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNull(number36);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "10-June-2019" + "'", str43.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "10-June-2019" + "'", str48.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1560236399999L + "'", long50 == 1560236399999L);
//        org.junit.Assert.assertNotNull(timeSeries51);
//        org.junit.Assert.assertNotNull(obj52);
//        org.junit.Assert.assertNull(class53);
//    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (3) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(100, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test451() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test451");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setMaximumItemCount((int) (byte) 0);
//        boolean boolean7 = timeSeries4.getNotify();
//        java.util.List list8 = timeSeries4.getItems();
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class12);
//        timeSeries13.setMaximumItemCount((int) (byte) 0);
//        boolean boolean16 = timeSeries13.getNotify();
//        java.util.List list17 = timeSeries13.getItems();
//        java.util.Collection collection18 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries13);
//        java.util.List list19 = timeSeries4.getItems();
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        java.util.Date date21 = day20.getEnd();
//        int int23 = day20.compareTo((java.lang.Object) (-1L));
//        java.lang.Class class27 = null;
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class27);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        java.lang.String str30 = day29.toString();
//        timeSeries28.delete((org.jfree.data.time.RegularTimePeriod) day29);
//        timeSeries28.fireSeriesChanged();
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        java.util.Date date34 = day33.getEnd();
//        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(date34);
//        java.lang.Number number36 = timeSeries28.getValue((org.jfree.data.time.RegularTimePeriod) month35);
//        java.lang.Class class40 = null;
//        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class40);
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
//        java.lang.String str43 = day42.toString();
//        timeSeries41.delete((org.jfree.data.time.RegularTimePeriod) day42);
//        boolean boolean45 = timeSeries28.equals((java.lang.Object) day42);
//        boolean boolean46 = day20.equals((java.lang.Object) timeSeries28);
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
//        java.lang.String str48 = day47.toString();
//        java.util.Date date49 = day47.getStart();
//        long long50 = day47.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) day20, (org.jfree.data.time.RegularTimePeriod) day47);
//        timeSeries51.fireSeriesChanged();
//        java.lang.Class class53 = timeSeries51.getTimePeriodClass();
//        java.util.List list54 = timeSeries51.getItems();
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(list8);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNotNull(list17);
//        org.junit.Assert.assertNotNull(collection18);
//        org.junit.Assert.assertNotNull(list19);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "10-June-2019" + "'", str30.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNull(number36);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "10-June-2019" + "'", str43.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "10-June-2019" + "'", str48.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1560236399999L + "'", long50 == 1560236399999L);
//        org.junit.Assert.assertNotNull(timeSeries51);
//        org.junit.Assert.assertNull(class53);
//        org.junit.Assert.assertNotNull(list54);
//    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        int int2 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate10 = serialDate7.getEndOfCurrentMonth(serialDate9);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean14 = spreadsheetDate4.isInRange(serialDate9, (org.jfree.data.time.SerialDate) spreadsheetDate13);
        int int15 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate4);
        int int16 = spreadsheetDate4.getDayOfMonth();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1900 + "'", int2 == 1900);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(12);
        java.util.Date date3 = spreadsheetDate2.toDate();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getEnd();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date5);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate6);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate12 = serialDate9.getEndOfCurrentMonth(serialDate11);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(serialDate9);
        boolean boolean15 = spreadsheetDate2.isInRange(serialDate6, serialDate9, 0);
        try {
            org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1900, (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        java.lang.String str3 = month2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        long long5 = month2.getSerialIndex();
        java.util.Calendar calendar6 = null;
        try {
            month2.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 24234L + "'", long5 == 24234L);
    }

//    @Test
//    public void test455() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test455");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day5);
//        timeSeries4.fireSeriesChanged();
//        java.lang.Comparable comparable9 = timeSeries4.getKey();
//        java.beans.PropertyChangeListener propertyChangeListener10 = null;
//        timeSeries4.removePropertyChangeListener(propertyChangeListener10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        long long13 = fixedMillisecond12.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (java.lang.Number) 11);
//        timeSeries4.setMaximumItemCount((int) (byte) 1);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + (-1.0f) + "'", comparable9.equals((-1.0f)));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560192233864L + "'", long13 == 1560192233864L);
//        org.junit.Assert.assertNull(timeSeriesDataItem15);
//    }

//    @Test
//    public void test456() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test456");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        java.util.Date date2 = day0.getStart();
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
//        java.lang.Class class7 = null;
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class7);
//        timeSeries8.setMaximumItemCount((int) (byte) 0);
//        boolean boolean11 = timeSeries8.getNotify();
//        java.util.List list12 = timeSeries8.getItems();
//        java.lang.Class class16 = null;
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class16);
//        timeSeries17.setMaximumItemCount((int) (byte) 0);
//        boolean boolean20 = timeSeries17.getNotify();
//        java.util.List list21 = timeSeries17.getItems();
//        java.util.Collection collection22 = timeSeries8.getTimePeriodsUniqueToOtherSeries(timeSeries17);
//        boolean boolean23 = timeSeries8.isEmpty();
//        timeSeries8.setDomainDescription("2019");
//        java.lang.Class<?> wildcardClass26 = timeSeries8.getClass();
//        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass26);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        java.util.Date date29 = day28.getEnd();
//        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month(date29);
//        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date29);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond(date29);
//        java.lang.Class class36 = null;
//        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class36);
//        timeSeries37.setMaximumItemCount((int) (byte) 0);
//        boolean boolean40 = timeSeries37.getNotify();
//        timeSeries37.setKey((java.lang.Comparable) 10.0d);
//        java.lang.Class<?> wildcardClass43 = timeSeries37.getClass();
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day();
//        java.lang.String str45 = day44.toString();
//        java.util.Date date46 = day44.getStart();
//        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year(date46);
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
//        java.util.Date date49 = day48.getEnd();
//        org.jfree.data.time.Month month50 = new org.jfree.data.time.Month(date49);
//        java.lang.String str51 = month50.toString();
//        java.util.TimeZone timeZone52 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean53 = month50.equals((java.lang.Object) timeZone52);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass43, date46, timeZone52);
//        java.lang.Class class55 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass43);
//        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day();
//        java.util.Date date57 = day56.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond58 = new org.jfree.data.time.FixedMillisecond(date57);
//        java.util.Date date59 = fixedMillisecond58.getTime();
//        java.lang.Class class63 = null;
//        org.jfree.data.time.TimeSeries timeSeries64 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class63);
//        timeSeries64.setMaximumItemCount((int) (byte) 0);
//        boolean boolean67 = timeSeries64.getNotify();
//        timeSeries64.setKey((java.lang.Comparable) 10.0d);
//        java.lang.Class<?> wildcardClass70 = timeSeries64.getClass();
//        org.jfree.data.time.Day day71 = new org.jfree.data.time.Day();
//        java.lang.String str72 = day71.toString();
//        java.util.Date date73 = day71.getStart();
//        org.jfree.data.time.Year year74 = new org.jfree.data.time.Year(date73);
//        org.jfree.data.time.Day day75 = new org.jfree.data.time.Day();
//        java.util.Date date76 = day75.getEnd();
//        org.jfree.data.time.Month month77 = new org.jfree.data.time.Month(date76);
//        java.lang.String str78 = month77.toString();
//        java.util.TimeZone timeZone79 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean80 = month77.equals((java.lang.Object) timeZone79);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass70, date73, timeZone79);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod82 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass43, date59, timeZone79);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod83 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass26, date29, timeZone79);
//        org.jfree.data.time.Day day84 = new org.jfree.data.time.Day(date2, timeZone79);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertNotNull(list12);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertNotNull(list21);
//        org.junit.Assert.assertNotNull(collection22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
//        org.junit.Assert.assertNotNull(wildcardClass43);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "10-June-2019" + "'", str45.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "June 2019" + "'", str51.equals("June 2019"));
//        org.junit.Assert.assertNotNull(timeZone52);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertNull(regularTimePeriod54);
//        org.junit.Assert.assertNotNull(class55);
//        org.junit.Assert.assertNotNull(date57);
//        org.junit.Assert.assertNotNull(date59);
//        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
//        org.junit.Assert.assertNotNull(wildcardClass70);
//        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "10-June-2019" + "'", str72.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date73);
//        org.junit.Assert.assertNotNull(date76);
//        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "June 2019" + "'", str78.equals("June 2019"));
//        org.junit.Assert.assertNotNull(timeZone79);
//        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
//        org.junit.Assert.assertNull(regularTimePeriod81);
//        org.junit.Assert.assertNull(regularTimePeriod82);
//        org.junit.Assert.assertNull(regularTimePeriod83);
//    }

//    @Test
//    public void test457() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test457");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(date1);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date1);
//        long long4 = fixedMillisecond3.getLastMillisecond();
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond3.getMiddleMillisecond(calendar5);
//        long long7 = fixedMillisecond3.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560236399999L + "'", long6 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560236399999L + "'", long7 == 1560236399999L);
//    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate7 = serialDate4.getEndOfCurrentMonth(serialDate6);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean11 = spreadsheetDate1.isInRange(serialDate6, (org.jfree.data.time.SerialDate) spreadsheetDate10);
        int int12 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean15 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate21 = serialDate18.getEndOfCurrentMonth(serialDate20);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addDays(0, serialDate21);
        boolean boolean23 = spreadsheetDate1.isOnOrBefore(serialDate21);
        int int24 = spreadsheetDate1.getYYYY();
        int int25 = spreadsheetDate1.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.createInstance(9);
        boolean boolean30 = spreadsheetDate27.isOnOrAfter(serialDate29);
        boolean boolean31 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate27);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate39 = serialDate36.getEndOfCurrentMonth(serialDate38);
        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate38);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean43 = spreadsheetDate33.isInRange(serialDate38, (org.jfree.data.time.SerialDate) spreadsheetDate42);
        int int44 = spreadsheetDate33.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean47 = spreadsheetDate33.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate46);
        org.jfree.data.time.SerialDate serialDate50 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate52 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate53 = serialDate50.getEndOfCurrentMonth(serialDate52);
        org.jfree.data.time.SerialDate serialDate54 = org.jfree.data.time.SerialDate.addDays(0, serialDate53);
        boolean boolean55 = spreadsheetDate33.isOnOrBefore(serialDate53);
        boolean boolean56 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate33);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1900 + "'", int12 == 1900);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1900 + "'", int24 == 1900);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2 + "'", int25 == 2);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertNotNull(serialDate38);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1900 + "'", int44 == 1900);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertNotNull(serialDate52);
        org.junit.Assert.assertNotNull(serialDate53);
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
    }

//    @Test
//    public void test459() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test459");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        java.util.Date date2 = day0.getStart();
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
//        long long4 = year3.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year3, (java.lang.Number) 100.0f);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = timeSeriesDataItem6.getPeriod();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeriesDataItem6.getPeriod();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
        java.util.Date date3 = fixedMillisecond2.getTime();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getEnd();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date5);
        java.lang.String str7 = month6.toString();
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean9 = month6.equals((java.lang.Object) timeZone8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date3, timeZone8);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (java.lang.Number) 10L);
        timeSeriesDataItem14.setValue((java.lang.Number) 100.0d);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "June 2019" + "'", str7.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(4);
        org.junit.Assert.assertNotNull(serialDate1);
    }

//    @Test
//    public void test462() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test462");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
//        int int2 = spreadsheetDate1.toSerial();
//        java.lang.String str3 = spreadsheetDate1.getDescription();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(3);
//        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate11 = serialDate8.getEndOfCurrentMonth(serialDate10);
//        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(3);
//        boolean boolean15 = spreadsheetDate5.isInRange(serialDate10, (org.jfree.data.time.SerialDate) spreadsheetDate14);
//        int int16 = spreadsheetDate5.getYYYY();
//        boolean boolean17 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate5);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        java.util.Date date19 = day18.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond(date19);
//        java.util.Date date21 = fixedMillisecond20.getTime();
//        long long22 = fixedMillisecond20.getSerialIndex();
//        long long23 = fixedMillisecond20.getFirstMillisecond();
//        java.util.Calendar calendar24 = null;
//        long long25 = fixedMillisecond20.getMiddleMillisecond(calendar24);
//        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate31 = serialDate28.getEndOfCurrentMonth(serialDate30);
//        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate30);
//        boolean boolean33 = fixedMillisecond20.equals((java.lang.Object) serialDate30);
//        long long34 = fixedMillisecond20.getMiddleMillisecond();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(3);
//        java.util.Date date37 = spreadsheetDate36.toDate();
//        int int38 = spreadsheetDate36.getMonth();
//        boolean boolean39 = fixedMillisecond20.equals((java.lang.Object) spreadsheetDate36);
//        org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.createInstance(100);
//        boolean boolean42 = spreadsheetDate36.isOnOrBefore(serialDate41);
//        org.jfree.data.time.SerialDate serialDate43 = null;
//        try {
//            boolean boolean44 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate36, serialDate43);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
//        org.junit.Assert.assertNull(str3);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1900 + "'", int16 == 1900);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560236399999L + "'", long22 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560236399999L + "'", long23 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560236399999L + "'", long25 == 1560236399999L);
//        org.junit.Assert.assertNotNull(serialDate28);
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertNotNull(serialDate32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560236399999L + "'", long34 == 1560236399999L);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNotNull(serialDate41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
//    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
        java.util.Date date3 = fixedMillisecond2.getTime();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date3);
        try {
            org.jfree.data.time.SerialDate serialDate6 = serialDate4.getNearestDayOfWeek(2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate4);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        java.lang.String str3 = month2.toString();
        long long4 = month2.getFirstMillisecond();
        int int5 = month2.getMonth();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1559372400000L + "'", long4 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
    }

//    @Test
//    public void test465() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test465");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setDomainDescription("hi!");
//        java.lang.Object obj7 = timeSeries4.clone();
//        java.lang.String str8 = timeSeries4.getDescription();
//        timeSeries4.setMaximumItemAge((long) 9999);
//        java.lang.Class class14 = null;
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class14);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        java.lang.String str17 = day16.toString();
//        timeSeries15.delete((org.jfree.data.time.RegularTimePeriod) day16);
//        timeSeries15.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener20 = null;
//        timeSeries15.addPropertyChangeListener(propertyChangeListener20);
//        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries4.addAndOrUpdate(timeSeries15);
//        timeSeries15.setRangeDescription("January");
//        org.junit.Assert.assertNotNull(obj7);
//        org.junit.Assert.assertNull(str8);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "10-June-2019" + "'", str17.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(timeSeries22);
//    }

//    @Test
//    public void test466() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test466");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        int int3 = day0.compareTo((java.lang.Object) (-1L));
//        java.lang.Class class7 = null;
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class7);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.lang.String str10 = day9.toString();
//        timeSeries8.delete((org.jfree.data.time.RegularTimePeriod) day9);
//        timeSeries8.fireSeriesChanged();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.util.Date date14 = day13.getEnd();
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
//        java.lang.Number number16 = timeSeries8.getValue((org.jfree.data.time.RegularTimePeriod) month15);
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class20);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.lang.String str23 = day22.toString();
//        timeSeries21.delete((org.jfree.data.time.RegularTimePeriod) day22);
//        boolean boolean25 = timeSeries8.equals((java.lang.Object) day22);
//        boolean boolean26 = day0.equals((java.lang.Object) timeSeries8);
//        timeSeries8.setDomainDescription("ERROR : Relative To String");
//        timeSeries8.setMaximumItemCount(3);
//        java.beans.PropertyChangeListener propertyChangeListener31 = null;
//        timeSeries8.removePropertyChangeListener(propertyChangeListener31);
//        timeSeries8.clear();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "10-June-2019" + "'", str23.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//    }

//    @Test
//    public void test467() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test467");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod2, (java.lang.Number) 1560193199999L);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.util.Date date6 = day5.getEnd();
//        int int8 = day5.compareTo((java.lang.Object) (-1L));
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class12);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.lang.String str15 = day14.toString();
//        timeSeries13.delete((org.jfree.data.time.RegularTimePeriod) day14);
//        timeSeries13.fireSeriesChanged();
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        java.util.Date date19 = day18.getEnd();
//        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(date19);
//        java.lang.Number number21 = timeSeries13.getValue((org.jfree.data.time.RegularTimePeriod) month20);
//        java.lang.Class class25 = null;
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class25);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        java.lang.String str28 = day27.toString();
//        timeSeries26.delete((org.jfree.data.time.RegularTimePeriod) day27);
//        boolean boolean30 = timeSeries13.equals((java.lang.Object) day27);
//        boolean boolean31 = day5.equals((java.lang.Object) timeSeries13);
//        timeSeries13.setDomainDescription("ERROR : Relative To String");
//        timeSeries13.removeAgedItems(false);
//        java.lang.Comparable comparable36 = timeSeries13.getKey();
//        timeSeries13.setDescription("");
//        int int39 = timeSeriesDataItem4.compareTo((java.lang.Object) timeSeries13);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10-June-2019" + "'", str15.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNull(number21);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "10-June-2019" + "'", str28.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertTrue("'" + comparable36 + "' != '" + (-1.0f) + "'", comparable36.equals((-1.0f)));
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
//    }

//    @Test
//    public void test468() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test468");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setDomainDescription("hi!");
//        java.lang.Object obj7 = timeSeries4.clone();
//        java.lang.String str8 = timeSeries4.getDescription();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.lang.String str10 = day9.toString();
//        java.util.Date date11 = day9.getStart();
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
//        long long13 = year12.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year12, (java.lang.Number) 100.0f);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        java.lang.String str17 = day16.toString();
//        java.util.Date date18 = day16.getStart();
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date18);
//        java.lang.Object obj20 = null;
//        int int21 = year19.compareTo(obj20);
//        java.lang.String str22 = year19.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year19.previous();
//        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) year12, (org.jfree.data.time.RegularTimePeriod) year19);
//        java.lang.Class class28 = null;
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class28);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        java.lang.String str31 = day30.toString();
//        timeSeries29.delete((org.jfree.data.time.RegularTimePeriod) day30);
//        timeSeries29.fireSeriesChanged();
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        java.util.Date date35 = day34.getEnd();
//        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month(date35);
//        java.lang.Number number37 = timeSeries29.getValue((org.jfree.data.time.RegularTimePeriod) month36);
//        int int38 = month36.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = month36.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries24.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month36, (java.lang.Number) (-460));
//        java.lang.String str42 = timeSeries24.getDomainDescription();
//        try {
//            timeSeries24.removeAgedItems((long) 9999, true);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(obj7);
//        org.junit.Assert.assertNull(str8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "10-June-2019" + "'", str17.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "2019" + "'", str22.equals("2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(timeSeries24);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "10-June-2019" + "'", str31.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNull(number37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 6 + "'", int38 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertNull(timeSeriesDataItem41);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "hi!" + "'", str42.equals("hi!"));
//    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
        timeSeries4.setMaximumItemCount((int) (byte) 0);
        boolean boolean7 = timeSeries4.getNotify();
        java.util.List list8 = timeSeries4.getItems();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeries4);
        java.lang.Object obj10 = seriesChangeEvent9.getSource();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNotNull(obj10);
    }

//    @Test
//    public void test470() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test470");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
//        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate6 = serialDate3.getEndOfCurrentMonth(serialDate5);
//        boolean boolean7 = spreadsheetDate1.isAfter(serialDate6);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.lang.String str9 = day8.toString();
//        long long10 = day8.getLastMillisecond();
//        int int12 = day8.compareTo((java.lang.Object) (byte) 10);
//        org.jfree.data.time.SerialDate serialDate13 = day8.getSerialDate();
//        boolean boolean14 = spreadsheetDate1.isOnOrBefore(serialDate13);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560236399999L + "'", long10 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//    }

//    @Test
//    public void test471() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test471");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
//        java.util.Date date3 = fixedMillisecond2.getTime();
//        long long4 = fixedMillisecond2.getSerialIndex();
//        long long5 = fixedMillisecond2.getFirstMillisecond();
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond2.getMiddleMillisecond(calendar6);
//        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate13 = serialDate10.getEndOfCurrentMonth(serialDate12);
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate12);
//        boolean boolean15 = fixedMillisecond2.equals((java.lang.Object) serialDate12);
//        long long16 = fixedMillisecond2.getMiddleMillisecond();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(3);
//        java.util.Date date19 = spreadsheetDate18.toDate();
//        int int20 = spreadsheetDate18.getMonth();
//        boolean boolean21 = fixedMillisecond2.equals((java.lang.Object) spreadsheetDate18);
//        int int22 = spreadsheetDate18.getYYYY();
//        int int23 = spreadsheetDate18.getMonth();
//        int int24 = spreadsheetDate18.getMonth();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560236399999L + "'", long5 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560236399999L + "'", long7 == 1560236399999L);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560236399999L + "'", long16 == 1560236399999L);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1900 + "'", int22 == 1900);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//    }

//    @Test
//    public void test472() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test472");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
//        java.util.Date date2 = spreadsheetDate1.toDate();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class6);
//        timeSeries7.setMaximumItemCount((int) (byte) 0);
//        boolean boolean10 = timeSeries7.getNotify();
//        java.util.List list11 = timeSeries7.getItems();
//        java.lang.Class class15 = null;
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class15);
//        timeSeries16.setMaximumItemCount((int) (byte) 0);
//        boolean boolean19 = timeSeries16.getNotify();
//        java.util.List list20 = timeSeries16.getItems();
//        java.util.Collection collection21 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries16);
//        boolean boolean22 = timeSeries7.isEmpty();
//        timeSeries7.setDomainDescription("2019");
//        java.lang.Class<?> wildcardClass25 = timeSeries7.getClass();
//        java.lang.Class class26 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass25);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        java.util.Date date28 = day27.getEnd();
//        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month(date28);
//        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(date28);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond(date28);
//        java.lang.Class class35 = null;
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class35);
//        timeSeries36.setMaximumItemCount((int) (byte) 0);
//        boolean boolean39 = timeSeries36.getNotify();
//        timeSeries36.setKey((java.lang.Comparable) 10.0d);
//        java.lang.Class<?> wildcardClass42 = timeSeries36.getClass();
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
//        java.lang.String str44 = day43.toString();
//        java.util.Date date45 = day43.getStart();
//        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year(date45);
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
//        java.util.Date date48 = day47.getEnd();
//        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month(date48);
//        java.lang.String str50 = month49.toString();
//        java.util.TimeZone timeZone51 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean52 = month49.equals((java.lang.Object) timeZone51);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass42, date45, timeZone51);
//        java.lang.Class class54 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass42);
//        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day();
//        java.util.Date date56 = day55.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond57 = new org.jfree.data.time.FixedMillisecond(date56);
//        java.util.Date date58 = fixedMillisecond57.getTime();
//        java.lang.Class class62 = null;
//        org.jfree.data.time.TimeSeries timeSeries63 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class62);
//        timeSeries63.setMaximumItemCount((int) (byte) 0);
//        boolean boolean66 = timeSeries63.getNotify();
//        timeSeries63.setKey((java.lang.Comparable) 10.0d);
//        java.lang.Class<?> wildcardClass69 = timeSeries63.getClass();
//        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day();
//        java.lang.String str71 = day70.toString();
//        java.util.Date date72 = day70.getStart();
//        org.jfree.data.time.Year year73 = new org.jfree.data.time.Year(date72);
//        org.jfree.data.time.Day day74 = new org.jfree.data.time.Day();
//        java.util.Date date75 = day74.getEnd();
//        org.jfree.data.time.Month month76 = new org.jfree.data.time.Month(date75);
//        java.lang.String str77 = month76.toString();
//        java.util.TimeZone timeZone78 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean79 = month76.equals((java.lang.Object) timeZone78);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass69, date72, timeZone78);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass42, date58, timeZone78);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod82 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date28, timeZone78);
//        org.jfree.data.time.TimeSeries timeSeries83 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate1, (java.lang.Class) wildcardClass25);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertNotNull(list11);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertNotNull(list20);
//        org.junit.Assert.assertNotNull(collection21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertNotNull(wildcardClass25);
//        org.junit.Assert.assertNotNull(class26);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
//        org.junit.Assert.assertNotNull(wildcardClass42);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "10-June-2019" + "'", str44.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "June 2019" + "'", str50.equals("June 2019"));
//        org.junit.Assert.assertNotNull(timeZone51);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//        org.junit.Assert.assertNull(regularTimePeriod53);
//        org.junit.Assert.assertNotNull(class54);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
//        org.junit.Assert.assertNotNull(wildcardClass69);
//        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "10-June-2019" + "'", str71.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date72);
//        org.junit.Assert.assertNotNull(date75);
//        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "June 2019" + "'", str77.equals("June 2019"));
//        org.junit.Assert.assertNotNull(timeZone78);
//        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
//        org.junit.Assert.assertNull(regularTimePeriod80);
//        org.junit.Assert.assertNull(regularTimePeriod81);
//        org.junit.Assert.assertNull(regularTimePeriod82);
//    }

//    @Test
//    public void test473() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test473");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setMaximumItemCount((int) (byte) 0);
//        boolean boolean7 = timeSeries4.getNotify();
//        timeSeries4.setKey((java.lang.Comparable) 10.0d);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        java.util.Date date11 = day10.getEnd();
//        int int13 = day10.compareTo((java.lang.Object) (-1L));
//        org.jfree.data.time.SerialDate serialDate14 = day10.getSerialDate();
//        long long15 = day10.getLastMillisecond();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        java.lang.String str18 = day17.toString();
//        java.util.Date date19 = day17.getStart();
//        org.jfree.data.time.SerialDate serialDate20 = day17.getSerialDate();
//        java.lang.Class<?> wildcardClass21 = day17.getClass();
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 4, (java.lang.Class) wildcardClass21);
//        boolean boolean23 = day10.equals((java.lang.Object) 4);
//        java.lang.Class class27 = null;
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class27);
//        timeSeries28.setMaximumItemCount((int) (byte) 0);
//        boolean boolean31 = timeSeries28.getNotify();
//        java.util.List list32 = timeSeries28.getItems();
//        java.lang.Class class36 = null;
//        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class36);
//        timeSeries37.setMaximumItemCount((int) (byte) 0);
//        boolean boolean40 = timeSeries37.getNotify();
//        java.util.List list41 = timeSeries37.getItems();
//        java.util.Collection collection42 = timeSeries28.getTimePeriodsUniqueToOtherSeries(timeSeries37);
//        java.util.List list43 = timeSeries28.getItems();
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day();
//        java.util.Date date45 = day44.getEnd();
//        int int47 = day44.compareTo((java.lang.Object) (-1L));
//        java.lang.Class class51 = null;
//        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class51);
//        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day();
//        java.lang.String str54 = day53.toString();
//        timeSeries52.delete((org.jfree.data.time.RegularTimePeriod) day53);
//        timeSeries52.fireSeriesChanged();
//        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day();
//        java.util.Date date58 = day57.getEnd();
//        org.jfree.data.time.Month month59 = new org.jfree.data.time.Month(date58);
//        java.lang.Number number60 = timeSeries52.getValue((org.jfree.data.time.RegularTimePeriod) month59);
//        java.lang.Class class64 = null;
//        org.jfree.data.time.TimeSeries timeSeries65 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class64);
//        org.jfree.data.time.Day day66 = new org.jfree.data.time.Day();
//        java.lang.String str67 = day66.toString();
//        timeSeries65.delete((org.jfree.data.time.RegularTimePeriod) day66);
//        boolean boolean69 = timeSeries52.equals((java.lang.Object) day66);
//        boolean boolean70 = day44.equals((java.lang.Object) timeSeries52);
//        org.jfree.data.time.Day day71 = new org.jfree.data.time.Day();
//        java.lang.String str72 = day71.toString();
//        java.util.Date date73 = day71.getStart();
//        long long74 = day71.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries75 = timeSeries28.createCopy((org.jfree.data.time.RegularTimePeriod) day44, (org.jfree.data.time.RegularTimePeriod) day71);
//        org.jfree.data.time.TimeSeries timeSeries76 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) day10, (org.jfree.data.time.RegularTimePeriod) day71);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560236399999L + "'", long15 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "10-June-2019" + "'", str18.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
//        org.junit.Assert.assertNotNull(list32);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
//        org.junit.Assert.assertNotNull(list41);
//        org.junit.Assert.assertNotNull(collection42);
//        org.junit.Assert.assertNotNull(list43);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "10-June-2019" + "'", str54.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertNull(number60);
//        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "10-June-2019" + "'", str67.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
//        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
//        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "10-June-2019" + "'", str72.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date73);
//        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 1560236399999L + "'", long74 == 1560236399999L);
//        org.junit.Assert.assertNotNull(timeSeries75);
//        org.junit.Assert.assertNotNull(timeSeries76);
//    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (short) -1, (int) (short) -1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(13);
        org.junit.Assert.assertNotNull(serialDate1);
    }

//    @Test
//    public void test476() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test476");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(date1);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date1);
//        long long4 = fixedMillisecond3.getLastMillisecond();
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond3.getMiddleMillisecond(calendar5);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        java.lang.String str8 = day7.toString();
//        java.util.Date date9 = day7.getStart();
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date9);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.previous();
//        java.lang.String str12 = regularTimePeriod11.toString();
//        int int13 = fixedMillisecond3.compareTo((java.lang.Object) regularTimePeriod11);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3, (double) 1.0f);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560236399999L + "'", long6 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10-June-2019" + "'", str8.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2018" + "'", str12.equals("2018"));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//    }

//    @Test
//    public void test477() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test477");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        java.util.Date date2 = day0.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
//        java.lang.Class class9 = null;
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class9);
//        timeSeries10.setMaximumItemCount((int) (byte) 0);
//        boolean boolean13 = timeSeries10.getNotify();
//        timeSeries10.setKey((java.lang.Comparable) 10.0d);
//        java.lang.Class<?> wildcardClass16 = timeSeries10.getClass();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        java.lang.String str18 = day17.toString();
//        java.util.Date date19 = day17.getStart();
//        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date19);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        java.util.Date date22 = day21.getEnd();
//        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(date22);
//        java.lang.String str24 = month23.toString();
//        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean26 = month23.equals((java.lang.Object) timeZone25);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date19, timeZone25);
//        java.lang.Class class28 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass16);
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond3, "10-June-2019", "", (java.lang.Class) wildcardClass16);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        java.util.Date date31 = day30.getEnd();
//        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(date31);
//        java.lang.Class class36 = null;
//        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class36);
//        timeSeries37.setMaximumItemCount((int) (byte) 0);
//        boolean boolean40 = timeSeries37.getNotify();
//        timeSeries37.setKey((java.lang.Comparable) 10.0d);
//        java.lang.Class<?> wildcardClass43 = timeSeries37.getClass();
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day();
//        java.lang.String str45 = day44.toString();
//        java.util.Date date46 = day44.getStart();
//        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year(date46);
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
//        java.util.Date date49 = day48.getEnd();
//        org.jfree.data.time.Month month50 = new org.jfree.data.time.Month(date49);
//        java.lang.String str51 = month50.toString();
//        java.util.TimeZone timeZone52 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean53 = month50.equals((java.lang.Object) timeZone52);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass43, date46, timeZone52);
//        org.jfree.data.time.Month month55 = new org.jfree.data.time.Month(date31, timeZone52);
//        java.util.TimeZone timeZone56 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date31, timeZone56);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "10-June-2019" + "'", str18.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "June 2019" + "'", str24.equals("June 2019"));
//        org.junit.Assert.assertNotNull(timeZone25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(class28);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
//        org.junit.Assert.assertNotNull(wildcardClass43);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "10-June-2019" + "'", str45.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "June 2019" + "'", str51.equals("June 2019"));
//        org.junit.Assert.assertNotNull(timeZone52);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertNull(regularTimePeriod54);
//        org.junit.Assert.assertNotNull(timeZone56);
//        org.junit.Assert.assertNull(regularTimePeriod57);
//    }

//    @Test
//    public void test478() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test478");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setMaximumItemCount((int) (byte) 0);
//        boolean boolean7 = timeSeries4.getNotify();
//        java.util.List list8 = timeSeries4.getItems();
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class12);
//        timeSeries13.setMaximumItemCount((int) (byte) 0);
//        boolean boolean16 = timeSeries13.getNotify();
//        java.util.List list17 = timeSeries13.getItems();
//        java.util.Collection collection18 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries13);
//        java.util.List list19 = timeSeries4.getItems();
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        java.util.Date date21 = day20.getEnd();
//        int int23 = day20.compareTo((java.lang.Object) (-1L));
//        java.lang.Class class27 = null;
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class27);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        java.lang.String str30 = day29.toString();
//        timeSeries28.delete((org.jfree.data.time.RegularTimePeriod) day29);
//        timeSeries28.fireSeriesChanged();
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        java.util.Date date34 = day33.getEnd();
//        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(date34);
//        java.lang.Number number36 = timeSeries28.getValue((org.jfree.data.time.RegularTimePeriod) month35);
//        java.lang.Class class40 = null;
//        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class40);
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
//        java.lang.String str43 = day42.toString();
//        timeSeries41.delete((org.jfree.data.time.RegularTimePeriod) day42);
//        boolean boolean45 = timeSeries28.equals((java.lang.Object) day42);
//        boolean boolean46 = day20.equals((java.lang.Object) timeSeries28);
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
//        java.lang.String str48 = day47.toString();
//        java.util.Date date49 = day47.getStart();
//        long long50 = day47.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) day20, (org.jfree.data.time.RegularTimePeriod) day47);
//        timeSeries51.fireSeriesChanged();
//        java.lang.Class class56 = null;
//        org.jfree.data.time.TimeSeries timeSeries57 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class56);
//        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day();
//        java.lang.String str59 = day58.toString();
//        timeSeries57.delete((org.jfree.data.time.RegularTimePeriod) day58);
//        timeSeries57.fireSeriesChanged();
//        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day();
//        java.util.Date date63 = day62.getEnd();
//        org.jfree.data.time.Month month64 = new org.jfree.data.time.Month(date63);
//        java.lang.Number number65 = timeSeries57.getValue((org.jfree.data.time.RegularTimePeriod) month64);
//        org.jfree.data.time.Year year66 = month64.getYear();
//        java.lang.String str67 = year66.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem69 = timeSeries51.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year66, (double) 2019L);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(list8);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNotNull(list17);
//        org.junit.Assert.assertNotNull(collection18);
//        org.junit.Assert.assertNotNull(list19);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "10-June-2019" + "'", str30.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNull(number36);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "10-June-2019" + "'", str43.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "10-June-2019" + "'", str48.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1560236399999L + "'", long50 == 1560236399999L);
//        org.junit.Assert.assertNotNull(timeSeries51);
//        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "10-June-2019" + "'", str59.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date63);
//        org.junit.Assert.assertNull(number65);
//        org.junit.Assert.assertNotNull(year66);
//        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "2019" + "'", str67.equals("2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem69);
//    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 9999);
        java.lang.String str2 = seriesChangeEvent1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9999]" + "'", str2.equals("org.jfree.data.general.SeriesChangeEvent[source=9999]"));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        java.util.Date date4 = day3.getEnd();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate11 = serialDate8.getEndOfCurrentMonth(serialDate10);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(serialDate8);
        boolean boolean14 = spreadsheetDate1.isInRange(serialDate5, serialDate8, 0);
        java.util.Date date15 = spreadsheetDate1.toDate();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(date15);
    }

//    @Test
//    public void test481() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test481");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        java.util.Date date2 = day0.getStart();
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.util.Date date7 = day5.getStart();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.lang.String str9 = day8.toString();
//        java.util.Date date10 = day8.getStart();
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date10);
//        java.lang.Class class15 = null;
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class15);
//        timeSeries16.setMaximumItemCount((int) (byte) 0);
//        boolean boolean19 = timeSeries16.getNotify();
//        java.util.List list20 = timeSeries16.getItems();
//        java.lang.Class class24 = null;
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class24);
//        timeSeries25.setMaximumItemCount((int) (byte) 0);
//        boolean boolean28 = timeSeries25.getNotify();
//        java.util.List list29 = timeSeries25.getItems();
//        java.util.Collection collection30 = timeSeries16.getTimePeriodsUniqueToOtherSeries(timeSeries25);
//        boolean boolean31 = timeSeries16.isEmpty();
//        timeSeries16.setDomainDescription("2019");
//        java.lang.Class<?> wildcardClass34 = timeSeries16.getClass();
//        java.util.Date date35 = null;
//        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass34, date35, timeZone36);
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date10, timeZone36);
//        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(date7, timeZone36);
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date2, timeZone36);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertNotNull(list20);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
//        org.junit.Assert.assertNotNull(list29);
//        org.junit.Assert.assertNotNull(collection30);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNotNull(timeZone36);
//        org.junit.Assert.assertNull(regularTimePeriod37);
//    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate4 = serialDate1.getEndOfCurrentMonth(serialDate3);
        try {
            org.jfree.data.time.SerialDate serialDate6 = serialDate3.getPreviousDayOfWeek((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class6);
        timeSeries7.setMaximumItemCount((int) (byte) 0);
        boolean boolean10 = timeSeries7.getNotify();
        java.util.List list11 = timeSeries7.getItems();
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class15);
        timeSeries16.setMaximumItemCount((int) (byte) 0);
        boolean boolean19 = timeSeries16.getNotify();
        java.util.List list20 = timeSeries16.getItems();
        java.util.Collection collection21 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries16);
        boolean boolean22 = timeSeries7.isEmpty();
        timeSeries7.setDomainDescription("2019");
        java.lang.Class<?> wildcardClass25 = timeSeries7.getClass();
        java.util.Date date26 = null;
        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date26, timeZone27);
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date1, timeZone27);
        int int31 = day29.compareTo((java.lang.Object) "");
        org.jfree.data.time.SerialDate serialDate32 = day29.getSerialDate();
        serialDate32.setDescription("");
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertNotNull(collection21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(serialDate32);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
        timeSeries4.setDomainDescription("hi!");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        java.util.Date date8 = day7.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries4.addChangeListener(seriesChangeListener11);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
    }

//    @Test
//    public void test485() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test485");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        java.util.Date date2 = day0.getStart();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        java.lang.String str4 = day3.toString();
//        java.util.Date date5 = day3.getStart();
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
//        java.lang.Class class10 = null;
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class10);
//        timeSeries11.setMaximumItemCount((int) (byte) 0);
//        boolean boolean14 = timeSeries11.getNotify();
//        java.util.List list15 = timeSeries11.getItems();
//        java.lang.Class class19 = null;
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class19);
//        timeSeries20.setMaximumItemCount((int) (byte) 0);
//        boolean boolean23 = timeSeries20.getNotify();
//        java.util.List list24 = timeSeries20.getItems();
//        java.util.Collection collection25 = timeSeries11.getTimePeriodsUniqueToOtherSeries(timeSeries20);
//        boolean boolean26 = timeSeries11.isEmpty();
//        timeSeries11.setDomainDescription("2019");
//        java.lang.Class<?> wildcardClass29 = timeSeries11.getClass();
//        java.util.Date date30 = null;
//        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass29, date30, timeZone31);
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date5, timeZone31);
//        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date2, timeZone31);
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(date2);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10-June-2019" + "'", str4.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(list15);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//        org.junit.Assert.assertNotNull(list24);
//        org.junit.Assert.assertNotNull(collection25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNotNull(timeZone31);
//        org.junit.Assert.assertNull(regularTimePeriod32);
//    }

//    @Test
//    public void test486() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test486");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        int int3 = day0.compareTo((java.lang.Object) (-1L));
//        java.lang.Class class7 = null;
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class7);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.lang.String str10 = day9.toString();
//        timeSeries8.delete((org.jfree.data.time.RegularTimePeriod) day9);
//        timeSeries8.fireSeriesChanged();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.util.Date date14 = day13.getEnd();
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
//        java.lang.Number number16 = timeSeries8.getValue((org.jfree.data.time.RegularTimePeriod) month15);
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class20);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.lang.String str23 = day22.toString();
//        timeSeries21.delete((org.jfree.data.time.RegularTimePeriod) day22);
//        boolean boolean25 = timeSeries8.equals((java.lang.Object) day22);
//        boolean boolean26 = day0.equals((java.lang.Object) timeSeries8);
//        timeSeries8.setDomainDescription("ERROR : Relative To String");
//        timeSeries8.setMaximumItemCount(3);
//        int int31 = timeSeries8.getItemCount();
//        java.beans.PropertyChangeListener propertyChangeListener32 = null;
//        timeSeries8.removePropertyChangeListener(propertyChangeListener32);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "10-June-2019" + "'", str23.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate7 = serialDate4.getEndOfCurrentMonth(serialDate6);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean11 = spreadsheetDate1.isInRange(serialDate6, (org.jfree.data.time.SerialDate) spreadsheetDate10);
        int int12 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean15 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate14);
        int int16 = spreadsheetDate14.getDayOfWeek();
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1900 + "'", int12 == 1900);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 3 + "'", int16 == 3);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        java.lang.String str3 = month2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        long long5 = month2.getMiddleMillisecond();
        int int6 = month2.getYearValue();
        long long7 = month2.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560668399999L + "'", long5 == 1560668399999L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1559372400000L + "'", long7 == 1559372400000L);
    }

//    @Test
//    public void test489() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test489");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setMaximumItemCount((int) (byte) 0);
//        boolean boolean7 = timeSeries4.getNotify();
//        java.util.List list8 = timeSeries4.getItems();
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class12);
//        timeSeries13.setMaximumItemCount((int) (byte) 0);
//        boolean boolean16 = timeSeries13.getNotify();
//        java.util.List list17 = timeSeries13.getItems();
//        java.util.Collection collection18 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries13);
//        boolean boolean19 = timeSeries4.isEmpty();
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        java.util.Date date21 = day20.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(date21);
//        java.util.Date date23 = fixedMillisecond22.getTime();
//        long long24 = fixedMillisecond22.getSerialIndex();
//        long long25 = fixedMillisecond22.getFirstMillisecond();
//        java.util.Calendar calendar26 = null;
//        long long27 = fixedMillisecond22.getMiddleMillisecond(calendar26);
//        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate33 = serialDate30.getEndOfCurrentMonth(serialDate32);
//        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate32);
//        boolean boolean35 = fixedMillisecond22.equals((java.lang.Object) serialDate32);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = fixedMillisecond22.next();
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
//        java.util.Date date38 = day37.getEnd();
//        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month(date38);
//        java.lang.String str40 = month39.toString();
//        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean42 = month39.equals((java.lang.Object) timeZone41);
//        int int43 = month39.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = month39.previous();
//        org.jfree.data.time.TimeSeries timeSeries45 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, regularTimePeriod44);
//        org.jfree.data.time.SerialDate serialDate47 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate50 = serialDate47.getEndOfCurrentMonth(serialDate49);
//        timeSeries4.setKey((java.lang.Comparable) serialDate47);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(list8);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNotNull(list17);
//        org.junit.Assert.assertNotNull(collection18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560236399999L + "'", long24 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560236399999L + "'", long25 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560236399999L + "'", long27 == 1560236399999L);
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertNotNull(serialDate32);
//        org.junit.Assert.assertNotNull(serialDate33);
//        org.junit.Assert.assertNotNull(serialDate34);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "June 2019" + "'", str40.equals("June 2019"));
//        org.junit.Assert.assertNotNull(timeZone41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 2019 + "'", int43 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod44);
//        org.junit.Assert.assertNotNull(timeSeries45);
//        org.junit.Assert.assertNotNull(serialDate47);
//        org.junit.Assert.assertNotNull(serialDate49);
//        org.junit.Assert.assertNotNull(serialDate50);
//    }

//    @Test
//    public void test490() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test490");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setDomainDescription("hi!");
//        java.lang.Object obj7 = timeSeries4.clone();
//        java.lang.String str8 = timeSeries4.getDescription();
//        timeSeries4.setRangeDescription("June 2019");
//        boolean boolean11 = timeSeries4.isEmpty();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        java.lang.String str13 = day12.toString();
//        java.util.Date date14 = day12.getStart();
//        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date14);
//        java.lang.Object obj16 = null;
//        int int17 = year15.compareTo(obj16);
//        java.lang.String str18 = year15.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year15.previous();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) year15);
//        org.junit.Assert.assertNotNull(obj7);
//        org.junit.Assert.assertNull(str8);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "10-June-2019" + "'", str13.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "2019" + "'", str18.equals("2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(8, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
        timeSeries4.setDomainDescription("hi!");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        java.util.Date date8 = day7.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) 0);
        java.lang.Object obj11 = null;
        boolean boolean12 = timeSeries4.equals(obj11);
        timeSeries4.removeAgedItems(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries4.addChangeListener(seriesChangeListener15);
        try {
            timeSeries4.delete(10, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

//    @Test
//    public void test493() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test493");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setMaximumItemCount((int) (byte) 0);
//        boolean boolean7 = timeSeries4.getNotify();
//        java.util.List list8 = timeSeries4.getItems();
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class12);
//        timeSeries13.setMaximumItemCount((int) (byte) 0);
//        boolean boolean16 = timeSeries13.getNotify();
//        java.util.List list17 = timeSeries13.getItems();
//        java.util.Collection collection18 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries13);
//        java.util.List list19 = timeSeries4.getItems();
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        java.util.Date date21 = day20.getEnd();
//        int int23 = day20.compareTo((java.lang.Object) (-1L));
//        java.lang.Class class27 = null;
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class27);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        java.lang.String str30 = day29.toString();
//        timeSeries28.delete((org.jfree.data.time.RegularTimePeriod) day29);
//        timeSeries28.fireSeriesChanged();
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        java.util.Date date34 = day33.getEnd();
//        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(date34);
//        java.lang.Number number36 = timeSeries28.getValue((org.jfree.data.time.RegularTimePeriod) month35);
//        java.lang.Class class40 = null;
//        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class40);
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
//        java.lang.String str43 = day42.toString();
//        timeSeries41.delete((org.jfree.data.time.RegularTimePeriod) day42);
//        boolean boolean45 = timeSeries28.equals((java.lang.Object) day42);
//        boolean boolean46 = day20.equals((java.lang.Object) timeSeries28);
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
//        java.lang.String str48 = day47.toString();
//        java.util.Date date49 = day47.getStart();
//        long long50 = day47.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) day20, (org.jfree.data.time.RegularTimePeriod) day47);
//        timeSeries51.fireSeriesChanged();
//        java.util.Collection collection53 = timeSeries51.getTimePeriods();
//        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day();
//        java.lang.String str55 = day54.toString();
//        java.util.Date date56 = day54.getStart();
//        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year(date56);
//        java.lang.Object obj58 = null;
//        int int59 = year57.compareTo(obj58);
//        int int60 = year57.getYear();
//        java.lang.String str61 = year57.toString();
//        timeSeries51.setKey((java.lang.Comparable) year57);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = year57.previous();
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(list8);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNotNull(list17);
//        org.junit.Assert.assertNotNull(collection18);
//        org.junit.Assert.assertNotNull(list19);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "10-June-2019" + "'", str30.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNull(number36);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "10-June-2019" + "'", str43.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "10-June-2019" + "'", str48.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1560236399999L + "'", long50 == 1560236399999L);
//        org.junit.Assert.assertNotNull(timeSeries51);
//        org.junit.Assert.assertNotNull(collection53);
//        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "10-June-2019" + "'", str55.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 2019 + "'", int60 == 2019);
//        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "2019" + "'", str61.equals("2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod63);
//    }

//    @Test
//    public void test494() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test494");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        java.util.Date date2 = day0.getStart();
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month4, (double) 0.0f);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.lang.String str9 = day8.toString();
//        java.util.Date date10 = day8.getStart();
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date10);
//        java.lang.Object obj12 = null;
//        int int13 = year11.compareTo(obj12);
//        int int14 = year11.getYear();
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(2, year11);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = month15.previous();
//        boolean boolean17 = month4.equals((java.lang.Object) regularTimePeriod16);
//        long long18 = month4.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1561964399999L + "'", long18 == 1561964399999L);
//    }

//    @Test
//    public void test495() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test495");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
//        java.lang.String str3 = month2.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (double) (short) 100);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        java.util.Date date8 = day7.getEnd();
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date8);
//        java.lang.String str10 = month9.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month9, (double) (short) 100);
//        int int14 = timeSeriesDataItem6.compareTo((java.lang.Object) month9);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        java.lang.String str16 = day15.toString();
//        int int17 = month9.compareTo((java.lang.Object) str16);
//        long long18 = month9.getLastMillisecond();
//        org.jfree.data.time.Year year19 = month9.getYear();
//        java.util.Calendar calendar20 = null;
//        try {
//            long long21 = year19.getFirstMillisecond(calendar20);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "June 2019" + "'", str10.equals("June 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "10-June-2019" + "'", str16.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1561964399999L + "'", long18 == 1561964399999L);
//        org.junit.Assert.assertNotNull(year19);
//    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 9);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException3.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray5);
    }

//    @Test
//    public void test498() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test498");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        java.util.Date date2 = day0.getStart();
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2);
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = year4.getLastMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date2);
//    }

//    @Test
//    public void test499() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test499");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        java.util.Date date2 = day0.getStart();
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year3.previous();
//        long long5 = year3.getFirstMillisecond();
//        long long6 = year3.getFirstMillisecond();
//        long long7 = year3.getFirstMillisecond();
//        long long8 = year3.getFirstMillisecond();
//        long long9 = year3.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546329600000L + "'", long8 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
//    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }
}

