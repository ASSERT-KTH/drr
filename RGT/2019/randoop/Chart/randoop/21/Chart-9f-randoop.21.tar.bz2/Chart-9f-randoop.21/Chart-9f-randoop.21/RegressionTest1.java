import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

//    @Test
//    public void test001() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test001");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setDomainDescription("hi!");
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        java.util.Date date8 = day7.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) 0);
//        timeSeries4.setDescription("");
//        timeSeries4.setNotify(true);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        java.lang.String str16 = day15.toString();
//        java.util.Date date17 = day15.getStart();
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date17);
//        java.lang.Object obj19 = null;
//        int int20 = year18.compareTo(obj19);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) year18);
//        long long22 = year18.getLastMillisecond();
//        java.lang.String str23 = year18.toString();
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(timeSeriesDataItem10);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "10-June-2019" + "'", str16.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem21);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1577865599999L + "'", long22 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "2019" + "'", str23.equals("2019"));
//    }

//    @Test
//    public void test002() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test002");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        java.util.Date date2 = day0.getStart();
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year3.previous();
//        long long5 = year3.getFirstMillisecond();
//        long long6 = year3.getFirstMillisecond();
//        long long7 = year3.getFirstMillisecond();
//        java.util.Calendar calendar8 = null;
//        try {
//            long long9 = year3.getLastMillisecond(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
//    }

//    @Test
//    public void test003() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test003");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setMaximumItemCount((int) (byte) 0);
//        boolean boolean7 = timeSeries4.getNotify();
//        java.util.List list8 = timeSeries4.getItems();
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class12);
//        timeSeries13.setMaximumItemCount((int) (byte) 0);
//        boolean boolean16 = timeSeries13.getNotify();
//        java.util.List list17 = timeSeries13.getItems();
//        java.util.Collection collection18 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries13);
//        java.util.List list19 = timeSeries4.getItems();
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        java.util.Date date21 = day20.getEnd();
//        int int23 = day20.compareTo((java.lang.Object) (-1L));
//        java.lang.Class class27 = null;
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class27);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        java.lang.String str30 = day29.toString();
//        timeSeries28.delete((org.jfree.data.time.RegularTimePeriod) day29);
//        timeSeries28.fireSeriesChanged();
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        java.util.Date date34 = day33.getEnd();
//        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(date34);
//        java.lang.Number number36 = timeSeries28.getValue((org.jfree.data.time.RegularTimePeriod) month35);
//        java.lang.Class class40 = null;
//        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class40);
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
//        java.lang.String str43 = day42.toString();
//        timeSeries41.delete((org.jfree.data.time.RegularTimePeriod) day42);
//        boolean boolean45 = timeSeries28.equals((java.lang.Object) day42);
//        boolean boolean46 = day20.equals((java.lang.Object) timeSeries28);
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
//        java.lang.String str48 = day47.toString();
//        java.util.Date date49 = day47.getStart();
//        long long50 = day47.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) day20, (org.jfree.data.time.RegularTimePeriod) day47);
//        int int52 = day47.getYear();
//        org.jfree.data.time.SerialDate serialDate53 = day47.getSerialDate();
//        long long54 = day47.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(list8);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNotNull(list17);
//        org.junit.Assert.assertNotNull(collection18);
//        org.junit.Assert.assertNotNull(list19);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "10-June-2019" + "'", str30.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNull(number36);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "10-June-2019" + "'", str43.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "10-June-2019" + "'", str48.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1560236399999L + "'", long50 == 1560236399999L);
//        org.junit.Assert.assertNotNull(timeSeries51);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 2019 + "'", int52 == 2019);
//        org.junit.Assert.assertNotNull(serialDate53);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1560150000000L + "'", long54 == 1560150000000L);
//    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.String str5 = timePeriodFormatException3.toString();
        java.lang.String str6 = timePeriodFormatException3.toString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

//    @Test
//    public void test005() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test005");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        java.util.Date date2 = day0.getStart();
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
//        java.lang.Class class7 = null;
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class7);
//        timeSeries8.setMaximumItemCount((int) (byte) 0);
//        boolean boolean11 = timeSeries8.getNotify();
//        java.util.List list12 = timeSeries8.getItems();
//        java.lang.Class class16 = null;
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class16);
//        timeSeries17.setMaximumItemCount((int) (byte) 0);
//        boolean boolean20 = timeSeries17.getNotify();
//        java.util.List list21 = timeSeries17.getItems();
//        java.util.Collection collection22 = timeSeries8.getTimePeriodsUniqueToOtherSeries(timeSeries17);
//        boolean boolean23 = timeSeries8.isEmpty();
//        timeSeries8.setDomainDescription("2019");
//        java.lang.Class<?> wildcardClass26 = timeSeries8.getClass();
//        java.util.Date date27 = null;
//        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass26, date27, timeZone28);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date2, timeZone28);
//        java.lang.String str31 = day30.toString();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertNotNull(list12);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertNotNull(list21);
//        org.junit.Assert.assertNotNull(collection22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(timeZone28);
//        org.junit.Assert.assertNull(regularTimePeriod29);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "10-June-2019" + "'", str31.equals("10-June-2019"));
//    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
        java.util.Calendar calendar4 = null;
        try {
            long long5 = day3.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

//    @Test
//    public void test007() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test007");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        java.util.Date date2 = day0.getStart();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) 10.0f);
//        boolean boolean6 = day0.equals((java.lang.Object) (byte) -1);
//        java.util.Calendar calendar7 = null;
//        try {
//            long long8 = day0.getFirstMillisecond(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate7 = serialDate4.getEndOfCurrentMonth(serialDate6);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean11 = spreadsheetDate1.isInRange(serialDate6, (org.jfree.data.time.SerialDate) spreadsheetDate10);
        int int12 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean15 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate21 = serialDate18.getEndOfCurrentMonth(serialDate20);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addDays(0, serialDate21);
        boolean boolean23 = spreadsheetDate1.isOnOrBefore(serialDate21);
        int int24 = spreadsheetDate1.getYYYY();
        int int25 = spreadsheetDate1.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.createInstance(9);
        boolean boolean30 = spreadsheetDate27.isOnOrAfter(serialDate29);
        boolean boolean31 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate27);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate39 = serialDate36.getEndOfCurrentMonth(serialDate38);
        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate38);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean43 = spreadsheetDate33.isInRange(serialDate38, (org.jfree.data.time.SerialDate) spreadsheetDate42);
        int int44 = spreadsheetDate33.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean47 = spreadsheetDate33.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate46);
        org.jfree.data.time.SerialDate serialDate50 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate52 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate53 = serialDate50.getEndOfCurrentMonth(serialDate52);
        org.jfree.data.time.SerialDate serialDate54 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate52);
        boolean boolean55 = spreadsheetDate46.isOnOrAfter(serialDate52);
        java.util.Date date56 = spreadsheetDate46.toDate();
        boolean boolean57 = spreadsheetDate27.equals((java.lang.Object) date56);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1900 + "'", int12 == 1900);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1900 + "'", int24 == 1900);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2 + "'", int25 == 2);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertNotNull(serialDate38);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1900 + "'", int44 == 1900);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertNotNull(serialDate52);
        org.junit.Assert.assertNotNull(serialDate53);
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10);
        java.lang.Object obj2 = seriesChangeEvent1.getSource();
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + 10 + "'", obj2.equals(10));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
        timeSeries4.setMaximumItemCount((int) (byte) 0);
        boolean boolean7 = timeSeries4.getNotify();
        java.lang.Comparable comparable8 = timeSeries4.getKey();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener9);
        java.lang.Class class11 = timeSeries4.getTimePeriodClass();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0f) + "'", comparable8.equals((-1.0f)));
        org.junit.Assert.assertNull(class11);
    }

//    @Test
//    public void test011() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test011");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        java.lang.String str4 = day3.toString();
//        long long5 = day3.getFirstMillisecond();
//        boolean boolean6 = month2.equals((java.lang.Object) day3);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        java.util.Date date8 = day7.getEnd();
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date8);
//        java.lang.String str10 = month9.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month9, (double) (short) 100);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.util.Date date15 = day14.getEnd();
//        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date15);
//        java.lang.String str17 = month16.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month16.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month16, (double) (short) 100);
//        int int21 = timeSeriesDataItem13.compareTo((java.lang.Object) month16);
//        timeSeriesDataItem13.setValue((java.lang.Number) 6);
//        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate29 = serialDate26.getEndOfCurrentMonth(serialDate28);
//        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate28);
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(serialDate30);
//        boolean boolean32 = timeSeriesDataItem13.equals((java.lang.Object) serialDate30);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent33 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeriesDataItem13);
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        java.util.Date date35 = day34.getEnd();
//        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month(date35);
//        java.lang.String str37 = month36.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = month36.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month36, (double) (short) 100);
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
//        java.util.Date date42 = day41.getEnd();
//        org.jfree.data.time.Month month43 = new org.jfree.data.time.Month(date42);
//        java.lang.String str44 = month43.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = month43.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month43, (double) (short) 100);
//        int int48 = timeSeriesDataItem40.compareTo((java.lang.Object) month43);
//        timeSeriesDataItem40.setValue((java.lang.Number) 100);
//        java.lang.Number number51 = timeSeriesDataItem40.getValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = timeSeriesDataItem40.getPeriod();
//        boolean boolean53 = timeSeriesDataItem13.equals((java.lang.Object) regularTimePeriod52);
//        boolean boolean54 = day3.equals((java.lang.Object) regularTimePeriod52);
//        org.jfree.data.time.SerialDate serialDate55 = day3.getSerialDate();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10-June-2019" + "'", str4.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560150000000L + "'", long5 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "June 2019" + "'", str10.equals("June 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "June 2019" + "'", str17.equals("June 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertNotNull(serialDate28);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "June 2019" + "'", str37.equals("June 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "June 2019" + "'", str44.equals("June 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
//        org.junit.Assert.assertTrue("'" + number51 + "' != '" + 100 + "'", number51.equals(100));
//        org.junit.Assert.assertNotNull(regularTimePeriod52);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//        org.junit.Assert.assertNotNull(serialDate55);
//    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(3);
        int int3 = spreadsheetDate2.toSerial();
        java.lang.String str4 = spreadsheetDate2.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate12 = serialDate9.getEndOfCurrentMonth(serialDate11);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean16 = spreadsheetDate6.isInRange(serialDate11, (org.jfree.data.time.SerialDate) spreadsheetDate15);
        int int17 = spreadsheetDate6.getYYYY();
        boolean boolean18 = spreadsheetDate2.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate6);
        java.lang.String str19 = spreadsheetDate6.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance(9);
        boolean boolean26 = spreadsheetDate23.isOnOrAfter(serialDate25);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate34 = serialDate31.getEndOfCurrentMonth(serialDate33);
        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate33);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean38 = spreadsheetDate28.isInRange(serialDate33, (org.jfree.data.time.SerialDate) spreadsheetDate37);
        int int39 = spreadsheetDate28.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean42 = spreadsheetDate28.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate41);
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate47 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate48 = serialDate45.getEndOfCurrentMonth(serialDate47);
        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.addDays(0, serialDate48);
        boolean boolean50 = spreadsheetDate28.isOnOrBefore(serialDate48);
        int int51 = spreadsheetDate23.compare((org.jfree.data.time.SerialDate) spreadsheetDate28);
        int int52 = spreadsheetDate28.getDayOfMonth();
        int int53 = spreadsheetDate28.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate55 = new org.jfree.data.time.SpreadsheetDate(12);
        java.util.Date date56 = spreadsheetDate55.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate58 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate61 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate63 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate64 = serialDate61.getEndOfCurrentMonth(serialDate63);
        org.jfree.data.time.SerialDate serialDate65 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate63);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate67 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean68 = spreadsheetDate58.isInRange(serialDate63, (org.jfree.data.time.SerialDate) spreadsheetDate67);
        org.jfree.data.time.SerialDate serialDate70 = serialDate63.getPreviousDayOfWeek(7);
        boolean boolean71 = spreadsheetDate28.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate55, serialDate70);
        org.jfree.data.time.SerialDate serialDate72 = org.jfree.data.time.SerialDate.addDays((int) (short) -1, (org.jfree.data.time.SerialDate) spreadsheetDate28);
        org.jfree.data.time.SerialDate serialDate73 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate28);
        int int74 = spreadsheetDate6.compare((org.jfree.data.time.SerialDate) spreadsheetDate28);
        try {
            org.jfree.data.time.SerialDate serialDate75 = org.jfree.data.time.SerialDate.addDays(2958465, (org.jfree.data.time.SerialDate) spreadsheetDate6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1900 + "'", int17 == 1900);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "2-January-1900" + "'", str19.equals("2-January-1900"));
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1900 + "'", int39 == 1900);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 2 + "'", int52 == 2);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 3 + "'", int53 == 3);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertNotNull(serialDate61);
        org.junit.Assert.assertNotNull(serialDate63);
        org.junit.Assert.assertNotNull(serialDate64);
        org.junit.Assert.assertNotNull(serialDate65);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertNotNull(serialDate70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(serialDate72);
        org.junit.Assert.assertNotNull(serialDate73);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 0 + "'", int74 == 0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        java.util.Date date4 = day3.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
        java.util.Date date6 = fixedMillisecond5.getTime();
        int int7 = month2.compareTo((java.lang.Object) fixedMillisecond5);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        java.util.Date date9 = day8.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(date9);
        boolean boolean11 = fixedMillisecond5.equals((java.lang.Object) date9);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

//    @Test
//    public void test015() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test015");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        int int3 = day0.compareTo((java.lang.Object) (-1L));
//        java.lang.Class class7 = null;
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class7);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.lang.String str10 = day9.toString();
//        timeSeries8.delete((org.jfree.data.time.RegularTimePeriod) day9);
//        timeSeries8.fireSeriesChanged();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.util.Date date14 = day13.getEnd();
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
//        java.lang.Number number16 = timeSeries8.getValue((org.jfree.data.time.RegularTimePeriod) month15);
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class20);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.lang.String str23 = day22.toString();
//        timeSeries21.delete((org.jfree.data.time.RegularTimePeriod) day22);
//        boolean boolean25 = timeSeries8.equals((java.lang.Object) day22);
//        boolean boolean26 = day0.equals((java.lang.Object) timeSeries8);
//        timeSeries8.setDomainDescription("ERROR : Relative To String");
//        timeSeries8.setMaximumItemCount(3);
//        java.lang.Class class31 = timeSeries8.getTimePeriodClass();
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        java.util.Date date33 = day32.getEnd();
//        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month(date33);
//        java.lang.String str35 = month34.toString();
//        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean37 = month34.equals((java.lang.Object) timeZone36);
//        int int38 = month34.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = month34.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries8.addOrUpdate(regularTimePeriod39, (double) (byte) 10);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "10-June-2019" + "'", str23.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNull(class31);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "June 2019" + "'", str35.equals("June 2019"));
//        org.junit.Assert.assertNotNull(timeZone36);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2019 + "'", int38 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertNull(timeSeriesDataItem41);
//    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate8 = serialDate5.getEndOfCurrentMonth(serialDate7);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean12 = spreadsheetDate2.isInRange(serialDate7, (org.jfree.data.time.SerialDate) spreadsheetDate11);
        int int13 = spreadsheetDate2.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean16 = spreadsheetDate2.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate22 = serialDate19.getEndOfCurrentMonth(serialDate21);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addDays(0, serialDate22);
        boolean boolean24 = spreadsheetDate2.isOnOrBefore(serialDate22);
        int int25 = spreadsheetDate2.getYYYY();
        int int26 = spreadsheetDate2.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.createInstance(9);
        boolean boolean31 = spreadsheetDate28.isOnOrAfter(serialDate30);
        boolean boolean32 = spreadsheetDate2.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate28);
        try {
            org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(6, (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1900 + "'", int13 == 1900);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1900 + "'", int25 == 1900);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2 + "'", int26 == 2);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (2147483647) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((-457));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test019() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test019");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        java.lang.String str4 = day3.toString();
//        long long5 = day3.getFirstMillisecond();
//        boolean boolean6 = month2.equals((java.lang.Object) day3);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        java.util.Date date8 = day7.getEnd();
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date8);
//        java.lang.String str10 = month9.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month9, (double) (short) 100);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.util.Date date15 = day14.getEnd();
//        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date15);
//        java.lang.String str17 = month16.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month16.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month16, (double) (short) 100);
//        int int21 = timeSeriesDataItem13.compareTo((java.lang.Object) month16);
//        timeSeriesDataItem13.setValue((java.lang.Number) 6);
//        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate29 = serialDate26.getEndOfCurrentMonth(serialDate28);
//        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate28);
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(serialDate30);
//        boolean boolean32 = timeSeriesDataItem13.equals((java.lang.Object) serialDate30);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent33 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeriesDataItem13);
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        java.util.Date date35 = day34.getEnd();
//        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month(date35);
//        java.lang.String str37 = month36.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = month36.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month36, (double) (short) 100);
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
//        java.util.Date date42 = day41.getEnd();
//        org.jfree.data.time.Month month43 = new org.jfree.data.time.Month(date42);
//        java.lang.String str44 = month43.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = month43.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month43, (double) (short) 100);
//        int int48 = timeSeriesDataItem40.compareTo((java.lang.Object) month43);
//        timeSeriesDataItem40.setValue((java.lang.Number) 100);
//        java.lang.Number number51 = timeSeriesDataItem40.getValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = timeSeriesDataItem40.getPeriod();
//        boolean boolean53 = timeSeriesDataItem13.equals((java.lang.Object) regularTimePeriod52);
//        boolean boolean54 = day3.equals((java.lang.Object) regularTimePeriod52);
//        java.lang.Object obj55 = null;
//        int int56 = day3.compareTo(obj55);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10-June-2019" + "'", str4.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560150000000L + "'", long5 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "June 2019" + "'", str10.equals("June 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "June 2019" + "'", str17.equals("June 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertNotNull(serialDate28);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "June 2019" + "'", str37.equals("June 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "June 2019" + "'", str44.equals("June 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
//        org.junit.Assert.assertTrue("'" + number51 + "' != '" + 100 + "'", number51.equals(100));
//        org.junit.Assert.assertNotNull(regularTimePeriod52);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
//    }

//    @Test
//    public void test020() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test020");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
//        java.lang.String str3 = month2.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (double) (short) 100);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        java.util.Date date8 = day7.getEnd();
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date8);
//        java.lang.String str10 = month9.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month9, (double) (short) 100);
//        int int14 = timeSeriesDataItem6.compareTo((java.lang.Object) month9);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        java.lang.String str16 = day15.toString();
//        int int17 = month9.compareTo((java.lang.Object) str16);
//        long long18 = month9.getLastMillisecond();
//        org.jfree.data.time.Year year19 = month9.getYear();
//        long long20 = year19.getFirstMillisecond();
//        int int21 = year19.getYear();
//        java.util.Date date22 = year19.getStart();
//        int int23 = year19.getYear();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "June 2019" + "'", str10.equals("June 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "10-June-2019" + "'", str16.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1561964399999L + "'", long18 == 1561964399999L);
//        org.junit.Assert.assertNotNull(year19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1546329600000L + "'", long20 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2019 + "'", int23 == 2019);
//    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (12) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test022() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test022");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(date1);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date1);
//        long long4 = fixedMillisecond3.getLastMillisecond();
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond3.getMiddleMillisecond(calendar5);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        java.lang.String str8 = day7.toString();
//        java.util.Date date9 = day7.getStart();
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date9);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.previous();
//        java.lang.String str12 = regularTimePeriod11.toString();
//        int int13 = fixedMillisecond3.compareTo((java.lang.Object) regularTimePeriod11);
//        java.lang.Class class16 = null;
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int13, "Feb", "", class16);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560236399999L + "'", long6 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10-June-2019" + "'", str8.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2018" + "'", str12.equals("2018"));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//    }

//    @Test
//    public void test023() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test023");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(date1);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date1);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.String str5 = day4.toString();
//        java.util.Date date6 = day4.getStart();
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class11);
//        timeSeries12.setMaximumItemCount((int) (byte) 0);
//        boolean boolean15 = timeSeries12.getNotify();
//        java.util.List list16 = timeSeries12.getItems();
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class20);
//        timeSeries21.setMaximumItemCount((int) (byte) 0);
//        boolean boolean24 = timeSeries21.getNotify();
//        java.util.List list25 = timeSeries21.getItems();
//        java.util.Collection collection26 = timeSeries12.getTimePeriodsUniqueToOtherSeries(timeSeries21);
//        boolean boolean27 = timeSeries12.isEmpty();
//        timeSeries12.setDomainDescription("2019");
//        java.lang.Class<?> wildcardClass30 = timeSeries12.getClass();
//        java.util.Date date31 = null;
//        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date31, timeZone32);
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date6, timeZone32);
//        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year(date1, timeZone32);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond(date1);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10-June-2019" + "'", str5.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertNotNull(list16);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//        org.junit.Assert.assertNotNull(list25);
//        org.junit.Assert.assertNotNull(collection26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertNotNull(timeZone32);
//        org.junit.Assert.assertNull(regularTimePeriod33);
//    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
        timeSeries4.setMaximumItemCount((int) (byte) 0);
        boolean boolean7 = timeSeries4.getNotify();
        java.lang.Comparable comparable8 = timeSeries4.getKey();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = null;
        try {
            timeSeries4.add(timeSeriesDataItem11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0f) + "'", comparable8.equals((-1.0f)));
    }

//    @Test
//    public void test025() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test025");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setMaximumItemCount((int) (byte) 0);
//        boolean boolean7 = timeSeries4.getNotify();
//        java.util.List list8 = timeSeries4.getItems();
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class12);
//        timeSeries13.setMaximumItemCount((int) (byte) 0);
//        boolean boolean16 = timeSeries13.getNotify();
//        java.util.List list17 = timeSeries13.getItems();
//        java.util.Collection collection18 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries13);
//        java.util.List list19 = timeSeries4.getItems();
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        java.util.Date date21 = day20.getEnd();
//        int int23 = day20.compareTo((java.lang.Object) (-1L));
//        java.lang.Class class27 = null;
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class27);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        java.lang.String str30 = day29.toString();
//        timeSeries28.delete((org.jfree.data.time.RegularTimePeriod) day29);
//        timeSeries28.fireSeriesChanged();
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        java.util.Date date34 = day33.getEnd();
//        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(date34);
//        java.lang.Number number36 = timeSeries28.getValue((org.jfree.data.time.RegularTimePeriod) month35);
//        java.lang.Class class40 = null;
//        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class40);
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
//        java.lang.String str43 = day42.toString();
//        timeSeries41.delete((org.jfree.data.time.RegularTimePeriod) day42);
//        boolean boolean45 = timeSeries28.equals((java.lang.Object) day42);
//        boolean boolean46 = day20.equals((java.lang.Object) timeSeries28);
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
//        java.lang.String str48 = day47.toString();
//        java.util.Date date49 = day47.getStart();
//        long long50 = day47.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) day20, (org.jfree.data.time.RegularTimePeriod) day47);
//        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day();
//        java.util.Date date53 = day52.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond(date53);
//        java.util.Date date55 = fixedMillisecond54.getTime();
//        long long56 = fixedMillisecond54.getSerialIndex();
//        long long57 = fixedMillisecond54.getFirstMillisecond();
//        java.util.Calendar calendar58 = null;
//        long long59 = fixedMillisecond54.getLastMillisecond(calendar58);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem61 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond54, (double) 2);
//        long long62 = fixedMillisecond54.getFirstMillisecond();
//        long long63 = fixedMillisecond54.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(list8);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNotNull(list17);
//        org.junit.Assert.assertNotNull(collection18);
//        org.junit.Assert.assertNotNull(list19);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "10-June-2019" + "'", str30.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNull(number36);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "10-June-2019" + "'", str43.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "10-June-2019" + "'", str48.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1560236399999L + "'", long50 == 1560236399999L);
//        org.junit.Assert.assertNotNull(timeSeries51);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertNotNull(date55);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1560236399999L + "'", long56 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 1560236399999L + "'", long57 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 1560236399999L + "'", long59 == 1560236399999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem61);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 1560236399999L + "'", long62 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 1560236399999L + "'", long63 == 1560236399999L);
//    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate8 = serialDate5.getEndOfCurrentMonth(serialDate7);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean12 = spreadsheetDate2.isInRange(serialDate7, (org.jfree.data.time.SerialDate) spreadsheetDate11);
        int int13 = spreadsheetDate2.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean16 = spreadsheetDate2.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate22 = serialDate19.getEndOfCurrentMonth(serialDate21);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addDays(0, serialDate22);
        boolean boolean24 = spreadsheetDate2.isOnOrBefore(serialDate22);
        try {
            org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.addYears((-457), serialDate22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1900 + "'", int13 == 1900);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
        timeSeries4.setMaximumItemCount((int) (byte) 0);
        boolean boolean7 = timeSeries4.getNotify();
        java.lang.Comparable comparable8 = timeSeries4.getKey();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener9);
        java.lang.Class<?> wildcardClass11 = timeSeries4.getClass();
        java.lang.String str12 = timeSeries4.getDescription();
        java.lang.Class class13 = timeSeries4.getTimePeriodClass();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0f) + "'", comparable8.equals((-1.0f)));
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNull(class13);
    }

//    @Test
//    public void test028() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test028");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        java.util.Date date2 = day0.getStart();
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2);
//        int int5 = year4.getYear();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(1900);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(9);
        boolean boolean6 = spreadsheetDate3.isOnOrAfter(serialDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate14 = serialDate11.getEndOfCurrentMonth(serialDate13);
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean18 = spreadsheetDate8.isInRange(serialDate13, (org.jfree.data.time.SerialDate) spreadsheetDate17);
        int int19 = spreadsheetDate8.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean22 = spreadsheetDate8.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate28 = serialDate25.getEndOfCurrentMonth(serialDate27);
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.addDays(0, serialDate28);
        boolean boolean30 = spreadsheetDate8.isOnOrBefore(serialDate28);
        int int31 = spreadsheetDate3.compare((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(12);
        java.util.Date date34 = spreadsheetDate33.toDate();
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
        java.util.Date date36 = day35.getEnd();
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.createInstance(date36);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(serialDate37);
        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate43 = serialDate40.getEndOfCurrentMonth(serialDate42);
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(serialDate40);
        boolean boolean46 = spreadsheetDate33.isInRange(serialDate37, serialDate40, 0);
        boolean boolean47 = spreadsheetDate8.isOnOrAfter(serialDate37);
        org.jfree.data.time.SerialDate serialDate48 = null;
        try {
            boolean boolean49 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate8, serialDate48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1900 + "'", int19 == 1900);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class6);
        timeSeries7.setMaximumItemCount((int) (byte) 0);
        boolean boolean10 = timeSeries7.getNotify();
        java.util.List list11 = timeSeries7.getItems();
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class15);
        timeSeries16.setMaximumItemCount((int) (byte) 0);
        boolean boolean19 = timeSeries16.getNotify();
        java.util.List list20 = timeSeries16.getItems();
        java.util.Collection collection21 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries16);
        boolean boolean22 = timeSeries7.isEmpty();
        timeSeries7.setDomainDescription("2019");
        java.lang.Class<?> wildcardClass25 = timeSeries7.getClass();
        java.util.Date date26 = null;
        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date26, timeZone27);
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date1, timeZone27);
        int int31 = day29.compareTo((java.lang.Object) "");
        org.jfree.data.time.SerialDate serialDate32 = day29.getSerialDate();
        int int33 = day29.getYear();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertNotNull(collection21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2019 + "'", int33 == 2019);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
        timeSeries4.setMaximumItemCount((int) (byte) 0);
        boolean boolean7 = timeSeries4.getNotify();
        java.util.List list8 = timeSeries4.getItems();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class12);
        timeSeries13.setMaximumItemCount((int) (byte) 0);
        boolean boolean16 = timeSeries13.getNotify();
        java.util.List list17 = timeSeries13.getItems();
        java.util.Collection collection18 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timeSeries13.removePropertyChangeListener(propertyChangeListener19);
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener21);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(list17);
        org.junit.Assert.assertNotNull(collection18);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(9);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

//    @Test
//    public void test033() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test033");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
//        java.util.Date date3 = fixedMillisecond2.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond4.previous();
//        long long6 = fixedMillisecond4.getSerialIndex();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560236399999L + "'", long6 == 1560236399999L);
//    }

//    @Test
//    public void test034() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test034");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        java.util.Date date2 = day0.getStart();
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
//        java.util.TimeZone timeZone5 = null;
//        try {
//            org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date2, timeZone5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date2);
//    }

//    @Test
//    public void test035() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test035");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setMaximumItemCount((int) (byte) 0);
//        boolean boolean7 = timeSeries4.getNotify();
//        java.util.List list8 = timeSeries4.getItems();
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class12);
//        timeSeries13.setMaximumItemCount((int) (byte) 0);
//        boolean boolean16 = timeSeries13.getNotify();
//        java.util.List list17 = timeSeries13.getItems();
//        java.util.Collection collection18 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries13);
//        java.util.List list19 = timeSeries4.getItems();
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        java.util.Date date21 = day20.getEnd();
//        int int23 = day20.compareTo((java.lang.Object) (-1L));
//        java.lang.Class class27 = null;
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class27);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        java.lang.String str30 = day29.toString();
//        timeSeries28.delete((org.jfree.data.time.RegularTimePeriod) day29);
//        timeSeries28.fireSeriesChanged();
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        java.util.Date date34 = day33.getEnd();
//        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(date34);
//        java.lang.Number number36 = timeSeries28.getValue((org.jfree.data.time.RegularTimePeriod) month35);
//        java.lang.Class class40 = null;
//        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class40);
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
//        java.lang.String str43 = day42.toString();
//        timeSeries41.delete((org.jfree.data.time.RegularTimePeriod) day42);
//        boolean boolean45 = timeSeries28.equals((java.lang.Object) day42);
//        boolean boolean46 = day20.equals((java.lang.Object) timeSeries28);
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
//        java.lang.String str48 = day47.toString();
//        java.util.Date date49 = day47.getStart();
//        long long50 = day47.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) day20, (org.jfree.data.time.RegularTimePeriod) day47);
//        timeSeries51.fireSeriesChanged();
//        java.lang.Class class53 = timeSeries51.getTimePeriodClass();
//        java.lang.Class class57 = null;
//        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class57);
//        timeSeries58.setMaximumItemCount((int) (byte) 0);
//        boolean boolean61 = timeSeries58.getNotify();
//        java.util.List list62 = timeSeries58.getItems();
//        java.lang.Class class63 = timeSeries58.getTimePeriodClass();
//        java.util.Collection collection64 = timeSeries58.getTimePeriods();
//        java.util.Collection collection65 = timeSeries51.getTimePeriodsUniqueToOtherSeries(timeSeries58);
//        timeSeries58.fireSeriesChanged();
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(list8);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNotNull(list17);
//        org.junit.Assert.assertNotNull(collection18);
//        org.junit.Assert.assertNotNull(list19);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "10-June-2019" + "'", str30.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNull(number36);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "10-June-2019" + "'", str43.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "10-June-2019" + "'", str48.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1560236399999L + "'", long50 == 1560236399999L);
//        org.junit.Assert.assertNotNull(timeSeries51);
//        org.junit.Assert.assertNull(class53);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
//        org.junit.Assert.assertNotNull(list62);
//        org.junit.Assert.assertNull(class63);
//        org.junit.Assert.assertNotNull(collection64);
//        org.junit.Assert.assertNotNull(collection65);
//    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((int) (short) -1, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test037() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test037");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(date1);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date1);
//        long long4 = fixedMillisecond3.getLastMillisecond();
//        java.util.Calendar calendar5 = null;
//        fixedMillisecond3.peg(calendar5);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//    }

//    @Test
//    public void test038() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test038");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setMaximumItemCount((int) (byte) 0);
//        boolean boolean7 = timeSeries4.getNotify();
//        java.util.List list8 = timeSeries4.getItems();
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class12);
//        timeSeries13.setMaximumItemCount((int) (byte) 0);
//        boolean boolean16 = timeSeries13.getNotify();
//        java.util.List list17 = timeSeries13.getItems();
//        java.util.Collection collection18 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries13);
//        timeSeries13.setNotify(true);
//        java.lang.Class class24 = null;
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class24);
//        timeSeries25.setMaximumItemCount((int) (byte) 0);
//        boolean boolean28 = timeSeries25.getNotify();
//        java.util.List list29 = timeSeries25.getItems();
//        java.lang.Class class33 = null;
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class33);
//        timeSeries34.setMaximumItemCount((int) (byte) 0);
//        boolean boolean37 = timeSeries34.getNotify();
//        java.util.List list38 = timeSeries34.getItems();
//        java.util.Collection collection39 = timeSeries25.getTimePeriodsUniqueToOtherSeries(timeSeries34);
//        java.util.List list40 = timeSeries25.getItems();
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
//        java.util.Date date42 = day41.getEnd();
//        int int44 = day41.compareTo((java.lang.Object) (-1L));
//        java.lang.Class class48 = null;
//        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class48);
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day();
//        java.lang.String str51 = day50.toString();
//        timeSeries49.delete((org.jfree.data.time.RegularTimePeriod) day50);
//        timeSeries49.fireSeriesChanged();
//        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day();
//        java.util.Date date55 = day54.getEnd();
//        org.jfree.data.time.Month month56 = new org.jfree.data.time.Month(date55);
//        java.lang.Number number57 = timeSeries49.getValue((org.jfree.data.time.RegularTimePeriod) month56);
//        java.lang.Class class61 = null;
//        org.jfree.data.time.TimeSeries timeSeries62 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class61);
//        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day();
//        java.lang.String str64 = day63.toString();
//        timeSeries62.delete((org.jfree.data.time.RegularTimePeriod) day63);
//        boolean boolean66 = timeSeries49.equals((java.lang.Object) day63);
//        boolean boolean67 = day41.equals((java.lang.Object) timeSeries49);
//        org.jfree.data.time.Day day68 = new org.jfree.data.time.Day();
//        java.lang.String str69 = day68.toString();
//        java.util.Date date70 = day68.getStart();
//        long long71 = day68.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries72 = timeSeries25.createCopy((org.jfree.data.time.RegularTimePeriod) day41, (org.jfree.data.time.RegularTimePeriod) day68);
//        org.jfree.data.time.Day day73 = new org.jfree.data.time.Day();
//        java.util.Date date74 = day73.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond75 = new org.jfree.data.time.FixedMillisecond(date74);
//        java.util.Date date76 = fixedMillisecond75.getTime();
//        long long77 = fixedMillisecond75.getSerialIndex();
//        long long78 = fixedMillisecond75.getFirstMillisecond();
//        java.util.Calendar calendar79 = null;
//        long long80 = fixedMillisecond75.getLastMillisecond(calendar79);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem82 = timeSeries25.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond75, (double) 2);
//        long long83 = fixedMillisecond75.getFirstMillisecond();
//        int int84 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond75);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(list8);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNotNull(list17);
//        org.junit.Assert.assertNotNull(collection18);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
//        org.junit.Assert.assertNotNull(list29);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
//        org.junit.Assert.assertNotNull(list38);
//        org.junit.Assert.assertNotNull(collection39);
//        org.junit.Assert.assertNotNull(list40);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "10-June-2019" + "'", str51.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date55);
//        org.junit.Assert.assertNull(number57);
//        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "10-June-2019" + "'", str64.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
//        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
//        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "10-June-2019" + "'", str69.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date70);
//        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 1560236399999L + "'", long71 == 1560236399999L);
//        org.junit.Assert.assertNotNull(timeSeries72);
//        org.junit.Assert.assertNotNull(date74);
//        org.junit.Assert.assertNotNull(date76);
//        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 1560236399999L + "'", long77 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 1560236399999L + "'", long78 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 1560236399999L + "'", long80 == 1560236399999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem82);
//        org.junit.Assert.assertTrue("'" + long83 + "' != '" + 1560236399999L + "'", long83 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int84 + "' != '" + (-1) + "'", int84 == (-1));
//    }

//    @Test
//    public void test039() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test039");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
//        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate7 = serialDate4.getEndOfCurrentMonth(serialDate6);
//        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(3);
//        boolean boolean11 = spreadsheetDate1.isInRange(serialDate6, (org.jfree.data.time.SerialDate) spreadsheetDate10);
//        int int12 = spreadsheetDate1.getYYYY();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(3);
//        boolean boolean15 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate14);
//        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate21 = serialDate18.getEndOfCurrentMonth(serialDate20);
//        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate20);
//        boolean boolean23 = spreadsheetDate14.isOnOrAfter(serialDate20);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(3);
//        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate31 = serialDate28.getEndOfCurrentMonth(serialDate30);
//        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate30);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate(3);
//        boolean boolean35 = spreadsheetDate25.isInRange(serialDate30, (org.jfree.data.time.SerialDate) spreadsheetDate34);
//        int int36 = spreadsheetDate25.getYYYY();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate(3);
//        boolean boolean39 = spreadsheetDate25.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate38);
//        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate45 = serialDate42.getEndOfCurrentMonth(serialDate44);
//        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.addDays(0, serialDate45);
//        boolean boolean47 = spreadsheetDate25.isOnOrBefore(serialDate45);
//        int int48 = spreadsheetDate25.getYYYY();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate(12);
//        java.util.Date date51 = spreadsheetDate50.toDate();
//        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day();
//        java.util.Date date53 = day52.getEnd();
//        org.jfree.data.time.SerialDate serialDate54 = org.jfree.data.time.SerialDate.createInstance(date53);
//        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day(serialDate54);
//        org.jfree.data.time.SerialDate serialDate57 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate59 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate60 = serialDate57.getEndOfCurrentMonth(serialDate59);
//        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day(serialDate57);
//        boolean boolean63 = spreadsheetDate50.isInRange(serialDate54, serialDate57, 0);
//        boolean boolean64 = spreadsheetDate25.isOn(serialDate57);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate66 = new org.jfree.data.time.SpreadsheetDate(3);
//        org.jfree.data.time.SerialDate serialDate68 = org.jfree.data.time.SerialDate.createInstance(9);
//        boolean boolean69 = spreadsheetDate66.isOnOrAfter(serialDate68);
//        int int70 = spreadsheetDate66.getDayOfWeek();
//        org.jfree.data.time.Day day71 = new org.jfree.data.time.Day();
//        java.lang.String str72 = day71.toString();
//        long long73 = day71.getFirstMillisecond();
//        boolean boolean74 = spreadsheetDate66.equals((java.lang.Object) long73);
//        boolean boolean75 = spreadsheetDate25.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate66);
//        int int76 = spreadsheetDate25.toSerial();
//        boolean boolean77 = spreadsheetDate14.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate25);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1900 + "'", int12 == 1900);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(serialDate28);
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertNotNull(serialDate32);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1900 + "'", int36 == 1900);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNotNull(serialDate42);
//        org.junit.Assert.assertNotNull(serialDate44);
//        org.junit.Assert.assertNotNull(serialDate45);
//        org.junit.Assert.assertNotNull(serialDate46);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1900 + "'", int48 == 1900);
//        org.junit.Assert.assertNotNull(date51);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertNotNull(serialDate54);
//        org.junit.Assert.assertNotNull(serialDate57);
//        org.junit.Assert.assertNotNull(serialDate59);
//        org.junit.Assert.assertNotNull(serialDate60);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
//        org.junit.Assert.assertNotNull(serialDate68);
//        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 3 + "'", int70 == 3);
//        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "10-June-2019" + "'", str72.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 1560150000000L + "'", long73 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
//        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
//        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 3 + "'", int76 == 3);
//        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
//    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10);
        java.lang.String str2 = seriesChangeEvent1.toString();
        java.lang.String str3 = seriesChangeEvent1.toString();
        java.lang.String str4 = seriesChangeEvent1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=10]" + "'", str2.equals("org.jfree.data.general.SeriesChangeEvent[source=10]"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=10]" + "'", str3.equals("org.jfree.data.general.SeriesChangeEvent[source=10]"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=10]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=10]"));
    }

//    @Test
//    public void test041() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test041");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        java.util.Date date4 = day3.getEnd();
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date4);
//        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(date4);
//        boolean boolean8 = day0.equals((java.lang.Object) serialDate7);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(12);
//        java.util.Date date11 = spreadsheetDate10.toDate();
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.addDays((int) (byte) 1, serialDate14);
//        boolean boolean16 = spreadsheetDate10.isAfter(serialDate15);
//        org.jfree.data.time.SerialDate serialDate17 = serialDate7.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate10);
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate10);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNotNull(serialDate17);
//    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        int int2 = spreadsheetDate1.getDayOfWeek();
        int int3 = spreadsheetDate1.getDayOfWeek();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(1900, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test044() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test044");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        int int3 = day0.compareTo((java.lang.Object) (-1L));
//        java.lang.Class class7 = null;
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class7);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.lang.String str10 = day9.toString();
//        timeSeries8.delete((org.jfree.data.time.RegularTimePeriod) day9);
//        timeSeries8.fireSeriesChanged();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.util.Date date14 = day13.getEnd();
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
//        java.lang.Number number16 = timeSeries8.getValue((org.jfree.data.time.RegularTimePeriod) month15);
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class20);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.lang.String str23 = day22.toString();
//        timeSeries21.delete((org.jfree.data.time.RegularTimePeriod) day22);
//        boolean boolean25 = timeSeries8.equals((java.lang.Object) day22);
//        boolean boolean26 = day0.equals((java.lang.Object) timeSeries8);
//        timeSeries8.setDomainDescription("ERROR : Relative To String");
//        java.lang.String str29 = timeSeries8.getRangeDescription();
//        java.lang.Class class30 = timeSeries8.getTimePeriodClass();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "10-June-2019" + "'", str23.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "hi!" + "'", str29.equals("hi!"));
//        org.junit.Assert.assertNull(class30);
//    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        java.lang.String str3 = month2.toString();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean5 = month2.equals((java.lang.Object) timeZone4);
        int int6 = month2.getMonth();
        long long7 = month2.getLastMillisecond();
        java.lang.String str8 = month2.toString();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1561964399999L + "'", long7 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "June 2019" + "'", str8.equals("June 2019"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(0, 7, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test048() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test048");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
//        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate7 = serialDate4.getEndOfCurrentMonth(serialDate6);
//        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(3);
//        boolean boolean11 = spreadsheetDate1.isInRange(serialDate6, (org.jfree.data.time.SerialDate) spreadsheetDate10);
//        int int12 = spreadsheetDate1.getYYYY();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(3);
//        boolean boolean15 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate14);
//        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate21 = serialDate18.getEndOfCurrentMonth(serialDate20);
//        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addDays(0, serialDate21);
//        boolean boolean23 = spreadsheetDate1.isOnOrBefore(serialDate21);
//        int int24 = spreadsheetDate1.getYYYY();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(12);
//        java.util.Date date27 = spreadsheetDate26.toDate();
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        java.util.Date date29 = day28.getEnd();
//        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.createInstance(date29);
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(serialDate30);
//        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate36 = serialDate33.getEndOfCurrentMonth(serialDate35);
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(serialDate33);
//        boolean boolean39 = spreadsheetDate26.isInRange(serialDate30, serialDate33, 0);
//        boolean boolean40 = spreadsheetDate1.isOn(serialDate33);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate(3);
//        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.createInstance(9);
//        boolean boolean45 = spreadsheetDate42.isOnOrAfter(serialDate44);
//        int int46 = spreadsheetDate42.getDayOfWeek();
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
//        java.lang.String str48 = day47.toString();
//        long long49 = day47.getFirstMillisecond();
//        boolean boolean50 = spreadsheetDate42.equals((java.lang.Object) long49);
//        boolean boolean51 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate42);
//        int int52 = spreadsheetDate1.toSerial();
//        try {
//            org.jfree.data.time.SerialDate serialDate54 = spreadsheetDate1.getNearestDayOfWeek(10);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1900 + "'", int12 == 1900);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1900 + "'", int24 == 1900);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertNotNull(serialDate33);
//        org.junit.Assert.assertNotNull(serialDate35);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertNotNull(serialDate44);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 3 + "'", int46 == 3);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "10-June-2019" + "'", str48.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1560150000000L + "'", long49 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 3 + "'", int52 == 3);
//    }

//    @Test
//    public void test049() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test049");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setMaximumItemCount((int) (byte) 0);
//        boolean boolean7 = timeSeries4.getNotify();
//        java.lang.Comparable comparable8 = timeSeries4.getKey();
//        java.beans.PropertyChangeListener propertyChangeListener9 = null;
//        timeSeries4.removePropertyChangeListener(propertyChangeListener9);
//        java.lang.Class<?> wildcardClass11 = timeSeries4.getClass();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        java.lang.String str13 = day12.toString();
//        java.util.Date date14 = day12.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(date14);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        java.lang.String str17 = day16.toString();
//        java.util.Date date18 = day16.getStart();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        java.lang.String str20 = day19.toString();
//        java.util.Date date21 = day19.getStart();
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date21);
//        java.lang.Class class26 = null;
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class26);
//        timeSeries27.setMaximumItemCount((int) (byte) 0);
//        boolean boolean30 = timeSeries27.getNotify();
//        java.util.List list31 = timeSeries27.getItems();
//        java.lang.Class class35 = null;
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class35);
//        timeSeries36.setMaximumItemCount((int) (byte) 0);
//        boolean boolean39 = timeSeries36.getNotify();
//        java.util.List list40 = timeSeries36.getItems();
//        java.util.Collection collection41 = timeSeries27.getTimePeriodsUniqueToOtherSeries(timeSeries36);
//        boolean boolean42 = timeSeries27.isEmpty();
//        timeSeries27.setDomainDescription("2019");
//        java.lang.Class<?> wildcardClass45 = timeSeries27.getClass();
//        java.util.Date date46 = null;
//        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass45, date46, timeZone47);
//        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day(date21, timeZone47);
//        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year(date18, timeZone47);
//        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day();
//        java.lang.String str52 = day51.toString();
//        java.util.Date date53 = day51.getStart();
//        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day();
//        java.lang.String str55 = day54.toString();
//        java.util.Date date56 = day54.getStart();
//        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year(date56);
//        java.lang.Class class61 = null;
//        org.jfree.data.time.TimeSeries timeSeries62 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class61);
//        timeSeries62.setMaximumItemCount((int) (byte) 0);
//        boolean boolean65 = timeSeries62.getNotify();
//        java.util.List list66 = timeSeries62.getItems();
//        java.lang.Class class70 = null;
//        org.jfree.data.time.TimeSeries timeSeries71 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class70);
//        timeSeries71.setMaximumItemCount((int) (byte) 0);
//        boolean boolean74 = timeSeries71.getNotify();
//        java.util.List list75 = timeSeries71.getItems();
//        java.util.Collection collection76 = timeSeries62.getTimePeriodsUniqueToOtherSeries(timeSeries71);
//        boolean boolean77 = timeSeries62.isEmpty();
//        timeSeries62.setDomainDescription("2019");
//        java.lang.Class<?> wildcardClass80 = timeSeries62.getClass();
//        java.util.Date date81 = null;
//        java.util.TimeZone timeZone82 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod83 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass80, date81, timeZone82);
//        org.jfree.data.time.Day day84 = new org.jfree.data.time.Day(date56, timeZone82);
//        org.jfree.data.time.Year year85 = new org.jfree.data.time.Year(date53, timeZone82);
//        org.jfree.data.time.Month month86 = new org.jfree.data.time.Month(date18, timeZone82);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod87 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date14, timeZone82);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0f) + "'", comparable8.equals((-1.0f)));
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "10-June-2019" + "'", str13.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "10-June-2019" + "'", str17.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "10-June-2019" + "'", str20.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
//        org.junit.Assert.assertNotNull(list31);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
//        org.junit.Assert.assertNotNull(list40);
//        org.junit.Assert.assertNotNull(collection41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
//        org.junit.Assert.assertNotNull(wildcardClass45);
//        org.junit.Assert.assertNotNull(timeZone47);
//        org.junit.Assert.assertNull(regularTimePeriod48);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "10-June-2019" + "'", str52.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "10-June-2019" + "'", str55.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
//        org.junit.Assert.assertNotNull(list66);
//        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
//        org.junit.Assert.assertNotNull(list75);
//        org.junit.Assert.assertNotNull(collection76);
//        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
//        org.junit.Assert.assertNotNull(wildcardClass80);
//        org.junit.Assert.assertNotNull(timeZone82);
//        org.junit.Assert.assertNull(regularTimePeriod83);
//        org.junit.Assert.assertNull(regularTimePeriod87);
//    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate5 = serialDate2.getEndOfCurrentMonth(serialDate4);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate4);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate6);
        java.lang.String str8 = serialDate6.getDescription();
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNull(str8);
    }

//    @Test
//    public void test051() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test051");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day5);
//        timeSeries4.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener9 = null;
//        timeSeries4.addPropertyChangeListener(propertyChangeListener9);
//        try {
//            timeSeries4.delete(100, (int) (short) 1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//    }

//    @Test
//    public void test052() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test052");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day5);
//        timeSeries4.fireSeriesChanged();
//        timeSeries4.removeAgedItems(false);
//        java.lang.Class class14 = null;
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class14);
//        timeSeries15.setMaximumItemCount((int) (byte) 0);
//        boolean boolean18 = timeSeries15.getNotify();
//        java.util.List list19 = timeSeries15.getItems();
//        java.lang.Class class23 = null;
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class23);
//        timeSeries24.setMaximumItemCount((int) (byte) 0);
//        boolean boolean27 = timeSeries24.getNotify();
//        java.util.List list28 = timeSeries24.getItems();
//        java.util.Collection collection29 = timeSeries15.getTimePeriodsUniqueToOtherSeries(timeSeries24);
//        boolean boolean30 = timeSeries15.isEmpty();
//        timeSeries15.setDomainDescription("2019");
//        java.lang.Class class36 = null;
//        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class36);
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
//        java.lang.String str39 = day38.toString();
//        timeSeries37.delete((org.jfree.data.time.RegularTimePeriod) day38);
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
//        java.util.Date date42 = day41.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond(date42);
//        java.util.Date date44 = fixedMillisecond43.getTime();
//        long long45 = fixedMillisecond43.getSerialIndex();
//        long long46 = fixedMillisecond43.getFirstMillisecond();
//        java.util.Calendar calendar47 = null;
//        long long48 = fixedMillisecond43.getMiddleMillisecond(calendar47);
//        org.jfree.data.time.TimeSeries timeSeries49 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) day38, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond43);
//        java.util.Collection collection50 = timeSeries15.getTimePeriods();
//        int int51 = timeSeries15.getMaximumItemCount();
//        java.util.Collection collection52 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries15);
//        timeSeries4.setDescription("Monday");
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertNotNull(list19);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//        org.junit.Assert.assertNotNull(list28);
//        org.junit.Assert.assertNotNull(collection29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "10-June-2019" + "'", str39.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1560236399999L + "'", long45 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1560236399999L + "'", long46 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1560236399999L + "'", long48 == 1560236399999L);
//        org.junit.Assert.assertNotNull(timeSeries49);
//        org.junit.Assert.assertNotNull(collection50);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
//        org.junit.Assert.assertNotNull(collection52);
//    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
        timeSeries4.setMaximumItemCount((int) (byte) 0);
        boolean boolean7 = timeSeries4.getNotify();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class11);
        timeSeries12.setDomainDescription("hi!");
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        java.util.Date date16 = day15.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day15, (java.lang.Number) 0);
        java.lang.Object obj19 = null;
        boolean boolean20 = timeSeries12.equals(obj19);
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries4.addAndOrUpdate(timeSeries12);
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener22);
        boolean boolean24 = timeSeries4.getNotify();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(timeSeries21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10);
        java.lang.String str2 = seriesChangeEvent1.toString();
        java.lang.Object obj3 = seriesChangeEvent1.getSource();
        java.lang.Object obj4 = seriesChangeEvent1.getSource();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=10]" + "'", str2.equals("org.jfree.data.general.SeriesChangeEvent[source=10]"));
        org.junit.Assert.assertTrue("'" + obj3 + "' != '" + 10 + "'", obj3.equals(10));
        org.junit.Assert.assertTrue("'" + obj4 + "' != '" + 10 + "'", obj4.equals(10));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
        timeSeries4.setMaximumItemCount((int) (byte) 0);
        boolean boolean7 = timeSeries4.getNotify();
        java.util.List list8 = timeSeries4.getItems();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class12);
        timeSeries13.setMaximumItemCount((int) (byte) 0);
        boolean boolean16 = timeSeries13.getNotify();
        java.util.List list17 = timeSeries13.getItems();
        java.util.Collection collection18 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        boolean boolean19 = timeSeries4.isEmpty();
        timeSeries4.setDomainDescription("2019");
        java.lang.Class<?> wildcardClass22 = timeSeries4.getClass();
        java.lang.Comparable comparable23 = timeSeries4.getKey();
        timeSeries4.fireSeriesChanged();
        timeSeries4.setMaximumItemAge(1560192233864L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(list17);
        org.junit.Assert.assertNotNull(collection18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertTrue("'" + comparable23 + "' != '" + (-1.0f) + "'", comparable23.equals((-1.0f)));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addDays((int) (byte) 1, serialDate5);
        boolean boolean7 = spreadsheetDate1.isAfter(serialDate6);
        int int8 = spreadsheetDate1.getYYYY();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1900 + "'", int8 == 1900);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        int int3 = day0.compareTo((java.lang.Object) (-1L));
        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
        int int6 = day0.compareTo((java.lang.Object) 0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

//    @Test
//    public void test058() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test058");
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        java.lang.String str2 = day1.toString();
//        java.util.Date date3 = day1.getStart();
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date3);
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3);
//        try {
//            org.jfree.data.time.Month month6 = new org.jfree.data.time.Month((int) (short) 0, year5);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10-June-2019" + "'", str2.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date3);
//    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((-460), (int) (byte) 1, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(9);
        boolean boolean4 = spreadsheetDate1.isOnOrAfter(serialDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate12 = serialDate9.getEndOfCurrentMonth(serialDate11);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean16 = spreadsheetDate6.isInRange(serialDate11, (org.jfree.data.time.SerialDate) spreadsheetDate15);
        int int17 = spreadsheetDate6.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean20 = spreadsheetDate6.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate26 = serialDate23.getEndOfCurrentMonth(serialDate25);
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.addDays(0, serialDate26);
        boolean boolean28 = spreadsheetDate6.isOnOrBefore(serialDate26);
        int int29 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate6);
        int int30 = spreadsheetDate6.getDayOfMonth();
        int int31 = spreadsheetDate6.toSerial();
        spreadsheetDate6.setDescription("January");
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1900 + "'", int17 == 1900);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2 + "'", int30 == 2);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 3 + "'", int31 == 3);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(9999);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year3.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

//    @Test
//    public void test063() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test063");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        int int3 = day0.compareTo((java.lang.Object) (-1L));
//        java.lang.Class class7 = null;
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class7);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.lang.String str10 = day9.toString();
//        timeSeries8.delete((org.jfree.data.time.RegularTimePeriod) day9);
//        timeSeries8.fireSeriesChanged();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.util.Date date14 = day13.getEnd();
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
//        java.lang.Number number16 = timeSeries8.getValue((org.jfree.data.time.RegularTimePeriod) month15);
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class20);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.lang.String str23 = day22.toString();
//        timeSeries21.delete((org.jfree.data.time.RegularTimePeriod) day22);
//        boolean boolean25 = timeSeries8.equals((java.lang.Object) day22);
//        boolean boolean26 = day0.equals((java.lang.Object) timeSeries8);
//        timeSeries8.setDomainDescription("ERROR : Relative To String");
//        timeSeries8.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
//        long long31 = timeSeries8.getMaximumItemAge();
//        java.util.List list32 = timeSeries8.getItems();
//        timeSeries8.setMaximumItemCount(0);
//        try {
//            org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = timeSeries8.getNextTimePeriod();
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "10-June-2019" + "'", str23.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 9223372036854775807L + "'", long31 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(list32);
//    }

//    @Test
//    public void test064() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test064");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class6);
//        timeSeries7.setMaximumItemCount((int) (byte) 0);
//        boolean boolean10 = timeSeries7.getNotify();
//        java.util.List list11 = timeSeries7.getItems();
//        java.lang.Class class15 = null;
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class15);
//        timeSeries16.setMaximumItemCount((int) (byte) 0);
//        boolean boolean19 = timeSeries16.getNotify();
//        java.util.List list20 = timeSeries16.getItems();
//        java.util.Collection collection21 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries16);
//        boolean boolean22 = timeSeries7.isEmpty();
//        timeSeries7.setDomainDescription("2019");
//        java.lang.Class<?> wildcardClass25 = timeSeries7.getClass();
//        java.util.Date date26 = null;
//        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date26, timeZone27);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date1, timeZone27);
//        int int31 = day29.compareTo((java.lang.Object) "");
//        org.jfree.data.time.SerialDate serialDate32 = day29.getSerialDate();
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        java.lang.String str34 = day33.toString();
//        java.util.Date date35 = day33.getStart();
//        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(date35);
//        long long37 = year36.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year36, (java.lang.Number) 100.0f);
//        java.lang.Class class43 = null;
//        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class43);
//        timeSeries44.setMaximumItemCount((int) (byte) 0);
//        boolean boolean47 = timeSeries44.getNotify();
//        timeSeries44.setKey((java.lang.Comparable) 10.0d);
//        java.lang.Class<?> wildcardClass50 = timeSeries44.getClass();
//        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day();
//        java.lang.String str52 = day51.toString();
//        java.util.Date date53 = day51.getStart();
//        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year(date53);
//        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day();
//        java.util.Date date56 = day55.getEnd();
//        org.jfree.data.time.Month month57 = new org.jfree.data.time.Month(date56);
//        java.lang.String str58 = month57.toString();
//        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean60 = month57.equals((java.lang.Object) timeZone59);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass50, date53, timeZone59);
//        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day();
//        java.util.Date date63 = day62.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond64 = new org.jfree.data.time.FixedMillisecond(date63);
//        java.util.Date date65 = fixedMillisecond64.getTime();
//        org.jfree.data.time.Day day66 = new org.jfree.data.time.Day();
//        java.util.Date date67 = day66.getEnd();
//        org.jfree.data.time.Month month68 = new org.jfree.data.time.Month(date67);
//        java.lang.String str69 = month68.toString();
//        java.util.TimeZone timeZone70 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean71 = month68.equals((java.lang.Object) timeZone70);
//        org.jfree.data.time.Day day72 = new org.jfree.data.time.Day(date65, timeZone70);
//        org.jfree.data.time.Month month73 = new org.jfree.data.time.Month(date53, timeZone70);
//        int int74 = timeSeriesDataItem39.compareTo((java.lang.Object) timeZone70);
//        boolean boolean75 = day29.equals((java.lang.Object) timeZone70);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertNotNull(list11);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertNotNull(list20);
//        org.junit.Assert.assertNotNull(collection21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertNotNull(wildcardClass25);
//        org.junit.Assert.assertNotNull(timeZone27);
//        org.junit.Assert.assertNull(regularTimePeriod28);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
//        org.junit.Assert.assertNotNull(serialDate32);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "10-June-2019" + "'", str34.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1577865599999L + "'", long37 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
//        org.junit.Assert.assertNotNull(wildcardClass50);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "10-June-2019" + "'", str52.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "June 2019" + "'", str58.equals("June 2019"));
//        org.junit.Assert.assertNotNull(timeZone59);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//        org.junit.Assert.assertNull(regularTimePeriod61);
//        org.junit.Assert.assertNotNull(date63);
//        org.junit.Assert.assertNotNull(date65);
//        org.junit.Assert.assertNotNull(date67);
//        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "June 2019" + "'", str69.equals("June 2019"));
//        org.junit.Assert.assertNotNull(timeZone70);
//        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
//        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 1 + "'", int74 == 1);
//        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
//    }

//    @Test
//    public void test065() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test065");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
//        java.util.Date date3 = fixedMillisecond2.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond2.previous();
//        long long5 = fixedMillisecond2.getLastMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560236399999L + "'", long5 == 1560236399999L);
//    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) '#', 2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (short) 1, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test068() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test068");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day5);
//        timeSeries4.fireSeriesChanged();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.util.Date date10 = day9.getEnd();
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
//        java.lang.Number number12 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month11);
//        java.lang.Class class13 = null;
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month11, class13);
//        try {
//            timeSeries14.delete((int) (byte) 1, (int) (byte) 1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNull(number12);
//    }

//    @Test
//    public void test069() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test069");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
//        java.lang.String str3 = month2.toString();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean5 = month2.equals((java.lang.Object) timeZone4);
//        int int6 = month2.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month2.previous();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.util.Date date9 = day8.getEnd();
//        int int11 = day8.compareTo((java.lang.Object) (-1L));
//        java.lang.Class class15 = null;
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class15);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        java.lang.String str18 = day17.toString();
//        timeSeries16.delete((org.jfree.data.time.RegularTimePeriod) day17);
//        timeSeries16.fireSeriesChanged();
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        java.util.Date date22 = day21.getEnd();
//        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(date22);
//        java.lang.Number number24 = timeSeries16.getValue((org.jfree.data.time.RegularTimePeriod) month23);
//        java.lang.Class class28 = null;
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class28);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        java.lang.String str31 = day30.toString();
//        timeSeries29.delete((org.jfree.data.time.RegularTimePeriod) day30);
//        boolean boolean33 = timeSeries16.equals((java.lang.Object) day30);
//        boolean boolean34 = day8.equals((java.lang.Object) timeSeries16);
//        timeSeries16.setDomainDescription("ERROR : Relative To String");
//        java.lang.String str37 = timeSeries16.getRangeDescription();
//        boolean boolean38 = month2.equals((java.lang.Object) str37);
//        org.jfree.data.time.Year year39 = month2.getYear();
//        java.lang.String str40 = month2.toString();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "10-June-2019" + "'", str18.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNull(number24);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "10-June-2019" + "'", str31.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "hi!" + "'", str37.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(year39);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "June 2019" + "'", str40.equals("June 2019"));
//    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        java.lang.String str3 = month2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (double) (short) 100);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        java.util.Date date8 = day7.getEnd();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date8);
        java.lang.String str10 = month9.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month9, (double) (short) 100);
        int int14 = timeSeriesDataItem6.compareTo((java.lang.Object) month9);
        timeSeriesDataItem6.setValue((java.lang.Number) 6);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate22 = serialDate19.getEndOfCurrentMonth(serialDate21);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate21);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(serialDate23);
        boolean boolean25 = timeSeriesDataItem6.equals((java.lang.Object) serialDate23);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = timeSeriesDataItem6.getPeriod();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem6);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "June 2019" + "'", str10.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((-457));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date1);
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year4.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(100, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test074() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test074");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setMaximumItemCount((int) (byte) 0);
//        boolean boolean7 = timeSeries4.getNotify();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class11);
//        timeSeries12.setDomainDescription("hi!");
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        java.util.Date date16 = day15.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day15, (java.lang.Number) 0);
//        java.lang.Object obj19 = null;
//        boolean boolean20 = timeSeries12.equals(obj19);
//        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries4.addAndOrUpdate(timeSeries12);
//        timeSeries21.setNotify(true);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        java.util.Date date25 = day24.getEnd();
//        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(date25);
//        java.lang.String str27 = month26.toString();
//        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean29 = month26.equals((java.lang.Object) timeZone28);
//        int int30 = month26.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = month26.previous();
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        java.util.Date date33 = day32.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond(date33);
//        java.util.Date date35 = fixedMillisecond34.getTime();
//        long long36 = fixedMillisecond34.getSerialIndex();
//        long long37 = fixedMillisecond34.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries21.createCopy((org.jfree.data.time.RegularTimePeriod) month26, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day();
//        java.util.Date date40 = day39.getEnd();
//        boolean boolean41 = month26.equals((java.lang.Object) date40);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNull(timeSeriesDataItem18);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(timeSeries21);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "June 2019" + "'", str27.equals("June 2019"));
//        org.junit.Assert.assertNotNull(timeZone28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560236399999L + "'", long36 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560236399999L + "'", long37 == 1560236399999L);
//        org.junit.Assert.assertNotNull(timeSeries38);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7, "10-June-2019", "ERROR : Relative To String", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        int int7 = timeSeries4.getItemCount();
        java.lang.Comparable comparable8 = timeSeries4.getKey();
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 7 + "'", comparable8.equals(7));
    }

//    @Test
//    public void test076() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test076");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day5);
//        timeSeries4.fireSeriesChanged();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.util.Date date10 = day9.getEnd();
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
//        java.lang.Number number12 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month11);
//        java.lang.Class class16 = null;
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class16);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        java.lang.String str19 = day18.toString();
//        timeSeries17.delete((org.jfree.data.time.RegularTimePeriod) day18);
//        boolean boolean21 = timeSeries4.equals((java.lang.Object) day18);
//        try {
//            timeSeries4.delete(11, 8);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNull(number12);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "10-June-2019" + "'", str19.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(9);
        boolean boolean4 = spreadsheetDate1.isOnOrAfter(serialDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate12 = serialDate9.getEndOfCurrentMonth(serialDate11);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean16 = spreadsheetDate6.isInRange(serialDate11, (org.jfree.data.time.SerialDate) spreadsheetDate15);
        int int17 = spreadsheetDate6.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean20 = spreadsheetDate6.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate26 = serialDate23.getEndOfCurrentMonth(serialDate25);
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.addDays(0, serialDate26);
        boolean boolean28 = spreadsheetDate6.isOnOrBefore(serialDate26);
        int int29 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate6);
        int int30 = spreadsheetDate6.getDayOfMonth();
        spreadsheetDate6.setDescription("Overwritten values from: -1.0");
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1900 + "'", int17 == 1900);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2 + "'", int30 == 2);
    }

//    @Test
//    public void test078() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test078");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getFirstMillisecond();
//        long long3 = day0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560236399999L + "'", long3 == 1560236399999L);
//    }

//    @Test
//    public void test079() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test079");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
//        java.util.Date date3 = fixedMillisecond2.getTime();
//        long long4 = fixedMillisecond2.getSerialIndex();
//        long long5 = fixedMillisecond2.getFirstMillisecond();
//        long long6 = fixedMillisecond2.getFirstMillisecond();
//        long long7 = fixedMillisecond2.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond2.previous();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560236399999L + "'", long5 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560236399999L + "'", long6 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560236399999L + "'", long7 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//    }

//    @Test
//    public void test080() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test080");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
//        java.util.Date date3 = fixedMillisecond2.getTime();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.String str5 = day4.toString();
//        java.util.Date date6 = day4.getStart();
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class11);
//        timeSeries12.setMaximumItemCount((int) (byte) 0);
//        boolean boolean15 = timeSeries12.getNotify();
//        java.util.List list16 = timeSeries12.getItems();
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class20);
//        timeSeries21.setMaximumItemCount((int) (byte) 0);
//        boolean boolean24 = timeSeries21.getNotify();
//        java.util.List list25 = timeSeries21.getItems();
//        java.util.Collection collection26 = timeSeries12.getTimePeriodsUniqueToOtherSeries(timeSeries21);
//        boolean boolean27 = timeSeries12.isEmpty();
//        timeSeries12.setDomainDescription("2019");
//        java.lang.Class<?> wildcardClass30 = timeSeries12.getClass();
//        java.util.Date date31 = null;
//        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date31, timeZone32);
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date6, timeZone32);
//        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(date3, timeZone32);
//        java.lang.String str36 = month35.toString();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10-June-2019" + "'", str5.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertNotNull(list16);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//        org.junit.Assert.assertNotNull(list25);
//        org.junit.Assert.assertNotNull(collection26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertNotNull(timeZone32);
//        org.junit.Assert.assertNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "June 2019" + "'", str36.equals("June 2019"));
//    }

//    @Test
//    public void test081() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test081");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
//        java.util.Date date3 = fixedMillisecond2.getTime();
//        long long4 = fixedMillisecond2.getSerialIndex();
//        long long5 = fixedMillisecond2.getFirstMillisecond();
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond2.getMiddleMillisecond(calendar6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond2.next();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.lang.String str10 = day9.toString();
//        java.util.Date date11 = day9.getStart();
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
//        boolean boolean13 = fixedMillisecond2.equals((java.lang.Object) year12);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560236399999L + "'", long5 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560236399999L + "'", long7 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//    }

//    @Test
//    public void test082() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test082");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day5);
//        timeSeries4.fireSeriesChanged();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.util.Date date10 = day9.getEnd();
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
//        java.lang.Number number12 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month11);
//        java.lang.String str13 = month11.toString();
//        long long14 = month11.getSerialIndex();
//        long long15 = month11.getFirstMillisecond();
//        int int16 = month11.getYearValue();
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNull(number12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "June 2019" + "'", str13.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 24234L + "'", long14 == 24234L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1559372400000L + "'", long15 == 1559372400000L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Calendar calendar1 = null;
        try {
            month0.peg(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
        timeSeries4.setMaximumItemCount((int) (byte) 0);
        boolean boolean7 = timeSeries4.getNotify();
        java.lang.Comparable comparable8 = timeSeries4.getKey();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener9);
        timeSeries4.setMaximumItemCount(11);
        timeSeries4.fireSeriesChanged();
        timeSeries4.removeAgedItems(true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0f) + "'", comparable8.equals((-1.0f)));
    }

//    @Test
//    public void test085() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test085");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setDomainDescription("hi!");
//        java.lang.Object obj7 = timeSeries4.clone();
//        java.lang.String str8 = timeSeries4.getDescription();
//        timeSeries4.setMaximumItemAge((long) 9999);
//        java.lang.Class class14 = null;
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class14);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        java.lang.String str17 = day16.toString();
//        timeSeries15.delete((org.jfree.data.time.RegularTimePeriod) day16);
//        timeSeries15.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener20 = null;
//        timeSeries15.addPropertyChangeListener(propertyChangeListener20);
//        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries4.addAndOrUpdate(timeSeries15);
//        try {
//            org.jfree.data.time.TimeSeries timeSeries25 = timeSeries15.createCopy(13, (int) (short) 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(obj7);
//        org.junit.Assert.assertNull(str8);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "10-June-2019" + "'", str17.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(timeSeries22);
//    }

//    @Test
//    public void test086() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test086");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setDomainDescription("hi!");
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        java.util.Date date8 = day7.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) 0);
//        timeSeries4.setDescription("");
//        timeSeries4.setNotify(true);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        java.lang.String str16 = day15.toString();
//        java.util.Date date17 = day15.getStart();
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date17);
//        java.lang.Object obj19 = null;
//        int int20 = year18.compareTo(obj19);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) year18);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.util.Date date23 = day22.getEnd();
//        int int25 = day22.compareTo((java.lang.Object) (-1L));
//        java.lang.Class class29 = null;
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class29);
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        java.lang.String str32 = day31.toString();
//        timeSeries30.delete((org.jfree.data.time.RegularTimePeriod) day31);
//        timeSeries30.fireSeriesChanged();
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        java.util.Date date36 = day35.getEnd();
//        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month(date36);
//        java.lang.Number number38 = timeSeries30.getValue((org.jfree.data.time.RegularTimePeriod) month37);
//        java.lang.Class class42 = null;
//        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class42);
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day();
//        java.lang.String str45 = day44.toString();
//        timeSeries43.delete((org.jfree.data.time.RegularTimePeriod) day44);
//        boolean boolean47 = timeSeries30.equals((java.lang.Object) day44);
//        boolean boolean48 = day22.equals((java.lang.Object) timeSeries30);
//        timeSeries30.setDomainDescription("ERROR : Relative To String");
//        timeSeries30.removeAgedItems(false);
//        java.lang.Comparable comparable53 = timeSeries30.getKey();
//        timeSeries30.setDescription("");
//        boolean boolean56 = timeSeriesDataItem21.equals((java.lang.Object) "");
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(timeSeriesDataItem10);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "10-June-2019" + "'", str16.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem21);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "10-June-2019" + "'", str32.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNull(number38);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "10-June-2019" + "'", str45.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertTrue("'" + comparable53 + "' != '" + (-1.0f) + "'", comparable53.equals((-1.0f)));
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//    }

//    @Test
//    public void test087() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test087");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day5);
//        timeSeries4.fireSeriesChanged();
//        java.lang.String str9 = timeSeries4.getDomainDescription();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        java.util.Date date11 = day10.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond(date11);
//        java.util.Date date13 = fixedMillisecond12.getTime();
//        long long14 = fixedMillisecond12.getSerialIndex();
//        long long15 = fixedMillisecond12.getFirstMillisecond();
//        java.util.Calendar calendar16 = null;
//        long long17 = fixedMillisecond12.getFirstMillisecond(calendar16);
//        try {
//            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (double) (short) 10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560236399999L + "'", long14 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560236399999L + "'", long15 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560236399999L + "'", long17 == 1560236399999L);
//    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class6);
        timeSeries7.setMaximumItemCount((int) (byte) 0);
        boolean boolean10 = timeSeries7.getNotify();
        java.util.List list11 = timeSeries7.getItems();
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class15);
        timeSeries16.setMaximumItemCount((int) (byte) 0);
        boolean boolean19 = timeSeries16.getNotify();
        java.util.List list20 = timeSeries16.getItems();
        java.util.Collection collection21 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries16);
        boolean boolean22 = timeSeries7.isEmpty();
        timeSeries7.setDomainDescription("2019");
        java.lang.Class<?> wildcardClass25 = timeSeries7.getClass();
        java.util.Date date26 = null;
        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date26, timeZone27);
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date1, timeZone27);
        int int30 = day29.getMonth();
        java.util.Calendar calendar31 = null;
        try {
            long long32 = day29.getFirstMillisecond(calendar31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertNotNull(collection21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 6 + "'", int30 == 6);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(3);
        int int3 = spreadsheetDate2.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate11 = serialDate8.getEndOfCurrentMonth(serialDate10);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean15 = spreadsheetDate5.isInRange(serialDate10, (org.jfree.data.time.SerialDate) spreadsheetDate14);
        int int16 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate24 = serialDate21.getEndOfCurrentMonth(serialDate23);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate23);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean28 = spreadsheetDate18.isInRange(serialDate23, (org.jfree.data.time.SerialDate) spreadsheetDate27);
        boolean boolean29 = spreadsheetDate2.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate27);
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
        java.util.Date date31 = day30.getEnd();
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(date31);
        java.lang.String str33 = month32.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = month32.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month32, (double) (short) 100);
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
        java.util.Date date38 = day37.getEnd();
        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month(date38);
        java.lang.String str40 = month39.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = month39.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month39, (double) (short) 100);
        int int44 = timeSeriesDataItem36.compareTo((java.lang.Object) month39);
        timeSeriesDataItem36.setValue((java.lang.Number) 6);
        java.lang.Object obj47 = new java.lang.Object();
        int int48 = timeSeriesDataItem36.compareTo(obj47);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = timeSeriesDataItem36.getPeriod();
        boolean boolean50 = spreadsheetDate27.equals((java.lang.Object) timeSeriesDataItem36);
        int int51 = year0.compareTo((java.lang.Object) spreadsheetDate27);
        int int52 = spreadsheetDate27.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate54 = new org.jfree.data.time.SpreadsheetDate(3);
        int int55 = spreadsheetDate54.getYYYY();
        boolean boolean56 = spreadsheetDate27.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate54);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1900 + "'", int3 == 1900);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "June 2019" + "'", str33.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "June 2019" + "'", str40.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 2 + "'", int52 == 2);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1900 + "'", int55 == 1900);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        java.lang.String str3 = month2.toString();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean5 = month2.equals((java.lang.Object) timeZone4);
        int int6 = month2.getYearValue();
        long long7 = month2.getSerialIndex();
        int int8 = month2.getYearValue();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 24234L + "'", long7 == 24234L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
    }

//    @Test
//    public void test091() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test091");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day5);
//        timeSeries4.fireSeriesChanged();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.util.Date date10 = day9.getEnd();
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
//        java.lang.Number number12 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month11);
//        java.lang.String str13 = month11.toString();
//        long long14 = month11.getSerialIndex();
//        java.lang.String str15 = month11.toString();
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNull(number12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "June 2019" + "'", str13.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 24234L + "'", long14 == 24234L);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "June 2019" + "'", str15.equals("June 2019"));
//    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        int int2 = spreadsheetDate1.toSerial();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class6);
        timeSeries7.setMaximumItemCount((int) (byte) 0);
        boolean boolean10 = timeSeries7.getNotify();
        java.util.List list11 = timeSeries7.getItems();
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class15);
        timeSeries16.setMaximumItemCount((int) (byte) 0);
        boolean boolean19 = timeSeries16.getNotify();
        java.util.List list20 = timeSeries16.getItems();
        java.util.Collection collection21 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries16);
        boolean boolean22 = timeSeries7.isEmpty();
        timeSeries7.setDomainDescription("2019");
        java.lang.Class<?> wildcardClass25 = timeSeries7.getClass();
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate1, (java.lang.Class) wildcardClass25);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertNotNull(collection21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(wildcardClass25);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) '4', 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 52");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("June 2019");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

//    @Test
//    public void test095() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test095");
//        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate5 = serialDate2.getEndOfCurrentMonth(serialDate4);
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate4);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(3);
//        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(9);
//        boolean boolean12 = spreadsheetDate9.isOnOrAfter(serialDate11);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(3);
//        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate20 = serialDate17.getEndOfCurrentMonth(serialDate19);
//        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate19);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(3);
//        boolean boolean24 = spreadsheetDate14.isInRange(serialDate19, (org.jfree.data.time.SerialDate) spreadsheetDate23);
//        int int25 = spreadsheetDate14.getYYYY();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(3);
//        boolean boolean28 = spreadsheetDate14.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate27);
//        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate34 = serialDate31.getEndOfCurrentMonth(serialDate33);
//        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.addDays(0, serialDate34);
//        boolean boolean36 = spreadsheetDate14.isOnOrBefore(serialDate34);
//        int int37 = spreadsheetDate9.compare((org.jfree.data.time.SerialDate) spreadsheetDate14);
//        org.jfree.data.time.SerialDate serialDate38 = serialDate6.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate14);
//        java.util.Date date39 = spreadsheetDate14.toDate();
//        java.lang.Class class43 = null;
//        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class43);
//        timeSeries44.setMaximumItemCount((int) (byte) 0);
//        boolean boolean47 = timeSeries44.getNotify();
//        timeSeries44.setKey((java.lang.Comparable) 10.0d);
//        java.lang.Class<?> wildcardClass50 = timeSeries44.getClass();
//        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day();
//        java.lang.String str52 = day51.toString();
//        java.util.Date date53 = day51.getStart();
//        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year(date53);
//        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day();
//        java.util.Date date56 = day55.getEnd();
//        org.jfree.data.time.Month month57 = new org.jfree.data.time.Month(date56);
//        java.lang.String str58 = month57.toString();
//        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean60 = month57.equals((java.lang.Object) timeZone59);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass50, date53, timeZone59);
//        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day();
//        java.util.Date date63 = day62.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond64 = new org.jfree.data.time.FixedMillisecond(date63);
//        java.util.Date date65 = fixedMillisecond64.getTime();
//        org.jfree.data.time.Day day66 = new org.jfree.data.time.Day();
//        java.util.Date date67 = day66.getEnd();
//        org.jfree.data.time.Month month68 = new org.jfree.data.time.Month(date67);
//        java.lang.String str69 = month68.toString();
//        java.util.TimeZone timeZone70 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean71 = month68.equals((java.lang.Object) timeZone70);
//        org.jfree.data.time.Day day72 = new org.jfree.data.time.Day(date65, timeZone70);
//        org.jfree.data.time.Month month73 = new org.jfree.data.time.Month(date53, timeZone70);
//        org.jfree.data.time.Year year74 = new org.jfree.data.time.Year(date39, timeZone70);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1900 + "'", int25 == 1900);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertNotNull(serialDate33);
//        org.junit.Assert.assertNotNull(serialDate34);
//        org.junit.Assert.assertNotNull(serialDate35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertNotNull(serialDate38);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
//        org.junit.Assert.assertNotNull(wildcardClass50);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "10-June-2019" + "'", str52.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "June 2019" + "'", str58.equals("June 2019"));
//        org.junit.Assert.assertNotNull(timeZone59);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//        org.junit.Assert.assertNull(regularTimePeriod61);
//        org.junit.Assert.assertNotNull(date63);
//        org.junit.Assert.assertNotNull(date65);
//        org.junit.Assert.assertNotNull(date67);
//        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "June 2019" + "'", str69.equals("June 2019"));
//        org.junit.Assert.assertNotNull(timeZone70);
//        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
//    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        java.lang.String str3 = month2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        long long5 = month2.getSerialIndex();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = month2.getMiddleMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 24234L + "'", long5 == 24234L);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate7 = serialDate4.getEndOfCurrentMonth(serialDate6);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean11 = spreadsheetDate1.isInRange(serialDate6, (org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SerialDate serialDate13 = serialDate6.getPreviousDayOfWeek(7);
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate6, class14);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(serialDate13);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10);
        java.lang.String str2 = seriesChangeEvent1.toString();
        java.lang.Object obj3 = seriesChangeEvent1.getSource();
        java.lang.String str4 = seriesChangeEvent1.toString();
        java.lang.String str5 = seriesChangeEvent1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=10]" + "'", str2.equals("org.jfree.data.general.SeriesChangeEvent[source=10]"));
        org.junit.Assert.assertTrue("'" + obj3 + "' != '" + 10 + "'", obj3.equals(10));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=10]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=10]"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=10]" + "'", str5.equals("org.jfree.data.general.SeriesChangeEvent[source=10]"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
        timeSeries4.setMaximumItemCount((int) (byte) 0);
        boolean boolean7 = timeSeries4.getNotify();
        java.util.List list8 = timeSeries4.getItems();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class12);
        timeSeries13.setMaximumItemCount((int) (byte) 0);
        boolean boolean16 = timeSeries13.getNotify();
        java.util.List list17 = timeSeries13.getItems();
        java.util.Collection collection18 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        boolean boolean19 = timeSeries4.isEmpty();
        timeSeries4.setDomainDescription("2019");
        java.lang.Class<?> wildcardClass22 = timeSeries4.getClass();
        try {
            timeSeries4.removeAgedItems((long) 'a', false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(list17);
        org.junit.Assert.assertNotNull(collection18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(wildcardClass22);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
        java.util.Date date3 = fixedMillisecond2.getTime();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getEnd();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date5);
        java.lang.String str7 = month6.toString();
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean9 = month6.equals((java.lang.Object) timeZone8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date3, timeZone8);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (java.lang.Number) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = timeSeriesDataItem14.getPeriod();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "June 2019" + "'", str7.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
    }

//    @Test
//    public void test101() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test101");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
//        java.lang.String str3 = month2.toString();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean5 = month2.equals((java.lang.Object) timeZone4);
//        int int6 = month2.getMonth();
//        long long7 = month2.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month2.next();
//        java.util.Date date9 = month2.getStart();
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        java.lang.String str12 = day11.toString();
//        long long13 = day11.getLastMillisecond();
//        int int14 = day11.getYear();
//        int int15 = year10.compareTo((java.lang.Object) int14);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1561964399999L + "'", long7 == 1561964399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10-June-2019" + "'", str12.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560236399999L + "'", long13 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//    }

//    @Test
//    public void test102() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test102");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
//        java.lang.String str3 = month2.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (double) (short) 100);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        java.util.Date date8 = day7.getEnd();
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date8);
//        java.lang.String str10 = month9.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month9, (double) (short) 100);
//        int int14 = timeSeriesDataItem6.compareTo((java.lang.Object) month9);
//        timeSeriesDataItem6.setValue((java.lang.Number) 100);
//        java.lang.Number number17 = timeSeriesDataItem6.getValue();
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        java.util.Date date19 = day18.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond(date19);
//        java.util.Date date21 = fixedMillisecond20.getTime();
//        int int23 = fixedMillisecond20.compareTo((java.lang.Object) "June 2019");
//        long long24 = fixedMillisecond20.getLastMillisecond();
//        long long25 = fixedMillisecond20.getLastMillisecond();
//        boolean boolean26 = timeSeriesDataItem6.equals((java.lang.Object) long25);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = timeSeriesDataItem6.getPeriod();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "June 2019" + "'", str10.equals("June 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 100 + "'", number17.equals(100));
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560236399999L + "'", long24 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560236399999L + "'", long25 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class6);
        timeSeries7.setMaximumItemCount((int) (byte) 0);
        boolean boolean10 = timeSeries7.getNotify();
        java.util.List list11 = timeSeries7.getItems();
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class15);
        timeSeries16.setMaximumItemCount((int) (byte) 0);
        boolean boolean19 = timeSeries16.getNotify();
        java.util.List list20 = timeSeries16.getItems();
        java.util.Collection collection21 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries16);
        boolean boolean22 = timeSeries7.isEmpty();
        timeSeries7.setDomainDescription("2019");
        java.lang.Class<?> wildcardClass25 = timeSeries7.getClass();
        java.util.Date date26 = null;
        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date26, timeZone27);
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date1, timeZone27);
        java.util.TimeZone timeZone30 = null;
        try {
            org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date1, timeZone30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertNotNull(collection21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertNull(regularTimePeriod28);
    }

//    @Test
//    public void test104() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test104");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day5);
//        java.lang.String str8 = timeSeries4.getRangeDescription();
//        java.lang.Class<?> wildcardClass9 = timeSeries4.getClass();
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
//        org.junit.Assert.assertNotNull(wildcardClass9);
//    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(9);
        boolean boolean4 = spreadsheetDate1.isOnOrAfter(serialDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate12 = serialDate9.getEndOfCurrentMonth(serialDate11);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean16 = spreadsheetDate6.isInRange(serialDate11, (org.jfree.data.time.SerialDate) spreadsheetDate15);
        int int17 = spreadsheetDate6.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean20 = spreadsheetDate6.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate26 = serialDate23.getEndOfCurrentMonth(serialDate25);
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate25);
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(serialDate27);
        serialDate27.setDescription("January");
        boolean boolean31 = spreadsheetDate6.isOnOrBefore(serialDate27);
        boolean boolean32 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate42 = serialDate39.getEndOfCurrentMonth(serialDate41);
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate41);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean46 = spreadsheetDate36.isInRange(serialDate41, (org.jfree.data.time.SerialDate) spreadsheetDate45);
        int int47 = spreadsheetDate36.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate49 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean50 = spreadsheetDate36.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate49);
        org.jfree.data.time.SerialDate serialDate53 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate55 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate56 = serialDate53.getEndOfCurrentMonth(serialDate55);
        org.jfree.data.time.SerialDate serialDate57 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate55);
        boolean boolean58 = spreadsheetDate49.isOnOrAfter(serialDate55);
        org.jfree.data.time.SerialDate serialDate59 = org.jfree.data.time.SerialDate.addYears(0, (org.jfree.data.time.SerialDate) spreadsheetDate49);
        org.jfree.data.time.SerialDate serialDate60 = org.jfree.data.time.SerialDate.addDays(10, (org.jfree.data.time.SerialDate) spreadsheetDate49);
        boolean boolean61 = spreadsheetDate6.isOnOrBefore(serialDate60);
        int int62 = spreadsheetDate6.getDayOfMonth();
        try {
            org.jfree.data.time.SerialDate serialDate64 = spreadsheetDate6.getPreviousDayOfWeek(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1900 + "'", int17 == 1900);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1900 + "'", int47 == 1900);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(serialDate53);
        org.junit.Assert.assertNotNull(serialDate55);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(serialDate59);
        org.junit.Assert.assertNotNull(serialDate60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 2 + "'", int62 == 2);
    }

//    @Test
//    public void test106() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test106");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setMaximumItemCount((int) (byte) 0);
//        boolean boolean7 = timeSeries4.getNotify();
//        java.util.List list8 = timeSeries4.getItems();
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class12);
//        timeSeries13.setMaximumItemCount((int) (byte) 0);
//        boolean boolean16 = timeSeries13.getNotify();
//        java.util.List list17 = timeSeries13.getItems();
//        java.util.Collection collection18 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries13);
//        boolean boolean19 = timeSeries4.isEmpty();
//        timeSeries4.setDomainDescription("2019");
//        java.lang.Class<?> wildcardClass22 = timeSeries4.getClass();
//        java.lang.Class class23 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass22);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        java.util.Date date25 = day24.getEnd();
//        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(date25);
//        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date25);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond(date25);
//        java.lang.Class class32 = null;
//        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class32);
//        timeSeries33.setMaximumItemCount((int) (byte) 0);
//        boolean boolean36 = timeSeries33.getNotify();
//        timeSeries33.setKey((java.lang.Comparable) 10.0d);
//        java.lang.Class<?> wildcardClass39 = timeSeries33.getClass();
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day();
//        java.lang.String str41 = day40.toString();
//        java.util.Date date42 = day40.getStart();
//        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year(date42);
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day();
//        java.util.Date date45 = day44.getEnd();
//        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month(date45);
//        java.lang.String str47 = month46.toString();
//        java.util.TimeZone timeZone48 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean49 = month46.equals((java.lang.Object) timeZone48);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass39, date42, timeZone48);
//        java.lang.Class class51 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass39);
//        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day();
//        java.util.Date date53 = day52.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond(date53);
//        java.util.Date date55 = fixedMillisecond54.getTime();
//        java.lang.Class class59 = null;
//        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class59);
//        timeSeries60.setMaximumItemCount((int) (byte) 0);
//        boolean boolean63 = timeSeries60.getNotify();
//        timeSeries60.setKey((java.lang.Comparable) 10.0d);
//        java.lang.Class<?> wildcardClass66 = timeSeries60.getClass();
//        org.jfree.data.time.Day day67 = new org.jfree.data.time.Day();
//        java.lang.String str68 = day67.toString();
//        java.util.Date date69 = day67.getStart();
//        org.jfree.data.time.Year year70 = new org.jfree.data.time.Year(date69);
//        org.jfree.data.time.Day day71 = new org.jfree.data.time.Day();
//        java.util.Date date72 = day71.getEnd();
//        org.jfree.data.time.Month month73 = new org.jfree.data.time.Month(date72);
//        java.lang.String str74 = month73.toString();
//        java.util.TimeZone timeZone75 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean76 = month73.equals((java.lang.Object) timeZone75);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass66, date69, timeZone75);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass39, date55, timeZone75);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass22, date25, timeZone75);
//        org.jfree.data.time.SerialDate serialDate80 = org.jfree.data.time.SerialDate.createInstance(date25);
//        java.lang.String str81 = serialDate80.toString();
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(list8);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNotNull(list17);
//        org.junit.Assert.assertNotNull(collection18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertNotNull(wildcardClass22);
//        org.junit.Assert.assertNotNull(class23);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
//        org.junit.Assert.assertNotNull(wildcardClass39);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "10-June-2019" + "'", str41.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "June 2019" + "'", str47.equals("June 2019"));
//        org.junit.Assert.assertNotNull(timeZone48);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertNull(regularTimePeriod50);
//        org.junit.Assert.assertNotNull(class51);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertNotNull(date55);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
//        org.junit.Assert.assertNotNull(wildcardClass66);
//        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "10-June-2019" + "'", str68.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date69);
//        org.junit.Assert.assertNotNull(date72);
//        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "June 2019" + "'", str74.equals("June 2019"));
//        org.junit.Assert.assertNotNull(timeZone75);
//        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
//        org.junit.Assert.assertNull(regularTimePeriod77);
//        org.junit.Assert.assertNull(regularTimePeriod78);
//        org.junit.Assert.assertNull(regularTimePeriod79);
//        org.junit.Assert.assertNotNull(serialDate80);
//        org.junit.Assert.assertTrue("'" + str81 + "' != '" + "10-June-2019" + "'", str81.equals("10-June-2019"));
//    }

//    @Test
//    public void test107() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test107");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
//        int int2 = spreadsheetDate1.getYYYY();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(3);
//        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate10 = serialDate7.getEndOfCurrentMonth(serialDate9);
//        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate9);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(3);
//        boolean boolean14 = spreadsheetDate4.isInRange(serialDate9, (org.jfree.data.time.SerialDate) spreadsheetDate13);
//        int int15 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate4);
//        java.lang.Class class19 = null;
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class19);
//        timeSeries20.setDomainDescription("hi!");
//        java.lang.Object obj23 = timeSeries20.clone();
//        java.lang.String str24 = timeSeries20.getDescription();
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        java.lang.String str26 = day25.toString();
//        java.util.Date date27 = day25.getStart();
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date27);
//        long long29 = year28.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year28, (java.lang.Number) 100.0f);
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        java.lang.String str33 = day32.toString();
//        java.util.Date date34 = day32.getStart();
//        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year(date34);
//        java.lang.Object obj36 = null;
//        int int37 = year35.compareTo(obj36);
//        java.lang.String str38 = year35.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = year35.previous();
//        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries20.createCopy((org.jfree.data.time.RegularTimePeriod) year28, (org.jfree.data.time.RegularTimePeriod) year35);
//        boolean boolean41 = timeSeries20.getNotify();
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
//        java.lang.String str43 = day42.toString();
//        java.util.Date date44 = day42.getStart();
//        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year(date44);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = year45.previous();
//        long long47 = year45.getFirstMillisecond();
//        long long48 = year45.getFirstMillisecond();
//        long long49 = year45.getFirstMillisecond();
//        long long50 = year45.getFirstMillisecond();
//        timeSeries20.delete((org.jfree.data.time.RegularTimePeriod) year45);
//        try {
//            int int52 = spreadsheetDate1.compareTo((java.lang.Object) year45);
//            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.Year cannot be cast to org.jfree.data.time.SerialDate");
//        } catch (java.lang.ClassCastException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1900 + "'", int2 == 1900);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertNotNull(obj23);
//        org.junit.Assert.assertNull(str24);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "10-June-2019" + "'", str26.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1577865599999L + "'", long29 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "10-June-2019" + "'", str33.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "2019" + "'", str38.equals("2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertNotNull(timeSeries40);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "10-June-2019" + "'", str43.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1546329600000L + "'", long47 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1546329600000L + "'", long48 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1546329600000L + "'", long49 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1546329600000L + "'", long50 == 1546329600000L);
//    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate5 = serialDate2.getEndOfCurrentMonth(serialDate4);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate4);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(9);
        boolean boolean12 = spreadsheetDate9.isOnOrAfter(serialDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate20 = serialDate17.getEndOfCurrentMonth(serialDate19);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate19);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean24 = spreadsheetDate14.isInRange(serialDate19, (org.jfree.data.time.SerialDate) spreadsheetDate23);
        int int25 = spreadsheetDate14.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean28 = spreadsheetDate14.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate27);
        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate34 = serialDate31.getEndOfCurrentMonth(serialDate33);
        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.addDays(0, serialDate34);
        boolean boolean36 = spreadsheetDate14.isOnOrBefore(serialDate34);
        int int37 = spreadsheetDate9.compare((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SerialDate serialDate38 = serialDate6.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate14);
        try {
            org.jfree.data.time.SerialDate serialDate40 = spreadsheetDate14.getPreviousDayOfWeek((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1900 + "'", int25 == 1900);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(serialDate38);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
        timeSeries4.setDomainDescription("hi!");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        java.util.Date date8 = day7.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) 0);
        java.lang.Object obj11 = null;
        boolean boolean12 = timeSeries4.equals(obj11);
        timeSeries4.setDescription("10-June-2019");
        timeSeries4.setDomainDescription("ERROR : Relative To String");
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener17);
        java.util.Collection collection19 = timeSeries4.getTimePeriods();
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(collection19);
    }

//    @Test
//    public void test110() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test110");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        int int3 = day0.compareTo((java.lang.Object) (-1L));
//        long long4 = day0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.previous();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate7 = serialDate4.getEndOfCurrentMonth(serialDate6);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean11 = spreadsheetDate1.isInRange(serialDate6, (org.jfree.data.time.SerialDate) spreadsheetDate10);
        java.lang.String str12 = serialDate6.toString();
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "8-January-1900" + "'", str12.equals("8-January-1900"));
    }

//    @Test
//    public void test112() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test112");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setMaximumItemCount((int) (byte) 0);
//        boolean boolean7 = timeSeries4.getNotify();
//        timeSeries4.setKey((java.lang.Comparable) 10.0d);
//        java.lang.Class<?> wildcardClass10 = timeSeries4.getClass();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        java.lang.String str12 = day11.toString();
//        java.util.Date date13 = day11.getStart();
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date13);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        java.util.Date date16 = day15.getEnd();
//        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date16);
//        java.lang.String str18 = month17.toString();
//        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean20 = month17.equals((java.lang.Object) timeZone19);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date13, timeZone19);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.util.Date date23 = day22.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(date23);
//        java.util.Date date25 = fixedMillisecond24.getTime();
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        java.util.Date date27 = day26.getEnd();
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(date27);
//        java.lang.String str29 = month28.toString();
//        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean31 = month28.equals((java.lang.Object) timeZone30);
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date25, timeZone30);
//        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(date13, timeZone30);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = month33.next();
//        org.jfree.data.time.Year year35 = month33.getYear();
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10-June-2019" + "'", str12.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "June 2019" + "'", str18.equals("June 2019"));
//        org.junit.Assert.assertNotNull(timeZone19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "June 2019" + "'", str29.equals("June 2019"));
//        org.junit.Assert.assertNotNull(timeZone30);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertNotNull(year35);
//    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.time.TimePeriodFormatException: ");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Last" + "'", str1.equals("Last"));
    }

//    @Test
//    public void test115() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test115");
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        java.util.Date date2 = day1.getEnd();
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
//        java.lang.String str4 = month3.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month3, (double) (short) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.util.Date date9 = day8.getEnd();
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date9);
//        java.lang.String str11 = month10.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month10.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month10, (double) (short) 100);
//        int int15 = timeSeriesDataItem7.compareTo((java.lang.Object) month10);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        java.lang.String str17 = day16.toString();
//        int int18 = month10.compareTo((java.lang.Object) str17);
//        long long19 = month10.getLastMillisecond();
//        org.jfree.data.time.Year year20 = month10.getYear();
//        long long21 = year20.getFirstMillisecond();
//        long long22 = year20.getFirstMillisecond();
//        java.lang.String str23 = year20.toString();
//        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(8, year20);
//        long long25 = year20.getSerialIndex();
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "June 2019" + "'", str11.equals("June 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "10-June-2019" + "'", str17.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1561964399999L + "'", long19 == 1561964399999L);
//        org.junit.Assert.assertNotNull(year20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1546329600000L + "'", long21 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1546329600000L + "'", long22 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "2019" + "'", str23.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 2019L + "'", long25 == 2019L);
//    }

//    @Test
//    public void test116() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test116");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
//        java.util.Date date2 = spreadsheetDate1.toDate();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date2);
//        java.lang.Class class7 = null;
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class7);
//        timeSeries8.setMaximumItemCount((int) (byte) 0);
//        boolean boolean11 = timeSeries8.getNotify();
//        timeSeries8.setKey((java.lang.Comparable) 10.0d);
//        java.lang.Class<?> wildcardClass14 = timeSeries8.getClass();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        java.lang.String str16 = day15.toString();
//        java.util.Date date17 = day15.getStart();
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date17);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        java.util.Date date20 = day19.getEnd();
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(date20);
//        java.lang.String str22 = month21.toString();
//        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean24 = month21.equals((java.lang.Object) timeZone23);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass14, date17, timeZone23);
//        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(date2, timeZone23);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "10-June-2019" + "'", str16.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "June 2019" + "'", str22.equals("June 2019"));
//        org.junit.Assert.assertNotNull(timeZone23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNull(regularTimePeriod25);
//    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(date1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date1);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date1);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(serialDate2);
    }

//    @Test
//    public void test118() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test118");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day5);
//        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries4.createCopy(1, (int) (short) 100);
//        int int11 = timeSeries10.getMaximumItemCount();
//        timeSeries10.setRangeDescription("Tuesday");
//        try {
//            org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeries10.getNextTimePeriod();
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(timeSeries10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2147483647 + "'", int11 == 2147483647);
//    }

//    @Test
//    public void test119() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test119");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
//        java.util.Date date3 = fixedMillisecond2.getTime();
//        long long4 = fixedMillisecond2.getSerialIndex();
//        java.util.Date date5 = fixedMillisecond2.getTime();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//        org.junit.Assert.assertNotNull(date5);
//    }

//    @Test
//    public void test120() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test120");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(date1);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date1);
//        long long4 = fixedMillisecond3.getLastMillisecond();
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond3.getMiddleMillisecond(calendar5);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        java.lang.String str8 = day7.toString();
//        java.util.Date date9 = day7.getStart();
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date9);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.previous();
//        java.lang.String str12 = regularTimePeriod11.toString();
//        int int13 = fixedMillisecond3.compareTo((java.lang.Object) regularTimePeriod11);
//        long long14 = fixedMillisecond3.getMiddleMillisecond();
//        java.util.Calendar calendar15 = null;
//        long long16 = fixedMillisecond3.getFirstMillisecond(calendar15);
//        long long17 = fixedMillisecond3.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560236399999L + "'", long6 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10-June-2019" + "'", str8.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2018" + "'", str12.equals("2018"));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560236399999L + "'", long14 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560236399999L + "'", long16 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560236399999L + "'", long17 == 1560236399999L);
//    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        java.lang.String str3 = month2.toString();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean5 = month2.equals((java.lang.Object) timeZone4);
        int int6 = month2.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (double) 2958465);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class12);
        timeSeries13.setMaximumItemCount((int) (byte) 0);
        timeSeries13.removeAgedItems(true);
        boolean boolean18 = month2.equals((java.lang.Object) timeSeries13);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(3);
        int int3 = spreadsheetDate2.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate11 = serialDate8.getEndOfCurrentMonth(serialDate10);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean15 = spreadsheetDate5.isInRange(serialDate10, (org.jfree.data.time.SerialDate) spreadsheetDate14);
        int int16 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate24 = serialDate21.getEndOfCurrentMonth(serialDate23);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate23);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean28 = spreadsheetDate18.isInRange(serialDate23, (org.jfree.data.time.SerialDate) spreadsheetDate27);
        boolean boolean29 = spreadsheetDate2.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate27);
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
        java.util.Date date31 = day30.getEnd();
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(date31);
        java.lang.String str33 = month32.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = month32.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month32, (double) (short) 100);
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
        java.util.Date date38 = day37.getEnd();
        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month(date38);
        java.lang.String str40 = month39.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = month39.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month39, (double) (short) 100);
        int int44 = timeSeriesDataItem36.compareTo((java.lang.Object) month39);
        timeSeriesDataItem36.setValue((java.lang.Number) 6);
        java.lang.Object obj47 = new java.lang.Object();
        int int48 = timeSeriesDataItem36.compareTo(obj47);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = timeSeriesDataItem36.getPeriod();
        boolean boolean50 = spreadsheetDate27.equals((java.lang.Object) timeSeriesDataItem36);
        int int51 = year0.compareTo((java.lang.Object) spreadsheetDate27);
        int int52 = spreadsheetDate27.getMonth();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1900 + "'", int3 == 1900);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "June 2019" + "'", str33.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "June 2019" + "'", str40.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
    }

//    @Test
//    public void test123() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test123");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        int int3 = day0.compareTo((java.lang.Object) (-1L));
//        java.lang.Class class7 = null;
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class7);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.lang.String str10 = day9.toString();
//        timeSeries8.delete((org.jfree.data.time.RegularTimePeriod) day9);
//        timeSeries8.fireSeriesChanged();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.util.Date date14 = day13.getEnd();
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
//        java.lang.Number number16 = timeSeries8.getValue((org.jfree.data.time.RegularTimePeriod) month15);
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class20);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.lang.String str23 = day22.toString();
//        timeSeries21.delete((org.jfree.data.time.RegularTimePeriod) day22);
//        boolean boolean25 = timeSeries8.equals((java.lang.Object) day22);
//        boolean boolean26 = day0.equals((java.lang.Object) timeSeries8);
//        timeSeries8.setDomainDescription("ERROR : Relative To String");
//        java.lang.String str29 = timeSeries8.getRangeDescription();
//        java.lang.String str30 = timeSeries8.getRangeDescription();
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        java.lang.String str32 = day31.toString();
//        long long33 = day31.getFirstMillisecond();
//        java.lang.Number number34 = timeSeries8.getValue((org.jfree.data.time.RegularTimePeriod) day31);
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        java.util.Date date36 = day35.getEnd();
//        int int38 = day35.compareTo((java.lang.Object) (-1L));
//        java.lang.Class class42 = null;
//        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class42);
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day();
//        java.lang.String str45 = day44.toString();
//        timeSeries43.delete((org.jfree.data.time.RegularTimePeriod) day44);
//        timeSeries43.fireSeriesChanged();
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
//        java.util.Date date49 = day48.getEnd();
//        org.jfree.data.time.Month month50 = new org.jfree.data.time.Month(date49);
//        java.lang.Number number51 = timeSeries43.getValue((org.jfree.data.time.RegularTimePeriod) month50);
//        java.lang.Class class55 = null;
//        org.jfree.data.time.TimeSeries timeSeries56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class55);
//        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day();
//        java.lang.String str58 = day57.toString();
//        timeSeries56.delete((org.jfree.data.time.RegularTimePeriod) day57);
//        boolean boolean60 = timeSeries43.equals((java.lang.Object) day57);
//        boolean boolean61 = day35.equals((java.lang.Object) timeSeries43);
//        timeSeries43.setDomainDescription("ERROR : Relative To String");
//        timeSeries43.setMaximumItemCount(3);
//        java.lang.Class class66 = timeSeries43.getTimePeriodClass();
//        timeSeries43.setNotify(false);
//        org.jfree.data.time.Day day69 = new org.jfree.data.time.Day();
//        java.lang.String str70 = day69.toString();
//        java.util.Date date71 = day69.getStart();
//        long long72 = day69.getLastMillisecond();
//        int int73 = timeSeries43.getIndex((org.jfree.data.time.RegularTimePeriod) day69);
//        java.util.Collection collection74 = timeSeries8.getTimePeriodsUniqueToOtherSeries(timeSeries43);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "10-June-2019" + "'", str23.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "hi!" + "'", str29.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "hi!" + "'", str30.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "10-June-2019" + "'", str32.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560150000000L + "'", long33 == 1560150000000L);
//        org.junit.Assert.assertNull(number34);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "10-June-2019" + "'", str45.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertNull(number51);
//        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "10-June-2019" + "'", str58.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
//        org.junit.Assert.assertNull(class66);
//        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "10-June-2019" + "'", str70.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date71);
//        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 1560236399999L + "'", long72 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + (-1) + "'", int73 == (-1));
//        org.junit.Assert.assertNotNull(collection74);
//    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        java.util.Date date2 = spreadsheetDate1.toDate();
        java.util.Date date3 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.util.Date date6 = day5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        java.lang.String str8 = month7.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month7.next();
        long long10 = month7.getMiddleMillisecond();
        int int11 = day4.compareTo((java.lang.Object) month7);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "June 2019" + "'", str8.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560668399999L + "'", long10 == 1560668399999L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        java.lang.String str3 = month2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (double) (short) 100);
        int int7 = month2.getMonth();
        java.lang.String str8 = month2.toString();
        org.jfree.data.time.Year year9 = month2.getYear();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "June 2019" + "'", str8.equals("June 2019"));
        org.junit.Assert.assertNotNull(year9);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(11);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1560668399999L);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560668399999L + "'", long2 == 1560668399999L);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
        timeSeries4.setMaximumItemCount((int) (byte) 0);
        boolean boolean7 = timeSeries4.getNotify();
        java.lang.Object obj8 = timeSeries4.clone();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(obj8);
    }

//    @Test
//    public void test129() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test129");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
//        java.lang.String str3 = month2.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (double) (short) 100);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        java.util.Date date8 = day7.getEnd();
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date8);
//        java.lang.String str10 = month9.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month9, (double) (short) 100);
//        int int14 = timeSeriesDataItem6.compareTo((java.lang.Object) month9);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        java.lang.String str16 = day15.toString();
//        int int17 = month9.compareTo((java.lang.Object) str16);
//        long long18 = month9.getLastMillisecond();
//        org.jfree.data.time.Year year19 = month9.getYear();
//        long long20 = year19.getFirstMillisecond();
//        java.lang.String str21 = year19.toString();
//        java.util.Calendar calendar22 = null;
//        try {
//            year19.peg(calendar22);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "June 2019" + "'", str10.equals("June 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "10-June-2019" + "'", str16.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1561964399999L + "'", long18 == 1561964399999L);
//        org.junit.Assert.assertNotNull(year19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1546329600000L + "'", long20 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2019" + "'", str21.equals("2019"));
//    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test131() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test131");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setMaximumItemCount((int) (byte) 0);
//        boolean boolean7 = timeSeries4.getNotify();
//        timeSeries4.setKey((java.lang.Comparable) 10.0d);
//        java.lang.Class<?> wildcardClass10 = timeSeries4.getClass();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        java.lang.String str12 = day11.toString();
//        java.util.Date date13 = day11.getStart();
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date13);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        java.util.Date date16 = day15.getEnd();
//        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date16);
//        java.lang.String str18 = month17.toString();
//        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean20 = month17.equals((java.lang.Object) timeZone19);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date13, timeZone19);
//        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(date13);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10-June-2019" + "'", str12.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "June 2019" + "'", str18.equals("June 2019"));
//        org.junit.Assert.assertNotNull(timeZone19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNull(regularTimePeriod21);
//    }

//    @Test
//    public void test132() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test132");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setMaximumItemCount((int) (byte) 0);
//        boolean boolean7 = timeSeries4.getNotify();
//        java.util.List list8 = timeSeries4.getItems();
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class12);
//        timeSeries13.setMaximumItemCount((int) (byte) 0);
//        boolean boolean16 = timeSeries13.getNotify();
//        java.util.List list17 = timeSeries13.getItems();
//        java.util.Collection collection18 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries13);
//        boolean boolean19 = timeSeries4.isEmpty();
//        timeSeries4.setDomainDescription("2019");
//        java.lang.Class class25 = null;
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class25);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        java.lang.String str28 = day27.toString();
//        timeSeries26.delete((org.jfree.data.time.RegularTimePeriod) day27);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        java.util.Date date31 = day30.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond(date31);
//        java.util.Date date33 = fixedMillisecond32.getTime();
//        long long34 = fixedMillisecond32.getSerialIndex();
//        long long35 = fixedMillisecond32.getFirstMillisecond();
//        java.util.Calendar calendar36 = null;
//        long long37 = fixedMillisecond32.getMiddleMillisecond(calendar36);
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) day27, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond32);
//        int int39 = day27.getMonth();
//        long long40 = day27.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(list8);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNotNull(list17);
//        org.junit.Assert.assertNotNull(collection18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "10-June-2019" + "'", str28.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560236399999L + "'", long34 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560236399999L + "'", long35 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560236399999L + "'", long37 == 1560236399999L);
//        org.junit.Assert.assertNotNull(timeSeries38);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 6 + "'", int39 == 6);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 43626L + "'", long40 == 43626L);
//    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
        timeSeries4.setDomainDescription("hi!");
        java.lang.Object obj7 = timeSeries4.clone();
        timeSeries4.setRangeDescription("10-June-2019");
        java.lang.Class class10 = timeSeries4.getTimePeriodClass();
        int int11 = timeSeries4.getItemCount();
        try {
            org.jfree.data.time.TimeSeries timeSeries14 = timeSeries4.createCopy((int) 'a', (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNull(class10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("8-January-1900");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Tuesday");
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("Last");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test138() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test138");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setMaximumItemCount((int) (byte) 0);
//        boolean boolean7 = timeSeries4.getNotify();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class11);
//        timeSeries12.setDomainDescription("hi!");
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        java.util.Date date16 = day15.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day15, (java.lang.Number) 0);
//        java.lang.Object obj19 = null;
//        boolean boolean20 = timeSeries12.equals(obj19);
//        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries4.addAndOrUpdate(timeSeries12);
//        timeSeries21.setNotify(true);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        java.util.Date date25 = day24.getEnd();
//        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(date25);
//        java.lang.String str27 = month26.toString();
//        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean29 = month26.equals((java.lang.Object) timeZone28);
//        int int30 = month26.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = month26.previous();
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        java.util.Date date33 = day32.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond(date33);
//        java.util.Date date35 = fixedMillisecond34.getTime();
//        long long36 = fixedMillisecond34.getSerialIndex();
//        long long37 = fixedMillisecond34.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries21.createCopy((org.jfree.data.time.RegularTimePeriod) month26, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = null;
//        java.lang.Class class43 = null;
//        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class43);
//        timeSeries44.setMaximumItemCount((int) (byte) 0);
//        boolean boolean47 = timeSeries44.getNotify();
//        java.util.List list48 = timeSeries44.getItems();
//        java.lang.Class class52 = null;
//        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class52);
//        timeSeries53.setMaximumItemCount((int) (byte) 0);
//        boolean boolean56 = timeSeries53.getNotify();
//        java.util.List list57 = timeSeries53.getItems();
//        java.util.Collection collection58 = timeSeries44.getTimePeriodsUniqueToOtherSeries(timeSeries53);
//        java.util.List list59 = timeSeries44.getItems();
//        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day();
//        java.util.Date date61 = day60.getEnd();
//        int int63 = day60.compareTo((java.lang.Object) (-1L));
//        java.lang.Class class67 = null;
//        org.jfree.data.time.TimeSeries timeSeries68 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class67);
//        org.jfree.data.time.Day day69 = new org.jfree.data.time.Day();
//        java.lang.String str70 = day69.toString();
//        timeSeries68.delete((org.jfree.data.time.RegularTimePeriod) day69);
//        timeSeries68.fireSeriesChanged();
//        org.jfree.data.time.Day day73 = new org.jfree.data.time.Day();
//        java.util.Date date74 = day73.getEnd();
//        org.jfree.data.time.Month month75 = new org.jfree.data.time.Month(date74);
//        java.lang.Number number76 = timeSeries68.getValue((org.jfree.data.time.RegularTimePeriod) month75);
//        java.lang.Class class80 = null;
//        org.jfree.data.time.TimeSeries timeSeries81 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class80);
//        org.jfree.data.time.Day day82 = new org.jfree.data.time.Day();
//        java.lang.String str83 = day82.toString();
//        timeSeries81.delete((org.jfree.data.time.RegularTimePeriod) day82);
//        boolean boolean85 = timeSeries68.equals((java.lang.Object) day82);
//        boolean boolean86 = day60.equals((java.lang.Object) timeSeries68);
//        org.jfree.data.time.Day day87 = new org.jfree.data.time.Day();
//        java.lang.String str88 = day87.toString();
//        java.util.Date date89 = day87.getStart();
//        long long90 = day87.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries91 = timeSeries44.createCopy((org.jfree.data.time.RegularTimePeriod) day60, (org.jfree.data.time.RegularTimePeriod) day87);
//        int int92 = day87.getYear();
//        java.lang.String str93 = day87.toString();
//        int int94 = day87.getDayOfMonth();
//        try {
//            org.jfree.data.time.TimeSeries timeSeries95 = timeSeries38.createCopy(regularTimePeriod39, (org.jfree.data.time.RegularTimePeriod) day87);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'start' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNull(timeSeriesDataItem18);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(timeSeries21);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "June 2019" + "'", str27.equals("June 2019"));
//        org.junit.Assert.assertNotNull(timeZone28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560236399999L + "'", long36 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560236399999L + "'", long37 == 1560236399999L);
//        org.junit.Assert.assertNotNull(timeSeries38);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
//        org.junit.Assert.assertNotNull(list48);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
//        org.junit.Assert.assertNotNull(list57);
//        org.junit.Assert.assertNotNull(collection58);
//        org.junit.Assert.assertNotNull(list59);
//        org.junit.Assert.assertNotNull(date61);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
//        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "10-June-2019" + "'", str70.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date74);
//        org.junit.Assert.assertNull(number76);
//        org.junit.Assert.assertTrue("'" + str83 + "' != '" + "10-June-2019" + "'", str83.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
//        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
//        org.junit.Assert.assertTrue("'" + str88 + "' != '" + "10-June-2019" + "'", str88.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date89);
//        org.junit.Assert.assertTrue("'" + long90 + "' != '" + 1560236399999L + "'", long90 == 1560236399999L);
//        org.junit.Assert.assertNotNull(timeSeries91);
//        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 2019 + "'", int92 == 2019);
//        org.junit.Assert.assertTrue("'" + str93 + "' != '" + "10-June-2019" + "'", str93.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 10 + "'", int94 == 10);
//    }

//    @Test
//    public void test139() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test139");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        int int3 = day0.compareTo((java.lang.Object) (-1L));
//        java.lang.Class class7 = null;
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class7);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.lang.String str10 = day9.toString();
//        timeSeries8.delete((org.jfree.data.time.RegularTimePeriod) day9);
//        timeSeries8.fireSeriesChanged();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.util.Date date14 = day13.getEnd();
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
//        java.lang.Number number16 = timeSeries8.getValue((org.jfree.data.time.RegularTimePeriod) month15);
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class20);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.lang.String str23 = day22.toString();
//        timeSeries21.delete((org.jfree.data.time.RegularTimePeriod) day22);
//        boolean boolean25 = timeSeries8.equals((java.lang.Object) day22);
//        boolean boolean26 = day0.equals((java.lang.Object) timeSeries8);
//        timeSeries8.setDomainDescription("ERROR : Relative To String");
//        java.lang.String str29 = timeSeries8.getRangeDescription();
//        try {
//            org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = timeSeries8.getNextTimePeriod();
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "10-June-2019" + "'", str23.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "hi!" + "'", str29.equals("hi!"));
//    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(2, false);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "February" + "'", str2.equals("February"));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(2958465);
        try {
            org.jfree.data.time.SerialDate serialDate3 = serialDate1.getNearestDayOfWeek(2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) '4', 1900);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
        timeSeries4.setMaximumItemCount((int) (byte) 0);
        boolean boolean7 = timeSeries4.getNotify();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class11);
        timeSeries12.setDomainDescription("hi!");
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        java.util.Date date16 = day15.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day15, (java.lang.Number) 0);
        java.lang.Object obj19 = null;
        boolean boolean20 = timeSeries12.equals(obj19);
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries4.addAndOrUpdate(timeSeries12);
        boolean boolean22 = timeSeries4.getNotify();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate30 = serialDate27.getEndOfCurrentMonth(serialDate29);
        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate29);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean34 = spreadsheetDate24.isInRange(serialDate29, (org.jfree.data.time.SerialDate) spreadsheetDate33);
        org.jfree.data.time.SerialDate serialDate36 = serialDate29.getPreviousDayOfWeek(7);
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(serialDate36);
        long long38 = day37.getFirstMillisecond();
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day();
        java.util.Date date40 = day39.getEnd();
        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month(date40);
        java.lang.String str42 = month41.toString();
        org.jfree.data.time.TimeSeries timeSeries43 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) day37, (org.jfree.data.time.RegularTimePeriod) month41);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(timeSeries21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-2208528000000L) + "'", long38 == (-2208528000000L));
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "June 2019" + "'", str42.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries43);
    }

//    @Test
//    public void test145() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test145");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day5);
//        timeSeries4.fireSeriesChanged();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.util.Date date10 = day9.getEnd();
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
//        java.lang.Number number12 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month11);
//        java.lang.Class class13 = null;
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month11, class13);
//        timeSeries14.setDescription("Monday");
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNull(number12);
//    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate7 = serialDate4.getEndOfCurrentMonth(serialDate6);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean11 = spreadsheetDate1.isInRange(serialDate6, (org.jfree.data.time.SerialDate) spreadsheetDate10);
        int int12 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean15 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate21 = serialDate18.getEndOfCurrentMonth(serialDate20);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addDays(0, serialDate21);
        boolean boolean23 = spreadsheetDate1.isOnOrBefore(serialDate21);
        int int24 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(12);
        java.util.Date date27 = spreadsheetDate26.toDate();
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
        java.util.Date date29 = day28.getEnd();
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.createInstance(date29);
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(serialDate30);
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate36 = serialDate33.getEndOfCurrentMonth(serialDate35);
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(serialDate33);
        boolean boolean39 = spreadsheetDate26.isInRange(serialDate30, serialDate33, 0);
        boolean boolean40 = spreadsheetDate1.isOn(serialDate33);
        serialDate33.setDescription("Nearest");
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1900 + "'", int12 == 1900);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1900 + "'", int24 == 1900);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

//    @Test
//    public void test147() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test147");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        java.util.Date date2 = day0.getStart();
//        java.lang.String str3 = day0.toString();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10-June-2019" + "'", str3.equals("10-June-2019"));
//    }

//    @Test
//    public void test148() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test148");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        java.util.Date date2 = day0.getStart();
//        long long3 = day0.getLastMillisecond();
//        java.lang.String str4 = day0.toString();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560236399999L + "'", long3 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10-June-2019" + "'", str4.equals("10-June-2019"));
//    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
    }

//    @Test
//    public void test150() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test150");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        int int3 = day0.compareTo((java.lang.Object) (-1L));
//        java.lang.Class class7 = null;
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class7);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.lang.String str10 = day9.toString();
//        timeSeries8.delete((org.jfree.data.time.RegularTimePeriod) day9);
//        timeSeries8.fireSeriesChanged();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.util.Date date14 = day13.getEnd();
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
//        java.lang.Number number16 = timeSeries8.getValue((org.jfree.data.time.RegularTimePeriod) month15);
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class20);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.lang.String str23 = day22.toString();
//        timeSeries21.delete((org.jfree.data.time.RegularTimePeriod) day22);
//        boolean boolean25 = timeSeries8.equals((java.lang.Object) day22);
//        boolean boolean26 = day0.equals((java.lang.Object) timeSeries8);
//        timeSeries8.setDomainDescription("ERROR : Relative To String");
//        timeSeries8.removeAgedItems(false);
//        java.lang.Comparable comparable31 = timeSeries8.getKey();
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        java.lang.String str33 = day32.toString();
//        long long34 = day32.getFirstMillisecond();
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        java.util.Date date36 = day35.getEnd();
//        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.createInstance(date36);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond(date36);
//        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.createInstance(date36);
//        boolean boolean40 = day32.equals((java.lang.Object) serialDate39);
//        try {
//            timeSeries8.add((org.jfree.data.time.RegularTimePeriod) day32, (java.lang.Number) 2958465, true);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "10-June-2019" + "'", str23.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + comparable31 + "' != '" + (-1.0f) + "'", comparable31.equals((-1.0f)));
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "10-June-2019" + "'", str33.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560150000000L + "'", long34 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNotNull(serialDate37);
//        org.junit.Assert.assertNotNull(serialDate39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        java.lang.String str3 = month2.toString();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean5 = month2.equals((java.lang.Object) timeZone4);
        int int6 = month2.getMonth();
        long long7 = month2.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month2.next();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1561964399999L + "'", long7 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class6);
        timeSeries7.setMaximumItemCount((int) (byte) 0);
        boolean boolean10 = timeSeries7.getNotify();
        java.util.List list11 = timeSeries7.getItems();
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class15);
        timeSeries16.setMaximumItemCount((int) (byte) 0);
        boolean boolean19 = timeSeries16.getNotify();
        java.util.List list20 = timeSeries16.getItems();
        java.util.Collection collection21 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries16);
        boolean boolean22 = timeSeries7.isEmpty();
        timeSeries7.setDomainDescription("2019");
        java.lang.Class<?> wildcardClass25 = timeSeries7.getClass();
        java.util.Date date26 = null;
        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date26, timeZone27);
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date1, timeZone27);
        int int31 = day29.compareTo((java.lang.Object) "");
        java.util.Calendar calendar32 = null;
        try {
            long long33 = day29.getMiddleMillisecond(calendar32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertNotNull(collection21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
        timeSeries4.setMaximumItemCount((int) (byte) 0);
        boolean boolean7 = timeSeries4.getNotify();
        java.util.List list8 = timeSeries4.getItems();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class12);
        timeSeries13.setMaximumItemCount((int) (byte) 0);
        boolean boolean16 = timeSeries13.getNotify();
        java.util.List list17 = timeSeries13.getItems();
        java.util.Collection collection18 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        boolean boolean19 = timeSeries4.isEmpty();
        timeSeries4.setDomainDescription("2019");
        java.lang.Class<?> wildcardClass22 = timeSeries4.getClass();
        java.lang.Object obj23 = timeSeries4.clone();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(list17);
        org.junit.Assert.assertNotNull(collection18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(obj23);
    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test154");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setMaximumItemCount((int) (byte) 0);
//        boolean boolean7 = timeSeries4.getNotify();
//        java.util.List list8 = timeSeries4.getItems();
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class12);
//        timeSeries13.setMaximumItemCount((int) (byte) 0);
//        boolean boolean16 = timeSeries13.getNotify();
//        java.util.List list17 = timeSeries13.getItems();
//        java.util.Collection collection18 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries13);
//        boolean boolean19 = timeSeries4.isEmpty();
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        java.util.Date date21 = day20.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(date21);
//        java.util.Date date23 = fixedMillisecond22.getTime();
//        long long24 = fixedMillisecond22.getSerialIndex();
//        long long25 = fixedMillisecond22.getFirstMillisecond();
//        java.util.Calendar calendar26 = null;
//        long long27 = fixedMillisecond22.getMiddleMillisecond(calendar26);
//        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate33 = serialDate30.getEndOfCurrentMonth(serialDate32);
//        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate32);
//        boolean boolean35 = fixedMillisecond22.equals((java.lang.Object) serialDate32);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = fixedMillisecond22.next();
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
//        java.util.Date date38 = day37.getEnd();
//        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month(date38);
//        java.lang.String str40 = month39.toString();
//        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean42 = month39.equals((java.lang.Object) timeZone41);
//        int int43 = month39.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = month39.previous();
//        org.jfree.data.time.TimeSeries timeSeries45 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, regularTimePeriod44);
//        java.lang.String str46 = fixedMillisecond22.toString();
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(list8);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNotNull(list17);
//        org.junit.Assert.assertNotNull(collection18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560236399999L + "'", long24 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560236399999L + "'", long25 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560236399999L + "'", long27 == 1560236399999L);
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertNotNull(serialDate32);
//        org.junit.Assert.assertNotNull(serialDate33);
//        org.junit.Assert.assertNotNull(serialDate34);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "June 2019" + "'", str40.equals("June 2019"));
//        org.junit.Assert.assertNotNull(timeZone41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 2019 + "'", int43 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod44);
//        org.junit.Assert.assertNotNull(timeSeries45);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "Mon Jun 10 23:59:59 PDT 2019" + "'", str46.equals("Mon Jun 10 23:59:59 PDT 2019"));
//    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(12);
        java.util.Date date3 = spreadsheetDate2.toDate();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getEnd();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date5);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate6);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate12 = serialDate9.getEndOfCurrentMonth(serialDate11);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(serialDate9);
        boolean boolean15 = spreadsheetDate2.isInRange(serialDate6, serialDate9, 0);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate6);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(serialDate16);
    }

//    @Test
//    public void test156() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test156");
//        java.util.Date date0 = null;
//        java.lang.Class class4 = null;
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class4);
//        timeSeries5.setMaximumItemCount((int) (byte) 0);
//        boolean boolean8 = timeSeries5.getNotify();
//        java.util.List list9 = timeSeries5.getItems();
//        java.lang.Class class13 = null;
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class13);
//        timeSeries14.setMaximumItemCount((int) (byte) 0);
//        boolean boolean17 = timeSeries14.getNotify();
//        java.util.List list18 = timeSeries14.getItems();
//        java.util.Collection collection19 = timeSeries5.getTimePeriodsUniqueToOtherSeries(timeSeries14);
//        boolean boolean20 = timeSeries5.isEmpty();
//        timeSeries5.setDomainDescription("2019");
//        java.lang.Class<?> wildcardClass23 = timeSeries5.getClass();
//        java.lang.Class class24 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass23);
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        java.util.Date date26 = day25.getEnd();
//        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(date26);
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date26);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond(date26);
//        java.lang.Class class33 = null;
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class33);
//        timeSeries34.setMaximumItemCount((int) (byte) 0);
//        boolean boolean37 = timeSeries34.getNotify();
//        timeSeries34.setKey((java.lang.Comparable) 10.0d);
//        java.lang.Class<?> wildcardClass40 = timeSeries34.getClass();
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
//        java.lang.String str42 = day41.toString();
//        java.util.Date date43 = day41.getStart();
//        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year(date43);
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day();
//        java.util.Date date46 = day45.getEnd();
//        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month(date46);
//        java.lang.String str48 = month47.toString();
//        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean50 = month47.equals((java.lang.Object) timeZone49);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass40, date43, timeZone49);
//        java.lang.Class class52 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass40);
//        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day();
//        java.util.Date date54 = day53.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond55 = new org.jfree.data.time.FixedMillisecond(date54);
//        java.util.Date date56 = fixedMillisecond55.getTime();
//        java.lang.Class class60 = null;
//        org.jfree.data.time.TimeSeries timeSeries61 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class60);
//        timeSeries61.setMaximumItemCount((int) (byte) 0);
//        boolean boolean64 = timeSeries61.getNotify();
//        timeSeries61.setKey((java.lang.Comparable) 10.0d);
//        java.lang.Class<?> wildcardClass67 = timeSeries61.getClass();
//        org.jfree.data.time.Day day68 = new org.jfree.data.time.Day();
//        java.lang.String str69 = day68.toString();
//        java.util.Date date70 = day68.getStart();
//        org.jfree.data.time.Year year71 = new org.jfree.data.time.Year(date70);
//        org.jfree.data.time.Day day72 = new org.jfree.data.time.Day();
//        java.util.Date date73 = day72.getEnd();
//        org.jfree.data.time.Month month74 = new org.jfree.data.time.Month(date73);
//        java.lang.String str75 = month74.toString();
//        java.util.TimeZone timeZone76 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean77 = month74.equals((java.lang.Object) timeZone76);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass67, date70, timeZone76);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass40, date56, timeZone76);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date26, timeZone76);
//        try {
//            org.jfree.data.time.Month month81 = new org.jfree.data.time.Month(date0, timeZone76);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertNotNull(list9);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertNotNull(list18);
//        org.junit.Assert.assertNotNull(collection19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertNotNull(wildcardClass23);
//        org.junit.Assert.assertNotNull(class24);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
//        org.junit.Assert.assertNotNull(wildcardClass40);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "10-June-2019" + "'", str42.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "June 2019" + "'", str48.equals("June 2019"));
//        org.junit.Assert.assertNotNull(timeZone49);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertNull(regularTimePeriod51);
//        org.junit.Assert.assertNotNull(class52);
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
//        org.junit.Assert.assertNotNull(wildcardClass67);
//        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "10-June-2019" + "'", str69.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date70);
//        org.junit.Assert.assertNotNull(date73);
//        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "June 2019" + "'", str75.equals("June 2019"));
//        org.junit.Assert.assertNotNull(timeZone76);
//        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
//        org.junit.Assert.assertNull(regularTimePeriod78);
//        org.junit.Assert.assertNull(regularTimePeriod79);
//        org.junit.Assert.assertNull(regularTimePeriod80);
//    }

//    @Test
//    public void test157() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test157");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
//        java.util.Date date3 = fixedMillisecond2.getTime();
//        long long4 = fixedMillisecond2.getSerialIndex();
//        long long5 = fixedMillisecond2.getFirstMillisecond();
//        java.lang.Class class9 = null;
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class9);
//        timeSeries10.setMaximumItemCount((int) (byte) 0);
//        boolean boolean13 = timeSeries10.getNotify();
//        java.util.List list14 = timeSeries10.getItems();
//        java.lang.Class class18 = null;
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class18);
//        timeSeries19.setMaximumItemCount((int) (byte) 0);
//        boolean boolean22 = timeSeries19.getNotify();
//        java.util.List list23 = timeSeries19.getItems();
//        java.util.Collection collection24 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries19);
//        boolean boolean25 = timeSeries10.isEmpty();
//        timeSeries10.setDomainDescription("2019");
//        java.lang.Class<?> wildcardClass28 = timeSeries10.getClass();
//        java.lang.Class class29 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass28);
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond2, (java.lang.Class) wildcardClass28);
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        java.lang.String str32 = day31.toString();
//        java.util.Date date33 = day31.getStart();
//        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date33);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = year34.previous();
//        timeSeries30.delete(regularTimePeriod35);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560236399999L + "'", long5 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertNotNull(list14);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertNotNull(list23);
//        org.junit.Assert.assertNotNull(collection24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertNotNull(wildcardClass28);
//        org.junit.Assert.assertNotNull(class29);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "10-June-2019" + "'", str32.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//    }

//    @Test
//    public void test158() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test158");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
//        java.util.Date date3 = fixedMillisecond2.getTime();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.String str5 = day4.toString();
//        java.util.Date date6 = day4.getStart();
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class11);
//        timeSeries12.setMaximumItemCount((int) (byte) 0);
//        boolean boolean15 = timeSeries12.getNotify();
//        java.util.List list16 = timeSeries12.getItems();
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class20);
//        timeSeries21.setMaximumItemCount((int) (byte) 0);
//        boolean boolean24 = timeSeries21.getNotify();
//        java.util.List list25 = timeSeries21.getItems();
//        java.util.Collection collection26 = timeSeries12.getTimePeriodsUniqueToOtherSeries(timeSeries21);
//        boolean boolean27 = timeSeries12.isEmpty();
//        timeSeries12.setDomainDescription("2019");
//        java.lang.Class<?> wildcardClass30 = timeSeries12.getClass();
//        java.util.Date date31 = null;
//        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date31, timeZone32);
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date6, timeZone32);
//        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(date3, timeZone32);
//        int int36 = month35.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = month35.next();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10-June-2019" + "'", str5.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertNotNull(list16);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//        org.junit.Assert.assertNotNull(list25);
//        org.junit.Assert.assertNotNull(collection26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertNotNull(timeZone32);
//        org.junit.Assert.assertNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 6 + "'", int36 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
        java.util.Date date3 = fixedMillisecond2.getTime();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getEnd();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date5);
        java.lang.String str7 = month6.toString();
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean9 = month6.equals((java.lang.Object) timeZone8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date3, timeZone8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.previous();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "June 2019" + "'", str7.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test161() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test161");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        java.util.Date date2 = day0.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
//        java.lang.Class class7 = null;
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class7);
//        timeSeries8.setMaximumItemCount((int) (byte) 0);
//        boolean boolean11 = timeSeries8.getNotify();
//        java.util.List list12 = timeSeries8.getItems();
//        java.lang.Class class16 = null;
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class16);
//        timeSeries17.setMaximumItemCount((int) (byte) 0);
//        boolean boolean20 = timeSeries17.getNotify();
//        java.util.List list21 = timeSeries17.getItems();
//        java.util.Collection collection22 = timeSeries8.getTimePeriodsUniqueToOtherSeries(timeSeries17);
//        java.util.List list23 = timeSeries8.getItems();
//        boolean boolean24 = fixedMillisecond3.equals((java.lang.Object) timeSeries8);
//        java.lang.Class class28 = null;
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class28);
//        timeSeries29.setMaximumItemCount((int) (byte) 0);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener32 = null;
//        timeSeries29.removeChangeListener(seriesChangeListener32);
//        boolean boolean34 = fixedMillisecond3.equals((java.lang.Object) seriesChangeListener32);
//        long long35 = fixedMillisecond3.getMiddleMillisecond();
//        long long36 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = fixedMillisecond3.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = fixedMillisecond3.next();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertNotNull(list12);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertNotNull(list21);
//        org.junit.Assert.assertNotNull(collection22);
//        org.junit.Assert.assertNotNull(list23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560150000000L + "'", long35 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560150000000L + "'", long36 == 1560150000000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//    }

//    @Test
//    public void test162() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test162");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day5);
//        long long8 = day5.getMiddleMillisecond();
//        org.jfree.data.time.SerialDate serialDate9 = day5.getSerialDate();
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560193199999L + "'", long8 == 1560193199999L);
//        org.junit.Assert.assertNotNull(serialDate9);
//    }

//    @Test
//    public void test163() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test163");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day5);
//        timeSeries4.fireSeriesChanged();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.util.Date date10 = day9.getEnd();
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
//        java.lang.Number number12 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month11);
//        java.lang.Class class13 = null;
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month11, class13);
//        java.lang.Class class15 = timeSeries14.getTimePeriodClass();
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNull(number12);
//        org.junit.Assert.assertNull(class15);
//    }

//    @Test
//    public void test164() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test164");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setMaximumItemCount((int) (byte) 0);
//        boolean boolean7 = timeSeries4.getNotify();
//        java.util.List list8 = timeSeries4.getItems();
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class12);
//        timeSeries13.setMaximumItemCount((int) (byte) 0);
//        boolean boolean16 = timeSeries13.getNotify();
//        java.util.List list17 = timeSeries13.getItems();
//        java.util.Collection collection18 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries13);
//        java.beans.PropertyChangeListener propertyChangeListener19 = null;
//        timeSeries13.removePropertyChangeListener(propertyChangeListener19);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        java.util.Date date22 = day21.getEnd();
//        int int24 = day21.compareTo((java.lang.Object) (-1L));
//        java.lang.Class class28 = null;
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class28);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        java.lang.String str31 = day30.toString();
//        timeSeries29.delete((org.jfree.data.time.RegularTimePeriod) day30);
//        timeSeries29.fireSeriesChanged();
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        java.util.Date date35 = day34.getEnd();
//        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month(date35);
//        java.lang.Number number37 = timeSeries29.getValue((org.jfree.data.time.RegularTimePeriod) month36);
//        java.lang.Class class41 = null;
//        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class41);
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
//        java.lang.String str44 = day43.toString();
//        timeSeries42.delete((org.jfree.data.time.RegularTimePeriod) day43);
//        boolean boolean46 = timeSeries29.equals((java.lang.Object) day43);
//        boolean boolean47 = day21.equals((java.lang.Object) timeSeries29);
//        timeSeries29.setDomainDescription("ERROR : Relative To String");
//        java.lang.String str50 = timeSeries29.getRangeDescription();
//        java.lang.String str51 = timeSeries29.getRangeDescription();
//        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day();
//        java.lang.String str53 = day52.toString();
//        long long54 = day52.getFirstMillisecond();
//        java.lang.Number number55 = timeSeries29.getValue((org.jfree.data.time.RegularTimePeriod) day52);
//        java.lang.Number number56 = timeSeries13.getValue((org.jfree.data.time.RegularTimePeriod) day52);
//        int int57 = day52.getMonth();
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(list8);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNotNull(list17);
//        org.junit.Assert.assertNotNull(collection18);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "10-June-2019" + "'", str31.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNull(number37);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "10-June-2019" + "'", str44.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "hi!" + "'", str50.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "hi!" + "'", str51.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "10-June-2019" + "'", str53.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1560150000000L + "'", long54 == 1560150000000L);
//        org.junit.Assert.assertNull(number55);
//        org.junit.Assert.assertNull(number56);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 6 + "'", int57 == 6);
//    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate7 = serialDate4.getEndOfCurrentMonth(serialDate6);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean11 = spreadsheetDate1.isInRange(serialDate6, (org.jfree.data.time.SerialDate) spreadsheetDate10);
        int int12 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean15 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate14);
        int int16 = spreadsheetDate1.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate23 = serialDate20.getEndOfCurrentMonth(serialDate22);
        boolean boolean24 = spreadsheetDate18.isAfter(serialDate23);
        boolean boolean25 = spreadsheetDate1.isBefore(serialDate23);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate33 = serialDate30.getEndOfCurrentMonth(serialDate32);
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate32);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean37 = spreadsheetDate27.isInRange(serialDate32, (org.jfree.data.time.SerialDate) spreadsheetDate36);
        int int38 = spreadsheetDate27.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean41 = spreadsheetDate27.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate40);
        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate47 = serialDate44.getEndOfCurrentMonth(serialDate46);
        org.jfree.data.time.SerialDate serialDate48 = org.jfree.data.time.SerialDate.addDays(0, serialDate47);
        boolean boolean49 = spreadsheetDate27.isOnOrBefore(serialDate47);
        int int50 = spreadsheetDate27.getYYYY();
        int int51 = spreadsheetDate27.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate53 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate55 = org.jfree.data.time.SerialDate.createInstance(9);
        boolean boolean56 = spreadsheetDate53.isOnOrAfter(serialDate55);
        boolean boolean57 = spreadsheetDate27.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate53);
        boolean boolean58 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate27);
        org.jfree.data.time.SerialDate serialDate61 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate63 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate64 = serialDate61.getEndOfCurrentMonth(serialDate63);
        org.jfree.data.time.SerialDate serialDate65 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate63);
        org.jfree.data.time.Day day66 = new org.jfree.data.time.Day(serialDate65);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate68 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate70 = org.jfree.data.time.SerialDate.createInstance(9);
        boolean boolean71 = spreadsheetDate68.isOnOrAfter(serialDate70);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate73 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate76 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate78 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate79 = serialDate76.getEndOfCurrentMonth(serialDate78);
        org.jfree.data.time.SerialDate serialDate80 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate78);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate82 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean83 = spreadsheetDate73.isInRange(serialDate78, (org.jfree.data.time.SerialDate) spreadsheetDate82);
        int int84 = spreadsheetDate73.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate86 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean87 = spreadsheetDate73.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate86);
        org.jfree.data.time.SerialDate serialDate90 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate92 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate93 = serialDate90.getEndOfCurrentMonth(serialDate92);
        org.jfree.data.time.SerialDate serialDate94 = org.jfree.data.time.SerialDate.addDays(0, serialDate93);
        boolean boolean95 = spreadsheetDate73.isOnOrBefore(serialDate93);
        int int96 = spreadsheetDate68.compare((org.jfree.data.time.SerialDate) spreadsheetDate73);
        org.jfree.data.time.SerialDate serialDate97 = serialDate65.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate73);
        boolean boolean98 = spreadsheetDate1.isAfter(serialDate65);
        java.util.Date date99 = spreadsheetDate1.toDate();
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1900 + "'", int12 == 1900);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1900 + "'", int38 == 1900);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1900 + "'", int50 == 1900);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 2 + "'", int51 == 2);
        org.junit.Assert.assertNotNull(serialDate55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertNotNull(serialDate61);
        org.junit.Assert.assertNotNull(serialDate63);
        org.junit.Assert.assertNotNull(serialDate64);
        org.junit.Assert.assertNotNull(serialDate65);
        org.junit.Assert.assertNotNull(serialDate70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(serialDate76);
        org.junit.Assert.assertNotNull(serialDate78);
        org.junit.Assert.assertNotNull(serialDate79);
        org.junit.Assert.assertNotNull(serialDate80);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + true + "'", boolean83 == true);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 1900 + "'", int84 == 1900);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertNotNull(serialDate90);
        org.junit.Assert.assertNotNull(serialDate92);
        org.junit.Assert.assertNotNull(serialDate93);
        org.junit.Assert.assertNotNull(serialDate94);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + true + "'", boolean95 == true);
        org.junit.Assert.assertTrue("'" + int96 + "' != '" + 0 + "'", int96 == 0);
        org.junit.Assert.assertNotNull(serialDate97);
        org.junit.Assert.assertTrue("'" + boolean98 + "' != '" + false + "'", boolean98 == false);
        org.junit.Assert.assertNotNull(date99);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test167() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test167");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day5);
//        timeSeries4.fireSeriesChanged();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.util.Date date10 = day9.getEnd();
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
//        java.lang.Number number12 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month11);
//        java.lang.Class class16 = null;
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class16);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        java.lang.String str19 = day18.toString();
//        timeSeries17.delete((org.jfree.data.time.RegularTimePeriod) day18);
//        boolean boolean21 = timeSeries4.equals((java.lang.Object) day18);
//        java.lang.Class class25 = null;
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class25);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        java.lang.String str28 = day27.toString();
//        timeSeries26.delete((org.jfree.data.time.RegularTimePeriod) day27);
//        timeSeries26.fireSeriesChanged();
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        java.util.Date date32 = day31.getEnd();
//        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(date32);
//        java.lang.Number number34 = timeSeries26.getValue((org.jfree.data.time.RegularTimePeriod) month33);
//        int int35 = month33.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = month33.previous();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) month33);
//        long long38 = month33.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNull(number12);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "10-June-2019" + "'", str19.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "10-June-2019" + "'", str28.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNull(number34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 6 + "'", int35 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1559372400000L + "'", long38 == 1559372400000L);
//    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 0, 0, 2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
        timeSeries4.setMaximumItemCount((int) (byte) 0);
        boolean boolean7 = timeSeries4.getNotify();
        java.util.List list8 = timeSeries4.getItems();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class12);
        timeSeries13.setMaximumItemCount((int) (byte) 0);
        boolean boolean16 = timeSeries13.getNotify();
        java.util.List list17 = timeSeries13.getItems();
        java.util.Collection collection18 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        boolean boolean19 = timeSeries4.isEmpty();
        boolean boolean20 = timeSeries4.isEmpty();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(list17);
        org.junit.Assert.assertNotNull(collection18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(12);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

//    @Test
//    public void test171() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test171");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setDomainDescription("hi!");
//        java.lang.Object obj7 = timeSeries4.clone();
//        java.lang.String str8 = timeSeries4.getDescription();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.lang.String str10 = day9.toString();
//        java.util.Date date11 = day9.getStart();
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
//        long long13 = year12.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year12, (java.lang.Number) 100.0f);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        java.lang.String str17 = day16.toString();
//        java.util.Date date18 = day16.getStart();
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date18);
//        java.lang.Object obj20 = null;
//        int int21 = year19.compareTo(obj20);
//        java.lang.String str22 = year19.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year19.previous();
//        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) year12, (org.jfree.data.time.RegularTimePeriod) year19);
//        java.lang.Class class28 = null;
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class28);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        java.lang.String str31 = day30.toString();
//        timeSeries29.delete((org.jfree.data.time.RegularTimePeriod) day30);
//        timeSeries29.fireSeriesChanged();
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        java.util.Date date35 = day34.getEnd();
//        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month(date35);
//        java.lang.Number number37 = timeSeries29.getValue((org.jfree.data.time.RegularTimePeriod) month36);
//        int int38 = month36.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = month36.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries24.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month36, (java.lang.Number) (-460));
//        java.lang.String str42 = timeSeries24.getDomainDescription();
//        java.util.List list43 = timeSeries24.getItems();
//        org.junit.Assert.assertNotNull(obj7);
//        org.junit.Assert.assertNull(str8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "10-June-2019" + "'", str17.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "2019" + "'", str22.equals("2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(timeSeries24);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "10-June-2019" + "'", str31.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNull(number37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 6 + "'", int38 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertNull(timeSeriesDataItem41);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "hi!" + "'", str42.equals("hi!"));
//        org.junit.Assert.assertNotNull(list43);
//    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(6, 12);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(2);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        java.lang.String str2 = spreadsheetDate1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2-January-1900" + "'", str2.equals("2-January-1900"));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        java.lang.String str3 = month2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (double) (short) 100);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        java.util.Date date8 = day7.getEnd();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date8);
        java.lang.String str10 = month9.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month9, (double) (short) 100);
        int int14 = timeSeriesDataItem6.compareTo((java.lang.Object) month9);
        timeSeriesDataItem6.setValue((java.lang.Number) 6);
        java.lang.Number number17 = timeSeriesDataItem6.getValue();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "June 2019" + "'", str10.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 6 + "'", number17.equals(6));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((int) (short) 1);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Sunday" + "'", str1.equals("Sunday"));
    }

//    @Test
//    public void test177() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test177");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        java.util.Date date2 = day0.getStart();
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
//        java.lang.Object obj4 = null;
//        int int5 = year3.compareTo(obj4);
//        long long6 = year3.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year3.next();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(9);
        boolean boolean4 = spreadsheetDate1.isOnOrAfter(serialDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate12 = serialDate9.getEndOfCurrentMonth(serialDate11);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean16 = spreadsheetDate6.isInRange(serialDate11, (org.jfree.data.time.SerialDate) spreadsheetDate15);
        int int17 = spreadsheetDate6.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean20 = spreadsheetDate6.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate26 = serialDate23.getEndOfCurrentMonth(serialDate25);
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.addDays(0, serialDate26);
        boolean boolean28 = spreadsheetDate6.isOnOrBefore(serialDate26);
        int int29 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate6);
        int int30 = spreadsheetDate6.getDayOfMonth();
        int int31 = spreadsheetDate6.toSerial();
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = fixedMillisecond33.previous();
        try {
            int int35 = spreadsheetDate6.compareTo((java.lang.Object) regularTimePeriod34);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.FixedMillisecond cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1900 + "'", int17 == 1900);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2 + "'", int30 == 2);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 3 + "'", int31 == 3);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
    }

//    @Test
//    public void test179() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test179");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1);
//        int int4 = day3.getDayOfMonth();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("Tuesday");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test181() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test181");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        int int3 = day0.compareTo((java.lang.Object) (-1L));
//        java.lang.Class class7 = null;
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class7);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.lang.String str10 = day9.toString();
//        timeSeries8.delete((org.jfree.data.time.RegularTimePeriod) day9);
//        timeSeries8.fireSeriesChanged();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.util.Date date14 = day13.getEnd();
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
//        java.lang.Number number16 = timeSeries8.getValue((org.jfree.data.time.RegularTimePeriod) month15);
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class20);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.lang.String str23 = day22.toString();
//        timeSeries21.delete((org.jfree.data.time.RegularTimePeriod) day22);
//        boolean boolean25 = timeSeries8.equals((java.lang.Object) day22);
//        boolean boolean26 = day0.equals((java.lang.Object) timeSeries8);
//        timeSeries8.setDomainDescription("ERROR : Relative To String");
//        java.lang.String str29 = timeSeries8.getRangeDescription();
//        java.lang.String str30 = timeSeries8.getRangeDescription();
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        java.lang.String str32 = day31.toString();
//        long long33 = day31.getFirstMillisecond();
//        java.lang.Number number34 = timeSeries8.getValue((org.jfree.data.time.RegularTimePeriod) day31);
//        try {
//            timeSeries8.delete((-1), 6);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "10-June-2019" + "'", str23.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "hi!" + "'", str29.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "hi!" + "'", str30.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "10-June-2019" + "'", str32.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560150000000L + "'", long33 == 1560150000000L);
//        org.junit.Assert.assertNull(number34);
//    }

//    @Test
//    public void test182() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test182");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        java.util.Date date2 = day0.getStart();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        java.lang.String str4 = day3.toString();
//        java.util.Date date5 = day3.getStart();
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
//        java.lang.Class class10 = null;
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class10);
//        timeSeries11.setMaximumItemCount((int) (byte) 0);
//        boolean boolean14 = timeSeries11.getNotify();
//        java.util.List list15 = timeSeries11.getItems();
//        java.lang.Class class19 = null;
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class19);
//        timeSeries20.setMaximumItemCount((int) (byte) 0);
//        boolean boolean23 = timeSeries20.getNotify();
//        java.util.List list24 = timeSeries20.getItems();
//        java.util.Collection collection25 = timeSeries11.getTimePeriodsUniqueToOtherSeries(timeSeries20);
//        boolean boolean26 = timeSeries11.isEmpty();
//        timeSeries11.setDomainDescription("2019");
//        java.lang.Class<?> wildcardClass29 = timeSeries11.getClass();
//        java.util.Date date30 = null;
//        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass29, date30, timeZone31);
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date5, timeZone31);
//        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date2, timeZone31);
//        java.lang.Class class38 = null;
//        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class38);
//        timeSeries39.setMaximumItemCount((int) (byte) 0);
//        boolean boolean42 = timeSeries39.getNotify();
//        timeSeries39.setKey((java.lang.Comparable) 10.0d);
//        java.lang.Class<?> wildcardClass45 = timeSeries39.getClass();
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day();
//        java.lang.String str47 = day46.toString();
//        java.util.Date date48 = day46.getStart();
//        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year(date48);
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day();
//        java.util.Date date51 = day50.getEnd();
//        org.jfree.data.time.Month month52 = new org.jfree.data.time.Month(date51);
//        java.lang.String str53 = month52.toString();
//        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean55 = month52.equals((java.lang.Object) timeZone54);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass45, date48, timeZone54);
//        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day();
//        java.util.Date date58 = day57.getEnd();
//        org.jfree.data.time.Month month59 = new org.jfree.data.time.Month(date58);
//        java.lang.Class class63 = null;
//        org.jfree.data.time.TimeSeries timeSeries64 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class63);
//        timeSeries64.setMaximumItemCount((int) (byte) 0);
//        boolean boolean67 = timeSeries64.getNotify();
//        timeSeries64.setKey((java.lang.Comparable) 10.0d);
//        java.lang.Class<?> wildcardClass70 = timeSeries64.getClass();
//        org.jfree.data.time.Day day71 = new org.jfree.data.time.Day();
//        java.lang.String str72 = day71.toString();
//        java.util.Date date73 = day71.getStart();
//        org.jfree.data.time.Year year74 = new org.jfree.data.time.Year(date73);
//        org.jfree.data.time.Day day75 = new org.jfree.data.time.Day();
//        java.util.Date date76 = day75.getEnd();
//        org.jfree.data.time.Month month77 = new org.jfree.data.time.Month(date76);
//        java.lang.String str78 = month77.toString();
//        java.util.TimeZone timeZone79 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean80 = month77.equals((java.lang.Object) timeZone79);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass70, date73, timeZone79);
//        org.jfree.data.time.Month month82 = new org.jfree.data.time.Month(date58, timeZone79);
//        org.jfree.data.time.Year year83 = new org.jfree.data.time.Year(date48, timeZone79);
//        org.jfree.data.time.Year year84 = new org.jfree.data.time.Year(date2, timeZone79);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10-June-2019" + "'", str4.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(list15);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//        org.junit.Assert.assertNotNull(list24);
//        org.junit.Assert.assertNotNull(collection25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNotNull(timeZone31);
//        org.junit.Assert.assertNull(regularTimePeriod32);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
//        org.junit.Assert.assertNotNull(wildcardClass45);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "10-June-2019" + "'", str47.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertNotNull(date51);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "June 2019" + "'", str53.equals("June 2019"));
//        org.junit.Assert.assertNotNull(timeZone54);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertNull(regularTimePeriod56);
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
//        org.junit.Assert.assertNotNull(wildcardClass70);
//        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "10-June-2019" + "'", str72.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date73);
//        org.junit.Assert.assertNotNull(date76);
//        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "June 2019" + "'", str78.equals("June 2019"));
//        org.junit.Assert.assertNotNull(timeZone79);
//        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
//        org.junit.Assert.assertNull(regularTimePeriod81);
//    }

//    @Test
//    public void test183() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test183");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        java.util.Date date2 = day0.getStart();
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year3.previous();
//        long long5 = year3.getFirstMillisecond();
//        long long6 = year3.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
//    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(12);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test185() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test185");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setMaximumItemCount((int) (byte) 0);
//        boolean boolean7 = timeSeries4.getNotify();
//        java.util.List list8 = timeSeries4.getItems();
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class12);
//        timeSeries13.setMaximumItemCount((int) (byte) 0);
//        boolean boolean16 = timeSeries13.getNotify();
//        java.util.List list17 = timeSeries13.getItems();
//        java.util.Collection collection18 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries13);
//        boolean boolean19 = timeSeries4.isEmpty();
//        timeSeries4.setDomainDescription("2019");
//        java.lang.Class<?> wildcardClass22 = timeSeries4.getClass();
//        java.lang.Comparable comparable23 = timeSeries4.getKey();
//        timeSeries4.fireSeriesChanged();
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        java.util.Date date26 = day25.getEnd();
//        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(date26);
//        java.lang.String str28 = month27.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month27.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month27, (double) (short) 100);
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        java.util.Date date33 = day32.getEnd();
//        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month(date33);
//        java.lang.String str35 = month34.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = month34.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month34, (double) (short) 100);
//        int int39 = timeSeriesDataItem31.compareTo((java.lang.Object) month34);
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day();
//        java.lang.String str41 = day40.toString();
//        int int42 = month34.compareTo((java.lang.Object) str41);
//        long long43 = month34.getLastMillisecond();
//        org.jfree.data.time.Year year44 = month34.getYear();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent45 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) month34);
//        java.lang.String str46 = month34.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) month34);
//        try {
//            org.jfree.data.time.TimeSeries timeSeries50 = timeSeries4.createCopy((int) '4', (int) (byte) 10);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(list8);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNotNull(list17);
//        org.junit.Assert.assertNotNull(collection18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertNotNull(wildcardClass22);
//        org.junit.Assert.assertTrue("'" + comparable23 + "' != '" + (-1.0f) + "'", comparable23.equals((-1.0f)));
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "June 2019" + "'", str28.equals("June 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "June 2019" + "'", str35.equals("June 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "10-June-2019" + "'", str41.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1561964399999L + "'", long43 == 1561964399999L);
//        org.junit.Assert.assertNotNull(year44);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "June 2019" + "'", str46.equals("June 2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem47);
//    }

//    @Test
//    public void test186() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test186");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setDomainDescription("hi!");
//        java.lang.Object obj7 = timeSeries4.clone();
//        java.lang.String str8 = timeSeries4.getDescription();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.lang.String str10 = day9.toString();
//        java.util.Date date11 = day9.getStart();
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
//        long long13 = year12.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year12, (java.lang.Number) 100.0f);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        java.lang.String str17 = day16.toString();
//        java.util.Date date18 = day16.getStart();
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date18);
//        java.lang.Object obj20 = null;
//        int int21 = year19.compareTo(obj20);
//        java.lang.String str22 = year19.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year19.previous();
//        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) year12, (org.jfree.data.time.RegularTimePeriod) year19);
//        timeSeries24.setDomainDescription("Feb");
//        java.util.Collection collection27 = timeSeries24.getTimePeriods();
//        org.junit.Assert.assertNotNull(obj7);
//        org.junit.Assert.assertNull(str8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "10-June-2019" + "'", str17.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "2019" + "'", str22.equals("2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(timeSeries24);
//        org.junit.Assert.assertNotNull(collection27);
//    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((int) (short) 10);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

//    @Test
//    public void test188() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test188");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        java.util.Date date2 = day0.getStart();
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
//        java.lang.Object obj4 = null;
//        int int5 = year3.compareTo(obj4);
//        int int6 = year3.getYear();
//        long long7 = year3.getFirstMillisecond();
//        long long8 = year3.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long8);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
//    }

//    @Test
//    public void test189() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test189");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
//        java.util.Date date3 = fixedMillisecond2.getTime();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.util.Date date5 = day4.getEnd();
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date5);
//        java.lang.String str7 = month6.toString();
//        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean9 = month6.equals((java.lang.Object) timeZone8);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date3, timeZone8);
//        java.lang.String str11 = day10.toString();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "June 2019" + "'", str7.equals("June 2019"));
//        org.junit.Assert.assertNotNull(timeZone8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10-June-2019" + "'", str11.equals("10-June-2019"));
//    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate8 = serialDate5.getEndOfCurrentMonth(serialDate7);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean12 = spreadsheetDate2.isInRange(serialDate7, (org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SerialDate serialDate14 = serialDate7.getPreviousDayOfWeek(7);
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.addDays(1900, serialDate7);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(7);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(2958465, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2958465");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

//    @Test
//    public void test193() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test193");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(date1);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(serialDate2);
//        long long4 = day3.getFirstMillisecond();
//        long long5 = day3.getLastMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560150000000L + "'", long4 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560236399999L + "'", long5 == 1560236399999L);
//    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        java.util.Date date2 = day1.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        java.lang.String str4 = month3.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month3, (double) (short) 100);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        java.util.Date date9 = day8.getEnd();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date9);
        java.lang.String str11 = month10.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month10.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month10, (double) (short) 100);
        int int15 = timeSeriesDataItem7.compareTo((java.lang.Object) month10);
        timeSeriesDataItem7.setValue((java.lang.Number) 100);
        java.lang.Number number18 = timeSeriesDataItem7.getValue();
        java.lang.Number number19 = timeSeriesDataItem7.getValue();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate27 = serialDate24.getEndOfCurrentMonth(serialDate26);
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate26);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean31 = spreadsheetDate21.isInRange(serialDate26, (org.jfree.data.time.SerialDate) spreadsheetDate30);
        int int32 = spreadsheetDate21.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean35 = spreadsheetDate21.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate34);
        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate41 = serialDate38.getEndOfCurrentMonth(serialDate40);
        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.addDays(0, serialDate41);
        boolean boolean43 = spreadsheetDate21.isOnOrBefore(serialDate41);
        int int44 = spreadsheetDate21.getYYYY();
        boolean boolean45 = timeSeriesDataItem7.equals((java.lang.Object) spreadsheetDate21);
        try {
            org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(9, (org.jfree.data.time.SerialDate) spreadsheetDate21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "June 2019" + "'", str11.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 100 + "'", number18.equals(100));
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + 100 + "'", number19.equals(100));
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1900 + "'", int32 == 1900);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(serialDate38);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1900 + "'", int44 == 1900);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
        timeSeries4.setMaximumItemCount((int) (byte) 0);
        boolean boolean7 = timeSeries4.getNotify();
        java.util.List list8 = timeSeries4.getItems();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class12);
        timeSeries13.setMaximumItemCount((int) (byte) 0);
        boolean boolean16 = timeSeries13.getNotify();
        java.util.List list17 = timeSeries13.getItems();
        java.util.Collection collection18 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        java.lang.Class class22 = null;
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class22);
        timeSeries23.setMaximumItemCount((int) (byte) 0);
        boolean boolean26 = timeSeries23.getNotify();
        java.lang.Class class30 = null;
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class30);
        timeSeries31.setDomainDescription("hi!");
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
        java.util.Date date35 = day34.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries31.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day34, (java.lang.Number) 0);
        java.lang.Object obj38 = null;
        boolean boolean39 = timeSeries31.equals(obj38);
        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries23.addAndOrUpdate(timeSeries31);
        timeSeries40.setNotify(true);
        boolean boolean43 = timeSeries40.isEmpty();
        java.util.Collection collection44 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries40);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(list17);
        org.junit.Assert.assertNotNull(collection18);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNull(timeSeriesDataItem37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(timeSeries40);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(collection44);
    }

//    @Test
//    public void test196() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test196");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7, "10-June-2019", "ERROR : Relative To String", class3);
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
//        int int7 = timeSeries4.getItemCount();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class11);
//        timeSeries12.setMaximumItemCount((int) (byte) 0);
//        boolean boolean15 = timeSeries12.getNotify();
//        java.util.List list16 = timeSeries12.getItems();
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class20);
//        timeSeries21.setMaximumItemCount((int) (byte) 0);
//        boolean boolean24 = timeSeries21.getNotify();
//        java.util.List list25 = timeSeries21.getItems();
//        java.util.Collection collection26 = timeSeries12.getTimePeriodsUniqueToOtherSeries(timeSeries21);
//        boolean boolean27 = timeSeries12.isEmpty();
//        timeSeries12.setDomainDescription("2019");
//        java.lang.Class class33 = null;
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class33);
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        java.lang.String str36 = day35.toString();
//        timeSeries34.delete((org.jfree.data.time.RegularTimePeriod) day35);
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
//        java.util.Date date39 = day38.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond(date39);
//        java.util.Date date41 = fixedMillisecond40.getTime();
//        long long42 = fixedMillisecond40.getSerialIndex();
//        long long43 = fixedMillisecond40.getFirstMillisecond();
//        java.util.Calendar calendar44 = null;
//        long long45 = fixedMillisecond40.getMiddleMillisecond(calendar44);
//        org.jfree.data.time.TimeSeries timeSeries46 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) day35, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond40);
//        java.util.Collection collection47 = timeSeries12.getTimePeriods();
//        int int48 = timeSeries12.getMaximumItemCount();
//        timeSeries12.setRangeDescription("June 2019");
//        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries4.addAndOrUpdate(timeSeries12);
//        timeSeries4.setRangeDescription("Monday");
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertNotNull(list16);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//        org.junit.Assert.assertNotNull(list25);
//        org.junit.Assert.assertNotNull(collection26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "10-June-2019" + "'", str36.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1560236399999L + "'", long42 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1560236399999L + "'", long43 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1560236399999L + "'", long45 == 1560236399999L);
//        org.junit.Assert.assertNotNull(timeSeries46);
//        org.junit.Assert.assertNotNull(collection47);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
//        org.junit.Assert.assertNotNull(timeSeries51);
//    }

//    @Test
//    public void test197() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test197");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
//        java.util.Date date3 = fixedMillisecond2.getTime();
//        int int5 = fixedMillisecond2.compareTo((java.lang.Object) "June 2019");
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond2.getFirstMillisecond(calendar6);
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond2.getLastMillisecond(calendar8);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560236399999L + "'", long7 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560236399999L + "'", long9 == 1560236399999L);
//    }

//    @Test
//    public void test198() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test198");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
//        java.util.Date date3 = fixedMillisecond2.getTime();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.util.Date date5 = day4.getEnd();
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date5);
//        java.lang.String str7 = month6.toString();
//        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean9 = month6.equals((java.lang.Object) timeZone8);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date3, timeZone8);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (java.lang.Number) 10L);
//        java.util.Date date15 = fixedMillisecond12.getEnd();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
//        long long17 = day16.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "June 2019" + "'", str7.equals("June 2019"));
//        org.junit.Assert.assertNotNull(timeZone8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560150000000L + "'", long17 == 1560150000000L);
//    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(10, 9999, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test200() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test200");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
//        java.lang.String str3 = month2.toString();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean5 = month2.equals((java.lang.Object) timeZone4);
//        int int6 = month2.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month2.previous();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.util.Date date9 = day8.getEnd();
//        int int11 = day8.compareTo((java.lang.Object) (-1L));
//        java.lang.Class class15 = null;
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class15);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        java.lang.String str18 = day17.toString();
//        timeSeries16.delete((org.jfree.data.time.RegularTimePeriod) day17);
//        timeSeries16.fireSeriesChanged();
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        java.util.Date date22 = day21.getEnd();
//        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(date22);
//        java.lang.Number number24 = timeSeries16.getValue((org.jfree.data.time.RegularTimePeriod) month23);
//        java.lang.Class class28 = null;
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class28);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        java.lang.String str31 = day30.toString();
//        timeSeries29.delete((org.jfree.data.time.RegularTimePeriod) day30);
//        boolean boolean33 = timeSeries16.equals((java.lang.Object) day30);
//        boolean boolean34 = day8.equals((java.lang.Object) timeSeries16);
//        timeSeries16.setDomainDescription("ERROR : Relative To String");
//        java.lang.String str37 = timeSeries16.getRangeDescription();
//        boolean boolean38 = month2.equals((java.lang.Object) str37);
//        org.jfree.data.time.Year year39 = month2.getYear();
//        java.util.Date date40 = month2.getStart();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "10-June-2019" + "'", str18.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNull(number24);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "10-June-2019" + "'", str31.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "hi!" + "'", str37.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(year39);
//        org.junit.Assert.assertNotNull(date40);
//    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(5, 4, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test202() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test202");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setMaximumItemCount((int) (byte) 0);
//        boolean boolean7 = timeSeries4.getNotify();
//        java.util.List list8 = timeSeries4.getItems();
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class12);
//        timeSeries13.setMaximumItemCount((int) (byte) 0);
//        boolean boolean16 = timeSeries13.getNotify();
//        java.util.List list17 = timeSeries13.getItems();
//        java.util.Collection collection18 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries13);
//        java.util.List list19 = timeSeries4.getItems();
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        java.util.Date date21 = day20.getEnd();
//        int int23 = day20.compareTo((java.lang.Object) (-1L));
//        java.lang.Class class27 = null;
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class27);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        java.lang.String str30 = day29.toString();
//        timeSeries28.delete((org.jfree.data.time.RegularTimePeriod) day29);
//        timeSeries28.fireSeriesChanged();
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        java.util.Date date34 = day33.getEnd();
//        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(date34);
//        java.lang.Number number36 = timeSeries28.getValue((org.jfree.data.time.RegularTimePeriod) month35);
//        java.lang.Class class40 = null;
//        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class40);
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
//        java.lang.String str43 = day42.toString();
//        timeSeries41.delete((org.jfree.data.time.RegularTimePeriod) day42);
//        boolean boolean45 = timeSeries28.equals((java.lang.Object) day42);
//        boolean boolean46 = day20.equals((java.lang.Object) timeSeries28);
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
//        java.lang.String str48 = day47.toString();
//        java.util.Date date49 = day47.getStart();
//        long long50 = day47.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) day20, (org.jfree.data.time.RegularTimePeriod) day47);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = day47.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem54 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day47, (double) (byte) -1);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(list8);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNotNull(list17);
//        org.junit.Assert.assertNotNull(collection18);
//        org.junit.Assert.assertNotNull(list19);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "10-June-2019" + "'", str30.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNull(number36);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "10-June-2019" + "'", str43.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "10-June-2019" + "'", str48.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1560236399999L + "'", long50 == 1560236399999L);
//        org.junit.Assert.assertNotNull(timeSeries51);
//        org.junit.Assert.assertNotNull(regularTimePeriod52);
//    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(9);
        boolean boolean5 = spreadsheetDate2.isOnOrAfter(serialDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate13 = serialDate10.getEndOfCurrentMonth(serialDate12);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean17 = spreadsheetDate7.isInRange(serialDate12, (org.jfree.data.time.SerialDate) spreadsheetDate16);
        int int18 = spreadsheetDate7.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean21 = spreadsheetDate7.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate27 = serialDate24.getEndOfCurrentMonth(serialDate26);
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.addDays(0, serialDate27);
        boolean boolean29 = spreadsheetDate7.isOnOrBefore(serialDate27);
        int int30 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate7);
        int int31 = spreadsheetDate7.getDayOfMonth();
        int int32 = spreadsheetDate7.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate(12);
        java.util.Date date35 = spreadsheetDate34.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate43 = serialDate40.getEndOfCurrentMonth(serialDate42);
        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate42);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean47 = spreadsheetDate37.isInRange(serialDate42, (org.jfree.data.time.SerialDate) spreadsheetDate46);
        org.jfree.data.time.SerialDate serialDate49 = serialDate42.getPreviousDayOfWeek(7);
        boolean boolean50 = spreadsheetDate7.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate34, serialDate49);
        org.jfree.data.time.SerialDate serialDate51 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(1, (org.jfree.data.time.SerialDate) spreadsheetDate7);
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(serialDate51);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1900 + "'", int18 == 1900);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2 + "'", int31 == 2);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 3 + "'", int32 == 3);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(serialDate51);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(4, 1);
    }

//    @Test
//    public void test205() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test205");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
//        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate7 = serialDate4.getEndOfCurrentMonth(serialDate6);
//        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(3);
//        boolean boolean11 = spreadsheetDate1.isInRange(serialDate6, (org.jfree.data.time.SerialDate) spreadsheetDate10);
//        int int12 = spreadsheetDate1.getYYYY();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(3);
//        boolean boolean15 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate14);
//        int int16 = spreadsheetDate1.getMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(12);
//        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate23 = serialDate20.getEndOfCurrentMonth(serialDate22);
//        boolean boolean24 = spreadsheetDate18.isAfter(serialDate23);
//        boolean boolean25 = spreadsheetDate1.isBefore(serialDate23);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(3);
//        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate33 = serialDate30.getEndOfCurrentMonth(serialDate32);
//        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate32);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(3);
//        boolean boolean37 = spreadsheetDate27.isInRange(serialDate32, (org.jfree.data.time.SerialDate) spreadsheetDate36);
//        int int38 = spreadsheetDate27.getYYYY();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate(3);
//        boolean boolean41 = spreadsheetDate27.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate40);
//        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate47 = serialDate44.getEndOfCurrentMonth(serialDate46);
//        org.jfree.data.time.SerialDate serialDate48 = org.jfree.data.time.SerialDate.addDays(0, serialDate47);
//        boolean boolean49 = spreadsheetDate27.isOnOrBefore(serialDate47);
//        int int50 = spreadsheetDate27.getYYYY();
//        int int51 = spreadsheetDate27.getDayOfMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate53 = new org.jfree.data.time.SpreadsheetDate(3);
//        org.jfree.data.time.SerialDate serialDate55 = org.jfree.data.time.SerialDate.createInstance(9);
//        boolean boolean56 = spreadsheetDate53.isOnOrAfter(serialDate55);
//        boolean boolean57 = spreadsheetDate27.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate53);
//        boolean boolean58 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate27);
//        java.lang.Class class62 = null;
//        org.jfree.data.time.TimeSeries timeSeries63 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class62);
//        timeSeries63.setDomainDescription("hi!");
//        org.jfree.data.time.Day day66 = new org.jfree.data.time.Day();
//        java.util.Date date67 = day66.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem69 = timeSeries63.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day66, (java.lang.Number) 0);
//        timeSeries63.setDescription("");
//        boolean boolean72 = spreadsheetDate27.equals((java.lang.Object) timeSeries63);
//        java.lang.Class class76 = null;
//        org.jfree.data.time.TimeSeries timeSeries77 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class76);
//        org.jfree.data.time.Day day78 = new org.jfree.data.time.Day();
//        java.lang.String str79 = day78.toString();
//        timeSeries77.delete((org.jfree.data.time.RegularTimePeriod) day78);
//        timeSeries77.fireSeriesChanged();
//        org.jfree.data.time.Day day82 = new org.jfree.data.time.Day();
//        java.util.Date date83 = day82.getEnd();
//        org.jfree.data.time.Month month84 = new org.jfree.data.time.Month(date83);
//        java.lang.Number number85 = timeSeries77.getValue((org.jfree.data.time.RegularTimePeriod) month84);
//        java.lang.String str86 = month84.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod87 = month84.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod88 = month84.previous();
//        try {
//            int int89 = spreadsheetDate27.compareTo((java.lang.Object) month84);
//            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.Month cannot be cast to org.jfree.data.time.SerialDate");
//        } catch (java.lang.ClassCastException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1900 + "'", int12 == 1900);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertNotNull(serialDate32);
//        org.junit.Assert.assertNotNull(serialDate33);
//        org.junit.Assert.assertNotNull(serialDate34);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1900 + "'", int38 == 1900);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertNotNull(serialDate44);
//        org.junit.Assert.assertNotNull(serialDate46);
//        org.junit.Assert.assertNotNull(serialDate47);
//        org.junit.Assert.assertNotNull(serialDate48);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1900 + "'", int50 == 1900);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 2 + "'", int51 == 2);
//        org.junit.Assert.assertNotNull(serialDate55);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
//        org.junit.Assert.assertNotNull(date67);
//        org.junit.Assert.assertNull(timeSeriesDataItem69);
//        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
//        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "10-June-2019" + "'", str79.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date83);
//        org.junit.Assert.assertNull(number85);
//        org.junit.Assert.assertTrue("'" + str86 + "' != '" + "June 2019" + "'", str86.equals("June 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod87);
//        org.junit.Assert.assertNotNull(regularTimePeriod88);
//    }

//    @Test
//    public void test206() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test206");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setDomainDescription("hi!");
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        java.util.Date date8 = day7.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) 0);
//        timeSeries4.setDescription("");
//        timeSeries4.setNotify(true);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        java.lang.String str16 = day15.toString();
//        java.util.Date date17 = day15.getStart();
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date17);
//        java.lang.Object obj19 = null;
//        int int20 = year18.compareTo(obj19);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) year18);
//        java.lang.Number number23 = timeSeries4.getValue((int) (byte) 0);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(timeSeriesDataItem10);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "10-June-2019" + "'", str16.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem21);
//        org.junit.Assert.assertTrue("'" + number23 + "' != '" + 0 + "'", number23.equals(0));
//    }

//    @Test
//    public void test207() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test207");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setMaximumItemCount((int) (byte) 0);
//        boolean boolean7 = timeSeries4.getNotify();
//        java.util.List list8 = timeSeries4.getItems();
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class12);
//        timeSeries13.setMaximumItemCount((int) (byte) 0);
//        boolean boolean16 = timeSeries13.getNotify();
//        java.util.List list17 = timeSeries13.getItems();
//        java.util.Collection collection18 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries13);
//        java.util.List list19 = timeSeries4.getItems();
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        java.util.Date date21 = day20.getEnd();
//        int int23 = day20.compareTo((java.lang.Object) (-1L));
//        java.lang.Class class27 = null;
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class27);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        java.lang.String str30 = day29.toString();
//        timeSeries28.delete((org.jfree.data.time.RegularTimePeriod) day29);
//        timeSeries28.fireSeriesChanged();
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        java.util.Date date34 = day33.getEnd();
//        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(date34);
//        java.lang.Number number36 = timeSeries28.getValue((org.jfree.data.time.RegularTimePeriod) month35);
//        java.lang.Class class40 = null;
//        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class40);
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
//        java.lang.String str43 = day42.toString();
//        timeSeries41.delete((org.jfree.data.time.RegularTimePeriod) day42);
//        boolean boolean45 = timeSeries28.equals((java.lang.Object) day42);
//        boolean boolean46 = day20.equals((java.lang.Object) timeSeries28);
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
//        java.lang.String str48 = day47.toString();
//        java.util.Date date49 = day47.getStart();
//        long long50 = day47.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) day20, (org.jfree.data.time.RegularTimePeriod) day47);
//        java.lang.Object obj52 = timeSeries51.clone();
//        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day();
//        java.lang.String str55 = day54.toString();
//        java.util.Date date56 = day54.getStart();
//        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year(date56);
//        java.lang.Object obj58 = null;
//        int int59 = year57.compareTo(obj58);
//        int int60 = year57.getYear();
//        org.jfree.data.time.Month month61 = new org.jfree.data.time.Month(2, year57);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = month61.previous();
//        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day();
//        java.lang.String str64 = day63.toString();
//        java.util.Date date65 = day63.getStart();
//        org.jfree.data.time.Year year66 = new org.jfree.data.time.Year(date65);
//        java.lang.Object obj67 = null;
//        int int68 = year66.compareTo(obj67);
//        long long69 = year66.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries70 = timeSeries51.createCopy(regularTimePeriod62, (org.jfree.data.time.RegularTimePeriod) year66);
//        java.util.Calendar calendar71 = null;
//        try {
//            long long72 = year66.getFirstMillisecond(calendar71);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(list8);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNotNull(list17);
//        org.junit.Assert.assertNotNull(collection18);
//        org.junit.Assert.assertNotNull(list19);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "10-June-2019" + "'", str30.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNull(number36);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "10-June-2019" + "'", str43.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "10-June-2019" + "'", str48.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1560236399999L + "'", long50 == 1560236399999L);
//        org.junit.Assert.assertNotNull(timeSeries51);
//        org.junit.Assert.assertNotNull(obj52);
//        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "10-June-2019" + "'", str55.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 2019 + "'", int60 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod62);
//        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "10-June-2019" + "'", str64.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date65);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 1 + "'", int68 == 1);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 2019L + "'", long69 == 2019L);
//        org.junit.Assert.assertNotNull(timeSeries70);
//    }

//    @Test
//    public void test208() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test208");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
//        java.util.Date date3 = fixedMillisecond2.getTime();
//        long long4 = fixedMillisecond2.getSerialIndex();
//        long long5 = fixedMillisecond2.getFirstMillisecond();
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond2.getMiddleMillisecond(calendar6);
//        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate13 = serialDate10.getEndOfCurrentMonth(serialDate12);
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate12);
//        boolean boolean15 = fixedMillisecond2.equals((java.lang.Object) serialDate12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond2.next();
//        long long17 = fixedMillisecond2.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = fixedMillisecond2.next();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560236399999L + "'", long5 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560236399999L + "'", long7 == 1560236399999L);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560236399999L + "'", long17 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        java.lang.Class class0 = null;
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate6 = serialDate3.getEndOfCurrentMonth(serialDate5);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate5);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(serialDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance(9);
        boolean boolean13 = spreadsheetDate10.isOnOrAfter(serialDate12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate21 = serialDate18.getEndOfCurrentMonth(serialDate20);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean25 = spreadsheetDate15.isInRange(serialDate20, (org.jfree.data.time.SerialDate) spreadsheetDate24);
        int int26 = spreadsheetDate15.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean29 = spreadsheetDate15.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate28);
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate35 = serialDate32.getEndOfCurrentMonth(serialDate34);
        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.addDays(0, serialDate35);
        boolean boolean37 = spreadsheetDate15.isOnOrBefore(serialDate35);
        int int38 = spreadsheetDate10.compare((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SerialDate serialDate39 = serialDate7.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate15);
        java.util.Date date40 = spreadsheetDate15.toDate();
        java.util.TimeZone timeZone41 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date40, timeZone41);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1900 + "'", int26 == 1900);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNull(regularTimePeriod42);
    }

//    @Test
//    public void test210() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test210");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setMaximumItemCount((int) (byte) 0);
//        boolean boolean7 = timeSeries4.getNotify();
//        java.util.List list8 = timeSeries4.getItems();
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class12);
//        timeSeries13.setMaximumItemCount((int) (byte) 0);
//        boolean boolean16 = timeSeries13.getNotify();
//        java.util.List list17 = timeSeries13.getItems();
//        java.util.Collection collection18 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries13);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        java.util.Date date20 = day19.getEnd();
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(date20);
//        java.lang.String str22 = month21.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month21.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month21, (double) (short) 100);
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        java.util.Date date27 = day26.getEnd();
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(date27);
//        java.lang.String str29 = month28.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = month28.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month28, (double) (short) 100);
//        int int33 = timeSeriesDataItem25.compareTo((java.lang.Object) month28);
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        java.lang.String str35 = day34.toString();
//        int int36 = month28.compareTo((java.lang.Object) str35);
//        long long37 = month28.getLastMillisecond();
//        org.jfree.data.time.Year year38 = month28.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = year38.next();
//        try {
//            timeSeries4.add(regularTimePeriod39, (java.lang.Number) (short) -1);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(list8);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNotNull(list17);
//        org.junit.Assert.assertNotNull(collection18);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "June 2019" + "'", str22.equals("June 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "June 2019" + "'", str29.equals("June 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "10-June-2019" + "'", str35.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1561964399999L + "'", long37 == 1561964399999L);
//        org.junit.Assert.assertNotNull(year38);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(2958465);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test212() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test212");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
//        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate7 = serialDate4.getEndOfCurrentMonth(serialDate6);
//        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(3);
//        boolean boolean11 = spreadsheetDate1.isInRange(serialDate6, (org.jfree.data.time.SerialDate) spreadsheetDate10);
//        int int12 = spreadsheetDate1.getYYYY();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(3);
//        boolean boolean15 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate14);
//        java.lang.String str16 = spreadsheetDate1.getDescription();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        java.util.Date date18 = day17.getEnd();
//        int int20 = day17.compareTo((java.lang.Object) (-1L));
//        java.lang.Class class24 = null;
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class24);
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        java.lang.String str27 = day26.toString();
//        timeSeries25.delete((org.jfree.data.time.RegularTimePeriod) day26);
//        timeSeries25.fireSeriesChanged();
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        java.util.Date date31 = day30.getEnd();
//        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(date31);
//        java.lang.Number number33 = timeSeries25.getValue((org.jfree.data.time.RegularTimePeriod) month32);
//        java.lang.Class class37 = null;
//        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class37);
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day();
//        java.lang.String str40 = day39.toString();
//        timeSeries38.delete((org.jfree.data.time.RegularTimePeriod) day39);
//        boolean boolean42 = timeSeries25.equals((java.lang.Object) day39);
//        boolean boolean43 = day17.equals((java.lang.Object) timeSeries25);
//        timeSeries25.setDomainDescription("ERROR : Relative To String");
//        timeSeries25.removeAgedItems(false);
//        java.lang.Comparable comparable48 = timeSeries25.getKey();
//        timeSeries25.setDescription("");
//        org.jfree.data.time.Month month53 = new org.jfree.data.time.Month(9, (int) (byte) 0);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem55 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month53, (java.lang.Number) 3);
//        timeSeries25.delete((org.jfree.data.time.RegularTimePeriod) month53);
//        boolean boolean57 = spreadsheetDate1.equals((java.lang.Object) timeSeries25);
//        int int58 = spreadsheetDate1.getDayOfWeek();
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1900 + "'", int12 == 1900);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNull(str16);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "10-June-2019" + "'", str27.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNull(number33);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "10-June-2019" + "'", str40.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertTrue("'" + comparable48 + "' != '" + (-1.0f) + "'", comparable48.equals((-1.0f)));
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 3 + "'", int58 == 3);
//    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
        timeSeries4.setMaximumItemCount((int) (byte) 0);
        boolean boolean7 = timeSeries4.getNotify();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class11);
        timeSeries12.setDomainDescription("hi!");
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        java.util.Date date16 = day15.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day15, (java.lang.Number) 0);
        java.lang.Object obj19 = null;
        boolean boolean20 = timeSeries12.equals(obj19);
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries4.addAndOrUpdate(timeSeries12);
        int int22 = timeSeries4.getItemCount();
        try {
            java.lang.Number number24 = timeSeries4.getValue((-460));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(timeSeries21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date2);
        int int4 = timeSeries3.getItemCount();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (short) 1, 5, 2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("Tuesday");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(3);
        int int3 = spreadsheetDate2.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate11 = serialDate8.getEndOfCurrentMonth(serialDate10);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean15 = spreadsheetDate5.isInRange(serialDate10, (org.jfree.data.time.SerialDate) spreadsheetDate14);
        int int16 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate24 = serialDate21.getEndOfCurrentMonth(serialDate23);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate23);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean28 = spreadsheetDate18.isInRange(serialDate23, (org.jfree.data.time.SerialDate) spreadsheetDate27);
        boolean boolean29 = spreadsheetDate2.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate27);
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
        java.util.Date date31 = day30.getEnd();
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(date31);
        java.lang.String str33 = month32.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = month32.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month32, (double) (short) 100);
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
        java.util.Date date38 = day37.getEnd();
        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month(date38);
        java.lang.String str40 = month39.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = month39.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month39, (double) (short) 100);
        int int44 = timeSeriesDataItem36.compareTo((java.lang.Object) month39);
        timeSeriesDataItem36.setValue((java.lang.Number) 6);
        java.lang.Object obj47 = new java.lang.Object();
        int int48 = timeSeriesDataItem36.compareTo(obj47);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = timeSeriesDataItem36.getPeriod();
        boolean boolean50 = spreadsheetDate27.equals((java.lang.Object) timeSeriesDataItem36);
        int int51 = year0.compareTo((java.lang.Object) spreadsheetDate27);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate53 = new org.jfree.data.time.SpreadsheetDate(12);
        java.util.Date date54 = spreadsheetDate53.toDate();
        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day();
        java.util.Date date56 = day55.getEnd();
        org.jfree.data.time.SerialDate serialDate57 = org.jfree.data.time.SerialDate.createInstance(date56);
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(serialDate57);
        org.jfree.data.time.SerialDate serialDate60 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate62 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate63 = serialDate60.getEndOfCurrentMonth(serialDate62);
        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day(serialDate60);
        boolean boolean66 = spreadsheetDate53.isInRange(serialDate57, serialDate60, 0);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate68 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate71 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate73 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate74 = serialDate71.getEndOfCurrentMonth(serialDate73);
        org.jfree.data.time.SerialDate serialDate75 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate73);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate77 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean78 = spreadsheetDate68.isInRange(serialDate73, (org.jfree.data.time.SerialDate) spreadsheetDate77);
        int int79 = spreadsheetDate77.getYYYY();
        boolean boolean81 = spreadsheetDate27.isInRange(serialDate60, (org.jfree.data.time.SerialDate) spreadsheetDate77, (int) (short) -1);
        try {
            org.jfree.data.time.SerialDate serialDate83 = spreadsheetDate27.getNearestDayOfWeek(12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1900 + "'", int3 == 1900);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "June 2019" + "'", str33.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "June 2019" + "'", str40.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertNotNull(serialDate60);
        org.junit.Assert.assertNotNull(serialDate62);
        org.junit.Assert.assertNotNull(serialDate63);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertNotNull(serialDate71);
        org.junit.Assert.assertNotNull(serialDate73);
        org.junit.Assert.assertNotNull(serialDate74);
        org.junit.Assert.assertNotNull(serialDate75);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 1900 + "'", int79 == 1900);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
    }

//    @Test
//    public void test218() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test218");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        java.util.Date date2 = day0.getStart();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        java.util.Date date4 = day0.getEnd();
//        java.util.TimeZone timeZone5 = null;
//        try {
//            org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date4, timeZone5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertNotNull(date4);
//    }

//    @Test
//    public void test219() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test219");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setMaximumItemCount((int) (byte) 0);
//        boolean boolean7 = timeSeries4.getNotify();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class11);
//        timeSeries12.setDomainDescription("hi!");
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        java.util.Date date16 = day15.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day15, (java.lang.Number) 0);
//        java.lang.Object obj19 = null;
//        boolean boolean20 = timeSeries12.equals(obj19);
//        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries4.addAndOrUpdate(timeSeries12);
//        java.lang.Comparable comparable22 = timeSeries21.getKey();
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        java.util.Date date24 = day23.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond(date24);
//        java.util.Date date26 = fixedMillisecond25.getTime();
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        java.util.Date date28 = day27.getEnd();
//        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month(date28);
//        java.lang.String str30 = month29.toString();
//        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean32 = month29.equals((java.lang.Object) timeZone31);
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date26, timeZone31);
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date26);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond(date26);
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
//        java.lang.String str37 = day36.toString();
//        java.util.Date date38 = day36.getStart();
//        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(date38);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = year39.previous();
//        int int41 = fixedMillisecond35.compareTo((java.lang.Object) year39);
//        try {
//            timeSeries21.add((org.jfree.data.time.RegularTimePeriod) year39, (java.lang.Number) 5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNull(timeSeriesDataItem18);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(timeSeries21);
//        org.junit.Assert.assertTrue("'" + comparable22 + "' != '" + "Overwritten values from: -1.0" + "'", comparable22.equals("Overwritten values from: -1.0"));
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "June 2019" + "'", str30.equals("June 2019"));
//        org.junit.Assert.assertNotNull(timeZone31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "10-June-2019" + "'", str37.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(regularTimePeriod40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
//    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        java.util.Date date4 = day3.getEnd();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate11 = serialDate8.getEndOfCurrentMonth(serialDate10);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(serialDate8);
        boolean boolean14 = spreadsheetDate1.isInRange(serialDate5, serialDate8, 0);
        int int15 = spreadsheetDate1.getMonth();
        int int16 = spreadsheetDate1.toSerial();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 12 + "'", int16 == 12);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(date1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond3.next();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(9);
        boolean boolean5 = spreadsheetDate2.isOnOrAfter(serialDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate13 = serialDate10.getEndOfCurrentMonth(serialDate12);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean17 = spreadsheetDate7.isInRange(serialDate12, (org.jfree.data.time.SerialDate) spreadsheetDate16);
        int int18 = spreadsheetDate7.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean21 = spreadsheetDate7.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate27 = serialDate24.getEndOfCurrentMonth(serialDate26);
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.addDays(0, serialDate27);
        boolean boolean29 = spreadsheetDate7.isOnOrBefore(serialDate27);
        int int30 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate7);
        int int31 = spreadsheetDate7.getDayOfMonth();
        int int32 = spreadsheetDate7.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate(12);
        java.util.Date date35 = spreadsheetDate34.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate43 = serialDate40.getEndOfCurrentMonth(serialDate42);
        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate42);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean47 = spreadsheetDate37.isInRange(serialDate42, (org.jfree.data.time.SerialDate) spreadsheetDate46);
        org.jfree.data.time.SerialDate serialDate49 = serialDate42.getPreviousDayOfWeek(7);
        boolean boolean50 = spreadsheetDate7.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate34, serialDate49);
        org.jfree.data.time.SerialDate serialDate51 = org.jfree.data.time.SerialDate.addDays((int) (short) -1, (org.jfree.data.time.SerialDate) spreadsheetDate7);
        int int52 = spreadsheetDate7.getDayOfWeek();
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1900 + "'", int18 == 1900);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2 + "'", int31 == 2);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 3 + "'", int32 == 3);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 3 + "'", int52 == 3);
    }

//    @Test
//    public void test223() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test223");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setDomainDescription("hi!");
//        java.lang.Object obj7 = timeSeries4.clone();
//        java.lang.String str8 = timeSeries4.getDescription();
//        timeSeries4.setRangeDescription("June 2019");
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        java.util.Date date12 = day11.getEnd();
//        int int14 = day11.compareTo((java.lang.Object) (-1L));
//        org.jfree.data.time.SerialDate serialDate15 = day11.getSerialDate();
//        long long16 = day11.getLastMillisecond();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        java.lang.String str18 = day17.toString();
//        java.util.Date date19 = day17.getStart();
//        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date19);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year20.previous();
//        java.lang.String str22 = regularTimePeriod21.toString();
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) day11, regularTimePeriod21);
//        long long24 = day11.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate25 = day11.getSerialDate();
//        try {
//            org.jfree.data.time.SerialDate serialDate27 = serialDate25.getPreviousDayOfWeek(0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(obj7);
//        org.junit.Assert.assertNull(str8);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560236399999L + "'", long16 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "10-June-2019" + "'", str18.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "2018" + "'", str22.equals("2018"));
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560150000000L + "'", long24 == 1560150000000L);
//        org.junit.Assert.assertNotNull(serialDate25);
//    }

//    @Test
//    public void test224() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test224");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
//        java.util.Date date3 = fixedMillisecond2.getTime();
//        long long4 = fixedMillisecond2.getSerialIndex();
//        long long5 = fixedMillisecond2.getFirstMillisecond();
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond2.getMiddleMillisecond(calendar6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond2.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = fixedMillisecond2.previous();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560236399999L + "'", long5 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560236399999L + "'", long7 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
        timeSeries4.setMaximumItemCount((int) (byte) 0);
        boolean boolean7 = timeSeries4.getNotify();
        java.lang.Comparable comparable8 = timeSeries4.getKey();
        java.lang.Object obj9 = timeSeries4.clone();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        java.lang.String str11 = month10.toString();
        int int12 = month10.getYearValue();
        try {
            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) month10, (double) 1.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0f) + "'", comparable8.equals((-1.0f)));
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "June 2019" + "'", str11.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(9);
        boolean boolean4 = spreadsheetDate1.isOnOrAfter(serialDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate12 = serialDate9.getEndOfCurrentMonth(serialDate11);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean16 = spreadsheetDate6.isInRange(serialDate11, (org.jfree.data.time.SerialDate) spreadsheetDate15);
        int int17 = spreadsheetDate6.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean20 = spreadsheetDate6.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate26 = serialDate23.getEndOfCurrentMonth(serialDate25);
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.addDays(0, serialDate26);
        boolean boolean28 = spreadsheetDate6.isOnOrBefore(serialDate26);
        int int29 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate6);
        int int30 = spreadsheetDate1.toSerial();
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1900 + "'", int17 == 1900);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 3 + "'", int30 == 3);
    }

//    @Test
//    public void test227() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test227");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 7, "10-June-2019", "ERROR : Relative To String", class3);
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
//        int int7 = timeSeries4.getItemCount();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class11);
//        timeSeries12.setMaximumItemCount((int) (byte) 0);
//        boolean boolean15 = timeSeries12.getNotify();
//        java.util.List list16 = timeSeries12.getItems();
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class20);
//        timeSeries21.setMaximumItemCount((int) (byte) 0);
//        boolean boolean24 = timeSeries21.getNotify();
//        java.util.List list25 = timeSeries21.getItems();
//        java.util.Collection collection26 = timeSeries12.getTimePeriodsUniqueToOtherSeries(timeSeries21);
//        boolean boolean27 = timeSeries12.isEmpty();
//        timeSeries12.setDomainDescription("2019");
//        java.lang.Class class33 = null;
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class33);
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        java.lang.String str36 = day35.toString();
//        timeSeries34.delete((org.jfree.data.time.RegularTimePeriod) day35);
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
//        java.util.Date date39 = day38.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond(date39);
//        java.util.Date date41 = fixedMillisecond40.getTime();
//        long long42 = fixedMillisecond40.getSerialIndex();
//        long long43 = fixedMillisecond40.getFirstMillisecond();
//        java.util.Calendar calendar44 = null;
//        long long45 = fixedMillisecond40.getMiddleMillisecond(calendar44);
//        org.jfree.data.time.TimeSeries timeSeries46 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) day35, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond40);
//        java.util.Collection collection47 = timeSeries12.getTimePeriods();
//        int int48 = timeSeries12.getMaximumItemCount();
//        timeSeries12.setRangeDescription("June 2019");
//        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries4.addAndOrUpdate(timeSeries12);
//        java.lang.Class class55 = null;
//        org.jfree.data.time.TimeSeries timeSeries56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class55);
//        timeSeries56.setMaximumItemCount((int) (byte) 0);
//        boolean boolean59 = timeSeries56.getNotify();
//        timeSeries56.setKey((java.lang.Comparable) 10.0d);
//        java.lang.Class<?> wildcardClass62 = timeSeries56.getClass();
//        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day();
//        java.lang.String str64 = day63.toString();
//        java.util.Date date65 = day63.getStart();
//        org.jfree.data.time.Year year66 = new org.jfree.data.time.Year(date65);
//        org.jfree.data.time.Day day67 = new org.jfree.data.time.Day();
//        java.util.Date date68 = day67.getEnd();
//        org.jfree.data.time.Month month69 = new org.jfree.data.time.Month(date68);
//        java.lang.String str70 = month69.toString();
//        java.util.TimeZone timeZone71 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean72 = month69.equals((java.lang.Object) timeZone71);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass62, date65, timeZone71);
//        org.jfree.data.time.Day day74 = new org.jfree.data.time.Day();
//        java.util.Date date75 = day74.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond76 = new org.jfree.data.time.FixedMillisecond(date75);
//        java.util.Date date77 = fixedMillisecond76.getTime();
//        org.jfree.data.time.Day day78 = new org.jfree.data.time.Day();
//        java.util.Date date79 = day78.getEnd();
//        org.jfree.data.time.Month month80 = new org.jfree.data.time.Month(date79);
//        java.lang.String str81 = month80.toString();
//        java.util.TimeZone timeZone82 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean83 = month80.equals((java.lang.Object) timeZone82);
//        org.jfree.data.time.Day day84 = new org.jfree.data.time.Day(date77, timeZone82);
//        org.jfree.data.time.Month month85 = new org.jfree.data.time.Month(date65, timeZone82);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod86 = month85.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod87 = null;
//        try {
//            org.jfree.data.time.TimeSeries timeSeries88 = timeSeries51.createCopy(regularTimePeriod86, regularTimePeriod87);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'end' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertNotNull(list16);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//        org.junit.Assert.assertNotNull(list25);
//        org.junit.Assert.assertNotNull(collection26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "10-June-2019" + "'", str36.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1560236399999L + "'", long42 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1560236399999L + "'", long43 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1560236399999L + "'", long45 == 1560236399999L);
//        org.junit.Assert.assertNotNull(timeSeries46);
//        org.junit.Assert.assertNotNull(collection47);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
//        org.junit.Assert.assertNotNull(timeSeries51);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
//        org.junit.Assert.assertNotNull(wildcardClass62);
//        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "10-June-2019" + "'", str64.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date65);
//        org.junit.Assert.assertNotNull(date68);
//        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "June 2019" + "'", str70.equals("June 2019"));
//        org.junit.Assert.assertNotNull(timeZone71);
//        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
//        org.junit.Assert.assertNull(regularTimePeriod73);
//        org.junit.Assert.assertNotNull(date75);
//        org.junit.Assert.assertNotNull(date77);
//        org.junit.Assert.assertNotNull(date79);
//        org.junit.Assert.assertTrue("'" + str81 + "' != '" + "June 2019" + "'", str81.equals("June 2019"));
//        org.junit.Assert.assertNotNull(timeZone82);
//        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod86);
//    }

//    @Test
//    public void test228() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test228");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        int int3 = day0.compareTo((java.lang.Object) (-1L));
//        java.lang.Class class7 = null;
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class7);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.lang.String str10 = day9.toString();
//        timeSeries8.delete((org.jfree.data.time.RegularTimePeriod) day9);
//        timeSeries8.fireSeriesChanged();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.util.Date date14 = day13.getEnd();
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
//        java.lang.Number number16 = timeSeries8.getValue((org.jfree.data.time.RegularTimePeriod) month15);
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class20);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.lang.String str23 = day22.toString();
//        timeSeries21.delete((org.jfree.data.time.RegularTimePeriod) day22);
//        boolean boolean25 = timeSeries8.equals((java.lang.Object) day22);
//        boolean boolean26 = day0.equals((java.lang.Object) timeSeries8);
//        timeSeries8.setDomainDescription("ERROR : Relative To String");
//        timeSeries8.setMaximumItemCount(3);
//        java.lang.Class class31 = timeSeries8.getTimePeriodClass();
//        timeSeries8.setNotify(false);
//        java.lang.Class class37 = null;
//        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class37);
//        timeSeries38.setMaximumItemCount((int) (byte) 0);
//        boolean boolean41 = timeSeries38.getNotify();
//        java.util.List list42 = timeSeries38.getItems();
//        java.lang.Class class46 = null;
//        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class46);
//        timeSeries47.setMaximumItemCount((int) (byte) 0);
//        boolean boolean50 = timeSeries47.getNotify();
//        java.util.List list51 = timeSeries47.getItems();
//        java.util.Collection collection52 = timeSeries38.getTimePeriodsUniqueToOtherSeries(timeSeries47);
//        boolean boolean53 = timeSeries38.isEmpty();
//        timeSeries38.setDomainDescription("2019");
//        java.lang.Class class59 = null;
//        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class59);
//        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day();
//        java.lang.String str62 = day61.toString();
//        timeSeries60.delete((org.jfree.data.time.RegularTimePeriod) day61);
//        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day();
//        java.util.Date date65 = day64.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond66 = new org.jfree.data.time.FixedMillisecond(date65);
//        java.util.Date date67 = fixedMillisecond66.getTime();
//        long long68 = fixedMillisecond66.getSerialIndex();
//        long long69 = fixedMillisecond66.getFirstMillisecond();
//        java.util.Calendar calendar70 = null;
//        long long71 = fixedMillisecond66.getMiddleMillisecond(calendar70);
//        org.jfree.data.time.TimeSeries timeSeries72 = timeSeries38.createCopy((org.jfree.data.time.RegularTimePeriod) day61, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond66);
//        int int73 = day61.getMonth();
//        int int74 = timeSeries8.getIndex((org.jfree.data.time.RegularTimePeriod) day61);
//        boolean boolean75 = timeSeries8.getNotify();
//        java.lang.Object obj76 = timeSeries8.clone();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "10-June-2019" + "'", str23.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNull(class31);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
//        org.junit.Assert.assertNotNull(list42);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
//        org.junit.Assert.assertNotNull(list51);
//        org.junit.Assert.assertNotNull(collection52);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "10-June-2019" + "'", str62.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date65);
//        org.junit.Assert.assertNotNull(date67);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 1560236399999L + "'", long68 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 1560236399999L + "'", long69 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 1560236399999L + "'", long71 == 1560236399999L);
//        org.junit.Assert.assertNotNull(timeSeries72);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 6 + "'", int73 == 6);
//        org.junit.Assert.assertTrue("'" + int74 + "' != '" + (-1) + "'", int74 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
//        org.junit.Assert.assertNotNull(obj76);
//    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        java.lang.Comparable comparable0 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries(comparable0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test230() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test230");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setDomainDescription("hi!");
//        java.lang.Object obj7 = timeSeries4.clone();
//        timeSeries4.setRangeDescription("10-June-2019");
//        timeSeries4.setNotify(true);
//        java.lang.Class class15 = null;
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class15);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        java.lang.String str18 = day17.toString();
//        timeSeries16.delete((org.jfree.data.time.RegularTimePeriod) day17);
//        timeSeries16.fireSeriesChanged();
//        timeSeries16.removeAgedItems(false);
//        java.lang.Class class26 = null;
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class26);
//        timeSeries27.setMaximumItemCount((int) (byte) 0);
//        boolean boolean30 = timeSeries27.getNotify();
//        java.util.List list31 = timeSeries27.getItems();
//        java.lang.Class class35 = null;
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class35);
//        timeSeries36.setMaximumItemCount((int) (byte) 0);
//        boolean boolean39 = timeSeries36.getNotify();
//        java.util.List list40 = timeSeries36.getItems();
//        java.util.Collection collection41 = timeSeries27.getTimePeriodsUniqueToOtherSeries(timeSeries36);
//        boolean boolean42 = timeSeries27.isEmpty();
//        timeSeries27.setDomainDescription("2019");
//        java.lang.Class class48 = null;
//        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class48);
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day();
//        java.lang.String str51 = day50.toString();
//        timeSeries49.delete((org.jfree.data.time.RegularTimePeriod) day50);
//        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day();
//        java.util.Date date54 = day53.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond55 = new org.jfree.data.time.FixedMillisecond(date54);
//        java.util.Date date56 = fixedMillisecond55.getTime();
//        long long57 = fixedMillisecond55.getSerialIndex();
//        long long58 = fixedMillisecond55.getFirstMillisecond();
//        java.util.Calendar calendar59 = null;
//        long long60 = fixedMillisecond55.getMiddleMillisecond(calendar59);
//        org.jfree.data.time.TimeSeries timeSeries61 = timeSeries27.createCopy((org.jfree.data.time.RegularTimePeriod) day50, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond55);
//        java.util.Collection collection62 = timeSeries27.getTimePeriods();
//        int int63 = timeSeries27.getMaximumItemCount();
//        java.util.Collection collection64 = timeSeries16.getTimePeriodsUniqueToOtherSeries(timeSeries27);
//        timeSeries27.setDomainDescription("Monday");
//        java.util.Collection collection67 = timeSeries27.getTimePeriods();
//        java.util.Collection collection68 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries27);
//        org.junit.Assert.assertNotNull(obj7);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "10-June-2019" + "'", str18.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
//        org.junit.Assert.assertNotNull(list31);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
//        org.junit.Assert.assertNotNull(list40);
//        org.junit.Assert.assertNotNull(collection41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "10-June-2019" + "'", str51.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 1560236399999L + "'", long57 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1560236399999L + "'", long58 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1560236399999L + "'", long60 == 1560236399999L);
//        org.junit.Assert.assertNotNull(timeSeries61);
//        org.junit.Assert.assertNotNull(collection62);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
//        org.junit.Assert.assertNotNull(collection64);
//        org.junit.Assert.assertNotNull(collection67);
//        org.junit.Assert.assertNotNull(collection68);
//    }

//    @Test
//    public void test231() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test231");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setMaximumItemCount((int) (byte) 0);
//        boolean boolean7 = timeSeries4.getNotify();
//        java.util.List list8 = timeSeries4.getItems();
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class12);
//        timeSeries13.setMaximumItemCount((int) (byte) 0);
//        boolean boolean16 = timeSeries13.getNotify();
//        java.util.List list17 = timeSeries13.getItems();
//        java.util.Collection collection18 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries13);
//        boolean boolean19 = timeSeries4.isEmpty();
//        timeSeries4.setDomainDescription("2019");
//        java.lang.Class<?> wildcardClass22 = timeSeries4.getClass();
//        java.lang.Class class23 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass22);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        java.util.Date date25 = day24.getEnd();
//        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(date25);
//        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date25);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond(date25);
//        java.lang.Class class32 = null;
//        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class32);
//        timeSeries33.setMaximumItemCount((int) (byte) 0);
//        boolean boolean36 = timeSeries33.getNotify();
//        timeSeries33.setKey((java.lang.Comparable) 10.0d);
//        java.lang.Class<?> wildcardClass39 = timeSeries33.getClass();
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day();
//        java.lang.String str41 = day40.toString();
//        java.util.Date date42 = day40.getStart();
//        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year(date42);
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day();
//        java.util.Date date45 = day44.getEnd();
//        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month(date45);
//        java.lang.String str47 = month46.toString();
//        java.util.TimeZone timeZone48 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean49 = month46.equals((java.lang.Object) timeZone48);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass39, date42, timeZone48);
//        java.lang.Class class51 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass39);
//        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day();
//        java.util.Date date53 = day52.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond(date53);
//        java.util.Date date55 = fixedMillisecond54.getTime();
//        java.lang.Class class59 = null;
//        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class59);
//        timeSeries60.setMaximumItemCount((int) (byte) 0);
//        boolean boolean63 = timeSeries60.getNotify();
//        timeSeries60.setKey((java.lang.Comparable) 10.0d);
//        java.lang.Class<?> wildcardClass66 = timeSeries60.getClass();
//        org.jfree.data.time.Day day67 = new org.jfree.data.time.Day();
//        java.lang.String str68 = day67.toString();
//        java.util.Date date69 = day67.getStart();
//        org.jfree.data.time.Year year70 = new org.jfree.data.time.Year(date69);
//        org.jfree.data.time.Day day71 = new org.jfree.data.time.Day();
//        java.util.Date date72 = day71.getEnd();
//        org.jfree.data.time.Month month73 = new org.jfree.data.time.Month(date72);
//        java.lang.String str74 = month73.toString();
//        java.util.TimeZone timeZone75 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean76 = month73.equals((java.lang.Object) timeZone75);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass66, date69, timeZone75);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass39, date55, timeZone75);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass22, date25, timeZone75);
//        org.jfree.data.time.SerialDate serialDate80 = org.jfree.data.time.SerialDate.createInstance(date25);
//        org.jfree.data.time.SerialDate serialDate82 = serialDate80.getPreviousDayOfWeek(3);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(list8);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNotNull(list17);
//        org.junit.Assert.assertNotNull(collection18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertNotNull(wildcardClass22);
//        org.junit.Assert.assertNotNull(class23);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
//        org.junit.Assert.assertNotNull(wildcardClass39);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "10-June-2019" + "'", str41.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "June 2019" + "'", str47.equals("June 2019"));
//        org.junit.Assert.assertNotNull(timeZone48);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertNull(regularTimePeriod50);
//        org.junit.Assert.assertNotNull(class51);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertNotNull(date55);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
//        org.junit.Assert.assertNotNull(wildcardClass66);
//        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "10-June-2019" + "'", str68.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date69);
//        org.junit.Assert.assertNotNull(date72);
//        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "June 2019" + "'", str74.equals("June 2019"));
//        org.junit.Assert.assertNotNull(timeZone75);
//        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
//        org.junit.Assert.assertNull(regularTimePeriod77);
//        org.junit.Assert.assertNull(regularTimePeriod78);
//        org.junit.Assert.assertNull(regularTimePeriod79);
//        org.junit.Assert.assertNotNull(serialDate80);
//        org.junit.Assert.assertNotNull(serialDate82);
//    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        java.lang.String str3 = month2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (double) (short) 100);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        java.util.Date date8 = day7.getEnd();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date8);
        java.lang.String str10 = month9.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month9, (double) (short) 100);
        int int14 = timeSeriesDataItem6.compareTo((java.lang.Object) month9);
        timeSeriesDataItem6.setValue((java.lang.Number) 6);
        java.lang.Object obj17 = new java.lang.Object();
        int int18 = timeSeriesDataItem6.compareTo(obj17);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int18);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "June 2019" + "'", str10.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

//    @Test
//    public void test233() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test233");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        java.util.Date date2 = day0.getStart();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        java.lang.Class<?> wildcardClass4 = day0.getClass();
//        long long5 = day0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560150000000L + "'", long5 == 1560150000000L);
//    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(3);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) 'a', (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(2019, (int) '#', 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test237() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test237");
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        java.util.Date date2 = day1.getEnd();
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
//        java.lang.String str4 = month3.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month3, (double) (short) 100);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.util.Date date9 = day8.getEnd();
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date9);
//        java.lang.String str11 = month10.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month10.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month10, (double) (short) 100);
//        int int15 = timeSeriesDataItem7.compareTo((java.lang.Object) month10);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        java.lang.String str17 = day16.toString();
//        int int18 = month10.compareTo((java.lang.Object) str17);
//        long long19 = month10.getLastMillisecond();
//        org.jfree.data.time.Year year20 = month10.getYear();
//        long long21 = year20.getFirstMillisecond();
//        long long22 = year20.getFirstMillisecond();
//        try {
//            org.jfree.data.time.Month month23 = new org.jfree.data.time.Month((int) (short) 100, year20);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "June 2019" + "'", str11.equals("June 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "10-June-2019" + "'", str17.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1561964399999L + "'", long19 == 1561964399999L);
//        org.junit.Assert.assertNotNull(year20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1546329600000L + "'", long21 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1546329600000L + "'", long22 == 1546329600000L);
//    }

//    @Test
//    public void test238() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test238");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setDomainDescription("hi!");
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        java.util.Date date8 = day7.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) 0);
//        java.lang.Object obj11 = null;
//        boolean boolean12 = timeSeries4.equals(obj11);
//        timeSeries4.removeAgedItems(false);
//        java.lang.Class class18 = null;
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class18);
//        timeSeries19.setMaximumItemCount((int) (byte) 0);
//        boolean boolean22 = timeSeries19.getNotify();
//        java.util.List list23 = timeSeries19.getItems();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent24 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeries19);
//        java.util.Collection collection25 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries19);
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        java.util.Date date27 = day26.getEnd();
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(date27);
//        java.lang.String str29 = month28.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = month28.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month28, (double) (short) 100);
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        java.util.Date date34 = day33.getEnd();
//        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(date34);
//        java.lang.String str36 = month35.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = month35.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month35, (double) (short) 100);
//        int int40 = timeSeriesDataItem32.compareTo((java.lang.Object) month35);
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
//        java.lang.String str42 = day41.toString();
//        int int43 = month35.compareTo((java.lang.Object) str42);
//        long long44 = month35.getLastMillisecond();
//        org.jfree.data.time.Year year45 = month35.getYear();
//        long long46 = year45.getFirstMillisecond();
//        int int47 = year45.getYear();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) year45);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(timeSeriesDataItem10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertNotNull(list23);
//        org.junit.Assert.assertNotNull(collection25);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "June 2019" + "'", str29.equals("June 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "June 2019" + "'", str36.equals("June 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "10-June-2019" + "'", str42.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1561964399999L + "'", long44 == 1561964399999L);
//        org.junit.Assert.assertNotNull(year45);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1546329600000L + "'", long46 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 2019 + "'", int47 == 2019);
//    }

//    @Test
//    public void test239() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test239");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setMaximumItemCount((int) (byte) 0);
//        boolean boolean7 = timeSeries4.getNotify();
//        java.util.List list8 = timeSeries4.getItems();
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class12);
//        timeSeries13.setMaximumItemCount((int) (byte) 0);
//        boolean boolean16 = timeSeries13.getNotify();
//        java.util.List list17 = timeSeries13.getItems();
//        java.util.Collection collection18 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries13);
//        java.util.List list19 = timeSeries4.getItems();
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        java.util.Date date21 = day20.getEnd();
//        int int23 = day20.compareTo((java.lang.Object) (-1L));
//        java.lang.Class class27 = null;
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class27);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        java.lang.String str30 = day29.toString();
//        timeSeries28.delete((org.jfree.data.time.RegularTimePeriod) day29);
//        timeSeries28.fireSeriesChanged();
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        java.util.Date date34 = day33.getEnd();
//        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(date34);
//        java.lang.Number number36 = timeSeries28.getValue((org.jfree.data.time.RegularTimePeriod) month35);
//        java.lang.Class class40 = null;
//        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class40);
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
//        java.lang.String str43 = day42.toString();
//        timeSeries41.delete((org.jfree.data.time.RegularTimePeriod) day42);
//        boolean boolean45 = timeSeries28.equals((java.lang.Object) day42);
//        boolean boolean46 = day20.equals((java.lang.Object) timeSeries28);
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
//        java.lang.String str48 = day47.toString();
//        java.util.Date date49 = day47.getStart();
//        long long50 = day47.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) day20, (org.jfree.data.time.RegularTimePeriod) day47);
//        java.lang.Object obj52 = timeSeries51.clone();
//        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day();
//        java.lang.String str55 = day54.toString();
//        java.util.Date date56 = day54.getStart();
//        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year(date56);
//        java.lang.Object obj58 = null;
//        int int59 = year57.compareTo(obj58);
//        int int60 = year57.getYear();
//        org.jfree.data.time.Month month61 = new org.jfree.data.time.Month(2, year57);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem63 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year57, (java.lang.Number) 1560150000000L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = timeSeriesDataItem63.getPeriod();
//        try {
//            timeSeries51.add(timeSeriesDataItem63, true);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(list8);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNotNull(list17);
//        org.junit.Assert.assertNotNull(collection18);
//        org.junit.Assert.assertNotNull(list19);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "10-June-2019" + "'", str30.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNull(number36);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "10-June-2019" + "'", str43.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "10-June-2019" + "'", str48.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1560236399999L + "'", long50 == 1560236399999L);
//        org.junit.Assert.assertNotNull(timeSeries51);
//        org.junit.Assert.assertNotNull(obj52);
//        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "10-June-2019" + "'", str55.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 2019 + "'", int60 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod64);
//    }

//    @Test
//    public void test240() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test240");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setDomainDescription("hi!");
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        java.util.Date date8 = day7.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) 0);
//        java.lang.Object obj11 = null;
//        boolean boolean12 = timeSeries4.equals(obj11);
//        timeSeries4.setDescription("10-June-2019");
//        timeSeries4.setDomainDescription("ERROR : Relative To String");
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        java.util.Date date18 = day17.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond(date18);
//        java.util.Date date20 = fixedMillisecond19.getTime();
//        long long21 = fixedMillisecond19.getSerialIndex();
//        long long22 = fixedMillisecond19.getFirstMillisecond();
//        java.util.Calendar calendar23 = null;
//        fixedMillisecond19.peg(calendar23);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
//        try {
//            java.lang.Number number27 = timeSeries4.getValue((int) (short) 10);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(timeSeriesDataItem10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560236399999L + "'", long21 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560236399999L + "'", long22 == 1560236399999L);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem25);
//    }

//    @Test
//    public void test241() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test241");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setDomainDescription("hi!");
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        java.util.Date date8 = day7.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) 0);
//        timeSeries4.setDescription("");
//        timeSeries4.setNotify(true);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        java.lang.String str16 = day15.toString();
//        java.util.Date date17 = day15.getStart();
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date17);
//        java.lang.Object obj19 = null;
//        int int20 = year18.compareTo(obj19);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) year18);
//        long long22 = year18.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year18.previous();
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(timeSeriesDataItem10);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "10-June-2019" + "'", str16.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem21);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1577865599999L + "'", long22 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        java.lang.String str3 = month2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (double) (short) 100);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        java.util.Date date8 = day7.getEnd();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date8);
        java.lang.String str10 = month9.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month9, (double) (short) 100);
        int int14 = timeSeriesDataItem6.compareTo((java.lang.Object) month9);
        timeSeriesDataItem6.setValue((java.lang.Number) 6);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate22 = serialDate19.getEndOfCurrentMonth(serialDate21);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate21);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(serialDate23);
        boolean boolean25 = timeSeriesDataItem6.equals((java.lang.Object) serialDate23);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = timeSeriesDataItem6.getPeriod();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = timeSeriesDataItem6.getPeriod();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "June 2019" + "'", str10.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
    }

//    @Test
//    public void test243() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test243");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setMaximumItemCount((int) (byte) 0);
//        boolean boolean7 = timeSeries4.getNotify();
//        timeSeries4.setKey((java.lang.Comparable) 10.0d);
//        java.lang.Class<?> wildcardClass10 = timeSeries4.getClass();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        java.lang.String str12 = day11.toString();
//        java.util.Date date13 = day11.getStart();
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date13);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        java.util.Date date16 = day15.getEnd();
//        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date16);
//        java.lang.String str18 = month17.toString();
//        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean20 = month17.equals((java.lang.Object) timeZone19);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date13, timeZone19);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.util.Date date23 = day22.getEnd();
//        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(date23);
//        java.lang.Class class28 = null;
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class28);
//        timeSeries29.setMaximumItemCount((int) (byte) 0);
//        boolean boolean32 = timeSeries29.getNotify();
//        timeSeries29.setKey((java.lang.Comparable) 10.0d);
//        java.lang.Class<?> wildcardClass35 = timeSeries29.getClass();
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
//        java.lang.String str37 = day36.toString();
//        java.util.Date date38 = day36.getStart();
//        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(date38);
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day();
//        java.util.Date date41 = day40.getEnd();
//        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month(date41);
//        java.lang.String str43 = month42.toString();
//        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean45 = month42.equals((java.lang.Object) timeZone44);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass35, date38, timeZone44);
//        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month(date23, timeZone44);
//        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year(date13, timeZone44);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = year48.previous();
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10-June-2019" + "'", str12.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "June 2019" + "'", str18.equals("June 2019"));
//        org.junit.Assert.assertNotNull(timeZone19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
//        org.junit.Assert.assertNotNull(wildcardClass35);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "10-June-2019" + "'", str37.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "June 2019" + "'", str43.equals("June 2019"));
//        org.junit.Assert.assertNotNull(timeZone44);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertNull(regularTimePeriod46);
//        org.junit.Assert.assertNotNull(regularTimePeriod49);
//    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
        timeSeries4.setDomainDescription("hi!");
        java.lang.Object obj7 = timeSeries4.clone();
        timeSeries4.setRangeDescription("10-June-2019");
        java.lang.Class class10 = timeSeries4.getTimePeriodClass();
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener11);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        java.util.Date date14 = day13.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(date14);
        java.util.Date date16 = fixedMillisecond15.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond(date16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = fixedMillisecond17.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries4.addOrUpdate(regularTimePeriod18, (double) 3);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNull(class10);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
    }

//    @Test
//    public void test246() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test246");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setDomainDescription("hi!");
//        java.lang.Object obj7 = timeSeries4.clone();
//        java.lang.String str8 = timeSeries4.getDescription();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.lang.String str10 = day9.toString();
//        java.util.Date date11 = day9.getStart();
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
//        long long13 = year12.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year12, (java.lang.Number) 100.0f);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        java.lang.String str17 = day16.toString();
//        java.util.Date date18 = day16.getStart();
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date18);
//        java.lang.Object obj20 = null;
//        int int21 = year19.compareTo(obj20);
//        java.lang.String str22 = year19.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year19.previous();
//        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) year12, (org.jfree.data.time.RegularTimePeriod) year19);
//        boolean boolean25 = timeSeries4.getNotify();
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        java.lang.String str27 = day26.toString();
//        java.util.Date date28 = day26.getStart();
//        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date28);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = year29.previous();
//        long long31 = year29.getFirstMillisecond();
//        long long32 = year29.getFirstMillisecond();
//        long long33 = year29.getFirstMillisecond();
//        long long34 = year29.getFirstMillisecond();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) year29);
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
//        java.lang.String str37 = day36.toString();
//        java.util.Date date38 = day36.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond(date38);
//        java.lang.Class class43 = null;
//        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class43);
//        timeSeries44.setMaximumItemCount((int) (byte) 0);
//        boolean boolean47 = timeSeries44.getNotify();
//        java.util.List list48 = timeSeries44.getItems();
//        java.lang.Class class52 = null;
//        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class52);
//        timeSeries53.setMaximumItemCount((int) (byte) 0);
//        boolean boolean56 = timeSeries53.getNotify();
//        java.util.List list57 = timeSeries53.getItems();
//        java.util.Collection collection58 = timeSeries44.getTimePeriodsUniqueToOtherSeries(timeSeries53);
//        java.util.List list59 = timeSeries44.getItems();
//        boolean boolean60 = fixedMillisecond39.equals((java.lang.Object) timeSeries44);
//        long long61 = fixedMillisecond39.getMiddleMillisecond();
//        java.util.Calendar calendar62 = null;
//        long long63 = fixedMillisecond39.getFirstMillisecond(calendar62);
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39);
//        org.junit.Assert.assertNotNull(obj7);
//        org.junit.Assert.assertNull(str8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "10-June-2019" + "'", str17.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "2019" + "'", str22.equals("2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(timeSeries24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "10-June-2019" + "'", str27.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1546329600000L + "'", long31 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1546329600000L + "'", long32 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1546329600000L + "'", long33 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1546329600000L + "'", long34 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "10-June-2019" + "'", str37.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
//        org.junit.Assert.assertNotNull(list48);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
//        org.junit.Assert.assertNotNull(list57);
//        org.junit.Assert.assertNotNull(collection58);
//        org.junit.Assert.assertNotNull(list59);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 1560150000000L + "'", long61 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 1560150000000L + "'", long63 == 1560150000000L);
//    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate5 = serialDate2.getEndOfCurrentMonth(serialDate4);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate4);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(9);
        boolean boolean12 = spreadsheetDate9.isOnOrAfter(serialDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate20 = serialDate17.getEndOfCurrentMonth(serialDate19);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate19);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean24 = spreadsheetDate14.isInRange(serialDate19, (org.jfree.data.time.SerialDate) spreadsheetDate23);
        int int25 = spreadsheetDate14.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean28 = spreadsheetDate14.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate27);
        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate34 = serialDate31.getEndOfCurrentMonth(serialDate33);
        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.addDays(0, serialDate34);
        boolean boolean36 = spreadsheetDate14.isOnOrBefore(serialDate34);
        int int37 = spreadsheetDate9.compare((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SerialDate serialDate38 = serialDate6.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate14);
        java.util.Date date39 = spreadsheetDate14.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate46 = serialDate43.getEndOfCurrentMonth(serialDate45);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate(12);
        java.util.Date date49 = spreadsheetDate48.toDate();
        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day();
        java.util.Date date51 = day50.getEnd();
        org.jfree.data.time.SerialDate serialDate52 = org.jfree.data.time.SerialDate.createInstance(date51);
        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day(serialDate52);
        org.jfree.data.time.SerialDate serialDate55 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate57 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate58 = serialDate55.getEndOfCurrentMonth(serialDate57);
        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day(serialDate55);
        boolean boolean61 = spreadsheetDate48.isInRange(serialDate52, serialDate55, 0);
        boolean boolean62 = spreadsheetDate41.isInRange(serialDate45, serialDate52);
        org.jfree.data.time.SerialDate serialDate63 = spreadsheetDate14.getEndOfCurrentMonth(serialDate52);
        try {
            org.jfree.data.time.SerialDate serialDate65 = serialDate63.getPreviousDayOfWeek((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1900 + "'", int25 == 1900);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(serialDate38);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNotNull(serialDate52);
        org.junit.Assert.assertNotNull(serialDate55);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertNotNull(serialDate58);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNotNull(serialDate63);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        java.lang.String str3 = month2.toString();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean5 = month2.equals((java.lang.Object) timeZone4);
        int int6 = month2.getMonth();
        long long7 = month2.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month2.next();
        java.util.Date date9 = month2.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month2.previous();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1561964399999L + "'", long7 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        java.lang.String str3 = month2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (double) (short) 100);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        java.util.Date date8 = day7.getEnd();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date8);
        java.lang.String str10 = month9.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month9, (double) (short) 100);
        int int14 = timeSeriesDataItem6.compareTo((java.lang.Object) month9);
        timeSeriesDataItem6.setValue((java.lang.Number) 100);
        java.lang.Object obj17 = timeSeriesDataItem6.clone();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "June 2019" + "'", str10.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(obj17);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(9);
        boolean boolean4 = spreadsheetDate1.isOnOrAfter(serialDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate12 = serialDate9.getEndOfCurrentMonth(serialDate11);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean16 = spreadsheetDate6.isInRange(serialDate11, (org.jfree.data.time.SerialDate) spreadsheetDate15);
        int int17 = spreadsheetDate6.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean20 = spreadsheetDate6.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate26 = serialDate23.getEndOfCurrentMonth(serialDate25);
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate25);
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(serialDate27);
        serialDate27.setDescription("January");
        boolean boolean31 = spreadsheetDate6.isOnOrBefore(serialDate27);
        boolean boolean32 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate42 = serialDate39.getEndOfCurrentMonth(serialDate41);
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate41);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean46 = spreadsheetDate36.isInRange(serialDate41, (org.jfree.data.time.SerialDate) spreadsheetDate45);
        int int47 = spreadsheetDate36.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate49 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean50 = spreadsheetDate36.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate49);
        org.jfree.data.time.SerialDate serialDate53 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate55 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate56 = serialDate53.getEndOfCurrentMonth(serialDate55);
        org.jfree.data.time.SerialDate serialDate57 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate55);
        boolean boolean58 = spreadsheetDate49.isOnOrAfter(serialDate55);
        org.jfree.data.time.SerialDate serialDate59 = org.jfree.data.time.SerialDate.addYears(0, (org.jfree.data.time.SerialDate) spreadsheetDate49);
        org.jfree.data.time.SerialDate serialDate60 = org.jfree.data.time.SerialDate.addDays(10, (org.jfree.data.time.SerialDate) spreadsheetDate49);
        boolean boolean61 = spreadsheetDate6.isOnOrBefore(serialDate60);
        int int62 = spreadsheetDate6.getDayOfMonth();
        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1900 + "'", int17 == 1900);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1900 + "'", int47 == 1900);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(serialDate53);
        org.junit.Assert.assertNotNull(serialDate55);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(serialDate59);
        org.junit.Assert.assertNotNull(serialDate60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 2 + "'", int62 == 2);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate7 = serialDate4.getEndOfCurrentMonth(serialDate6);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean11 = spreadsheetDate1.isInRange(serialDate6, (org.jfree.data.time.SerialDate) spreadsheetDate10);
        int int12 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean15 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate21 = serialDate18.getEndOfCurrentMonth(serialDate20);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addDays(0, serialDate21);
        boolean boolean23 = spreadsheetDate1.isOnOrBefore(serialDate21);
        int int24 = spreadsheetDate1.getYYYY();
        int int25 = spreadsheetDate1.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.createInstance(9);
        boolean boolean30 = spreadsheetDate27.isOnOrAfter(serialDate29);
        boolean boolean31 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate27);
        int int32 = spreadsheetDate27.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate40 = serialDate37.getEndOfCurrentMonth(serialDate39);
        org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate39);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean44 = spreadsheetDate34.isInRange(serialDate39, (org.jfree.data.time.SerialDate) spreadsheetDate43);
        int int45 = spreadsheetDate34.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean48 = spreadsheetDate34.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate47);
        org.jfree.data.time.SerialDate serialDate51 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate53 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate54 = serialDate51.getEndOfCurrentMonth(serialDate53);
        org.jfree.data.time.SerialDate serialDate55 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate53);
        boolean boolean56 = spreadsheetDate47.isOnOrAfter(serialDate53);
        boolean boolean57 = spreadsheetDate27.isOnOrBefore(serialDate53);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1900 + "'", int12 == 1900);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1900 + "'", int24 == 1900);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2 + "'", int25 == 2);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1900 + "'", int45 == 1900);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertNotNull(serialDate53);
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertNotNull(serialDate55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
    }

//    @Test
//    public void test252() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test252");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        java.util.Date date2 = day0.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date2);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date2);
//    }

//    @Test
//    public void test253() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test253");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setMaximumItemCount((int) (byte) 0);
//        boolean boolean7 = timeSeries4.getNotify();
//        java.lang.Comparable comparable8 = timeSeries4.getKey();
//        timeSeries4.setNotify(false);
//        boolean boolean11 = timeSeries4.isEmpty();
//        java.lang.String str12 = timeSeries4.getDescription();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.util.Date date14 = day13.getEnd();
//        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance(date14);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(serialDate15);
//        long long17 = day16.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) day16);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0f) + "'", comparable8.equals((-1.0f)));
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertNull(str12);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560150000000L + "'", long17 == 1560150000000L);
//        org.junit.Assert.assertNull(timeSeriesDataItem18);
//    }

//    @Test
//    public void test254() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test254");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setMaximumItemCount((int) (byte) 0);
//        boolean boolean7 = timeSeries4.getNotify();
//        java.util.List list8 = timeSeries4.getItems();
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class12);
//        timeSeries13.setMaximumItemCount((int) (byte) 0);
//        boolean boolean16 = timeSeries13.getNotify();
//        java.util.List list17 = timeSeries13.getItems();
//        java.util.Collection collection18 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries13);
//        boolean boolean19 = timeSeries4.isEmpty();
//        timeSeries4.setDomainDescription("2019");
//        java.lang.Class class25 = null;
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class25);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        java.lang.String str28 = day27.toString();
//        timeSeries26.delete((org.jfree.data.time.RegularTimePeriod) day27);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        java.util.Date date31 = day30.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond(date31);
//        java.util.Date date33 = fixedMillisecond32.getTime();
//        long long34 = fixedMillisecond32.getSerialIndex();
//        long long35 = fixedMillisecond32.getFirstMillisecond();
//        java.util.Calendar calendar36 = null;
//        long long37 = fixedMillisecond32.getMiddleMillisecond(calendar36);
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) day27, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond32);
//        java.lang.Class class42 = null;
//        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class42);
//        timeSeries43.setDomainDescription("hi!");
//        java.lang.Object obj46 = timeSeries43.clone();
//        java.lang.String str47 = timeSeries43.getDescription();
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
//        java.lang.String str49 = day48.toString();
//        java.util.Date date50 = day48.getStart();
//        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year(date50);
//        long long52 = year51.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem54 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year51, (java.lang.Number) 100.0f);
//        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day();
//        java.lang.String str56 = day55.toString();
//        java.util.Date date57 = day55.getStart();
//        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year(date57);
//        java.lang.Object obj59 = null;
//        int int60 = year58.compareTo(obj59);
//        java.lang.String str61 = year58.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = year58.previous();
//        org.jfree.data.time.TimeSeries timeSeries63 = timeSeries43.createCopy((org.jfree.data.time.RegularTimePeriod) year51, (org.jfree.data.time.RegularTimePeriod) year58);
//        boolean boolean64 = timeSeries43.getNotify();
//        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day();
//        java.lang.String str66 = day65.toString();
//        java.util.Date date67 = day65.getStart();
//        org.jfree.data.time.Year year68 = new org.jfree.data.time.Year(date67);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = year68.previous();
//        long long70 = year68.getFirstMillisecond();
//        long long71 = year68.getFirstMillisecond();
//        long long72 = year68.getFirstMillisecond();
//        long long73 = year68.getFirstMillisecond();
//        timeSeries43.delete((org.jfree.data.time.RegularTimePeriod) year68);
//        int int75 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) year68);
//        long long76 = year68.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(list8);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNotNull(list17);
//        org.junit.Assert.assertNotNull(collection18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "10-June-2019" + "'", str28.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560236399999L + "'", long34 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560236399999L + "'", long35 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560236399999L + "'", long37 == 1560236399999L);
//        org.junit.Assert.assertNotNull(timeSeries38);
//        org.junit.Assert.assertNotNull(obj46);
//        org.junit.Assert.assertNull(str47);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "10-June-2019" + "'", str49.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1577865599999L + "'", long52 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "10-June-2019" + "'", str56.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date57);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1 + "'", int60 == 1);
//        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "2019" + "'", str61.equals("2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod62);
//        org.junit.Assert.assertNotNull(timeSeries63);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
//        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "10-June-2019" + "'", str66.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date67);
//        org.junit.Assert.assertNotNull(regularTimePeriod69);
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 1546329600000L + "'", long70 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 1546329600000L + "'", long71 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 1546329600000L + "'", long72 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 1546329600000L + "'", long73 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int75 + "' != '" + (-1) + "'", int75 == (-1));
//        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 1546329600000L + "'", long76 == 1546329600000L);
//    }

//    @Test
//    public void test255() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test255");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setMaximumItemCount((int) (byte) 0);
//        boolean boolean7 = timeSeries4.getNotify();
//        java.util.List list8 = timeSeries4.getItems();
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class12);
//        timeSeries13.setMaximumItemCount((int) (byte) 0);
//        boolean boolean16 = timeSeries13.getNotify();
//        java.util.List list17 = timeSeries13.getItems();
//        java.util.Collection collection18 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries13);
//        boolean boolean19 = timeSeries4.isEmpty();
//        timeSeries4.setDomainDescription("2019");
//        java.lang.Class class25 = null;
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class25);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        java.lang.String str28 = day27.toString();
//        timeSeries26.delete((org.jfree.data.time.RegularTimePeriod) day27);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        java.util.Date date31 = day30.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond(date31);
//        java.util.Date date33 = fixedMillisecond32.getTime();
//        long long34 = fixedMillisecond32.getSerialIndex();
//        long long35 = fixedMillisecond32.getFirstMillisecond();
//        java.util.Calendar calendar36 = null;
//        long long37 = fixedMillisecond32.getMiddleMillisecond(calendar36);
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) day27, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond32);
//        java.lang.Class class42 = null;
//        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class42);
//        timeSeries43.setDomainDescription("hi!");
//        java.lang.Object obj46 = timeSeries43.clone();
//        java.lang.String str47 = timeSeries43.getDescription();
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
//        java.lang.String str49 = day48.toString();
//        java.util.Date date50 = day48.getStart();
//        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year(date50);
//        long long52 = year51.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem54 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year51, (java.lang.Number) 100.0f);
//        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day();
//        java.lang.String str56 = day55.toString();
//        java.util.Date date57 = day55.getStart();
//        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year(date57);
//        java.lang.Object obj59 = null;
//        int int60 = year58.compareTo(obj59);
//        java.lang.String str61 = year58.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = year58.previous();
//        org.jfree.data.time.TimeSeries timeSeries63 = timeSeries43.createCopy((org.jfree.data.time.RegularTimePeriod) year51, (org.jfree.data.time.RegularTimePeriod) year58);
//        boolean boolean64 = timeSeries43.getNotify();
//        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day();
//        java.lang.String str66 = day65.toString();
//        java.util.Date date67 = day65.getStart();
//        org.jfree.data.time.Year year68 = new org.jfree.data.time.Year(date67);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = year68.previous();
//        long long70 = year68.getFirstMillisecond();
//        long long71 = year68.getFirstMillisecond();
//        long long72 = year68.getFirstMillisecond();
//        long long73 = year68.getFirstMillisecond();
//        timeSeries43.delete((org.jfree.data.time.RegularTimePeriod) year68);
//        int int75 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) year68);
//        java.lang.String str76 = year68.toString();
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(list8);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNotNull(list17);
//        org.junit.Assert.assertNotNull(collection18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "10-June-2019" + "'", str28.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560236399999L + "'", long34 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560236399999L + "'", long35 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560236399999L + "'", long37 == 1560236399999L);
//        org.junit.Assert.assertNotNull(timeSeries38);
//        org.junit.Assert.assertNotNull(obj46);
//        org.junit.Assert.assertNull(str47);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "10-June-2019" + "'", str49.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1577865599999L + "'", long52 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "10-June-2019" + "'", str56.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date57);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1 + "'", int60 == 1);
//        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "2019" + "'", str61.equals("2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod62);
//        org.junit.Assert.assertNotNull(timeSeries63);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
//        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "10-June-2019" + "'", str66.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date67);
//        org.junit.Assert.assertNotNull(regularTimePeriod69);
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 1546329600000L + "'", long70 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 1546329600000L + "'", long71 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 1546329600000L + "'", long72 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 1546329600000L + "'", long73 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int75 + "' != '" + (-1) + "'", int75 == (-1));
//        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "2019" + "'", str76.equals("2019"));
//    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '#');
    }

//    @Test
//    public void test257() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test257");
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        java.lang.String str3 = day2.toString();
//        java.util.Date date4 = day2.getStart();
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
//        java.lang.Object obj6 = null;
//        int int7 = year5.compareTo(obj6);
//        int int8 = year5.getYear();
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(2, year5);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 1560150000000L);
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(6, year5);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10-June-2019" + "'", str3.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//    }

//    @Test
//    public void test258() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test258");
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        java.lang.String str4 = day3.toString();
//        java.util.Date date5 = day3.getStart();
//        org.jfree.data.time.SerialDate serialDate6 = day3.getSerialDate();
//        java.lang.Class<?> wildcardClass7 = day3.getClass();
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 1, "org.jfree.data.time.TimePeriodFormatException: ", "2-January-1900", (java.lang.Class) wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10-June-2019" + "'", str4.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("Nearest");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate7 = serialDate4.getEndOfCurrentMonth(serialDate6);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean11 = spreadsheetDate1.isInRange(serialDate6, (org.jfree.data.time.SerialDate) spreadsheetDate10);
        int int12 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean15 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate20 = serialDate17.getEndOfCurrentMonth(serialDate19);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(serialDate17);
        boolean boolean22 = spreadsheetDate1.isOnOrBefore(serialDate17);
        org.jfree.data.time.SerialDate serialDate24 = serialDate17.getFollowingDayOfWeek(3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1900 + "'", int12 == 1900);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(serialDate24);
    }

//    @Test
//    public void test261() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test261");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
//        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate7 = serialDate4.getEndOfCurrentMonth(serialDate6);
//        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(3);
//        boolean boolean11 = spreadsheetDate1.isInRange(serialDate6, (org.jfree.data.time.SerialDate) spreadsheetDate10);
//        int int12 = spreadsheetDate1.getYYYY();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(3);
//        boolean boolean15 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate14);
//        int int16 = spreadsheetDate1.getMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(12);
//        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate23 = serialDate20.getEndOfCurrentMonth(serialDate22);
//        boolean boolean24 = spreadsheetDate18.isAfter(serialDate23);
//        boolean boolean25 = spreadsheetDate1.isBefore(serialDate23);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(3);
//        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate33 = serialDate30.getEndOfCurrentMonth(serialDate32);
//        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate32);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(3);
//        boolean boolean37 = spreadsheetDate27.isInRange(serialDate32, (org.jfree.data.time.SerialDate) spreadsheetDate36);
//        int int38 = spreadsheetDate27.getYYYY();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate(3);
//        boolean boolean41 = spreadsheetDate27.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate40);
//        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate47 = serialDate44.getEndOfCurrentMonth(serialDate46);
//        org.jfree.data.time.SerialDate serialDate48 = org.jfree.data.time.SerialDate.addDays(0, serialDate47);
//        boolean boolean49 = spreadsheetDate27.isOnOrBefore(serialDate47);
//        int int50 = spreadsheetDate27.getYYYY();
//        int int51 = spreadsheetDate27.getDayOfMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate53 = new org.jfree.data.time.SpreadsheetDate(3);
//        org.jfree.data.time.SerialDate serialDate55 = org.jfree.data.time.SerialDate.createInstance(9);
//        boolean boolean56 = spreadsheetDate53.isOnOrAfter(serialDate55);
//        boolean boolean57 = spreadsheetDate27.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate53);
//        boolean boolean58 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate27);
//        java.util.Date date59 = spreadsheetDate1.toDate();
//        int int60 = spreadsheetDate1.getDayOfMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate62 = new org.jfree.data.time.SpreadsheetDate(3);
//        org.jfree.data.time.SerialDate serialDate65 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate67 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate68 = serialDate65.getEndOfCurrentMonth(serialDate67);
//        org.jfree.data.time.SerialDate serialDate69 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate67);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate71 = new org.jfree.data.time.SpreadsheetDate(3);
//        boolean boolean72 = spreadsheetDate62.isInRange(serialDate67, (org.jfree.data.time.SerialDate) spreadsheetDate71);
//        int int73 = spreadsheetDate62.getYYYY();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate75 = new org.jfree.data.time.SpreadsheetDate(3);
//        boolean boolean76 = spreadsheetDate62.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate75);
//        int int77 = spreadsheetDate62.getMonth();
//        org.jfree.data.time.Day day78 = new org.jfree.data.time.Day();
//        java.lang.String str79 = day78.toString();
//        long long80 = day78.getLastMillisecond();
//        int int82 = day78.compareTo((java.lang.Object) (byte) 10);
//        org.jfree.data.time.SerialDate serialDate83 = day78.getSerialDate();
//        boolean boolean84 = spreadsheetDate62.isAfter(serialDate83);
//        boolean boolean85 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate62);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1900 + "'", int12 == 1900);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertNotNull(serialDate32);
//        org.junit.Assert.assertNotNull(serialDate33);
//        org.junit.Assert.assertNotNull(serialDate34);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1900 + "'", int38 == 1900);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertNotNull(serialDate44);
//        org.junit.Assert.assertNotNull(serialDate46);
//        org.junit.Assert.assertNotNull(serialDate47);
//        org.junit.Assert.assertNotNull(serialDate48);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1900 + "'", int50 == 1900);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 2 + "'", int51 == 2);
//        org.junit.Assert.assertNotNull(serialDate55);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
//        org.junit.Assert.assertNotNull(date59);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 2 + "'", int60 == 2);
//        org.junit.Assert.assertNotNull(serialDate65);
//        org.junit.Assert.assertNotNull(serialDate67);
//        org.junit.Assert.assertNotNull(serialDate68);
//        org.junit.Assert.assertNotNull(serialDate69);
//        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 1900 + "'", int73 == 1900);
//        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 1 + "'", int77 == 1);
//        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "10-June-2019" + "'", str79.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 1560236399999L + "'", long80 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 1 + "'", int82 == 1);
//        org.junit.Assert.assertNotNull(serialDate83);
//        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
//        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + true + "'", boolean85 == true);
//    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((-460));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
        timeSeries4.setMaximumItemCount((int) (byte) 0);
        boolean boolean7 = timeSeries4.getNotify();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class11);
        timeSeries12.setDomainDescription("hi!");
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        java.util.Date date16 = day15.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day15, (java.lang.Number) 0);
        java.lang.Object obj19 = null;
        boolean boolean20 = timeSeries12.equals(obj19);
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries4.addAndOrUpdate(timeSeries12);
        int int22 = timeSeries4.getItemCount();
        boolean boolean23 = timeSeries4.isEmpty();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(timeSeries21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

//    @Test
//    public void test264() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test264");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setMaximumItemCount((int) (byte) 0);
//        boolean boolean7 = timeSeries4.getNotify();
//        java.util.List list8 = timeSeries4.getItems();
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class12);
//        timeSeries13.setMaximumItemCount((int) (byte) 0);
//        boolean boolean16 = timeSeries13.getNotify();
//        java.util.List list17 = timeSeries13.getItems();
//        java.util.Collection collection18 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries13);
//        java.util.List list19 = timeSeries4.getItems();
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        java.util.Date date21 = day20.getEnd();
//        int int23 = day20.compareTo((java.lang.Object) (-1L));
//        java.lang.Class class27 = null;
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class27);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        java.lang.String str30 = day29.toString();
//        timeSeries28.delete((org.jfree.data.time.RegularTimePeriod) day29);
//        timeSeries28.fireSeriesChanged();
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        java.util.Date date34 = day33.getEnd();
//        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(date34);
//        java.lang.Number number36 = timeSeries28.getValue((org.jfree.data.time.RegularTimePeriod) month35);
//        java.lang.Class class40 = null;
//        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class40);
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
//        java.lang.String str43 = day42.toString();
//        timeSeries41.delete((org.jfree.data.time.RegularTimePeriod) day42);
//        boolean boolean45 = timeSeries28.equals((java.lang.Object) day42);
//        boolean boolean46 = day20.equals((java.lang.Object) timeSeries28);
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
//        java.lang.String str48 = day47.toString();
//        java.util.Date date49 = day47.getStart();
//        long long50 = day47.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) day20, (org.jfree.data.time.RegularTimePeriod) day47);
//        timeSeries4.setKey((java.lang.Comparable) 0L);
//        timeSeries4.setRangeDescription("ERROR : Relative To String");
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(list8);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNotNull(list17);
//        org.junit.Assert.assertNotNull(collection18);
//        org.junit.Assert.assertNotNull(list19);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "10-June-2019" + "'", str30.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNull(number36);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "10-June-2019" + "'", str43.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "10-June-2019" + "'", str48.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1560236399999L + "'", long50 == 1560236399999L);
//        org.junit.Assert.assertNotNull(timeSeries51);
//    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(2);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "February" + "'", str1.equals("February"));
    }

//    @Test
//    public void test266() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test266");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setMaximumItemCount((int) (byte) 0);
//        boolean boolean7 = timeSeries4.getNotify();
//        java.lang.Comparable comparable8 = timeSeries4.getKey();
//        java.lang.Object obj9 = timeSeries4.clone();
//        java.lang.Class class13 = null;
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class13);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        java.lang.String str16 = day15.toString();
//        timeSeries14.delete((org.jfree.data.time.RegularTimePeriod) day15);
//        java.lang.String str18 = timeSeries14.getRangeDescription();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        java.util.Date date20 = day19.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond(date20);
//        int int22 = timeSeries14.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21);
//        try {
//            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, 0.0d, false);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0f) + "'", comparable8.equals((-1.0f)));
//        org.junit.Assert.assertNotNull(obj9);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "10-June-2019" + "'", str16.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hi!" + "'", str18.equals("hi!"));
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
//    }

//    @Test
//    public void test267() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test267");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
//        java.lang.String str3 = month2.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (double) (short) 100);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        java.util.Date date8 = day7.getEnd();
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date8);
//        java.lang.String str10 = month9.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month9, (double) (short) 100);
//        int int14 = timeSeriesDataItem6.compareTo((java.lang.Object) month9);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        java.lang.String str16 = day15.toString();
//        int int17 = month9.compareTo((java.lang.Object) str16);
//        long long18 = month9.getLastMillisecond();
//        org.jfree.data.time.Year year19 = month9.getYear();
//        long long20 = year19.getFirstMillisecond();
//        int int21 = year19.getYear();
//        java.lang.String str22 = year19.toString();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "June 2019" + "'", str10.equals("June 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "10-June-2019" + "'", str16.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1561964399999L + "'", long18 == 1561964399999L);
//        org.junit.Assert.assertNotNull(year19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1546329600000L + "'", long20 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "2019" + "'", str22.equals("2019"));
//    }

//    @Test
//    public void test268() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test268");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        int int3 = day0.compareTo((java.lang.Object) (-1L));
//        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
//        long long5 = day0.getLastMillisecond();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(3);
//        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate13 = serialDate10.getEndOfCurrentMonth(serialDate12);
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate12);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(3);
//        boolean boolean17 = spreadsheetDate7.isInRange(serialDate12, (org.jfree.data.time.SerialDate) spreadsheetDate16);
//        int int18 = spreadsheetDate7.getYYYY();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(3);
//        boolean boolean21 = spreadsheetDate7.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate20);
//        int int22 = day0.compareTo((java.lang.Object) boolean21);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560236399999L + "'", long5 == 1560236399999L);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1900 + "'", int18 == 1900);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//    }

//    @Test
//    public void test269() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test269");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        int int3 = day0.compareTo((java.lang.Object) (-1L));
//        java.lang.Class class7 = null;
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class7);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.lang.String str10 = day9.toString();
//        timeSeries8.delete((org.jfree.data.time.RegularTimePeriod) day9);
//        timeSeries8.fireSeriesChanged();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.util.Date date14 = day13.getEnd();
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
//        java.lang.Number number16 = timeSeries8.getValue((org.jfree.data.time.RegularTimePeriod) month15);
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class20);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.lang.String str23 = day22.toString();
//        timeSeries21.delete((org.jfree.data.time.RegularTimePeriod) day22);
//        boolean boolean25 = timeSeries8.equals((java.lang.Object) day22);
//        boolean boolean26 = day0.equals((java.lang.Object) timeSeries8);
//        timeSeries8.setDomainDescription("ERROR : Relative To String");
//        timeSeries8.setMaximumItemCount(3);
//        java.lang.Class class31 = timeSeries8.getTimePeriodClass();
//        timeSeries8.setNotify(false);
//        java.lang.Class class37 = null;
//        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class37);
//        timeSeries38.setMaximumItemCount((int) (byte) 0);
//        boolean boolean41 = timeSeries38.getNotify();
//        java.util.List list42 = timeSeries38.getItems();
//        java.lang.Class class46 = null;
//        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class46);
//        timeSeries47.setMaximumItemCount((int) (byte) 0);
//        boolean boolean50 = timeSeries47.getNotify();
//        java.util.List list51 = timeSeries47.getItems();
//        java.util.Collection collection52 = timeSeries38.getTimePeriodsUniqueToOtherSeries(timeSeries47);
//        boolean boolean53 = timeSeries38.isEmpty();
//        timeSeries38.setDomainDescription("2019");
//        java.lang.Class class59 = null;
//        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class59);
//        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day();
//        java.lang.String str62 = day61.toString();
//        timeSeries60.delete((org.jfree.data.time.RegularTimePeriod) day61);
//        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day();
//        java.util.Date date65 = day64.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond66 = new org.jfree.data.time.FixedMillisecond(date65);
//        java.util.Date date67 = fixedMillisecond66.getTime();
//        long long68 = fixedMillisecond66.getSerialIndex();
//        long long69 = fixedMillisecond66.getFirstMillisecond();
//        java.util.Calendar calendar70 = null;
//        long long71 = fixedMillisecond66.getMiddleMillisecond(calendar70);
//        org.jfree.data.time.TimeSeries timeSeries72 = timeSeries38.createCopy((org.jfree.data.time.RegularTimePeriod) day61, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond66);
//        int int73 = day61.getMonth();
//        int int74 = timeSeries8.getIndex((org.jfree.data.time.RegularTimePeriod) day61);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = day61.next();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "10-June-2019" + "'", str23.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNull(class31);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
//        org.junit.Assert.assertNotNull(list42);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
//        org.junit.Assert.assertNotNull(list51);
//        org.junit.Assert.assertNotNull(collection52);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "10-June-2019" + "'", str62.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date65);
//        org.junit.Assert.assertNotNull(date67);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 1560236399999L + "'", long68 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 1560236399999L + "'", long69 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 1560236399999L + "'", long71 == 1560236399999L);
//        org.junit.Assert.assertNotNull(timeSeries72);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 6 + "'", int73 == 6);
//        org.junit.Assert.assertTrue("'" + int74 + "' != '" + (-1) + "'", int74 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod75);
//    }

//    @Test
//    public void test270() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test270");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
//        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate7 = serialDate4.getEndOfCurrentMonth(serialDate6);
//        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(3);
//        boolean boolean11 = spreadsheetDate1.isInRange(serialDate6, (org.jfree.data.time.SerialDate) spreadsheetDate10);
//        org.jfree.data.time.SerialDate serialDate13 = serialDate6.getPreviousDayOfWeek(7);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(serialDate13);
//        long long15 = day14.getFirstMillisecond();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        java.util.Date date17 = day16.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
//        java.util.Date date19 = fixedMillisecond18.getTime();
//        long long20 = fixedMillisecond18.getSerialIndex();
//        long long21 = fixedMillisecond18.getFirstMillisecond();
//        boolean boolean23 = fixedMillisecond18.equals((java.lang.Object) (short) 10);
//        long long24 = fixedMillisecond18.getSerialIndex();
//        java.lang.Class class28 = null;
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class28);
//        timeSeries29.setMaximumItemCount((int) (byte) 0);
//        boolean boolean32 = timeSeries29.getNotify();
//        timeSeries29.setKey((java.lang.Comparable) 10.0d);
//        java.lang.Class<?> wildcardClass35 = timeSeries29.getClass();
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
//        java.lang.String str37 = day36.toString();
//        java.util.Date date38 = day36.getStart();
//        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(date38);
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day();
//        java.util.Date date41 = day40.getEnd();
//        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month(date41);
//        java.lang.String str43 = month42.toString();
//        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean45 = month42.equals((java.lang.Object) timeZone44);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass35, date38, timeZone44);
//        java.lang.Class class47 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass35);
//        java.lang.Class class48 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass35);
//        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond18, (java.lang.Class) wildcardClass35);
//        boolean boolean50 = day14.equals((java.lang.Object) fixedMillisecond18);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-2208528000000L) + "'", long15 == (-2208528000000L));
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560236399999L + "'", long20 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560236399999L + "'", long21 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560236399999L + "'", long24 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
//        org.junit.Assert.assertNotNull(wildcardClass35);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "10-June-2019" + "'", str37.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "June 2019" + "'", str43.equals("June 2019"));
//        org.junit.Assert.assertNotNull(timeZone44);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertNull(regularTimePeriod46);
//        org.junit.Assert.assertNotNull(class47);
//        org.junit.Assert.assertNotNull(class48);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate7 = serialDate4.getEndOfCurrentMonth(serialDate6);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean11 = spreadsheetDate1.isInRange(serialDate6, (org.jfree.data.time.SerialDate) spreadsheetDate10);
        int int12 = spreadsheetDate1.getYYYY();
        int int13 = spreadsheetDate1.getMonth();
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1900 + "'", int12 == 1900);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

//    @Test
//    public void test272() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test272");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setDomainDescription("hi!");
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        java.util.Date date8 = day7.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) 0);
//        java.lang.Object obj11 = null;
//        boolean boolean12 = timeSeries4.equals(obj11);
//        timeSeries4.setDescription("10-June-2019");
//        timeSeries4.setDomainDescription("ERROR : Relative To String");
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        java.util.Date date18 = day17.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond(date18);
//        java.util.Date date20 = fixedMillisecond19.getTime();
//        long long21 = fixedMillisecond19.getSerialIndex();
//        long long22 = fixedMillisecond19.getFirstMillisecond();
//        java.util.Calendar calendar23 = null;
//        fixedMillisecond19.peg(calendar23);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
//        java.util.Calendar calendar26 = null;
//        long long27 = fixedMillisecond19.getFirstMillisecond(calendar26);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(timeSeriesDataItem10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560236399999L + "'", long21 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560236399999L + "'", long22 == 1560236399999L);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem25);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560236399999L + "'", long27 == 1560236399999L);
//    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
        java.util.Date date3 = fixedMillisecond2.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date3);
    }

//    @Test
//    public void test274() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test274");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setDomainDescription("hi!");
//        java.lang.Object obj7 = timeSeries4.clone();
//        java.lang.String str8 = timeSeries4.getDescription();
//        timeSeries4.setMaximumItemAge((long) 9999);
//        java.lang.Class class14 = null;
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class14);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        java.lang.String str17 = day16.toString();
//        timeSeries15.delete((org.jfree.data.time.RegularTimePeriod) day16);
//        timeSeries15.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener20 = null;
//        timeSeries15.addPropertyChangeListener(propertyChangeListener20);
//        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries4.addAndOrUpdate(timeSeries15);
//        long long23 = timeSeries4.getMaximumItemAge();
//        java.beans.PropertyChangeListener propertyChangeListener24 = null;
//        timeSeries4.removePropertyChangeListener(propertyChangeListener24);
//        org.junit.Assert.assertNotNull(obj7);
//        org.junit.Assert.assertNull(str8);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "10-June-2019" + "'", str17.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(timeSeries22);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 9999L + "'", long23 == 9999L);
//    }

//    @Test
//    public void test275() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test275");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
//        java.util.Date date3 = fixedMillisecond2.getTime();
//        long long4 = fixedMillisecond2.getSerialIndex();
//        long long5 = fixedMillisecond2.getFirstMillisecond();
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond2.getMiddleMillisecond(calendar6);
//        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate13 = serialDate10.getEndOfCurrentMonth(serialDate12);
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate12);
//        boolean boolean15 = fixedMillisecond2.equals((java.lang.Object) serialDate12);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2, (double) 6);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560236399999L + "'", long5 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560236399999L + "'", long7 == 1560236399999L);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(4, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30 + "'", int2 == 30);
    }

//    @Test
//    public void test277() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test277");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setDomainDescription("hi!");
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        java.util.Date date8 = day7.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) 0);
//        java.lang.Object obj11 = null;
//        boolean boolean12 = timeSeries4.equals(obj11);
//        timeSeries4.setDescription("10-June-2019");
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        java.lang.String str16 = day15.toString();
//        java.util.Date date17 = day15.getStart();
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date17);
//        java.lang.Class class22 = null;
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class22);
//        timeSeries23.setMaximumItemCount((int) (byte) 0);
//        boolean boolean26 = timeSeries23.getNotify();
//        java.util.List list27 = timeSeries23.getItems();
//        java.lang.Class class31 = null;
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class31);
//        timeSeries32.setMaximumItemCount((int) (byte) 0);
//        boolean boolean35 = timeSeries32.getNotify();
//        java.util.List list36 = timeSeries32.getItems();
//        java.util.Collection collection37 = timeSeries23.getTimePeriodsUniqueToOtherSeries(timeSeries32);
//        boolean boolean38 = timeSeries23.isEmpty();
//        timeSeries23.setDomainDescription("2019");
//        java.lang.Class<?> wildcardClass41 = timeSeries23.getClass();
//        java.util.Date date42 = null;
//        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass41, date42, timeZone43);
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date17, timeZone43);
//        org.jfree.data.time.SerialDate serialDate46 = day45.getSerialDate();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) day45);
//        java.lang.Class class48 = null;
//        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day45, class48);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(timeSeriesDataItem10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "10-June-2019" + "'", str16.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
//        org.junit.Assert.assertNotNull(list27);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
//        org.junit.Assert.assertNotNull(list36);
//        org.junit.Assert.assertNotNull(collection37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
//        org.junit.Assert.assertNotNull(wildcardClass41);
//        org.junit.Assert.assertNotNull(timeZone43);
//        org.junit.Assert.assertNull(regularTimePeriod44);
//        org.junit.Assert.assertNotNull(serialDate46);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem47);
//    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate7 = serialDate4.getEndOfCurrentMonth(serialDate6);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean11 = spreadsheetDate1.isInRange(serialDate6, (org.jfree.data.time.SerialDate) spreadsheetDate10);
        int int12 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean15 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(3);
        int int18 = spreadsheetDate17.getYYYY();
        int int19 = spreadsheetDate17.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(3);
        int int22 = spreadsheetDate21.toSerial();
        java.lang.String str23 = spreadsheetDate21.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate31 = serialDate28.getEndOfCurrentMonth(serialDate30);
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate30);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean35 = spreadsheetDate25.isInRange(serialDate30, (org.jfree.data.time.SerialDate) spreadsheetDate34);
        int int36 = spreadsheetDate25.getYYYY();
        boolean boolean37 = spreadsheetDate21.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate25);
        boolean boolean38 = spreadsheetDate17.isOn((org.jfree.data.time.SerialDate) spreadsheetDate21);
        int int39 = spreadsheetDate14.compare((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1900 + "'", int12 == 1900);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1900 + "'", int18 == 1900);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1900 + "'", int19 == 1900);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 3 + "'", int22 == 3);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1900 + "'", int36 == 1900);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
    }

//    @Test
//    public void test279() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test279");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setMaximumItemCount((int) (byte) 0);
//        boolean boolean7 = timeSeries4.getNotify();
//        java.util.List list8 = timeSeries4.getItems();
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class12);
//        timeSeries13.setMaximumItemCount((int) (byte) 0);
//        boolean boolean16 = timeSeries13.getNotify();
//        java.util.List list17 = timeSeries13.getItems();
//        java.util.Collection collection18 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries13);
//        java.util.List list19 = timeSeries4.getItems();
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        java.util.Date date21 = day20.getEnd();
//        int int23 = day20.compareTo((java.lang.Object) (-1L));
//        java.lang.Class class27 = null;
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class27);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        java.lang.String str30 = day29.toString();
//        timeSeries28.delete((org.jfree.data.time.RegularTimePeriod) day29);
//        timeSeries28.fireSeriesChanged();
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        java.util.Date date34 = day33.getEnd();
//        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(date34);
//        java.lang.Number number36 = timeSeries28.getValue((org.jfree.data.time.RegularTimePeriod) month35);
//        java.lang.Class class40 = null;
//        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class40);
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
//        java.lang.String str43 = day42.toString();
//        timeSeries41.delete((org.jfree.data.time.RegularTimePeriod) day42);
//        boolean boolean45 = timeSeries28.equals((java.lang.Object) day42);
//        boolean boolean46 = day20.equals((java.lang.Object) timeSeries28);
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
//        java.lang.String str48 = day47.toString();
//        java.util.Date date49 = day47.getStart();
//        long long50 = day47.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) day20, (org.jfree.data.time.RegularTimePeriod) day47);
//        int int52 = day47.getYear();
//        java.lang.String str53 = day47.toString();
//        int int54 = day47.getYear();
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(list8);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNotNull(list17);
//        org.junit.Assert.assertNotNull(collection18);
//        org.junit.Assert.assertNotNull(list19);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "10-June-2019" + "'", str30.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNull(number36);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "10-June-2019" + "'", str43.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "10-June-2019" + "'", str48.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1560236399999L + "'", long50 == 1560236399999L);
//        org.junit.Assert.assertNotNull(timeSeries51);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 2019 + "'", int52 == 2019);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "10-June-2019" + "'", str53.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 2019 + "'", int54 == 2019);
//    }

//    @Test
//    public void test280() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test280");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setMaximumItemCount((int) (byte) 0);
//        boolean boolean7 = timeSeries4.getNotify();
//        timeSeries4.setKey((java.lang.Comparable) 10.0d);
//        java.lang.Class<?> wildcardClass10 = timeSeries4.getClass();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        java.lang.String str12 = day11.toString();
//        java.util.Date date13 = day11.getStart();
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date13);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        java.util.Date date16 = day15.getEnd();
//        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date16);
//        java.lang.String str18 = month17.toString();
//        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean20 = month17.equals((java.lang.Object) timeZone19);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date13, timeZone19);
//        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.createInstance(date13);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate22);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10-June-2019" + "'", str12.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "June 2019" + "'", str18.equals("June 2019"));
//        org.junit.Assert.assertNotNull(timeZone19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(serialDate22);
//    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(date1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date1);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date1);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate4);
    }

//    @Test
//    public void test282() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test282");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setDomainDescription("hi!");
//        java.lang.Object obj7 = timeSeries4.clone();
//        java.lang.String str8 = timeSeries4.getDescription();
//        timeSeries4.setMaximumItemAge((long) 9999);
//        java.lang.Class class14 = null;
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class14);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        java.lang.String str17 = day16.toString();
//        timeSeries15.delete((org.jfree.data.time.RegularTimePeriod) day16);
//        timeSeries15.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener20 = null;
//        timeSeries15.addPropertyChangeListener(propertyChangeListener20);
//        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries4.addAndOrUpdate(timeSeries15);
//        long long23 = timeSeries4.getMaximumItemAge();
//        java.lang.Comparable comparable24 = timeSeries4.getKey();
//        org.junit.Assert.assertNotNull(obj7);
//        org.junit.Assert.assertNull(str8);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "10-June-2019" + "'", str17.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(timeSeries22);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 9999L + "'", long23 == 9999L);
//        org.junit.Assert.assertTrue("'" + comparable24 + "' != '" + (-1.0f) + "'", comparable24.equals((-1.0f)));
//    }

//    @Test
//    public void test283() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test283");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        java.util.Date date2 = day0.getStart();
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year3.previous();
//        long long5 = year3.getFirstMillisecond();
//        long long6 = year3.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year3.previous();
//        java.util.Calendar calendar8 = null;
//        try {
//            long long9 = year3.getFirstMillisecond(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//    }

//    @Test
//    public void test284() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test284");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        java.util.Date date2 = day0.getStart();
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) year4);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//    }

//    @Test
//    public void test285() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test285");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getFirstMillisecond();
//        java.lang.String str3 = day0.toString();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10-June-2019" + "'", str3.equals("10-June-2019"));
//    }

//    @Test
//    public void test286() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test286");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day5);
//        timeSeries4.fireSeriesChanged();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.util.Date date10 = day9.getEnd();
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
//        java.lang.Number number12 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month11);
//        org.jfree.data.time.Year year13 = month11.getYear();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.lang.String str15 = day14.toString();
//        java.util.Date date16 = day14.getStart();
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
//        java.lang.Object obj18 = null;
//        int int19 = year17.compareTo(obj18);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year17.previous();
//        boolean boolean21 = month11.equals((java.lang.Object) regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNull(number12);
//        org.junit.Assert.assertNotNull(year13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10-June-2019" + "'", str15.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        int int2 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate10 = serialDate7.getEndOfCurrentMonth(serialDate9);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean14 = spreadsheetDate4.isInRange(serialDate9, (org.jfree.data.time.SerialDate) spreadsheetDate13);
        int int15 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate23 = serialDate20.getEndOfCurrentMonth(serialDate22);
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate22);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean27 = spreadsheetDate17.isInRange(serialDate22, (org.jfree.data.time.SerialDate) spreadsheetDate26);
        int int28 = spreadsheetDate17.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean31 = spreadsheetDate17.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate30);
        int int32 = spreadsheetDate30.getDayOfMonth();
        int int33 = spreadsheetDate30.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate41 = serialDate38.getEndOfCurrentMonth(serialDate40);
        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate40);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean45 = spreadsheetDate35.isInRange(serialDate40, (org.jfree.data.time.SerialDate) spreadsheetDate44);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.createInstance(9);
        boolean boolean50 = spreadsheetDate47.isOnOrAfter(serialDate49);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate52 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate55 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate57 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate58 = serialDate55.getEndOfCurrentMonth(serialDate57);
        org.jfree.data.time.SerialDate serialDate59 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate57);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate61 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean62 = spreadsheetDate52.isInRange(serialDate57, (org.jfree.data.time.SerialDate) spreadsheetDate61);
        int int63 = spreadsheetDate52.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate65 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean66 = spreadsheetDate52.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate65);
        org.jfree.data.time.SerialDate serialDate69 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate71 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate72 = serialDate69.getEndOfCurrentMonth(serialDate71);
        org.jfree.data.time.SerialDate serialDate73 = org.jfree.data.time.SerialDate.addDays(0, serialDate72);
        boolean boolean74 = spreadsheetDate52.isOnOrBefore(serialDate72);
        int int75 = spreadsheetDate47.compare((org.jfree.data.time.SerialDate) spreadsheetDate52);
        int int76 = spreadsheetDate52.getDayOfMonth();
        int int77 = spreadsheetDate52.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate79 = new org.jfree.data.time.SpreadsheetDate(12);
        java.util.Date date80 = spreadsheetDate79.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate82 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate85 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate87 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate88 = serialDate85.getEndOfCurrentMonth(serialDate87);
        org.jfree.data.time.SerialDate serialDate89 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate87);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate91 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean92 = spreadsheetDate82.isInRange(serialDate87, (org.jfree.data.time.SerialDate) spreadsheetDate91);
        org.jfree.data.time.SerialDate serialDate94 = serialDate87.getPreviousDayOfWeek(7);
        boolean boolean95 = spreadsheetDate52.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate79, serialDate94);
        org.jfree.data.time.SerialDate serialDate96 = serialDate40.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate52);
        boolean boolean97 = spreadsheetDate4.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate30, (org.jfree.data.time.SerialDate) spreadsheetDate52);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1900 + "'", int2 == 1900);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1900 + "'", int28 == 1900);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2 + "'", int32 == 2);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertNotNull(serialDate38);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(serialDate55);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertNotNull(serialDate58);
        org.junit.Assert.assertNotNull(serialDate59);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1900 + "'", int63 == 1900);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(serialDate69);
        org.junit.Assert.assertNotNull(serialDate71);
        org.junit.Assert.assertNotNull(serialDate72);
        org.junit.Assert.assertNotNull(serialDate73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 0 + "'", int75 == 0);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 2 + "'", int76 == 2);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 3 + "'", int77 == 3);
        org.junit.Assert.assertNotNull(date80);
        org.junit.Assert.assertNotNull(serialDate85);
        org.junit.Assert.assertNotNull(serialDate87);
        org.junit.Assert.assertNotNull(serialDate88);
        org.junit.Assert.assertNotNull(serialDate89);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + true + "'", boolean92 == true);
        org.junit.Assert.assertNotNull(serialDate94);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
        org.junit.Assert.assertNotNull(serialDate96);
        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + true + "'", boolean97 == true);
    }

//    @Test
//    public void test288() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test288");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(3);
//        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(9);
//        boolean boolean5 = spreadsheetDate2.isOnOrAfter(serialDate4);
//        int int6 = spreadsheetDate2.getDayOfWeek();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        java.lang.String str8 = day7.toString();
//        long long9 = day7.getFirstMillisecond();
//        boolean boolean10 = spreadsheetDate2.equals((java.lang.Object) long9);
//        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(7, (org.jfree.data.time.SerialDate) spreadsheetDate2);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 3 + "'", int6 == 3);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10-June-2019" + "'", str8.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560150000000L + "'", long9 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(serialDate11);
//    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate5 = serialDate2.getEndOfCurrentMonth(serialDate4);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate4);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(9);
        boolean boolean12 = spreadsheetDate9.isOnOrAfter(serialDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate20 = serialDate17.getEndOfCurrentMonth(serialDate19);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate19);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean24 = spreadsheetDate14.isInRange(serialDate19, (org.jfree.data.time.SerialDate) spreadsheetDate23);
        int int25 = spreadsheetDate14.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean28 = spreadsheetDate14.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate27);
        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate34 = serialDate31.getEndOfCurrentMonth(serialDate33);
        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.addDays(0, serialDate34);
        boolean boolean36 = spreadsheetDate14.isOnOrBefore(serialDate34);
        int int37 = spreadsheetDate9.compare((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SerialDate serialDate38 = serialDate6.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate14);
        java.util.Date date39 = spreadsheetDate14.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate46 = serialDate43.getEndOfCurrentMonth(serialDate45);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate(12);
        java.util.Date date49 = spreadsheetDate48.toDate();
        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day();
        java.util.Date date51 = day50.getEnd();
        org.jfree.data.time.SerialDate serialDate52 = org.jfree.data.time.SerialDate.createInstance(date51);
        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day(serialDate52);
        org.jfree.data.time.SerialDate serialDate55 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate57 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate58 = serialDate55.getEndOfCurrentMonth(serialDate57);
        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day(serialDate55);
        boolean boolean61 = spreadsheetDate48.isInRange(serialDate52, serialDate55, 0);
        boolean boolean62 = spreadsheetDate41.isInRange(serialDate45, serialDate52);
        org.jfree.data.time.SerialDate serialDate63 = spreadsheetDate14.getEndOfCurrentMonth(serialDate52);
        java.util.Date date64 = spreadsheetDate14.toDate();
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1900 + "'", int25 == 1900);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(serialDate38);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNotNull(serialDate52);
        org.junit.Assert.assertNotNull(serialDate55);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertNotNull(serialDate58);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNotNull(serialDate63);
        org.junit.Assert.assertNotNull(date64);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
        java.util.Date date3 = fixedMillisecond2.getTime();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getEnd();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date5);
        java.lang.String str7 = month6.toString();
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean9 = month6.equals((java.lang.Object) timeZone8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date3, timeZone8);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (java.lang.Number) 10L);
        java.util.Date date15 = fixedMillisecond12.getEnd();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day16.previous();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "June 2019" + "'", str7.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
        timeSeries4.setMaximumItemCount((int) (byte) 0);
        boolean boolean7 = timeSeries4.getNotify();
        java.util.List list8 = timeSeries4.getItems();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class12);
        timeSeries13.setMaximumItemCount((int) (byte) 0);
        boolean boolean16 = timeSeries13.getNotify();
        java.util.List list17 = timeSeries13.getItems();
        java.util.Collection collection18 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        boolean boolean19 = timeSeries4.isEmpty();
        timeSeries4.setDomainDescription("2019");
        java.lang.Class<?> wildcardClass22 = timeSeries4.getClass();
        java.lang.Comparable comparable23 = timeSeries4.getKey();
        timeSeries4.fireSeriesChanged();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = timeSeries4.getTimePeriod((-457));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(list17);
        org.junit.Assert.assertNotNull(collection18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertTrue("'" + comparable23 + "' != '" + (-1.0f) + "'", comparable23.equals((-1.0f)));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
        int int3 = day0.getYear();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
    }

//    @Test
//    public void test293() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test293");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setDomainDescription("hi!");
//        java.lang.Object obj7 = timeSeries4.clone();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.lang.String str9 = day8.toString();
//        java.util.Date date10 = day8.getStart();
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date10);
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) year11);
//        org.junit.Assert.assertNotNull(obj7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date10);
//    }

//    @Test
//    public void test294() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test294");
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        java.lang.String str2 = day1.toString();
//        long long3 = day1.getLastMillisecond();
//        int int5 = day1.compareTo((java.lang.Object) (byte) 10);
//        org.jfree.data.time.SerialDate serialDate6 = day1.getSerialDate();
//        try {
//            org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(8, serialDate6);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10-June-2019" + "'", str2.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560236399999L + "'", long3 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(serialDate6);
//    }

//    @Test
//    public void test295() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test295");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setMaximumItemCount((int) (byte) 0);
//        boolean boolean7 = timeSeries4.getNotify();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class11);
//        timeSeries12.setDomainDescription("hi!");
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        java.util.Date date16 = day15.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day15, (java.lang.Number) 0);
//        java.lang.Object obj19 = null;
//        boolean boolean20 = timeSeries12.equals(obj19);
//        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries4.addAndOrUpdate(timeSeries12);
//        java.beans.PropertyChangeListener propertyChangeListener22 = null;
//        timeSeries4.removePropertyChangeListener(propertyChangeListener22);
//        timeSeries4.clear();
//        java.lang.Comparable comparable25 = timeSeries4.getKey();
//        java.lang.Class class29 = null;
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class29);
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        java.lang.String str32 = day31.toString();
//        timeSeries30.delete((org.jfree.data.time.RegularTimePeriod) day31);
//        timeSeries30.fireSeriesChanged();
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        java.util.Date date36 = day35.getEnd();
//        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month(date36);
//        java.lang.Number number38 = timeSeries30.getValue((org.jfree.data.time.RegularTimePeriod) month37);
//        int int39 = month37.getMonth();
//        int int40 = month37.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = month37.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) month37);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate(3);
//        java.util.Date date45 = spreadsheetDate44.toDate();
//        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date45);
//        org.jfree.data.time.TimeSeries timeSeries49 = timeSeries46.createCopy(0, 2958465);
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day();
//        java.lang.String str51 = day50.toString();
//        long long52 = day50.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem54 = timeSeries49.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day50, (java.lang.Number) 9999);
//        int int55 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) day50);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNull(timeSeriesDataItem18);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(timeSeries21);
//        org.junit.Assert.assertTrue("'" + comparable25 + "' != '" + (-1.0f) + "'", comparable25.equals((-1.0f)));
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "10-June-2019" + "'", str32.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNull(number38);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 6 + "'", int39 == 6);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 6 + "'", int40 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertNull(timeSeriesDataItem42);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertNotNull(timeSeries49);
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "10-June-2019" + "'", str51.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1560236399999L + "'", long52 == 1560236399999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem54);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-1) + "'", int55 == (-1));
//    }

//    @Test
//    public void test296() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test296");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setDomainDescription("hi!");
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        java.util.Date date8 = day7.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) 0);
//        java.lang.Object obj11 = null;
//        boolean boolean12 = timeSeries4.equals(obj11);
//        timeSeries4.setDescription("10-June-2019");
//        timeSeries4.setDomainDescription("ERROR : Relative To String");
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        java.util.Date date18 = day17.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond(date18);
//        java.util.Date date20 = fixedMillisecond19.getTime();
//        long long21 = fixedMillisecond19.getSerialIndex();
//        long long22 = fixedMillisecond19.getFirstMillisecond();
//        java.util.Calendar calendar23 = null;
//        fixedMillisecond19.peg(calendar23);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
//        timeSeriesDataItem25.setValue((java.lang.Number) 2);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(timeSeriesDataItem10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560236399999L + "'", long21 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560236399999L + "'", long22 == 1560236399999L);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem25);
//    }

//    @Test
//    public void test297() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test297");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        java.util.Date date2 = day0.getStart();
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
//        java.lang.Object obj4 = null;
//        int int5 = year3.compareTo(obj4);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year3.previous();
//        long long7 = year3.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
//    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesChangeEvent[source=10]");
        java.lang.String str2 = seriesException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("2018");
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        org.jfree.data.general.SeriesException seriesException7 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesChangeEvent[source=10]");
        java.lang.String str8 = seriesException7.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("2018");
        seriesException7.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesChangeEvent[source=10]" + "'", str2.equals("org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesChangeEvent[source=10]"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesChangeEvent[source=10]" + "'", str8.equals("org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesChangeEvent[source=10]"));
    }

//    @Test
//    public void test299() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test299");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        java.util.Date date2 = day0.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
//        java.lang.Class class7 = null;
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class7);
//        timeSeries8.setMaximumItemCount((int) (byte) 0);
//        boolean boolean11 = timeSeries8.getNotify();
//        java.util.List list12 = timeSeries8.getItems();
//        java.lang.Class class16 = null;
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class16);
//        timeSeries17.setMaximumItemCount((int) (byte) 0);
//        boolean boolean20 = timeSeries17.getNotify();
//        java.util.List list21 = timeSeries17.getItems();
//        java.util.Collection collection22 = timeSeries8.getTimePeriodsUniqueToOtherSeries(timeSeries17);
//        java.util.List list23 = timeSeries8.getItems();
//        boolean boolean24 = fixedMillisecond3.equals((java.lang.Object) timeSeries8);
//        java.lang.Class class28 = null;
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class28);
//        timeSeries29.setMaximumItemCount((int) (byte) 0);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener32 = null;
//        timeSeries29.removeChangeListener(seriesChangeListener32);
//        boolean boolean34 = fixedMillisecond3.equals((java.lang.Object) seriesChangeListener32);
//        long long35 = fixedMillisecond3.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass36 = fixedMillisecond3.getClass();
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
//        java.util.Date date38 = day37.getEnd();
//        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.createInstance(date38);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond(date38);
//        long long41 = fixedMillisecond40.getLastMillisecond();
//        java.util.Calendar calendar42 = null;
//        long long43 = fixedMillisecond40.getMiddleMillisecond(calendar42);
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day();
//        java.lang.String str45 = day44.toString();
//        java.util.Date date46 = day44.getStart();
//        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year(date46);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = year47.previous();
//        java.lang.String str49 = regularTimePeriod48.toString();
//        int int50 = fixedMillisecond40.compareTo((java.lang.Object) regularTimePeriod48);
//        long long51 = fixedMillisecond40.getMiddleMillisecond();
//        int int52 = fixedMillisecond3.compareTo((java.lang.Object) fixedMillisecond40);
//        java.util.Calendar calendar53 = null;
//        long long54 = fixedMillisecond40.getLastMillisecond(calendar53);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertNotNull(list12);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertNotNull(list21);
//        org.junit.Assert.assertNotNull(collection22);
//        org.junit.Assert.assertNotNull(list23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560150000000L + "'", long35 == 1560150000000L);
//        org.junit.Assert.assertNotNull(wildcardClass36);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(serialDate39);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560236399999L + "'", long41 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1560236399999L + "'", long43 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "10-June-2019" + "'", str45.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNotNull(regularTimePeriod48);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "2018" + "'", str49.equals("2018"));
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1560236399999L + "'", long51 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1560236399999L + "'", long54 == 1560236399999L);
//    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10);
        java.lang.String str2 = seriesChangeEvent1.toString();
        java.lang.Object obj3 = seriesChangeEvent1.getSource();
        java.lang.String str4 = seriesChangeEvent1.toString();
        java.lang.Object obj5 = seriesChangeEvent1.getSource();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=10]" + "'", str2.equals("org.jfree.data.general.SeriesChangeEvent[source=10]"));
        org.junit.Assert.assertTrue("'" + obj3 + "' != '" + 10 + "'", obj3.equals(10));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=10]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=10]"));
        org.junit.Assert.assertTrue("'" + obj5 + "' != '" + 10 + "'", obj5.equals(10));
    }

//    @Test
//    public void test301() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test301");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
//        java.util.Date date3 = fixedMillisecond2.getTime();
//        long long4 = fixedMillisecond2.getSerialIndex();
//        long long5 = fixedMillisecond2.getFirstMillisecond();
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond2.getMiddleMillisecond(calendar6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond2.next();
//        long long9 = fixedMillisecond2.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560236399999L + "'", long5 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560236399999L + "'", long7 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560236399999L + "'", long9 == 1560236399999L);
//    }

//    @Test
//    public void test302() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test302");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setDomainDescription("hi!");
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        java.util.Date date8 = day7.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) 0);
//        timeSeries4.setDescription("");
//        timeSeries4.setNotify(true);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        java.lang.String str16 = day15.toString();
//        java.util.Date date17 = day15.getStart();
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date17);
//        java.lang.Object obj19 = null;
//        int int20 = year18.compareTo(obj19);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) year18);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.util.Date date23 = day22.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(date23);
//        java.util.Date date25 = fixedMillisecond24.getTime();
//        long long26 = fixedMillisecond24.getSerialIndex();
//        long long27 = fixedMillisecond24.getFirstMillisecond();
//        java.util.Calendar calendar28 = null;
//        long long29 = fixedMillisecond24.getLastMillisecond(calendar28);
//        java.lang.Number number30 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, number30);
//        timeSeries4.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (java.lang.Number) (-2208355200000L));
//        java.util.Date date34 = fixedMillisecond24.getStart();
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(timeSeriesDataItem10);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "10-June-2019" + "'", str16.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem21);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560236399999L + "'", long26 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560236399999L + "'", long27 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560236399999L + "'", long29 == 1560236399999L);
//        org.junit.Assert.assertNotNull(date34);
//    }

//    @Test
//    public void test303() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test303");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        int int3 = day0.compareTo((java.lang.Object) (-1L));
//        java.lang.Class class7 = null;
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class7);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.lang.String str10 = day9.toString();
//        timeSeries8.delete((org.jfree.data.time.RegularTimePeriod) day9);
//        timeSeries8.fireSeriesChanged();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.util.Date date14 = day13.getEnd();
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
//        java.lang.Number number16 = timeSeries8.getValue((org.jfree.data.time.RegularTimePeriod) month15);
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class20);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.lang.String str23 = day22.toString();
//        timeSeries21.delete((org.jfree.data.time.RegularTimePeriod) day22);
//        boolean boolean25 = timeSeries8.equals((java.lang.Object) day22);
//        boolean boolean26 = day0.equals((java.lang.Object) timeSeries8);
//        timeSeries8.setDomainDescription("ERROR : Relative To String");
//        timeSeries8.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
//        java.lang.Class class31 = timeSeries8.getTimePeriodClass();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "10-June-2019" + "'", str23.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNull(class31);
//    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date1);
        java.lang.String str4 = year3.toString();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
    }

//    @Test
//    public void test305() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test305");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        java.util.Date date2 = day0.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
//        java.lang.Class class7 = null;
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class7);
//        timeSeries8.setMaximumItemCount((int) (byte) 0);
//        boolean boolean11 = timeSeries8.getNotify();
//        java.util.List list12 = timeSeries8.getItems();
//        java.lang.Class class16 = null;
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class16);
//        timeSeries17.setMaximumItemCount((int) (byte) 0);
//        boolean boolean20 = timeSeries17.getNotify();
//        java.util.List list21 = timeSeries17.getItems();
//        java.util.Collection collection22 = timeSeries8.getTimePeriodsUniqueToOtherSeries(timeSeries17);
//        java.util.List list23 = timeSeries8.getItems();
//        boolean boolean24 = fixedMillisecond3.equals((java.lang.Object) timeSeries8);
//        java.lang.Class class28 = null;
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class28);
//        timeSeries29.setMaximumItemCount((int) (byte) 0);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener32 = null;
//        timeSeries29.removeChangeListener(seriesChangeListener32);
//        boolean boolean34 = fixedMillisecond3.equals((java.lang.Object) seriesChangeListener32);
//        long long35 = fixedMillisecond3.getMiddleMillisecond();
//        long long36 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = fixedMillisecond3.previous();
//        java.util.Calendar calendar38 = null;
//        fixedMillisecond3.peg(calendar38);
//        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
//        int int41 = fixedMillisecond3.compareTo((java.lang.Object) year40);
//        long long42 = year40.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertNotNull(list12);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertNotNull(list21);
//        org.junit.Assert.assertNotNull(collection22);
//        org.junit.Assert.assertNotNull(list23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560150000000L + "'", long35 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560150000000L + "'", long36 == 1560150000000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1562097599999L + "'", long42 == 1562097599999L);
//    }

//    @Test
//    public void test306() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test306");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setMaximumItemCount((int) (byte) 0);
//        boolean boolean7 = timeSeries4.getNotify();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class11);
//        timeSeries12.setDomainDescription("hi!");
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        java.util.Date date16 = day15.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day15, (java.lang.Number) 0);
//        java.lang.Object obj19 = null;
//        boolean boolean20 = timeSeries12.equals(obj19);
//        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries4.addAndOrUpdate(timeSeries12);
//        timeSeries21.setNotify(true);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        java.util.Date date25 = day24.getEnd();
//        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(date25);
//        java.lang.String str27 = month26.toString();
//        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean29 = month26.equals((java.lang.Object) timeZone28);
//        int int30 = month26.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = month26.previous();
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        java.util.Date date33 = day32.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond(date33);
//        java.util.Date date35 = fixedMillisecond34.getTime();
//        long long36 = fixedMillisecond34.getSerialIndex();
//        long long37 = fixedMillisecond34.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries21.createCopy((org.jfree.data.time.RegularTimePeriod) month26, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = month26.next();
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNull(timeSeriesDataItem18);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(timeSeries21);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "June 2019" + "'", str27.equals("June 2019"));
//        org.junit.Assert.assertNotNull(timeZone28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560236399999L + "'", long36 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560236399999L + "'", long37 == 1560236399999L);
//        org.junit.Assert.assertNotNull(timeSeries38);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//    }

//    @Test
//    public void test307() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test307");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setMaximumItemCount((int) (byte) 0);
//        boolean boolean7 = timeSeries4.getNotify();
//        java.util.List list8 = timeSeries4.getItems();
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class12);
//        timeSeries13.setMaximumItemCount((int) (byte) 0);
//        boolean boolean16 = timeSeries13.getNotify();
//        java.util.List list17 = timeSeries13.getItems();
//        java.util.Collection collection18 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries13);
//        boolean boolean19 = timeSeries4.isEmpty();
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        java.util.Date date21 = day20.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(date21);
//        java.util.Date date23 = fixedMillisecond22.getTime();
//        long long24 = fixedMillisecond22.getSerialIndex();
//        long long25 = fixedMillisecond22.getFirstMillisecond();
//        java.util.Calendar calendar26 = null;
//        long long27 = fixedMillisecond22.getMiddleMillisecond(calendar26);
//        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.createInstance(9);
//        org.jfree.data.time.SerialDate serialDate33 = serialDate30.getEndOfCurrentMonth(serialDate32);
//        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate32);
//        boolean boolean35 = fixedMillisecond22.equals((java.lang.Object) serialDate32);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = fixedMillisecond22.next();
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
//        java.util.Date date38 = day37.getEnd();
//        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month(date38);
//        java.lang.String str40 = month39.toString();
//        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean42 = month39.equals((java.lang.Object) timeZone41);
//        int int43 = month39.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = month39.previous();
//        org.jfree.data.time.TimeSeries timeSeries45 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, regularTimePeriod44);
//        long long46 = fixedMillisecond22.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(list8);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNotNull(list17);
//        org.junit.Assert.assertNotNull(collection18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560236399999L + "'", long24 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560236399999L + "'", long25 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560236399999L + "'", long27 == 1560236399999L);
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertNotNull(serialDate32);
//        org.junit.Assert.assertNotNull(serialDate33);
//        org.junit.Assert.assertNotNull(serialDate34);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "June 2019" + "'", str40.equals("June 2019"));
//        org.junit.Assert.assertNotNull(timeZone41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 2019 + "'", int43 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod44);
//        org.junit.Assert.assertNotNull(timeSeries45);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1560236399999L + "'", long46 == 1560236399999L);
//    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate7 = serialDate4.getEndOfCurrentMonth(serialDate6);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean11 = spreadsheetDate1.isInRange(serialDate6, (org.jfree.data.time.SerialDate) spreadsheetDate10);
        int int12 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean15 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate21 = serialDate18.getEndOfCurrentMonth(serialDate20);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addDays(0, serialDate21);
        boolean boolean23 = spreadsheetDate1.isOnOrBefore(serialDate21);
        int int24 = spreadsheetDate1.getYYYY();
        java.lang.String str25 = spreadsheetDate1.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(1900);
        boolean boolean28 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate27);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1900 + "'", int12 == 1900);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1900 + "'", int24 == 1900);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate9 = serialDate6.getEndOfCurrentMonth(serialDate8);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean13 = spreadsheetDate3.isInRange(serialDate8, (org.jfree.data.time.SerialDate) spreadsheetDate12);
        int int14 = spreadsheetDate3.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean17 = spreadsheetDate3.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate23 = serialDate20.getEndOfCurrentMonth(serialDate22);
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate22);
        boolean boolean25 = spreadsheetDate16.isOnOrAfter(serialDate22);
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.addYears(0, (org.jfree.data.time.SerialDate) spreadsheetDate16);
        try {
            org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((-1), serialDate26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1900 + "'", int14 == 1900);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(serialDate26);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        java.lang.String str3 = month2.toString();
        int int4 = month2.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (double) (short) -1);
        timeSeriesDataItem6.setValue((java.lang.Number) (byte) 10);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(9);
        boolean boolean4 = spreadsheetDate1.isOnOrAfter(serialDate3);
        int int5 = spreadsheetDate1.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate14 = serialDate11.getEndOfCurrentMonth(serialDate13);
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean18 = spreadsheetDate8.isInRange(serialDate13, (org.jfree.data.time.SerialDate) spreadsheetDate17);
        int int19 = spreadsheetDate8.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean22 = spreadsheetDate8.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate28 = serialDate25.getEndOfCurrentMonth(serialDate27);
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate27);
        boolean boolean30 = spreadsheetDate21.isOnOrAfter(serialDate27);
        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.addYears(0, (org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate39 = serialDate36.getEndOfCurrentMonth(serialDate38);
        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate38);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean43 = spreadsheetDate33.isInRange(serialDate38, (org.jfree.data.time.SerialDate) spreadsheetDate42);
        int int44 = spreadsheetDate33.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean47 = spreadsheetDate33.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate46);
        org.jfree.data.time.SerialDate serialDate50 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate52 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate53 = serialDate50.getEndOfCurrentMonth(serialDate52);
        org.jfree.data.time.SerialDate serialDate54 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate52);
        boolean boolean55 = spreadsheetDate46.isOnOrAfter(serialDate52);
        int int56 = spreadsheetDate46.getMonth();
        int int57 = spreadsheetDate46.getDayOfWeek();
        boolean boolean58 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate21, (org.jfree.data.time.SerialDate) spreadsheetDate46);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1900 + "'", int19 == 1900);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertNotNull(serialDate38);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1900 + "'", int44 == 1900);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertNotNull(serialDate52);
        org.junit.Assert.assertNotNull(serialDate53);
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 3 + "'", int57 == 3);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(2147483647);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test313() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test313");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        int int3 = day0.compareTo((java.lang.Object) (-1L));
//        java.lang.Class class7 = null;
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class7);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.lang.String str10 = day9.toString();
//        timeSeries8.delete((org.jfree.data.time.RegularTimePeriod) day9);
//        timeSeries8.fireSeriesChanged();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.util.Date date14 = day13.getEnd();
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
//        java.lang.Number number16 = timeSeries8.getValue((org.jfree.data.time.RegularTimePeriod) month15);
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class20);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.lang.String str23 = day22.toString();
//        timeSeries21.delete((org.jfree.data.time.RegularTimePeriod) day22);
//        boolean boolean25 = timeSeries8.equals((java.lang.Object) day22);
//        boolean boolean26 = day0.equals((java.lang.Object) timeSeries8);
//        timeSeries8.setDomainDescription("ERROR : Relative To String");
//        timeSeries8.setMaximumItemCount(3);
//        java.lang.Class class31 = timeSeries8.getTimePeriodClass();
//        timeSeries8.setNotify(false);
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        java.lang.String str35 = day34.toString();
//        java.util.Date date36 = day34.getStart();
//        long long37 = day34.getLastMillisecond();
//        int int38 = timeSeries8.getIndex((org.jfree.data.time.RegularTimePeriod) day34);
//        java.lang.String str39 = timeSeries8.getRangeDescription();
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day();
//        java.lang.String str41 = day40.toString();
//        java.util.Date date42 = day40.getStart();
//        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year(date42);
//        long long44 = year43.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = year43.next();
//        java.lang.Number number46 = timeSeries8.getValue(regularTimePeriod45);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "10-June-2019" + "'", str23.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNull(class31);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "10-June-2019" + "'", str35.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560236399999L + "'", long37 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "hi!" + "'", str39.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "10-June-2019" + "'", str41.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1577865599999L + "'", long44 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertNull(number46);
//    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(9);
        boolean boolean4 = spreadsheetDate1.isOnOrAfter(serialDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate12 = serialDate9.getEndOfCurrentMonth(serialDate11);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean16 = spreadsheetDate6.isInRange(serialDate11, (org.jfree.data.time.SerialDate) spreadsheetDate15);
        int int17 = spreadsheetDate6.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean20 = spreadsheetDate6.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate26 = serialDate23.getEndOfCurrentMonth(serialDate25);
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.addDays(0, serialDate26);
        boolean boolean28 = spreadsheetDate6.isOnOrBefore(serialDate26);
        int int29 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.createInstance(9);
        boolean boolean36 = spreadsheetDate33.isOnOrAfter(serialDate35);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate44 = serialDate41.getEndOfCurrentMonth(serialDate43);
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate43);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean48 = spreadsheetDate38.isInRange(serialDate43, (org.jfree.data.time.SerialDate) spreadsheetDate47);
        int int49 = spreadsheetDate38.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean52 = spreadsheetDate38.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate51);
        org.jfree.data.time.SerialDate serialDate55 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate57 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate58 = serialDate55.getEndOfCurrentMonth(serialDate57);
        org.jfree.data.time.SerialDate serialDate59 = org.jfree.data.time.SerialDate.addDays(0, serialDate58);
        boolean boolean60 = spreadsheetDate38.isOnOrBefore(serialDate58);
        int int61 = spreadsheetDate33.compare((org.jfree.data.time.SerialDate) spreadsheetDate38);
        int int62 = spreadsheetDate38.getDayOfMonth();
        int int63 = spreadsheetDate38.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate65 = new org.jfree.data.time.SpreadsheetDate(12);
        java.util.Date date66 = spreadsheetDate65.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate68 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate71 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate73 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate74 = serialDate71.getEndOfCurrentMonth(serialDate73);
        org.jfree.data.time.SerialDate serialDate75 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate73);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate77 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean78 = spreadsheetDate68.isInRange(serialDate73, (org.jfree.data.time.SerialDate) spreadsheetDate77);
        org.jfree.data.time.SerialDate serialDate80 = serialDate73.getPreviousDayOfWeek(7);
        boolean boolean81 = spreadsheetDate38.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate65, serialDate80);
        org.jfree.data.time.SerialDate serialDate82 = org.jfree.data.time.SerialDate.addDays((int) (short) -1, (org.jfree.data.time.SerialDate) spreadsheetDate38);
        org.jfree.data.time.SerialDate serialDate83 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate38);
        boolean boolean84 = spreadsheetDate6.isOn(serialDate83);
        try {
            org.jfree.data.time.SerialDate serialDate86 = serialDate83.getPreviousDayOfWeek(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1900 + "'", int17 == 1900);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1900 + "'", int49 == 1900);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(serialDate55);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertNotNull(serialDate58);
        org.junit.Assert.assertNotNull(serialDate59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 2 + "'", int62 == 2);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 3 + "'", int63 == 3);
        org.junit.Assert.assertNotNull(date66);
        org.junit.Assert.assertNotNull(serialDate71);
        org.junit.Assert.assertNotNull(serialDate73);
        org.junit.Assert.assertNotNull(serialDate74);
        org.junit.Assert.assertNotNull(serialDate75);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
        org.junit.Assert.assertNotNull(serialDate80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNotNull(serialDate82);
        org.junit.Assert.assertNotNull(serialDate83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + true + "'", boolean84 == true);
    }

//    @Test
//    public void test315() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test315");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setDomainDescription("hi!");
//        java.lang.Object obj7 = timeSeries4.clone();
//        java.lang.String str8 = timeSeries4.getDescription();
//        timeSeries4.setMaximumItemAge((long) 9999);
//        java.lang.Class class14 = null;
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class14);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        java.lang.String str17 = day16.toString();
//        timeSeries15.delete((org.jfree.data.time.RegularTimePeriod) day16);
//        timeSeries15.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener20 = null;
//        timeSeries15.addPropertyChangeListener(propertyChangeListener20);
//        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries4.addAndOrUpdate(timeSeries15);
//        java.lang.Class class26 = null;
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class26);
//        timeSeries27.setMaximumItemCount((int) (byte) 0);
//        boolean boolean30 = timeSeries27.getNotify();
//        java.util.List list31 = timeSeries27.getItems();
//        java.lang.Class class35 = null;
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class35);
//        timeSeries36.setMaximumItemCount((int) (byte) 0);
//        boolean boolean39 = timeSeries36.getNotify();
//        java.util.List list40 = timeSeries36.getItems();
//        java.util.Collection collection41 = timeSeries27.getTimePeriodsUniqueToOtherSeries(timeSeries36);
//        java.util.List list42 = timeSeries27.getItems();
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
//        java.util.Date date44 = day43.getEnd();
//        int int46 = day43.compareTo((java.lang.Object) (-1L));
//        java.lang.Class class50 = null;
//        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class50);
//        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day();
//        java.lang.String str53 = day52.toString();
//        timeSeries51.delete((org.jfree.data.time.RegularTimePeriod) day52);
//        timeSeries51.fireSeriesChanged();
//        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day();
//        java.util.Date date57 = day56.getEnd();
//        org.jfree.data.time.Month month58 = new org.jfree.data.time.Month(date57);
//        java.lang.Number number59 = timeSeries51.getValue((org.jfree.data.time.RegularTimePeriod) month58);
//        java.lang.Class class63 = null;
//        org.jfree.data.time.TimeSeries timeSeries64 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class63);
//        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day();
//        java.lang.String str66 = day65.toString();
//        timeSeries64.delete((org.jfree.data.time.RegularTimePeriod) day65);
//        boolean boolean68 = timeSeries51.equals((java.lang.Object) day65);
//        boolean boolean69 = day43.equals((java.lang.Object) timeSeries51);
//        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day();
//        java.lang.String str71 = day70.toString();
//        java.util.Date date72 = day70.getStart();
//        long long73 = day70.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries74 = timeSeries27.createCopy((org.jfree.data.time.RegularTimePeriod) day43, (org.jfree.data.time.RegularTimePeriod) day70);
//        timeSeries27.setKey((java.lang.Comparable) 0L);
//        java.lang.Class class77 = timeSeries27.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries78 = timeSeries22.addAndOrUpdate(timeSeries27);
//        java.beans.PropertyChangeListener propertyChangeListener79 = null;
//        timeSeries78.addPropertyChangeListener(propertyChangeListener79);
//        org.junit.Assert.assertNotNull(obj7);
//        org.junit.Assert.assertNull(str8);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "10-June-2019" + "'", str17.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(timeSeries22);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
//        org.junit.Assert.assertNotNull(list31);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
//        org.junit.Assert.assertNotNull(list40);
//        org.junit.Assert.assertNotNull(collection41);
//        org.junit.Assert.assertNotNull(list42);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "10-June-2019" + "'", str53.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date57);
//        org.junit.Assert.assertNull(number59);
//        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "10-June-2019" + "'", str66.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
//        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
//        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "10-June-2019" + "'", str71.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date72);
//        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 1560236399999L + "'", long73 == 1560236399999L);
//        org.junit.Assert.assertNotNull(timeSeries74);
//        org.junit.Assert.assertNull(class77);
//        org.junit.Assert.assertNotNull(timeSeries78);
//    }

//    @Test
//    public void test316() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test316");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        java.util.Date date2 = day0.getStart();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) 10.0f);
//        boolean boolean6 = day0.equals((java.lang.Object) (byte) -1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day0.previous();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//    }

//    @Test
//    public void test317() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test317");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setMaximumItemCount((int) (byte) 0);
//        boolean boolean7 = timeSeries4.getNotify();
//        java.util.List list8 = timeSeries4.getItems();
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class12);
//        timeSeries13.setMaximumItemCount((int) (byte) 0);
//        boolean boolean16 = timeSeries13.getNotify();
//        java.util.List list17 = timeSeries13.getItems();
//        java.util.Collection collection18 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries13);
//        boolean boolean19 = timeSeries4.isEmpty();
//        timeSeries4.setDomainDescription("2019");
//        java.lang.Class class25 = null;
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class25);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        java.lang.String str28 = day27.toString();
//        timeSeries26.delete((org.jfree.data.time.RegularTimePeriod) day27);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        java.util.Date date31 = day30.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond(date31);
//        java.util.Date date33 = fixedMillisecond32.getTime();
//        long long34 = fixedMillisecond32.getSerialIndex();
//        long long35 = fixedMillisecond32.getFirstMillisecond();
//        java.util.Calendar calendar36 = null;
//        long long37 = fixedMillisecond32.getMiddleMillisecond(calendar36);
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) day27, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond32);
//        int int39 = day27.getYear();
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(list8);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNotNull(list17);
//        org.junit.Assert.assertNotNull(collection18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "10-June-2019" + "'", str28.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560236399999L + "'", long34 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560236399999L + "'", long35 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560236399999L + "'", long37 == 1560236399999L);
//        org.junit.Assert.assertNotNull(timeSeries38);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2019 + "'", int39 == 2019);
//    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("2019");
    }

//    @Test
//    public void test319() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test319");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        java.util.Date date2 = day0.getStart();
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
//        java.lang.Object obj4 = null;
//        int int5 = year3.compareTo(obj4);
//        int int6 = year3.getYear();
//        long long7 = year3.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year3.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod8, 0.0d);
//        java.lang.Number number11 = timeSeriesDataItem10.getValue();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 0.0d + "'", number11.equals(0.0d));
//    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
        timeSeries4.setDomainDescription("hi!");
        java.lang.Object obj7 = timeSeries4.clone();
        java.lang.String str8 = timeSeries4.getDescription();
        timeSeries4.setRangeDescription("June 2019");
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries4.getDataItem((-460));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SerialDate serialDate7 = serialDate4.getEndOfCurrentMonth(serialDate6);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean11 = spreadsheetDate1.isInRange(serialDate6, (org.jfree.data.time.SerialDate) spreadsheetDate10);
        int int12 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(3);
        boolean boolean15 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate14);
        int int16 = spreadsheetDate14.getMonth();
        int int17 = spreadsheetDate14.getMonth();
        int int18 = spreadsheetDate14.toSerial();
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1900 + "'", int12 == 1900);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 3 + "'", int18 == 3);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test323() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test323");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day5);
//        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries4.createCopy(1, (int) (short) 100);
//        timeSeries10.setMaximumItemCount(2);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(timeSeries10);
//    }

//    @Test
//    public void test324() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test324");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class3);
//        timeSeries4.setMaximumItemCount((int) (byte) 0);
//        boolean boolean7 = timeSeries4.getNotify();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class11);
//        timeSeries12.setDomainDescription("hi!");
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        java.util.Date date16 = day15.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day15, (java.lang.Number) 0);
//        java.lang.Object obj19 = null;
//        boolean boolean20 = timeSeries12.equals(obj19);
//        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries4.addAndOrUpdate(timeSeries12);
//        timeSeries21.setNotify(true);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        java.util.Date date25 = day24.getEnd();
//        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(date25);
//        java.lang.String str27 = month26.toString();
//        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean29 = month26.equals((java.lang.Object) timeZone28);
//        int int30 = month26.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = month26.previous();
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        java.util.Date date33 = day32.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond(date33);
//        java.util.Date date35 = fixedMillisecond34.getTime();
//        long long36 = fixedMillisecond34.getSerialIndex();
//        long long37 = fixedMillisecond34.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries21.createCopy((org.jfree.data.time.RegularTimePeriod) month26, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
//        timeSeries38.clear();
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day();
//        java.util.Date date41 = day40.getEnd();
//        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month(date41);
//        java.lang.String str43 = month42.toString();
//        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean45 = month42.equals((java.lang.Object) timeZone44);
//        int int46 = month42.getMonth();
//        long long47 = month42.getLastMillisecond();
//        long long48 = month42.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = timeSeries38.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month42, (double) 2019L);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNull(timeSeriesDataItem18);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(timeSeries21);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "June 2019" + "'", str27.equals("June 2019"));
//        org.junit.Assert.assertNotNull(timeZone28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560236399999L + "'", long36 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560236399999L + "'", long37 == 1560236399999L);
//        org.junit.Assert.assertNotNull(timeSeries38);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "June 2019" + "'", str43.equals("June 2019"));
//        org.junit.Assert.assertNotNull(timeZone44);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 6 + "'", int46 == 6);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1561964399999L + "'", long47 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 24234L + "'", long48 == 24234L);
//        org.junit.Assert.assertNull(timeSeriesDataItem50);
//    }

//    @Test
//    public void test325() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test325");
//        java.lang.Class class4 = null;
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), "hi!", "hi!", class4);
//        timeSeries5.setDomainDescription("hi!");
//        java.lang.Object obj8 = timeSeries5.clone();
//        java.lang.String str9 = timeSeries5.getDescription();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        java.lang.String str11 = day10.toString();
//        java.util.Date date12 = day10.getStart();
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date12);
//        long long14 = year13.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) 100.0f);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        java.lang.String str18 = day17.toString();
//        java.util.Date date19 = day17.getStart();
//        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date19);
//        java.lang.Object obj21 = null;
//        int int22 = year20.compareTo(obj21);
//        java.lang.String str23 = year20.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year20.previous();
//        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) year13, (org.jfree.data.time.RegularTimePeriod) year20);
//        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(9, year20);
//        org.junit.Assert.assertNotNull(obj8);
//        org.junit.Assert.assertNull(str9);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10-June-2019" + "'", str11.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "10-June-2019" + "'", str18.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "2019" + "'", str23.equals("2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(timeSeries25);
//    }
//}

