import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (-1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.jfree.data.time.TimePeriod timePeriod0 = null;
        java.lang.Number number1 = null;
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue(timePeriod0, number1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        timePeriodValues1.setKey((java.lang.Comparable) 100L);
        timePeriodValues1.setKey((java.lang.Comparable) (short) 100);
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = null;
        try {
            timePeriodValues1.add(timePeriodValue8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null item not allowed.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        java.util.Date date0 = null;
        java.util.Date date1 = null;
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(date0, date1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getItemCount();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        org.jfree.data.time.TimePeriod timePeriod8 = null;
        try {
            timePeriodValues1.add(timePeriod8, (java.lang.Number) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        boolean boolean5 = timePeriodValues1.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.TimePeriod timePeriod6 = null;
        try {
            timePeriodValues1.add(timePeriod6, (double) 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        timePeriodValues1.setKey((java.lang.Comparable) 100L);
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue7 = timePeriodValues1.getDataItem((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(10, (int) (byte) 100, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = year0.getMiddleMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener11);
        java.lang.String str13 = timePeriodValues1.getDomainDescription();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue15 = timePeriodValues1.getDataItem((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        try {
            java.lang.Number number12 = timePeriodValues1.getValue((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMinEndIndex();
        java.lang.String str6 = timePeriodValues1.getRangeDescription();
        try {
            java.lang.Number number8 = timePeriodValues1.getValue(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Value" + "'", str6.equals("Value"));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.jfree.data.time.SerialDate serialDate0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(serialDate0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'serialDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("hi!");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMinEndIndex();
        java.lang.String str6 = timePeriodValues1.getRangeDescription();
        timePeriodValues1.setDescription("hi!");
        int int9 = timePeriodValues1.getItemCount();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Value" + "'", str6.equals("Value"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        java.util.Calendar calendar11 = null;
        try {
            year8.peg(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year0.getFirstMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 12, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (byte) 0, 1, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        boolean boolean2 = timePeriodValues1.getNotify();
        try {
            timePeriodValues1.update((int) (short) 100, (java.lang.Number) 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        timePeriodValues1.setKey((java.lang.Comparable) 100L);
        timePeriodValues1.setKey((java.lang.Comparable) (short) 100);
        java.lang.Number number9 = null;
        try {
            timePeriodValues1.update((int) '#', number9);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = day0.getFirstMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        timePeriodValues1.fireSeriesChanged();
        try {
            org.jfree.data.time.TimePeriod timePeriod10 = timePeriodValues1.getTimePeriod(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = day0.getFirstMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        java.lang.String str11 = year8.toString();
        java.util.Calendar calendar12 = null;
        try {
            year8.peg(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2019" + "'", str11.equals("2019"));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMinEndIndex();
        boolean boolean6 = timePeriodValues1.isEmpty();
        java.lang.Object obj7 = timePeriodValues1.clone();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener11);
        java.lang.String str13 = timePeriodValues1.getDomainDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues15.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timePeriodValues15.removePropertyChangeListener(propertyChangeListener18);
        java.lang.String str20 = timePeriodValues15.getDescription();
        int int21 = timePeriodValues15.getMinStartIndex();
        timePeriodValues15.fireSeriesChanged();
        boolean boolean23 = timePeriodValues1.equals((java.lang.Object) timePeriodValues15);
        timePeriodValues1.setRangeDescription("");
        org.jfree.data.time.TimePeriodValues timePeriodValues27 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener28 = null;
        timePeriodValues27.addChangeListener(seriesChangeListener28);
        int int30 = timePeriodValues27.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass31 = timePeriodValues27.getClass();
        java.util.Date date32 = null;
        java.util.TimeZone timeZone33 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass31, date32, timeZone33);
        boolean boolean35 = timePeriodValues1.equals((java.lang.Object) regularTimePeriod34);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertNull(regularTimePeriod34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
        try {
            timePeriodValues1.update(5, (java.lang.Number) 100.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

//    @Test
//    public void test044() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test044");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        java.util.Calendar calendar2 = null;
//        try {
//            long long3 = day0.getLastMillisecond(calendar2);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 2019L);
        java.util.Date date13 = year8.getEnd();
        java.util.Date date14 = null;
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod(date13, date14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(date13);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        timePeriodValues1.setKey((java.lang.Comparable) 100L);
        timePeriodValues1.setKey((java.lang.Comparable) (short) 100);
        try {
            java.lang.Number number9 = timePeriodValues1.getValue(11);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 11, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues3.setNotify(true);
        boolean boolean7 = timePeriodValues3.equals((java.lang.Object) (short) 0);
        boolean boolean8 = year0.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        timePeriodValues10.setKey((java.lang.Comparable) 100L);
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues16.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timePeriodValues16.removePropertyChangeListener(propertyChangeListener19);
        int int21 = timePeriodValues16.getItemCount();
        int int22 = timePeriodValues16.getMaxMiddleIndex();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        timePeriodValues16.add((org.jfree.data.time.TimePeriod) year23, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue27 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year23, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year23.previous();
        timePeriodValues10.setKey((java.lang.Comparable) year23);
        int int30 = year0.compareTo((java.lang.Object) year23);
        long long31 = year0.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1562097599999L + "'", long31 == 1562097599999L);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        try {
            org.jfree.data.time.TimePeriod timePeriod9 = timePeriodValues1.getTimePeriod(6);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) -1, (int) (byte) 10, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Calendar calendar1 = null;
        try {
            year0.peg(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMinEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener6);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 0L);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = day0.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getMinMiddleIndex();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 100);
        timePeriodValue3.setValue((java.lang.Number) (byte) -1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        timePeriodValues1.fireSeriesChanged();
        try {
            java.lang.Number number10 = timePeriodValues1.getValue((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener11);
        java.lang.String str13 = timePeriodValues1.getDomainDescription();
        try {
            timePeriodValues1.delete(0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 2019L);
        int int13 = year8.getYear();
        java.util.Calendar calendar14 = null;
        try {
            long long15 = year8.getLastMillisecond(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 100);
        java.util.Date date4 = year0.getStart();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year0.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.general.SeriesChangeEvent[source=0]");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener11);
        java.lang.String str13 = timePeriodValues1.getDomainDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues15.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timePeriodValues15.removePropertyChangeListener(propertyChangeListener18);
        java.lang.String str20 = timePeriodValues15.getDescription();
        int int21 = timePeriodValues15.getMinStartIndex();
        timePeriodValues15.fireSeriesChanged();
        boolean boolean23 = timePeriodValues1.equals((java.lang.Object) timePeriodValues15);
        boolean boolean24 = timePeriodValues15.isEmpty();
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

//    @Test
//    public void test065() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test065");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getMiddleMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = day0.getMiddleMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560452399999L + "'", long2 == 1560452399999L);
//        org.junit.Assert.assertNotNull(serialDate3);
//    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        try {
            timePeriodValues1.delete((int) (short) 10, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (4) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues3.setNotify(true);
        boolean boolean7 = timePeriodValues3.equals((java.lang.Object) (short) 0);
        boolean boolean8 = year0.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        timePeriodValues10.setKey((java.lang.Comparable) 100L);
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues16.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timePeriodValues16.removePropertyChangeListener(propertyChangeListener19);
        int int21 = timePeriodValues16.getItemCount();
        int int22 = timePeriodValues16.getMaxMiddleIndex();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        timePeriodValues16.add((org.jfree.data.time.TimePeriod) year23, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue27 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year23, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year23.previous();
        timePeriodValues10.setKey((java.lang.Comparable) year23);
        int int30 = year0.compareTo((java.lang.Object) year23);
        java.util.Calendar calendar31 = null;
        try {
            long long32 = year23.getFirstMillisecond(calendar31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues3.setNotify(true);
        boolean boolean7 = timePeriodValues3.equals((java.lang.Object) (short) 0);
        boolean boolean8 = year0.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        timePeriodValues10.setKey((java.lang.Comparable) 100L);
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues16.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timePeriodValues16.removePropertyChangeListener(propertyChangeListener19);
        int int21 = timePeriodValues16.getItemCount();
        int int22 = timePeriodValues16.getMaxMiddleIndex();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        timePeriodValues16.add((org.jfree.data.time.TimePeriod) year23, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue27 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year23, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year23.previous();
        timePeriodValues10.setKey((java.lang.Comparable) year23);
        int int30 = year0.compareTo((java.lang.Object) year23);
        int int31 = year23.getYear();
        java.util.Calendar calendar32 = null;
        try {
            long long33 = year23.getFirstMillisecond(calendar32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2019 + "'", int31 == 2019);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener13);
        int int15 = timePeriodValues10.getItemCount();
        int int16 = timePeriodValues10.getMaxMiddleIndex();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) year17, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 2019L);
        java.util.Date date22 = year17.getEnd();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date22, timeZone23);
        java.lang.Class class25 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(class25);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        timePeriodValues1.setNotify(true);
        java.lang.Number number11 = null;
        try {
            timePeriodValues1.update(100, number11);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("2019");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        int int11 = timePeriodValues1.getMinMiddleIndex();
        timePeriodValues1.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=0]");
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        long long3 = year2.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year2, (java.lang.Number) 100);
        java.lang.Object obj6 = timePeriodValue5.clone();
        int int7 = day0.compareTo(obj6);
        java.util.Calendar calendar8 = null;
        try {
            long long9 = day0.getFirstMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("13-June-2019");
        org.junit.Assert.assertNull(day1);
    }

//    @Test
//    public void test078() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test078");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 0L);
//        int int3 = day0.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMinEndIndex();
        java.lang.String str6 = timePeriodValues1.getRangeDescription();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year7.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod9, (java.lang.Number) 6);
        boolean boolean12 = timePeriodValues1.getNotify();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue14 = timePeriodValues1.getDataItem((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Value" + "'", str6.equals("Value"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener13);
        int int15 = timePeriodValues10.getItemCount();
        int int16 = timePeriodValues10.getMaxMiddleIndex();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) year17, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 2019L);
        java.util.Date date22 = year17.getEnd();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date22, timeZone23);
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues26.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timePeriodValues26.removePropertyChangeListener(propertyChangeListener29);
        int int31 = timePeriodValues26.getItemCount();
        int int32 = timePeriodValues26.getMaxMiddleIndex();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        timePeriodValues26.add((org.jfree.data.time.TimePeriod) year33, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue37 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year33, (java.lang.Number) 2019L);
        java.util.Date date38 = year33.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(date22, date38);
        long long40 = simpleTimePeriod39.getEndMillis();
        long long41 = simpleTimePeriod39.getStartMillis();
        boolean boolean43 = simpleTimePeriod39.equals((java.lang.Object) 0);
        java.util.Date date44 = simpleTimePeriod39.getStart();
        java.util.Date date45 = null;
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod46 = new org.jfree.data.time.SimpleTimePeriod(date44, date45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1577865599999L + "'", long40 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1577865599999L + "'", long41 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(date44);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener13);
        int int15 = timePeriodValues10.getItemCount();
        int int16 = timePeriodValues10.getMaxMiddleIndex();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) year17, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 2019L);
        java.util.Date date22 = year17.getEnd();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date22, timeZone23);
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues26.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timePeriodValues26.removePropertyChangeListener(propertyChangeListener29);
        int int31 = timePeriodValues26.getItemCount();
        int int32 = timePeriodValues26.getMaxMiddleIndex();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        timePeriodValues26.add((org.jfree.data.time.TimePeriod) year33, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue37 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year33, (java.lang.Number) 2019L);
        java.util.Date date38 = year33.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(date22, date38);
        long long40 = simpleTimePeriod39.getEndMillis();
        long long41 = simpleTimePeriod39.getStartMillis();
        boolean boolean43 = simpleTimePeriod39.equals((java.lang.Object) 0);
        java.util.Date date44 = simpleTimePeriod39.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues46 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener47 = null;
        timePeriodValues46.addChangeListener(seriesChangeListener47);
        int int49 = timePeriodValues46.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass50 = timePeriodValues46.getClass();
        java.util.Date date51 = null;
        java.util.TimeZone timeZone52 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass50, date51, timeZone52);
        org.jfree.data.time.TimePeriodValues timePeriodValues55 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues55.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener58 = null;
        timePeriodValues55.removePropertyChangeListener(propertyChangeListener58);
        int int60 = timePeriodValues55.getItemCount();
        int int61 = timePeriodValues55.getMaxMiddleIndex();
        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year();
        timePeriodValues55.add((org.jfree.data.time.TimePeriod) year62, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue66 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year62, (java.lang.Number) 2019L);
        java.util.Date date67 = year62.getEnd();
        java.util.TimeZone timeZone68 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass50, date67, timeZone68);
        org.jfree.data.time.TimePeriodValues timePeriodValues71 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues71.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener74 = null;
        timePeriodValues71.removePropertyChangeListener(propertyChangeListener74);
        int int76 = timePeriodValues71.getItemCount();
        int int77 = timePeriodValues71.getMaxMiddleIndex();
        org.jfree.data.time.Year year78 = new org.jfree.data.time.Year();
        timePeriodValues71.add((org.jfree.data.time.TimePeriod) year78, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue82 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year78, (java.lang.Number) 2019L);
        java.util.Date date83 = year78.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod84 = new org.jfree.data.time.SimpleTimePeriod(date67, date83);
        java.util.TimeZone timeZone85 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year86 = new org.jfree.data.time.Year(date67, timeZone85);
        boolean boolean87 = simpleTimePeriod39.equals((java.lang.Object) date67);
        long long88 = simpleTimePeriod39.getStartMillis();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1577865599999L + "'", long40 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1577865599999L + "'", long41 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertNull(regularTimePeriod53);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
        org.junit.Assert.assertNotNull(date67);
        org.junit.Assert.assertNotNull(timeZone68);
        org.junit.Assert.assertNull(regularTimePeriod69);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 0 + "'", int76 == 0);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + (-1) + "'", int77 == (-1));
        org.junit.Assert.assertNotNull(date83);
        org.junit.Assert.assertNotNull(timeZone85);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertTrue("'" + long88 + "' != '" + 1577865599999L + "'", long88 == 1577865599999L);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues3.setNotify(true);
        boolean boolean7 = timePeriodValues3.equals((java.lang.Object) (short) 0);
        boolean boolean8 = year0.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        timePeriodValues10.setKey((java.lang.Comparable) 100L);
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues16.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timePeriodValues16.removePropertyChangeListener(propertyChangeListener19);
        int int21 = timePeriodValues16.getItemCount();
        int int22 = timePeriodValues16.getMaxMiddleIndex();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        timePeriodValues16.add((org.jfree.data.time.TimePeriod) year23, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue27 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year23, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year23.previous();
        timePeriodValues10.setKey((java.lang.Comparable) year23);
        int int30 = year0.compareTo((java.lang.Object) year23);
        int int31 = year23.getYear();
        long long32 = year23.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2019 + "'", int31 == 2019);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 2019L + "'", long32 == 2019L);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues3.setNotify(true);
        boolean boolean7 = timePeriodValues3.equals((java.lang.Object) (short) 0);
        boolean boolean8 = year0.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        timePeriodValues10.setKey((java.lang.Comparable) 100L);
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues16.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timePeriodValues16.removePropertyChangeListener(propertyChangeListener19);
        int int21 = timePeriodValues16.getItemCount();
        int int22 = timePeriodValues16.getMaxMiddleIndex();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        timePeriodValues16.add((org.jfree.data.time.TimePeriod) year23, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue27 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year23, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year23.previous();
        timePeriodValues10.setKey((java.lang.Comparable) year23);
        int int30 = year0.compareTo((java.lang.Object) year23);
        int int31 = year0.getYear();
        long long32 = year0.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2019 + "'", int31 == 2019);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 2019L + "'", long32 == 2019L);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        java.lang.Comparable comparable0 = null;
        try {
            org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues(comparable0, "", "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1.0f);
        timePeriodValues1.setNotify(true);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year8.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year8.previous();
        java.lang.Object obj15 = null;
        int int16 = year8.compareTo(obj15);
        java.util.Calendar calendar17 = null;
        try {
            year8.peg(calendar17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        try {
            org.jfree.data.general.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) seriesChangeListener2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        int int11 = timePeriodValues1.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener12);
        int int14 = timePeriodValues1.getMinStartIndex();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener13);
        int int15 = timePeriodValues10.getItemCount();
        int int16 = timePeriodValues10.getMaxMiddleIndex();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) year17, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 2019L);
        java.util.Date date22 = year17.getEnd();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date22, timeZone23);
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues26.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timePeriodValues26.removePropertyChangeListener(propertyChangeListener29);
        int int31 = timePeriodValues26.getItemCount();
        int int32 = timePeriodValues26.getMaxMiddleIndex();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        timePeriodValues26.add((org.jfree.data.time.TimePeriod) year33, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue37 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year33, (java.lang.Number) 2019L);
        java.util.Date date38 = year33.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(date22, date38);
        org.jfree.data.time.TimePeriodValues timePeriodValues41 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues41.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener44 = null;
        timePeriodValues41.removePropertyChangeListener(propertyChangeListener44);
        java.lang.String str46 = timePeriodValues41.getDescription();
        int int47 = timePeriodValues41.getMinStartIndex();
        timePeriodValues41.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues52 = timePeriodValues41.createCopy(0, 1);
        boolean boolean53 = simpleTimePeriod39.equals((java.lang.Object) 0);
        java.util.Date date54 = simpleTimePeriod39.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues56 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues56.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener59 = null;
        timePeriodValues56.removePropertyChangeListener(propertyChangeListener59);
        int int61 = timePeriodValues56.getItemCount();
        int int62 = timePeriodValues56.getMaxMiddleIndex();
        org.jfree.data.time.Year year63 = new org.jfree.data.time.Year();
        timePeriodValues56.add((org.jfree.data.time.TimePeriod) year63, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue67 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year63, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = year63.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = year63.previous();
        int int70 = simpleTimePeriod39.compareTo((java.lang.Object) regularTimePeriod69);
        java.util.Date date71 = simpleTimePeriod39.getStart();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNull(str46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-1) + "'", int62 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod68);
        org.junit.Assert.assertNotNull(regularTimePeriod69);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 1 + "'", int70 == 1);
        org.junit.Assert.assertNotNull(date71);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("2019");
        org.junit.Assert.assertNotNull(year1);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (-1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener7);
        int int9 = timePeriodValues1.getMinStartIndex();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

//    @Test
//    public void test093() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test093");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass1 = day0.getClass();
//        long long2 = day0.getLastMillisecond();
//        java.lang.String str3 = day0.toString();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = day0.getLastMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560495599999L + "'", long2 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '4', "TimePeriodValue[2019,100]", "2019");
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        int int9 = timePeriodValues1.getMinEndIndex();
        int int10 = timePeriodValues1.getItemCount();
        java.lang.Comparable comparable11 = timePeriodValues1.getKey();
        try {
            java.lang.Number number13 = timePeriodValues1.getValue(7);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + (byte) 1 + "'", comparable11.equals((byte) 1));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 100);
        java.util.Date date4 = year0.getStart();
        int int5 = year0.getYear();
        java.util.Calendar calendar6 = null;
        try {
            year0.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 2019L);
        int int13 = year8.getYear();
        java.util.Calendar calendar14 = null;
        try {
            long long15 = year8.getMiddleMillisecond(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        java.lang.Comparable comparable0 = null;
        try {
            org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues(comparable0, "TimePeriodValue[2019,100]", "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener2);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 0L);
        int int3 = day0.getYear();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = day0.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        timePeriodValues1.setNotify(true);
        try {
            org.jfree.data.time.TimePeriod timePeriod11 = timePeriodValues1.getTimePeriod(11);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 11, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        int int11 = timePeriodValues1.getMaxEndIndex();
        java.lang.String str12 = timePeriodValues1.getRangeDescription();
        java.lang.String str13 = timePeriodValues1.getDomainDescription();
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Value" + "'", str12.equals("Value"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

//    @Test
//    public void test103() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test103");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.next();
//        long long3 = day0.getFirstMillisecond();
//        java.util.Calendar calendar4 = null;
//        try {
//            day0.peg(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        int int11 = timePeriodValues1.getMinMiddleIndex();
        try {
            org.jfree.data.time.TimePeriod timePeriod13 = timePeriodValues1.getTimePeriod((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        timePeriodValues1.setKey((java.lang.Comparable) 100L);
        timePeriodValues1.setKey((java.lang.Comparable) (short) 100);
        java.lang.String str8 = timePeriodValues1.getRangeDescription();
        try {
            java.lang.Number number10 = timePeriodValues1.getValue((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Value" + "'", str8.equals("Value"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 100);
        java.util.Date date4 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues6.addChangeListener(seriesChangeListener7);
        int int9 = timePeriodValues6.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass10 = timePeriodValues6.getClass();
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date11, timeZone12);
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues15.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timePeriodValues15.removePropertyChangeListener(propertyChangeListener18);
        int int20 = timePeriodValues15.getItemCount();
        int int21 = timePeriodValues15.getMaxMiddleIndex();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        timePeriodValues15.add((org.jfree.data.time.TimePeriod) year22, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue26 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year22, (java.lang.Number) 2019L);
        java.util.Date date27 = year22.getEnd();
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date27, timeZone28);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(date4, timeZone28);
        org.jfree.data.time.TimePeriodValues timePeriodValues32 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener33 = null;
        timePeriodValues32.addChangeListener(seriesChangeListener33);
        int int35 = timePeriodValues32.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass36 = timePeriodValues32.getClass();
        java.util.Date date37 = null;
        java.util.TimeZone timeZone38 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date37, timeZone38);
        org.jfree.data.time.TimePeriodValues timePeriodValues41 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues41.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener44 = null;
        timePeriodValues41.removePropertyChangeListener(propertyChangeListener44);
        int int46 = timePeriodValues41.getItemCount();
        int int47 = timePeriodValues41.getMaxMiddleIndex();
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year();
        timePeriodValues41.add((org.jfree.data.time.TimePeriod) year48, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue52 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year48, (java.lang.Number) 2019L);
        java.util.Date date53 = year48.getEnd();
        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date53, timeZone54);
        org.jfree.data.time.TimePeriodValues timePeriodValues57 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues57.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener60 = null;
        timePeriodValues57.removePropertyChangeListener(propertyChangeListener60);
        int int62 = timePeriodValues57.getItemCount();
        int int63 = timePeriodValues57.getMaxMiddleIndex();
        org.jfree.data.time.Year year64 = new org.jfree.data.time.Year();
        timePeriodValues57.add((org.jfree.data.time.TimePeriod) year64, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue68 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year64, (java.lang.Number) 2019L);
        java.util.Date date69 = year64.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod70 = new org.jfree.data.time.SimpleTimePeriod(date53, date69);
        java.util.TimeZone timeZone71 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year72 = new org.jfree.data.time.Year(date53, timeZone71);
        org.jfree.data.time.Year year73 = new org.jfree.data.time.Year(date4, timeZone71);
        boolean boolean75 = year73.equals((java.lang.Object) 12);
        java.util.Calendar calendar76 = null;
        try {
            year73.peg(calendar76);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertNotNull(timeZone54);
        org.junit.Assert.assertNull(regularTimePeriod55);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-1) + "'", int63 == (-1));
        org.junit.Assert.assertNotNull(date69);
        org.junit.Assert.assertNotNull(timeZone71);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        int int11 = timePeriodValues1.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener12);
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue15 = timePeriodValues1.getDataItem(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year8.previous();
        java.lang.String str14 = year8.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year8.next();
        java.lang.Number number16 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod15, number16);
        long long18 = regularTimePeriod15.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019" + "'", str14.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1593676799999L + "'", long18 == 1593676799999L);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener11);
        java.lang.String str13 = timePeriodValues1.getDomainDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener14);
        java.lang.Comparable comparable16 = null;
        try {
            timePeriodValues1.setKey(comparable16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener7);
        try {
            timePeriodValues1.delete((int) ' ', (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10);
        timePeriodValues1.setDescription("Time");
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues7.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues7.removePropertyChangeListener(propertyChangeListener10);
        int int12 = timePeriodValues7.getItemCount();
        int int13 = timePeriodValues7.getMaxMiddleIndex();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        timePeriodValues7.add((org.jfree.data.time.TimePeriod) year14, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue18 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year14.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod19, (double) 2019L);
        int int22 = timePeriodValues1.getMinEndIndex();
        java.lang.String str23 = timePeriodValues1.getDomainDescription();
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Time" + "'", str23.equals("Time"));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        int int11 = timePeriodValues1.getMinMiddleIndex();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue13 = timePeriodValues1.getDataItem((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = null;
        try {
            timePeriodValues1.add(timePeriodValue2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null item not allowed.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test115() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test115");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass1 = day0.getClass();
//        long long2 = day0.getLastMillisecond();
//        java.lang.String str3 = day0.toString();
//        long long4 = day0.getFirstMillisecond();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = day0.getFirstMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560495599999L + "'", long2 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        timePeriodValues1.setKey((java.lang.Comparable) ' ');
        try {
            java.lang.Number number14 = timePeriodValues1.getValue(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

//    @Test
//    public void test117() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test117");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getMiddleMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = day0.getLastMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560452399999L + "'", long2 == 1560452399999L);
//        org.junit.Assert.assertNotNull(serialDate3);
//    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener13);
        int int15 = timePeriodValues10.getItemCount();
        int int16 = timePeriodValues10.getMaxMiddleIndex();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) year17, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 2019L);
        java.util.Date date22 = year17.getEnd();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date22, timeZone23);
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues26.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timePeriodValues26.removePropertyChangeListener(propertyChangeListener29);
        int int31 = timePeriodValues26.getItemCount();
        int int32 = timePeriodValues26.getMaxMiddleIndex();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        timePeriodValues26.add((org.jfree.data.time.TimePeriod) year33, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue37 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year33, (java.lang.Number) 2019L);
        java.util.Date date38 = year33.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(date22, date38);
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year(date22);
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date22);
        java.lang.String str42 = day41.toString();
        java.lang.String str43 = day41.toString();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "31-December-2019" + "'", str42.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "31-December-2019" + "'", str43.equals("31-December-2019"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues3.setNotify(true);
        boolean boolean7 = timePeriodValues3.equals((java.lang.Object) (short) 0);
        boolean boolean8 = year0.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        timePeriodValues10.setKey((java.lang.Comparable) 100L);
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues16.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timePeriodValues16.removePropertyChangeListener(propertyChangeListener19);
        int int21 = timePeriodValues16.getItemCount();
        int int22 = timePeriodValues16.getMaxMiddleIndex();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        timePeriodValues16.add((org.jfree.data.time.TimePeriod) year23, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue27 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year23, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year23.previous();
        timePeriodValues10.setKey((java.lang.Comparable) year23);
        int int30 = year0.compareTo((java.lang.Object) year23);
        long long31 = year0.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 2019L + "'", long31 == 2019L);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (java.lang.Number) 100);
        java.lang.Object obj11 = timePeriodValue10.clone();
        timePeriodValues1.add(timePeriodValue10);
        java.lang.String str13 = timePeriodValue10.toString();
        java.lang.Object obj14 = timePeriodValue10.clone();
        java.lang.Number number15 = timePeriodValue10.getValue();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "TimePeriodValue[2019,100]" + "'", str13.equals("TimePeriodValue[2019,100]"));
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 100 + "'", number15.equals(100));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "TimePeriodValue[2019,3]");
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues3.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener6);
        int int8 = timePeriodValues3.getItemCount();
        int int9 = timePeriodValues3.getMaxMiddleIndex();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year10, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year10, (java.lang.Number) 2019L);
        java.util.Date date15 = year10.getEnd();
        long long16 = year10.getFirstMillisecond();
        boolean boolean17 = day0.equals((java.lang.Object) long16);
        java.util.Calendar calendar18 = null;
        try {
            long long19 = day0.getMiddleMillisecond(calendar18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1546329600000L + "'", long16 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

//    @Test
//    public void test123() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test123");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.next();
//        long long3 = day0.getFirstMillisecond();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = day0.getLastMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues3.setNotify(true);
        boolean boolean7 = timePeriodValues3.equals((java.lang.Object) (short) 0);
        boolean boolean8 = year0.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        timePeriodValues10.setKey((java.lang.Comparable) 100L);
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues16.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timePeriodValues16.removePropertyChangeListener(propertyChangeListener19);
        int int21 = timePeriodValues16.getItemCount();
        int int22 = timePeriodValues16.getMaxMiddleIndex();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        timePeriodValues16.add((org.jfree.data.time.TimePeriod) year23, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue27 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year23, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year23.previous();
        timePeriodValues10.setKey((java.lang.Comparable) year23);
        int int30 = year0.compareTo((java.lang.Object) year23);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year0.previous();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.data.time.TimePeriod timePeriod0 = null;
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue(timePeriod0, (java.lang.Number) (-1.0f));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues3.setNotify(true);
        boolean boolean7 = timePeriodValues3.equals((java.lang.Object) (short) 0);
        boolean boolean8 = year0.equals((java.lang.Object) (short) 0);
        long long9 = year0.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1562097599999L + "'", long9 == 1562097599999L);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10);
        boolean boolean2 = timePeriodValues1.isEmpty();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        timePeriodValues1.setKey((java.lang.Comparable) 100L);
        timePeriodValues1.setKey((java.lang.Comparable) (short) 100);
        java.lang.String str8 = timePeriodValues1.getRangeDescription();
        try {
            timePeriodValues1.delete(2, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Value" + "'", str8.equals("Value"));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener11);
        java.lang.String str13 = timePeriodValues1.getDomainDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues15.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timePeriodValues15.removePropertyChangeListener(propertyChangeListener18);
        java.lang.String str20 = timePeriodValues15.getDescription();
        int int21 = timePeriodValues15.getMinStartIndex();
        timePeriodValues15.fireSeriesChanged();
        boolean boolean23 = timePeriodValues1.equals((java.lang.Object) timePeriodValues15);
        timePeriodValues1.setRangeDescription("");
        java.lang.String str26 = timePeriodValues1.getDescription();
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(str26);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMinEndIndex();
        java.lang.String str6 = timePeriodValues1.getRangeDescription();
        java.lang.Comparable comparable7 = timePeriodValues1.getKey();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Value" + "'", str6.equals("Value"));
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + (byte) 1 + "'", comparable7.equals((byte) 1));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(7, (int) (short) 0, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        boolean boolean9 = timePeriodValues1.equals((java.lang.Object) 3);
        java.lang.String str10 = timePeriodValues1.getDomainDescription();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Time" + "'", str10.equals("Time"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues1.createCopy((int) (byte) 10, (int) (short) 1);
        org.junit.Assert.assertNotNull(timePeriodValues6);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        long long11 = year8.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1562097599999L + "'", long11 == 1562097599999L);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMinEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = timePeriodValues1.createCopy(6, (int) (byte) 100);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener13);
        int int15 = timePeriodValues10.getItemCount();
        int int16 = timePeriodValues10.getMaxMiddleIndex();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) year17, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year17.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year17.previous();
        java.lang.Object obj24 = null;
        int int25 = year17.compareTo(obj24);
        timePeriodValues1.setKey((java.lang.Comparable) year17);
        long long27 = year17.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 2019L + "'", long27 == 2019L);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        int int11 = timePeriodValues1.getMaxStartIndex();
        boolean boolean13 = timePeriodValues1.equals((java.lang.Object) "TimePeriodValue[2019,3]");
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 0L);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = day0.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) 10, (int) (short) -1, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test139() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test139");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        try {
            org.jfree.data.time.TimePeriod timePeriod7 = timePeriodValues1.getTimePeriod(6);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

//    @Test
//    public void test141() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test141");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getMiddleMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate5 = day4.getSerialDate();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
//        boolean boolean7 = day0.equals((java.lang.Object) serialDate5);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day0.next();
//        int int9 = day0.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560452399999L + "'", long2 == 1560452399999L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 13 + "'", int9 == 13);
//    }

//    @Test
//    public void test142() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test142");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getMiddleMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate5 = day4.getSerialDate();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
//        boolean boolean7 = day0.equals((java.lang.Object) serialDate5);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(serialDate5);
//        long long9 = day8.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560452399999L + "'", long2 == 1560452399999L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560495599999L + "'", long9 == 1560495599999L);
//    }

//    @Test
//    public void test143() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test143");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getMiddleMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560452399999L + "'", long2 == 1560452399999L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertNotNull(serialDate4);
//    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        int int11 = timePeriodValues1.getMaxEndIndex();
        java.lang.String str12 = timePeriodValues1.getRangeDescription();
        java.lang.Class<?> wildcardClass13 = timePeriodValues1.getClass();
        timePeriodValues1.setDescription("13-June-2019");
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Value" + "'", str12.equals("Value"));
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year8.previous();
        java.lang.String str14 = year8.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year8.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year8.previous();
        java.util.Date date17 = regularTimePeriod16.getEnd();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019" + "'", str14.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(date17);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (13) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        timePeriodValues1.setKey((java.lang.Comparable) "hi!");
        timePeriodValues1.setDescription("Value");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener8);
        timePeriodValues1.setRangeDescription("31-December-2019");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener12);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMinEndIndex();
        java.lang.String str6 = timePeriodValues1.getRangeDescription();
        java.lang.Comparable comparable7 = null;
        try {
            timePeriodValues1.setKey(comparable7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Value" + "'", str6.equals("Value"));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 100);
        java.lang.String str4 = timePeriodValue3.toString();
        java.lang.Number number5 = timePeriodValue3.getValue();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "TimePeriodValue[2019,100]" + "'", str4.equals("TimePeriodValue[2019,100]"));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 100 + "'", number5.equals(100));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMinEndIndex();
        boolean boolean6 = timePeriodValues1.isEmpty();
        boolean boolean7 = timePeriodValues1.getNotify();
        int int8 = timePeriodValues1.getMinMiddleIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

//    @Test
//    public void test152() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test152");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass1 = day0.getClass();
//        long long2 = day0.getLastMillisecond();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = day0.getLastMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560495599999L + "'", long2 == 1560495599999L);
//    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener11);
        java.lang.String str13 = timePeriodValues1.getDomainDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues15.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timePeriodValues15.removePropertyChangeListener(propertyChangeListener18);
        java.lang.String str20 = timePeriodValues15.getDescription();
        int int21 = timePeriodValues15.getMinStartIndex();
        timePeriodValues15.fireSeriesChanged();
        boolean boolean23 = timePeriodValues1.equals((java.lang.Object) timePeriodValues15);
        int int24 = timePeriodValues1.getMaxStartIndex();
        java.lang.Comparable comparable25 = timePeriodValues1.getKey();
        int int26 = timePeriodValues1.getMinStartIndex();
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + comparable25 + "' != '" + (byte) 1 + "'", comparable25.equals((byte) 1));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 2019L);
        java.util.Date date13 = year8.getEnd();
        long long14 = year8.getMiddleMillisecond();
        java.lang.Class<?> wildcardClass15 = year8.getClass();
        java.util.Calendar calendar16 = null;
        try {
            year8.peg(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1562097599999L + "'", long14 == 1562097599999L);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = day0.getLastMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener13);
        int int15 = timePeriodValues10.getItemCount();
        int int16 = timePeriodValues10.getMaxMiddleIndex();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) year17, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 2019L);
        java.util.Date date22 = year17.getEnd();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date22, timeZone23);
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues26.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timePeriodValues26.removePropertyChangeListener(propertyChangeListener29);
        int int31 = timePeriodValues26.getItemCount();
        int int32 = timePeriodValues26.getMaxMiddleIndex();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        timePeriodValues26.add((org.jfree.data.time.TimePeriod) year33, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue37 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year33, (java.lang.Number) 2019L);
        java.util.Date date38 = year33.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(date22, date38);
        org.jfree.data.time.TimePeriodValues timePeriodValues41 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues41.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener44 = null;
        timePeriodValues41.removePropertyChangeListener(propertyChangeListener44);
        java.lang.String str46 = timePeriodValues41.getDescription();
        int int47 = timePeriodValues41.getMinStartIndex();
        timePeriodValues41.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues52 = timePeriodValues41.createCopy(0, 1);
        boolean boolean53 = simpleTimePeriod39.equals((java.lang.Object) 0);
        java.util.Date date54 = simpleTimePeriod39.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues56 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues56.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener59 = null;
        timePeriodValues56.removePropertyChangeListener(propertyChangeListener59);
        int int61 = timePeriodValues56.getItemCount();
        int int62 = timePeriodValues56.getMaxMiddleIndex();
        org.jfree.data.time.Year year63 = new org.jfree.data.time.Year();
        timePeriodValues56.add((org.jfree.data.time.TimePeriod) year63, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue67 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year63, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = year63.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = year63.previous();
        int int70 = simpleTimePeriod39.compareTo((java.lang.Object) regularTimePeriod69);
        long long71 = simpleTimePeriod39.getStartMillis();
        java.util.Date date72 = simpleTimePeriod39.getStart();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNull(str46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-1) + "'", int62 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod68);
        org.junit.Assert.assertNotNull(regularTimePeriod69);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 1 + "'", int70 == 1);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 1577865599999L + "'", long71 == 1577865599999L);
        org.junit.Assert.assertNotNull(date72);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener13);
        int int15 = timePeriodValues10.getItemCount();
        int int16 = timePeriodValues10.getMaxMiddleIndex();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) year17, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 2019L);
        java.util.Date date22 = year17.getEnd();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date22, timeZone23);
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues26.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timePeriodValues26.removePropertyChangeListener(propertyChangeListener29);
        int int31 = timePeriodValues26.getItemCount();
        int int32 = timePeriodValues26.getMaxMiddleIndex();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        timePeriodValues26.add((org.jfree.data.time.TimePeriod) year33, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue37 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year33, (java.lang.Number) 2019L);
        java.util.Date date38 = year33.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(date22, date38);
        long long40 = simpleTimePeriod39.getEndMillis();
        long long41 = simpleTimePeriod39.getStartMillis();
        boolean boolean43 = simpleTimePeriod39.equals((java.lang.Object) 0);
        java.util.Date date44 = simpleTimePeriod39.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues46 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener47 = null;
        timePeriodValues46.addChangeListener(seriesChangeListener47);
        int int49 = timePeriodValues46.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass50 = timePeriodValues46.getClass();
        java.util.Date date51 = null;
        java.util.TimeZone timeZone52 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass50, date51, timeZone52);
        org.jfree.data.time.TimePeriodValues timePeriodValues55 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues55.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener58 = null;
        timePeriodValues55.removePropertyChangeListener(propertyChangeListener58);
        int int60 = timePeriodValues55.getItemCount();
        int int61 = timePeriodValues55.getMaxMiddleIndex();
        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year();
        timePeriodValues55.add((org.jfree.data.time.TimePeriod) year62, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue66 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year62, (java.lang.Number) 2019L);
        java.util.Date date67 = year62.getEnd();
        java.util.TimeZone timeZone68 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass50, date67, timeZone68);
        org.jfree.data.time.TimePeriodValues timePeriodValues71 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues71.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener74 = null;
        timePeriodValues71.removePropertyChangeListener(propertyChangeListener74);
        int int76 = timePeriodValues71.getItemCount();
        int int77 = timePeriodValues71.getMaxMiddleIndex();
        org.jfree.data.time.Year year78 = new org.jfree.data.time.Year();
        timePeriodValues71.add((org.jfree.data.time.TimePeriod) year78, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue82 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year78, (java.lang.Number) 2019L);
        java.util.Date date83 = year78.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod84 = new org.jfree.data.time.SimpleTimePeriod(date67, date83);
        java.util.TimeZone timeZone85 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year86 = new org.jfree.data.time.Year(date67, timeZone85);
        boolean boolean87 = simpleTimePeriod39.equals((java.lang.Object) date67);
        java.util.Date date88 = simpleTimePeriod39.getStart();
        java.util.Date date89 = simpleTimePeriod39.getStart();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1577865599999L + "'", long40 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1577865599999L + "'", long41 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertNull(regularTimePeriod53);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
        org.junit.Assert.assertNotNull(date67);
        org.junit.Assert.assertNotNull(timeZone68);
        org.junit.Assert.assertNull(regularTimePeriod69);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 0 + "'", int76 == 0);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + (-1) + "'", int77 == (-1));
        org.junit.Assert.assertNotNull(date83);
        org.junit.Assert.assertNotNull(timeZone85);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertNotNull(date88);
        org.junit.Assert.assertNotNull(date89);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        long long3 = year2.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year2, (java.lang.Number) 100);
        java.lang.Object obj6 = timePeriodValue5.clone();
        int int7 = day0.compareTo(obj6);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
        int int10 = day8.getYear();
        boolean boolean11 = day0.equals((java.lang.Object) int10);
        int int12 = day0.getMonth();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        boolean boolean2 = timePeriodValues1.getNotify();
        java.lang.String str3 = timePeriodValues1.getRangeDescription();
        try {
            org.jfree.data.time.TimePeriod timePeriod5 = timePeriodValues1.getTimePeriod(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Value" + "'", str3.equals("Value"));
    }

//    @Test
//    public void test160() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test160");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        timePeriodValues1.setNotify(true);
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
//        java.lang.String str6 = timePeriodValues1.getDescription();
//        int int7 = timePeriodValues1.getMinStartIndex();
//        int int8 = timePeriodValues1.getMaxEndIndex();
//        timePeriodValues1.setDomainDescription("");
//        java.beans.PropertyChangeListener propertyChangeListener11 = null;
//        timePeriodValues1.removePropertyChangeListener(propertyChangeListener11);
//        java.lang.String str13 = timePeriodValues1.getDomainDescription();
//        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        timePeriodValues15.setNotify(true);
//        java.beans.PropertyChangeListener propertyChangeListener18 = null;
//        timePeriodValues15.removePropertyChangeListener(propertyChangeListener18);
//        java.lang.String str20 = timePeriodValues15.getDescription();
//        int int21 = timePeriodValues15.getMinStartIndex();
//        timePeriodValues15.fireSeriesChanged();
//        boolean boolean23 = timePeriodValues1.equals((java.lang.Object) timePeriodValues15);
//        int int24 = timePeriodValues1.getMaxStartIndex();
//        int int25 = timePeriodValues1.getMaxStartIndex();
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass27 = day26.getClass();
//        long long28 = day26.getLastMillisecond();
//        long long29 = day26.getMiddleMillisecond();
//        timePeriodValues1.setKey((java.lang.Comparable) day26);
//        int int31 = day26.getDayOfMonth();
//        org.junit.Assert.assertNull(str6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertNull(str20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass27);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560495599999L + "'", long28 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560452399999L + "'", long29 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 13 + "'", int31 == 13);
//    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass1 = day0.getClass();
        int int2 = day0.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 8);
        java.util.Calendar calendar5 = null;
        try {
            long long6 = day0.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(serialDate1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(serialDate1);
        java.util.Calendar calendar4 = null;
        try {
            long long5 = day3.getMiddleMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (java.lang.Number) 100);
        java.lang.Object obj11 = timePeriodValue10.clone();
        timePeriodValues1.add(timePeriodValue10);
        java.lang.Number number13 = timePeriodValue10.getValue();
        java.lang.Number number14 = timePeriodValue10.getValue();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 100 + "'", number13.equals(100));
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 100 + "'", number14.equals(100));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.data.time.TimePeriod timePeriod0 = null;
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue(timePeriod0, 10.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("Time");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener11);
        java.lang.String str13 = timePeriodValues1.getDomainDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener14);
        try {
            java.lang.Number number17 = timePeriodValues1.getValue(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getYear();
        int int2 = day0.getYear();
        java.util.Calendar calendar3 = null;
        try {
            day0.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMinEndIndex();
        java.lang.Object obj6 = timePeriodValues1.clone();
        timePeriodValues1.setDescription("TimePeriodValue[13-June-2019,8.0]");
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        java.lang.Class class9 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize(class9);
        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize(class9);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertNotNull(class11);
    }

//    @Test
//    public void test171() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test171");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        timePeriodValues1.setNotify(true);
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
//        java.lang.String str6 = timePeriodValues1.getDescription();
//        int int7 = timePeriodValues1.getMinStartIndex();
//        int int8 = timePeriodValues1.getMaxEndIndex();
//        timePeriodValues1.setDomainDescription("");
//        java.beans.PropertyChangeListener propertyChangeListener11 = null;
//        timePeriodValues1.removePropertyChangeListener(propertyChangeListener11);
//        java.lang.String str13 = timePeriodValues1.getDomainDescription();
//        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        timePeriodValues15.setNotify(true);
//        java.beans.PropertyChangeListener propertyChangeListener18 = null;
//        timePeriodValues15.removePropertyChangeListener(propertyChangeListener18);
//        java.lang.String str20 = timePeriodValues15.getDescription();
//        int int21 = timePeriodValues15.getMinStartIndex();
//        timePeriodValues15.fireSeriesChanged();
//        boolean boolean23 = timePeriodValues1.equals((java.lang.Object) timePeriodValues15);
//        int int24 = timePeriodValues1.getMaxStartIndex();
//        int int25 = timePeriodValues1.getMaxStartIndex();
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass27 = day26.getClass();
//        long long28 = day26.getLastMillisecond();
//        long long29 = day26.getMiddleMillisecond();
//        timePeriodValues1.setKey((java.lang.Comparable) day26);
//        long long31 = day26.getSerialIndex();
//        long long32 = day26.getSerialIndex();
//        long long33 = day26.getSerialIndex();
//        org.junit.Assert.assertNull(str6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertNull(str20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass27);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560495599999L + "'", long28 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560452399999L + "'", long29 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 43629L + "'", long31 == 43629L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 43629L + "'", long32 == 43629L);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 43629L + "'", long33 == 43629L);
//    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener13);
        int int15 = timePeriodValues10.getItemCount();
        int int16 = timePeriodValues10.getMaxMiddleIndex();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) year17, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 2019L);
        java.util.Date date22 = year17.getEnd();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date22, timeZone23);
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues26.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timePeriodValues26.removePropertyChangeListener(propertyChangeListener29);
        int int31 = timePeriodValues26.getItemCount();
        int int32 = timePeriodValues26.getMaxMiddleIndex();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        timePeriodValues26.add((org.jfree.data.time.TimePeriod) year33, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue37 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year33, (java.lang.Number) 2019L);
        java.util.Date date38 = year33.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(date22, date38);
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date22);
        org.jfree.data.time.SerialDate serialDate41 = day40.getSerialDate();
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(serialDate41);
        java.lang.String str43 = day42.toString();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "31-December-2019" + "'", str43.equals("31-December-2019"));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener13);
        int int15 = timePeriodValues10.getItemCount();
        int int16 = timePeriodValues10.getMaxMiddleIndex();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) year17, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 2019L);
        java.util.Date date22 = year17.getEnd();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date22, timeZone23);
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues26.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timePeriodValues26.removePropertyChangeListener(propertyChangeListener29);
        int int31 = timePeriodValues26.getItemCount();
        int int32 = timePeriodValues26.getMaxMiddleIndex();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        timePeriodValues26.add((org.jfree.data.time.TimePeriod) year33, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue37 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year33, (java.lang.Number) 2019L);
        java.util.Date date38 = year33.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(date22, date38);
        long long40 = simpleTimePeriod39.getEndMillis();
        long long41 = simpleTimePeriod39.getStartMillis();
        boolean boolean43 = simpleTimePeriod39.equals((java.lang.Object) 0);
        java.util.Date date44 = simpleTimePeriod39.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues46 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener47 = null;
        timePeriodValues46.addChangeListener(seriesChangeListener47);
        int int49 = timePeriodValues46.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass50 = timePeriodValues46.getClass();
        java.util.Date date51 = null;
        java.util.TimeZone timeZone52 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass50, date51, timeZone52);
        org.jfree.data.time.TimePeriodValues timePeriodValues55 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues55.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener58 = null;
        timePeriodValues55.removePropertyChangeListener(propertyChangeListener58);
        int int60 = timePeriodValues55.getItemCount();
        int int61 = timePeriodValues55.getMaxMiddleIndex();
        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year();
        timePeriodValues55.add((org.jfree.data.time.TimePeriod) year62, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue66 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year62, (java.lang.Number) 2019L);
        java.util.Date date67 = year62.getEnd();
        java.util.TimeZone timeZone68 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass50, date67, timeZone68);
        org.jfree.data.time.TimePeriodValues timePeriodValues71 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues71.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener74 = null;
        timePeriodValues71.removePropertyChangeListener(propertyChangeListener74);
        int int76 = timePeriodValues71.getItemCount();
        int int77 = timePeriodValues71.getMaxMiddleIndex();
        org.jfree.data.time.Year year78 = new org.jfree.data.time.Year();
        timePeriodValues71.add((org.jfree.data.time.TimePeriod) year78, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue82 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year78, (java.lang.Number) 2019L);
        java.util.Date date83 = year78.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod84 = new org.jfree.data.time.SimpleTimePeriod(date67, date83);
        java.util.TimeZone timeZone85 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year86 = new org.jfree.data.time.Year(date67, timeZone85);
        boolean boolean87 = simpleTimePeriod39.equals((java.lang.Object) date67);
        long long88 = simpleTimePeriod39.getEndMillis();
        long long89 = simpleTimePeriod39.getStartMillis();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1577865599999L + "'", long40 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1577865599999L + "'", long41 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertNull(regularTimePeriod53);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
        org.junit.Assert.assertNotNull(date67);
        org.junit.Assert.assertNotNull(timeZone68);
        org.junit.Assert.assertNull(regularTimePeriod69);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 0 + "'", int76 == 0);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + (-1) + "'", int77 == (-1));
        org.junit.Assert.assertNotNull(date83);
        org.junit.Assert.assertNotNull(timeZone85);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertTrue("'" + long88 + "' != '" + 1577865599999L + "'", long88 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long89 + "' != '" + 1577865599999L + "'", long89 == 1577865599999L);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("TimePeriodValue[13-June-2019,8.0]");
        java.lang.Throwable throwable2 = null;
        try {
            timePeriodFormatException1.addSuppressed(throwable2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("TimePeriodValue[13-June-2019,8.0]");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray3);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener7);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener11);
        int int13 = timePeriodValues1.getItemCount();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMinEndIndex();
        java.lang.String str6 = timePeriodValues1.getRangeDescription();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year7.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod9, (java.lang.Number) 6);
        int int12 = timePeriodValues1.getMinEndIndex();
        try {
            timePeriodValues1.delete((int) (byte) 100, 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Value" + "'", str6.equals("Value"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year11, (java.lang.Number) 100);
        timePeriodValues1.add(timePeriodValue14);
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue17 = timePeriodValues1.getDataItem(4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2019L + "'", long12 == 2019L);
    }

//    @Test
//    public void test179() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test179");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(serialDate1);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(serialDate1);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(serialDate1);
//        long long5 = day4.getLastMillisecond();
//        java.util.Date date6 = day4.getStart();
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
//        long long8 = year7.getSerialIndex();
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (java.lang.Number) 100);
//        java.util.Date date11 = year7.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
//        timePeriodValues13.addChangeListener(seriesChangeListener14);
//        int int16 = timePeriodValues13.getMinMiddleIndex();
//        java.lang.Class<?> wildcardClass17 = timePeriodValues13.getClass();
//        java.util.Date date18 = null;
//        java.util.TimeZone timeZone19 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date18, timeZone19);
//        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        timePeriodValues22.setNotify(true);
//        java.beans.PropertyChangeListener propertyChangeListener25 = null;
//        timePeriodValues22.removePropertyChangeListener(propertyChangeListener25);
//        int int27 = timePeriodValues22.getItemCount();
//        int int28 = timePeriodValues22.getMaxMiddleIndex();
//        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
//        timePeriodValues22.add((org.jfree.data.time.TimePeriod) year29, (double) 6);
//        org.jfree.data.time.TimePeriodValue timePeriodValue33 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year29, (java.lang.Number) 2019L);
//        java.util.Date date34 = year29.getEnd();
//        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date34, timeZone35);
//        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year(date11, timeZone35);
//        org.jfree.data.time.TimePeriodValues timePeriodValues39 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener40 = null;
//        timePeriodValues39.addChangeListener(seriesChangeListener40);
//        int int42 = timePeriodValues39.getMinMiddleIndex();
//        java.lang.Class<?> wildcardClass43 = timePeriodValues39.getClass();
//        java.util.Date date44 = null;
//        java.util.TimeZone timeZone45 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass43, date44, timeZone45);
//        org.jfree.data.time.TimePeriodValues timePeriodValues48 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        timePeriodValues48.setNotify(true);
//        java.beans.PropertyChangeListener propertyChangeListener51 = null;
//        timePeriodValues48.removePropertyChangeListener(propertyChangeListener51);
//        int int53 = timePeriodValues48.getItemCount();
//        int int54 = timePeriodValues48.getMaxMiddleIndex();
//        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year();
//        timePeriodValues48.add((org.jfree.data.time.TimePeriod) year55, (double) 6);
//        org.jfree.data.time.TimePeriodValue timePeriodValue59 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year55, (java.lang.Number) 2019L);
//        java.util.Date date60 = year55.getEnd();
//        java.util.TimeZone timeZone61 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass43, date60, timeZone61);
//        org.jfree.data.time.TimePeriodValues timePeriodValues64 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        timePeriodValues64.setNotify(true);
//        java.beans.PropertyChangeListener propertyChangeListener67 = null;
//        timePeriodValues64.removePropertyChangeListener(propertyChangeListener67);
//        int int69 = timePeriodValues64.getItemCount();
//        int int70 = timePeriodValues64.getMaxMiddleIndex();
//        org.jfree.data.time.Year year71 = new org.jfree.data.time.Year();
//        timePeriodValues64.add((org.jfree.data.time.TimePeriod) year71, (double) 6);
//        org.jfree.data.time.TimePeriodValue timePeriodValue75 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year71, (java.lang.Number) 2019L);
//        java.util.Date date76 = year71.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod77 = new org.jfree.data.time.SimpleTimePeriod(date60, date76);
//        java.util.TimeZone timeZone78 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year79 = new org.jfree.data.time.Year(date60, timeZone78);
//        org.jfree.data.time.Year year80 = new org.jfree.data.time.Year(date11, timeZone78);
//        try {
//            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod81 = new org.jfree.data.time.SimpleTimePeriod(date6, date11);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560495599999L + "'", long5 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(timeZone35);
//        org.junit.Assert.assertNull(regularTimePeriod36);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass43);
//        org.junit.Assert.assertNull(regularTimePeriod46);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1) + "'", int54 == (-1));
//        org.junit.Assert.assertNotNull(date60);
//        org.junit.Assert.assertNotNull(timeZone61);
//        org.junit.Assert.assertNull(regularTimePeriod62);
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + (-1) + "'", int70 == (-1));
//        org.junit.Assert.assertNotNull(date76);
//        org.junit.Assert.assertNotNull(timeZone78);
//    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        timePeriodValues1.setNotify(true);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year10, (java.lang.Number) 100);
        timePeriodValue13.setValue((java.lang.Number) 3);
        org.jfree.data.time.TimePeriod timePeriod16 = timePeriodValue13.getPeriod();
        timePeriodValues1.add(timePeriodValue13);
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues19.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timePeriodValues19.removePropertyChangeListener(propertyChangeListener22);
        java.lang.String str24 = timePeriodValues19.getDescription();
        int int25 = timePeriodValues19.getMinStartIndex();
        timePeriodValues19.setNotify(true);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener28 = null;
        timePeriodValues19.removeChangeListener(seriesChangeListener28);
        java.lang.Class<?> wildcardClass30 = timePeriodValues19.getClass();
        boolean boolean31 = timePeriodValue13.equals((java.lang.Object) timePeriodValues19);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
        org.junit.Assert.assertNotNull(timePeriod16);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

//    @Test
//    public void test181() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test181");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        timePeriodValues1.setNotify(true);
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
//        int int6 = timePeriodValues1.getItemCount();
//        int int7 = timePeriodValues1.getMaxMiddleIndex();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
//        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 2019L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year8.previous();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        int int15 = day14.getMonth();
//        long long16 = day14.getMiddleMillisecond();
//        org.jfree.data.time.SerialDate serialDate17 = day14.getSerialDate();
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate19 = day18.getSerialDate();
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(serialDate19);
//        boolean boolean21 = day14.equals((java.lang.Object) serialDate19);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day14.next();
//        int int23 = year8.compareTo((java.lang.Object) regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560452399999L + "'", long16 == 1560452399999L);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 100);
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year0.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(7, (int) '#', (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
        int int6 = timePeriodValues1.getMaxStartIndex();
        java.lang.Comparable comparable7 = null;
        try {
            timePeriodValues1.setKey(comparable7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        java.util.Date date0 = null;
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timePeriodValues2.addChangeListener(seriesChangeListener3);
        int int5 = timePeriodValues2.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass6 = timePeriodValues2.getClass();
        java.util.Date date7 = null;
        java.util.TimeZone timeZone8 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date7, timeZone8);
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues11.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timePeriodValues11.removePropertyChangeListener(propertyChangeListener14);
        int int16 = timePeriodValues11.getItemCount();
        int int17 = timePeriodValues11.getMaxMiddleIndex();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        timePeriodValues11.add((org.jfree.data.time.TimePeriod) year18, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue22 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year18, (java.lang.Number) 2019L);
        java.util.Date date23 = year18.getEnd();
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date23, timeZone24);
        org.jfree.data.time.TimePeriodValues timePeriodValues27 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues27.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener30 = null;
        timePeriodValues27.removePropertyChangeListener(propertyChangeListener30);
        int int32 = timePeriodValues27.getItemCount();
        int int33 = timePeriodValues27.getMaxMiddleIndex();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        timePeriodValues27.add((org.jfree.data.time.TimePeriod) year34, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue38 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year34, (java.lang.Number) 2019L);
        java.util.Date date39 = year34.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod40 = new org.jfree.data.time.SimpleTimePeriod(date23, date39);
        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year(date23, timeZone41);
        try {
            org.jfree.data.time.Year year43 = new org.jfree.data.time.Year(date0, timeZone41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(timeZone41);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues3.setNotify(true);
        boolean boolean7 = timePeriodValues3.equals((java.lang.Object) (short) 0);
        boolean boolean8 = year0.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        timePeriodValues10.setKey((java.lang.Comparable) 100L);
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues16.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timePeriodValues16.removePropertyChangeListener(propertyChangeListener19);
        int int21 = timePeriodValues16.getItemCount();
        int int22 = timePeriodValues16.getMaxMiddleIndex();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        timePeriodValues16.add((org.jfree.data.time.TimePeriod) year23, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue27 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year23, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year23.previous();
        timePeriodValues10.setKey((java.lang.Comparable) year23);
        int int30 = year0.compareTo((java.lang.Object) year23);
        java.lang.String str31 = year0.toString();
        java.lang.Object obj32 = null;
        boolean boolean33 = year0.equals(obj32);
        java.util.Date date34 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues36 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener37 = null;
        timePeriodValues36.addChangeListener(seriesChangeListener37);
        int int39 = timePeriodValues36.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass40 = timePeriodValues36.getClass();
        java.util.Date date41 = null;
        java.util.TimeZone timeZone42 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass40, date41, timeZone42);
        org.jfree.data.time.TimePeriodValues timePeriodValues45 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues45.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener48 = null;
        timePeriodValues45.removePropertyChangeListener(propertyChangeListener48);
        int int50 = timePeriodValues45.getItemCount();
        int int51 = timePeriodValues45.getMaxMiddleIndex();
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year();
        timePeriodValues45.add((org.jfree.data.time.TimePeriod) year52, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue56 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year52, (java.lang.Number) 2019L);
        java.util.Date date57 = year52.getEnd();
        java.util.TimeZone timeZone58 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass40, date57, timeZone58);
        org.jfree.data.time.TimePeriodValues timePeriodValues61 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues61.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener64 = null;
        timePeriodValues61.removePropertyChangeListener(propertyChangeListener64);
        int int66 = timePeriodValues61.getItemCount();
        int int67 = timePeriodValues61.getMaxMiddleIndex();
        org.jfree.data.time.Year year68 = new org.jfree.data.time.Year();
        timePeriodValues61.add((org.jfree.data.time.TimePeriod) year68, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue72 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year68, (java.lang.Number) 2019L);
        java.util.Date date73 = year68.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod74 = new org.jfree.data.time.SimpleTimePeriod(date57, date73);
        long long75 = simpleTimePeriod74.getEndMillis();
        long long76 = simpleTimePeriod74.getStartMillis();
        boolean boolean78 = simpleTimePeriod74.equals((java.lang.Object) 0);
        java.util.Date date79 = simpleTimePeriod74.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues81 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues81.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener84 = null;
        timePeriodValues81.removePropertyChangeListener(propertyChangeListener84);
        int int86 = timePeriodValues81.getItemCount();
        int int87 = timePeriodValues81.getMaxMiddleIndex();
        org.jfree.data.time.Year year88 = new org.jfree.data.time.Year();
        timePeriodValues81.add((org.jfree.data.time.TimePeriod) year88, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue92 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year88, (java.lang.Number) 2019L);
        java.util.Date date93 = year88.getEnd();
        org.jfree.data.time.Year year94 = new org.jfree.data.time.Year(date93);
        java.util.TimeZone timeZone95 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day96 = new org.jfree.data.time.Day(date93, timeZone95);
        org.jfree.data.time.Day day97 = new org.jfree.data.time.Day(date79, timeZone95);
        org.jfree.data.time.Day day98 = new org.jfree.data.time.Day(date34, timeZone95);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod99 = day98.previous();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "2019" + "'", str31.equals("2019"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertNull(regularTimePeriod43);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1) + "'", int51 == (-1));
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertNotNull(timeZone58);
        org.junit.Assert.assertNull(regularTimePeriod59);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + (-1) + "'", int67 == (-1));
        org.junit.Assert.assertNotNull(date73);
        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 1577865599999L + "'", long75 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 1577865599999L + "'", long76 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(date79);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 0 + "'", int86 == 0);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + (-1) + "'", int87 == (-1));
        org.junit.Assert.assertNotNull(date93);
        org.junit.Assert.assertNotNull(timeZone95);
        org.junit.Assert.assertNotNull(regularTimePeriod99);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 0L);
        java.util.Calendar calendar3 = null;
        try {
            day0.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (java.lang.Number) 100);
        java.lang.Object obj11 = timePeriodValue10.clone();
        timePeriodValues1.add(timePeriodValue10);
        org.jfree.data.time.TimePeriod timePeriod13 = timePeriodValue10.getPeriod();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(timePeriod13);
    }

//    @Test
//    public void test189() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test189");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass1 = day0.getClass();
//        long long2 = day0.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0, "Time", "2019");
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = day0.getFirstMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560495599999L + "'", long2 == 1560495599999L);
//    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMinEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = timePeriodValues1.createCopy(6, (int) (byte) 100);
        int int9 = timePeriodValues1.getMinMiddleIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues1.createCopy(0, 0);
        try {
            java.lang.Number number11 = timePeriodValues1.getValue(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(timePeriodValues9);
    }

//    @Test
//    public void test192() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test192");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        java.lang.Object obj2 = null;
//        boolean boolean3 = day0.equals(obj2);
//        int int4 = day0.getYear();
//        long long5 = day0.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560452399999L + "'", long5 == 1560452399999L);
//    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 2019L);
        java.util.Date date13 = year8.getEnd();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date13);
        java.util.Date date15 = null;
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod(date13, date15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(date13);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMinEndIndex();
        boolean boolean6 = timePeriodValues1.getNotify();
        try {
            org.jfree.data.time.TimePeriod timePeriod8 = timePeriodValues1.getTimePeriod(9);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        java.lang.String str7 = timePeriodValues1.getDescription();
        java.lang.Comparable comparable8 = timePeriodValues1.getKey();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue10 = timePeriodValues1.getDataItem(9);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (byte) 1 + "'", comparable8.equals((byte) 1));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        timePeriodValues1.setKey((java.lang.Comparable) "hi!");
        timePeriodValues1.setDescription("Value");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener8);
        boolean boolean10 = timePeriodValues1.getNotify();
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("Value");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 3);
    }

//    @Test
//    public void test199() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test199");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        timePeriodValues1.setNotify(true);
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
//        java.lang.String str6 = timePeriodValues1.getDescription();
//        int int7 = timePeriodValues1.getMinStartIndex();
//        int int8 = timePeriodValues1.getMaxEndIndex();
//        timePeriodValues1.setDomainDescription("");
//        java.beans.PropertyChangeListener propertyChangeListener11 = null;
//        timePeriodValues1.removePropertyChangeListener(propertyChangeListener11);
//        java.lang.String str13 = timePeriodValues1.getDomainDescription();
//        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        timePeriodValues15.setNotify(true);
//        java.beans.PropertyChangeListener propertyChangeListener18 = null;
//        timePeriodValues15.removePropertyChangeListener(propertyChangeListener18);
//        java.lang.String str20 = timePeriodValues15.getDescription();
//        int int21 = timePeriodValues15.getMinStartIndex();
//        timePeriodValues15.fireSeriesChanged();
//        boolean boolean23 = timePeriodValues1.equals((java.lang.Object) timePeriodValues15);
//        int int24 = timePeriodValues1.getMaxStartIndex();
//        int int25 = timePeriodValues1.getMaxStartIndex();
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass27 = day26.getClass();
//        long long28 = day26.getLastMillisecond();
//        long long29 = day26.getMiddleMillisecond();
//        timePeriodValues1.setKey((java.lang.Comparable) day26);
//        java.util.Date date31 = day26.getEnd();
//        org.junit.Assert.assertNull(str6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertNull(str20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass27);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560495599999L + "'", long28 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560452399999L + "'", long29 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date31);
//    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
        int int6 = timePeriodValues1.getMaxStartIndex();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year8.previous();
        java.lang.String str14 = year8.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year8.previous();
        java.util.Calendar calendar16 = null;
        try {
            long long17 = year8.getLastMillisecond(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019" + "'", str14.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod15);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        timePeriodValues1.setKey((java.lang.Comparable) ' ');
        int int13 = timePeriodValues1.getMinStartIndex();
        boolean boolean14 = timePeriodValues1.isEmpty();
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

//    @Test
//    public void test203() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test203");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getMiddleMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate5 = day4.getSerialDate();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
//        boolean boolean7 = day0.equals((java.lang.Object) serialDate5);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day0.next();
//        int int9 = day0.getYear();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560452399999L + "'", long2 == 1560452399999L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        boolean boolean5 = timePeriodValues1.equals((java.lang.Object) (short) 0);
        int int6 = timePeriodValues1.getMaxEndIndex();
        int int7 = timePeriodValues1.getMinMiddleIndex();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMinEndIndex();
        boolean boolean6 = timePeriodValues1.isEmpty();
        boolean boolean7 = timePeriodValues1.getNotify();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener8);
        try {
            timePeriodValues1.delete(4, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        int int9 = timePeriodValues1.getMinMiddleIndex();
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 100);
        timePeriodValue3.setValue((java.lang.Number) 3);
        org.jfree.data.time.TimePeriod timePeriod6 = timePeriodValue3.getPeriod();
        java.lang.Object obj7 = timePeriodValue3.clone();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues9.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues9.removePropertyChangeListener(propertyChangeListener12);
        int int14 = timePeriodValues9.getItemCount();
        int int15 = timePeriodValues9.getMaxMiddleIndex();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        timePeriodValues9.add((org.jfree.data.time.TimePeriod) year16, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year16, (java.lang.Number) 2019L);
        java.util.Date date21 = year16.getEnd();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date21);
        boolean boolean23 = timePeriodValue3.equals((java.lang.Object) date21);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(timePeriod6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        int int11 = timePeriodValues1.getItemCount();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues13.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues13.removePropertyChangeListener(propertyChangeListener16);
        int int18 = timePeriodValues13.getItemCount();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        long long20 = year19.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue22 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year19, (java.lang.Number) 100);
        java.lang.Object obj23 = timePeriodValue22.clone();
        timePeriodValues13.add(timePeriodValue22);
        java.lang.String str25 = timePeriodValue22.toString();
        java.lang.Object obj26 = timePeriodValue22.clone();
        timePeriodValues1.add(timePeriodValue22);
        timePeriodValue22.setValue((java.lang.Number) 10.0f);
        org.jfree.data.time.TimePeriod timePeriod30 = timePeriodValue22.getPeriod();
        org.jfree.data.time.TimePeriodValues timePeriodValues32 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues32.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener35 = null;
        timePeriodValues32.removePropertyChangeListener(propertyChangeListener35);
        int int37 = timePeriodValues32.getItemCount();
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
        long long39 = year38.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue41 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year38, (java.lang.Number) 100);
        java.lang.Object obj42 = timePeriodValue41.clone();
        timePeriodValues32.add(timePeriodValue41);
        java.lang.String str44 = timePeriodValue41.toString();
        java.lang.Object obj45 = timePeriodValue41.clone();
        boolean boolean46 = timePeriodValue22.equals(obj45);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 2019L + "'", long20 == 2019L);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "TimePeriodValue[2019,100]" + "'", str25.equals("TimePeriodValue[2019,100]"));
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertNotNull(timePeriod30);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 2019L + "'", long39 == 2019L);
        org.junit.Assert.assertNotNull(obj42);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "TimePeriodValue[2019,100]" + "'", str44.equals("TimePeriodValue[2019,100]"));
        org.junit.Assert.assertNotNull(obj45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener13);
        int int15 = timePeriodValues10.getItemCount();
        int int16 = timePeriodValues10.getMaxMiddleIndex();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) year17, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 2019L);
        java.util.Date date22 = year17.getEnd();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date22, timeZone23);
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues26.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timePeriodValues26.removePropertyChangeListener(propertyChangeListener29);
        int int31 = timePeriodValues26.getItemCount();
        int int32 = timePeriodValues26.getMaxMiddleIndex();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        timePeriodValues26.add((org.jfree.data.time.TimePeriod) year33, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue37 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year33, (java.lang.Number) 2019L);
        java.util.Date date38 = year33.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(date22, date38);
        long long40 = simpleTimePeriod39.getEndMillis();
        long long41 = simpleTimePeriod39.getStartMillis();
        boolean boolean43 = simpleTimePeriod39.equals((java.lang.Object) 0);
        java.util.Date date44 = simpleTimePeriod39.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues46 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener47 = null;
        timePeriodValues46.addChangeListener(seriesChangeListener47);
        int int49 = timePeriodValues46.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass50 = timePeriodValues46.getClass();
        java.util.Date date51 = null;
        java.util.TimeZone timeZone52 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass50, date51, timeZone52);
        org.jfree.data.time.TimePeriodValues timePeriodValues55 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues55.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener58 = null;
        timePeriodValues55.removePropertyChangeListener(propertyChangeListener58);
        int int60 = timePeriodValues55.getItemCount();
        int int61 = timePeriodValues55.getMaxMiddleIndex();
        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year();
        timePeriodValues55.add((org.jfree.data.time.TimePeriod) year62, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue66 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year62, (java.lang.Number) 2019L);
        java.util.Date date67 = year62.getEnd();
        java.util.TimeZone timeZone68 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass50, date67, timeZone68);
        org.jfree.data.time.TimePeriodValues timePeriodValues71 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues71.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener74 = null;
        timePeriodValues71.removePropertyChangeListener(propertyChangeListener74);
        int int76 = timePeriodValues71.getItemCount();
        int int77 = timePeriodValues71.getMaxMiddleIndex();
        org.jfree.data.time.Year year78 = new org.jfree.data.time.Year();
        timePeriodValues71.add((org.jfree.data.time.TimePeriod) year78, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue82 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year78, (java.lang.Number) 2019L);
        java.util.Date date83 = year78.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod84 = new org.jfree.data.time.SimpleTimePeriod(date67, date83);
        java.util.TimeZone timeZone85 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year86 = new org.jfree.data.time.Year(date67, timeZone85);
        boolean boolean87 = simpleTimePeriod39.equals((java.lang.Object) date67);
        java.util.Date date88 = simpleTimePeriod39.getEnd();
        boolean boolean90 = simpleTimePeriod39.equals((java.lang.Object) (byte) 10);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1577865599999L + "'", long40 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1577865599999L + "'", long41 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertNull(regularTimePeriod53);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
        org.junit.Assert.assertNotNull(date67);
        org.junit.Assert.assertNotNull(timeZone68);
        org.junit.Assert.assertNull(regularTimePeriod69);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 0 + "'", int76 == 0);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + (-1) + "'", int77 == (-1));
        org.junit.Assert.assertNotNull(date83);
        org.junit.Assert.assertNotNull(timeZone85);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertNotNull(date88);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        boolean boolean9 = timePeriodValues1.equals((java.lang.Object) 3);
        java.lang.Comparable comparable10 = timePeriodValues1.getKey();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (byte) 1 + "'", comparable10.equals((byte) 1));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2019, 3, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        java.lang.Object obj0 = null;
        try {
            org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent(obj0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        int int11 = timePeriodValues1.getMaxMiddleIndex();
        java.lang.String str12 = timePeriodValues1.getDomainDescription();
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(serialDate1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(serialDate1);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(serialDate1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
        java.util.Calendar calendar6 = null;
        try {
            day4.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        try {
            java.lang.Number number7 = timePeriodValues1.getValue(2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2019, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = regularTimePeriod1.getMiddleMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesChangeEvent[source=4]");
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener13);
        int int15 = timePeriodValues10.getItemCount();
        int int16 = timePeriodValues10.getMaxMiddleIndex();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) year17, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 2019L);
        java.util.Date date22 = year17.getEnd();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date22, timeZone23);
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues26.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timePeriodValues26.removePropertyChangeListener(propertyChangeListener29);
        int int31 = timePeriodValues26.getItemCount();
        int int32 = timePeriodValues26.getMaxMiddleIndex();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        timePeriodValues26.add((org.jfree.data.time.TimePeriod) year33, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue37 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year33, (java.lang.Number) 2019L);
        java.util.Date date38 = year33.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(date22, date38);
        org.jfree.data.time.TimePeriodValues timePeriodValues41 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues41.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener44 = null;
        timePeriodValues41.removePropertyChangeListener(propertyChangeListener44);
        java.lang.String str46 = timePeriodValues41.getDescription();
        int int47 = timePeriodValues41.getMinStartIndex();
        timePeriodValues41.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues52 = timePeriodValues41.createCopy(0, 1);
        boolean boolean53 = simpleTimePeriod39.equals((java.lang.Object) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues55 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues55.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener58 = null;
        timePeriodValues55.removePropertyChangeListener(propertyChangeListener58);
        int int60 = timePeriodValues55.getItemCount();
        int int61 = timePeriodValues55.getMaxMiddleIndex();
        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year();
        timePeriodValues55.add((org.jfree.data.time.TimePeriod) year62, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue66 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year62, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = year62.previous();
        long long68 = regularTimePeriod67.getMiddleMillisecond();
        boolean boolean69 = simpleTimePeriod39.equals((java.lang.Object) long68);
        org.jfree.data.time.TimePeriodValues timePeriodValues72 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) boolean69, "", "13-June-2019");
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNull(str46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod67);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 1530561599999L + "'", long68 == 1530561599999L);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        timePeriodValues1.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = timePeriodValues1.createCopy(4, 0);
        timePeriodValues1.delete((int) (byte) 10, (int) (short) 0);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues12);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year8.previous();
        java.lang.String str14 = year8.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year8.next();
        java.lang.Number number16 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod15, number16);
        org.jfree.data.time.TimePeriod timePeriod18 = timePeriodValue17.getPeriod();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019" + "'", str14.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(timePeriod18);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener13);
        int int15 = timePeriodValues10.getItemCount();
        int int16 = timePeriodValues10.getMaxMiddleIndex();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) year17, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 2019L);
        java.util.Date date22 = year17.getEnd();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date22, timeZone23);
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues26.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timePeriodValues26.removePropertyChangeListener(propertyChangeListener29);
        int int31 = timePeriodValues26.getItemCount();
        int int32 = timePeriodValues26.getMaxMiddleIndex();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        timePeriodValues26.add((org.jfree.data.time.TimePeriod) year33, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue37 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year33, (java.lang.Number) 2019L);
        java.util.Date date38 = year33.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(date22, date38);
        long long40 = simpleTimePeriod39.getEndMillis();
        long long41 = simpleTimePeriod39.getStartMillis();
        boolean boolean43 = simpleTimePeriod39.equals((java.lang.Object) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues45 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener46 = null;
        timePeriodValues45.addChangeListener(seriesChangeListener46);
        int int48 = timePeriodValues45.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass49 = timePeriodValues45.getClass();
        java.util.Date date50 = null;
        java.util.TimeZone timeZone51 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass49, date50, timeZone51);
        org.jfree.data.time.TimePeriodValues timePeriodValues54 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues54.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener57 = null;
        timePeriodValues54.removePropertyChangeListener(propertyChangeListener57);
        int int59 = timePeriodValues54.getItemCount();
        int int60 = timePeriodValues54.getMaxMiddleIndex();
        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year();
        timePeriodValues54.add((org.jfree.data.time.TimePeriod) year61, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue65 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year61, (java.lang.Number) 2019L);
        java.util.Date date66 = year61.getEnd();
        java.util.TimeZone timeZone67 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass49, date66, timeZone67);
        org.jfree.data.time.TimePeriodValues timePeriodValues70 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues70.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener73 = null;
        timePeriodValues70.removePropertyChangeListener(propertyChangeListener73);
        int int75 = timePeriodValues70.getItemCount();
        int int76 = timePeriodValues70.getMaxMiddleIndex();
        org.jfree.data.time.Year year77 = new org.jfree.data.time.Year();
        timePeriodValues70.add((org.jfree.data.time.TimePeriod) year77, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue81 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year77, (java.lang.Number) 2019L);
        java.util.Date date82 = year77.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod83 = new org.jfree.data.time.SimpleTimePeriod(date66, date82);
        long long84 = simpleTimePeriod83.getEndMillis();
        long long85 = simpleTimePeriod83.getStartMillis();
        boolean boolean87 = simpleTimePeriod83.equals((java.lang.Object) 0);
        java.util.Date date88 = simpleTimePeriod83.getStart();
        boolean boolean89 = simpleTimePeriod39.equals((java.lang.Object) simpleTimePeriod83);
        long long90 = simpleTimePeriod39.getEndMillis();
        long long91 = simpleTimePeriod39.getEndMillis();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1577865599999L + "'", long40 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1577865599999L + "'", long41 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass49);
        org.junit.Assert.assertNull(regularTimePeriod52);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1) + "'", int60 == (-1));
        org.junit.Assert.assertNotNull(date66);
        org.junit.Assert.assertNotNull(timeZone67);
        org.junit.Assert.assertNull(regularTimePeriod68);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 0 + "'", int75 == 0);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + (-1) + "'", int76 == (-1));
        org.junit.Assert.assertNotNull(date82);
        org.junit.Assert.assertTrue("'" + long84 + "' != '" + 1577865599999L + "'", long84 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long85 + "' != '" + 1577865599999L + "'", long85 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertNotNull(date88);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + true + "'", boolean89 == true);
        org.junit.Assert.assertTrue("'" + long90 + "' != '" + 1577865599999L + "'", long90 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long91 + "' != '" + 1577865599999L + "'", long91 == 1577865599999L);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.String str2 = seriesChangeEvent1.toString();
        java.lang.String str3 = seriesChangeEvent1.toString();
        java.lang.Object obj4 = seriesChangeEvent1.getSource();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=0]" + "'", str2.equals("org.jfree.data.general.SeriesChangeEvent[source=0]"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=0]" + "'", str3.equals("org.jfree.data.general.SeriesChangeEvent[source=0]"));
        org.junit.Assert.assertTrue("'" + obj4 + "' != '" + (byte) 0 + "'", obj4.equals((byte) 0));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) 100, (int) (byte) 1, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener11);
        java.lang.String str13 = timePeriodValues1.getDomainDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues15.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timePeriodValues15.removePropertyChangeListener(propertyChangeListener18);
        java.lang.String str20 = timePeriodValues15.getDescription();
        int int21 = timePeriodValues15.getMinStartIndex();
        timePeriodValues15.fireSeriesChanged();
        boolean boolean23 = timePeriodValues1.equals((java.lang.Object) timePeriodValues15);
        try {
            timePeriodValues15.update(12, (java.lang.Number) 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 12, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener13);
        int int15 = timePeriodValues10.getItemCount();
        int int16 = timePeriodValues10.getMaxMiddleIndex();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) year17, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 2019L);
        java.util.Date date22 = year17.getEnd();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date22, timeZone23);
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues26.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timePeriodValues26.removePropertyChangeListener(propertyChangeListener29);
        int int31 = timePeriodValues26.getItemCount();
        int int32 = timePeriodValues26.getMaxMiddleIndex();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        timePeriodValues26.add((org.jfree.data.time.TimePeriod) year33, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue37 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year33, (java.lang.Number) 2019L);
        java.util.Date date38 = year33.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(date22, date38);
        long long40 = simpleTimePeriod39.getEndMillis();
        long long41 = simpleTimePeriod39.getStartMillis();
        boolean boolean43 = simpleTimePeriod39.equals((java.lang.Object) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues45 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener46 = null;
        timePeriodValues45.addChangeListener(seriesChangeListener46);
        int int48 = timePeriodValues45.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass49 = timePeriodValues45.getClass();
        java.util.Date date50 = null;
        java.util.TimeZone timeZone51 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass49, date50, timeZone51);
        org.jfree.data.time.TimePeriodValues timePeriodValues54 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues54.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener57 = null;
        timePeriodValues54.removePropertyChangeListener(propertyChangeListener57);
        int int59 = timePeriodValues54.getItemCount();
        int int60 = timePeriodValues54.getMaxMiddleIndex();
        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year();
        timePeriodValues54.add((org.jfree.data.time.TimePeriod) year61, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue65 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year61, (java.lang.Number) 2019L);
        java.util.Date date66 = year61.getEnd();
        java.util.TimeZone timeZone67 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass49, date66, timeZone67);
        org.jfree.data.time.TimePeriodValues timePeriodValues70 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues70.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener73 = null;
        timePeriodValues70.removePropertyChangeListener(propertyChangeListener73);
        int int75 = timePeriodValues70.getItemCount();
        int int76 = timePeriodValues70.getMaxMiddleIndex();
        org.jfree.data.time.Year year77 = new org.jfree.data.time.Year();
        timePeriodValues70.add((org.jfree.data.time.TimePeriod) year77, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue81 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year77, (java.lang.Number) 2019L);
        java.util.Date date82 = year77.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod83 = new org.jfree.data.time.SimpleTimePeriod(date66, date82);
        long long84 = simpleTimePeriod83.getEndMillis();
        long long85 = simpleTimePeriod83.getStartMillis();
        boolean boolean87 = simpleTimePeriod83.equals((java.lang.Object) 0);
        java.util.Date date88 = simpleTimePeriod83.getStart();
        boolean boolean89 = simpleTimePeriod39.equals((java.lang.Object) simpleTimePeriod83);
        long long90 = simpleTimePeriod83.getStartMillis();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1577865599999L + "'", long40 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1577865599999L + "'", long41 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass49);
        org.junit.Assert.assertNull(regularTimePeriod52);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1) + "'", int60 == (-1));
        org.junit.Assert.assertNotNull(date66);
        org.junit.Assert.assertNotNull(timeZone67);
        org.junit.Assert.assertNull(regularTimePeriod68);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 0 + "'", int75 == 0);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + (-1) + "'", int76 == (-1));
        org.junit.Assert.assertNotNull(date82);
        org.junit.Assert.assertTrue("'" + long84 + "' != '" + 1577865599999L + "'", long84 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long85 + "' != '" + 1577865599999L + "'", long85 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertNotNull(date88);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + true + "'", boolean89 == true);
        org.junit.Assert.assertTrue("'" + long90 + "' != '" + 1577865599999L + "'", long90 == 1577865599999L);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (java.lang.Number) 100);
        java.lang.Object obj11 = timePeriodValue10.clone();
        timePeriodValues1.add(timePeriodValue10);
        boolean boolean13 = timePeriodValues1.isEmpty();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(serialDate7);
        boolean boolean9 = timePeriodValues1.equals((java.lang.Object) serialDate7);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (100) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMinEndIndex();
        java.lang.String str6 = timePeriodValues1.getRangeDescription();
        timePeriodValues1.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener8);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Value" + "'", str6.equals("Value"));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues1.createCopy(0, 0);
        int int10 = timePeriodValues9.getMaxMiddleIndex();
        timePeriodValues9.setKey((java.lang.Comparable) 10);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(timePeriodValues9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        int int11 = timePeriodValues1.getMinMiddleIndex();
        int int12 = timePeriodValues1.getMinStartIndex();
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year8.previous();
        java.lang.String str14 = year8.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year8.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 100.0f);
        java.lang.String str18 = timePeriodValue17.toString();
        java.lang.Number number19 = timePeriodValue17.getValue();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019" + "'", str14.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "TimePeriodValue[2019,100.0]" + "'", str18.equals("TimePeriodValue[2019,100.0]"));
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + 100.0f + "'", number19.equals(100.0f));
    }

//    @Test
//    public void test233() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test233");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getMiddleMillisecond();
//        java.util.Calendar calendar3 = null;
//        try {
//            day0.peg(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560452399999L + "'", long2 == 1560452399999L);
//    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        int int11 = timePeriodValues1.getMaxMiddleIndex();
        timePeriodValues1.setNotify(true);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener14);
        int int16 = timePeriodValues1.getMaxMiddleIndex();
        java.lang.Comparable comparable17 = null;
        try {
            timePeriodValues1.setKey(comparable17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener13);
        int int15 = timePeriodValues10.getItemCount();
        int int16 = timePeriodValues10.getMaxMiddleIndex();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) year17, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 2019L);
        java.util.Date date22 = year17.getEnd();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date22, timeZone23);
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues26.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timePeriodValues26.removePropertyChangeListener(propertyChangeListener29);
        int int31 = timePeriodValues26.getItemCount();
        int int32 = timePeriodValues26.getMaxMiddleIndex();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        timePeriodValues26.add((org.jfree.data.time.TimePeriod) year33, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue37 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year33, (java.lang.Number) 2019L);
        java.util.Date date38 = year33.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(date22, date38);
        long long40 = simpleTimePeriod39.getEndMillis();
        long long41 = simpleTimePeriod39.getStartMillis();
        boolean boolean43 = simpleTimePeriod39.equals((java.lang.Object) 0);
        java.util.Date date44 = simpleTimePeriod39.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues46 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener47 = null;
        timePeriodValues46.addChangeListener(seriesChangeListener47);
        int int49 = timePeriodValues46.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass50 = timePeriodValues46.getClass();
        java.util.Date date51 = null;
        java.util.TimeZone timeZone52 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass50, date51, timeZone52);
        org.jfree.data.time.TimePeriodValues timePeriodValues55 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues55.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener58 = null;
        timePeriodValues55.removePropertyChangeListener(propertyChangeListener58);
        int int60 = timePeriodValues55.getItemCount();
        int int61 = timePeriodValues55.getMaxMiddleIndex();
        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year();
        timePeriodValues55.add((org.jfree.data.time.TimePeriod) year62, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue66 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year62, (java.lang.Number) 2019L);
        java.util.Date date67 = year62.getEnd();
        java.util.TimeZone timeZone68 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass50, date67, timeZone68);
        org.jfree.data.time.TimePeriodValues timePeriodValues71 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues71.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener74 = null;
        timePeriodValues71.removePropertyChangeListener(propertyChangeListener74);
        int int76 = timePeriodValues71.getItemCount();
        int int77 = timePeriodValues71.getMaxMiddleIndex();
        org.jfree.data.time.Year year78 = new org.jfree.data.time.Year();
        timePeriodValues71.add((org.jfree.data.time.TimePeriod) year78, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue82 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year78, (java.lang.Number) 2019L);
        java.util.Date date83 = year78.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod84 = new org.jfree.data.time.SimpleTimePeriod(date67, date83);
        java.util.TimeZone timeZone85 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year86 = new org.jfree.data.time.Year(date67, timeZone85);
        boolean boolean87 = simpleTimePeriod39.equals((java.lang.Object) date67);
        long long88 = simpleTimePeriod39.getEndMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues90 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener91 = null;
        timePeriodValues90.addChangeListener(seriesChangeListener91);
        int int93 = timePeriodValues90.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass94 = timePeriodValues90.getClass();
        try {
            int int95 = simpleTimePeriod39.compareTo((java.lang.Object) timePeriodValues90);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.TimePeriodValues cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1577865599999L + "'", long40 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1577865599999L + "'", long41 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertNull(regularTimePeriod53);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
        org.junit.Assert.assertNotNull(date67);
        org.junit.Assert.assertNotNull(timeZone68);
        org.junit.Assert.assertNull(regularTimePeriod69);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 0 + "'", int76 == 0);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + (-1) + "'", int77 == (-1));
        org.junit.Assert.assertNotNull(date83);
        org.junit.Assert.assertNotNull(timeZone85);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertTrue("'" + long88 + "' != '" + 1577865599999L + "'", long88 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + (-1) + "'", int93 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass94);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) ' ');
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues4.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues4.removePropertyChangeListener(propertyChangeListener7);
        int int9 = timePeriodValues4.getItemCount();
        int int10 = timePeriodValues4.getMaxMiddleIndex();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        timePeriodValues4.add((org.jfree.data.time.TimePeriod) year11, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue15 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year11, (java.lang.Number) 2019L);
        java.util.Date date16 = year11.getEnd();
        boolean boolean17 = simpleTimePeriod2.equals((java.lang.Object) date16);
        java.lang.Object obj18 = null;
        try {
            int int19 = simpleTimePeriod2.compareTo(obj18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        java.lang.String str2 = timePeriodValues1.getDescription();
        java.lang.String str3 = timePeriodValues1.getDomainDescription();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
    }

//    @Test
//    public void test238() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test238");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getMiddleMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate5 = day4.getSerialDate();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
//        boolean boolean7 = day0.equals((java.lang.Object) serialDate5);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day0.next();
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod8, (double) (short) 0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560452399999L + "'", long2 == 1560452399999L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        timePeriodValues1.setKey((java.lang.Comparable) "hi!");
        timePeriodValues1.delete(13, 4);
        java.lang.Number number10 = null;
        try {
            timePeriodValues1.update(0, number10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        timePeriodValues1.setNotify(true);
        try {
            java.lang.Number number9 = timePeriodValues1.getValue((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMinEndIndex();
        boolean boolean6 = timePeriodValues1.isEmpty();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener8);
        try {
            timePeriodValues1.delete(0, 31);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 2019L);
        java.util.Date date13 = year8.getEnd();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date13);
        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, (java.lang.Number) 5);
        java.util.Calendar calendar17 = null;
        try {
            long long18 = year14.getFirstMillisecond(calendar17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(date13);
    }

//    @Test
//    public void test243() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test243");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        timePeriodValues3.setNotify(true);
//        java.beans.PropertyChangeListener propertyChangeListener6 = null;
//        timePeriodValues3.removePropertyChangeListener(propertyChangeListener6);
//        java.lang.String str8 = timePeriodValues3.getDescription();
//        int int9 = timePeriodValues3.getMinStartIndex();
//        timePeriodValues3.setNotify(true);
//        int int12 = day0.compareTo((java.lang.Object) timePeriodValues3);
//        long long13 = day0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertNull(str8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560409200000L + "'", long13 == 1560409200000L);
//    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        timePeriodValues1.setNotify(true);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year10, (java.lang.Number) 100);
        timePeriodValue13.setValue((java.lang.Number) 3);
        org.jfree.data.time.TimePeriod timePeriod16 = timePeriodValue13.getPeriod();
        timePeriodValues1.add(timePeriodValue13);
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues19.setNotify(true);
        timePeriodValues19.setKey((java.lang.Comparable) 100L);
        timePeriodValues19.setKey((java.lang.Comparable) (short) 100);
        java.lang.String str26 = timePeriodValues19.getRangeDescription();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        long long28 = year27.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue30 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year27, (java.lang.Number) 100);
        timePeriodValues19.add(timePeriodValue30);
        boolean boolean32 = timePeriodValue13.equals((java.lang.Object) timePeriodValues19);
        timePeriodValue13.setValue((java.lang.Number) 43830L);
        java.lang.Object obj35 = timePeriodValue13.clone();
        timePeriodValue13.setValue((java.lang.Number) (short) 10);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
        org.junit.Assert.assertNotNull(timePeriod16);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Value" + "'", str26.equals("Value"));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 2019L + "'", long28 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(obj35);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        timePeriodValues1.delete((int) (byte) 1, (int) (byte) 0);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (java.lang.Number) 100);
        java.lang.Object obj11 = timePeriodValue10.clone();
        java.lang.String str12 = timePeriodValue10.toString();
        boolean boolean14 = timePeriodValue10.equals((java.lang.Object) 100);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        boolean boolean16 = timePeriodValue10.equals((java.lang.Object) day15);
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues18.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timePeriodValues18.removePropertyChangeListener(propertyChangeListener21);
        int int23 = timePeriodValues18.getItemCount();
        int int24 = timePeriodValues18.getMaxMiddleIndex();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        timePeriodValues18.add((org.jfree.data.time.TimePeriod) year25, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue29 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year25, (java.lang.Number) 2019L);
        java.util.Date date30 = year25.getEnd();
        long long31 = year25.getMiddleMillisecond();
        long long32 = year25.getSerialIndex();
        boolean boolean33 = day15.equals((java.lang.Object) year25);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year25, (java.lang.Number) 1577865599999L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "TimePeriodValue[2019,100]" + "'", str12.equals("TimePeriodValue[2019,100]"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1562097599999L + "'", long31 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 2019L + "'", long32 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

//    @Test
//    public void test246() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test246");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass1 = day0.getClass();
//        long long2 = day0.getLastMillisecond();
//        java.lang.String str3 = day0.toString();
//        long long4 = day0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.next();
//        org.junit.Assert.assertNotNull(wildcardClass1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560495599999L + "'", long2 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        java.util.Date date0 = null;
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timePeriodValues2.addChangeListener(seriesChangeListener3);
        int int5 = timePeriodValues2.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass6 = timePeriodValues2.getClass();
        java.util.Date date7 = null;
        java.util.TimeZone timeZone8 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date7, timeZone8);
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues11.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timePeriodValues11.removePropertyChangeListener(propertyChangeListener14);
        int int16 = timePeriodValues11.getItemCount();
        int int17 = timePeriodValues11.getMaxMiddleIndex();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        timePeriodValues11.add((org.jfree.data.time.TimePeriod) year18, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue22 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year18, (java.lang.Number) 2019L);
        java.util.Date date23 = year18.getEnd();
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date23, timeZone24);
        org.jfree.data.time.TimePeriodValues timePeriodValues27 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues27.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener30 = null;
        timePeriodValues27.removePropertyChangeListener(propertyChangeListener30);
        int int32 = timePeriodValues27.getItemCount();
        int int33 = timePeriodValues27.getMaxMiddleIndex();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        timePeriodValues27.add((org.jfree.data.time.TimePeriod) year34, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue38 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year34, (java.lang.Number) 2019L);
        java.util.Date date39 = year34.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod40 = new org.jfree.data.time.SimpleTimePeriod(date23, date39);
        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year(date23, timeZone41);
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod43 = new org.jfree.data.time.SimpleTimePeriod(date0, date23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(timeZone41);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 100);
        java.util.Date date4 = year0.getStart();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) (short) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues8.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues8.removePropertyChangeListener(propertyChangeListener11);
        java.lang.String str13 = timePeriodValues8.getDescription();
        boolean boolean14 = year0.equals((java.lang.Object) timePeriodValues8);
        java.util.Calendar calendar15 = null;
        try {
            year0.peg(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) ' ');
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues4.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues4.removePropertyChangeListener(propertyChangeListener7);
        int int9 = timePeriodValues4.getItemCount();
        int int10 = timePeriodValues4.getMaxMiddleIndex();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        timePeriodValues4.add((org.jfree.data.time.TimePeriod) year11, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue15 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year11, (java.lang.Number) 2019L);
        java.util.Date date16 = year11.getEnd();
        boolean boolean17 = simpleTimePeriod2.equals((java.lang.Object) date16);
        long long18 = simpleTimePeriod2.getStartMillis();
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.String str2 = seriesChangeEvent1.toString();
        java.lang.Object obj3 = seriesChangeEvent1.getSource();
        java.lang.String str4 = seriesChangeEvent1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=0]" + "'", str2.equals("org.jfree.data.general.SeriesChangeEvent[source=0]"));
        org.junit.Assert.assertTrue("'" + obj3 + "' != '" + (byte) 0 + "'", obj3.equals((byte) 0));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=0]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=0]"));
    }

//    @Test
//    public void test251() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test251");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        int int4 = timePeriodValues1.getMinMiddleIndex();
//        int int5 = timePeriodValues1.getMinEndIndex();
//        java.lang.String str6 = timePeriodValues1.getRangeDescription();
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
//        long long8 = year7.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year7.previous();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod9, (java.lang.Number) 6);
//        int int12 = timePeriodValues1.getMinEndIndex();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.String str14 = day13.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day13.next();
//        long long16 = day13.getFirstMillisecond();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day13, (java.lang.Number) 4);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Value" + "'", str6.equals("Value"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560409200000L + "'", long16 == 1560409200000L);
//    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        timePeriodValues1.setNotify(true);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener10);
        java.lang.Class<?> wildcardClass12 = timePeriodValues1.getClass();
        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass12);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(class13);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener11);
        int int13 = timePeriodValues1.getMaxEndIndex();
        try {
            java.lang.Number number15 = timePeriodValues1.getValue((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        timePeriodValues1.fireSeriesChanged();
        try {
            timePeriodValues1.update((int) (byte) 1, (java.lang.Number) 1562097599999L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener13);
        int int15 = timePeriodValues10.getItemCount();
        int int16 = timePeriodValues10.getMaxMiddleIndex();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) year17, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 2019L);
        java.util.Date date22 = year17.getEnd();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date22, timeZone23);
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues26.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timePeriodValues26.removePropertyChangeListener(propertyChangeListener29);
        int int31 = timePeriodValues26.getItemCount();
        int int32 = timePeriodValues26.getMaxMiddleIndex();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        timePeriodValues26.add((org.jfree.data.time.TimePeriod) year33, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue37 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year33, (java.lang.Number) 2019L);
        java.util.Date date38 = year33.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(date22, date38);
        org.jfree.data.time.TimePeriodValues timePeriodValues41 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues41.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener44 = null;
        timePeriodValues41.removePropertyChangeListener(propertyChangeListener44);
        java.lang.String str46 = timePeriodValues41.getDescription();
        int int47 = timePeriodValues41.getMinStartIndex();
        timePeriodValues41.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues52 = timePeriodValues41.createCopy(0, 1);
        boolean boolean53 = simpleTimePeriod39.equals((java.lang.Object) 0);
        java.util.Date date54 = simpleTimePeriod39.getStart();
        org.jfree.data.time.TimePeriodValue timePeriodValue56 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod39, (double) (byte) 100);
        java.util.Date date57 = simpleTimePeriod39.getEnd();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNull(str46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertNotNull(date57);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        int int2 = timePeriodValues1.getMinMiddleIndex();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener13);
        int int15 = timePeriodValues10.getItemCount();
        int int16 = timePeriodValues10.getMaxMiddleIndex();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) year17, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 2019L);
        java.util.Date date22 = year17.getEnd();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date22, timeZone23);
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues26.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timePeriodValues26.removePropertyChangeListener(propertyChangeListener29);
        int int31 = timePeriodValues26.getItemCount();
        int int32 = timePeriodValues26.getMaxMiddleIndex();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        timePeriodValues26.add((org.jfree.data.time.TimePeriod) year33, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue37 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year33, (java.lang.Number) 2019L);
        java.util.Date date38 = year33.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(date22, date38);
        org.jfree.data.time.TimePeriodValues timePeriodValues41 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues41.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener44 = null;
        timePeriodValues41.removePropertyChangeListener(propertyChangeListener44);
        java.lang.String str46 = timePeriodValues41.getDescription();
        int int47 = timePeriodValues41.getMinStartIndex();
        timePeriodValues41.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues52 = timePeriodValues41.createCopy(0, 1);
        boolean boolean53 = simpleTimePeriod39.equals((java.lang.Object) 0);
        java.util.Date date54 = simpleTimePeriod39.getStart();
        org.jfree.data.time.TimePeriodValue timePeriodValue56 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod39, (double) (byte) 100);
        org.jfree.data.time.TimePeriodValues timePeriodValues58 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener59 = null;
        timePeriodValues58.addChangeListener(seriesChangeListener59);
        int int61 = timePeriodValues58.getMinMiddleIndex();
        int int62 = timePeriodValues58.getMinEndIndex();
        boolean boolean63 = timePeriodValues58.isEmpty();
        int int64 = timePeriodValues58.getMaxMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener65 = null;
        timePeriodValues58.addChangeListener(seriesChangeListener65);
        try {
            int int67 = simpleTimePeriod39.compareTo((java.lang.Object) timePeriodValues58);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.TimePeriodValues cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNull(str46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-1) + "'", int62 == (-1));
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + (-1) + "'", int64 == (-1));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(serialDate1);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = day2.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener11);
        java.lang.String str13 = timePeriodValues1.getDomainDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues15.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timePeriodValues15.removePropertyChangeListener(propertyChangeListener18);
        java.lang.String str20 = timePeriodValues15.getDescription();
        int int21 = timePeriodValues15.getMinStartIndex();
        timePeriodValues15.fireSeriesChanged();
        boolean boolean23 = timePeriodValues1.equals((java.lang.Object) timePeriodValues15);
        int int24 = timePeriodValues1.getMaxStartIndex();
        java.lang.Comparable comparable25 = timePeriodValues1.getKey();
        try {
            timePeriodValues1.update(0, (java.lang.Number) 100.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + comparable25 + "' != '" + (byte) 1 + "'", comparable25.equals((byte) 1));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10);
        java.lang.Object obj2 = seriesChangeEvent1.getSource();
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + 10 + "'", obj2.equals(10));
    }

//    @Test
//    public void test261() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test261");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass1 = day0.getClass();
//        long long2 = day0.getLastMillisecond();
//        long long3 = day0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.next();
//        org.junit.Assert.assertNotNull(wildcardClass1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560495599999L + "'", long2 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560452399999L + "'", long3 == 1560452399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("TimePeriodValue[13-June-2019,8.0]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (byte) 1, (int) (short) 100, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        int int11 = timePeriodValues1.getMaxEndIndex();
        java.lang.String str12 = timePeriodValues1.getRangeDescription();
        timePeriodValues1.setKey((java.lang.Comparable) 7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener15);
        timePeriodValues1.setRangeDescription("");
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener21 = null;
        timePeriodValues20.addChangeListener(seriesChangeListener21);
        int int23 = timePeriodValues20.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass24 = timePeriodValues20.getClass();
        java.util.Date date25 = null;
        java.util.TimeZone timeZone26 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date25, timeZone26);
        org.jfree.data.time.TimePeriodValues timePeriodValues29 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues29.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener32 = null;
        timePeriodValues29.removePropertyChangeListener(propertyChangeListener32);
        int int34 = timePeriodValues29.getItemCount();
        int int35 = timePeriodValues29.getMaxMiddleIndex();
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        timePeriodValues29.add((org.jfree.data.time.TimePeriod) year36, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue40 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year36, (java.lang.Number) 2019L);
        java.util.Date date41 = year36.getEnd();
        java.util.TimeZone timeZone42 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date41, timeZone42);
        org.jfree.data.time.TimePeriodValues timePeriodValues45 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues45.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener48 = null;
        timePeriodValues45.removePropertyChangeListener(propertyChangeListener48);
        int int50 = timePeriodValues45.getItemCount();
        int int51 = timePeriodValues45.getMaxMiddleIndex();
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year();
        timePeriodValues45.add((org.jfree.data.time.TimePeriod) year52, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue56 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year52, (java.lang.Number) 2019L);
        java.util.Date date57 = year52.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod58 = new org.jfree.data.time.SimpleTimePeriod(date41, date57);
        long long59 = simpleTimePeriod58.getEndMillis();
        long long60 = simpleTimePeriod58.getStartMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues62 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues62.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener65 = null;
        timePeriodValues62.removePropertyChangeListener(propertyChangeListener65);
        int int67 = timePeriodValues62.getItemCount();
        int int68 = timePeriodValues62.getMaxMiddleIndex();
        org.jfree.data.time.Year year69 = new org.jfree.data.time.Year();
        timePeriodValues62.add((org.jfree.data.time.TimePeriod) year69, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue73 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year69, (java.lang.Number) 2019L);
        java.util.Date date74 = year69.getEnd();
        long long75 = year69.getFirstMillisecond();
        boolean boolean76 = simpleTimePeriod58.equals((java.lang.Object) long75);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod58, (java.lang.Number) 10);
        org.jfree.data.time.TimePeriodValues timePeriodValues80 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues80.setNotify(true);
        timePeriodValues80.setKey((java.lang.Comparable) 100L);
        timePeriodValues80.setKey((java.lang.Comparable) (short) 100);
        java.lang.String str87 = timePeriodValues80.getRangeDescription();
        try {
            int int88 = simpleTimePeriod58.compareTo((java.lang.Object) timePeriodValues80);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.TimePeriodValues cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Value" + "'", str12.equals("Value"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(timeZone42);
        org.junit.Assert.assertNull(regularTimePeriod43);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1) + "'", int51 == (-1));
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 1577865599999L + "'", long59 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1577865599999L + "'", long60 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + (-1) + "'", int68 == (-1));
        org.junit.Assert.assertNotNull(date74);
        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 1546329600000L + "'", long75 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + str87 + "' != '" + "Value" + "'", str87.equals("Value"));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        int int11 = timePeriodValues1.getMaxEndIndex();
        java.lang.String str12 = timePeriodValues1.getRangeDescription();
        int int13 = timePeriodValues1.getMaxEndIndex();
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener14);
        int int16 = timePeriodValues1.getMaxStartIndex();
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Value" + "'", str12.equals("Value"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        java.util.Date date3 = regularTimePeriod2.getStart();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener13);
        int int15 = timePeriodValues10.getItemCount();
        int int16 = timePeriodValues10.getMaxMiddleIndex();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) year17, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 2019L);
        java.util.Date date22 = year17.getEnd();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date22, timeZone23);
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues26.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timePeriodValues26.removePropertyChangeListener(propertyChangeListener29);
        int int31 = timePeriodValues26.getItemCount();
        int int32 = timePeriodValues26.getMaxMiddleIndex();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        timePeriodValues26.add((org.jfree.data.time.TimePeriod) year33, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue37 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year33, (java.lang.Number) 2019L);
        java.util.Date date38 = year33.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(date22, date38);
        long long40 = simpleTimePeriod39.getEndMillis();
        long long41 = simpleTimePeriod39.getStartMillis();
        boolean boolean43 = simpleTimePeriod39.equals((java.lang.Object) 0);
        java.util.Date date44 = simpleTimePeriod39.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues46 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener47 = null;
        timePeriodValues46.addChangeListener(seriesChangeListener47);
        int int49 = timePeriodValues46.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass50 = timePeriodValues46.getClass();
        java.util.Date date51 = null;
        java.util.TimeZone timeZone52 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass50, date51, timeZone52);
        org.jfree.data.time.TimePeriodValues timePeriodValues55 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues55.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener58 = null;
        timePeriodValues55.removePropertyChangeListener(propertyChangeListener58);
        int int60 = timePeriodValues55.getItemCount();
        int int61 = timePeriodValues55.getMaxMiddleIndex();
        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year();
        timePeriodValues55.add((org.jfree.data.time.TimePeriod) year62, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue66 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year62, (java.lang.Number) 2019L);
        java.util.Date date67 = year62.getEnd();
        java.util.TimeZone timeZone68 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass50, date67, timeZone68);
        org.jfree.data.time.TimePeriodValues timePeriodValues71 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues71.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener74 = null;
        timePeriodValues71.removePropertyChangeListener(propertyChangeListener74);
        int int76 = timePeriodValues71.getItemCount();
        int int77 = timePeriodValues71.getMaxMiddleIndex();
        org.jfree.data.time.Year year78 = new org.jfree.data.time.Year();
        timePeriodValues71.add((org.jfree.data.time.TimePeriod) year78, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue82 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year78, (java.lang.Number) 2019L);
        java.util.Date date83 = year78.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod84 = new org.jfree.data.time.SimpleTimePeriod(date67, date83);
        java.util.TimeZone timeZone85 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year86 = new org.jfree.data.time.Year(date67, timeZone85);
        boolean boolean87 = simpleTimePeriod39.equals((java.lang.Object) date67);
        java.util.Date date88 = simpleTimePeriod39.getEnd();
        org.jfree.data.time.Year year89 = new org.jfree.data.time.Year();
        long long90 = year89.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue92 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year89, (java.lang.Number) 100);
        java.util.Date date93 = year89.getStart();
        org.jfree.data.time.TimePeriodValue timePeriodValue95 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year89, (java.lang.Number) (short) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod96 = year89.previous();
        long long97 = year89.getLastMillisecond();
        boolean boolean98 = simpleTimePeriod39.equals((java.lang.Object) year89);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1577865599999L + "'", long40 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1577865599999L + "'", long41 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertNull(regularTimePeriod53);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
        org.junit.Assert.assertNotNull(date67);
        org.junit.Assert.assertNotNull(timeZone68);
        org.junit.Assert.assertNull(regularTimePeriod69);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 0 + "'", int76 == 0);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + (-1) + "'", int77 == (-1));
        org.junit.Assert.assertNotNull(date83);
        org.junit.Assert.assertNotNull(timeZone85);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertNotNull(date88);
        org.junit.Assert.assertTrue("'" + long90 + "' != '" + 2019L + "'", long90 == 2019L);
        org.junit.Assert.assertNotNull(date93);
        org.junit.Assert.assertNotNull(regularTimePeriod96);
        org.junit.Assert.assertTrue("'" + long97 + "' != '" + 1577865599999L + "'", long97 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean98 + "' != '" + false + "'", boolean98 == false);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMinEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = timePeriodValues1.createCopy(6, (int) (byte) 100);
        int int9 = timePeriodValues8.getMinEndIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        long long11 = year8.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1546329600000L + "'", long11 == 1546329600000L);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMinEndIndex();
        java.lang.String str6 = timePeriodValues1.getRangeDescription();
        timePeriodValues1.fireSeriesChanged();
        java.lang.String str8 = timePeriodValues1.getDescription();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Value" + "'", str6.equals("Value"));
        org.junit.Assert.assertNull(str8);
    }

//    @Test
//    public void test271() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test271");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getLastMillisecond();
//        java.util.Calendar calendar3 = null;
//        try {
//            day0.peg(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560495599999L + "'", long2 == 1560495599999L);
//    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 2019L);
        int int13 = year8.getYear();
        java.lang.String str14 = year8.toString();
        java.util.Calendar calendar15 = null;
        try {
            year8.peg(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019" + "'", str14.equals("2019"));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        java.lang.Comparable comparable0 = null;
        try {
            org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues(comparable0, "Value", "Value");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 100);
        java.util.Date date4 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues6.addChangeListener(seriesChangeListener7);
        int int9 = timePeriodValues6.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass10 = timePeriodValues6.getClass();
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date11, timeZone12);
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues15.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timePeriodValues15.removePropertyChangeListener(propertyChangeListener18);
        int int20 = timePeriodValues15.getItemCount();
        int int21 = timePeriodValues15.getMaxMiddleIndex();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        timePeriodValues15.add((org.jfree.data.time.TimePeriod) year22, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue26 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year22, (java.lang.Number) 2019L);
        java.util.Date date27 = year22.getEnd();
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date27, timeZone28);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(date4, timeZone28);
        org.jfree.data.time.TimePeriodValues timePeriodValues32 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener33 = null;
        timePeriodValues32.addChangeListener(seriesChangeListener33);
        int int35 = timePeriodValues32.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass36 = timePeriodValues32.getClass();
        java.util.Date date37 = null;
        java.util.TimeZone timeZone38 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date37, timeZone38);
        org.jfree.data.time.TimePeriodValues timePeriodValues41 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues41.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener44 = null;
        timePeriodValues41.removePropertyChangeListener(propertyChangeListener44);
        int int46 = timePeriodValues41.getItemCount();
        int int47 = timePeriodValues41.getMaxMiddleIndex();
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year();
        timePeriodValues41.add((org.jfree.data.time.TimePeriod) year48, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue52 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year48, (java.lang.Number) 2019L);
        java.util.Date date53 = year48.getEnd();
        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date53, timeZone54);
        org.jfree.data.time.TimePeriodValues timePeriodValues57 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues57.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener60 = null;
        timePeriodValues57.removePropertyChangeListener(propertyChangeListener60);
        int int62 = timePeriodValues57.getItemCount();
        int int63 = timePeriodValues57.getMaxMiddleIndex();
        org.jfree.data.time.Year year64 = new org.jfree.data.time.Year();
        timePeriodValues57.add((org.jfree.data.time.TimePeriod) year64, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue68 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year64, (java.lang.Number) 2019L);
        java.util.Date date69 = year64.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod70 = new org.jfree.data.time.SimpleTimePeriod(date53, date69);
        java.util.TimeZone timeZone71 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year72 = new org.jfree.data.time.Year(date53, timeZone71);
        org.jfree.data.time.Year year73 = new org.jfree.data.time.Year(date4, timeZone71);
        java.util.Date date74 = null;
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod75 = new org.jfree.data.time.SimpleTimePeriod(date4, date74);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertNotNull(timeZone54);
        org.junit.Assert.assertNull(regularTimePeriod55);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-1) + "'", int63 == (-1));
        org.junit.Assert.assertNotNull(date69);
        org.junit.Assert.assertNotNull(timeZone71);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMinEndIndex();
        java.lang.String str6 = timePeriodValues1.getRangeDescription();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year7.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod9, (java.lang.Number) 6);
        boolean boolean12 = timePeriodValues1.getNotify();
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener13);
        timePeriodValues1.setRangeDescription("Time");
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Value" + "'", str6.equals("Value"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 2019L);
        java.lang.Class<?> wildcardClass13 = year8.getClass();
        java.lang.String str14 = year8.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year8.next();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019" + "'", str14.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod15);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 2019L);
        java.util.Date date13 = year8.getEnd();
        long long14 = year8.getMiddleMillisecond();
        java.lang.String str15 = year8.toString();
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues17.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timePeriodValues17.removePropertyChangeListener(propertyChangeListener20);
        int int22 = timePeriodValues17.getItemCount();
        int int23 = timePeriodValues17.getMaxMiddleIndex();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        timePeriodValues17.add((org.jfree.data.time.TimePeriod) year24, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue28 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year24, (java.lang.Number) 2019L);
        java.util.Date date29 = year24.getEnd();
        long long30 = year24.getFirstMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues32 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues32.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener35 = null;
        timePeriodValues32.removePropertyChangeListener(propertyChangeListener35);
        java.lang.String str37 = timePeriodValues32.getDescription();
        int int38 = timePeriodValues32.getMinStartIndex();
        int int39 = timePeriodValues32.getMaxEndIndex();
        timePeriodValues32.setDomainDescription("");
        int int42 = timePeriodValues32.getMaxMiddleIndex();
        timePeriodValues32.setNotify(true);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener45 = null;
        timePeriodValues32.removeChangeListener(seriesChangeListener45);
        int int47 = year24.compareTo((java.lang.Object) timePeriodValues32);
        boolean boolean48 = year8.equals((java.lang.Object) int47);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1562097599999L + "'", long14 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1546329600000L + "'", long30 == 1546329600000L);
        org.junit.Assert.assertNull(str37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 2019L);
        java.lang.Class<?> wildcardClass13 = year8.getClass();
        java.util.Calendar calendar14 = null;
        try {
            long long15 = year8.getFirstMillisecond(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues3.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener6);
        int int8 = timePeriodValues3.getItemCount();
        int int9 = timePeriodValues3.getMaxMiddleIndex();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year10, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year10, (java.lang.Number) 2019L);
        java.util.Date date15 = year10.getEnd();
        long long16 = year10.getFirstMillisecond();
        boolean boolean17 = day0.equals((java.lang.Object) long16);
        java.util.Calendar calendar18 = null;
        try {
            long long19 = day0.getFirstMillisecond(calendar18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1546329600000L + "'", long16 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

//    @Test
//    public void test280() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test280");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        int int2 = day0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
//        long long4 = regularTimePeriod3.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass5 = regularTimePeriod3.getClass();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 2019L);
        java.util.Date date13 = year8.getEnd();
        long long14 = year8.getFirstMillisecond();
        java.util.Calendar calendar15 = null;
        try {
            long long16 = year8.getLastMillisecond(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener13);
        int int15 = timePeriodValues10.getItemCount();
        int int16 = timePeriodValues10.getMaxMiddleIndex();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) year17, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 2019L);
        java.util.Date date22 = year17.getEnd();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date22, timeZone23);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod27 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) ' ');
        org.jfree.data.time.TimePeriodValues timePeriodValues29 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues29.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener32 = null;
        timePeriodValues29.removePropertyChangeListener(propertyChangeListener32);
        int int34 = timePeriodValues29.getItemCount();
        int int35 = timePeriodValues29.getMaxMiddleIndex();
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        timePeriodValues29.add((org.jfree.data.time.TimePeriod) year36, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue40 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year36, (java.lang.Number) 2019L);
        java.util.Date date41 = year36.getEnd();
        boolean boolean42 = simpleTimePeriod27.equals((java.lang.Object) date41);
        org.jfree.data.time.TimePeriodValues timePeriodValues44 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener45 = null;
        timePeriodValues44.addChangeListener(seriesChangeListener45);
        int int47 = timePeriodValues44.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass48 = timePeriodValues44.getClass();
        java.util.Date date49 = null;
        java.util.TimeZone timeZone50 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass48, date49, timeZone50);
        org.jfree.data.time.TimePeriodValues timePeriodValues53 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues53.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener56 = null;
        timePeriodValues53.removePropertyChangeListener(propertyChangeListener56);
        int int58 = timePeriodValues53.getItemCount();
        int int59 = timePeriodValues53.getMaxMiddleIndex();
        org.jfree.data.time.Year year60 = new org.jfree.data.time.Year();
        timePeriodValues53.add((org.jfree.data.time.TimePeriod) year60, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue64 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year60, (java.lang.Number) 2019L);
        java.util.Date date65 = year60.getEnd();
        java.util.TimeZone timeZone66 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass48, date65, timeZone66);
        org.jfree.data.time.TimePeriodValues timePeriodValues69 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues69.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener72 = null;
        timePeriodValues69.removePropertyChangeListener(propertyChangeListener72);
        int int74 = timePeriodValues69.getItemCount();
        int int75 = timePeriodValues69.getMaxMiddleIndex();
        org.jfree.data.time.Year year76 = new org.jfree.data.time.Year();
        timePeriodValues69.add((org.jfree.data.time.TimePeriod) year76, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue80 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year76, (java.lang.Number) 2019L);
        java.util.Date date81 = year76.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod82 = new org.jfree.data.time.SimpleTimePeriod(date65, date81);
        org.jfree.data.time.TimePeriodValues timePeriodValues84 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues84.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener87 = null;
        timePeriodValues84.removePropertyChangeListener(propertyChangeListener87);
        java.lang.String str89 = timePeriodValues84.getDescription();
        int int90 = timePeriodValues84.getMinStartIndex();
        timePeriodValues84.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues95 = timePeriodValues84.createCopy(0, 1);
        boolean boolean96 = simpleTimePeriod82.equals((java.lang.Object) 0);
        java.util.Date date97 = simpleTimePeriod82.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod98 = new org.jfree.data.time.SimpleTimePeriod(date41, date97);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod99 = new org.jfree.data.time.SimpleTimePeriod(date22, date97);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass48);
        org.junit.Assert.assertNull(regularTimePeriod51);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-1) + "'", int59 == (-1));
        org.junit.Assert.assertNotNull(date65);
        org.junit.Assert.assertNotNull(timeZone66);
        org.junit.Assert.assertNull(regularTimePeriod67);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 0 + "'", int74 == 0);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + (-1) + "'", int75 == (-1));
        org.junit.Assert.assertNotNull(date81);
        org.junit.Assert.assertNull(str89);
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + (-1) + "'", int90 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues95);
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + false + "'", boolean96 == false);
        org.junit.Assert.assertNotNull(date97);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMinEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = timePeriodValues1.createCopy(6, (int) (byte) 100);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener13);
        int int15 = timePeriodValues10.getItemCount();
        int int16 = timePeriodValues10.getMaxMiddleIndex();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) year17, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year17.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year17.previous();
        java.lang.Object obj24 = null;
        int int25 = year17.compareTo(obj24);
        timePeriodValues1.setKey((java.lang.Comparable) year17);
        try {
            timePeriodValues1.delete((int) '4', 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
    }

//    @Test
//    public void test284() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test284");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getMiddleMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate5 = day4.getSerialDate();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
//        boolean boolean7 = day0.equals((java.lang.Object) serialDate5);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(serialDate5);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(serialDate5);
//        org.jfree.data.time.SerialDate serialDate10 = day9.getSerialDate();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560452399999L + "'", long2 == 1560452399999L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(serialDate10);
//    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 2019L);
        java.util.Date date13 = year8.getEnd();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date13);
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date13, "13-June-2019", "31-December-2019");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
        timePeriodValues17.addChangeListener(seriesChangeListener18);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(date13);
    }

//    @Test
//    public void test286() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test286");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 1530561599999L);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 2019L);
        java.util.Date date13 = year8.getEnd();
        long long14 = year8.getMiddleMillisecond();
        java.lang.String str15 = year8.toString();
        java.util.Date date16 = year8.getEnd();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1562097599999L + "'", long14 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
        org.junit.Assert.assertNotNull(date16);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 100, "", "Time");
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        java.lang.String str2 = timePeriodValues1.getDescription();
        int int3 = timePeriodValues1.getItemCount();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year11, (java.lang.Number) 100);
        timePeriodValues1.add(timePeriodValue14);
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = timePeriodValues1.createCopy(7, 5);
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timePeriodValues18.addPropertyChangeListener(propertyChangeListener19);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2019L + "'", long12 == 2019L);
        org.junit.Assert.assertNotNull(timePeriodValues18);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(9, (-1), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMinEndIndex();
        java.lang.String str6 = timePeriodValues1.getRangeDescription();
        try {
            timePeriodValues1.update((int) (byte) -1, (java.lang.Number) 43629L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Value" + "'", str6.equals("Value"));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        java.lang.Comparable comparable0 = null;
        try {
            org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues(comparable0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 100);
        java.lang.Object obj4 = timePeriodValue3.clone();
        java.lang.String str5 = timePeriodValue3.toString();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getSerialIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues9.setNotify(true);
        boolean boolean13 = timePeriodValues9.equals((java.lang.Object) (short) 0);
        boolean boolean14 = year6.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues16.setNotify(true);
        timePeriodValues16.setKey((java.lang.Comparable) 100L);
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues22.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener25 = null;
        timePeriodValues22.removePropertyChangeListener(propertyChangeListener25);
        int int27 = timePeriodValues22.getItemCount();
        int int28 = timePeriodValues22.getMaxMiddleIndex();
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
        timePeriodValues22.add((org.jfree.data.time.TimePeriod) year29, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue33 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year29, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = year29.previous();
        timePeriodValues16.setKey((java.lang.Comparable) year29);
        int int36 = year6.compareTo((java.lang.Object) year29);
        java.lang.String str37 = year6.toString();
        java.lang.Object obj38 = null;
        boolean boolean39 = year6.equals(obj38);
        java.util.Date date40 = year6.getStart();
        boolean boolean41 = timePeriodValue3.equals((java.lang.Object) date40);
        java.lang.String str42 = timePeriodValue3.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "TimePeriodValue[2019,100]" + "'", str5.equals("TimePeriodValue[2019,100]"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "2019" + "'", str37.equals("2019"));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "TimePeriodValue[2019,100]" + "'", str42.equals("TimePeriodValue[2019,100]"));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        try {
            org.jfree.data.time.TimePeriod timePeriod7 = timePeriodValues1.getTimePeriod((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year8.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year8.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year8.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (double) 1577779200000L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        timePeriodValues1.setKey((java.lang.Comparable) "hi!");
        timePeriodValues1.setDescription("Value");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener8);
        timePeriodValues1.setRangeDescription("31-December-2019");
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue13 = timePeriodValues1.getDataItem((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.next();
        java.util.Date date3 = day0.getEnd();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = day0.getMiddleMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
    }

//    @Test
//    public void test299() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test299");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass1 = day0.getClass();
//        int int2 = day0.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 8);
//        java.lang.String str5 = timePeriodValue4.toString();
//        java.lang.String str6 = timePeriodValue4.toString();
//        org.junit.Assert.assertNotNull(wildcardClass1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "TimePeriodValue[13-June-2019,8.0]" + "'", str5.equals("TimePeriodValue[13-June-2019,8.0]"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "TimePeriodValue[13-June-2019,8.0]" + "'", str6.equals("TimePeriodValue[13-June-2019,8.0]"));
//    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 2019L);
        java.util.Date date13 = year8.getEnd();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date13);
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date13, timeZone15);
        long long17 = day16.getSerialIndex();
        java.util.Date date18 = day16.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day16.previous();
        java.lang.String str20 = day16.toString();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 43830L + "'", long17 == 43830L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "31-December-2019" + "'", str20.equals("31-December-2019"));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("31-December-2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1.0f);
        java.lang.Comparable comparable2 = timePeriodValues1.getKey();
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 1.0f + "'", comparable2.equals(1.0f));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues3.setNotify(true);
        boolean boolean7 = timePeriodValues3.equals((java.lang.Object) (short) 0);
        boolean boolean8 = year0.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        timePeriodValues10.setKey((java.lang.Comparable) 100L);
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues16.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timePeriodValues16.removePropertyChangeListener(propertyChangeListener19);
        int int21 = timePeriodValues16.getItemCount();
        int int22 = timePeriodValues16.getMaxMiddleIndex();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        timePeriodValues16.add((org.jfree.data.time.TimePeriod) year23, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue27 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year23, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year23.previous();
        timePeriodValues10.setKey((java.lang.Comparable) year23);
        int int30 = year0.compareTo((java.lang.Object) year23);
        java.lang.String str31 = year0.toString();
        java.lang.Object obj32 = null;
        boolean boolean33 = year0.equals(obj32);
        long long34 = year0.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "2019" + "'", str31.equals("2019"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1546329600000L + "'", long34 == 1546329600000L);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener13);
        int int15 = timePeriodValues10.getItemCount();
        int int16 = timePeriodValues10.getMaxMiddleIndex();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) year17, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 2019L);
        java.util.Date date22 = year17.getEnd();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date22, timeZone23);
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues26.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timePeriodValues26.removePropertyChangeListener(propertyChangeListener29);
        int int31 = timePeriodValues26.getItemCount();
        int int32 = timePeriodValues26.getMaxMiddleIndex();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        timePeriodValues26.add((org.jfree.data.time.TimePeriod) year33, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue37 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year33, (java.lang.Number) 2019L);
        java.util.Date date38 = year33.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(date22, date38);
        org.jfree.data.time.TimePeriodValues timePeriodValues41 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        boolean boolean42 = timePeriodValues41.getNotify();
        java.beans.PropertyChangeListener propertyChangeListener43 = null;
        timePeriodValues41.addPropertyChangeListener(propertyChangeListener43);
        timePeriodValues41.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesChangeEvent[source=0]");
        boolean boolean47 = simpleTimePeriod39.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesChangeEvent[source=0]");
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMinEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = timePeriodValues1.createCopy(6, (int) (byte) 100);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener13);
        int int15 = timePeriodValues10.getItemCount();
        int int16 = timePeriodValues10.getMaxMiddleIndex();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) year17, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year17.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year17.previous();
        java.lang.Object obj24 = null;
        int int25 = year17.compareTo(obj24);
        timePeriodValues1.setKey((java.lang.Comparable) year17);
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue28 = timePeriodValues1.getDataItem(12);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 12, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(10, 8, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener11);
        java.lang.String str13 = timePeriodValues1.getDomainDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues15.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timePeriodValues15.removePropertyChangeListener(propertyChangeListener18);
        java.lang.String str20 = timePeriodValues15.getDescription();
        int int21 = timePeriodValues15.getMinStartIndex();
        timePeriodValues15.fireSeriesChanged();
        boolean boolean23 = timePeriodValues1.equals((java.lang.Object) timePeriodValues15);
        int int24 = timePeriodValues1.getMaxMiddleIndex();
        int int25 = timePeriodValues1.getItemCount();
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = timePeriodValues1.createCopy(2019, 1);
        boolean boolean29 = timePeriodValues28.getNotify();
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(timePeriodValues28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        java.lang.Object obj2 = null;
        boolean boolean3 = day0.equals(obj2);
        java.lang.Object obj4 = null;
        boolean boolean5 = day0.equals(obj4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day0.next();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

//    @Test
//    public void test309() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test309");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.next();
//        long long3 = day0.getFirstMillisecond();
//        int int4 = day0.getYear();
//        long long5 = day0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560409200000L + "'", long5 == 1560409200000L);
//    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMinEndIndex();
        java.lang.String str6 = timePeriodValues1.getRangeDescription();
        int int7 = timePeriodValues1.getMinEndIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Value" + "'", str6.equals("Value"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        int int11 = timePeriodValues1.getMaxEndIndex();
        boolean boolean13 = timePeriodValues1.equals((java.lang.Object) (-1L));
        timePeriodValues1.delete(0, (-1));
        try {
            timePeriodValues1.update(10, (java.lang.Number) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year8.previous();
        java.lang.String str14 = year8.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year8.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 100.0f);
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener20 = null;
        timePeriodValues19.addChangeListener(seriesChangeListener20);
        int int22 = timePeriodValues19.getMinMiddleIndex();
        int int23 = timePeriodValues19.getMinEndIndex();
        java.lang.String str24 = timePeriodValues19.getRangeDescription();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        long long26 = year25.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year25.previous();
        timePeriodValues19.add((org.jfree.data.time.TimePeriod) regularTimePeriod27, (java.lang.Number) 6);
        boolean boolean30 = timePeriodValues19.getNotify();
        int int31 = year8.compareTo((java.lang.Object) timePeriodValues19);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019" + "'", str14.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Value" + "'", str24.equals("Value"));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 2019L + "'", long26 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues3.setNotify(true);
        boolean boolean7 = timePeriodValues3.equals((java.lang.Object) (short) 0);
        boolean boolean8 = year0.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        timePeriodValues10.setKey((java.lang.Comparable) 100L);
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues16.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timePeriodValues16.removePropertyChangeListener(propertyChangeListener19);
        int int21 = timePeriodValues16.getItemCount();
        int int22 = timePeriodValues16.getMaxMiddleIndex();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        timePeriodValues16.add((org.jfree.data.time.TimePeriod) year23, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue27 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year23, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year23.previous();
        timePeriodValues10.setKey((java.lang.Comparable) year23);
        int int30 = year0.compareTo((java.lang.Object) year23);
        java.lang.String str31 = year0.toString();
        long long32 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues34 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues34.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener37 = null;
        timePeriodValues34.removePropertyChangeListener(propertyChangeListener37);
        java.lang.String str39 = timePeriodValues34.getDescription();
        int int40 = timePeriodValues34.getMinStartIndex();
        int int41 = timePeriodValues34.getMaxEndIndex();
        timePeriodValues34.setDomainDescription("");
        int int44 = timePeriodValues34.getMaxEndIndex();
        java.lang.String str45 = timePeriodValues34.getRangeDescription();
        java.lang.Class<?> wildcardClass46 = timePeriodValues34.getClass();
        boolean boolean47 = year0.equals((java.lang.Object) timePeriodValues34);
        long long48 = year0.getSerialIndex();
        java.util.Calendar calendar49 = null;
        try {
            long long50 = year0.getMiddleMillisecond(calendar49);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "2019" + "'", str31.equals("2019"));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 2019L + "'", long32 == 2019L);
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "Value" + "'", str45.equals("Value"));
        org.junit.Assert.assertNotNull(wildcardClass46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 2019L + "'", long48 == 2019L);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "2019");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDescription("31-December-2019");
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (java.lang.Number) 100);
        java.util.Date date11 = year7.getStart();
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (java.lang.Number) (short) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year7.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod14, (java.lang.Number) (-1));
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year17.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod19, (double) 10.0f);
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue23 = timePeriodValues1.getDataItem(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2019L + "'", long18 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year8.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year8.previous();
        java.lang.Object obj15 = null;
        int int16 = year8.compareTo(obj15);
        java.lang.Number number17 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue18 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, number17);
        java.util.Calendar calendar19 = null;
        try {
            long long20 = year8.getFirstMillisecond(calendar19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass1 = day0.getClass();
        int int2 = day0.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 8);
        java.lang.Number number5 = timePeriodValue4.getValue();
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 8.0d + "'", number5.equals(8.0d));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener13);
        int int15 = timePeriodValues10.getItemCount();
        int int16 = timePeriodValues10.getMaxMiddleIndex();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) year17, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 2019L);
        java.util.Date date22 = year17.getEnd();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date22, timeZone23);
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues26.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timePeriodValues26.removePropertyChangeListener(propertyChangeListener29);
        int int31 = timePeriodValues26.getItemCount();
        int int32 = timePeriodValues26.getMaxMiddleIndex();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        timePeriodValues26.add((org.jfree.data.time.TimePeriod) year33, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue37 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year33, (java.lang.Number) 2019L);
        java.util.Date date38 = year33.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(date22, date38);
        java.util.Date date40 = simpleTimePeriod39.getEnd();
        java.util.Date date41 = simpleTimePeriod39.getEnd();
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
        long long43 = year42.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue45 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year42, (java.lang.Number) 100);
        java.util.Date date46 = year42.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues48 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener49 = null;
        timePeriodValues48.addChangeListener(seriesChangeListener49);
        int int51 = timePeriodValues48.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass52 = timePeriodValues48.getClass();
        java.util.Date date53 = null;
        java.util.TimeZone timeZone54 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass52, date53, timeZone54);
        org.jfree.data.time.TimePeriodValues timePeriodValues57 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues57.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener60 = null;
        timePeriodValues57.removePropertyChangeListener(propertyChangeListener60);
        int int62 = timePeriodValues57.getItemCount();
        int int63 = timePeriodValues57.getMaxMiddleIndex();
        org.jfree.data.time.Year year64 = new org.jfree.data.time.Year();
        timePeriodValues57.add((org.jfree.data.time.TimePeriod) year64, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue68 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year64, (java.lang.Number) 2019L);
        java.util.Date date69 = year64.getEnd();
        java.util.TimeZone timeZone70 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass52, date69, timeZone70);
        org.jfree.data.time.Year year72 = new org.jfree.data.time.Year(date46, timeZone70);
        org.jfree.data.time.TimePeriodValues timePeriodValues74 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener75 = null;
        timePeriodValues74.addChangeListener(seriesChangeListener75);
        int int77 = timePeriodValues74.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass78 = timePeriodValues74.getClass();
        java.util.Date date79 = null;
        java.util.TimeZone timeZone80 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass78, date79, timeZone80);
        org.jfree.data.time.TimePeriodValues timePeriodValues83 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues83.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener86 = null;
        timePeriodValues83.removePropertyChangeListener(propertyChangeListener86);
        int int88 = timePeriodValues83.getItemCount();
        int int89 = timePeriodValues83.getMaxMiddleIndex();
        org.jfree.data.time.Year year90 = new org.jfree.data.time.Year();
        timePeriodValues83.add((org.jfree.data.time.TimePeriod) year90, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue94 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year90, (java.lang.Number) 2019L);
        java.util.Date date95 = year90.getEnd();
        java.util.TimeZone timeZone96 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod97 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass78, date95, timeZone96);
        org.jfree.data.time.Year year98 = new org.jfree.data.time.Year(date46, timeZone96);
        org.jfree.data.time.Year year99 = new org.jfree.data.time.Year(date41, timeZone96);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 2019L + "'", long43 == 2019L);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1) + "'", int51 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass52);
        org.junit.Assert.assertNull(regularTimePeriod55);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-1) + "'", int63 == (-1));
        org.junit.Assert.assertNotNull(date69);
        org.junit.Assert.assertNotNull(timeZone70);
        org.junit.Assert.assertNull(regularTimePeriod71);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + (-1) + "'", int77 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass78);
        org.junit.Assert.assertNull(regularTimePeriod81);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 0 + "'", int88 == 0);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + (-1) + "'", int89 == (-1));
        org.junit.Assert.assertNotNull(date95);
        org.junit.Assert.assertNotNull(timeZone96);
        org.junit.Assert.assertNull(regularTimePeriod97);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year8.previous();
        java.lang.String str14 = year8.toString();
        long long15 = year8.getFirstMillisecond();
        java.util.Calendar calendar16 = null;
        try {
            long long17 = year8.getLastMillisecond(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019" + "'", str14.equals("2019"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1546329600000L + "'", long15 == 1546329600000L);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("TimePeriodValue[13-June-2019,8.0]");
        org.junit.Assert.assertNull(day1);
    }

//    @Test
//    public void test320() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test320");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        java.lang.Object obj2 = null;
//        boolean boolean3 = day0.equals(obj2);
//        long long4 = day0.getLastMillisecond();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560495599999L + "'", long4 == 1560495599999L);
//    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.general.SeriesChangeEvent[source=0]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test322() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test322");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        timePeriodValues1.setNotify(true);
//        timePeriodValues1.setKey((java.lang.Comparable) 100L);
//        timePeriodValues1.setKey((java.lang.Comparable) (short) 100);
//        java.lang.String str8 = timePeriodValues1.getRangeDescription();
//        int int9 = timePeriodValues1.getMinStartIndex();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
//        timePeriodValues1.removeChangeListener(seriesChangeListener10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        int int13 = day12.getMonth();
//        long long14 = day12.getMiddleMillisecond();
//        org.jfree.data.time.SerialDate serialDate15 = day12.getSerialDate();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate17 = day16.getSerialDate();
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(serialDate17);
//        boolean boolean19 = day12.equals((java.lang.Object) serialDate17);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(serialDate17);
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day20, (java.lang.Number) 0);
//        int int23 = timePeriodValues1.getMinStartIndex();
//        timePeriodValues1.setNotify(false);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Value" + "'", str8.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560452399999L + "'", long14 == 1560452399999L);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) 0, 11, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener11);
        java.lang.String str13 = timePeriodValues1.getDomainDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues15.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timePeriodValues15.removePropertyChangeListener(propertyChangeListener18);
        java.lang.String str20 = timePeriodValues15.getDescription();
        int int21 = timePeriodValues15.getMinStartIndex();
        timePeriodValues15.fireSeriesChanged();
        boolean boolean23 = timePeriodValues1.equals((java.lang.Object) timePeriodValues15);
        int int24 = timePeriodValues1.getMaxStartIndex();
        java.lang.Comparable comparable25 = timePeriodValues1.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues27 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        boolean boolean28 = timePeriodValues27.getNotify();
        timePeriodValues27.setDomainDescription("Value");
        boolean boolean31 = timePeriodValues1.equals((java.lang.Object) "Value");
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + comparable25 + "' != '" + (byte) 1 + "'", comparable25.equals((byte) 1));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

//    @Test
//    public void test325() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test325");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getMiddleMillisecond();
//        long long3 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = day5.getFirstMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560452399999L + "'", long2 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate4);
//    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        int int2 = year0.getYear();
        java.util.Date date3 = year0.getEnd();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1.0f);
        timePeriodValues1.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=0]");
        timePeriodValues1.delete((int) (short) 10, 7);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener11);
        java.lang.String str13 = timePeriodValues1.getDomainDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues15.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timePeriodValues15.removePropertyChangeListener(propertyChangeListener18);
        java.lang.String str20 = timePeriodValues15.getDescription();
        int int21 = timePeriodValues15.getMinStartIndex();
        timePeriodValues15.fireSeriesChanged();
        boolean boolean23 = timePeriodValues1.equals((java.lang.Object) timePeriodValues15);
        int int24 = timePeriodValues15.getMaxMiddleIndex();
        int int25 = timePeriodValues15.getMaxEndIndex();
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        java.util.Date date0 = null;
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        long long2 = year1.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year1, (java.lang.Number) 100);
        java.util.Date date5 = year1.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues7.addChangeListener(seriesChangeListener8);
        int int10 = timePeriodValues7.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass11 = timePeriodValues7.getClass();
        java.util.Date date12 = null;
        java.util.TimeZone timeZone13 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date12, timeZone13);
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues16.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timePeriodValues16.removePropertyChangeListener(propertyChangeListener19);
        int int21 = timePeriodValues16.getItemCount();
        int int22 = timePeriodValues16.getMaxMiddleIndex();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        timePeriodValues16.add((org.jfree.data.time.TimePeriod) year23, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue27 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year23, (java.lang.Number) 2019L);
        java.util.Date date28 = year23.getEnd();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date28, timeZone29);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date5, timeZone29);
        org.jfree.data.time.TimePeriodValues timePeriodValues33 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener34 = null;
        timePeriodValues33.addChangeListener(seriesChangeListener34);
        int int36 = timePeriodValues33.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass37 = timePeriodValues33.getClass();
        java.util.Date date38 = null;
        java.util.TimeZone timeZone39 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass37, date38, timeZone39);
        org.jfree.data.time.TimePeriodValues timePeriodValues42 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues42.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener45 = null;
        timePeriodValues42.removePropertyChangeListener(propertyChangeListener45);
        int int47 = timePeriodValues42.getItemCount();
        int int48 = timePeriodValues42.getMaxMiddleIndex();
        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year();
        timePeriodValues42.add((org.jfree.data.time.TimePeriod) year49, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue53 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year49, (java.lang.Number) 2019L);
        java.util.Date date54 = year49.getEnd();
        java.util.TimeZone timeZone55 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass37, date54, timeZone55);
        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year(date5, timeZone55);
        try {
            org.jfree.data.time.Year year58 = new org.jfree.data.time.Year(date0, timeZone55);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertNull(regularTimePeriod40);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertNotNull(timeZone55);
        org.junit.Assert.assertNull(regularTimePeriod56);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 4, "13-June-2019", "");
        int int4 = timePeriodValues3.getItemCount();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        int int2 = year0.getYear();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        long long4 = year3.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year3, (java.lang.Number) 100);
        timePeriodValue6.setValue((java.lang.Number) 3);
        org.jfree.data.time.TimePeriod timePeriod9 = timePeriodValue6.getPeriod();
        java.lang.Object obj10 = timePeriodValue6.clone();
        int int11 = year0.compareTo((java.lang.Object) timePeriodValue6);
        int int12 = year0.getYear();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertNotNull(timePeriod9);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "2019");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues5.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues5.removePropertyChangeListener(propertyChangeListener8);
        int int10 = timePeriodValues5.getItemCount();
        int int11 = timePeriodValues5.getMaxMiddleIndex();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        timePeriodValues5.add((org.jfree.data.time.TimePeriod) year12, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year12, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year12.previous();
        java.lang.String str18 = year12.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year12.next();
        java.lang.Number number20 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod19, number20);
        timePeriodValues1.add(timePeriodValue21);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "2019" + "'", str18.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod19);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener13);
        int int15 = timePeriodValues10.getItemCount();
        int int16 = timePeriodValues10.getMaxMiddleIndex();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) year17, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 2019L);
        java.util.Date date22 = year17.getEnd();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date22, timeZone23);
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues26.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timePeriodValues26.removePropertyChangeListener(propertyChangeListener29);
        int int31 = timePeriodValues26.getItemCount();
        int int32 = timePeriodValues26.getMaxMiddleIndex();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        timePeriodValues26.add((org.jfree.data.time.TimePeriod) year33, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue37 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year33, (java.lang.Number) 2019L);
        java.util.Date date38 = year33.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(date22, date38);
        org.jfree.data.time.TimePeriodValues timePeriodValues41 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues41.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener44 = null;
        timePeriodValues41.removePropertyChangeListener(propertyChangeListener44);
        java.lang.String str46 = timePeriodValues41.getDescription();
        int int47 = timePeriodValues41.getMinStartIndex();
        timePeriodValues41.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues52 = timePeriodValues41.createCopy(0, 1);
        boolean boolean53 = simpleTimePeriod39.equals((java.lang.Object) 0);
        java.util.Date date54 = simpleTimePeriod39.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues56 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues56.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener59 = null;
        timePeriodValues56.removePropertyChangeListener(propertyChangeListener59);
        int int61 = timePeriodValues56.getItemCount();
        int int62 = timePeriodValues56.getMaxMiddleIndex();
        org.jfree.data.time.Year year63 = new org.jfree.data.time.Year();
        timePeriodValues56.add((org.jfree.data.time.TimePeriod) year63, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue67 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year63, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = year63.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = year63.previous();
        int int70 = simpleTimePeriod39.compareTo((java.lang.Object) regularTimePeriod69);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent71 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) int70);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNull(str46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-1) + "'", int62 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod68);
        org.junit.Assert.assertNotNull(regularTimePeriod69);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 1 + "'", int70 == 1);
    }

//    @Test
//    public void test334() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test334");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        timePeriodValues1.setNotify(true);
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
//        int int6 = timePeriodValues1.getItemCount();
//        int int7 = timePeriodValues1.getMaxMiddleIndex();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
//        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 2019L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year8.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year8.previous();
//        java.lang.Object obj15 = null;
//        int int16 = year8.compareTo(obj15);
//        java.lang.Number number17 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue18 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, number17);
//        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (double) 1593676799999L);
//        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        timePeriodValues22.setNotify(true);
//        timePeriodValues22.setKey((java.lang.Comparable) 100L);
//        timePeriodValues22.setKey((java.lang.Comparable) (short) 100);
//        java.lang.String str29 = timePeriodValues22.getRangeDescription();
//        int int30 = timePeriodValues22.getMinStartIndex();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener31 = null;
//        timePeriodValues22.removeChangeListener(seriesChangeListener31);
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        int int34 = day33.getMonth();
//        long long35 = day33.getMiddleMillisecond();
//        org.jfree.data.time.SerialDate serialDate36 = day33.getSerialDate();
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate38 = day37.getSerialDate();
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(serialDate38);
//        boolean boolean40 = day33.equals((java.lang.Object) serialDate38);
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(serialDate38);
//        timePeriodValues22.add((org.jfree.data.time.TimePeriod) day41, (java.lang.Number) 0);
//        int int44 = timePeriodValues22.getMinStartIndex();
//        boolean boolean45 = timePeriodValue20.equals((java.lang.Object) timePeriodValues22);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Value" + "'", str29.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 6 + "'", int34 == 6);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560452399999L + "'", long35 == 1560452399999L);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertNotNull(serialDate38);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        timePeriodValues1.setNotify(true);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener10);
        java.lang.Class<?> wildcardClass12 = timePeriodValues1.getClass();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year13, (java.lang.Number) 100);
        java.util.Date date17 = year13.getStart();
        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year13, (java.lang.Number) (short) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year13.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod20, (java.lang.Number) 1577779200000L);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2019L + "'", long14 == 2019L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass1 = day0.getClass();
        int int2 = day0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.next();
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("2019");
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 100.0f, "", "31-December-2019");
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        timePeriodValues1.setKey((java.lang.Comparable) 100L);
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues7.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues7.removePropertyChangeListener(propertyChangeListener10);
        int int12 = timePeriodValues7.getItemCount();
        int int13 = timePeriodValues7.getMaxMiddleIndex();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        timePeriodValues7.add((org.jfree.data.time.TimePeriod) year14, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue18 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year14.previous();
        timePeriodValues1.setKey((java.lang.Comparable) year14);
        java.lang.String str21 = year14.toString();
        java.util.Calendar calendar22 = null;
        try {
            year14.peg(calendar22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2019" + "'", str21.equals("2019"));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(1560495599999L, 1530561599999L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues7.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues7.removePropertyChangeListener(propertyChangeListener10);
        int int12 = timePeriodValues7.getItemCount();
        int int13 = timePeriodValues7.getMaxMiddleIndex();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        timePeriodValues7.add((org.jfree.data.time.TimePeriod) year14, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue18 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year14.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod19, (double) 2019L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener22 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener22);
        java.lang.String str24 = timePeriodValues1.getRangeDescription();
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Value" + "'", str24.equals("Value"));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener13);
        int int15 = timePeriodValues10.getItemCount();
        int int16 = timePeriodValues10.getMaxMiddleIndex();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) year17, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 2019L);
        java.util.Date date22 = year17.getEnd();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date22, timeZone23);
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues26.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timePeriodValues26.removePropertyChangeListener(propertyChangeListener29);
        int int31 = timePeriodValues26.getItemCount();
        int int32 = timePeriodValues26.getMaxMiddleIndex();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        timePeriodValues26.add((org.jfree.data.time.TimePeriod) year33, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue37 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year33, (java.lang.Number) 2019L);
        java.util.Date date38 = year33.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(date22, date38);
        long long40 = simpleTimePeriod39.getEndMillis();
        long long41 = simpleTimePeriod39.getStartMillis();
        boolean boolean43 = simpleTimePeriod39.equals((java.lang.Object) 0);
        java.util.Date date44 = simpleTimePeriod39.getStart();
        long long45 = simpleTimePeriod39.getStartMillis();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1577865599999L + "'", long40 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1577865599999L + "'", long41 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1577865599999L + "'", long45 == 1577865599999L);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener13);
        int int15 = timePeriodValues10.getItemCount();
        int int16 = timePeriodValues10.getMaxMiddleIndex();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) year17, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 2019L);
        java.util.Date date22 = year17.getEnd();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date22, timeZone23);
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues26.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timePeriodValues26.removePropertyChangeListener(propertyChangeListener29);
        int int31 = timePeriodValues26.getItemCount();
        int int32 = timePeriodValues26.getMaxMiddleIndex();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        timePeriodValues26.add((org.jfree.data.time.TimePeriod) year33, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue37 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year33, (java.lang.Number) 2019L);
        java.util.Date date38 = year33.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(date22, date38);
        long long40 = simpleTimePeriod39.getEndMillis();
        long long41 = simpleTimePeriod39.getStartMillis();
        boolean boolean43 = simpleTimePeriod39.equals((java.lang.Object) 0);
        java.util.Date date44 = simpleTimePeriod39.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues46 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener47 = null;
        timePeriodValues46.addChangeListener(seriesChangeListener47);
        int int49 = timePeriodValues46.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass50 = timePeriodValues46.getClass();
        java.util.Date date51 = null;
        java.util.TimeZone timeZone52 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass50, date51, timeZone52);
        org.jfree.data.time.TimePeriodValues timePeriodValues55 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues55.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener58 = null;
        timePeriodValues55.removePropertyChangeListener(propertyChangeListener58);
        int int60 = timePeriodValues55.getItemCount();
        int int61 = timePeriodValues55.getMaxMiddleIndex();
        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year();
        timePeriodValues55.add((org.jfree.data.time.TimePeriod) year62, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue66 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year62, (java.lang.Number) 2019L);
        java.util.Date date67 = year62.getEnd();
        java.util.TimeZone timeZone68 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass50, date67, timeZone68);
        org.jfree.data.time.TimePeriodValues timePeriodValues71 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues71.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener74 = null;
        timePeriodValues71.removePropertyChangeListener(propertyChangeListener74);
        int int76 = timePeriodValues71.getItemCount();
        int int77 = timePeriodValues71.getMaxMiddleIndex();
        org.jfree.data.time.Year year78 = new org.jfree.data.time.Year();
        timePeriodValues71.add((org.jfree.data.time.TimePeriod) year78, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue82 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year78, (java.lang.Number) 2019L);
        java.util.Date date83 = year78.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod84 = new org.jfree.data.time.SimpleTimePeriod(date67, date83);
        java.util.TimeZone timeZone85 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year86 = new org.jfree.data.time.Year(date67, timeZone85);
        boolean boolean87 = simpleTimePeriod39.equals((java.lang.Object) date67);
        long long88 = simpleTimePeriod39.getEndMillis();
        java.util.Date date89 = simpleTimePeriod39.getStart();
        long long90 = simpleTimePeriod39.getEndMillis();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1577865599999L + "'", long40 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1577865599999L + "'", long41 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertNull(regularTimePeriod53);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
        org.junit.Assert.assertNotNull(date67);
        org.junit.Assert.assertNotNull(timeZone68);
        org.junit.Assert.assertNull(regularTimePeriod69);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 0 + "'", int76 == 0);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + (-1) + "'", int77 == (-1));
        org.junit.Assert.assertNotNull(date83);
        org.junit.Assert.assertNotNull(timeZone85);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertTrue("'" + long88 + "' != '" + 1577865599999L + "'", long88 == 1577865599999L);
        org.junit.Assert.assertNotNull(date89);
        org.junit.Assert.assertTrue("'" + long90 + "' != '" + 1577865599999L + "'", long90 == 1577865599999L);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMinEndIndex();
        boolean boolean6 = timePeriodValues1.isEmpty();
        boolean boolean7 = timePeriodValues1.getNotify();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener8);
        try {
            timePeriodValues1.update((int) (short) 1, (java.lang.Number) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        java.lang.Object obj2 = null;
        boolean boolean3 = day0.equals(obj2);
        java.lang.Object obj4 = null;
        boolean boolean5 = day0.equals(obj4);
        java.util.Date date6 = day0.getStart();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(date6);
    }

//    @Test
//    public void test346() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test346");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 0L);
//        int int3 = day0.getYear();
//        java.lang.String str4 = day0.toString();
//        int int5 = day0.getDayOfMonth();
//        int int6 = day0.getMonth();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) day0);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "13-June-2019" + "'", str4.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        int int11 = timePeriodValues1.getMaxEndIndex();
        java.lang.String str12 = timePeriodValues1.getRangeDescription();
        java.lang.Class<?> wildcardClass13 = timePeriodValues1.getClass();
        java.lang.Class<?> wildcardClass14 = timePeriodValues1.getClass();
        java.lang.String str15 = timePeriodValues1.getDomainDescription();
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Value" + "'", str12.equals("Value"));
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues7.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues7.removePropertyChangeListener(propertyChangeListener10);
        int int12 = timePeriodValues7.getItemCount();
        int int13 = timePeriodValues7.getMaxMiddleIndex();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        timePeriodValues7.add((org.jfree.data.time.TimePeriod) year14, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue18 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year14.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod19, (double) 2019L);
        int int22 = timePeriodValues1.getMinEndIndex();
        int int23 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setNotify(false);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate27 = day26.getSerialDate();
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(serialDate27);
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(serialDate27);
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(serialDate27);
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(serialDate27);
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(serialDate27);
        boolean boolean33 = timePeriodValues1.equals((java.lang.Object) day32);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.data.time.TimePeriod timePeriod0 = null;
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue(timePeriod0, (double) 1560365999999L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year8.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year8.previous();
        java.lang.Object obj15 = null;
        int int16 = year8.compareTo(obj15);
        java.lang.Number number17 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue18 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, number17);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        long long20 = year19.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue22 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year19, (java.lang.Number) 100);
        java.util.Date date23 = year19.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener26 = null;
        timePeriodValues25.addChangeListener(seriesChangeListener26);
        int int28 = timePeriodValues25.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass29 = timePeriodValues25.getClass();
        java.util.Date date30 = null;
        java.util.TimeZone timeZone31 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass29, date30, timeZone31);
        org.jfree.data.time.TimePeriodValues timePeriodValues34 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues34.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener37 = null;
        timePeriodValues34.removePropertyChangeListener(propertyChangeListener37);
        int int39 = timePeriodValues34.getItemCount();
        int int40 = timePeriodValues34.getMaxMiddleIndex();
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
        timePeriodValues34.add((org.jfree.data.time.TimePeriod) year41, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue45 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year41, (java.lang.Number) 2019L);
        java.util.Date date46 = year41.getEnd();
        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass29, date46, timeZone47);
        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year(date23, timeZone47);
        org.jfree.data.time.TimePeriodValues timePeriodValues51 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener52 = null;
        timePeriodValues51.addChangeListener(seriesChangeListener52);
        int int54 = timePeriodValues51.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass55 = timePeriodValues51.getClass();
        java.util.Date date56 = null;
        java.util.TimeZone timeZone57 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass55, date56, timeZone57);
        org.jfree.data.time.TimePeriodValues timePeriodValues60 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues60.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener63 = null;
        timePeriodValues60.removePropertyChangeListener(propertyChangeListener63);
        int int65 = timePeriodValues60.getItemCount();
        int int66 = timePeriodValues60.getMaxMiddleIndex();
        org.jfree.data.time.Year year67 = new org.jfree.data.time.Year();
        timePeriodValues60.add((org.jfree.data.time.TimePeriod) year67, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue71 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year67, (java.lang.Number) 2019L);
        java.util.Date date72 = year67.getEnd();
        java.util.TimeZone timeZone73 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass55, date72, timeZone73);
        org.jfree.data.time.Year year75 = new org.jfree.data.time.Year(date23, timeZone73);
        boolean boolean76 = timePeriodValue18.equals((java.lang.Object) date23);
        org.jfree.data.time.TimePeriod timePeriod77 = timePeriodValue18.getPeriod();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 2019L + "'", long20 == 2019L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertNull(regularTimePeriod32);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(timeZone47);
        org.junit.Assert.assertNull(regularTimePeriod48);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1) + "'", int54 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass55);
        org.junit.Assert.assertNull(regularTimePeriod58);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + (-1) + "'", int66 == (-1));
        org.junit.Assert.assertNotNull(date72);
        org.junit.Assert.assertNotNull(timeZone73);
        org.junit.Assert.assertNull(regularTimePeriod74);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(timePeriod77);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        timePeriodValues1.setKey((java.lang.Comparable) 100L);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year6, (java.lang.Number) 100);
        java.lang.String str10 = timePeriodValue9.toString();
        boolean boolean12 = timePeriodValue9.equals((java.lang.Object) (short) 100);
        java.lang.Object obj13 = timePeriodValue9.clone();
        timePeriodValues1.add(timePeriodValue9);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "TimePeriodValue[2019,100]" + "'", str10.equals("TimePeriodValue[2019,100]"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(obj13);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timePeriodValues12.addChangeListener(seriesChangeListener13);
        int int15 = timePeriodValues12.getMinMiddleIndex();
        int int16 = timePeriodValues12.getMinEndIndex();
        java.lang.Object obj17 = timePeriodValues12.clone();
        java.lang.Class<?> wildcardClass18 = obj17.getClass();
        boolean boolean19 = timePeriodValues1.equals((java.lang.Object) wildcardClass18);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener11);
        int int13 = timePeriodValues1.getMaxStartIndex();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue15 = timePeriodValues1.getDataItem(12);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 12, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        int int11 = timePeriodValues1.getMaxMiddleIndex();
        timePeriodValues1.setNotify(true);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener14);
        int int16 = timePeriodValues1.getMaxMiddleIndex();
        timePeriodValues1.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesChangeEvent[source=0]");
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year8.previous();
        java.lang.String str14 = year8.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year8.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 100.0f);
        java.lang.String str18 = year8.toString();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019" + "'", str14.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "2019" + "'", str18.equals("2019"));
    }

//    @Test
//    public void test356() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test356");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.next();
//        java.util.Calendar calendar3 = null;
//        try {
//            day0.peg(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 1, (long) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test358() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test358");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        timePeriodValues1.setNotify(true);
//        timePeriodValues1.setKey((java.lang.Comparable) 100L);
//        timePeriodValues1.setKey((java.lang.Comparable) (short) 100);
//        java.lang.String str8 = timePeriodValues1.getRangeDescription();
//        int int9 = timePeriodValues1.getMinStartIndex();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
//        timePeriodValues1.removeChangeListener(seriesChangeListener10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        int int13 = day12.getMonth();
//        long long14 = day12.getMiddleMillisecond();
//        org.jfree.data.time.SerialDate serialDate15 = day12.getSerialDate();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate17 = day16.getSerialDate();
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(serialDate17);
//        boolean boolean19 = day12.equals((java.lang.Object) serialDate17);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(serialDate17);
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day20, (java.lang.Number) 0);
//        int int23 = day20.getDayOfMonth();
//        java.util.Calendar calendar24 = null;
//        try {
//            long long25 = day20.getLastMillisecond(calendar24);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Value" + "'", str8.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560452399999L + "'", long14 == 1560452399999L);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 13 + "'", int23 == 13);
//    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        timePeriodValues1.setNotify(true);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year10, (java.lang.Number) 100);
        java.lang.String str14 = timePeriodValue13.toString();
        timePeriodValues1.add(timePeriodValue13);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        long long17 = year16.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year16, (java.lang.Number) 100);
        java.util.Date date20 = year16.getStart();
        org.jfree.data.time.TimePeriodValue timePeriodValue22 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year16, (java.lang.Number) (short) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year16.previous();
        long long24 = year16.getSerialIndex();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year16, (java.lang.Number) 4);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent27 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) year16);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "TimePeriodValue[2019,100]" + "'", str14.equals("TimePeriodValue[2019,100]"));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2019L + "'", long17 == 2019L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 2019L + "'", long24 == 2019L);
    }

//    @Test
//    public void test360() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test360");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getMiddleMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(serialDate3);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.previous();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560452399999L + "'", long2 == 1560452399999L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMinEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues7.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues7.removePropertyChangeListener(propertyChangeListener10);
        java.lang.String str12 = timePeriodValues7.getDescription();
        int int13 = timePeriodValues7.getMinStartIndex();
        timePeriodValues7.setNotify(true);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        long long17 = year16.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year16, (java.lang.Number) 100);
        timePeriodValue19.setValue((java.lang.Number) 3);
        org.jfree.data.time.TimePeriod timePeriod22 = timePeriodValue19.getPeriod();
        timePeriodValues7.add(timePeriodValue19);
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues25.setNotify(true);
        timePeriodValues25.setKey((java.lang.Comparable) 100L);
        timePeriodValues25.setKey((java.lang.Comparable) (short) 100);
        java.lang.String str32 = timePeriodValues25.getRangeDescription();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        long long34 = year33.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue36 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year33, (java.lang.Number) 100);
        timePeriodValues25.add(timePeriodValue36);
        boolean boolean38 = timePeriodValue19.equals((java.lang.Object) timePeriodValues25);
        java.lang.String str39 = timePeriodValue19.toString();
        org.jfree.data.time.TimePeriodValues timePeriodValues41 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues41.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener44 = null;
        timePeriodValues41.removePropertyChangeListener(propertyChangeListener44);
        java.lang.String str46 = timePeriodValues41.getDescription();
        int int47 = timePeriodValues41.getMinStartIndex();
        int int48 = timePeriodValues41.getMaxEndIndex();
        timePeriodValues41.setDomainDescription("");
        int int51 = timePeriodValues41.getMaxEndIndex();
        boolean boolean53 = timePeriodValues41.equals((java.lang.Object) (-1L));
        boolean boolean54 = timePeriodValue19.equals((java.lang.Object) timePeriodValues41);
        boolean boolean55 = timePeriodValues1.equals((java.lang.Object) boolean54);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener56 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener56);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2019L + "'", long17 == 2019L);
        org.junit.Assert.assertNotNull(timePeriod22);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Value" + "'", str32.equals("Value"));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 2019L + "'", long34 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "TimePeriodValue[2019,3]" + "'", str39.equals("TimePeriodValue[2019,3]"));
        org.junit.Assert.assertNull(str46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1) + "'", int51 == (-1));
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.data.time.TimePeriod timePeriod0 = null;
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue(timePeriod0, (double) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        timePeriodValues1.setNotify(true);
        java.lang.Object obj8 = timePeriodValues1.clone();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener13);
        java.lang.String str15 = timePeriodValues10.getDescription();
        int int16 = timePeriodValues10.getMinStartIndex();
        timePeriodValues10.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = timePeriodValues10.createCopy(0, 1);
        int int22 = timePeriodValues10.getMaxMiddleIndex();
        boolean boolean23 = timePeriodValues1.equals((java.lang.Object) int22);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener13);
        int int15 = timePeriodValues10.getItemCount();
        int int16 = timePeriodValues10.getMaxMiddleIndex();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) year17, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 2019L);
        java.util.Date date22 = year17.getEnd();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date22, timeZone23);
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues26.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timePeriodValues26.removePropertyChangeListener(propertyChangeListener29);
        int int31 = timePeriodValues26.getItemCount();
        int int32 = timePeriodValues26.getMaxMiddleIndex();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        timePeriodValues26.add((org.jfree.data.time.TimePeriod) year33, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue37 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year33, (java.lang.Number) 2019L);
        java.util.Date date38 = year33.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(date22, date38);
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year(date22);
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date22);
        long long42 = day41.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1577779200000L + "'", long42 == 1577779200000L);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) -1, 9, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) ' ');
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (java.lang.Number) 6);
        long long5 = simpleTimePeriod2.getEndMillis();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 32L + "'", long5 == 32L);
    }

//    @Test
//    public void test367() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test367");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getMiddleMillisecond();
//        int int3 = day0.getMonth();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = day0.getFirstMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560452399999L + "'", long2 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 100);
        java.util.Date date4 = year0.getStart();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 11);
        int int7 = year0.getYear();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        timePeriodValues1.setNotify(true);
        java.lang.Comparable comparable8 = timePeriodValues1.getKey();
        boolean boolean9 = timePeriodValues1.getNotify();
        timePeriodValues1.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=4]");
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (byte) 1 + "'", comparable8.equals((byte) 1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

//    @Test
//    public void test370() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test370");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass1 = day0.getClass();
//        long long2 = day0.getLastMillisecond();
//        long long3 = day0.getSerialIndex();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = day0.getFirstMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560495599999L + "'", long2 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43629L + "'", long3 == 43629L);
//    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        int int11 = timePeriodValues1.getMaxMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener12);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        int int11 = timePeriodValues1.getMaxEndIndex();
        java.lang.String str12 = timePeriodValues1.getRangeDescription();
        timePeriodValues1.setKey((java.lang.Comparable) 7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener15);
        timePeriodValues1.setRangeDescription("");
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener21 = null;
        timePeriodValues20.addChangeListener(seriesChangeListener21);
        int int23 = timePeriodValues20.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass24 = timePeriodValues20.getClass();
        java.util.Date date25 = null;
        java.util.TimeZone timeZone26 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date25, timeZone26);
        org.jfree.data.time.TimePeriodValues timePeriodValues29 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues29.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener32 = null;
        timePeriodValues29.removePropertyChangeListener(propertyChangeListener32);
        int int34 = timePeriodValues29.getItemCount();
        int int35 = timePeriodValues29.getMaxMiddleIndex();
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        timePeriodValues29.add((org.jfree.data.time.TimePeriod) year36, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue40 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year36, (java.lang.Number) 2019L);
        java.util.Date date41 = year36.getEnd();
        java.util.TimeZone timeZone42 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date41, timeZone42);
        org.jfree.data.time.TimePeriodValues timePeriodValues45 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues45.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener48 = null;
        timePeriodValues45.removePropertyChangeListener(propertyChangeListener48);
        int int50 = timePeriodValues45.getItemCount();
        int int51 = timePeriodValues45.getMaxMiddleIndex();
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year();
        timePeriodValues45.add((org.jfree.data.time.TimePeriod) year52, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue56 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year52, (java.lang.Number) 2019L);
        java.util.Date date57 = year52.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod58 = new org.jfree.data.time.SimpleTimePeriod(date41, date57);
        long long59 = simpleTimePeriod58.getEndMillis();
        long long60 = simpleTimePeriod58.getStartMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues62 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues62.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener65 = null;
        timePeriodValues62.removePropertyChangeListener(propertyChangeListener65);
        int int67 = timePeriodValues62.getItemCount();
        int int68 = timePeriodValues62.getMaxMiddleIndex();
        org.jfree.data.time.Year year69 = new org.jfree.data.time.Year();
        timePeriodValues62.add((org.jfree.data.time.TimePeriod) year69, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue73 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year69, (java.lang.Number) 2019L);
        java.util.Date date74 = year69.getEnd();
        long long75 = year69.getFirstMillisecond();
        boolean boolean76 = simpleTimePeriod58.equals((java.lang.Object) long75);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod58, (java.lang.Number) 10);
        long long79 = simpleTimePeriod58.getEndMillis();
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Value" + "'", str12.equals("Value"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(timeZone42);
        org.junit.Assert.assertNull(regularTimePeriod43);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1) + "'", int51 == (-1));
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 1577865599999L + "'", long59 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1577865599999L + "'", long60 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + (-1) + "'", int68 == (-1));
        org.junit.Assert.assertNotNull(date74);
        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 1546329600000L + "'", long75 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + long79 + "' != '" + 1577865599999L + "'", long79 == 1577865599999L);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        timePeriodValues1.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener9);
        int int11 = timePeriodValues1.getItemCount();
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2, 12, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues7.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues7.removePropertyChangeListener(propertyChangeListener10);
        int int12 = timePeriodValues7.getItemCount();
        int int13 = timePeriodValues7.getMaxMiddleIndex();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        timePeriodValues7.add((org.jfree.data.time.TimePeriod) year14, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue18 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year14.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod19, (double) 2019L);
        int int22 = timePeriodValues1.getMinEndIndex();
        int int23 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        long long25 = year24.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue27 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year24, (java.lang.Number) 100);
        java.lang.String str28 = timePeriodValue27.toString();
        timePeriodValues1.add(timePeriodValue27);
        try {
            timePeriodValues1.update(9, (java.lang.Number) 11);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 2019L + "'", long25 == 2019L);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "TimePeriodValue[2019,100]" + "'", str28.equals("TimePeriodValue[2019,100]"));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues1.createCopy(0, 0);
        int int10 = timePeriodValues1.getMaxMiddleIndex();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(timePeriodValues9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year11, (java.lang.Number) 100);
        timePeriodValues1.add(timePeriodValue14);
        try {
            org.jfree.data.time.TimePeriod timePeriod17 = timePeriodValues1.getTimePeriod(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2019L + "'", long12 == 2019L);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) ' ');
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues4.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues4.removePropertyChangeListener(propertyChangeListener7);
        int int9 = timePeriodValues4.getItemCount();
        int int10 = timePeriodValues4.getMaxMiddleIndex();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        timePeriodValues4.add((org.jfree.data.time.TimePeriod) year11, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue15 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year11, (java.lang.Number) 2019L);
        java.util.Date date16 = year11.getEnd();
        boolean boolean17 = simpleTimePeriod2.equals((java.lang.Object) date16);
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener20 = null;
        timePeriodValues19.addChangeListener(seriesChangeListener20);
        int int22 = timePeriodValues19.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass23 = timePeriodValues19.getClass();
        java.util.Date date24 = null;
        java.util.TimeZone timeZone25 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date24, timeZone25);
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues28.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timePeriodValues28.removePropertyChangeListener(propertyChangeListener31);
        int int33 = timePeriodValues28.getItemCount();
        int int34 = timePeriodValues28.getMaxMiddleIndex();
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
        timePeriodValues28.add((org.jfree.data.time.TimePeriod) year35, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue39 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year35, (java.lang.Number) 2019L);
        java.util.Date date40 = year35.getEnd();
        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date40, timeZone41);
        org.jfree.data.time.TimePeriodValues timePeriodValues44 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues44.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener47 = null;
        timePeriodValues44.removePropertyChangeListener(propertyChangeListener47);
        int int49 = timePeriodValues44.getItemCount();
        int int50 = timePeriodValues44.getMaxMiddleIndex();
        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year();
        timePeriodValues44.add((org.jfree.data.time.TimePeriod) year51, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue55 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year51, (java.lang.Number) 2019L);
        java.util.Date date56 = year51.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod57 = new org.jfree.data.time.SimpleTimePeriod(date40, date56);
        org.jfree.data.time.TimePeriodValues timePeriodValues59 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues59.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener62 = null;
        timePeriodValues59.removePropertyChangeListener(propertyChangeListener62);
        java.lang.String str64 = timePeriodValues59.getDescription();
        int int65 = timePeriodValues59.getMinStartIndex();
        timePeriodValues59.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues70 = timePeriodValues59.createCopy(0, 1);
        boolean boolean71 = simpleTimePeriod57.equals((java.lang.Object) 0);
        java.util.Date date72 = simpleTimePeriod57.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod73 = new org.jfree.data.time.SimpleTimePeriod(date16, date72);
        org.jfree.data.time.TimePeriodValues timePeriodValues75 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener76 = null;
        timePeriodValues75.addChangeListener(seriesChangeListener76);
        int int78 = timePeriodValues75.getMinMiddleIndex();
        int int79 = timePeriodValues75.getMinEndIndex();
        boolean boolean80 = timePeriodValues75.isEmpty();
        int int81 = timePeriodValues75.getMaxMiddleIndex();
        int int82 = timePeriodValues75.getMaxStartIndex();
        try {
            int int83 = simpleTimePeriod73.compareTo((java.lang.Object) timePeriodValues75);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.TimePeriodValues cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(timeZone41);
        org.junit.Assert.assertNull(regularTimePeriod42);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertNull(str64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + (-1) + "'", int65 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(date72);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + (-1) + "'", int78 == (-1));
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + (-1) + "'", int79 == (-1));
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + true + "'", boolean80 == true);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + (-1) + "'", int81 == (-1));
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + (-1) + "'", int82 == (-1));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) '4');
        java.lang.String str2 = seriesChangeEvent1.toString();
        java.lang.Object obj3 = seriesChangeEvent1.getSource();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=4]" + "'", str2.equals("org.jfree.data.general.SeriesChangeEvent[source=4]"));
        org.junit.Assert.assertTrue("'" + obj3 + "' != '" + '4' + "'", obj3.equals('4'));
    }

//    @Test
//    public void test380() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test380");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getMiddleMillisecond();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = day0.getLastMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560452399999L + "'", long2 == 1560452399999L);
//    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year8.previous();
        int int14 = year8.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (double) 1593676799999L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        timePeriodValues1.setNotify(true);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year10, (java.lang.Number) 100);
        timePeriodValue13.setValue((java.lang.Number) 3);
        org.jfree.data.time.TimePeriod timePeriod16 = timePeriodValue13.getPeriod();
        timePeriodValues1.add(timePeriodValue13);
        try {
            org.jfree.data.time.TimePeriodValues timePeriodValues20 = timePeriodValues1.createCopy(7, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
        org.junit.Assert.assertNotNull(timePeriod16);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener11);
        java.lang.String str13 = timePeriodValues1.getDomainDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues15.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timePeriodValues15.removePropertyChangeListener(propertyChangeListener18);
        java.lang.String str20 = timePeriodValues15.getDescription();
        int int21 = timePeriodValues15.getMinStartIndex();
        timePeriodValues15.fireSeriesChanged();
        boolean boolean23 = timePeriodValues1.equals((java.lang.Object) timePeriodValues15);
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timePeriodValues15.addPropertyChangeListener(propertyChangeListener24);
        java.beans.PropertyChangeListener propertyChangeListener26 = null;
        timePeriodValues15.addPropertyChangeListener(propertyChangeListener26);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        java.lang.String str7 = timePeriodValues1.getDescription();
        int int8 = timePeriodValues1.getMinMiddleIndex();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMinEndIndex();
        java.lang.String str6 = timePeriodValues1.getRangeDescription();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year7.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod9, (java.lang.Number) 6);
        timePeriodValues1.setDomainDescription("Value");
        timePeriodValues1.setDescription("2019");
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Value" + "'", str6.equals("Value"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        boolean boolean9 = timePeriodValues1.equals((java.lang.Object) 3);
        timePeriodValues1.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesChangeEvent[source=0]");
        try {
            timePeriodValues1.delete(2, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMinEndIndex();
        java.lang.String str6 = timePeriodValues1.getRangeDescription();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year7.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod9, (java.lang.Number) 6);
        timePeriodValues1.setDomainDescription("Value");
        int int14 = timePeriodValues1.getMaxStartIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Value" + "'", str6.equals("Value"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (10) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, 0, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues3.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener6);
        java.lang.String str8 = timePeriodValues3.getDescription();
        int int9 = timePeriodValues3.getMinStartIndex();
        timePeriodValues3.setNotify(true);
        int int12 = day0.compareTo((java.lang.Object) timePeriodValues3);
        java.lang.Object obj13 = timePeriodValues3.clone();
        java.lang.Object obj14 = timePeriodValues3.clone();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 100);
        java.util.Date date4 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues6.addChangeListener(seriesChangeListener7);
        int int9 = timePeriodValues6.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass10 = timePeriodValues6.getClass();
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date11, timeZone12);
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues15.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timePeriodValues15.removePropertyChangeListener(propertyChangeListener18);
        int int20 = timePeriodValues15.getItemCount();
        int int21 = timePeriodValues15.getMaxMiddleIndex();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        timePeriodValues15.add((org.jfree.data.time.TimePeriod) year22, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue26 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year22, (java.lang.Number) 2019L);
        java.util.Date date27 = year22.getEnd();
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date27, timeZone28);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(date4, timeZone28);
        org.jfree.data.time.TimePeriodValues timePeriodValues32 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener33 = null;
        timePeriodValues32.addChangeListener(seriesChangeListener33);
        int int35 = timePeriodValues32.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass36 = timePeriodValues32.getClass();
        java.util.Date date37 = null;
        java.util.TimeZone timeZone38 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date37, timeZone38);
        org.jfree.data.time.TimePeriodValues timePeriodValues41 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues41.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener44 = null;
        timePeriodValues41.removePropertyChangeListener(propertyChangeListener44);
        int int46 = timePeriodValues41.getItemCount();
        int int47 = timePeriodValues41.getMaxMiddleIndex();
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year();
        timePeriodValues41.add((org.jfree.data.time.TimePeriod) year48, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue52 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year48, (java.lang.Number) 2019L);
        java.util.Date date53 = year48.getEnd();
        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date53, timeZone54);
        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year(date4, timeZone54);
        java.util.Calendar calendar57 = null;
        try {
            long long58 = year56.getFirstMillisecond(calendar57);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertNotNull(timeZone54);
        org.junit.Assert.assertNull(regularTimePeriod55);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        int int2 = day0.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesChangeEvent[source=0]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener13);
        int int15 = timePeriodValues10.getItemCount();
        int int16 = timePeriodValues10.getMaxMiddleIndex();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) year17, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 2019L);
        java.util.Date date22 = year17.getEnd();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date22, timeZone23);
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues26.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timePeriodValues26.removePropertyChangeListener(propertyChangeListener29);
        int int31 = timePeriodValues26.getItemCount();
        int int32 = timePeriodValues26.getMaxMiddleIndex();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        timePeriodValues26.add((org.jfree.data.time.TimePeriod) year33, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue37 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year33, (java.lang.Number) 2019L);
        java.util.Date date38 = year33.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(date22, date38);
        org.jfree.data.time.TimePeriodValues timePeriodValues41 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues41.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener44 = null;
        timePeriodValues41.removePropertyChangeListener(propertyChangeListener44);
        java.lang.String str46 = timePeriodValues41.getDescription();
        int int47 = timePeriodValues41.getMinStartIndex();
        timePeriodValues41.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues52 = timePeriodValues41.createCopy(0, 1);
        boolean boolean53 = simpleTimePeriod39.equals((java.lang.Object) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues55 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues55.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener58 = null;
        timePeriodValues55.removePropertyChangeListener(propertyChangeListener58);
        int int60 = timePeriodValues55.getItemCount();
        int int61 = timePeriodValues55.getMaxMiddleIndex();
        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year();
        timePeriodValues55.add((org.jfree.data.time.TimePeriod) year62, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue66 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year62, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = year62.previous();
        long long68 = regularTimePeriod67.getMiddleMillisecond();
        boolean boolean69 = simpleTimePeriod39.equals((java.lang.Object) long68);
        java.util.Date date70 = simpleTimePeriod39.getEnd();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNull(str46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod67);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 1530561599999L + "'", long68 == 1530561599999L);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(date70);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 100);
        java.util.Date date4 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues6.addChangeListener(seriesChangeListener7);
        int int9 = timePeriodValues6.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass10 = timePeriodValues6.getClass();
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date11, timeZone12);
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues15.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timePeriodValues15.removePropertyChangeListener(propertyChangeListener18);
        int int20 = timePeriodValues15.getItemCount();
        int int21 = timePeriodValues15.getMaxMiddleIndex();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        timePeriodValues15.add((org.jfree.data.time.TimePeriod) year22, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue26 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year22, (java.lang.Number) 2019L);
        java.util.Date date27 = year22.getEnd();
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date27, timeZone28);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(date4, timeZone28);
        org.jfree.data.time.TimePeriodValues timePeriodValues32 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener33 = null;
        timePeriodValues32.addChangeListener(seriesChangeListener33);
        int int35 = timePeriodValues32.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass36 = timePeriodValues32.getClass();
        java.util.Date date37 = null;
        java.util.TimeZone timeZone38 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date37, timeZone38);
        org.jfree.data.time.TimePeriodValues timePeriodValues41 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues41.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener44 = null;
        timePeriodValues41.removePropertyChangeListener(propertyChangeListener44);
        int int46 = timePeriodValues41.getItemCount();
        int int47 = timePeriodValues41.getMaxMiddleIndex();
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year();
        timePeriodValues41.add((org.jfree.data.time.TimePeriod) year48, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue52 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year48, (java.lang.Number) 2019L);
        java.util.Date date53 = year48.getEnd();
        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date53, timeZone54);
        org.jfree.data.time.TimePeriodValues timePeriodValues57 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues57.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener60 = null;
        timePeriodValues57.removePropertyChangeListener(propertyChangeListener60);
        int int62 = timePeriodValues57.getItemCount();
        int int63 = timePeriodValues57.getMaxMiddleIndex();
        org.jfree.data.time.Year year64 = new org.jfree.data.time.Year();
        timePeriodValues57.add((org.jfree.data.time.TimePeriod) year64, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue68 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year64, (java.lang.Number) 2019L);
        java.util.Date date69 = year64.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod70 = new org.jfree.data.time.SimpleTimePeriod(date53, date69);
        java.util.TimeZone timeZone71 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year72 = new org.jfree.data.time.Year(date53, timeZone71);
        org.jfree.data.time.Year year73 = new org.jfree.data.time.Year(date4, timeZone71);
        org.jfree.data.time.Year year74 = new org.jfree.data.time.Year(date4);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertNotNull(timeZone54);
        org.junit.Assert.assertNull(regularTimePeriod55);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-1) + "'", int63 == (-1));
        org.junit.Assert.assertNotNull(date69);
        org.junit.Assert.assertNotNull(timeZone71);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year11, (java.lang.Number) 100);
        timePeriodValues1.add(timePeriodValue14);
        java.lang.String str16 = timePeriodValues1.getDescription();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 100);
        java.util.Date date21 = year17.getStart();
        org.jfree.data.time.TimePeriodValue timePeriodValue23 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) (short) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues25.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener28 = null;
        timePeriodValues25.removePropertyChangeListener(propertyChangeListener28);
        java.lang.String str30 = timePeriodValues25.getDescription();
        boolean boolean31 = year17.equals((java.lang.Object) timePeriodValues25);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 43629L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = year17.next();
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2019L + "'", long12 == 2019L);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2019L + "'", long18 == 2019L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 2019L);
        java.util.Date date13 = year8.getEnd();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date13);
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date13, "13-June-2019", "31-December-2019");
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = timePeriodValues17.createCopy(4, 6);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(timePeriodValues20);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        timePeriodValues1.setKey((java.lang.Comparable) 100L);
        timePeriodValues1.setKey((java.lang.Comparable) (short) 100);
        java.lang.String str8 = timePeriodValues1.getRangeDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year9, (java.lang.Number) 100);
        timePeriodValues1.add(timePeriodValue12);
        timePeriodValue12.setValue((java.lang.Number) 0.0f);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Value" + "'", str8.equals("Value"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 2019L);
        long long13 = year8.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year8.next();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener13);
        int int15 = timePeriodValues10.getItemCount();
        int int16 = timePeriodValues10.getMaxMiddleIndex();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) year17, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 2019L);
        java.util.Date date22 = year17.getEnd();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date22, timeZone23);
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues26.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timePeriodValues26.removePropertyChangeListener(propertyChangeListener29);
        int int31 = timePeriodValues26.getItemCount();
        int int32 = timePeriodValues26.getMaxMiddleIndex();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        timePeriodValues26.add((org.jfree.data.time.TimePeriod) year33, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue37 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year33, (java.lang.Number) 2019L);
        java.util.Date date38 = year33.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(date22, date38);
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date22);
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year(date22);
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year(date22);
        java.util.Calendar calendar43 = null;
        try {
            year42.peg(calendar43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(date38);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues3.setNotify(true);
        boolean boolean7 = timePeriodValues3.equals((java.lang.Object) (short) 0);
        boolean boolean8 = year0.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        timePeriodValues10.setKey((java.lang.Comparable) 100L);
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues16.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timePeriodValues16.removePropertyChangeListener(propertyChangeListener19);
        int int21 = timePeriodValues16.getItemCount();
        int int22 = timePeriodValues16.getMaxMiddleIndex();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        timePeriodValues16.add((org.jfree.data.time.TimePeriod) year23, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue27 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year23, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year23.previous();
        timePeriodValues10.setKey((java.lang.Comparable) year23);
        int int30 = year0.compareTo((java.lang.Object) year23);
        java.lang.String str31 = year0.toString();
        long long32 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues34 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues34.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener37 = null;
        timePeriodValues34.removePropertyChangeListener(propertyChangeListener37);
        java.lang.String str39 = timePeriodValues34.getDescription();
        int int40 = timePeriodValues34.getMinStartIndex();
        int int41 = timePeriodValues34.getMaxEndIndex();
        timePeriodValues34.setDomainDescription("");
        int int44 = timePeriodValues34.getMaxEndIndex();
        java.lang.String str45 = timePeriodValues34.getRangeDescription();
        java.lang.Class<?> wildcardClass46 = timePeriodValues34.getClass();
        boolean boolean47 = year0.equals((java.lang.Object) timePeriodValues34);
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue49 = timePeriodValues34.getDataItem(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "2019" + "'", str31.equals("2019"));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 2019L + "'", long32 == 2019L);
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "Value" + "'", str45.equals("Value"));
        org.junit.Assert.assertNotNull(wildcardClass46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 100);
        java.util.Date date4 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues6.addChangeListener(seriesChangeListener7);
        int int9 = timePeriodValues6.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass10 = timePeriodValues6.getClass();
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date11, timeZone12);
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues15.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timePeriodValues15.removePropertyChangeListener(propertyChangeListener18);
        int int20 = timePeriodValues15.getItemCount();
        int int21 = timePeriodValues15.getMaxMiddleIndex();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        timePeriodValues15.add((org.jfree.data.time.TimePeriod) year22, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue26 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year22, (java.lang.Number) 2019L);
        java.util.Date date27 = year22.getEnd();
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date27, timeZone28);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(date4, timeZone28);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        long long32 = year31.getSerialIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues34 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues34.setNotify(true);
        boolean boolean38 = timePeriodValues34.equals((java.lang.Object) (short) 0);
        boolean boolean39 = year31.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues41 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues41.setNotify(true);
        timePeriodValues41.setKey((java.lang.Comparable) 100L);
        org.jfree.data.time.TimePeriodValues timePeriodValues47 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues47.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener50 = null;
        timePeriodValues47.removePropertyChangeListener(propertyChangeListener50);
        int int52 = timePeriodValues47.getItemCount();
        int int53 = timePeriodValues47.getMaxMiddleIndex();
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year();
        timePeriodValues47.add((org.jfree.data.time.TimePeriod) year54, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue58 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year54, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = year54.previous();
        timePeriodValues41.setKey((java.lang.Comparable) year54);
        int int61 = year31.compareTo((java.lang.Object) year54);
        java.lang.String str62 = year31.toString();
        java.lang.Object obj63 = null;
        boolean boolean64 = year31.equals(obj63);
        java.util.Date date65 = year31.getStart();
        org.jfree.data.time.TimePeriodValue timePeriodValue67 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year31, 0.0d);
        int int68 = year30.compareTo((java.lang.Object) timePeriodValue67);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 2019L + "'", long32 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-1) + "'", int53 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod59);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "2019" + "'", str62.equals("2019"));
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(date65);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 1 + "'", int68 == 1);
    }

//    @Test
//    public void test403() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test403");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        timePeriodValues1.setNotify(true);
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
//        java.lang.String str6 = timePeriodValues1.getDescription();
//        int int7 = timePeriodValues1.getMinStartIndex();
//        int int8 = timePeriodValues1.getMaxEndIndex();
//        timePeriodValues1.setDomainDescription("");
//        java.beans.PropertyChangeListener propertyChangeListener11 = null;
//        timePeriodValues1.removePropertyChangeListener(propertyChangeListener11);
//        java.lang.String str13 = timePeriodValues1.getDomainDescription();
//        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        timePeriodValues15.setNotify(true);
//        java.beans.PropertyChangeListener propertyChangeListener18 = null;
//        timePeriodValues15.removePropertyChangeListener(propertyChangeListener18);
//        java.lang.String str20 = timePeriodValues15.getDescription();
//        int int21 = timePeriodValues15.getMinStartIndex();
//        timePeriodValues15.fireSeriesChanged();
//        boolean boolean23 = timePeriodValues1.equals((java.lang.Object) timePeriodValues15);
//        int int24 = timePeriodValues1.getMaxStartIndex();
//        int int25 = timePeriodValues1.getMaxStartIndex();
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass27 = day26.getClass();
//        long long28 = day26.getLastMillisecond();
//        long long29 = day26.getMiddleMillisecond();
//        timePeriodValues1.setKey((java.lang.Comparable) day26);
//        java.lang.String str31 = timePeriodValues1.getDomainDescription();
//        timePeriodValues1.setDomainDescription("");
//        org.junit.Assert.assertNull(str6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertNull(str20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass27);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560495599999L + "'", long28 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560452399999L + "'", long29 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "" + "'", str31.equals(""));
//    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(1530561599999L, (long) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test405() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test405");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 0L);
//        int int3 = day0.getYear();
//        java.lang.String str4 = day0.toString();
//        int int5 = day0.getDayOfMonth();
//        int int6 = day0.getMonth();
//        java.util.Calendar calendar7 = null;
//        try {
//            long long8 = day0.getLastMillisecond(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "13-June-2019" + "'", str4.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//    }

//    @Test
//    public void test406() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test406");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 0L);
//        int int3 = day0.getYear();
//        java.lang.String str4 = day0.toString();
//        int int5 = day0.getDayOfMonth();
//        int int6 = day0.getMonth();
//        long long7 = day0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "13-June-2019" + "'", str4.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener13);
        int int15 = timePeriodValues10.getItemCount();
        int int16 = timePeriodValues10.getMaxMiddleIndex();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) year17, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 2019L);
        java.util.Date date22 = year17.getEnd();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date22, timeZone23);
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues26.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timePeriodValues26.removePropertyChangeListener(propertyChangeListener29);
        int int31 = timePeriodValues26.getItemCount();
        int int32 = timePeriodValues26.getMaxMiddleIndex();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        timePeriodValues26.add((org.jfree.data.time.TimePeriod) year33, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue37 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year33, (java.lang.Number) 2019L);
        java.util.Date date38 = year33.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(date22, date38);
        org.jfree.data.time.TimePeriodValues timePeriodValues41 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues41.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener44 = null;
        timePeriodValues41.removePropertyChangeListener(propertyChangeListener44);
        java.lang.String str46 = timePeriodValues41.getDescription();
        int int47 = timePeriodValues41.getMinStartIndex();
        timePeriodValues41.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues52 = timePeriodValues41.createCopy(0, 1);
        boolean boolean53 = simpleTimePeriod39.equals((java.lang.Object) 0);
        java.util.Date date54 = simpleTimePeriod39.getStart();
        org.jfree.data.time.TimePeriodValue timePeriodValue56 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod39, (double) (byte) 100);
        timePeriodValue56.setValue((java.lang.Number) 100);
        java.lang.Object obj59 = timePeriodValue56.clone();
        java.lang.String str60 = timePeriodValue56.toString();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNull(str46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertNotNull(obj59);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        boolean boolean5 = timePeriodValues1.equals((java.lang.Object) (short) 0);
        int int6 = timePeriodValues1.getMinEndIndex();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener13);
        int int15 = timePeriodValues10.getItemCount();
        int int16 = timePeriodValues10.getMaxMiddleIndex();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) year17, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 2019L);
        java.util.Date date22 = year17.getEnd();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date22, timeZone23);
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues26.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timePeriodValues26.removePropertyChangeListener(propertyChangeListener29);
        int int31 = timePeriodValues26.getItemCount();
        int int32 = timePeriodValues26.getMaxMiddleIndex();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        timePeriodValues26.add((org.jfree.data.time.TimePeriod) year33, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue37 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year33, (java.lang.Number) 2019L);
        java.util.Date date38 = year33.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(date22, date38);
        org.jfree.data.time.TimePeriodValues timePeriodValues41 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues41.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener44 = null;
        timePeriodValues41.removePropertyChangeListener(propertyChangeListener44);
        java.lang.String str46 = timePeriodValues41.getDescription();
        int int47 = timePeriodValues41.getMinStartIndex();
        timePeriodValues41.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues52 = timePeriodValues41.createCopy(0, 1);
        boolean boolean53 = simpleTimePeriod39.equals((java.lang.Object) 0);
        java.util.Date date54 = simpleTimePeriod39.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues56 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues56.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener59 = null;
        timePeriodValues56.removePropertyChangeListener(propertyChangeListener59);
        int int61 = timePeriodValues56.getItemCount();
        int int62 = timePeriodValues56.getMaxMiddleIndex();
        org.jfree.data.time.Year year63 = new org.jfree.data.time.Year();
        timePeriodValues56.add((org.jfree.data.time.TimePeriod) year63, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue67 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year63, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = year63.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = year63.previous();
        int int70 = simpleTimePeriod39.compareTo((java.lang.Object) regularTimePeriod69);
        java.lang.Object obj71 = null;
        try {
            int int72 = simpleTimePeriod39.compareTo(obj71);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNull(str46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-1) + "'", int62 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod68);
        org.junit.Assert.assertNotNull(regularTimePeriod69);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 1 + "'", int70 == 1);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMinEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = timePeriodValues1.createCopy(6, (int) (byte) 100);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener13);
        int int15 = timePeriodValues10.getItemCount();
        int int16 = timePeriodValues10.getMaxMiddleIndex();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) year17, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year17.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year17.previous();
        java.lang.Object obj24 = null;
        int int25 = year17.compareTo(obj24);
        timePeriodValues1.setKey((java.lang.Comparable) year17);
        java.lang.String str27 = timePeriodValues1.getRangeDescription();
        java.lang.String str28 = timePeriodValues1.getDescription();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Value" + "'", str27.equals("Value"));
        org.junit.Assert.assertNull(str28);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        boolean boolean9 = timePeriodValues1.equals((java.lang.Object) 3);
        timePeriodValues1.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesChangeEvent[source=0]");
        try {
            timePeriodValues1.delete(1, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener13);
        int int15 = timePeriodValues10.getItemCount();
        int int16 = timePeriodValues10.getMaxMiddleIndex();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) year17, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 2019L);
        java.util.Date date22 = year17.getEnd();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date22, timeZone23);
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues26.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timePeriodValues26.removePropertyChangeListener(propertyChangeListener29);
        int int31 = timePeriodValues26.getItemCount();
        int int32 = timePeriodValues26.getMaxMiddleIndex();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        timePeriodValues26.add((org.jfree.data.time.TimePeriod) year33, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue37 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year33, (java.lang.Number) 2019L);
        java.util.Date date38 = year33.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(date22, date38);
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year(date38);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(date38);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(100, 0, 13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        int int11 = timePeriodValues1.getMaxEndIndex();
        boolean boolean13 = timePeriodValues1.equals((java.lang.Object) (-1L));
        int int14 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener15);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        boolean boolean2 = timePeriodValues1.getNotify();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener3);
        try {
            org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) propertyChangeListener3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 100);
        java.util.Date date4 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues6.addChangeListener(seriesChangeListener7);
        int int9 = timePeriodValues6.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass10 = timePeriodValues6.getClass();
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date11, timeZone12);
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues15.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timePeriodValues15.removePropertyChangeListener(propertyChangeListener18);
        int int20 = timePeriodValues15.getItemCount();
        int int21 = timePeriodValues15.getMaxMiddleIndex();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        timePeriodValues15.add((org.jfree.data.time.TimePeriod) year22, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue26 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year22, (java.lang.Number) 2019L);
        java.util.Date date27 = year22.getEnd();
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date27, timeZone28);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(date4, timeZone28);
        org.jfree.data.time.TimePeriodValues timePeriodValues32 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener33 = null;
        timePeriodValues32.addChangeListener(seriesChangeListener33);
        int int35 = timePeriodValues32.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass36 = timePeriodValues32.getClass();
        java.util.Date date37 = null;
        java.util.TimeZone timeZone38 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date37, timeZone38);
        org.jfree.data.time.TimePeriodValues timePeriodValues41 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues41.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener44 = null;
        timePeriodValues41.removePropertyChangeListener(propertyChangeListener44);
        int int46 = timePeriodValues41.getItemCount();
        int int47 = timePeriodValues41.getMaxMiddleIndex();
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year();
        timePeriodValues41.add((org.jfree.data.time.TimePeriod) year48, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue52 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year48, (java.lang.Number) 2019L);
        java.util.Date date53 = year48.getEnd();
        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date53, timeZone54);
        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year(date4, timeZone54);
        org.jfree.data.time.TimePeriodValue timePeriodValue58 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year56, (java.lang.Number) 1530561599999L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertNotNull(timeZone54);
        org.junit.Assert.assertNull(regularTimePeriod55);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 2019L);
        java.util.Date date13 = year8.getEnd();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date13);
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date13, timeZone15);
        long long17 = day16.getSerialIndex();
        java.util.Date date18 = day16.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day16.previous();
        int int20 = day16.getDayOfMonth();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 43830L + "'", long17 == 43830L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 31 + "'", int20 == 31);
    }

//    @Test
//    public void test418() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test418");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        timePeriodValues3.setNotify(true);
//        java.beans.PropertyChangeListener propertyChangeListener6 = null;
//        timePeriodValues3.removePropertyChangeListener(propertyChangeListener6);
//        int int8 = timePeriodValues3.getItemCount();
//        int int9 = timePeriodValues3.getMaxMiddleIndex();
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year10, (double) 6);
//        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year10, (java.lang.Number) 2019L);
//        java.util.Date date15 = year10.getEnd();
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date15);
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date15, timeZone17);
//        int int19 = day0.compareTo((java.lang.Object) day18);
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-201) + "'", int19 == (-201));
//    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("31-December-2019");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener11);
        int int13 = timePeriodValues1.getMaxEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = timePeriodValues1.createCopy(5, (int) '#');
        try {
            java.lang.Number number18 = timePeriodValues1.getValue((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues16);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener11);
        java.lang.String str13 = timePeriodValues1.getDomainDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues15.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timePeriodValues15.removePropertyChangeListener(propertyChangeListener18);
        java.lang.String str20 = timePeriodValues15.getDescription();
        int int21 = timePeriodValues15.getMinStartIndex();
        timePeriodValues15.fireSeriesChanged();
        boolean boolean23 = timePeriodValues1.equals((java.lang.Object) timePeriodValues15);
        int int24 = timePeriodValues15.getMinEndIndex();
        java.lang.String str25 = timePeriodValues15.getRangeDescription();
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Value" + "'", str25.equals("Value"));
    }

//    @Test
//    public void test422() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test422");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        int int4 = timePeriodValues1.getMinMiddleIndex();
//        int int5 = timePeriodValues1.getMinEndIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues8 = timePeriodValues1.createCopy(6, (int) (byte) 100);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.lang.String str10 = day9.toString();
//        java.util.Date date11 = day9.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day9.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day9.next();
//        timePeriodValues8.setKey((java.lang.Comparable) day9);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "13-June-2019" + "'", str10.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (byte) 0, (int) (byte) 1, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("13-June-2019");
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 2019L);
        java.util.Date date13 = year8.getEnd();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date13);
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date13, timeZone15);
        long long17 = day16.getFirstMillisecond();
        java.util.Calendar calendar18 = null;
        try {
            day16.peg(calendar18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1577779200000L + "'", long17 == 1577779200000L);
    }

//    @Test
//    public void test426() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test426");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getMiddleMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate5 = day4.getSerialDate();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
//        boolean boolean7 = day0.equals((java.lang.Object) serialDate5);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day0.next();
//        java.lang.String str9 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day0.next();
//        java.util.Calendar calendar11 = null;
//        try {
//            long long12 = day0.getLastMillisecond(calendar11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560452399999L + "'", long2 == 1560452399999L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "13-June-2019" + "'", str9.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(serialDate1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(serialDate1);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(serialDate1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = day4.getMiddleMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener11);
        java.lang.String str13 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.fireSeriesChanged();
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        int int11 = timePeriodValues1.getMaxEndIndex();
        java.lang.String str12 = timePeriodValues1.getRangeDescription();
        timePeriodValues1.setKey((java.lang.Comparable) 7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener15);
        timePeriodValues1.setRangeDescription("");
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate20 = day19.getSerialDate();
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(serialDate20);
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(serialDate20);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(serialDate20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day23.next();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod24, (java.lang.Number) 3);
        org.jfree.data.time.TimePeriodValue timePeriodValue28 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod24, (java.lang.Number) 10.0f);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Value" + "'", str12.equals("Value"));
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 100);
        java.util.Date date4 = year0.getStart();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) (short) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year0.previous();
        long long8 = year0.getLastMillisecond();
        long long9 = year0.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2019L + "'", long9 == 2019L);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("TimePeriodValue[2019,100.0]");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMinEndIndex();
        java.lang.String str6 = timePeriodValues1.getRangeDescription();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year7.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod9, (java.lang.Number) 6);
        int int12 = timePeriodValues1.getMinEndIndex();
        java.lang.Object obj13 = timePeriodValues1.clone();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Value" + "'", str6.equals("Value"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(obj13);
    }

//    @Test
//    public void test433() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test433");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass1 = day0.getClass();
//        long long2 = day0.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0, "Time", "2019");
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = day0.getLastMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560495599999L + "'", long2 == 1560495599999L);
//    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        int int3 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.previous();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) '#', 2, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year8.previous();
        java.lang.String str14 = year8.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year8.previous();
        java.util.Calendar calendar16 = null;
        try {
            year8.peg(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019" + "'", str14.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod15);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 2019L);
        java.util.Date date13 = year8.getEnd();
        long long14 = year8.getMiddleMillisecond();
        java.lang.String str15 = year8.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year8.previous();
        int int17 = year8.getYear();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1562097599999L + "'", long14 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
    }

//    @Test
//    public void test438() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test438");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass1 = day0.getClass();
//        long long2 = day0.getLastMillisecond();
//        java.lang.String str3 = day0.toString();
//        int int4 = day0.getYear();
//        long long5 = day0.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(wildcardClass1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560495599999L + "'", long2 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560452399999L + "'", long5 == 1560452399999L);
//    }

//    @Test
//    public void test439() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test439");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        timePeriodValues1.setNotify(true);
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
//        java.lang.String str6 = timePeriodValues1.getDescription();
//        int int7 = timePeriodValues1.getMinStartIndex();
//        timePeriodValues1.setNotify(true);
//        org.jfree.data.time.TimePeriodValues timePeriodValues12 = timePeriodValues1.createCopy(4, 0);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.String str14 = day13.toString();
//        int int15 = day13.getMonth();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day13, (java.lang.Number) 8.0d);
//        org.junit.Assert.assertNull(str6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues12);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
//    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues7.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues7.removePropertyChangeListener(propertyChangeListener10);
        int int12 = timePeriodValues7.getItemCount();
        int int13 = timePeriodValues7.getMaxMiddleIndex();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        timePeriodValues7.add((org.jfree.data.time.TimePeriod) year14, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue18 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year14.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod19, (double) 2019L);
        java.lang.Object obj22 = timePeriodValues1.clone();
        int int23 = timePeriodValues1.getMinStartIndex();
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) ' ');
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (java.lang.Number) 6);
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues6.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timePeriodValues6.removePropertyChangeListener(propertyChangeListener9);
        java.lang.String str11 = timePeriodValues6.getDescription();
        int int12 = timePeriodValues6.getMinStartIndex();
        timePeriodValues6.setNotify(true);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        long long16 = year15.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue18 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year15, (java.lang.Number) 100);
        timePeriodValue18.setValue((java.lang.Number) 3);
        org.jfree.data.time.TimePeriod timePeriod21 = timePeriodValue18.getPeriod();
        timePeriodValues6.add(timePeriodValue18);
        org.jfree.data.time.TimePeriodValues timePeriodValues24 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues24.setNotify(true);
        timePeriodValues24.setKey((java.lang.Comparable) 100L);
        timePeriodValues24.setKey((java.lang.Comparable) (short) 100);
        java.lang.String str31 = timePeriodValues24.getRangeDescription();
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        long long33 = year32.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue35 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year32, (java.lang.Number) 100);
        timePeriodValues24.add(timePeriodValue35);
        boolean boolean37 = timePeriodValue18.equals((java.lang.Object) timePeriodValues24);
        java.lang.String str38 = timePeriodValue18.toString();
        org.jfree.data.time.TimePeriodValues timePeriodValues40 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues40.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener43 = null;
        timePeriodValues40.removePropertyChangeListener(propertyChangeListener43);
        java.lang.String str45 = timePeriodValues40.getDescription();
        int int46 = timePeriodValues40.getMinStartIndex();
        int int47 = timePeriodValues40.getMaxEndIndex();
        timePeriodValues40.setDomainDescription("");
        int int50 = timePeriodValues40.getMaxEndIndex();
        boolean boolean52 = timePeriodValues40.equals((java.lang.Object) (-1L));
        boolean boolean53 = timePeriodValue18.equals((java.lang.Object) timePeriodValues40);
        boolean boolean54 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValue18);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertNotNull(timePeriod21);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Value" + "'", str31.equals("Value"));
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 2019L + "'", long33 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "TimePeriodValue[2019,3]" + "'", str38.equals("TimePeriodValue[2019,3]"));
        org.junit.Assert.assertNull(str45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("Time");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        int int9 = timePeriodValues1.getMinEndIndex();
        int int10 = timePeriodValues1.getItemCount();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener11);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        timePeriodValues1.delete((int) (byte) 1, (int) (byte) 0);
        java.lang.String str7 = timePeriodValues1.getDescription();
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        timePeriodValues1.setNotify(true);
        java.lang.Comparable comparable8 = timePeriodValues1.getKey();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) ' ');
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod11, (java.lang.Number) 6);
        timePeriodValues1.add(timePeriodValue13);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (byte) 1 + "'", comparable8.equals((byte) 1));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        timePeriodValues1.setKey((java.lang.Comparable) 100L);
        timePeriodValues1.setKey((java.lang.Comparable) (short) 100);
        java.lang.String str8 = timePeriodValues1.getRangeDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year9, (java.lang.Number) 100);
        timePeriodValues1.add(timePeriodValue12);
        java.lang.Object obj14 = timePeriodValues1.clone();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Value" + "'", str8.equals("Value"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMinEndIndex();
        boolean boolean6 = timePeriodValues1.isEmpty();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        int int8 = timePeriodValues1.getMaxMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener9);
        timePeriodValues1.setNotify(false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 2019L);
        java.lang.Class<?> wildcardClass13 = year8.getClass();
        long long14 = year8.getSerialIndex();
        long long15 = year8.getSerialIndex();
        long long16 = year8.getSerialIndex();
        java.util.Date date17 = year8.getEnd();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2019L + "'", long14 == 2019L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2019L + "'", long15 == 2019L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertNotNull(date17);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMinEndIndex();
        boolean boolean6 = timePeriodValues1.isEmpty();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        int int8 = timePeriodValues1.getMaxMiddleIndex();
        timePeriodValues1.fireSeriesChanged();
        try {
            org.jfree.data.time.TimePeriod timePeriod11 = timePeriodValues1.getTimePeriod(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener11);
        java.lang.String str13 = timePeriodValues1.getDomainDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener14);
        int int16 = timePeriodValues1.getMinEndIndex();
        try {
            java.lang.Number number18 = timePeriodValues1.getValue(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 100);
        java.util.Date date4 = year0.getStart();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) (short) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues8.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues8.removePropertyChangeListener(propertyChangeListener11);
        java.lang.String str13 = timePeriodValues8.getDescription();
        boolean boolean14 = year0.equals((java.lang.Object) timePeriodValues8);
        timePeriodValues8.setDomainDescription("TimePeriodValue[2019,3]");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        timePeriodValues1.setKey((java.lang.Comparable) 100L);
        int int6 = timePeriodValues1.getMaxStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues1.createCopy(12, 100);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues9);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        timePeriodValues1.setKey((java.lang.Comparable) 100L);
        timePeriodValues1.setKey((java.lang.Comparable) (short) 100);
        java.lang.String str8 = timePeriodValues1.getRangeDescription();
        timePeriodValues1.delete(4, 0);
        timePeriodValues1.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Value" + "'", str8.equals("Value"));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 2019L);
        java.lang.Class<?> wildcardClass13 = year8.getClass();
        long long14 = year8.getSerialIndex();
        java.lang.String str15 = year8.toString();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2019L + "'", long14 == 2019L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year11, (java.lang.Number) 100);
        timePeriodValues1.add(timePeriodValue14);
        java.lang.String str16 = timePeriodValues1.getDescription();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 100);
        java.util.Date date21 = year17.getStart();
        org.jfree.data.time.TimePeriodValue timePeriodValue23 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) (short) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues25.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener28 = null;
        timePeriodValues25.removePropertyChangeListener(propertyChangeListener28);
        java.lang.String str30 = timePeriodValues25.getDescription();
        boolean boolean31 = year17.equals((java.lang.Object) timePeriodValues25);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 43629L);
        java.util.Calendar calendar34 = null;
        try {
            long long35 = year17.getFirstMillisecond(calendar34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2019L + "'", long12 == 2019L);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2019L + "'", long18 == 2019L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        java.lang.Comparable comparable0 = null;
        try {
            org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues(comparable0, "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesChangeEvent[source=0]", "Time");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        java.lang.Throwable[] throwableArray17 = timePeriodFormatException10.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException23 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException25 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
        timePeriodFormatException23.addSuppressed((java.lang.Throwable) timePeriodFormatException25);
        timePeriodFormatException21.addSuppressed((java.lang.Throwable) timePeriodFormatException23);
        timePeriodFormatException19.addSuppressed((java.lang.Throwable) timePeriodFormatException23);
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException23);
        java.lang.Throwable[] throwableArray30 = timePeriodFormatException23.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertNotNull(throwableArray30);
    }

//    @Test
//    public void test458() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test458");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getSerialIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        timePeriodValues3.setNotify(true);
//        boolean boolean7 = timePeriodValues3.equals((java.lang.Object) (short) 0);
//        boolean boolean8 = year0.equals((java.lang.Object) (short) 0);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass10 = day9.getClass();
//        long long11 = day9.getLastMillisecond();
//        int int12 = day9.getDayOfMonth();
//        java.util.Date date13 = day9.getStart();
//        boolean boolean14 = year0.equals((java.lang.Object) date13);
//        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date13);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560495599999L + "'", long11 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 13 + "'", int12 == 13);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year8.previous();
        java.util.Calendar calendar14 = null;
        try {
            year8.peg(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener13);
        int int15 = timePeriodValues10.getItemCount();
        int int16 = timePeriodValues10.getMaxMiddleIndex();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) year17, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 2019L);
        java.util.Date date22 = year17.getEnd();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date22, timeZone23);
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues26.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timePeriodValues26.removePropertyChangeListener(propertyChangeListener29);
        int int31 = timePeriodValues26.getItemCount();
        int int32 = timePeriodValues26.getMaxMiddleIndex();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        timePeriodValues26.add((org.jfree.data.time.TimePeriod) year33, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue37 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year33, (java.lang.Number) 2019L);
        java.util.Date date38 = year33.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(date22, date38);
        java.util.Date date40 = simpleTimePeriod39.getEnd();
        java.util.Date date41 = simpleTimePeriod39.getEnd();
        java.util.Date date42 = simpleTimePeriod39.getStart();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(date42);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues3.setNotify(true);
        boolean boolean7 = timePeriodValues3.equals((java.lang.Object) (short) 0);
        boolean boolean8 = year0.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        timePeriodValues10.setKey((java.lang.Comparable) 100L);
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues16.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timePeriodValues16.removePropertyChangeListener(propertyChangeListener19);
        int int21 = timePeriodValues16.getItemCount();
        int int22 = timePeriodValues16.getMaxMiddleIndex();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        timePeriodValues16.add((org.jfree.data.time.TimePeriod) year23, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue27 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year23, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year23.previous();
        timePeriodValues10.setKey((java.lang.Comparable) year23);
        int int30 = year0.compareTo((java.lang.Object) year23);
        java.lang.String str31 = year0.toString();
        long long32 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues34 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues34.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener37 = null;
        timePeriodValues34.removePropertyChangeListener(propertyChangeListener37);
        java.lang.String str39 = timePeriodValues34.getDescription();
        int int40 = timePeriodValues34.getMinStartIndex();
        int int41 = timePeriodValues34.getMaxEndIndex();
        timePeriodValues34.setDomainDescription("");
        int int44 = timePeriodValues34.getMaxEndIndex();
        java.lang.String str45 = timePeriodValues34.getRangeDescription();
        java.lang.Class<?> wildcardClass46 = timePeriodValues34.getClass();
        boolean boolean47 = year0.equals((java.lang.Object) timePeriodValues34);
        org.jfree.data.time.TimePeriodValues timePeriodValues49 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener50 = null;
        timePeriodValues49.addChangeListener(seriesChangeListener50);
        int int52 = timePeriodValues49.getMinMiddleIndex();
        int int53 = timePeriodValues49.getMinEndIndex();
        java.lang.String str54 = timePeriodValues49.getRangeDescription();
        timePeriodValues49.setDescription("hi!");
        java.lang.String str57 = timePeriodValues49.getRangeDescription();
        boolean boolean58 = year0.equals((java.lang.Object) timePeriodValues49);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "2019" + "'", str31.equals("2019"));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 2019L + "'", long32 == 2019L);
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "Value" + "'", str45.equals("Value"));
        org.junit.Assert.assertNotNull(wildcardClass46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-1) + "'", int53 == (-1));
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "Value" + "'", str54.equals("Value"));
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "Value" + "'", str57.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (java.lang.Number) 100);
        java.lang.Object obj11 = timePeriodValue10.clone();
        timePeriodValues1.add(timePeriodValue10);
        java.lang.Number number13 = timePeriodValue10.getValue();
        timePeriodValue10.setValue((java.lang.Number) (short) 100);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 100 + "'", number13.equals(100));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        timePeriodValues1.setKey((java.lang.Comparable) 100L);
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues7.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues7.removePropertyChangeListener(propertyChangeListener10);
        int int12 = timePeriodValues7.getItemCount();
        int int13 = timePeriodValues7.getMaxMiddleIndex();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        timePeriodValues7.add((org.jfree.data.time.TimePeriod) year14, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue18 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year14.previous();
        timePeriodValues1.setKey((java.lang.Comparable) year14);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate22 = day21.getSerialDate();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(serialDate22);
        int int24 = year14.compareTo((java.lang.Object) serialDate22);
        java.util.Calendar calendar25 = null;
        try {
            long long26 = year14.getLastMillisecond(calendar25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 100);
        java.util.Date date4 = year0.getStart();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) (short) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues8.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues8.removePropertyChangeListener(propertyChangeListener11);
        java.lang.String str13 = timePeriodValues8.getDescription();
        boolean boolean14 = year0.equals((java.lang.Object) timePeriodValues8);
        long long15 = year0.getMiddleMillisecond();
        java.util.Calendar calendar16 = null;
        try {
            long long17 = year0.getLastMillisecond(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1562097599999L + "'", long15 == 1562097599999L);
    }

//    @Test
//    public void test465() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test465");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 0L);
//        int int3 = day0.getYear();
//        java.lang.String str4 = day0.toString();
//        int int5 = day0.getDayOfMonth();
//        int int6 = day0.getMonth();
//        java.util.Calendar calendar7 = null;
//        try {
//            day0.peg(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "13-June-2019" + "'", str4.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener11);
        java.lang.String str13 = timePeriodValues1.getDomainDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues15.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timePeriodValues15.removePropertyChangeListener(propertyChangeListener18);
        java.lang.String str20 = timePeriodValues15.getDescription();
        int int21 = timePeriodValues15.getMinStartIndex();
        timePeriodValues15.fireSeriesChanged();
        boolean boolean23 = timePeriodValues1.equals((java.lang.Object) timePeriodValues15);
        int int24 = timePeriodValues1.getMaxStartIndex();
        java.lang.Comparable comparable25 = timePeriodValues1.getKey();
        boolean boolean26 = timePeriodValues1.getNotify();
        timePeriodValues1.fireSeriesChanged();
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + comparable25 + "' != '" + (byte) 1 + "'", comparable25.equals((byte) 1));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year8.previous();
        java.util.Date date14 = year8.getEnd();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date14);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(date14);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 2019L);
        java.lang.Class<?> wildcardClass13 = year8.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.String str2 = seriesChangeEvent1.toString();
        java.lang.String str3 = seriesChangeEvent1.toString();
        java.lang.String str4 = seriesChangeEvent1.toString();
        java.lang.Object obj5 = seriesChangeEvent1.getSource();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) seriesChangeEvent1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=0]" + "'", str2.equals("org.jfree.data.general.SeriesChangeEvent[source=0]"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=0]" + "'", str3.equals("org.jfree.data.general.SeriesChangeEvent[source=0]"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=0]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=0]"));
        org.junit.Assert.assertTrue("'" + obj5 + "' != '" + (byte) 0 + "'", obj5.equals((byte) 0));
    }

//    @Test
//    public void test470() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test470");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getMiddleMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(serialDate3);
//        java.lang.Object obj5 = null;
//        boolean boolean6 = day4.equals(obj5);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560452399999L + "'", long2 == 1560452399999L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMinEndIndex();
        boolean boolean6 = timePeriodValues1.isEmpty();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        int int8 = timePeriodValues1.getMaxMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener9);
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues12.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues12.removePropertyChangeListener(propertyChangeListener15);
        int int17 = timePeriodValues12.getItemCount();
        int int18 = timePeriodValues12.getMaxMiddleIndex();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        timePeriodValues12.add((org.jfree.data.time.TimePeriod) year19, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue23 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year19, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year19.previous();
        java.lang.String str25 = year19.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year19.next();
        java.lang.Number number27 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue28 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod26, number27);
        timePeriodValues1.add(timePeriodValue28);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "2019" + "'", str25.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod26);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues7.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues7.removePropertyChangeListener(propertyChangeListener10);
        int int12 = timePeriodValues7.getItemCount();
        int int13 = timePeriodValues7.getMaxMiddleIndex();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        timePeriodValues7.add((org.jfree.data.time.TimePeriod) year14, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue18 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year14.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod19, (double) 2019L);
        int int22 = timePeriodValues1.getMinEndIndex();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue24 = timePeriodValues1.getDataItem(2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
    }

//    @Test
//    public void test473() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test473");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        int int2 = day0.getYear();
//        long long3 = day0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.next();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = regularTimePeriod4.getMiddleMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43629L + "'", long3 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(serialDate1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(serialDate1);
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) serialDate1);
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        timePeriodValues1.setKey((java.lang.Comparable) 100L);
        timePeriodValues1.setKey((java.lang.Comparable) (short) 100);
        java.lang.String str8 = timePeriodValues1.getRangeDescription();
        int int9 = timePeriodValues1.getMinStartIndex();
        timePeriodValues1.delete(11, 8);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Value" + "'", str8.equals("Value"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

//    @Test
//    public void test476() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test476");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        int int2 = day0.getMonth();
//        java.util.Date date3 = day0.getEnd();
//        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        timePeriodValues5.setNotify(true);
//        java.beans.PropertyChangeListener propertyChangeListener8 = null;
//        timePeriodValues5.removePropertyChangeListener(propertyChangeListener8);
//        int int10 = timePeriodValues5.getItemCount();
//        int int11 = timePeriodValues5.getMaxMiddleIndex();
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
//        timePeriodValues5.add((org.jfree.data.time.TimePeriod) year12, (double) 6);
//        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year12, (java.lang.Number) 2019L);
//        java.util.Date date17 = year12.getEnd();
//        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener20 = null;
//        timePeriodValues19.addChangeListener(seriesChangeListener20);
//        int int22 = timePeriodValues19.getMinMiddleIndex();
//        java.lang.Class<?> wildcardClass23 = timePeriodValues19.getClass();
//        java.util.Date date24 = null;
//        java.util.TimeZone timeZone25 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date24, timeZone25);
//        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        timePeriodValues28.setNotify(true);
//        java.beans.PropertyChangeListener propertyChangeListener31 = null;
//        timePeriodValues28.removePropertyChangeListener(propertyChangeListener31);
//        int int33 = timePeriodValues28.getItemCount();
//        int int34 = timePeriodValues28.getMaxMiddleIndex();
//        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
//        timePeriodValues28.add((org.jfree.data.time.TimePeriod) year35, (double) 6);
//        org.jfree.data.time.TimePeriodValue timePeriodValue39 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year35, (java.lang.Number) 2019L);
//        java.util.Date date40 = year35.getEnd();
//        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date40, timeZone41);
//        org.jfree.data.time.TimePeriodValues timePeriodValues44 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        timePeriodValues44.setNotify(true);
//        java.beans.PropertyChangeListener propertyChangeListener47 = null;
//        timePeriodValues44.removePropertyChangeListener(propertyChangeListener47);
//        int int49 = timePeriodValues44.getItemCount();
//        int int50 = timePeriodValues44.getMaxMiddleIndex();
//        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year();
//        timePeriodValues44.add((org.jfree.data.time.TimePeriod) year51, (double) 6);
//        org.jfree.data.time.TimePeriodValue timePeriodValue55 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year51, (java.lang.Number) 2019L);
//        java.util.Date date56 = year51.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod57 = new org.jfree.data.time.SimpleTimePeriod(date40, date56);
//        long long58 = simpleTimePeriod57.getEndMillis();
//        long long59 = simpleTimePeriod57.getStartMillis();
//        boolean boolean61 = simpleTimePeriod57.equals((java.lang.Object) 0);
//        java.util.Date date62 = simpleTimePeriod57.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues64 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        timePeriodValues64.setNotify(true);
//        java.beans.PropertyChangeListener propertyChangeListener67 = null;
//        timePeriodValues64.removePropertyChangeListener(propertyChangeListener67);
//        int int69 = timePeriodValues64.getItemCount();
//        int int70 = timePeriodValues64.getMaxMiddleIndex();
//        org.jfree.data.time.Year year71 = new org.jfree.data.time.Year();
//        timePeriodValues64.add((org.jfree.data.time.TimePeriod) year71, (double) 6);
//        org.jfree.data.time.TimePeriodValue timePeriodValue75 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year71, (java.lang.Number) 2019L);
//        java.util.Date date76 = year71.getEnd();
//        org.jfree.data.time.Year year77 = new org.jfree.data.time.Year(date76);
//        java.util.TimeZone timeZone78 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day79 = new org.jfree.data.time.Day(date76, timeZone78);
//        org.jfree.data.time.Day day80 = new org.jfree.data.time.Day(date62, timeZone78);
//        org.jfree.data.time.Day day81 = new org.jfree.data.time.Day(date17, timeZone78);
//        org.jfree.data.time.Day day82 = new org.jfree.data.time.Day(date3, timeZone78);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass23);
//        org.junit.Assert.assertNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNotNull(timeZone41);
//        org.junit.Assert.assertNull(regularTimePeriod42);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1577865599999L + "'", long58 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 1577865599999L + "'", long59 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
//        org.junit.Assert.assertNotNull(date62);
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + (-1) + "'", int70 == (-1));
//        org.junit.Assert.assertNotNull(date76);
//        org.junit.Assert.assertNotNull(timeZone78);
//    }

//    @Test
//    public void test477() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test477");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getMiddleMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate5 = day4.getSerialDate();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
//        boolean boolean7 = day0.equals((java.lang.Object) serialDate5);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(serialDate5);
//        org.jfree.data.time.SerialDate serialDate9 = day8.getSerialDate();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560452399999L + "'", long2 == 1560452399999L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(serialDate9);
//    }

//    @Test
//    public void test478() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test478");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
//        long long3 = year2.getSerialIndex();
//        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year2, (java.lang.Number) 100);
//        java.lang.Object obj6 = timePeriodValue5.clone();
//        int int7 = day0.compareTo(obj6);
//        int int8 = day0.getDayOfMonth();
//        java.util.Calendar calendar9 = null;
//        try {
//            day0.peg(calendar9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
//        org.junit.Assert.assertNotNull(obj6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 13 + "'", int8 == 13);
//    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 2019L);
        java.util.Date date13 = year8.getEnd();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date13);
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date13, timeZone15);
        long long17 = day16.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day16.next();
        int int19 = day16.getDayOfMonth();
        java.util.Calendar calendar20 = null;
        try {
            long long21 = day16.getLastMillisecond(calendar20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 43830L + "'", long17 == 43830L);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 31 + "'", int19 == 31);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener13);
        int int15 = timePeriodValues10.getItemCount();
        int int16 = timePeriodValues10.getMaxMiddleIndex();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) year17, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 2019L);
        java.util.Date date22 = year17.getEnd();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date22, timeZone23);
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues26.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timePeriodValues26.removePropertyChangeListener(propertyChangeListener29);
        int int31 = timePeriodValues26.getItemCount();
        int int32 = timePeriodValues26.getMaxMiddleIndex();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        timePeriodValues26.add((org.jfree.data.time.TimePeriod) year33, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue37 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year33, (java.lang.Number) 2019L);
        java.util.Date date38 = year33.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(date22, date38);
        java.util.TimeZone timeZone40 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year(date22, timeZone40);
        java.util.Date date42 = year41.getEnd();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(timeZone40);
        org.junit.Assert.assertNotNull(date42);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 100);
        timePeriodValue3.setValue((java.lang.Number) 3);
        org.jfree.data.time.TimePeriod timePeriod6 = timePeriodValue3.getPeriod();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) timePeriod6, "31-December-2019", "Value");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(timePeriod6);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        java.util.Date date0 = null;
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues2.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues2.removePropertyChangeListener(propertyChangeListener5);
        int int7 = timePeriodValues2.getItemCount();
        int int8 = timePeriodValues2.getMaxMiddleIndex();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        timePeriodValues2.add((org.jfree.data.time.TimePeriod) year9, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year9, (java.lang.Number) 2019L);
        java.util.Date date14 = year9.getEnd();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date14);
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date14, timeZone16);
        long long18 = day17.getSerialIndex();
        java.util.Date date19 = day17.getEnd();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        long long21 = year20.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue23 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year20, (java.lang.Number) 100);
        java.util.Date date24 = year20.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener27 = null;
        timePeriodValues26.addChangeListener(seriesChangeListener27);
        int int29 = timePeriodValues26.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass30 = timePeriodValues26.getClass();
        java.util.Date date31 = null;
        java.util.TimeZone timeZone32 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date31, timeZone32);
        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues35.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener38 = null;
        timePeriodValues35.removePropertyChangeListener(propertyChangeListener38);
        int int40 = timePeriodValues35.getItemCount();
        int int41 = timePeriodValues35.getMaxMiddleIndex();
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
        timePeriodValues35.add((org.jfree.data.time.TimePeriod) year42, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue46 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year42, (java.lang.Number) 2019L);
        java.util.Date date47 = year42.getEnd();
        java.util.TimeZone timeZone48 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date47, timeZone48);
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year(date24, timeZone48);
        org.jfree.data.time.TimePeriodValues timePeriodValues52 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener53 = null;
        timePeriodValues52.addChangeListener(seriesChangeListener53);
        int int55 = timePeriodValues52.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass56 = timePeriodValues52.getClass();
        java.util.Date date57 = null;
        java.util.TimeZone timeZone58 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass56, date57, timeZone58);
        org.jfree.data.time.TimePeriodValues timePeriodValues61 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues61.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener64 = null;
        timePeriodValues61.removePropertyChangeListener(propertyChangeListener64);
        int int66 = timePeriodValues61.getItemCount();
        int int67 = timePeriodValues61.getMaxMiddleIndex();
        org.jfree.data.time.Year year68 = new org.jfree.data.time.Year();
        timePeriodValues61.add((org.jfree.data.time.TimePeriod) year68, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue72 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year68, (java.lang.Number) 2019L);
        java.util.Date date73 = year68.getEnd();
        java.util.TimeZone timeZone74 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass56, date73, timeZone74);
        org.jfree.data.time.TimePeriodValues timePeriodValues77 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues77.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener80 = null;
        timePeriodValues77.removePropertyChangeListener(propertyChangeListener80);
        int int82 = timePeriodValues77.getItemCount();
        int int83 = timePeriodValues77.getMaxMiddleIndex();
        org.jfree.data.time.Year year84 = new org.jfree.data.time.Year();
        timePeriodValues77.add((org.jfree.data.time.TimePeriod) year84, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue88 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year84, (java.lang.Number) 2019L);
        java.util.Date date89 = year84.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod90 = new org.jfree.data.time.SimpleTimePeriod(date73, date89);
        java.util.TimeZone timeZone91 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year92 = new org.jfree.data.time.Year(date73, timeZone91);
        org.jfree.data.time.Year year93 = new org.jfree.data.time.Year(date24, timeZone91);
        org.jfree.data.time.Day day94 = new org.jfree.data.time.Day(date19, timeZone91);
        try {
            org.jfree.data.time.Day day95 = new org.jfree.data.time.Day(date0, timeZone91);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 43830L + "'", long18 == 43830L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 2019L + "'", long21 == 2019L);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(timeZone48);
        org.junit.Assert.assertNull(regularTimePeriod49);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-1) + "'", int55 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass56);
        org.junit.Assert.assertNull(regularTimePeriod59);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + (-1) + "'", int67 == (-1));
        org.junit.Assert.assertNotNull(date73);
        org.junit.Assert.assertNotNull(timeZone74);
        org.junit.Assert.assertNull(regularTimePeriod75);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 0 + "'", int82 == 0);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + (-1) + "'", int83 == (-1));
        org.junit.Assert.assertNotNull(date89);
        org.junit.Assert.assertNotNull(timeZone91);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        boolean boolean6 = timePeriodValues1.getNotify();
        try {
            timePeriodValues1.update((int) (short) 100, (java.lang.Number) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        timePeriodValues1.setNotify(true);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener10);
        java.lang.Class<?> wildcardClass12 = timePeriodValues1.getClass();
        timePeriodValues1.setDomainDescription("TimePeriodValue[2019,3]");
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        timePeriodValues1.setKey((java.lang.Comparable) "hi!");
        timePeriodValues1.setDescription("Value");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener8);
        int int10 = timePeriodValues1.getMinEndIndex();
        try {
            org.jfree.data.time.TimePeriod timePeriod12 = timePeriodValues1.getTimePeriod((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener13);
        int int15 = timePeriodValues10.getItemCount();
        int int16 = timePeriodValues10.getMaxMiddleIndex();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) year17, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 2019L);
        java.util.Date date22 = year17.getEnd();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date22, timeZone23);
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues26.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timePeriodValues26.removePropertyChangeListener(propertyChangeListener29);
        int int31 = timePeriodValues26.getItemCount();
        int int32 = timePeriodValues26.getMaxMiddleIndex();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        timePeriodValues26.add((org.jfree.data.time.TimePeriod) year33, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue37 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year33, (java.lang.Number) 2019L);
        java.util.Date date38 = year33.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(date22, date38);
        long long40 = simpleTimePeriod39.getEndMillis();
        long long41 = simpleTimePeriod39.getStartMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues43 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues43.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener46 = null;
        timePeriodValues43.removePropertyChangeListener(propertyChangeListener46);
        int int48 = timePeriodValues43.getItemCount();
        int int49 = timePeriodValues43.getMaxMiddleIndex();
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
        timePeriodValues43.add((org.jfree.data.time.TimePeriod) year50, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue54 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year50, (java.lang.Number) 2019L);
        java.util.Date date55 = year50.getEnd();
        long long56 = year50.getFirstMillisecond();
        boolean boolean57 = simpleTimePeriod39.equals((java.lang.Object) long56);
        org.jfree.data.time.TimePeriodValues timePeriodValues59 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues59.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener62 = null;
        timePeriodValues59.removePropertyChangeListener(propertyChangeListener62);
        java.lang.String str64 = timePeriodValues59.getDescription();
        int int65 = timePeriodValues59.getMinStartIndex();
        int int66 = timePeriodValues59.getMaxEndIndex();
        timePeriodValues59.setDomainDescription("");
        java.beans.PropertyChangeListener propertyChangeListener69 = null;
        timePeriodValues59.removePropertyChangeListener(propertyChangeListener69);
        java.lang.String str71 = timePeriodValues59.getDomainDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener72 = null;
        timePeriodValues59.addChangeListener(seriesChangeListener72);
        int int74 = timePeriodValues59.getMinEndIndex();
        java.beans.PropertyChangeListener propertyChangeListener75 = null;
        timePeriodValues59.addPropertyChangeListener(propertyChangeListener75);
        int int77 = timePeriodValues59.getMinMiddleIndex();
        try {
            int int78 = simpleTimePeriod39.compareTo((java.lang.Object) int77);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Integer cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1577865599999L + "'", long40 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1577865599999L + "'", long41 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1546329600000L + "'", long56 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNull(str64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + (-1) + "'", int65 == (-1));
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + (-1) + "'", int66 == (-1));
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "" + "'", str71.equals(""));
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + (-1) + "'", int74 == (-1));
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + (-1) + "'", int77 == (-1));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 2019L);
        java.lang.Class<?> wildcardClass13 = year8.getClass();
        long long14 = year8.getSerialIndex();
        java.util.Calendar calendar15 = null;
        try {
            long long16 = year8.getLastMillisecond(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2019L + "'", long14 == 2019L);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMinEndIndex();
        java.lang.String str6 = timePeriodValues1.getRangeDescription();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year7.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod9, (java.lang.Number) 6);
        java.util.Date date12 = regularTimePeriod9.getStart();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Value" + "'", str6.equals("Value"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date12);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        timePeriodValues1.setKey((java.lang.Comparable) 100L);
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues7.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues7.removePropertyChangeListener(propertyChangeListener10);
        int int12 = timePeriodValues7.getItemCount();
        int int13 = timePeriodValues7.getMaxMiddleIndex();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        timePeriodValues7.add((org.jfree.data.time.TimePeriod) year14, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue18 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year14.previous();
        timePeriodValues1.setKey((java.lang.Comparable) year14);
        java.lang.String str21 = year14.toString();
        long long22 = year14.getSerialIndex();
        java.lang.Object obj23 = null;
        boolean boolean24 = year14.equals(obj23);
        java.util.Date date25 = year14.getEnd();
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2019" + "'", str21.equals("2019"));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 2019L + "'", long22 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(date25);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues1);
        java.lang.String str5 = seriesChangeEvent4.toString();
        java.lang.String str6 = seriesChangeEvent4.toString();
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        int int11 = timePeriodValues1.getMaxEndIndex();
        java.lang.String str12 = timePeriodValues1.getRangeDescription();
        timePeriodValues1.setKey((java.lang.Comparable) 7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener15);
        timePeriodValues1.setRangeDescription("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener19 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener19);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Value" + "'", str12.equals("Value"));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        try {
            java.lang.Number number12 = timePeriodValues1.getValue((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener7);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timePeriodValues10.addChangeListener(seriesChangeListener11);
        int int13 = timePeriodValues10.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass14 = timePeriodValues10.getClass();
        java.util.Date date15 = null;
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass14, date15, timeZone16);
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues19.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timePeriodValues19.removePropertyChangeListener(propertyChangeListener22);
        int int24 = timePeriodValues19.getItemCount();
        int int25 = timePeriodValues19.getMaxMiddleIndex();
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        timePeriodValues19.add((org.jfree.data.time.TimePeriod) year26, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue30 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year26, (java.lang.Number) 2019L);
        java.util.Date date31 = year26.getEnd();
        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass14, date31, timeZone32);
        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues35.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener38 = null;
        timePeriodValues35.removePropertyChangeListener(propertyChangeListener38);
        int int40 = timePeriodValues35.getItemCount();
        int int41 = timePeriodValues35.getMaxMiddleIndex();
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
        timePeriodValues35.add((org.jfree.data.time.TimePeriod) year42, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue46 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year42, (java.lang.Number) 2019L);
        java.util.Date date47 = year42.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod48 = new org.jfree.data.time.SimpleTimePeriod(date31, date47);
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year(date31, timeZone49);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = year50.previous();
        timePeriodValues1.setKey((java.lang.Comparable) regularTimePeriod51);
        timePeriodValues1.setDomainDescription("TimePeriodValue[2019,100]");
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNotNull(regularTimePeriod51);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 100);
        java.util.Date date4 = year0.getStart();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) (short) 0);
        int int7 = year0.getYear();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("TimePeriodValue[2019,100]");
        java.lang.Throwable throwable2 = null;
        try {
            timePeriodFormatException1.addSuppressed(throwable2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year8.previous();
        java.lang.String str14 = year8.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year8.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year8.previous();
        long long17 = regularTimePeriod16.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019" + "'", str14.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1530561599999L + "'", long17 == 1530561599999L);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        timePeriodValues1.setKey((java.lang.Comparable) 100L);
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues7.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues7.removePropertyChangeListener(propertyChangeListener10);
        int int12 = timePeriodValues7.getItemCount();
        int int13 = timePeriodValues7.getMaxMiddleIndex();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        timePeriodValues7.add((org.jfree.data.time.TimePeriod) year14, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue18 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year14.previous();
        timePeriodValues1.setKey((java.lang.Comparable) year14);
        java.lang.String str21 = year14.toString();
        long long22 = year14.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2019" + "'", str21.equals("2019"));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1577865599999L + "'", long22 == 1577865599999L);
    }

//    @Test
//    public void test498() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test498");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass1 = day0.getClass();
//        long long2 = day0.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0, "Time", "2019");
//        java.lang.String str6 = timePeriodValues5.getDescription();
//        org.junit.Assert.assertNotNull(wildcardClass1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560495599999L + "'", long2 == 1560495599999L);
//        org.junit.Assert.assertNull(str6);
//    }

//    @Test
//    public void test499() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test499");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        int int4 = timePeriodValues1.getMinMiddleIndex();
//        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
//        java.util.Date date6 = null;
//        java.util.TimeZone timeZone7 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
//        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        timePeriodValues10.setNotify(true);
//        java.beans.PropertyChangeListener propertyChangeListener13 = null;
//        timePeriodValues10.removePropertyChangeListener(propertyChangeListener13);
//        int int15 = timePeriodValues10.getItemCount();
//        int int16 = timePeriodValues10.getMaxMiddleIndex();
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
//        timePeriodValues10.add((org.jfree.data.time.TimePeriod) year17, (double) 6);
//        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 2019L);
//        java.util.Date date22 = year17.getEnd();
//        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date22, timeZone23);
//        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        timePeriodValues26.setNotify(true);
//        java.beans.PropertyChangeListener propertyChangeListener29 = null;
//        timePeriodValues26.removePropertyChangeListener(propertyChangeListener29);
//        int int31 = timePeriodValues26.getItemCount();
//        int int32 = timePeriodValues26.getMaxMiddleIndex();
//        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
//        timePeriodValues26.add((org.jfree.data.time.TimePeriod) year33, (double) 6);
//        org.jfree.data.time.TimePeriodValue timePeriodValue37 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year33, (java.lang.Number) 2019L);
//        java.util.Date date38 = year33.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(date22, date38);
//        long long40 = simpleTimePeriod39.getEndMillis();
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
//        int int42 = day41.getMonth();
//        long long43 = day41.getMiddleMillisecond();
//        org.jfree.data.time.SerialDate serialDate44 = day41.getSerialDate();
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate46 = day45.getSerialDate();
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(serialDate46);
//        boolean boolean48 = day41.equals((java.lang.Object) serialDate46);
//        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day(serialDate46);
//        boolean boolean50 = simpleTimePeriod39.equals((java.lang.Object) day49);
//        org.jfree.data.time.TimePeriodValues timePeriodValues52 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        timePeriodValues52.setNotify(true);
//        java.beans.PropertyChangeListener propertyChangeListener55 = null;
//        timePeriodValues52.removePropertyChangeListener(propertyChangeListener55);
//        java.lang.String str57 = timePeriodValues52.getDescription();
//        int int58 = timePeriodValues52.getMinStartIndex();
//        int int59 = timePeriodValues52.getMaxEndIndex();
//        timePeriodValues52.setDomainDescription("");
//        timePeriodValues52.setKey((java.lang.Comparable) ' ');
//        int int64 = timePeriodValues52.getMinStartIndex();
//        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day();
//        int int66 = day65.getYear();
//        int int67 = day65.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = day65.previous();
//        timePeriodValues52.add((org.jfree.data.time.TimePeriod) regularTimePeriod68, (double) (-201));
//        try {
//            int int71 = simpleTimePeriod39.compareTo((java.lang.Object) (-201));
//            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Integer cannot be cast to org.jfree.data.time.TimePeriod");
//        } catch (java.lang.ClassCastException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(timeZone23);
//        org.junit.Assert.assertNull(regularTimePeriod24);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1577865599999L + "'", long40 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 6 + "'", int42 == 6);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1560452399999L + "'", long43 == 1560452399999L);
//        org.junit.Assert.assertNotNull(serialDate44);
//        org.junit.Assert.assertNotNull(serialDate46);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertNull(str57);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + (-1) + "'", int58 == (-1));
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-1) + "'", int59 == (-1));
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + (-1) + "'", int64 == (-1));
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 2019 + "'", int66 == 2019);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 2019 + "'", int67 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod68);
//    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        int int11 = timePeriodValues1.getMaxMiddleIndex();
        timePeriodValues1.setNotify(true);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener14);
        int int16 = timePeriodValues1.getMaxStartIndex();
        java.lang.String str17 = timePeriodValues1.getRangeDescription();
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Value" + "'", str17.equals("Value"));
    }
}

