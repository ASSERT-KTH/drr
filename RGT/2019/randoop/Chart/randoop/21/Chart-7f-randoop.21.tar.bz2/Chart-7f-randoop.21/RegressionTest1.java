import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year8.previous();
        java.util.Date date14 = year8.getEnd();
        java.util.Calendar calendar15 = null;
        try {
            long long16 = year8.getFirstMillisecond(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(date14);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) '4');
        java.lang.String str2 = seriesChangeEvent1.toString();
        java.lang.String str3 = seriesChangeEvent1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=4]" + "'", str2.equals("org.jfree.data.general.SeriesChangeEvent[source=4]"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=4]" + "'", str3.equals("org.jfree.data.general.SeriesChangeEvent[source=4]"));
    }

//    @Test
//    public void test003() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test003");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass1 = day0.getClass();
//        long long2 = day0.getLastMillisecond();
//        java.lang.String str3 = day0.toString();
//        int int4 = day0.getYear();
//        long long5 = day0.getSerialIndex();
//        org.junit.Assert.assertNotNull(wildcardClass1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560495599999L + "'", long2 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43629L + "'", long5 == 43629L);
//    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        timePeriodValues1.setKey((java.lang.Comparable) 100L);
        int int6 = timePeriodValues1.getMaxStartIndex();
        int int7 = timePeriodValues1.getMaxStartIndex();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 2019L);
        java.lang.Class<?> wildcardClass13 = year8.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues15.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timePeriodValues15.removePropertyChangeListener(propertyChangeListener18);
        int int20 = timePeriodValues15.getItemCount();
        int int21 = timePeriodValues15.getMaxMiddleIndex();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        timePeriodValues15.add((org.jfree.data.time.TimePeriod) year22, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue26 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year22, (java.lang.Number) 2019L);
        boolean boolean27 = year8.equals((java.lang.Object) 2019L);
        long long28 = year8.getSerialIndex();
        java.util.Calendar calendar29 = null;
        try {
            year8.peg(calendar29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 2019L + "'", long28 == 2019L);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMinEndIndex();
        boolean boolean6 = timePeriodValues1.isEmpty();
        java.lang.Class<?> wildcardClass7 = timePeriodValues1.getClass();
        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass7);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(class8);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        timePeriodValues1.setKey((java.lang.Comparable) "hi!");
        timePeriodValues1.setDescription("Value");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener8);
        timePeriodValues1.setRangeDescription("31-December-2019");
        try {
            org.jfree.data.time.TimePeriod timePeriod13 = timePeriodValues1.getTimePeriod(11);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 11, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("TimePeriodValue[13-June-2019,8.0]");
        java.lang.String str2 = seriesException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: TimePeriodValue[13-June-2019,8.0]" + "'", str2.equals("org.jfree.data.general.SeriesException: TimePeriodValue[13-June-2019,8.0]"));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        java.lang.String str11 = year8.toString();
        java.lang.String str12 = year8.toString();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2019" + "'", str11.equals("2019"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2019" + "'", str12.equals("2019"));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        timePeriodValues1.delete((int) (byte) 1, (int) (byte) 0);
        int int7 = timePeriodValues1.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        int int11 = timePeriodValues1.getMinMiddleIndex();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) ' ');
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues16.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timePeriodValues16.removePropertyChangeListener(propertyChangeListener19);
        int int21 = timePeriodValues16.getItemCount();
        int int22 = timePeriodValues16.getMaxMiddleIndex();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        timePeriodValues16.add((org.jfree.data.time.TimePeriod) year23, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue27 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year23, (java.lang.Number) 2019L);
        java.util.Date date28 = year23.getEnd();
        boolean boolean29 = simpleTimePeriod14.equals((java.lang.Object) date28);
        org.jfree.data.time.TimePeriodValues timePeriodValues31 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener32 = null;
        timePeriodValues31.addChangeListener(seriesChangeListener32);
        int int34 = timePeriodValues31.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass35 = timePeriodValues31.getClass();
        java.util.Date date36 = null;
        java.util.TimeZone timeZone37 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass35, date36, timeZone37);
        org.jfree.data.time.TimePeriodValues timePeriodValues40 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues40.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener43 = null;
        timePeriodValues40.removePropertyChangeListener(propertyChangeListener43);
        int int45 = timePeriodValues40.getItemCount();
        int int46 = timePeriodValues40.getMaxMiddleIndex();
        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year();
        timePeriodValues40.add((org.jfree.data.time.TimePeriod) year47, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue51 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year47, (java.lang.Number) 2019L);
        java.util.Date date52 = year47.getEnd();
        java.util.TimeZone timeZone53 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass35, date52, timeZone53);
        org.jfree.data.time.TimePeriodValues timePeriodValues56 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues56.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener59 = null;
        timePeriodValues56.removePropertyChangeListener(propertyChangeListener59);
        int int61 = timePeriodValues56.getItemCount();
        int int62 = timePeriodValues56.getMaxMiddleIndex();
        org.jfree.data.time.Year year63 = new org.jfree.data.time.Year();
        timePeriodValues56.add((org.jfree.data.time.TimePeriod) year63, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue67 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year63, (java.lang.Number) 2019L);
        java.util.Date date68 = year63.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod69 = new org.jfree.data.time.SimpleTimePeriod(date52, date68);
        org.jfree.data.time.TimePeriodValues timePeriodValues71 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues71.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener74 = null;
        timePeriodValues71.removePropertyChangeListener(propertyChangeListener74);
        java.lang.String str76 = timePeriodValues71.getDescription();
        int int77 = timePeriodValues71.getMinStartIndex();
        timePeriodValues71.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues82 = timePeriodValues71.createCopy(0, 1);
        boolean boolean83 = simpleTimePeriod69.equals((java.lang.Object) 0);
        java.util.Date date84 = simpleTimePeriod69.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod85 = new org.jfree.data.time.SimpleTimePeriod(date28, date84);
        timePeriodValues1.setKey((java.lang.Comparable) simpleTimePeriod85);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertNull(regularTimePeriod38);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertNotNull(timeZone53);
        org.junit.Assert.assertNull(regularTimePeriod54);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-1) + "'", int62 == (-1));
        org.junit.Assert.assertNotNull(date68);
        org.junit.Assert.assertNull(str76);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + (-1) + "'", int77 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNotNull(date84);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        timePeriodValues1.setKey((java.lang.Comparable) 100L);
        timePeriodValues1.setKey((java.lang.Comparable) (short) 100);
        java.lang.String str8 = timePeriodValues1.getRangeDescription();
        int int9 = timePeriodValues1.getMaxMiddleIndex();
        timePeriodValues1.fireSeriesChanged();
        int int11 = timePeriodValues1.getMaxStartIndex();
        try {
            java.lang.Number number13 = timePeriodValues1.getValue((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Value" + "'", str8.equals("Value"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        timePeriodValues1.setKey((java.lang.Comparable) 100L);
        timePeriodValues1.setKey((java.lang.Comparable) (short) 100);
        java.lang.String str8 = timePeriodValues1.getRangeDescription();
        int int9 = timePeriodValues1.getMinStartIndex();
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener10);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Value" + "'", str8.equals("Value"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        int int9 = timePeriodValues1.getMinEndIndex();
        int int10 = timePeriodValues1.getItemCount();
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues12.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues12.removePropertyChangeListener(propertyChangeListener15);
        int int17 = timePeriodValues12.getItemCount();
        int int18 = timePeriodValues12.getMaxMiddleIndex();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        timePeriodValues12.add((org.jfree.data.time.TimePeriod) year19, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue23 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year19, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year19.previous();
        java.lang.String str25 = year19.toString();
        long long26 = year19.getFirstMillisecond();
        timePeriodValues1.setKey((java.lang.Comparable) year19);
        long long28 = year19.getLastMillisecond();
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "2019" + "'", str25.equals("2019"));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1546329600000L + "'", long26 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1577865599999L + "'", long28 == 1577865599999L);
    }

//    @Test
//    public void test015() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test015");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        timePeriodValues1.setNotify(true);
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
//        java.lang.String str6 = timePeriodValues1.getDescription();
//        int int7 = timePeriodValues1.getMinStartIndex();
//        int int8 = timePeriodValues1.getMaxEndIndex();
//        timePeriodValues1.setDomainDescription("");
//        java.beans.PropertyChangeListener propertyChangeListener11 = null;
//        timePeriodValues1.removePropertyChangeListener(propertyChangeListener11);
//        java.lang.String str13 = timePeriodValues1.getDomainDescription();
//        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        timePeriodValues15.setNotify(true);
//        java.beans.PropertyChangeListener propertyChangeListener18 = null;
//        timePeriodValues15.removePropertyChangeListener(propertyChangeListener18);
//        java.lang.String str20 = timePeriodValues15.getDescription();
//        int int21 = timePeriodValues15.getMinStartIndex();
//        timePeriodValues15.fireSeriesChanged();
//        boolean boolean23 = timePeriodValues1.equals((java.lang.Object) timePeriodValues15);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass25 = day24.getClass();
//        int int26 = day24.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue28 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day24, (double) 8);
//        long long29 = day24.getMiddleMillisecond();
//        timePeriodValues15.add((org.jfree.data.time.TimePeriod) day24, (double) (byte) 10);
//        org.junit.Assert.assertNull(str6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertNull(str20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(wildcardClass25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 6 + "'", int26 == 6);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560452399999L + "'", long29 == 1560452399999L);
//    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=4]");
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

//    @Test
//    public void test017() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test017");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        int int2 = day0.getMonth();
//        int int3 = day0.getYear();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = day0.getFirstMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//    }

//    @Test
//    public void test018() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test018");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        timePeriodValues1.setNotify(true);
//        timePeriodValues1.setKey((java.lang.Comparable) 100L);
//        timePeriodValues1.setKey((java.lang.Comparable) (short) 100);
//        java.lang.String str8 = timePeriodValues1.getRangeDescription();
//        int int9 = timePeriodValues1.getMinStartIndex();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
//        timePeriodValues1.removeChangeListener(seriesChangeListener10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        int int13 = day12.getMonth();
//        long long14 = day12.getMiddleMillisecond();
//        org.jfree.data.time.SerialDate serialDate15 = day12.getSerialDate();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate17 = day16.getSerialDate();
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(serialDate17);
//        boolean boolean19 = day12.equals((java.lang.Object) serialDate17);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(serialDate17);
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day20, (java.lang.Number) 0);
//        int int23 = day20.getDayOfMonth();
//        int int24 = day20.getYear();
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Value" + "'", str8.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560452399999L + "'", long14 == 1560452399999L);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 13 + "'", int23 == 13);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
//    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("TimePeriodValue[13-June-2019,8.0]");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 2019L);
        java.util.Date date13 = year8.getEnd();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date13);
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date13, timeZone15);
        long long17 = day16.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day16.next();
        org.jfree.data.time.SerialDate serialDate19 = day16.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day16.previous();
        long long21 = day16.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 43830L + "'", long17 == 43830L);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1577779200000L + "'", long21 == 1577779200000L);
    }

//    @Test
//    public void test021() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test021");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getMiddleMillisecond();
//        long long3 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate6 = day5.getSerialDate();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate6);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(serialDate6);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(serialDate6);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(serialDate6);
//        boolean boolean11 = day0.equals((java.lang.Object) serialDate6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day0.previous();
//        java.util.Calendar calendar13 = null;
//        try {
//            long long14 = day0.getFirstMillisecond(calendar13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560452399999L + "'", long2 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//    }

//    @Test
//    public void test022() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test022");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        timePeriodValues1.setNotify(true);
//        timePeriodValues1.setKey((java.lang.Comparable) 100L);
//        timePeriodValues1.setKey((java.lang.Comparable) (short) 100);
//        java.lang.String str8 = timePeriodValues1.getRangeDescription();
//        int int9 = timePeriodValues1.getMinStartIndex();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
//        timePeriodValues1.removeChangeListener(seriesChangeListener10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        int int13 = day12.getMonth();
//        long long14 = day12.getMiddleMillisecond();
//        org.jfree.data.time.SerialDate serialDate15 = day12.getSerialDate();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate17 = day16.getSerialDate();
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(serialDate17);
//        boolean boolean19 = day12.equals((java.lang.Object) serialDate17);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(serialDate17);
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day20, (java.lang.Number) 0);
//        org.jfree.data.time.TimePeriod timePeriod23 = null;
//        java.lang.Number number24 = null;
//        try {
//            timePeriodValues1.add(timePeriod23, number24);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Value" + "'", str8.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560452399999L + "'", long14 == 1560452399999L);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        boolean boolean2 = timePeriodValues1.getNotify();
        java.lang.String str3 = timePeriodValues1.getRangeDescription();
        try {
            timePeriodValues1.delete(5, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Value" + "'", str3.equals("Value"));
    }

//    @Test
//    public void test024() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test024");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getSerialIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        timePeriodValues3.setNotify(true);
//        boolean boolean7 = timePeriodValues3.equals((java.lang.Object) (short) 0);
//        boolean boolean8 = year0.equals((java.lang.Object) (short) 0);
//        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        timePeriodValues10.setNotify(true);
//        timePeriodValues10.setKey((java.lang.Comparable) 100L);
//        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        timePeriodValues16.setNotify(true);
//        java.beans.PropertyChangeListener propertyChangeListener19 = null;
//        timePeriodValues16.removePropertyChangeListener(propertyChangeListener19);
//        int int21 = timePeriodValues16.getItemCount();
//        int int22 = timePeriodValues16.getMaxMiddleIndex();
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
//        timePeriodValues16.add((org.jfree.data.time.TimePeriod) year23, (double) 6);
//        org.jfree.data.time.TimePeriodValue timePeriodValue27 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year23, (java.lang.Number) 2019L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year23.previous();
//        timePeriodValues10.setKey((java.lang.Comparable) year23);
//        int int30 = year0.compareTo((java.lang.Object) year23);
//        java.lang.String str31 = year0.toString();
//        long long32 = year0.getSerialIndex();
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate34 = day33.getSerialDate();
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(serialDate34);
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(serialDate34);
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(serialDate34);
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(serialDate34);
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass40 = day39.getClass();
//        long long41 = day39.getLastMillisecond();
//        java.lang.String str42 = day39.toString();
//        long long43 = day39.getFirstMillisecond();
//        java.util.Date date44 = day39.getEnd();
//        int int45 = day38.compareTo((java.lang.Object) day39);
//        int int46 = year0.compareTo((java.lang.Object) day39);
//        java.util.Calendar calendar47 = null;
//        try {
//            year0.peg(calendar47);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "2019" + "'", str31.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 2019L + "'", long32 == 2019L);
//        org.junit.Assert.assertNotNull(serialDate34);
//        org.junit.Assert.assertNotNull(wildcardClass40);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560495599999L + "'", long41 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "13-June-2019" + "'", str42.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1560409200000L + "'", long43 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
//    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year11, (java.lang.Number) 100);
        timePeriodValues1.add(timePeriodValue14);
        java.lang.String str16 = timePeriodValues1.getDescription();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 100);
        java.util.Date date21 = year17.getStart();
        org.jfree.data.time.TimePeriodValue timePeriodValue23 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) (short) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues25.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener28 = null;
        timePeriodValues25.removePropertyChangeListener(propertyChangeListener28);
        java.lang.String str30 = timePeriodValues25.getDescription();
        boolean boolean31 = year17.equals((java.lang.Object) timePeriodValues25);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 43629L);
        timePeriodValues1.setRangeDescription("2019");
        java.beans.PropertyChangeListener propertyChangeListener36 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener36);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2019L + "'", long12 == 2019L);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2019L + "'", long18 == 2019L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

//    @Test
//    public void test026() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test026");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass1 = day0.getClass();
//        long long2 = day0.getLastMillisecond();
//        long long3 = day0.getMiddleMillisecond();
//        int int4 = day0.getMonth();
//        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        timePeriodValues6.setNotify(true);
//        java.beans.PropertyChangeListener propertyChangeListener9 = null;
//        timePeriodValues6.removePropertyChangeListener(propertyChangeListener9);
//        int int11 = timePeriodValues6.getItemCount();
//        int int12 = timePeriodValues6.getMaxMiddleIndex();
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
//        timePeriodValues6.add((org.jfree.data.time.TimePeriod) year13, (double) 6);
//        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year13, (java.lang.Number) 2019L);
//        java.util.Date date18 = year13.getEnd();
//        long long19 = year13.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass20 = year13.getClass();
//        java.lang.Class class21 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass20);
//        boolean boolean22 = day0.equals((java.lang.Object) class21);
//        org.junit.Assert.assertNotNull(wildcardClass1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560495599999L + "'", long2 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560452399999L + "'", long3 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1562097599999L + "'", long19 == 1562097599999L);
//        org.junit.Assert.assertNotNull(wildcardClass20);
//        org.junit.Assert.assertNotNull(class21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.String str5 = timePeriodFormatException3.toString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesChangeEvent[source=0]" + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesChangeEvent[source=0]"));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 100);
        java.util.Date date4 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues6.addChangeListener(seriesChangeListener7);
        int int9 = timePeriodValues6.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass10 = timePeriodValues6.getClass();
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date11, timeZone12);
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues15.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timePeriodValues15.removePropertyChangeListener(propertyChangeListener18);
        int int20 = timePeriodValues15.getItemCount();
        int int21 = timePeriodValues15.getMaxMiddleIndex();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        timePeriodValues15.add((org.jfree.data.time.TimePeriod) year22, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue26 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year22, (java.lang.Number) 2019L);
        java.util.Date date27 = year22.getEnd();
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date27, timeZone28);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(date4, timeZone28);
        org.jfree.data.time.TimePeriodValues timePeriodValues32 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener33 = null;
        timePeriodValues32.addChangeListener(seriesChangeListener33);
        int int35 = timePeriodValues32.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass36 = timePeriodValues32.getClass();
        java.util.Date date37 = null;
        java.util.TimeZone timeZone38 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date37, timeZone38);
        org.jfree.data.time.TimePeriodValues timePeriodValues41 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues41.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener44 = null;
        timePeriodValues41.removePropertyChangeListener(propertyChangeListener44);
        int int46 = timePeriodValues41.getItemCount();
        int int47 = timePeriodValues41.getMaxMiddleIndex();
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year();
        timePeriodValues41.add((org.jfree.data.time.TimePeriod) year48, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue52 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year48, (java.lang.Number) 2019L);
        java.util.Date date53 = year48.getEnd();
        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date53, timeZone54);
        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year(date4, timeZone54);
        java.util.TimeZone timeZone57 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(date4, timeZone57);
        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day(date4);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertNotNull(timeZone54);
        org.junit.Assert.assertNull(regularTimePeriod55);
        org.junit.Assert.assertNotNull(timeZone57);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMinEndIndex();
        java.lang.String str6 = timePeriodValues1.getRangeDescription();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year7.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod9, (java.lang.Number) 6);
        java.lang.String str12 = timePeriodValues1.getDomainDescription();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Value" + "'", str6.equals("Value"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Time" + "'", str12.equals("Time"));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues7.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues7.removePropertyChangeListener(propertyChangeListener10);
        int int12 = timePeriodValues7.getItemCount();
        int int13 = timePeriodValues7.getMaxMiddleIndex();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        timePeriodValues7.add((org.jfree.data.time.TimePeriod) year14, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue18 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year14.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod19, (double) 2019L);
        int int22 = timePeriodValues1.getMinEndIndex();
        int int23 = timePeriodValues1.getMaxEndIndex();
        java.lang.String str24 = timePeriodValues1.getRangeDescription();
        timePeriodValues1.setNotify(true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Value" + "'", str24.equals("Value"));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener13);
        int int15 = timePeriodValues10.getItemCount();
        int int16 = timePeriodValues10.getMaxMiddleIndex();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) year17, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 2019L);
        java.util.Date date22 = year17.getEnd();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date22, timeZone23);
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues26.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timePeriodValues26.removePropertyChangeListener(propertyChangeListener29);
        int int31 = timePeriodValues26.getItemCount();
        int int32 = timePeriodValues26.getMaxMiddleIndex();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        timePeriodValues26.add((org.jfree.data.time.TimePeriod) year33, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue37 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year33, (java.lang.Number) 2019L);
        java.util.Date date38 = year33.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(date22, date38);
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date22);
        org.jfree.data.time.SerialDate serialDate41 = day40.getSerialDate();
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(serialDate41);
        long long43 = day42.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1577822399999L + "'", long43 == 1577822399999L);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener13);
        int int15 = timePeriodValues10.getItemCount();
        int int16 = timePeriodValues10.getMaxMiddleIndex();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) year17, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 2019L);
        java.util.Date date22 = year17.getEnd();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date22, timeZone23);
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues26.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timePeriodValues26.removePropertyChangeListener(propertyChangeListener29);
        int int31 = timePeriodValues26.getItemCount();
        int int32 = timePeriodValues26.getMaxMiddleIndex();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        timePeriodValues26.add((org.jfree.data.time.TimePeriod) year33, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue37 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year33, (java.lang.Number) 2019L);
        java.util.Date date38 = year33.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(date22, date38);
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year(date22);
        int int41 = year40.getYear();
        java.util.Calendar calendar42 = null;
        try {
            long long43 = year40.getLastMillisecond(calendar42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 2019 + "'", int41 == 2019);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        int int11 = timePeriodValues1.getMaxEndIndex();
        java.lang.String str12 = timePeriodValues1.getRangeDescription();
        java.lang.Class<?> wildcardClass13 = timePeriodValues1.getClass();
        java.lang.Class<?> wildcardClass14 = timePeriodValues1.getClass();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        long long16 = year15.getSerialIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues18.setNotify(true);
        boolean boolean22 = timePeriodValues18.equals((java.lang.Object) (short) 0);
        boolean boolean23 = year15.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues25.setNotify(true);
        timePeriodValues25.setKey((java.lang.Comparable) 100L);
        org.jfree.data.time.TimePeriodValues timePeriodValues31 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues31.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener34 = null;
        timePeriodValues31.removePropertyChangeListener(propertyChangeListener34);
        int int36 = timePeriodValues31.getItemCount();
        int int37 = timePeriodValues31.getMaxMiddleIndex();
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
        timePeriodValues31.add((org.jfree.data.time.TimePeriod) year38, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue42 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year38, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = year38.previous();
        timePeriodValues25.setKey((java.lang.Comparable) year38);
        int int45 = year15.compareTo((java.lang.Object) year38);
        int int46 = year38.getYear();
        int int48 = year38.compareTo((java.lang.Object) (short) 10);
        timePeriodValues1.setKey((java.lang.Comparable) (short) 10);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Value" + "'", str12.equals("Value"));
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 2019 + "'", int46 == 2019);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        timePeriodValues1.setKey((java.lang.Comparable) 100L);
        java.lang.String str6 = timePeriodValues1.getRangeDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Value" + "'", str6.equals("Value"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        timePeriodValues1.setKey((java.lang.Comparable) 100L);
        timePeriodValues1.setKey((java.lang.Comparable) (short) 100);
        java.lang.String str8 = timePeriodValues1.getRangeDescription();
        int int9 = timePeriodValues1.getMinStartIndex();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year10, (java.lang.Number) 100);
        java.util.Date date14 = year10.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
        timePeriodValues16.addChangeListener(seriesChangeListener17);
        int int19 = timePeriodValues16.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass20 = timePeriodValues16.getClass();
        java.util.Date date21 = null;
        java.util.TimeZone timeZone22 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass20, date21, timeZone22);
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues25.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener28 = null;
        timePeriodValues25.removePropertyChangeListener(propertyChangeListener28);
        int int30 = timePeriodValues25.getItemCount();
        int int31 = timePeriodValues25.getMaxMiddleIndex();
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        timePeriodValues25.add((org.jfree.data.time.TimePeriod) year32, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue36 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year32, (java.lang.Number) 2019L);
        java.util.Date date37 = year32.getEnd();
        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass20, date37, timeZone38);
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year(date14, timeZone38);
        org.jfree.data.time.TimePeriodValues timePeriodValues42 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener43 = null;
        timePeriodValues42.addChangeListener(seriesChangeListener43);
        int int45 = timePeriodValues42.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass46 = timePeriodValues42.getClass();
        java.util.Date date47 = null;
        java.util.TimeZone timeZone48 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass46, date47, timeZone48);
        org.jfree.data.time.TimePeriodValues timePeriodValues51 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues51.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener54 = null;
        timePeriodValues51.removePropertyChangeListener(propertyChangeListener54);
        int int56 = timePeriodValues51.getItemCount();
        int int57 = timePeriodValues51.getMaxMiddleIndex();
        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year();
        timePeriodValues51.add((org.jfree.data.time.TimePeriod) year58, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue62 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year58, (java.lang.Number) 2019L);
        java.util.Date date63 = year58.getEnd();
        java.util.TimeZone timeZone64 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass46, date63, timeZone64);
        org.jfree.data.time.TimePeriodValues timePeriodValues67 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues67.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener70 = null;
        timePeriodValues67.removePropertyChangeListener(propertyChangeListener70);
        int int72 = timePeriodValues67.getItemCount();
        int int73 = timePeriodValues67.getMaxMiddleIndex();
        org.jfree.data.time.Year year74 = new org.jfree.data.time.Year();
        timePeriodValues67.add((org.jfree.data.time.TimePeriod) year74, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue78 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year74, (java.lang.Number) 2019L);
        java.util.Date date79 = year74.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod80 = new org.jfree.data.time.SimpleTimePeriod(date63, date79);
        java.util.TimeZone timeZone81 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year82 = new org.jfree.data.time.Year(date63, timeZone81);
        org.jfree.data.time.Year year83 = new org.jfree.data.time.Year(date14, timeZone81);
        boolean boolean85 = year83.equals((java.lang.Object) 12);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year83, (double) 'a');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod88 = year83.previous();
        java.lang.String str89 = year83.toString();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Value" + "'", str8.equals("Value"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(timeZone38);
        org.junit.Assert.assertNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass46);
        org.junit.Assert.assertNull(regularTimePeriod49);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-1) + "'", int57 == (-1));
        org.junit.Assert.assertNotNull(date63);
        org.junit.Assert.assertNotNull(timeZone64);
        org.junit.Assert.assertNull(regularTimePeriod65);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 0 + "'", int72 == 0);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + (-1) + "'", int73 == (-1));
        org.junit.Assert.assertNotNull(date79);
        org.junit.Assert.assertNotNull(timeZone81);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod88);
        org.junit.Assert.assertTrue("'" + str89 + "' != '" + "2019" + "'", str89.equals("2019"));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 2019L);
        java.util.Date date13 = year8.getEnd();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date13);
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date13, timeZone15);
        long long17 = day16.getFirstMillisecond();
        int int18 = day16.getDayOfMonth();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1577779200000L + "'", long17 == 1577779200000L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 31 + "'", int18 == 31);
    }

//    @Test
//    public void test037() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test037");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        timePeriodValues1.setNotify(true);
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
//        java.lang.String str6 = timePeriodValues1.getDescription();
//        int int7 = timePeriodValues1.getMinStartIndex();
//        int int8 = timePeriodValues1.getMaxEndIndex();
//        timePeriodValues1.setDomainDescription("");
//        java.beans.PropertyChangeListener propertyChangeListener11 = null;
//        timePeriodValues1.removePropertyChangeListener(propertyChangeListener11);
//        java.lang.String str13 = timePeriodValues1.getDomainDescription();
//        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        timePeriodValues15.setNotify(true);
//        java.beans.PropertyChangeListener propertyChangeListener18 = null;
//        timePeriodValues15.removePropertyChangeListener(propertyChangeListener18);
//        java.lang.String str20 = timePeriodValues15.getDescription();
//        int int21 = timePeriodValues15.getMinStartIndex();
//        timePeriodValues15.fireSeriesChanged();
//        boolean boolean23 = timePeriodValues1.equals((java.lang.Object) timePeriodValues15);
//        int int24 = timePeriodValues1.getMaxStartIndex();
//        int int25 = timePeriodValues1.getMaxStartIndex();
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass27 = day26.getClass();
//        long long28 = day26.getLastMillisecond();
//        long long29 = day26.getMiddleMillisecond();
//        timePeriodValues1.setKey((java.lang.Comparable) day26);
//        long long31 = day26.getSerialIndex();
//        long long32 = day26.getLastMillisecond();
//        org.junit.Assert.assertNull(str6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertNull(str20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass27);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560495599999L + "'", long28 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560452399999L + "'", long29 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 43629L + "'", long31 == 43629L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560495599999L + "'", long32 == 1560495599999L);
//    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.String str2 = seriesChangeEvent1.toString();
        java.lang.Object obj3 = seriesChangeEvent1.getSource();
        java.lang.Object obj4 = seriesChangeEvent1.getSource();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=0]" + "'", str2.equals("org.jfree.data.general.SeriesChangeEvent[source=0]"));
        org.junit.Assert.assertTrue("'" + obj3 + "' != '" + (byte) 0 + "'", obj3.equals((byte) 0));
        org.junit.Assert.assertTrue("'" + obj4 + "' != '" + (byte) 0 + "'", obj4.equals((byte) 0));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 2019L);
        java.util.Date date13 = year8.getEnd();
        long long14 = year8.getMiddleMillisecond();
        java.lang.Class<?> wildcardClass15 = year8.getClass();
        java.lang.Class class16 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass15);
        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize(class16);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1562097599999L + "'", long14 == 1562097599999L);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(class16);
        org.junit.Assert.assertNotNull(class17);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMinEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = timePeriodValues1.createCopy(6, (int) (byte) 100);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener13);
        int int15 = timePeriodValues10.getItemCount();
        int int16 = timePeriodValues10.getMaxMiddleIndex();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) year17, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year17.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year17.previous();
        java.lang.Object obj24 = null;
        int int25 = year17.compareTo(obj24);
        timePeriodValues1.setKey((java.lang.Comparable) year17);
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues28.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timePeriodValues28.removePropertyChangeListener(propertyChangeListener31);
        int int33 = timePeriodValues28.getItemCount();
        int int34 = timePeriodValues28.getMaxMiddleIndex();
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
        timePeriodValues28.add((org.jfree.data.time.TimePeriod) year35, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue39 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year35, (java.lang.Number) 2019L);
        java.util.Date date40 = year35.getEnd();
        long long41 = year35.getMiddleMillisecond();
        long long42 = year35.getSerialIndex();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year35, (double) 0);
        int int45 = timePeriodValues1.getMaxMiddleIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1562097599999L + "'", long41 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 2019L + "'", long42 == 2019L);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) ' ');
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timePeriodValues4.addChangeListener(seriesChangeListener5);
        int int7 = timePeriodValues4.getMinMiddleIndex();
        int int8 = timePeriodValues4.getMinEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = timePeriodValues4.createCopy(6, (int) (byte) 100);
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues13.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues13.removePropertyChangeListener(propertyChangeListener16);
        int int18 = timePeriodValues13.getItemCount();
        int int19 = timePeriodValues13.getMaxMiddleIndex();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        timePeriodValues13.add((org.jfree.data.time.TimePeriod) year20, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue24 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year20, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year20.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year20.previous();
        java.lang.Object obj27 = null;
        int int28 = year20.compareTo(obj27);
        timePeriodValues4.setKey((java.lang.Comparable) year20);
        org.jfree.data.time.TimePeriodValues timePeriodValues31 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues31.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener34 = null;
        timePeriodValues31.removePropertyChangeListener(propertyChangeListener34);
        int int36 = timePeriodValues31.getItemCount();
        int int37 = timePeriodValues31.getMaxMiddleIndex();
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
        timePeriodValues31.add((org.jfree.data.time.TimePeriod) year38, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue42 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year38, (java.lang.Number) 2019L);
        java.util.Date date43 = year38.getEnd();
        long long44 = year38.getMiddleMillisecond();
        long long45 = year38.getSerialIndex();
        timePeriodValues4.add((org.jfree.data.time.TimePeriod) year38, (double) 0);
        boolean boolean48 = simpleTimePeriod2.equals((java.lang.Object) 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues11);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1562097599999L + "'", long44 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 2019L + "'", long45 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

//    @Test
//    public void test042() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test042");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.next();
//        java.lang.Object obj4 = null;
//        int int5 = day0.compareTo(obj4);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day0.next();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        timePeriodValues1.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = timePeriodValues1.createCopy(0, 1);
        int int13 = timePeriodValues12.getMaxStartIndex();
        timePeriodValues12.setDomainDescription("");
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener11);
        int int13 = timePeriodValues1.getMaxEndIndex();
        java.lang.Comparable comparable14 = timePeriodValues1.getKey();
        int int15 = timePeriodValues1.getMaxStartIndex();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
        int int17 = day16.getYear();
        int int18 = day16.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day16.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day16, (double) 1.0f);
        org.jfree.data.time.TimePeriodValue timePeriodValue23 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day16, (double) 1546329600000L);
        java.lang.Number number24 = null;
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day16, number24);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + (byte) 1 + "'", comparable14.equals((byte) 1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
    }

//    @Test
//    public void test045() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test045");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
//        long long3 = year2.getSerialIndex();
//        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year2, (java.lang.Number) 100);
//        java.lang.Object obj6 = timePeriodValue5.clone();
//        int int7 = day0.compareTo(obj6);
//        int int8 = day0.getDayOfMonth();
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0);
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
//        org.junit.Assert.assertNotNull(obj6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 13 + "'", int8 == 13);
//    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        boolean boolean2 = timePeriodValues1.getNotify();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener3);
        timePeriodValues1.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesChangeEvent[source=0]");
        org.jfree.data.time.TimePeriod timePeriod7 = null;
        try {
            timePeriodValues1.add(timePeriod7, (double) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        int int11 = timePeriodValues1.getMaxEndIndex();
        java.lang.String str12 = timePeriodValues1.getRangeDescription();
        timePeriodValues1.setKey((java.lang.Comparable) 7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener15);
        timePeriodValues1.setRangeDescription("");
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate20 = day19.getSerialDate();
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(serialDate20);
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(serialDate20);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(serialDate20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day23.next();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod24, (java.lang.Number) 3);
        int int27 = timePeriodValues1.getItemCount();
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Value" + "'", str12.equals("Value"));
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 100);
        java.lang.Object obj4 = timePeriodValue3.clone();
        java.lang.String str5 = timePeriodValue3.toString();
        boolean boolean7 = timePeriodValue3.equals((java.lang.Object) 100);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        boolean boolean9 = timePeriodValue3.equals((java.lang.Object) day8);
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timePeriodValues11.addChangeListener(seriesChangeListener12);
        int int14 = timePeriodValues11.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass15 = timePeriodValues11.getClass();
        java.util.Date date16 = null;
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date16, timeZone17);
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues20.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener23 = null;
        timePeriodValues20.removePropertyChangeListener(propertyChangeListener23);
        int int25 = timePeriodValues20.getItemCount();
        int int26 = timePeriodValues20.getMaxMiddleIndex();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        timePeriodValues20.add((org.jfree.data.time.TimePeriod) year27, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue31 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year27, (java.lang.Number) 2019L);
        java.util.Date date32 = year27.getEnd();
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date32, timeZone33);
        org.jfree.data.time.TimePeriodValues timePeriodValues36 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues36.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener39 = null;
        timePeriodValues36.removePropertyChangeListener(propertyChangeListener39);
        int int41 = timePeriodValues36.getItemCount();
        int int42 = timePeriodValues36.getMaxMiddleIndex();
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year();
        timePeriodValues36.add((org.jfree.data.time.TimePeriod) year43, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue47 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year43, (java.lang.Number) 2019L);
        java.util.Date date48 = year43.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod49 = new org.jfree.data.time.SimpleTimePeriod(date32, date48);
        org.jfree.data.time.TimePeriodValues timePeriodValues51 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues51.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener54 = null;
        timePeriodValues51.removePropertyChangeListener(propertyChangeListener54);
        java.lang.String str56 = timePeriodValues51.getDescription();
        int int57 = timePeriodValues51.getMinStartIndex();
        timePeriodValues51.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues62 = timePeriodValues51.createCopy(0, 1);
        boolean boolean63 = simpleTimePeriod49.equals((java.lang.Object) 0);
        java.util.Date date64 = simpleTimePeriod49.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues66 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues66.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener69 = null;
        timePeriodValues66.removePropertyChangeListener(propertyChangeListener69);
        int int71 = timePeriodValues66.getItemCount();
        int int72 = timePeriodValues66.getMaxMiddleIndex();
        org.jfree.data.time.Year year73 = new org.jfree.data.time.Year();
        timePeriodValues66.add((org.jfree.data.time.TimePeriod) year73, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue77 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year73, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = year73.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = year73.previous();
        int int80 = simpleTimePeriod49.compareTo((java.lang.Object) regularTimePeriod79);
        boolean boolean81 = timePeriodValue3.equals((java.lang.Object) regularTimePeriod79);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "TimePeriodValue[2019,100]" + "'", str5.equals("TimePeriodValue[2019,100]"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNull(regularTimePeriod34);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNull(str56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-1) + "'", int57 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 0 + "'", int71 == 0);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + (-1) + "'", int72 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod78);
        org.junit.Assert.assertNotNull(regularTimePeriod79);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 1 + "'", int80 == 1);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        java.util.Date date0 = null;
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues2.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues2.removePropertyChangeListener(propertyChangeListener5);
        int int7 = timePeriodValues2.getItemCount();
        int int8 = timePeriodValues2.getMaxMiddleIndex();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        timePeriodValues2.add((org.jfree.data.time.TimePeriod) year9, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year9, (java.lang.Number) 2019L);
        java.util.Date date14 = year9.getEnd();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date14);
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date14, timeZone16);
        try {
            org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date0, timeZone16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone16);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("TimePeriodValue[2019,3]");
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        timePeriodValues1.setKey((java.lang.Comparable) ' ');
        int int13 = timePeriodValues1.getMinStartIndex();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        int int15 = day14.getYear();
        int int16 = day14.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day14.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod17, (double) (-201));
        java.lang.String str20 = timePeriodValues1.getDescription();
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNull(str20);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 100);
        java.util.Date date4 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues6.addChangeListener(seriesChangeListener7);
        int int9 = timePeriodValues6.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass10 = timePeriodValues6.getClass();
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date11, timeZone12);
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues15.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timePeriodValues15.removePropertyChangeListener(propertyChangeListener18);
        int int20 = timePeriodValues15.getItemCount();
        int int21 = timePeriodValues15.getMaxMiddleIndex();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        timePeriodValues15.add((org.jfree.data.time.TimePeriod) year22, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue26 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year22, (java.lang.Number) 2019L);
        java.util.Date date27 = year22.getEnd();
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date27, timeZone28);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(date4, timeZone28);
        org.jfree.data.time.TimePeriodValues timePeriodValues32 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener33 = null;
        timePeriodValues32.addChangeListener(seriesChangeListener33);
        int int35 = timePeriodValues32.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass36 = timePeriodValues32.getClass();
        java.util.Date date37 = null;
        java.util.TimeZone timeZone38 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date37, timeZone38);
        org.jfree.data.time.TimePeriodValues timePeriodValues41 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues41.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener44 = null;
        timePeriodValues41.removePropertyChangeListener(propertyChangeListener44);
        int int46 = timePeriodValues41.getItemCount();
        int int47 = timePeriodValues41.getMaxMiddleIndex();
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year();
        timePeriodValues41.add((org.jfree.data.time.TimePeriod) year48, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue52 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year48, (java.lang.Number) 2019L);
        java.util.Date date53 = year48.getEnd();
        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date53, timeZone54);
        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year(date4, timeZone54);
        org.jfree.data.time.TimePeriodValues timePeriodValues60 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 4, "13-June-2019", "");
        int int61 = year56.compareTo((java.lang.Object) 4);
        int int62 = year56.getYear();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertNotNull(timeZone54);
        org.junit.Assert.assertNull(regularTimePeriod55);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1 + "'", int61 == 1);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 2019 + "'", int62 == 2019);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        timePeriodValues1.setKey((java.lang.Comparable) "hi!");
        timePeriodValues1.delete(13, 4);
        java.lang.Class<?> wildcardClass9 = timePeriodValues1.getClass();
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getYear();
        int int2 = day0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod3, (java.lang.Number) 0L);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        int int7 = day6.getYear();
        boolean boolean8 = timePeriodValue5.equals((java.lang.Object) int7);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 2019L);
        java.lang.Class<?> wildcardClass13 = year8.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues15.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timePeriodValues15.removePropertyChangeListener(propertyChangeListener18);
        int int20 = timePeriodValues15.getItemCount();
        int int21 = timePeriodValues15.getMaxMiddleIndex();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        timePeriodValues15.add((org.jfree.data.time.TimePeriod) year22, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue26 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year22, (java.lang.Number) 2019L);
        boolean boolean27 = year8.equals((java.lang.Object) 2019L);
        long long28 = year8.getSerialIndex();
        long long29 = year8.getSerialIndex();
        int int30 = year8.getYear();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 2019L + "'", long28 == 2019L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 2019L + "'", long29 == 2019L);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate12 = day11.getSerialDate();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(serialDate12);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(serialDate12);
        int int15 = day14.getMonth();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day14, (java.lang.Number) 12);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues3.setNotify(true);
        boolean boolean7 = timePeriodValues3.equals((java.lang.Object) (short) 0);
        boolean boolean8 = year0.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        timePeriodValues10.setKey((java.lang.Comparable) 100L);
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues16.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timePeriodValues16.removePropertyChangeListener(propertyChangeListener19);
        int int21 = timePeriodValues16.getItemCount();
        int int22 = timePeriodValues16.getMaxMiddleIndex();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        timePeriodValues16.add((org.jfree.data.time.TimePeriod) year23, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue27 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year23, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year23.previous();
        timePeriodValues10.setKey((java.lang.Comparable) year23);
        int int30 = year0.compareTo((java.lang.Object) year23);
        int int31 = year23.getYear();
        int int33 = year23.compareTo((java.lang.Object) (short) 10);
        java.lang.String str34 = year23.toString();
        long long35 = year23.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2019 + "'", int31 == 2019);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "2019" + "'", str34.equals("2019"));
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 2019L + "'", long35 == 2019L);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues3.setNotify(true);
        boolean boolean7 = timePeriodValues3.equals((java.lang.Object) (short) 0);
        boolean boolean8 = year0.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        timePeriodValues10.setKey((java.lang.Comparable) 100L);
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues16.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timePeriodValues16.removePropertyChangeListener(propertyChangeListener19);
        int int21 = timePeriodValues16.getItemCount();
        int int22 = timePeriodValues16.getMaxMiddleIndex();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        timePeriodValues16.add((org.jfree.data.time.TimePeriod) year23, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue27 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year23, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year23.previous();
        timePeriodValues10.setKey((java.lang.Comparable) year23);
        int int30 = year0.compareTo((java.lang.Object) year23);
        java.lang.String str31 = year0.toString();
        long long32 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues34 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues34.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener37 = null;
        timePeriodValues34.removePropertyChangeListener(propertyChangeListener37);
        java.lang.String str39 = timePeriodValues34.getDescription();
        int int40 = timePeriodValues34.getMinStartIndex();
        int int41 = timePeriodValues34.getMaxEndIndex();
        timePeriodValues34.setDomainDescription("");
        int int44 = timePeriodValues34.getMaxEndIndex();
        java.lang.String str45 = timePeriodValues34.getRangeDescription();
        java.lang.Class<?> wildcardClass46 = timePeriodValues34.getClass();
        boolean boolean47 = year0.equals((java.lang.Object) timePeriodValues34);
        long long48 = year0.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = year0.previous();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "2019" + "'", str31.equals("2019"));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 2019L + "'", long32 == 2019L);
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "Value" + "'", str45.equals("Value"));
        org.junit.Assert.assertNotNull(wildcardClass46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 2019L + "'", long48 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues3.setNotify(true);
        boolean boolean7 = timePeriodValues3.equals((java.lang.Object) (short) 0);
        boolean boolean8 = year0.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        timePeriodValues10.setKey((java.lang.Comparable) 100L);
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues16.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timePeriodValues16.removePropertyChangeListener(propertyChangeListener19);
        int int21 = timePeriodValues16.getItemCount();
        int int22 = timePeriodValues16.getMaxMiddleIndex();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        timePeriodValues16.add((org.jfree.data.time.TimePeriod) year23, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue27 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year23, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year23.previous();
        timePeriodValues10.setKey((java.lang.Comparable) year23);
        int int30 = year0.compareTo((java.lang.Object) year23);
        java.lang.String str31 = year0.toString();
        java.lang.Object obj32 = null;
        boolean boolean33 = year0.equals(obj32);
        java.util.Date date34 = year0.getStart();
        org.jfree.data.time.TimePeriodValue timePeriodValue36 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, 0.0d);
        java.lang.String str37 = year0.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "2019" + "'", str31.equals("2019"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "2019" + "'", str37.equals("2019"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 2019L);
        java.util.Date date13 = year8.getEnd();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date13);
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date13, timeZone15);
        long long17 = day16.getSerialIndex();
        java.util.Date date18 = day16.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day16.previous();
        java.lang.Class<?> wildcardClass20 = day16.getClass();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 43830L + "'", long17 == 43830L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(wildcardClass20);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener11);
        java.lang.String str13 = timePeriodValues1.getDomainDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener14);
        int int16 = timePeriodValues1.getMinEndIndex();
        java.lang.String str17 = timePeriodValues1.getDomainDescription();
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        timePeriodValues1.setNotify(true);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener10);
        timePeriodValues1.setRangeDescription("31-December-2019");
        int int14 = timePeriodValues1.getMinStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues16.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timePeriodValues16.removePropertyChangeListener(propertyChangeListener19);
        int int21 = timePeriodValues16.getItemCount();
        int int22 = timePeriodValues16.getMaxMiddleIndex();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        timePeriodValues16.add((org.jfree.data.time.TimePeriod) year23, (double) 6);
        java.lang.String str26 = year23.toString();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year23, (double) (short) 100);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "2019" + "'", str26.equals("2019"));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        timePeriodValues1.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = timePeriodValues1.createCopy(0, 1);
        java.lang.String str13 = timePeriodValues12.getDomainDescription();
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Time" + "'", str13.equals("Time"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass1 = day0.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        int int9 = timePeriodValues1.getMinEndIndex();
        int int10 = timePeriodValues1.getItemCount();
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues12.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues12.removePropertyChangeListener(propertyChangeListener15);
        int int17 = timePeriodValues12.getItemCount();
        int int18 = timePeriodValues12.getMaxMiddleIndex();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        timePeriodValues12.add((org.jfree.data.time.TimePeriod) year19, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue23 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year19, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year19.previous();
        java.lang.String str25 = year19.toString();
        long long26 = year19.getFirstMillisecond();
        timePeriodValues1.setKey((java.lang.Comparable) year19);
        java.beans.PropertyChangeListener propertyChangeListener28 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener28);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "2019" + "'", str25.equals("2019"));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1546329600000L + "'", long26 == 1546329600000L);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        timePeriodValues1.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = timePeriodValues1.createCopy(4, 0);
        int int13 = timePeriodValues1.getMinEndIndex();
        java.lang.Class<?> wildcardClass14 = timePeriodValues1.getClass();
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        boolean boolean2 = timePeriodValues1.getNotify();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener3);
        timePeriodValues1.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesChangeEvent[source=0]");
        timePeriodValues1.setDomainDescription("TimePeriodValue[2019,100.0]");
        java.lang.Comparable comparable9 = timePeriodValues1.getKey();
        int int10 = timePeriodValues1.getMinStartIndex();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + (byte) 1 + "'", comparable9.equals((byte) 1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("31-December-2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
        timePeriodFormatException14.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException23 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException25 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
        timePeriodFormatException23.addSuppressed((java.lang.Throwable) timePeriodFormatException25);
        timePeriodFormatException21.addSuppressed((java.lang.Throwable) timePeriodFormatException23);
        timePeriodFormatException19.addSuppressed((java.lang.Throwable) timePeriodFormatException23);
        timePeriodFormatException14.addSuppressed((java.lang.Throwable) timePeriodFormatException23);
        java.lang.Throwable[] throwableArray30 = timePeriodFormatException23.getSuppressed();
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException23);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        java.lang.String str33 = timePeriodFormatException7.toString();
        org.junit.Assert.assertNotNull(throwableArray30);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesChangeEvent[source=0]" + "'", str33.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesChangeEvent[source=0]"));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("Value");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        java.lang.String str8 = timePeriodFormatException6.toString();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Value" + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: Value"));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        int int11 = timePeriodValues1.getMaxEndIndex();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue13 = timePeriodValues1.getDataItem(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        int int11 = timePeriodValues1.getMaxMiddleIndex();
        int int12 = timePeriodValues1.getMaxEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener13);
        try {
            org.jfree.data.time.TimePeriod timePeriod16 = timePeriodValues1.getTimePeriod(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        timePeriodValues1.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = timePeriodValues1.createCopy(0, 1);
        int int13 = timePeriodValues12.getMaxStartIndex();
        int int14 = timePeriodValues12.getMaxEndIndex();
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener13);
        int int15 = timePeriodValues10.getItemCount();
        int int16 = timePeriodValues10.getMaxMiddleIndex();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) year17, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 2019L);
        java.util.Date date22 = year17.getEnd();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date22, timeZone23);
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues26.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timePeriodValues26.removePropertyChangeListener(propertyChangeListener29);
        int int31 = timePeriodValues26.getItemCount();
        int int32 = timePeriodValues26.getMaxMiddleIndex();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        timePeriodValues26.add((org.jfree.data.time.TimePeriod) year33, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue37 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year33, (java.lang.Number) 2019L);
        java.util.Date date38 = year33.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(date22, date38);
        long long40 = simpleTimePeriod39.getEndMillis();
        long long41 = simpleTimePeriod39.getStartMillis();
        boolean boolean43 = simpleTimePeriod39.equals((java.lang.Object) 0);
        java.util.Date date44 = simpleTimePeriod39.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues46 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener47 = null;
        timePeriodValues46.addChangeListener(seriesChangeListener47);
        int int49 = timePeriodValues46.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass50 = timePeriodValues46.getClass();
        java.util.Date date51 = null;
        java.util.TimeZone timeZone52 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass50, date51, timeZone52);
        org.jfree.data.time.TimePeriodValues timePeriodValues55 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues55.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener58 = null;
        timePeriodValues55.removePropertyChangeListener(propertyChangeListener58);
        int int60 = timePeriodValues55.getItemCount();
        int int61 = timePeriodValues55.getMaxMiddleIndex();
        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year();
        timePeriodValues55.add((org.jfree.data.time.TimePeriod) year62, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue66 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year62, (java.lang.Number) 2019L);
        java.util.Date date67 = year62.getEnd();
        java.util.TimeZone timeZone68 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass50, date67, timeZone68);
        org.jfree.data.time.TimePeriodValues timePeriodValues71 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues71.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener74 = null;
        timePeriodValues71.removePropertyChangeListener(propertyChangeListener74);
        int int76 = timePeriodValues71.getItemCount();
        int int77 = timePeriodValues71.getMaxMiddleIndex();
        org.jfree.data.time.Year year78 = new org.jfree.data.time.Year();
        timePeriodValues71.add((org.jfree.data.time.TimePeriod) year78, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue82 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year78, (java.lang.Number) 2019L);
        java.util.Date date83 = year78.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod84 = new org.jfree.data.time.SimpleTimePeriod(date67, date83);
        java.util.TimeZone timeZone85 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year86 = new org.jfree.data.time.Year(date67, timeZone85);
        boolean boolean87 = simpleTimePeriod39.equals((java.lang.Object) date67);
        java.util.Date date88 = simpleTimePeriod39.getStart();
        long long89 = simpleTimePeriod39.getStartMillis();
        long long90 = simpleTimePeriod39.getEndMillis();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1577865599999L + "'", long40 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1577865599999L + "'", long41 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertNull(regularTimePeriod53);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
        org.junit.Assert.assertNotNull(date67);
        org.junit.Assert.assertNotNull(timeZone68);
        org.junit.Assert.assertNull(regularTimePeriod69);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 0 + "'", int76 == 0);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + (-1) + "'", int77 == (-1));
        org.junit.Assert.assertNotNull(date83);
        org.junit.Assert.assertNotNull(timeZone85);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertNotNull(date88);
        org.junit.Assert.assertTrue("'" + long89 + "' != '" + 1577865599999L + "'", long89 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long90 + "' != '" + 1577865599999L + "'", long90 == 1577865599999L);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 2019L);
        java.lang.Class<?> wildcardClass13 = year8.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues15.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timePeriodValues15.removePropertyChangeListener(propertyChangeListener18);
        int int20 = timePeriodValues15.getItemCount();
        int int21 = timePeriodValues15.getMaxMiddleIndex();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        timePeriodValues15.add((org.jfree.data.time.TimePeriod) year22, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue26 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year22, (java.lang.Number) 2019L);
        boolean boolean27 = year8.equals((java.lang.Object) 2019L);
        long long28 = year8.getSerialIndex();
        java.util.Date date29 = year8.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = year8.previous();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 2019L + "'", long28 == 2019L);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
    }

//    @Test
//    public void test075() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test075");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass1 = day0.getClass();
//        long long2 = day0.getLastMillisecond();
//        java.lang.String str3 = day0.toString();
//        long long4 = day0.getFirstMillisecond();
//        java.lang.String str5 = day0.toString();
//        int int6 = day0.getYear();
//        org.junit.Assert.assertNotNull(wildcardClass1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560495599999L + "'", long2 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "13-June-2019" + "'", str5.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//    }

//    @Test
//    public void test076() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test076");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        int int4 = timePeriodValues1.getMinMiddleIndex();
//        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
//        java.util.Date date6 = null;
//        java.util.TimeZone timeZone7 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
//        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        timePeriodValues10.setNotify(true);
//        java.beans.PropertyChangeListener propertyChangeListener13 = null;
//        timePeriodValues10.removePropertyChangeListener(propertyChangeListener13);
//        int int15 = timePeriodValues10.getItemCount();
//        int int16 = timePeriodValues10.getMaxMiddleIndex();
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
//        timePeriodValues10.add((org.jfree.data.time.TimePeriod) year17, (double) 6);
//        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 2019L);
//        java.util.Date date22 = year17.getEnd();
//        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date22, timeZone23);
//        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        timePeriodValues26.setNotify(true);
//        java.beans.PropertyChangeListener propertyChangeListener29 = null;
//        timePeriodValues26.removePropertyChangeListener(propertyChangeListener29);
//        int int31 = timePeriodValues26.getItemCount();
//        int int32 = timePeriodValues26.getMaxMiddleIndex();
//        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
//        timePeriodValues26.add((org.jfree.data.time.TimePeriod) year33, (double) 6);
//        org.jfree.data.time.TimePeriodValue timePeriodValue37 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year33, (java.lang.Number) 2019L);
//        java.util.Date date38 = year33.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(date22, date38);
//        long long40 = simpleTimePeriod39.getEndMillis();
//        long long41 = simpleTimePeriod39.getStartMillis();
//        boolean boolean43 = simpleTimePeriod39.equals((java.lang.Object) 0);
//        java.util.Date date44 = simpleTimePeriod39.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues46 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener47 = null;
//        timePeriodValues46.addChangeListener(seriesChangeListener47);
//        int int49 = timePeriodValues46.getMinMiddleIndex();
//        java.lang.Class<?> wildcardClass50 = timePeriodValues46.getClass();
//        java.util.Date date51 = null;
//        java.util.TimeZone timeZone52 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass50, date51, timeZone52);
//        org.jfree.data.time.TimePeriodValues timePeriodValues55 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        timePeriodValues55.setNotify(true);
//        java.beans.PropertyChangeListener propertyChangeListener58 = null;
//        timePeriodValues55.removePropertyChangeListener(propertyChangeListener58);
//        int int60 = timePeriodValues55.getItemCount();
//        int int61 = timePeriodValues55.getMaxMiddleIndex();
//        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year();
//        timePeriodValues55.add((org.jfree.data.time.TimePeriod) year62, (double) 6);
//        org.jfree.data.time.TimePeriodValue timePeriodValue66 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year62, (java.lang.Number) 2019L);
//        java.util.Date date67 = year62.getEnd();
//        java.util.TimeZone timeZone68 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass50, date67, timeZone68);
//        org.jfree.data.time.TimePeriodValues timePeriodValues71 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        timePeriodValues71.setNotify(true);
//        java.beans.PropertyChangeListener propertyChangeListener74 = null;
//        timePeriodValues71.removePropertyChangeListener(propertyChangeListener74);
//        int int76 = timePeriodValues71.getItemCount();
//        int int77 = timePeriodValues71.getMaxMiddleIndex();
//        org.jfree.data.time.Year year78 = new org.jfree.data.time.Year();
//        timePeriodValues71.add((org.jfree.data.time.TimePeriod) year78, (double) 6);
//        org.jfree.data.time.TimePeriodValue timePeriodValue82 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year78, (java.lang.Number) 2019L);
//        java.util.Date date83 = year78.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod84 = new org.jfree.data.time.SimpleTimePeriod(date67, date83);
//        java.util.TimeZone timeZone85 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year86 = new org.jfree.data.time.Year(date67, timeZone85);
//        boolean boolean87 = simpleTimePeriod39.equals((java.lang.Object) date67);
//        org.jfree.data.time.Day day88 = new org.jfree.data.time.Day();
//        int int89 = day88.getMonth();
//        long long90 = day88.getMiddleMillisecond();
//        boolean boolean91 = simpleTimePeriod39.equals((java.lang.Object) long90);
//        org.jfree.data.time.Day day92 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue94 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day92, (double) 0L);
//        int int95 = day92.getYear();
//        java.lang.String str96 = day92.toString();
//        int int97 = day92.getDayOfMonth();
//        int int98 = day92.getMonth();
//        try {
//            int int99 = simpleTimePeriod39.compareTo((java.lang.Object) int98);
//            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Integer cannot be cast to org.jfree.data.time.TimePeriod");
//        } catch (java.lang.ClassCastException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(timeZone23);
//        org.junit.Assert.assertNull(regularTimePeriod24);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1577865599999L + "'", long40 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1577865599999L + "'", long41 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass50);
//        org.junit.Assert.assertNull(regularTimePeriod53);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
//        org.junit.Assert.assertNotNull(date67);
//        org.junit.Assert.assertNotNull(timeZone68);
//        org.junit.Assert.assertNull(regularTimePeriod69);
//        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 0 + "'", int76 == 0);
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + (-1) + "'", int77 == (-1));
//        org.junit.Assert.assertNotNull(date83);
//        org.junit.Assert.assertNotNull(timeZone85);
//        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
//        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 6 + "'", int89 == 6);
//        org.junit.Assert.assertTrue("'" + long90 + "' != '" + 1560452399999L + "'", long90 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
//        org.junit.Assert.assertTrue("'" + int95 + "' != '" + 2019 + "'", int95 == 2019);
//        org.junit.Assert.assertTrue("'" + str96 + "' != '" + "13-June-2019" + "'", str96.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int97 + "' != '" + 13 + "'", int97 == 13);
//        org.junit.Assert.assertTrue("'" + int98 + "' != '" + 6 + "'", int98 == 6);
//    }

//    @Test
//    public void test077() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test077");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getMiddleMillisecond();
//        int int3 = day0.getMonth();
//        java.util.Date date4 = day0.getStart();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.next();
//        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        timePeriodValues8.setNotify(true);
//        java.beans.PropertyChangeListener propertyChangeListener11 = null;
//        timePeriodValues8.removePropertyChangeListener(propertyChangeListener11);
//        int int13 = timePeriodValues8.getItemCount();
//        int int14 = timePeriodValues8.getMaxMiddleIndex();
//        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
//        timePeriodValues8.add((org.jfree.data.time.TimePeriod) year15, (double) 6);
//        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year15, (java.lang.Number) 2019L);
//        java.util.Date date20 = year15.getEnd();
//        long long21 = year15.getFirstMillisecond();
//        boolean boolean22 = day5.equals((java.lang.Object) long21);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent23 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) day5);
//        int int24 = day0.compareTo((java.lang.Object) seriesChangeEvent23);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560452399999L + "'", long2 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1546329600000L + "'", long21 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
        timePeriodValues1.setDomainDescription("Value");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener8);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

//    @Test
//    public void test079() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test079");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass1 = day0.getClass();
//        long long2 = day0.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0, "Time", "2019");
//        int int6 = timePeriodValues5.getMinEndIndex();
//        org.junit.Assert.assertNotNull(wildcardClass1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560495599999L + "'", long2 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener11);
        java.lang.String str13 = timePeriodValues1.getDomainDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues15.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timePeriodValues15.removePropertyChangeListener(propertyChangeListener18);
        java.lang.String str20 = timePeriodValues15.getDescription();
        int int21 = timePeriodValues15.getMinStartIndex();
        timePeriodValues15.fireSeriesChanged();
        boolean boolean23 = timePeriodValues1.equals((java.lang.Object) timePeriodValues15);
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = timePeriodValues1.createCopy((int) (byte) 0, 1);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(timePeriodValues26);
    }

//    @Test
//    public void test081() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test081");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        timePeriodValues1.setNotify(true);
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
//        int int6 = timePeriodValues1.getItemCount();
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues1.createCopy(0, 0);
//        int int10 = timePeriodValues9.getMaxMiddleIndex();
//        boolean boolean11 = timePeriodValues9.isEmpty();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate13 = day12.getSerialDate();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(serialDate13);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate13);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(serialDate13);
//        long long17 = day16.getLastMillisecond();
//        timePeriodValues9.add((org.jfree.data.time.TimePeriod) day16, (java.lang.Number) 1530561599999L);
//        int int20 = day16.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(timePeriodValues9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560495599999L + "'", long17 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 13 + "'", int20 == 13);
//    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener4);
        java.lang.Object obj6 = timePeriodValues1.clone();
        boolean boolean7 = timePeriodValues1.isEmpty();
        try {
            org.jfree.data.time.TimePeriod timePeriod9 = timePeriodValues1.getTimePeriod((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 100);
        java.util.Date date4 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues6.addChangeListener(seriesChangeListener7);
        int int9 = timePeriodValues6.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass10 = timePeriodValues6.getClass();
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date11, timeZone12);
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues15.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timePeriodValues15.removePropertyChangeListener(propertyChangeListener18);
        int int20 = timePeriodValues15.getItemCount();
        int int21 = timePeriodValues15.getMaxMiddleIndex();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        timePeriodValues15.add((org.jfree.data.time.TimePeriod) year22, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue26 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year22, (java.lang.Number) 2019L);
        java.util.Date date27 = year22.getEnd();
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date27, timeZone28);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(date4, timeZone28);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year30.previous();
        long long32 = year30.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1546329600000L + "'", long32 == 1546329600000L);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        boolean boolean2 = timePeriodValues1.getNotify();
        java.lang.String str3 = timePeriodValues1.getRangeDescription();
        java.lang.String str4 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setRangeDescription("hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Value" + "'", str3.equals("Value"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year11, (java.lang.Number) 100);
        timePeriodValues1.add(timePeriodValue14);
        java.lang.Object obj16 = timePeriodValue14.clone();
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues18.setNotify(true);
        timePeriodValues18.setKey((java.lang.Comparable) 100L);
        timePeriodValues18.setKey((java.lang.Comparable) (short) 100);
        boolean boolean25 = timePeriodValue14.equals((java.lang.Object) (short) 100);
        timePeriodValue14.setValue((java.lang.Number) 32L);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2019L + "'", long12 == 2019L);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        timePeriodValues1.setKey((java.lang.Comparable) 100L);
        timePeriodValues1.setKey((java.lang.Comparable) (short) 100);
        java.lang.String str8 = timePeriodValues1.getRangeDescription();
        int int9 = timePeriodValues1.getMinStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener10);
        java.lang.String str12 = timePeriodValues1.getRangeDescription();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Value" + "'", str8.equals("Value"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Value" + "'", str12.equals("Value"));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("Value");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        java.lang.Throwable[] throwableArray8 = timePeriodFormatException6.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
        timePeriodFormatException14.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        timePeriodFormatException12.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        java.lang.Throwable throwable21 = null;
        try {
            timePeriodFormatException6.addSuppressed(throwable21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(throwableArray8);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        timePeriodValues1.setNotify(true);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year10, (java.lang.Number) 100);
        timePeriodValue13.setValue((java.lang.Number) 3);
        org.jfree.data.time.TimePeriod timePeriod16 = timePeriodValue13.getPeriod();
        timePeriodValues1.add(timePeriodValue13);
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues19.setNotify(true);
        timePeriodValues19.setKey((java.lang.Comparable) 100L);
        timePeriodValues19.setKey((java.lang.Comparable) (short) 100);
        java.lang.String str26 = timePeriodValues19.getRangeDescription();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        long long28 = year27.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue30 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year27, (java.lang.Number) 100);
        timePeriodValues19.add(timePeriodValue30);
        boolean boolean32 = timePeriodValue13.equals((java.lang.Object) timePeriodValues19);
        java.lang.Number number33 = timePeriodValue13.getValue();
        org.jfree.data.time.TimePeriod timePeriod34 = timePeriodValue13.getPeriod();
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
        org.junit.Assert.assertNotNull(timePeriod16);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Value" + "'", str26.equals("Value"));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 2019L + "'", long28 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + number33 + "' != '" + 3 + "'", number33.equals(3));
        org.junit.Assert.assertNotNull(timePeriod34);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues1.createCopy(0, 0);
        int int10 = timePeriodValues9.getMaxMiddleIndex();
        boolean boolean11 = timePeriodValues9.isEmpty();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = timePeriodValues9.createCopy(1, 9);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(timePeriodValues9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(timePeriodValues14);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 2019L);
        java.lang.Class<?> wildcardClass13 = year8.getClass();
        java.lang.String str14 = year8.toString();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues16.setNotify(true);
        timePeriodValues16.setKey((java.lang.Comparable) 100L);
        timePeriodValues16.setKey((java.lang.Comparable) (short) 100);
        java.lang.String str23 = timePeriodValues16.getRangeDescription();
        int int24 = timePeriodValues16.getMaxMiddleIndex();
        timePeriodValues16.fireSeriesChanged();
        int int26 = timePeriodValues16.getMaxStartIndex();
        int int27 = year8.compareTo((java.lang.Object) int26);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019" + "'", str14.equals("2019"));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Value" + "'", str23.equals("Value"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 2019L);
        java.util.Date date13 = year8.getEnd();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date13);
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date13, timeZone15);
        long long17 = day16.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day16.next();
        org.jfree.data.time.SerialDate serialDate19 = day16.getSerialDate();
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(serialDate19);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 43830L + "'", long17 == 43830L);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(serialDate19);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 2019L);
        java.util.Date date13 = year8.getEnd();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date13);
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date13, timeZone15);
        long long17 = day16.getSerialIndex();
        java.util.Date date18 = day16.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day16.previous();
        int int20 = day16.getMonth();
        java.lang.Class<?> wildcardClass21 = day16.getClass();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 43830L + "'", long17 == 43830L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 12 + "'", int20 == 12);
        org.junit.Assert.assertNotNull(wildcardClass21);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
        timePeriodValues1.setDomainDescription("Value");
        boolean boolean8 = timePeriodValues1.getNotify();
        timePeriodValues1.setDomainDescription("");
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener11);
        java.lang.String str13 = timePeriodValues1.getDomainDescription();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        long long15 = year14.getSerialIndex();
        int int16 = year14.getYear();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year14, 0.0d);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2019L + "'", long15 == 2019L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 100);
        java.util.Date date4 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues6.addChangeListener(seriesChangeListener7);
        int int9 = timePeriodValues6.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass10 = timePeriodValues6.getClass();
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date11, timeZone12);
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues15.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timePeriodValues15.removePropertyChangeListener(propertyChangeListener18);
        int int20 = timePeriodValues15.getItemCount();
        int int21 = timePeriodValues15.getMaxMiddleIndex();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        timePeriodValues15.add((org.jfree.data.time.TimePeriod) year22, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue26 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year22, (java.lang.Number) 2019L);
        java.util.Date date27 = year22.getEnd();
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date27, timeZone28);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(date4, timeZone28);
        org.jfree.data.time.TimePeriodValues timePeriodValues32 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener33 = null;
        timePeriodValues32.addChangeListener(seriesChangeListener33);
        int int35 = timePeriodValues32.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass36 = timePeriodValues32.getClass();
        java.util.Date date37 = null;
        java.util.TimeZone timeZone38 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date37, timeZone38);
        org.jfree.data.time.TimePeriodValues timePeriodValues41 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues41.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener44 = null;
        timePeriodValues41.removePropertyChangeListener(propertyChangeListener44);
        int int46 = timePeriodValues41.getItemCount();
        int int47 = timePeriodValues41.getMaxMiddleIndex();
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year();
        timePeriodValues41.add((org.jfree.data.time.TimePeriod) year48, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue52 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year48, (java.lang.Number) 2019L);
        java.util.Date date53 = year48.getEnd();
        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date53, timeZone54);
        org.jfree.data.time.TimePeriodValues timePeriodValues57 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues57.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener60 = null;
        timePeriodValues57.removePropertyChangeListener(propertyChangeListener60);
        int int62 = timePeriodValues57.getItemCount();
        int int63 = timePeriodValues57.getMaxMiddleIndex();
        org.jfree.data.time.Year year64 = new org.jfree.data.time.Year();
        timePeriodValues57.add((org.jfree.data.time.TimePeriod) year64, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue68 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year64, (java.lang.Number) 2019L);
        java.util.Date date69 = year64.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod70 = new org.jfree.data.time.SimpleTimePeriod(date53, date69);
        java.util.TimeZone timeZone71 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year72 = new org.jfree.data.time.Year(date53, timeZone71);
        org.jfree.data.time.Year year73 = new org.jfree.data.time.Year(date4, timeZone71);
        boolean boolean75 = year73.equals((java.lang.Object) 12);
        java.lang.String str76 = year73.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertNotNull(timeZone54);
        org.junit.Assert.assertNull(regularTimePeriod55);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-1) + "'", int63 == (-1));
        org.junit.Assert.assertNotNull(date69);
        org.junit.Assert.assertNotNull(timeZone71);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "2019" + "'", str76.equals("2019"));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener13);
        int int15 = timePeriodValues10.getItemCount();
        int int16 = timePeriodValues10.getMaxMiddleIndex();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) year17, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 2019L);
        java.util.Date date22 = year17.getEnd();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date22, timeZone23);
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues26.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timePeriodValues26.removePropertyChangeListener(propertyChangeListener29);
        int int31 = timePeriodValues26.getItemCount();
        int int32 = timePeriodValues26.getMaxMiddleIndex();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        timePeriodValues26.add((org.jfree.data.time.TimePeriod) year33, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue37 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year33, (java.lang.Number) 2019L);
        java.util.Date date38 = year33.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(date22, date38);
        long long40 = simpleTimePeriod39.getEndMillis();
        long long41 = simpleTimePeriod39.getStartMillis();
        boolean boolean43 = simpleTimePeriod39.equals((java.lang.Object) 0);
        java.util.Date date44 = simpleTimePeriod39.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues46 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues46.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener49 = null;
        timePeriodValues46.removePropertyChangeListener(propertyChangeListener49);
        int int51 = timePeriodValues46.getItemCount();
        int int52 = timePeriodValues46.getMaxMiddleIndex();
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year();
        timePeriodValues46.add((org.jfree.data.time.TimePeriod) year53, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue57 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year53, (java.lang.Number) 2019L);
        java.util.Date date58 = year53.getEnd();
        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year(date58);
        java.util.TimeZone timeZone60 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day(date58, timeZone60);
        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day(date44, timeZone60);
        org.jfree.data.time.TimePeriodValues timePeriodValues65 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date44, "Value", "31-December-2019");
        org.jfree.data.time.Year year66 = new org.jfree.data.time.Year();
        long long67 = year66.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue69 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year66, (java.lang.Number) 100);
        java.lang.Object obj70 = timePeriodValue69.clone();
        java.lang.String str71 = timePeriodValue69.toString();
        java.lang.Object obj72 = null;
        boolean boolean73 = timePeriodValue69.equals(obj72);
        boolean boolean74 = timePeriodValues65.equals((java.lang.Object) timePeriodValue69);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1577865599999L + "'", long40 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1577865599999L + "'", long41 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertNotNull(timeZone60);
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 2019L + "'", long67 == 2019L);
        org.junit.Assert.assertNotNull(obj70);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "TimePeriodValue[2019,100]" + "'", str71.equals("TimePeriodValue[2019,100]"));
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMinEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = timePeriodValues1.createCopy(6, (int) (byte) 100);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener13);
        int int15 = timePeriodValues10.getItemCount();
        int int16 = timePeriodValues10.getMaxMiddleIndex();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) year17, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year17.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year17.previous();
        java.lang.Object obj24 = null;
        int int25 = year17.compareTo(obj24);
        java.lang.Number number26 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue27 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, number26);
        java.lang.Object obj28 = timePeriodValue27.clone();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent29 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValue27);
        timePeriodValues1.add(timePeriodValue27);
        int int31 = timePeriodValues1.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
    }

//    @Test
//    public void test098() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test098");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass1 = day0.getClass();
//        long long2 = day0.getLastMillisecond();
//        java.lang.String str3 = day0.toString();
//        int int4 = day0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.previous();
//        org.junit.Assert.assertNotNull(wildcardClass1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560495599999L + "'", long2 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//    }

//    @Test
//    public void test099() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test099");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        int int2 = day0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
//        int int4 = day0.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 13 + "'", int4 == 13);
//    }

//    @Test
//    public void test100() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test100");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.next();
//        long long3 = day0.getFirstMillisecond();
//        int int4 = day0.getYear();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//    }

//    @Test
//    public void test101() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test101");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        timePeriodValues1.setNotify(true);
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        timePeriodValues7.setNotify(true);
//        java.beans.PropertyChangeListener propertyChangeListener10 = null;
//        timePeriodValues7.removePropertyChangeListener(propertyChangeListener10);
//        int int12 = timePeriodValues7.getItemCount();
//        int int13 = timePeriodValues7.getMaxMiddleIndex();
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) year14, (double) 6);
//        org.jfree.data.time.TimePeriodValue timePeriodValue18 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, (java.lang.Number) 2019L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year14.previous();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod19, (double) 2019L);
//        int int22 = timePeriodValues1.getMinEndIndex();
//        int int23 = timePeriodValues1.getItemCount();
//        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
//        long long25 = year24.getSerialIndex();
//        org.jfree.data.time.TimePeriodValue timePeriodValue27 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year24, (java.lang.Number) 100);
//        java.lang.String str28 = timePeriodValue27.toString();
//        timePeriodValues1.add(timePeriodValue27);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate31 = day30.getSerialDate();
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(serialDate31);
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(serialDate31);
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(serialDate31);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = day34.next();
//        long long36 = day34.getSerialIndex();
//        boolean boolean37 = timePeriodValue27.equals((java.lang.Object) day34);
//        org.jfree.data.time.TimePeriodValues timePeriodValues39 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        timePeriodValues39.setNotify(true);
//        java.beans.PropertyChangeListener propertyChangeListener42 = null;
//        timePeriodValues39.removePropertyChangeListener(propertyChangeListener42);
//        int int44 = timePeriodValues39.getItemCount();
//        int int45 = timePeriodValues39.getMaxMiddleIndex();
//        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year();
//        timePeriodValues39.add((org.jfree.data.time.TimePeriod) year46, (double) 6);
//        org.jfree.data.time.TimePeriodValue timePeriodValue50 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year46, (java.lang.Number) 2019L);
//        java.util.Date date51 = year46.getEnd();
//        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year(date51);
//        java.util.TimeZone timeZone53 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day(date51, timeZone53);
//        long long55 = day54.getSerialIndex();
//        java.util.Date date56 = day54.getEnd();
//        int int57 = day34.compareTo((java.lang.Object) day54);
//        int int58 = day34.getYear();
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 2019L + "'", long25 == 2019L);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "TimePeriodValue[2019,100]" + "'", str28.equals("TimePeriodValue[2019,100]"));
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 43629L + "'", long36 == 43629L);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
//        org.junit.Assert.assertNotNull(date51);
//        org.junit.Assert.assertNotNull(timeZone53);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 43830L + "'", long55 == 43830L);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-201) + "'", int57 == (-201));
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 2019 + "'", int58 == 2019);
//    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener11);
        java.lang.String str13 = timePeriodValues1.getDomainDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener14);
        int int16 = timePeriodValues1.getMinEndIndex();
        try {
            java.lang.Number number18 = timePeriodValues1.getValue((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

//    @Test
//    public void test103() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test103");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        timePeriodValues1.setNotify(true);
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        timePeriodValues7.setNotify(true);
//        java.beans.PropertyChangeListener propertyChangeListener10 = null;
//        timePeriodValues7.removePropertyChangeListener(propertyChangeListener10);
//        int int12 = timePeriodValues7.getItemCount();
//        int int13 = timePeriodValues7.getMaxMiddleIndex();
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) year14, (double) 6);
//        org.jfree.data.time.TimePeriodValue timePeriodValue18 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, (java.lang.Number) 2019L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year14.previous();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod19, (double) 2019L);
//        int int22 = timePeriodValues1.getMinEndIndex();
//        int int23 = timePeriodValues1.getItemCount();
//        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
//        long long25 = year24.getSerialIndex();
//        org.jfree.data.time.TimePeriodValue timePeriodValue27 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year24, (java.lang.Number) 100);
//        java.lang.String str28 = timePeriodValue27.toString();
//        timePeriodValues1.add(timePeriodValue27);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate31 = day30.getSerialDate();
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(serialDate31);
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(serialDate31);
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(serialDate31);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = day34.next();
//        long long36 = day34.getSerialIndex();
//        boolean boolean37 = timePeriodValue27.equals((java.lang.Object) day34);
//        org.jfree.data.time.TimePeriodValues timePeriodValues39 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        timePeriodValues39.setNotify(true);
//        java.beans.PropertyChangeListener propertyChangeListener42 = null;
//        timePeriodValues39.removePropertyChangeListener(propertyChangeListener42);
//        int int44 = timePeriodValues39.getItemCount();
//        int int45 = timePeriodValues39.getMaxMiddleIndex();
//        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year();
//        timePeriodValues39.add((org.jfree.data.time.TimePeriod) year46, (double) 6);
//        org.jfree.data.time.TimePeriodValue timePeriodValue50 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year46, (java.lang.Number) 2019L);
//        java.util.Date date51 = year46.getEnd();
//        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year(date51);
//        java.util.TimeZone timeZone53 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day(date51, timeZone53);
//        long long55 = day54.getSerialIndex();
//        java.util.Date date56 = day54.getEnd();
//        int int57 = day34.compareTo((java.lang.Object) day54);
//        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day();
//        java.lang.String str59 = day58.toString();
//        java.util.Date date60 = day58.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = day58.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = day58.next();
//        boolean boolean63 = day34.equals((java.lang.Object) day58);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 2019L + "'", long25 == 2019L);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "TimePeriodValue[2019,100]" + "'", str28.equals("TimePeriodValue[2019,100]"));
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 43629L + "'", long36 == 43629L);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
//        org.junit.Assert.assertNotNull(date51);
//        org.junit.Assert.assertNotNull(timeZone53);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 43830L + "'", long55 == 43830L);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-201) + "'", int57 == (-201));
//        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "13-June-2019" + "'", str59.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(date60);
//        org.junit.Assert.assertNotNull(regularTimePeriod61);
//        org.junit.Assert.assertNotNull(regularTimePeriod62);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
//    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener11);
        java.lang.String str13 = timePeriodValues1.getDomainDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues15.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timePeriodValues15.removePropertyChangeListener(propertyChangeListener18);
        java.lang.String str20 = timePeriodValues15.getDescription();
        int int21 = timePeriodValues15.getMinStartIndex();
        timePeriodValues15.fireSeriesChanged();
        boolean boolean23 = timePeriodValues1.equals((java.lang.Object) timePeriodValues15);
        int int24 = timePeriodValues1.getMaxStartIndex();
        java.lang.Comparable comparable25 = timePeriodValues1.getKey();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener26 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener26);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + comparable25 + "' != '" + (byte) 1 + "'", comparable25.equals((byte) 1));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year8.previous();
        java.lang.String str14 = year8.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year8.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 100.0f);
        org.jfree.data.time.TimePeriod timePeriod18 = timePeriodValue17.getPeriod();
        org.jfree.data.time.TimePeriod timePeriod19 = timePeriodValue17.getPeriod();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019" + "'", str14.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(timePeriod18);
        org.junit.Assert.assertNotNull(timePeriod19);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues1.createCopy(0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timePeriodValues9.addChangeListener(seriesChangeListener10);
        java.lang.Object obj12 = timePeriodValues9.clone();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(timePeriodValues9);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        timePeriodValues1.setNotify(true);
        java.lang.Object obj10 = timePeriodValues1.clone();
        int int11 = timePeriodValues1.getItemCount();
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

//    @Test
//    public void test108() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test108");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass1 = day0.getClass();
//        int int2 = day0.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 8);
//        java.lang.String str5 = timePeriodValue4.toString();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
//        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
//        timePeriodFormatException16.addSuppressed((java.lang.Throwable) timePeriodFormatException18);
//        timePeriodFormatException14.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
//        timePeriodFormatException12.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
//        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
//        boolean boolean23 = timePeriodValue4.equals((java.lang.Object) timePeriodFormatException16);
//        java.lang.Throwable[] throwableArray24 = timePeriodFormatException16.getSuppressed();
//        org.junit.Assert.assertNotNull(wildcardClass1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "TimePeriodValue[13-June-2019,8.0]" + "'", str5.equals("TimePeriodValue[13-June-2019,8.0]"));
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(throwableArray24);
//    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (10) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        timePeriodValues1.setKey((java.lang.Comparable) 100L);
        timePeriodValues1.setKey((java.lang.Comparable) (short) 100);
        java.lang.String str8 = timePeriodValues1.getRangeDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year9, (java.lang.Number) 100);
        timePeriodValues1.add(timePeriodValue12);
        timePeriodValue12.setValue((java.lang.Number) 10L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Value" + "'", str8.equals("Value"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 100);
        java.util.Date date4 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues6.addChangeListener(seriesChangeListener7);
        int int9 = timePeriodValues6.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass10 = timePeriodValues6.getClass();
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date11, timeZone12);
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues15.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timePeriodValues15.removePropertyChangeListener(propertyChangeListener18);
        int int20 = timePeriodValues15.getItemCount();
        int int21 = timePeriodValues15.getMaxMiddleIndex();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        timePeriodValues15.add((org.jfree.data.time.TimePeriod) year22, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue26 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year22, (java.lang.Number) 2019L);
        java.util.Date date27 = year22.getEnd();
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date27, timeZone28);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(date4, timeZone28);
        org.jfree.data.time.TimePeriodValues timePeriodValues32 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener33 = null;
        timePeriodValues32.addChangeListener(seriesChangeListener33);
        int int35 = timePeriodValues32.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass36 = timePeriodValues32.getClass();
        java.util.Date date37 = null;
        java.util.TimeZone timeZone38 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date37, timeZone38);
        org.jfree.data.time.TimePeriodValues timePeriodValues41 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues41.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener44 = null;
        timePeriodValues41.removePropertyChangeListener(propertyChangeListener44);
        int int46 = timePeriodValues41.getItemCount();
        int int47 = timePeriodValues41.getMaxMiddleIndex();
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year();
        timePeriodValues41.add((org.jfree.data.time.TimePeriod) year48, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue52 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year48, (java.lang.Number) 2019L);
        java.util.Date date53 = year48.getEnd();
        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date53, timeZone54);
        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year(date4, timeZone54);
        java.util.TimeZone timeZone57 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(date4, timeZone57);
        int int59 = day58.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = day58.next();
        java.lang.Object obj61 = null;
        int int62 = day58.compareTo(obj61);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = day58.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue65 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day58, (double) (-1));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertNotNull(timeZone54);
        org.junit.Assert.assertNull(regularTimePeriod55);
        org.junit.Assert.assertNotNull(timeZone57);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 2019 + "'", int59 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod60);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1 + "'", int62 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod63);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener13);
        int int15 = timePeriodValues10.getItemCount();
        int int16 = timePeriodValues10.getMaxMiddleIndex();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) year17, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 2019L);
        java.util.Date date22 = year17.getEnd();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date22, timeZone23);
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues26.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timePeriodValues26.removePropertyChangeListener(propertyChangeListener29);
        int int31 = timePeriodValues26.getItemCount();
        int int32 = timePeriodValues26.getMaxMiddleIndex();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        timePeriodValues26.add((org.jfree.data.time.TimePeriod) year33, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue37 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year33, (java.lang.Number) 2019L);
        java.util.Date date38 = year33.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(date22, date38);
        long long40 = simpleTimePeriod39.getEndMillis();
        long long41 = simpleTimePeriod39.getStartMillis();
        boolean boolean43 = simpleTimePeriod39.equals((java.lang.Object) 0);
        java.util.Date date44 = simpleTimePeriod39.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues46 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener47 = null;
        timePeriodValues46.addChangeListener(seriesChangeListener47);
        int int49 = timePeriodValues46.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass50 = timePeriodValues46.getClass();
        java.util.Date date51 = null;
        java.util.TimeZone timeZone52 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass50, date51, timeZone52);
        org.jfree.data.time.TimePeriodValues timePeriodValues55 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues55.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener58 = null;
        timePeriodValues55.removePropertyChangeListener(propertyChangeListener58);
        int int60 = timePeriodValues55.getItemCount();
        int int61 = timePeriodValues55.getMaxMiddleIndex();
        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year();
        timePeriodValues55.add((org.jfree.data.time.TimePeriod) year62, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue66 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year62, (java.lang.Number) 2019L);
        java.util.Date date67 = year62.getEnd();
        java.util.TimeZone timeZone68 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass50, date67, timeZone68);
        org.jfree.data.time.TimePeriodValues timePeriodValues71 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues71.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener74 = null;
        timePeriodValues71.removePropertyChangeListener(propertyChangeListener74);
        int int76 = timePeriodValues71.getItemCount();
        int int77 = timePeriodValues71.getMaxMiddleIndex();
        org.jfree.data.time.Year year78 = new org.jfree.data.time.Year();
        timePeriodValues71.add((org.jfree.data.time.TimePeriod) year78, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue82 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year78, (java.lang.Number) 2019L);
        java.util.Date date83 = year78.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod84 = new org.jfree.data.time.SimpleTimePeriod(date67, date83);
        java.util.TimeZone timeZone85 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year86 = new org.jfree.data.time.Year(date67, timeZone85);
        boolean boolean87 = simpleTimePeriod39.equals((java.lang.Object) date67);
        java.util.Date date88 = simpleTimePeriod39.getStart();
        java.util.TimeZone timeZone89 = null;
        try {
            org.jfree.data.time.Year year90 = new org.jfree.data.time.Year(date88, timeZone89);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1577865599999L + "'", long40 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1577865599999L + "'", long41 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertNull(regularTimePeriod53);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
        org.junit.Assert.assertNotNull(date67);
        org.junit.Assert.assertNotNull(timeZone68);
        org.junit.Assert.assertNull(regularTimePeriod69);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 0 + "'", int76 == 0);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + (-1) + "'", int77 == (-1));
        org.junit.Assert.assertNotNull(date83);
        org.junit.Assert.assertNotNull(timeZone85);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertNotNull(date88);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 2019L);
        java.lang.Class<?> wildcardClass13 = year8.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues15.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timePeriodValues15.removePropertyChangeListener(propertyChangeListener18);
        int int20 = timePeriodValues15.getItemCount();
        int int21 = timePeriodValues15.getMaxMiddleIndex();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        timePeriodValues15.add((org.jfree.data.time.TimePeriod) year22, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue26 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year22, (java.lang.Number) 2019L);
        boolean boolean27 = year8.equals((java.lang.Object) 2019L);
        long long28 = year8.getSerialIndex();
        long long29 = year8.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue31 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, 1.0d);
        org.jfree.data.time.TimePeriod timePeriod32 = timePeriodValue31.getPeriod();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 2019L + "'", long28 == 2019L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 2019L + "'", long29 == 2019L);
        org.junit.Assert.assertNotNull(timePeriod32);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        int int9 = timePeriodValues1.getMinEndIndex();
        int int10 = timePeriodValues1.getItemCount();
        java.lang.String str11 = timePeriodValues1.getRangeDescription();
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Value" + "'", str11.equals("Value"));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(serialDate1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(serialDate1);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(serialDate1);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate1);
        org.jfree.data.time.SerialDate serialDate6 = day5.getSerialDate();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = day5.getMiddleMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(serialDate6);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10);
        int int2 = timePeriodValues1.getMaxStartIndex();
        int int3 = timePeriodValues1.getMinMiddleIndex();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        int int11 = timePeriodValues1.getMaxMiddleIndex();
        timePeriodValues1.setNotify(true);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener14);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener16 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener16);
        java.lang.Number number19 = null;
        try {
            timePeriodValues1.update(0, number19);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year8.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year8.previous();
        java.lang.Object obj15 = null;
        int int16 = year8.compareTo(obj15);
        java.lang.Number number17 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue18 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, number17);
        long long19 = year8.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2019L + "'", long19 == 2019L);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        int int9 = timePeriodValues1.getMinEndIndex();
        int int10 = timePeriodValues1.getItemCount();
        boolean boolean11 = timePeriodValues1.isEmpty();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("TimePeriodValue[13-June-2019,8.0]");
        boolean boolean14 = timePeriodValues1.equals((java.lang.Object) "TimePeriodValue[13-June-2019,8.0]");
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        int int11 = timePeriodValues1.getMaxEndIndex();
        boolean boolean13 = timePeriodValues1.equals((java.lang.Object) (-1L));
        int int14 = timePeriodValues1.getMaxMiddleIndex();
        timePeriodValues1.setNotify(false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) (-201));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "2019");
        java.lang.String str2 = timePeriodValues1.getRangeDescription();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Value" + "'", str2.equals("Value"));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 100);
        java.lang.Object obj4 = timePeriodValue3.clone();
        java.lang.String str5 = timePeriodValue3.toString();
        boolean boolean7 = timePeriodValue3.equals((java.lang.Object) 100);
        java.lang.Number number8 = timePeriodValue3.getValue();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "TimePeriodValue[2019,100]" + "'", str5.equals("TimePeriodValue[2019,100]"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 100 + "'", number8.equals(100));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        int int11 = timePeriodValues1.getMaxEndIndex();
        java.lang.String str12 = timePeriodValues1.getRangeDescription();
        java.lang.Class<?> wildcardClass13 = timePeriodValues1.getClass();
        java.lang.String str14 = timePeriodValues1.getRangeDescription();
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Value" + "'", str12.equals("Value"));
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Value" + "'", str14.equals("Value"));
    }

//    @Test
//    public void test125() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test125");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(serialDate1);
//        java.lang.String str3 = day2.toString();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 'a', (long) (byte) 100);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener13);
        int int15 = timePeriodValues10.getItemCount();
        int int16 = timePeriodValues10.getMaxMiddleIndex();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) year17, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 2019L);
        java.util.Date date22 = year17.getEnd();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date22, timeZone23);
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues26.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timePeriodValues26.removePropertyChangeListener(propertyChangeListener29);
        int int31 = timePeriodValues26.getItemCount();
        int int32 = timePeriodValues26.getMaxMiddleIndex();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        timePeriodValues26.add((org.jfree.data.time.TimePeriod) year33, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue37 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year33, (java.lang.Number) 2019L);
        java.util.Date date38 = year33.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(date22, date38);
        long long40 = simpleTimePeriod39.getEndMillis();
        long long41 = simpleTimePeriod39.getStartMillis();
        boolean boolean43 = simpleTimePeriod39.equals((java.lang.Object) 0);
        java.util.Date date44 = simpleTimePeriod39.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues46 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener47 = null;
        timePeriodValues46.addChangeListener(seriesChangeListener47);
        int int49 = timePeriodValues46.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass50 = timePeriodValues46.getClass();
        java.util.Date date51 = null;
        java.util.TimeZone timeZone52 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass50, date51, timeZone52);
        org.jfree.data.time.TimePeriodValues timePeriodValues55 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues55.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener58 = null;
        timePeriodValues55.removePropertyChangeListener(propertyChangeListener58);
        int int60 = timePeriodValues55.getItemCount();
        int int61 = timePeriodValues55.getMaxMiddleIndex();
        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year();
        timePeriodValues55.add((org.jfree.data.time.TimePeriod) year62, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue66 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year62, (java.lang.Number) 2019L);
        java.util.Date date67 = year62.getEnd();
        java.util.TimeZone timeZone68 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass50, date67, timeZone68);
        org.jfree.data.time.TimePeriodValues timePeriodValues71 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues71.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener74 = null;
        timePeriodValues71.removePropertyChangeListener(propertyChangeListener74);
        int int76 = timePeriodValues71.getItemCount();
        int int77 = timePeriodValues71.getMaxMiddleIndex();
        org.jfree.data.time.Year year78 = new org.jfree.data.time.Year();
        timePeriodValues71.add((org.jfree.data.time.TimePeriod) year78, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue82 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year78, (java.lang.Number) 2019L);
        java.util.Date date83 = year78.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod84 = new org.jfree.data.time.SimpleTimePeriod(date67, date83);
        java.util.TimeZone timeZone85 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year86 = new org.jfree.data.time.Year(date67, timeZone85);
        boolean boolean87 = simpleTimePeriod39.equals((java.lang.Object) date67);
        long long88 = simpleTimePeriod39.getEndMillis();
        org.jfree.data.time.TimePeriodValue timePeriodValue90 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod39, (java.lang.Number) 31);
        long long91 = simpleTimePeriod39.getStartMillis();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1577865599999L + "'", long40 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1577865599999L + "'", long41 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertNull(regularTimePeriod53);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
        org.junit.Assert.assertNotNull(date67);
        org.junit.Assert.assertNotNull(timeZone68);
        org.junit.Assert.assertNull(regularTimePeriod69);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 0 + "'", int76 == 0);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + (-1) + "'", int77 == (-1));
        org.junit.Assert.assertNotNull(date83);
        org.junit.Assert.assertNotNull(timeZone85);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertTrue("'" + long88 + "' != '" + 1577865599999L + "'", long88 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long91 + "' != '" + 1577865599999L + "'", long91 == 1577865599999L);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(serialDate1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(serialDate1);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(serialDate1);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate1);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate1);
        java.util.Calendar calendar7 = null;
        try {
            long long8 = day6.getMiddleMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
    }

//    @Test
//    public void test129() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test129");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(32L, 1560409200000L);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        java.lang.String str4 = day3.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day3.next();
//        boolean boolean7 = simpleTimePeriod2.equals((java.lang.Object) day3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "13-June-2019" + "'", str4.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMinEndIndex();
        int int6 = timePeriodValues1.getMinMiddleIndex();
        timePeriodValues1.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        long long3 = year2.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year2, (java.lang.Number) 100);
        java.util.Date date6 = year2.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues8.addChangeListener(seriesChangeListener9);
        int int11 = timePeriodValues8.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass12 = timePeriodValues8.getClass();
        java.util.Date date13 = null;
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date13, timeZone14);
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues17.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timePeriodValues17.removePropertyChangeListener(propertyChangeListener20);
        int int22 = timePeriodValues17.getItemCount();
        int int23 = timePeriodValues17.getMaxMiddleIndex();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        timePeriodValues17.add((org.jfree.data.time.TimePeriod) year24, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue28 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year24, (java.lang.Number) 2019L);
        java.util.Date date29 = year24.getEnd();
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date29, timeZone30);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date6, timeZone30);
        org.jfree.data.time.TimePeriodValues timePeriodValues34 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener35 = null;
        timePeriodValues34.addChangeListener(seriesChangeListener35);
        int int37 = timePeriodValues34.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass38 = timePeriodValues34.getClass();
        java.util.Date date39 = null;
        java.util.TimeZone timeZone40 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass38, date39, timeZone40);
        org.jfree.data.time.TimePeriodValues timePeriodValues43 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues43.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener46 = null;
        timePeriodValues43.removePropertyChangeListener(propertyChangeListener46);
        int int48 = timePeriodValues43.getItemCount();
        int int49 = timePeriodValues43.getMaxMiddleIndex();
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
        timePeriodValues43.add((org.jfree.data.time.TimePeriod) year50, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue54 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year50, (java.lang.Number) 2019L);
        java.util.Date date55 = year50.getEnd();
        java.util.TimeZone timeZone56 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass38, date55, timeZone56);
        org.jfree.data.time.TimePeriodValues timePeriodValues59 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues59.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener62 = null;
        timePeriodValues59.removePropertyChangeListener(propertyChangeListener62);
        int int64 = timePeriodValues59.getItemCount();
        int int65 = timePeriodValues59.getMaxMiddleIndex();
        org.jfree.data.time.Year year66 = new org.jfree.data.time.Year();
        timePeriodValues59.add((org.jfree.data.time.TimePeriod) year66, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue70 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year66, (java.lang.Number) 2019L);
        java.util.Date date71 = year66.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod72 = new org.jfree.data.time.SimpleTimePeriod(date55, date71);
        java.util.TimeZone timeZone73 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year74 = new org.jfree.data.time.Year(date55, timeZone73);
        org.jfree.data.time.Year year75 = new org.jfree.data.time.Year(date6, timeZone73);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year75, (double) 1560452399999L);
        long long78 = year75.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass38);
        org.junit.Assert.assertNull(regularTimePeriod41);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(timeZone56);
        org.junit.Assert.assertNull(regularTimePeriod57);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + (-1) + "'", int65 == (-1));
        org.junit.Assert.assertNotNull(date71);
        org.junit.Assert.assertNotNull(timeZone73);
        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 1562097599999L + "'", long78 == 1562097599999L);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener13);
        int int15 = timePeriodValues10.getItemCount();
        int int16 = timePeriodValues10.getMaxMiddleIndex();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) year17, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 2019L);
        java.util.Date date22 = year17.getEnd();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date22, timeZone23);
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues26.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timePeriodValues26.removePropertyChangeListener(propertyChangeListener29);
        int int31 = timePeriodValues26.getItemCount();
        int int32 = timePeriodValues26.getMaxMiddleIndex();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        timePeriodValues26.add((org.jfree.data.time.TimePeriod) year33, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue37 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year33, (java.lang.Number) 2019L);
        java.util.Date date38 = year33.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(date22, date38);
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year(date22);
        int int41 = year40.getYear();
        long long42 = year40.getFirstMillisecond();
        long long43 = year40.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 2019 + "'", int41 == 2019);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1546329600000L + "'", long42 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1577865599999L + "'", long43 == 1577865599999L);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "2019");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDescription("31-December-2019");
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (java.lang.Number) 100);
        java.util.Date date11 = year7.getStart();
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (java.lang.Number) (short) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year7.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod14, (java.lang.Number) (-1));
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 100);
        java.util.Date date21 = year17.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener24 = null;
        timePeriodValues23.addChangeListener(seriesChangeListener24);
        int int26 = timePeriodValues23.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass27 = timePeriodValues23.getClass();
        java.util.Date date28 = null;
        java.util.TimeZone timeZone29 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass27, date28, timeZone29);
        org.jfree.data.time.TimePeriodValues timePeriodValues32 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues32.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener35 = null;
        timePeriodValues32.removePropertyChangeListener(propertyChangeListener35);
        int int37 = timePeriodValues32.getItemCount();
        int int38 = timePeriodValues32.getMaxMiddleIndex();
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
        timePeriodValues32.add((org.jfree.data.time.TimePeriod) year39, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue43 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year39, (java.lang.Number) 2019L);
        java.util.Date date44 = year39.getEnd();
        java.util.TimeZone timeZone45 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass27, date44, timeZone45);
        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year(date21, timeZone45);
        org.jfree.data.time.TimePeriodValues timePeriodValues49 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener50 = null;
        timePeriodValues49.addChangeListener(seriesChangeListener50);
        int int52 = timePeriodValues49.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass53 = timePeriodValues49.getClass();
        java.util.Date date54 = null;
        java.util.TimeZone timeZone55 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass53, date54, timeZone55);
        org.jfree.data.time.TimePeriodValues timePeriodValues58 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues58.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener61 = null;
        timePeriodValues58.removePropertyChangeListener(propertyChangeListener61);
        int int63 = timePeriodValues58.getItemCount();
        int int64 = timePeriodValues58.getMaxMiddleIndex();
        org.jfree.data.time.Year year65 = new org.jfree.data.time.Year();
        timePeriodValues58.add((org.jfree.data.time.TimePeriod) year65, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue69 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year65, (java.lang.Number) 2019L);
        java.util.Date date70 = year65.getEnd();
        java.util.TimeZone timeZone71 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass53, date70, timeZone71);
        org.jfree.data.time.Year year73 = new org.jfree.data.time.Year(date21, timeZone71);
        java.util.TimeZone timeZone74 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day75 = new org.jfree.data.time.Day(date21, timeZone74);
        org.jfree.data.time.Year year76 = new org.jfree.data.time.Year(date21);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year76, (double) 4);
        timePeriodValues1.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2019L + "'", long18 == 2019L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(timeZone45);
        org.junit.Assert.assertNull(regularTimePeriod46);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass53);
        org.junit.Assert.assertNull(regularTimePeriod56);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + (-1) + "'", int64 == (-1));
        org.junit.Assert.assertNotNull(date70);
        org.junit.Assert.assertNotNull(timeZone71);
        org.junit.Assert.assertNull(regularTimePeriod72);
        org.junit.Assert.assertNotNull(timeZone74);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener13);
        int int15 = timePeriodValues10.getItemCount();
        int int16 = timePeriodValues10.getMaxMiddleIndex();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) year17, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 2019L);
        java.util.Date date22 = year17.getEnd();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date22, timeZone23);
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues26.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timePeriodValues26.removePropertyChangeListener(propertyChangeListener29);
        int int31 = timePeriodValues26.getItemCount();
        int int32 = timePeriodValues26.getMaxMiddleIndex();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        timePeriodValues26.add((org.jfree.data.time.TimePeriod) year33, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue37 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year33, (java.lang.Number) 2019L);
        java.util.Date date38 = year33.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(date22, date38);
        java.util.TimeZone timeZone40 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year(date22, timeZone40);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = year41.previous();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod45 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) ' ');
        long long46 = simpleTimePeriod45.getStartMillis();
        boolean boolean47 = year41.equals((java.lang.Object) long46);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(timeZone40);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 0L + "'", long46 == 0L);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 2019L);
        java.util.Date date13 = year8.getEnd();
        long long14 = year8.getMiddleMillisecond();
        java.lang.Class<?> wildcardClass15 = year8.getClass();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
        int int17 = day16.getYear();
        int int18 = day16.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day16.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day16, (double) 1.0f);
        java.util.Date date22 = day16.getStart();
        java.util.TimeZone timeZone23 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date22, timeZone23);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date22);
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day25);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1562097599999L + "'", long14 == 1562097599999L);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNull(regularTimePeriod24);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        long long3 = year2.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year2, (java.lang.Number) 100);
        java.lang.Object obj6 = timePeriodValue5.clone();
        int int7 = day0.compareTo(obj6);
        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 1560365999999L);
        timePeriodValue9.setValue((java.lang.Number) 10);
        java.lang.Number number12 = timePeriodValue9.getValue();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 10 + "'", number12.equals(10));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 13);
    }

//    @Test
//    public void test138() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test138");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 0L);
//        int int3 = day0.getYear();
//        java.lang.String str4 = day0.toString();
//        int int5 = day0.getDayOfMonth();
//        int int6 = day0.getYear();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "13-June-2019" + "'", str4.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//    }

//    @Test
//    public void test139() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test139");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.next();
//        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        timePeriodValues4.setNotify(true);
//        timePeriodValues4.setKey((java.lang.Comparable) 100L);
//        int int9 = timePeriodValues4.getMaxMiddleIndex();
//        boolean boolean10 = day0.equals((java.lang.Object) timePeriodValues4);
//        java.lang.String str11 = timePeriodValues4.getRangeDescription();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Value" + "'", str11.equals("Value"));
//    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 1, (long) 11);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        timePeriodValues1.setKey((java.lang.Comparable) "hi!");
        timePeriodValues1.setDescription("Value");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener8);
        timePeriodValues1.setRangeDescription("31-December-2019");
        timePeriodValues1.setRangeDescription("org.jfree.data.general.SeriesException: TimePeriodValue[13-June-2019,8.0]");
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        boolean boolean5 = timePeriodValues1.equals((java.lang.Object) (short) 0);
        int int6 = timePeriodValues1.getMaxEndIndex();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (java.lang.Number) 100);
        java.lang.String str11 = timePeriodValue10.toString();
        boolean boolean13 = timePeriodValue10.equals((java.lang.Object) (short) 100);
        java.lang.Object obj14 = timePeriodValue10.clone();
        org.jfree.data.time.TimePeriod timePeriod15 = timePeriodValue10.getPeriod();
        timePeriodValues1.add(timePeriod15, (java.lang.Number) 8);
        timePeriodValues1.setRangeDescription("TimePeriodValue[2019,100.0]");
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "TimePeriodValue[2019,100]" + "'", str11.equals("TimePeriodValue[2019,100]"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(timePeriod15);
    }

//    @Test
//    public void test143() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test143");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        timePeriodValues1.setNotify(true);
//        timePeriodValues1.setKey((java.lang.Comparable) 100L);
//        timePeriodValues1.setKey((java.lang.Comparable) (short) 100);
//        java.lang.String str8 = timePeriodValues1.getRangeDescription();
//        int int9 = timePeriodValues1.getMinStartIndex();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
//        timePeriodValues1.removeChangeListener(seriesChangeListener10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        int int13 = day12.getMonth();
//        long long14 = day12.getMiddleMillisecond();
//        org.jfree.data.time.SerialDate serialDate15 = day12.getSerialDate();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate17 = day16.getSerialDate();
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(serialDate17);
//        boolean boolean19 = day12.equals((java.lang.Object) serialDate17);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(serialDate17);
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day20, (java.lang.Number) 0);
//        long long23 = day20.getSerialIndex();
//        java.util.Calendar calendar24 = null;
//        try {
//            long long25 = day20.getFirstMillisecond(calendar24);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Value" + "'", str8.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560452399999L + "'", long14 == 1560452399999L);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 43629L + "'", long23 == 43629L);
//    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        timePeriodValues1.setNotify(true);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year10, (java.lang.Number) 100);
        timePeriodValue13.setValue((java.lang.Number) 3);
        org.jfree.data.time.TimePeriod timePeriod16 = timePeriodValue13.getPeriod();
        timePeriodValues1.add(timePeriodValue13);
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues19.setNotify(true);
        timePeriodValues19.setKey((java.lang.Comparable) 100L);
        timePeriodValues19.setKey((java.lang.Comparable) (short) 100);
        java.lang.String str26 = timePeriodValues19.getRangeDescription();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        long long28 = year27.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue30 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year27, (java.lang.Number) 100);
        timePeriodValues19.add(timePeriodValue30);
        boolean boolean32 = timePeriodValue13.equals((java.lang.Object) timePeriodValues19);
        java.lang.String str33 = timePeriodValue13.toString();
        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues35.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener38 = null;
        timePeriodValues35.removePropertyChangeListener(propertyChangeListener38);
        java.lang.String str40 = timePeriodValues35.getDescription();
        int int41 = timePeriodValues35.getMinStartIndex();
        int int42 = timePeriodValues35.getMaxEndIndex();
        timePeriodValues35.setDomainDescription("");
        int int45 = timePeriodValues35.getMaxEndIndex();
        boolean boolean47 = timePeriodValues35.equals((java.lang.Object) (-1L));
        boolean boolean48 = timePeriodValue13.equals((java.lang.Object) timePeriodValues35);
        java.lang.Comparable comparable49 = timePeriodValues35.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues52 = timePeriodValues35.createCopy((int) (byte) 100, 12);
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year();
        long long54 = year53.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue56 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year53, (java.lang.Number) 100);
        java.util.Date date57 = year53.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues59 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener60 = null;
        timePeriodValues59.addChangeListener(seriesChangeListener60);
        int int62 = timePeriodValues59.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass63 = timePeriodValues59.getClass();
        java.util.Date date64 = null;
        java.util.TimeZone timeZone65 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass63, date64, timeZone65);
        org.jfree.data.time.TimePeriodValues timePeriodValues68 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues68.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener71 = null;
        timePeriodValues68.removePropertyChangeListener(propertyChangeListener71);
        int int73 = timePeriodValues68.getItemCount();
        int int74 = timePeriodValues68.getMaxMiddleIndex();
        org.jfree.data.time.Year year75 = new org.jfree.data.time.Year();
        timePeriodValues68.add((org.jfree.data.time.TimePeriod) year75, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue79 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year75, (java.lang.Number) 2019L);
        java.util.Date date80 = year75.getEnd();
        java.util.TimeZone timeZone81 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod82 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass63, date80, timeZone81);
        org.jfree.data.time.Year year83 = new org.jfree.data.time.Year(date57, timeZone81);
        timePeriodValues52.setKey((java.lang.Comparable) date57);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
        org.junit.Assert.assertNotNull(timePeriod16);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Value" + "'", str26.equals("Value"));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 2019L + "'", long28 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "TimePeriodValue[2019,3]" + "'", str33.equals("TimePeriodValue[2019,3]"));
        org.junit.Assert.assertNull(str40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + comparable49 + "' != '" + (byte) 1 + "'", comparable49.equals((byte) 1));
        org.junit.Assert.assertNotNull(timePeriodValues52);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 2019L + "'", long54 == 2019L);
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-1) + "'", int62 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass63);
        org.junit.Assert.assertNull(regularTimePeriod66);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 0 + "'", int73 == 0);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + (-1) + "'", int74 == (-1));
        org.junit.Assert.assertNotNull(date80);
        org.junit.Assert.assertNotNull(timeZone81);
        org.junit.Assert.assertNull(regularTimePeriod82);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener13);
        int int15 = timePeriodValues10.getItemCount();
        int int16 = timePeriodValues10.getMaxMiddleIndex();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) year17, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 2019L);
        java.util.Date date22 = year17.getEnd();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date22, timeZone23);
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues26.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timePeriodValues26.removePropertyChangeListener(propertyChangeListener29);
        int int31 = timePeriodValues26.getItemCount();
        int int32 = timePeriodValues26.getMaxMiddleIndex();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        timePeriodValues26.add((org.jfree.data.time.TimePeriod) year33, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue37 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year33, (java.lang.Number) 2019L);
        java.util.Date date38 = year33.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(date22, date38);
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year(date22);
        java.util.Calendar calendar41 = null;
        try {
            long long42 = year40.getFirstMillisecond(calendar41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(date38);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        int int11 = timePeriodValues1.getMaxEndIndex();
        java.lang.String str12 = timePeriodValues1.getRangeDescription();
        timePeriodValues1.setKey((java.lang.Comparable) 7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener15);
        try {
            java.lang.Number number18 = timePeriodValues1.getValue(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Value" + "'", str12.equals("Value"));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 100);
        java.util.Date date4 = year0.getStart();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) (short) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues8.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues8.removePropertyChangeListener(propertyChangeListener11);
        java.lang.String str13 = timePeriodValues8.getDescription();
        int int14 = timePeriodValues8.getMinStartIndex();
        int int15 = timePeriodValues8.getMaxEndIndex();
        timePeriodValues8.setDomainDescription("");
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timePeriodValues8.removePropertyChangeListener(propertyChangeListener18);
        int int20 = timePeriodValues8.getMaxEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues23 = timePeriodValues8.createCopy(5, (int) '#');
        int int24 = year0.compareTo((java.lang.Object) 5);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
    }

//    @Test
//    public void test148() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test148");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass1 = day0.getClass();
//        long long2 = day0.getLastMillisecond();
//        long long3 = day0.getMiddleMillisecond();
//        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
//        org.junit.Assert.assertNotNull(wildcardClass1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560495599999L + "'", long2 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560452399999L + "'", long3 == 1560452399999L);
//        org.junit.Assert.assertNotNull(serialDate4);
//    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "2019");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDescription("31-December-2019");
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (java.lang.Number) 100);
        java.util.Date date11 = year7.getStart();
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (java.lang.Number) (short) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year7.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod14, (java.lang.Number) (-1));
        java.lang.String str17 = timePeriodValues1.getRangeDescription();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Value" + "'", str17.equals("Value"));
    }

//    @Test
//    public void test150() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test150");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        java.lang.Object obj2 = null;
//        boolean boolean3 = day0.equals(obj2);
//        int int4 = day0.getYear();
//        long long5 = day0.getSerialIndex();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43629L + "'", long5 == 43629L);
//    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues7.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues7.removePropertyChangeListener(propertyChangeListener10);
        int int12 = timePeriodValues7.getItemCount();
        int int13 = timePeriodValues7.getMaxMiddleIndex();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        timePeriodValues7.add((org.jfree.data.time.TimePeriod) year14, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue18 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year14.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod19, (double) 2019L);
        int int22 = timePeriodValues1.getMinEndIndex();
        int int23 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setRangeDescription("31-December-2019");
        java.beans.PropertyChangeListener propertyChangeListener26 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener26);
        boolean boolean28 = timePeriodValues1.isEmpty();
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        int int11 = timePeriodValues1.getMaxStartIndex();
        java.lang.String str12 = timePeriodValues1.getDescription();
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues9.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues9.removePropertyChangeListener(propertyChangeListener12);
        int int14 = timePeriodValues9.getItemCount();
        int int15 = timePeriodValues9.getMaxMiddleIndex();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        timePeriodValues9.add((org.jfree.data.time.TimePeriod) year16, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year16, (java.lang.Number) 2019L);
        java.lang.Class<?> wildcardClass21 = year16.getClass();
        long long22 = year16.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year16.next();
        timePeriodValues1.setKey((java.lang.Comparable) regularTimePeriod23);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 2019L + "'", long22 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.String str8 = timePeriodFormatException3.toString();
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException3.getSuppressed();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesChangeEvent[source=0]" + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesChangeEvent[source=0]"));
        org.junit.Assert.assertNotNull(throwableArray9);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 100);
        java.util.Date date4 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues6.addChangeListener(seriesChangeListener7);
        int int9 = timePeriodValues6.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass10 = timePeriodValues6.getClass();
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date11, timeZone12);
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues15.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timePeriodValues15.removePropertyChangeListener(propertyChangeListener18);
        int int20 = timePeriodValues15.getItemCount();
        int int21 = timePeriodValues15.getMaxMiddleIndex();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        timePeriodValues15.add((org.jfree.data.time.TimePeriod) year22, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue26 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year22, (java.lang.Number) 2019L);
        java.util.Date date27 = year22.getEnd();
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date27, timeZone28);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(date4, timeZone28);
        org.jfree.data.time.TimePeriodValues timePeriodValues32 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener33 = null;
        timePeriodValues32.addChangeListener(seriesChangeListener33);
        int int35 = timePeriodValues32.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass36 = timePeriodValues32.getClass();
        java.util.Date date37 = null;
        java.util.TimeZone timeZone38 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date37, timeZone38);
        org.jfree.data.time.TimePeriodValues timePeriodValues41 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues41.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener44 = null;
        timePeriodValues41.removePropertyChangeListener(propertyChangeListener44);
        int int46 = timePeriodValues41.getItemCount();
        int int47 = timePeriodValues41.getMaxMiddleIndex();
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year();
        timePeriodValues41.add((org.jfree.data.time.TimePeriod) year48, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue52 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year48, (java.lang.Number) 2019L);
        java.util.Date date53 = year48.getEnd();
        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date53, timeZone54);
        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year(date4, timeZone54);
        java.util.TimeZone timeZone57 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(date4, timeZone57);
        long long59 = day58.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertNotNull(timeZone54);
        org.junit.Assert.assertNull(regularTimePeriod55);
        org.junit.Assert.assertNotNull(timeZone57);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 43466L + "'", long59 == 43466L);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        int int11 = timePeriodValues1.getMaxEndIndex();
        java.lang.String str12 = timePeriodValues1.getRangeDescription();
        timePeriodValues1.setKey((java.lang.Comparable) 7);
        boolean boolean15 = timePeriodValues1.isEmpty();
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Value" + "'", str12.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener13);
        int int15 = timePeriodValues10.getItemCount();
        int int16 = timePeriodValues10.getMaxMiddleIndex();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) year17, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 2019L);
        java.util.Date date22 = year17.getEnd();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date22, timeZone23);
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues26.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timePeriodValues26.removePropertyChangeListener(propertyChangeListener29);
        int int31 = timePeriodValues26.getItemCount();
        int int32 = timePeriodValues26.getMaxMiddleIndex();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        timePeriodValues26.add((org.jfree.data.time.TimePeriod) year33, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue37 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year33, (java.lang.Number) 2019L);
        java.util.Date date38 = year33.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(date22, date38);
        long long40 = simpleTimePeriod39.getEndMillis();
        long long41 = simpleTimePeriod39.getStartMillis();
        boolean boolean43 = simpleTimePeriod39.equals((java.lang.Object) 0);
        java.util.Date date44 = simpleTimePeriod39.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues46 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues46.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener49 = null;
        timePeriodValues46.removePropertyChangeListener(propertyChangeListener49);
        int int51 = timePeriodValues46.getItemCount();
        int int52 = timePeriodValues46.getMaxMiddleIndex();
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year();
        timePeriodValues46.add((org.jfree.data.time.TimePeriod) year53, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue57 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year53, (java.lang.Number) 2019L);
        java.util.Date date58 = year53.getEnd();
        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year(date58);
        java.util.TimeZone timeZone60 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day(date58, timeZone60);
        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day(date44, timeZone60);
        org.jfree.data.time.TimePeriodValues timePeriodValues65 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date44, "Value", "31-December-2019");
        java.util.Date date66 = null;
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod67 = new org.jfree.data.time.SimpleTimePeriod(date44, date66);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1577865599999L + "'", long40 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1577865599999L + "'", long41 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertNotNull(timeZone60);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        int int11 = timePeriodValues1.getItemCount();
        java.lang.Object obj12 = timePeriodValues1.clone();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener11);
        java.lang.String str13 = timePeriodValues1.getDomainDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues15.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timePeriodValues15.removePropertyChangeListener(propertyChangeListener18);
        java.lang.String str20 = timePeriodValues15.getDescription();
        int int21 = timePeriodValues15.getMinStartIndex();
        timePeriodValues15.fireSeriesChanged();
        boolean boolean23 = timePeriodValues1.equals((java.lang.Object) timePeriodValues15);
        int int24 = timePeriodValues1.getMaxStartIndex();
        java.lang.Comparable comparable25 = timePeriodValues1.getKey();
        boolean boolean26 = timePeriodValues1.getNotify();
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues28.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timePeriodValues28.removePropertyChangeListener(propertyChangeListener31);
        org.jfree.data.time.TimePeriodValues timePeriodValues34 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues34.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener37 = null;
        timePeriodValues34.removePropertyChangeListener(propertyChangeListener37);
        int int39 = timePeriodValues34.getItemCount();
        int int40 = timePeriodValues34.getMaxMiddleIndex();
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
        timePeriodValues34.add((org.jfree.data.time.TimePeriod) year41, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue45 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year41, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = year41.previous();
        timePeriodValues28.add((org.jfree.data.time.TimePeriod) regularTimePeriod46, (double) 2019L);
        java.lang.Object obj49 = timePeriodValues28.clone();
        boolean boolean50 = timePeriodValues1.equals(obj49);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + comparable25 + "' != '" + (byte) 1 + "'", comparable25.equals((byte) 1));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertNotNull(obj49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        int int11 = timePeriodValues1.getItemCount();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues13.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues13.removePropertyChangeListener(propertyChangeListener16);
        int int18 = timePeriodValues13.getItemCount();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        long long20 = year19.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue22 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year19, (java.lang.Number) 100);
        java.lang.Object obj23 = timePeriodValue22.clone();
        timePeriodValues13.add(timePeriodValue22);
        java.lang.String str25 = timePeriodValue22.toString();
        java.lang.Object obj26 = timePeriodValue22.clone();
        timePeriodValues1.add(timePeriodValue22);
        timePeriodValue22.setValue((java.lang.Number) 10.0f);
        java.lang.Number number30 = timePeriodValue22.getValue();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 2019L + "'", long20 == 2019L);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "TimePeriodValue[2019,100]" + "'", str25.equals("TimePeriodValue[2019,100]"));
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertTrue("'" + number30 + "' != '" + 10.0f + "'", number30.equals(10.0f));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener11);
        int int13 = timePeriodValues1.getMaxEndIndex();
        int int14 = timePeriodValues1.getMaxMiddleIndex();
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMinEndIndex();
        java.lang.String str6 = timePeriodValues1.getRangeDescription();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year7.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod9, (java.lang.Number) 6);
        timePeriodValues1.setDomainDescription("Value");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener14);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Value" + "'", str6.equals("Value"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

//    @Test
//    public void test163() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test163");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass1 = day0.getClass();
//        long long2 = day0.getLastMillisecond();
//        long long3 = day0.getMiddleMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) ' ');
//        long long6 = day0.getSerialIndex();
//        org.junit.Assert.assertNotNull(wildcardClass1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560495599999L + "'", long2 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560452399999L + "'", long3 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43629L + "'", long6 == 43629L);
//    }

//    @Test
//    public void test164() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test164");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        timePeriodValues1.setNotify(true);
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
//        java.lang.String str6 = timePeriodValues1.getDescription();
//        int int7 = timePeriodValues1.getMinStartIndex();
//        int int8 = timePeriodValues1.getMaxEndIndex();
//        timePeriodValues1.setDomainDescription("");
//        java.beans.PropertyChangeListener propertyChangeListener11 = null;
//        timePeriodValues1.removePropertyChangeListener(propertyChangeListener11);
//        java.lang.String str13 = timePeriodValues1.getDomainDescription();
//        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        timePeriodValues15.setNotify(true);
//        java.beans.PropertyChangeListener propertyChangeListener18 = null;
//        timePeriodValues15.removePropertyChangeListener(propertyChangeListener18);
//        java.lang.String str20 = timePeriodValues15.getDescription();
//        int int21 = timePeriodValues15.getMinStartIndex();
//        timePeriodValues15.fireSeriesChanged();
//        boolean boolean23 = timePeriodValues1.equals((java.lang.Object) timePeriodValues15);
//        int int24 = timePeriodValues1.getMaxStartIndex();
//        int int25 = timePeriodValues1.getMaxStartIndex();
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass27 = day26.getClass();
//        long long28 = day26.getLastMillisecond();
//        long long29 = day26.getMiddleMillisecond();
//        timePeriodValues1.setKey((java.lang.Comparable) day26);
//        long long31 = day26.getSerialIndex();
//        long long32 = day26.getSerialIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues34 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        timePeriodValues34.setNotify(true);
//        java.beans.PropertyChangeListener propertyChangeListener37 = null;
//        timePeriodValues34.removePropertyChangeListener(propertyChangeListener37);
//        int int39 = timePeriodValues34.getItemCount();
//        int int40 = timePeriodValues34.getMaxMiddleIndex();
//        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
//        timePeriodValues34.add((org.jfree.data.time.TimePeriod) year41, (double) 6);
//        org.jfree.data.time.TimePeriodValue timePeriodValue45 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year41, (java.lang.Number) 2019L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = year41.previous();
//        java.lang.String str47 = year41.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = year41.next();
//        java.lang.Number number49 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue50 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod48, number49);
//        int int51 = day26.compareTo((java.lang.Object) regularTimePeriod48);
//        java.util.Date date52 = day26.getStart();
//        int int53 = day26.getYear();
//        org.junit.Assert.assertNull(str6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertNull(str20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass27);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560495599999L + "'", long28 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560452399999L + "'", long29 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 43629L + "'", long31 == 43629L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 43629L + "'", long32 == 43629L);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "2019" + "'", str47.equals("2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod48);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 2019 + "'", int53 == 2019);
//    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMinEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = timePeriodValues1.createCopy(6, (int) (byte) 100);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener13);
        int int15 = timePeriodValues10.getItemCount();
        int int16 = timePeriodValues10.getMaxMiddleIndex();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) year17, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year17.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year17.previous();
        java.lang.Object obj24 = null;
        int int25 = year17.compareTo(obj24);
        java.lang.Number number26 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue27 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, number26);
        java.lang.Object obj28 = timePeriodValue27.clone();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent29 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValue27);
        timePeriodValues1.add(timePeriodValue27);
        try {
            timePeriodValues1.update(7, (java.lang.Number) 1577865599999L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(obj28);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues7.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues7.removePropertyChangeListener(propertyChangeListener10);
        int int12 = timePeriodValues7.getItemCount();
        int int13 = timePeriodValues7.getMaxMiddleIndex();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        timePeriodValues7.add((org.jfree.data.time.TimePeriod) year14, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue18 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year14.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod19, (double) 2019L);
        int int22 = timePeriodValues1.getMinEndIndex();
        int int23 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setRangeDescription("");
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
    }

//    @Test
//    public void test167() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test167");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        int int4 = timePeriodValues1.getMinMiddleIndex();
//        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
//        java.util.Date date6 = null;
//        java.util.TimeZone timeZone7 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
//        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        timePeriodValues10.setNotify(true);
//        java.beans.PropertyChangeListener propertyChangeListener13 = null;
//        timePeriodValues10.removePropertyChangeListener(propertyChangeListener13);
//        int int15 = timePeriodValues10.getItemCount();
//        int int16 = timePeriodValues10.getMaxMiddleIndex();
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
//        timePeriodValues10.add((org.jfree.data.time.TimePeriod) year17, (double) 6);
//        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 2019L);
//        java.util.Date date22 = year17.getEnd();
//        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date22, timeZone23);
//        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        timePeriodValues26.setNotify(true);
//        java.beans.PropertyChangeListener propertyChangeListener29 = null;
//        timePeriodValues26.removePropertyChangeListener(propertyChangeListener29);
//        int int31 = timePeriodValues26.getItemCount();
//        int int32 = timePeriodValues26.getMaxMiddleIndex();
//        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
//        timePeriodValues26.add((org.jfree.data.time.TimePeriod) year33, (double) 6);
//        org.jfree.data.time.TimePeriodValue timePeriodValue37 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year33, (java.lang.Number) 2019L);
//        java.util.Date date38 = year33.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(date22, date38);
//        long long40 = simpleTimePeriod39.getEndMillis();
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
//        int int42 = day41.getMonth();
//        long long43 = day41.getMiddleMillisecond();
//        org.jfree.data.time.SerialDate serialDate44 = day41.getSerialDate();
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate46 = day45.getSerialDate();
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(serialDate46);
//        boolean boolean48 = day41.equals((java.lang.Object) serialDate46);
//        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day(serialDate46);
//        boolean boolean50 = simpleTimePeriod39.equals((java.lang.Object) day49);
//        org.jfree.data.time.TimePeriodValues timePeriodValues52 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        timePeriodValues52.setNotify(true);
//        java.beans.PropertyChangeListener propertyChangeListener55 = null;
//        timePeriodValues52.removePropertyChangeListener(propertyChangeListener55);
//        java.lang.String str57 = timePeriodValues52.getDescription();
//        int int58 = timePeriodValues52.getMinStartIndex();
//        int int59 = timePeriodValues52.getMaxEndIndex();
//        timePeriodValues52.setDomainDescription("");
//        java.beans.PropertyChangeListener propertyChangeListener62 = null;
//        timePeriodValues52.removePropertyChangeListener(propertyChangeListener62);
//        java.lang.String str64 = timePeriodValues52.getDomainDescription();
//        org.jfree.data.time.TimePeriodValues timePeriodValues66 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        timePeriodValues66.setNotify(true);
//        java.beans.PropertyChangeListener propertyChangeListener69 = null;
//        timePeriodValues66.removePropertyChangeListener(propertyChangeListener69);
//        java.lang.String str71 = timePeriodValues66.getDescription();
//        int int72 = timePeriodValues66.getMinStartIndex();
//        timePeriodValues66.fireSeriesChanged();
//        boolean boolean74 = timePeriodValues52.equals((java.lang.Object) timePeriodValues66);
//        timePeriodValues52.setRangeDescription("");
//        int int77 = timePeriodValues52.getMaxEndIndex();
//        java.beans.PropertyChangeListener propertyChangeListener78 = null;
//        timePeriodValues52.addPropertyChangeListener(propertyChangeListener78);
//        int int80 = day49.compareTo((java.lang.Object) timePeriodValues52);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(timeZone23);
//        org.junit.Assert.assertNull(regularTimePeriod24);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1577865599999L + "'", long40 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 6 + "'", int42 == 6);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1560452399999L + "'", long43 == 1560452399999L);
//        org.junit.Assert.assertNotNull(serialDate44);
//        org.junit.Assert.assertNotNull(serialDate46);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertNull(str57);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + (-1) + "'", int58 == (-1));
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-1) + "'", int59 == (-1));
//        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "" + "'", str64.equals(""));
//        org.junit.Assert.assertNull(str71);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + (-1) + "'", int72 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + (-1) + "'", int77 == (-1));
//        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 1 + "'", int80 == 1);
//    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues7.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues7.removePropertyChangeListener(propertyChangeListener10);
        int int12 = timePeriodValues7.getItemCount();
        int int13 = timePeriodValues7.getMaxMiddleIndex();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        timePeriodValues7.add((org.jfree.data.time.TimePeriod) year14, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue18 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year14.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod19, (double) 2019L);
        int int22 = timePeriodValues1.getMinEndIndex();
        int int23 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setRangeDescription("31-December-2019");
        java.lang.Comparable comparable26 = timePeriodValues1.getKey();
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + comparable26 + "' != '" + (byte) 1 + "'", comparable26.equals((byte) 1));
    }

//    @Test
//    public void test169() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test169");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        int int4 = timePeriodValues1.getMinMiddleIndex();
//        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
//        java.util.Date date6 = null;
//        java.util.TimeZone timeZone7 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
//        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        timePeriodValues10.setNotify(true);
//        java.beans.PropertyChangeListener propertyChangeListener13 = null;
//        timePeriodValues10.removePropertyChangeListener(propertyChangeListener13);
//        int int15 = timePeriodValues10.getItemCount();
//        int int16 = timePeriodValues10.getMaxMiddleIndex();
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
//        timePeriodValues10.add((org.jfree.data.time.TimePeriod) year17, (double) 6);
//        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 2019L);
//        java.util.Date date22 = year17.getEnd();
//        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date22, timeZone23);
//        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        timePeriodValues26.setNotify(true);
//        java.beans.PropertyChangeListener propertyChangeListener29 = null;
//        timePeriodValues26.removePropertyChangeListener(propertyChangeListener29);
//        int int31 = timePeriodValues26.getItemCount();
//        int int32 = timePeriodValues26.getMaxMiddleIndex();
//        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
//        timePeriodValues26.add((org.jfree.data.time.TimePeriod) year33, (double) 6);
//        org.jfree.data.time.TimePeriodValue timePeriodValue37 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year33, (java.lang.Number) 2019L);
//        java.util.Date date38 = year33.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(date22, date38);
//        long long40 = simpleTimePeriod39.getEndMillis();
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate42 = day41.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = day41.next();
//        long long44 = day41.getFirstMillisecond();
//        boolean boolean45 = simpleTimePeriod39.equals((java.lang.Object) long44);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(timeZone23);
//        org.junit.Assert.assertNull(regularTimePeriod24);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1577865599999L + "'", long40 == 1577865599999L);
//        org.junit.Assert.assertNotNull(serialDate42);
//        org.junit.Assert.assertNotNull(regularTimePeriod43);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1560409200000L + "'", long44 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year11, (java.lang.Number) 100);
        timePeriodValues1.add(timePeriodValue14);
        java.lang.Object obj16 = timePeriodValue14.clone();
        timePeriodValue14.setValue((java.lang.Number) 1L);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2019L + "'", long12 == 2019L);
        org.junit.Assert.assertNotNull(obj16);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 100);
        java.util.Date date4 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues6.addChangeListener(seriesChangeListener7);
        int int9 = timePeriodValues6.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass10 = timePeriodValues6.getClass();
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date11, timeZone12);
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues15.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timePeriodValues15.removePropertyChangeListener(propertyChangeListener18);
        int int20 = timePeriodValues15.getItemCount();
        int int21 = timePeriodValues15.getMaxMiddleIndex();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        timePeriodValues15.add((org.jfree.data.time.TimePeriod) year22, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue26 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year22, (java.lang.Number) 2019L);
        java.util.Date date27 = year22.getEnd();
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date27, timeZone28);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(date4, timeZone28);
        org.jfree.data.time.TimePeriodValues timePeriodValues32 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener33 = null;
        timePeriodValues32.addChangeListener(seriesChangeListener33);
        int int35 = timePeriodValues32.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass36 = timePeriodValues32.getClass();
        java.util.Date date37 = null;
        java.util.TimeZone timeZone38 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date37, timeZone38);
        org.jfree.data.time.TimePeriodValues timePeriodValues41 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues41.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener44 = null;
        timePeriodValues41.removePropertyChangeListener(propertyChangeListener44);
        int int46 = timePeriodValues41.getItemCount();
        int int47 = timePeriodValues41.getMaxMiddleIndex();
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year();
        timePeriodValues41.add((org.jfree.data.time.TimePeriod) year48, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue52 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year48, (java.lang.Number) 2019L);
        java.util.Date date53 = year48.getEnd();
        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date53, timeZone54);
        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year(date4, timeZone54);
        java.util.TimeZone timeZone57 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(date4, timeZone57);
        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year();
        long long60 = year59.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue62 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year59, (java.lang.Number) 100);
        java.util.Date date63 = year59.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues65 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener66 = null;
        timePeriodValues65.addChangeListener(seriesChangeListener66);
        int int68 = timePeriodValues65.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass69 = timePeriodValues65.getClass();
        java.util.Date date70 = null;
        java.util.TimeZone timeZone71 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass69, date70, timeZone71);
        org.jfree.data.time.TimePeriodValues timePeriodValues74 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues74.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener77 = null;
        timePeriodValues74.removePropertyChangeListener(propertyChangeListener77);
        int int79 = timePeriodValues74.getItemCount();
        int int80 = timePeriodValues74.getMaxMiddleIndex();
        org.jfree.data.time.Year year81 = new org.jfree.data.time.Year();
        timePeriodValues74.add((org.jfree.data.time.TimePeriod) year81, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue85 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year81, (java.lang.Number) 2019L);
        java.util.Date date86 = year81.getEnd();
        java.util.TimeZone timeZone87 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod88 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass69, date86, timeZone87);
        org.jfree.data.time.Year year89 = new org.jfree.data.time.Year(date63, timeZone87);
        org.jfree.data.time.Day day90 = new org.jfree.data.time.Day(date4, timeZone87);
        int int91 = day90.getMonth();
        int int92 = day90.getYear();
        java.util.Date date93 = day90.getStart();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertNotNull(timeZone54);
        org.junit.Assert.assertNull(regularTimePeriod55);
        org.junit.Assert.assertNotNull(timeZone57);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 2019L + "'", long60 == 2019L);
        org.junit.Assert.assertNotNull(date63);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + (-1) + "'", int68 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass69);
        org.junit.Assert.assertNull(regularTimePeriod72);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 0 + "'", int79 == 0);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + (-1) + "'", int80 == (-1));
        org.junit.Assert.assertNotNull(date86);
        org.junit.Assert.assertNotNull(timeZone87);
        org.junit.Assert.assertNull(regularTimePeriod88);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 1 + "'", int91 == 1);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 2019 + "'", int92 == 2019);
        org.junit.Assert.assertNotNull(date93);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year11, (java.lang.Number) 100);
        timePeriodValues1.add(timePeriodValue14);
        java.lang.String str16 = timePeriodValues1.getDescription();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 100);
        java.util.Date date21 = year17.getStart();
        org.jfree.data.time.TimePeriodValue timePeriodValue23 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) (short) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues25.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener28 = null;
        timePeriodValues25.removePropertyChangeListener(propertyChangeListener28);
        java.lang.String str30 = timePeriodValues25.getDescription();
        boolean boolean31 = year17.equals((java.lang.Object) timePeriodValues25);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 43629L);
        timePeriodValues1.setRangeDescription("2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException37 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException39 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
        timePeriodFormatException37.addSuppressed((java.lang.Throwable) timePeriodFormatException39);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException42 = new org.jfree.data.time.TimePeriodFormatException("Value");
        timePeriodFormatException39.addSuppressed((java.lang.Throwable) timePeriodFormatException42);
        boolean boolean44 = timePeriodValues1.equals((java.lang.Object) timePeriodFormatException39);
        java.lang.Throwable[] throwableArray45 = timePeriodFormatException39.getSuppressed();
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2019L + "'", long12 == 2019L);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2019L + "'", long18 == 2019L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(throwableArray45);
    }

//    @Test
//    public void test173() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test173");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        int int4 = timePeriodValues1.getMinMiddleIndex();
//        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
//        java.util.Date date6 = null;
//        java.util.TimeZone timeZone7 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
//        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        timePeriodValues10.setNotify(true);
//        java.beans.PropertyChangeListener propertyChangeListener13 = null;
//        timePeriodValues10.removePropertyChangeListener(propertyChangeListener13);
//        int int15 = timePeriodValues10.getItemCount();
//        int int16 = timePeriodValues10.getMaxMiddleIndex();
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
//        timePeriodValues10.add((org.jfree.data.time.TimePeriod) year17, (double) 6);
//        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 2019L);
//        java.util.Date date22 = year17.getEnd();
//        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date22, timeZone23);
//        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        timePeriodValues26.setNotify(true);
//        java.beans.PropertyChangeListener propertyChangeListener29 = null;
//        timePeriodValues26.removePropertyChangeListener(propertyChangeListener29);
//        int int31 = timePeriodValues26.getItemCount();
//        int int32 = timePeriodValues26.getMaxMiddleIndex();
//        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
//        timePeriodValues26.add((org.jfree.data.time.TimePeriod) year33, (double) 6);
//        org.jfree.data.time.TimePeriodValue timePeriodValue37 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year33, (java.lang.Number) 2019L);
//        java.util.Date date38 = year33.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(date22, date38);
//        long long40 = simpleTimePeriod39.getEndMillis();
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
//        int int42 = day41.getMonth();
//        long long43 = day41.getMiddleMillisecond();
//        org.jfree.data.time.SerialDate serialDate44 = day41.getSerialDate();
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate46 = day45.getSerialDate();
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(serialDate46);
//        boolean boolean48 = day41.equals((java.lang.Object) serialDate46);
//        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day(serialDate46);
//        boolean boolean50 = simpleTimePeriod39.equals((java.lang.Object) day49);
//        java.util.Date date51 = simpleTimePeriod39.getEnd();
//        long long52 = simpleTimePeriod39.getStartMillis();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(timeZone23);
//        org.junit.Assert.assertNull(regularTimePeriod24);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1577865599999L + "'", long40 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 6 + "'", int42 == 6);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1560452399999L + "'", long43 == 1560452399999L);
//        org.junit.Assert.assertNotNull(serialDate44);
//        org.junit.Assert.assertNotNull(serialDate46);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertNotNull(date51);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1577865599999L + "'", long52 == 1577865599999L);
//    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener13);
        int int15 = timePeriodValues10.getItemCount();
        int int16 = timePeriodValues10.getMaxMiddleIndex();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) year17, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 2019L);
        java.util.Date date22 = year17.getEnd();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date22, timeZone23);
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues26.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timePeriodValues26.removePropertyChangeListener(propertyChangeListener29);
        int int31 = timePeriodValues26.getItemCount();
        int int32 = timePeriodValues26.getMaxMiddleIndex();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        timePeriodValues26.add((org.jfree.data.time.TimePeriod) year33, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue37 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year33, (java.lang.Number) 2019L);
        java.util.Date date38 = year33.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(date22, date38);
        org.jfree.data.time.TimePeriodValues timePeriodValues41 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues41.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener44 = null;
        timePeriodValues41.removePropertyChangeListener(propertyChangeListener44);
        java.lang.String str46 = timePeriodValues41.getDescription();
        int int47 = timePeriodValues41.getMinStartIndex();
        timePeriodValues41.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues52 = timePeriodValues41.createCopy(0, 1);
        boolean boolean53 = simpleTimePeriod39.equals((java.lang.Object) 0);
        java.util.Date date54 = simpleTimePeriod39.getStart();
        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day(date54);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNull(str46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(date54);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        timePeriodValues1.setKey((java.lang.Comparable) "hi!");
        timePeriodValues1.delete(13, 4);
        timePeriodValues1.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener10);
    }

//    @Test
//    public void test176() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test176");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getSerialIndex();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 100);
//        java.util.Date date4 = year0.getStart();
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 1560409200000L);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate8 = day7.getSerialDate();
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
//        long long10 = year9.getSerialIndex();
//        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year9, (java.lang.Number) 100);
//        java.lang.Object obj13 = timePeriodValue12.clone();
//        int int14 = day7.compareTo(obj13);
//        int int15 = day7.getDayOfMonth();
//        long long16 = day7.getFirstMillisecond();
//        int int17 = year0.compareTo((java.lang.Object) day7);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
//        org.junit.Assert.assertNotNull(obj13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 13 + "'", int15 == 13);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560409200000L + "'", long16 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener13);
        int int15 = timePeriodValues10.getItemCount();
        int int16 = timePeriodValues10.getMaxMiddleIndex();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) year17, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 2019L);
        java.util.Date date22 = year17.getEnd();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date22, timeZone23);
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues26.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timePeriodValues26.removePropertyChangeListener(propertyChangeListener29);
        int int31 = timePeriodValues26.getItemCount();
        int int32 = timePeriodValues26.getMaxMiddleIndex();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        timePeriodValues26.add((org.jfree.data.time.TimePeriod) year33, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue37 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year33, (java.lang.Number) 2019L);
        java.util.Date date38 = year33.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(date22, date38);
        long long40 = simpleTimePeriod39.getEndMillis();
        long long41 = simpleTimePeriod39.getStartMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues43 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues43.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener46 = null;
        timePeriodValues43.removePropertyChangeListener(propertyChangeListener46);
        int int48 = timePeriodValues43.getItemCount();
        int int49 = timePeriodValues43.getMaxMiddleIndex();
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
        timePeriodValues43.add((org.jfree.data.time.TimePeriod) year50, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue54 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year50, (java.lang.Number) 2019L);
        java.util.Date date55 = year50.getEnd();
        long long56 = year50.getFirstMillisecond();
        boolean boolean57 = simpleTimePeriod39.equals((java.lang.Object) long56);
        long long58 = simpleTimePeriod39.getStartMillis();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1577865599999L + "'", long40 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1577865599999L + "'", long41 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1546329600000L + "'", long56 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1577865599999L + "'", long58 == 1577865599999L);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener13);
        int int15 = timePeriodValues10.getItemCount();
        int int16 = timePeriodValues10.getMaxMiddleIndex();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) year17, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 2019L);
        java.util.Date date22 = year17.getEnd();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date22, timeZone23);
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues26.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timePeriodValues26.removePropertyChangeListener(propertyChangeListener29);
        int int31 = timePeriodValues26.getItemCount();
        int int32 = timePeriodValues26.getMaxMiddleIndex();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        timePeriodValues26.add((org.jfree.data.time.TimePeriod) year33, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue37 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year33, (java.lang.Number) 2019L);
        java.util.Date date38 = year33.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(date22, date38);
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
        long long41 = year40.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue43 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year40, (java.lang.Number) 100);
        java.util.Date date44 = year40.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues46 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener47 = null;
        timePeriodValues46.addChangeListener(seriesChangeListener47);
        int int49 = timePeriodValues46.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass50 = timePeriodValues46.getClass();
        java.util.Date date51 = null;
        java.util.TimeZone timeZone52 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass50, date51, timeZone52);
        org.jfree.data.time.TimePeriodValues timePeriodValues55 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues55.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener58 = null;
        timePeriodValues55.removePropertyChangeListener(propertyChangeListener58);
        int int60 = timePeriodValues55.getItemCount();
        int int61 = timePeriodValues55.getMaxMiddleIndex();
        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year();
        timePeriodValues55.add((org.jfree.data.time.TimePeriod) year62, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue66 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year62, (java.lang.Number) 2019L);
        java.util.Date date67 = year62.getEnd();
        java.util.TimeZone timeZone68 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass50, date67, timeZone68);
        org.jfree.data.time.Year year70 = new org.jfree.data.time.Year(date44, timeZone68);
        org.jfree.data.time.TimePeriodValues timePeriodValues72 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener73 = null;
        timePeriodValues72.addChangeListener(seriesChangeListener73);
        int int75 = timePeriodValues72.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass76 = timePeriodValues72.getClass();
        java.util.Date date77 = null;
        java.util.TimeZone timeZone78 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass76, date77, timeZone78);
        org.jfree.data.time.TimePeriodValues timePeriodValues81 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues81.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener84 = null;
        timePeriodValues81.removePropertyChangeListener(propertyChangeListener84);
        int int86 = timePeriodValues81.getItemCount();
        int int87 = timePeriodValues81.getMaxMiddleIndex();
        org.jfree.data.time.Year year88 = new org.jfree.data.time.Year();
        timePeriodValues81.add((org.jfree.data.time.TimePeriod) year88, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue92 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year88, (java.lang.Number) 2019L);
        java.util.Date date93 = year88.getEnd();
        java.util.TimeZone timeZone94 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod95 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass76, date93, timeZone94);
        org.jfree.data.time.Year year96 = new org.jfree.data.time.Year(date44, timeZone94);
        org.jfree.data.time.Day day97 = new org.jfree.data.time.Day(date22, timeZone94);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 2019L + "'", long41 == 2019L);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertNull(regularTimePeriod53);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
        org.junit.Assert.assertNotNull(date67);
        org.junit.Assert.assertNotNull(timeZone68);
        org.junit.Assert.assertNull(regularTimePeriod69);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + (-1) + "'", int75 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass76);
        org.junit.Assert.assertNull(regularTimePeriod79);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 0 + "'", int86 == 0);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + (-1) + "'", int87 == (-1));
        org.junit.Assert.assertNotNull(date93);
        org.junit.Assert.assertNotNull(timeZone94);
        org.junit.Assert.assertNull(regularTimePeriod95);
    }

//    @Test
//    public void test179() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test179");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        int int2 = day0.getMonth();
//        int int3 = day0.getYear();
//        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
//        long long5 = day0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560409200000L + "'", long5 == 1560409200000L);
//    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        int int11 = timePeriodValues1.getMaxEndIndex();
        java.lang.String str12 = timePeriodValues1.getRangeDescription();
        timePeriodValues1.setKey((java.lang.Comparable) 7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener15);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener17);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Value" + "'", str12.equals("Value"));
    }

//    @Test
//    public void test181() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test181");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 0L);
//        int int3 = day0.getYear();
//        long long4 = day0.getMiddleMillisecond();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = day0.getLastMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560452399999L + "'", long4 == 1560452399999L);
//    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        int int9 = timePeriodValues1.getMinEndIndex();
        int int10 = timePeriodValues1.getItemCount();
        java.lang.Comparable comparable11 = timePeriodValues1.getKey();
        int int12 = timePeriodValues1.getMinMiddleIndex();
        try {
            org.jfree.data.time.TimePeriod timePeriod14 = timePeriodValues1.getTimePeriod((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + (byte) 1 + "'", comparable11.equals((byte) 1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        int int11 = timePeriodValues1.getMaxMiddleIndex();
        timePeriodValues1.setNotify(true);
        java.lang.String str14 = timePeriodValues1.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener15);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Value" + "'", str14.equals("Value"));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("TimePeriodValue[2019,100]");
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener13);
        int int15 = timePeriodValues10.getItemCount();
        int int16 = timePeriodValues10.getMaxMiddleIndex();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) year17, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 2019L);
        java.util.Date date22 = year17.getEnd();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date22, timeZone23);
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues26.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timePeriodValues26.removePropertyChangeListener(propertyChangeListener29);
        int int31 = timePeriodValues26.getItemCount();
        int int32 = timePeriodValues26.getMaxMiddleIndex();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        timePeriodValues26.add((org.jfree.data.time.TimePeriod) year33, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue37 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year33, (java.lang.Number) 2019L);
        java.util.Date date38 = year33.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(date22, date38);
        long long40 = simpleTimePeriod39.getEndMillis();
        long long41 = simpleTimePeriod39.getStartMillis();
        boolean boolean43 = simpleTimePeriod39.equals((java.lang.Object) 0);
        java.util.Date date44 = simpleTimePeriod39.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues46 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener47 = null;
        timePeriodValues46.addChangeListener(seriesChangeListener47);
        int int49 = timePeriodValues46.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass50 = timePeriodValues46.getClass();
        java.util.Date date51 = null;
        java.util.TimeZone timeZone52 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass50, date51, timeZone52);
        org.jfree.data.time.TimePeriodValues timePeriodValues55 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues55.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener58 = null;
        timePeriodValues55.removePropertyChangeListener(propertyChangeListener58);
        int int60 = timePeriodValues55.getItemCount();
        int int61 = timePeriodValues55.getMaxMiddleIndex();
        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year();
        timePeriodValues55.add((org.jfree.data.time.TimePeriod) year62, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue66 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year62, (java.lang.Number) 2019L);
        java.util.Date date67 = year62.getEnd();
        java.util.TimeZone timeZone68 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass50, date67, timeZone68);
        org.jfree.data.time.TimePeriodValues timePeriodValues71 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues71.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener74 = null;
        timePeriodValues71.removePropertyChangeListener(propertyChangeListener74);
        int int76 = timePeriodValues71.getItemCount();
        int int77 = timePeriodValues71.getMaxMiddleIndex();
        org.jfree.data.time.Year year78 = new org.jfree.data.time.Year();
        timePeriodValues71.add((org.jfree.data.time.TimePeriod) year78, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue82 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year78, (java.lang.Number) 2019L);
        java.util.Date date83 = year78.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod84 = new org.jfree.data.time.SimpleTimePeriod(date67, date83);
        java.util.TimeZone timeZone85 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year86 = new org.jfree.data.time.Year(date67, timeZone85);
        boolean boolean87 = simpleTimePeriod39.equals((java.lang.Object) date67);
        java.util.Date date88 = simpleTimePeriod39.getStart();
        long long89 = simpleTimePeriod39.getStartMillis();
        java.util.Date date90 = simpleTimePeriod39.getEnd();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1577865599999L + "'", long40 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1577865599999L + "'", long41 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertNull(regularTimePeriod53);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
        org.junit.Assert.assertNotNull(date67);
        org.junit.Assert.assertNotNull(timeZone68);
        org.junit.Assert.assertNull(regularTimePeriod69);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 0 + "'", int76 == 0);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + (-1) + "'", int77 == (-1));
        org.junit.Assert.assertNotNull(date83);
        org.junit.Assert.assertNotNull(timeZone85);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertNotNull(date88);
        org.junit.Assert.assertTrue("'" + long89 + "' != '" + 1577865599999L + "'", long89 == 1577865599999L);
        org.junit.Assert.assertNotNull(date90);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener11);
        int int13 = timePeriodValues1.getMaxEndIndex();
        java.lang.Comparable comparable14 = timePeriodValues1.getKey();
        int int15 = timePeriodValues1.getMaxStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues17.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timePeriodValues17.removePropertyChangeListener(propertyChangeListener20);
        int int22 = timePeriodValues17.getItemCount();
        int int23 = timePeriodValues17.getMaxMiddleIndex();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        timePeriodValues17.add((org.jfree.data.time.TimePeriod) year24, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue28 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year24, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year24.previous();
        boolean boolean31 = year24.equals((java.lang.Object) "hi!");
        boolean boolean33 = year24.equals((java.lang.Object) 100.0f);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year24, (java.lang.Number) 4);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + (byte) 1 + "'", comparable14.equals((byte) 1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        java.lang.Comparable comparable0 = null;
        try {
            org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues(comparable0, "Value", "Time");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 2019L);
        java.util.Date date13 = year8.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener16 = null;
        timePeriodValues15.addChangeListener(seriesChangeListener16);
        int int18 = timePeriodValues15.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass19 = timePeriodValues15.getClass();
        java.util.Date date20 = null;
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener23 = null;
        timePeriodValues22.addChangeListener(seriesChangeListener23);
        int int25 = timePeriodValues22.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass26 = timePeriodValues22.getClass();
        java.util.Date date27 = null;
        java.util.TimeZone timeZone28 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass26, date27, timeZone28);
        org.jfree.data.time.TimePeriodValues timePeriodValues31 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues31.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener34 = null;
        timePeriodValues31.removePropertyChangeListener(propertyChangeListener34);
        int int36 = timePeriodValues31.getItemCount();
        int int37 = timePeriodValues31.getMaxMiddleIndex();
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
        timePeriodValues31.add((org.jfree.data.time.TimePeriod) year38, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue42 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year38, (java.lang.Number) 2019L);
        java.util.Date date43 = year38.getEnd();
        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass26, date43, timeZone44);
        org.jfree.data.time.TimePeriodValues timePeriodValues47 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues47.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener50 = null;
        timePeriodValues47.removePropertyChangeListener(propertyChangeListener50);
        int int52 = timePeriodValues47.getItemCount();
        int int53 = timePeriodValues47.getMaxMiddleIndex();
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year();
        timePeriodValues47.add((org.jfree.data.time.TimePeriod) year54, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue58 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year54, (java.lang.Number) 2019L);
        java.util.Date date59 = year54.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod60 = new org.jfree.data.time.SimpleTimePeriod(date43, date59);
        long long61 = simpleTimePeriod60.getEndMillis();
        long long62 = simpleTimePeriod60.getStartMillis();
        boolean boolean64 = simpleTimePeriod60.equals((java.lang.Object) 0);
        java.util.Date date65 = simpleTimePeriod60.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues67 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues67.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener70 = null;
        timePeriodValues67.removePropertyChangeListener(propertyChangeListener70);
        int int72 = timePeriodValues67.getItemCount();
        int int73 = timePeriodValues67.getMaxMiddleIndex();
        org.jfree.data.time.Year year74 = new org.jfree.data.time.Year();
        timePeriodValues67.add((org.jfree.data.time.TimePeriod) year74, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue78 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year74, (java.lang.Number) 2019L);
        java.util.Date date79 = year74.getEnd();
        org.jfree.data.time.Year year80 = new org.jfree.data.time.Year(date79);
        java.util.TimeZone timeZone81 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day82 = new org.jfree.data.time.Day(date79, timeZone81);
        org.jfree.data.time.Day day83 = new org.jfree.data.time.Day(date65, timeZone81);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod84 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date20, timeZone81);
        org.jfree.data.time.Day day85 = new org.jfree.data.time.Day(date13, timeZone81);
        org.jfree.data.time.Year year86 = new org.jfree.data.time.Year(date13);
        org.jfree.data.time.Year year87 = new org.jfree.data.time.Year(date13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod88 = year87.previous();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(timeZone44);
        org.junit.Assert.assertNull(regularTimePeriod45);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-1) + "'", int53 == (-1));
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 1577865599999L + "'", long61 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 1577865599999L + "'", long62 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(date65);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 0 + "'", int72 == 0);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + (-1) + "'", int73 == (-1));
        org.junit.Assert.assertNotNull(date79);
        org.junit.Assert.assertNotNull(timeZone81);
        org.junit.Assert.assertNull(regularTimePeriod84);
        org.junit.Assert.assertNotNull(regularTimePeriod88);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener11);
        java.lang.String str13 = timePeriodValues1.getDomainDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener14);
        int int16 = timePeriodValues1.getMinEndIndex();
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener17);
        int int19 = timePeriodValues1.getMinMiddleIndex();
        int int20 = timePeriodValues1.getItemCount();
        try {
            timePeriodValues1.update(7, (java.lang.Number) 43466L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(serialDate1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(serialDate1);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(serialDate1);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate1);
        java.util.Calendar calendar6 = null;
        try {
            long long7 = day5.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
    }

//    @Test
//    public void test191() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test191");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass1 = day0.getClass();
//        long long2 = day0.getLastMillisecond();
//        int int3 = day0.getDayOfMonth();
//        java.util.Date date4 = day0.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date4);
//        org.junit.Assert.assertNotNull(wildcardClass1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560495599999L + "'", long2 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//        org.junit.Assert.assertNotNull(date4);
//    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 0L);
        org.jfree.data.time.TimePeriod timePeriod3 = timePeriodValue2.getPeriod();
        java.lang.Object obj4 = timePeriodValue2.clone();
        timePeriodValue2.setValue((java.lang.Number) 1560409200000L);
        timePeriodValue2.setValue((java.lang.Number) 2019L);
        org.junit.Assert.assertNotNull(timePeriod3);
        org.junit.Assert.assertNotNull(obj4);
    }

//    @Test
//    public void test193() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test193");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getMiddleMillisecond();
//        long long3 = day0.getFirstMillisecond();
//        java.lang.String str4 = day0.toString();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = day0.getMiddleMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560452399999L + "'", long2 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "13-June-2019" + "'", str4.equals("13-June-2019"));
//    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener13);
        int int15 = timePeriodValues10.getItemCount();
        int int16 = timePeriodValues10.getMaxMiddleIndex();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) year17, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 2019L);
        java.util.Date date22 = year17.getEnd();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date22, timeZone23);
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues26.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timePeriodValues26.removePropertyChangeListener(propertyChangeListener29);
        int int31 = timePeriodValues26.getItemCount();
        int int32 = timePeriodValues26.getMaxMiddleIndex();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        timePeriodValues26.add((org.jfree.data.time.TimePeriod) year33, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue37 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year33, (java.lang.Number) 2019L);
        java.util.Date date38 = year33.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(date22, date38);
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date22);
        org.jfree.data.time.SerialDate serialDate41 = day40.getSerialDate();
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(serialDate41);
        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(serialDate41);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(serialDate41);
    }

//    @Test
//    public void test195() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test195");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
//        long long3 = year2.getSerialIndex();
//        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year2, (java.lang.Number) 100);
//        java.lang.Object obj6 = timePeriodValue5.clone();
//        int int7 = day0.compareTo(obj6);
//        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 1560365999999L);
//        long long10 = day0.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
//        org.junit.Assert.assertNotNull(obj6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560452399999L + "'", long10 == 1560452399999L);
//    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        boolean boolean2 = timePeriodValues1.getNotify();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener3);
        timePeriodValues1.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesChangeEvent[source=0]");
        java.lang.Comparable comparable7 = timePeriodValues1.getKey();
        int int8 = timePeriodValues1.getMaxMiddleIndex();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + (byte) 1 + "'", comparable7.equals((byte) 1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getYear();
        int int2 = day0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 1.0f);
        java.util.Date date6 = day0.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (java.lang.Number) 100);
        java.util.Date date11 = year7.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
        timePeriodValues13.addChangeListener(seriesChangeListener14);
        int int16 = timePeriodValues13.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass17 = timePeriodValues13.getClass();
        java.util.Date date18 = null;
        java.util.TimeZone timeZone19 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date18, timeZone19);
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues22.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener25 = null;
        timePeriodValues22.removePropertyChangeListener(propertyChangeListener25);
        int int27 = timePeriodValues22.getItemCount();
        int int28 = timePeriodValues22.getMaxMiddleIndex();
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
        timePeriodValues22.add((org.jfree.data.time.TimePeriod) year29, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue33 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year29, (java.lang.Number) 2019L);
        java.util.Date date34 = year29.getEnd();
        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date34, timeZone35);
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year(date11, timeZone35);
        org.jfree.data.time.TimePeriodValues timePeriodValues39 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener40 = null;
        timePeriodValues39.addChangeListener(seriesChangeListener40);
        int int42 = timePeriodValues39.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass43 = timePeriodValues39.getClass();
        java.util.Date date44 = null;
        java.util.TimeZone timeZone45 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass43, date44, timeZone45);
        org.jfree.data.time.TimePeriodValues timePeriodValues48 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues48.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener51 = null;
        timePeriodValues48.removePropertyChangeListener(propertyChangeListener51);
        int int53 = timePeriodValues48.getItemCount();
        int int54 = timePeriodValues48.getMaxMiddleIndex();
        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year();
        timePeriodValues48.add((org.jfree.data.time.TimePeriod) year55, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue59 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year55, (java.lang.Number) 2019L);
        java.util.Date date60 = year55.getEnd();
        java.util.TimeZone timeZone61 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass43, date60, timeZone61);
        org.jfree.data.time.TimePeriodValues timePeriodValues64 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues64.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener67 = null;
        timePeriodValues64.removePropertyChangeListener(propertyChangeListener67);
        int int69 = timePeriodValues64.getItemCount();
        int int70 = timePeriodValues64.getMaxMiddleIndex();
        org.jfree.data.time.Year year71 = new org.jfree.data.time.Year();
        timePeriodValues64.add((org.jfree.data.time.TimePeriod) year71, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue75 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year71, (java.lang.Number) 2019L);
        java.util.Date date76 = year71.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod77 = new org.jfree.data.time.SimpleTimePeriod(date60, date76);
        java.util.TimeZone timeZone78 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year79 = new org.jfree.data.time.Year(date60, timeZone78);
        org.jfree.data.time.Year year80 = new org.jfree.data.time.Year(date11, timeZone78);
        org.jfree.data.time.Year year81 = new org.jfree.data.time.Year(date6, timeZone78);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(timeZone35);
        org.junit.Assert.assertNull(regularTimePeriod36);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertNull(regularTimePeriod46);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1) + "'", int54 == (-1));
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertNotNull(timeZone61);
        org.junit.Assert.assertNull(regularTimePeriod62);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + (-1) + "'", int70 == (-1));
        org.junit.Assert.assertNotNull(date76);
        org.junit.Assert.assertNotNull(timeZone78);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        java.lang.String str2 = timePeriodValues1.getDescription();
        timePeriodValues1.setRangeDescription("Value");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener5);
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 100);
        java.util.Date date4 = year0.getStart();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) (short) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues8.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues8.removePropertyChangeListener(propertyChangeListener11);
        java.lang.String str13 = timePeriodValues8.getDescription();
        boolean boolean14 = year0.equals((java.lang.Object) timePeriodValues8);
        timePeriodValues8.setRangeDescription("org.jfree.data.general.SeriesException: TimePeriodValue[13-June-2019,8.0]");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener13);
        int int15 = timePeriodValues10.getItemCount();
        int int16 = timePeriodValues10.getMaxMiddleIndex();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) year17, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 2019L);
        java.util.Date date22 = year17.getEnd();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date22, timeZone23);
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues26.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timePeriodValues26.removePropertyChangeListener(propertyChangeListener29);
        int int31 = timePeriodValues26.getItemCount();
        int int32 = timePeriodValues26.getMaxMiddleIndex();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        timePeriodValues26.add((org.jfree.data.time.TimePeriod) year33, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue37 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year33, (java.lang.Number) 2019L);
        java.util.Date date38 = year33.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(date22, date38);
        org.jfree.data.time.TimePeriodValues timePeriodValues41 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues41.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener44 = null;
        timePeriodValues41.removePropertyChangeListener(propertyChangeListener44);
        java.lang.String str46 = timePeriodValues41.getDescription();
        int int47 = timePeriodValues41.getMinStartIndex();
        timePeriodValues41.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues52 = timePeriodValues41.createCopy(0, 1);
        boolean boolean53 = simpleTimePeriod39.equals((java.lang.Object) 0);
        java.util.Date date54 = simpleTimePeriod39.getStart();
        org.jfree.data.time.TimePeriodValue timePeriodValue56 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod39, (double) (byte) 100);
        timePeriodValue56.setValue((java.lang.Number) 100);
        java.lang.Object obj59 = timePeriodValue56.clone();
        java.lang.Object obj60 = timePeriodValue56.clone();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNull(str46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertNotNull(obj59);
        org.junit.Assert.assertNotNull(obj60);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 0L);
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "2019");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timePeriodValues4.removeChangeListener(seriesChangeListener5);
        int int7 = timePeriodValues4.getItemCount();
        timePeriodValues4.setDescription("31-December-2019");
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year10, (java.lang.Number) 100);
        java.util.Date date14 = year10.getStart();
        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year10, (java.lang.Number) (short) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year10.previous();
        timePeriodValues4.add((org.jfree.data.time.TimePeriod) regularTimePeriod17, (java.lang.Number) (-1));
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        long long21 = year20.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue23 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year20, (java.lang.Number) 100);
        java.util.Date date24 = year20.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener27 = null;
        timePeriodValues26.addChangeListener(seriesChangeListener27);
        int int29 = timePeriodValues26.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass30 = timePeriodValues26.getClass();
        java.util.Date date31 = null;
        java.util.TimeZone timeZone32 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date31, timeZone32);
        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues35.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener38 = null;
        timePeriodValues35.removePropertyChangeListener(propertyChangeListener38);
        int int40 = timePeriodValues35.getItemCount();
        int int41 = timePeriodValues35.getMaxMiddleIndex();
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
        timePeriodValues35.add((org.jfree.data.time.TimePeriod) year42, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue46 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year42, (java.lang.Number) 2019L);
        java.util.Date date47 = year42.getEnd();
        java.util.TimeZone timeZone48 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date47, timeZone48);
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year(date24, timeZone48);
        org.jfree.data.time.TimePeriodValues timePeriodValues52 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener53 = null;
        timePeriodValues52.addChangeListener(seriesChangeListener53);
        int int55 = timePeriodValues52.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass56 = timePeriodValues52.getClass();
        java.util.Date date57 = null;
        java.util.TimeZone timeZone58 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass56, date57, timeZone58);
        org.jfree.data.time.TimePeriodValues timePeriodValues61 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues61.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener64 = null;
        timePeriodValues61.removePropertyChangeListener(propertyChangeListener64);
        int int66 = timePeriodValues61.getItemCount();
        int int67 = timePeriodValues61.getMaxMiddleIndex();
        org.jfree.data.time.Year year68 = new org.jfree.data.time.Year();
        timePeriodValues61.add((org.jfree.data.time.TimePeriod) year68, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue72 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year68, (java.lang.Number) 2019L);
        java.util.Date date73 = year68.getEnd();
        java.util.TimeZone timeZone74 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass56, date73, timeZone74);
        org.jfree.data.time.Year year76 = new org.jfree.data.time.Year(date24, timeZone74);
        java.util.TimeZone timeZone77 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day78 = new org.jfree.data.time.Day(date24, timeZone77);
        org.jfree.data.time.Year year79 = new org.jfree.data.time.Year(date24);
        timePeriodValues4.add((org.jfree.data.time.TimePeriod) year79, (double) 4);
        boolean boolean82 = day0.equals((java.lang.Object) timePeriodValues4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 2019L + "'", long21 == 2019L);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(timeZone48);
        org.junit.Assert.assertNull(regularTimePeriod49);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-1) + "'", int55 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass56);
        org.junit.Assert.assertNull(regularTimePeriod59);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + (-1) + "'", int67 == (-1));
        org.junit.Assert.assertNotNull(date73);
        org.junit.Assert.assertNotNull(timeZone74);
        org.junit.Assert.assertNull(regularTimePeriod75);
        org.junit.Assert.assertNotNull(timeZone77);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues1.createCopy(0, 0);
        int int10 = timePeriodValues9.getMaxMiddleIndex();
        boolean boolean11 = timePeriodValues9.isEmpty();
        java.lang.Class<?> wildcardClass12 = timePeriodValues9.getClass();
        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass12);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(timePeriodValues9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(class13);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMinEndIndex();
        java.lang.String str6 = timePeriodValues1.getRangeDescription();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year7.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod9, (java.lang.Number) 6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener12);
        boolean boolean14 = timePeriodValues1.isEmpty();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Value" + "'", str6.equals("Value"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

//    @Test
//    public void test204() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test204");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass1 = day0.getClass();
//        int int2 = day0.getMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 8);
//        java.lang.String str5 = timePeriodValue4.toString();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
//        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
//        timePeriodFormatException16.addSuppressed((java.lang.Throwable) timePeriodFormatException18);
//        timePeriodFormatException14.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
//        timePeriodFormatException12.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
//        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
//        boolean boolean23 = timePeriodValue4.equals((java.lang.Object) timePeriodFormatException16);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException25 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException27 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException29 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException31 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
//        timePeriodFormatException29.addSuppressed((java.lang.Throwable) timePeriodFormatException31);
//        timePeriodFormatException27.addSuppressed((java.lang.Throwable) timePeriodFormatException29);
//        timePeriodFormatException25.addSuppressed((java.lang.Throwable) timePeriodFormatException29);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException36 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException38 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
//        timePeriodFormatException36.addSuppressed((java.lang.Throwable) timePeriodFormatException38);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException41 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException43 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException45 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException47 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
//        timePeriodFormatException45.addSuppressed((java.lang.Throwable) timePeriodFormatException47);
//        timePeriodFormatException43.addSuppressed((java.lang.Throwable) timePeriodFormatException45);
//        timePeriodFormatException41.addSuppressed((java.lang.Throwable) timePeriodFormatException45);
//        timePeriodFormatException36.addSuppressed((java.lang.Throwable) timePeriodFormatException45);
//        java.lang.Throwable[] throwableArray52 = timePeriodFormatException45.getSuppressed();
//        timePeriodFormatException29.addSuppressed((java.lang.Throwable) timePeriodFormatException45);
//        timePeriodFormatException16.addSuppressed((java.lang.Throwable) timePeriodFormatException29);
//        org.junit.Assert.assertNotNull(wildcardClass1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "TimePeriodValue[13-June-2019,8.0]" + "'", str5.equals("TimePeriodValue[13-June-2019,8.0]"));
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(throwableArray52);
//    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues3.setNotify(true);
        boolean boolean7 = timePeriodValues3.equals((java.lang.Object) (short) 0);
        boolean boolean8 = year0.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        timePeriodValues10.setKey((java.lang.Comparable) 100L);
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues16.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timePeriodValues16.removePropertyChangeListener(propertyChangeListener19);
        int int21 = timePeriodValues16.getItemCount();
        int int22 = timePeriodValues16.getMaxMiddleIndex();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        timePeriodValues16.add((org.jfree.data.time.TimePeriod) year23, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue27 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year23, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year23.previous();
        timePeriodValues10.setKey((java.lang.Comparable) year23);
        int int30 = year0.compareTo((java.lang.Object) year23);
        java.lang.String str31 = year0.toString();
        java.lang.Object obj32 = null;
        boolean boolean33 = year0.equals(obj32);
        java.util.Date date34 = year0.getStart();
        org.jfree.data.time.TimePeriodValue timePeriodValue36 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, 0.0d);
        long long37 = year0.getFirstMillisecond();
        long long38 = year0.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "2019" + "'", str31.equals("2019"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1546329600000L + "'", long37 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1546329600000L + "'", long38 == 1546329600000L);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 2019L);
        java.util.Date date13 = year8.getEnd();
        long long14 = year8.getMiddleMillisecond();
        java.lang.Class<?> wildcardClass15 = year8.getClass();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
        int int17 = day16.getYear();
        int int18 = day16.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day16.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day16, (double) 1.0f);
        java.util.Date date22 = day16.getStart();
        java.util.TimeZone timeZone23 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date22, timeZone23);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date22);
        java.util.Calendar calendar26 = null;
        try {
            day25.peg(calendar26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1562097599999L + "'", long14 == 1562097599999L);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNull(regularTimePeriod24);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        timePeriodValues1.setNotify(true);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year10, (java.lang.Number) 100);
        timePeriodValue13.setValue((java.lang.Number) 3);
        org.jfree.data.time.TimePeriod timePeriod16 = timePeriodValue13.getPeriod();
        timePeriodValues1.add(timePeriodValue13);
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues19.setNotify(true);
        timePeriodValues19.setKey((java.lang.Comparable) 100L);
        timePeriodValues19.setKey((java.lang.Comparable) (short) 100);
        java.lang.String str26 = timePeriodValues19.getRangeDescription();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        long long28 = year27.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue30 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year27, (java.lang.Number) 100);
        timePeriodValues19.add(timePeriodValue30);
        boolean boolean32 = timePeriodValue13.equals((java.lang.Object) timePeriodValues19);
        java.lang.String str33 = timePeriodValue13.toString();
        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues35.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener38 = null;
        timePeriodValues35.removePropertyChangeListener(propertyChangeListener38);
        java.lang.String str40 = timePeriodValues35.getDescription();
        int int41 = timePeriodValues35.getMinStartIndex();
        int int42 = timePeriodValues35.getMaxEndIndex();
        timePeriodValues35.setDomainDescription("");
        int int45 = timePeriodValues35.getMaxEndIndex();
        boolean boolean47 = timePeriodValues35.equals((java.lang.Object) (-1L));
        boolean boolean48 = timePeriodValue13.equals((java.lang.Object) timePeriodValues35);
        org.jfree.data.time.TimePeriodValues timePeriodValues50 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues50.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener53 = null;
        timePeriodValues50.removePropertyChangeListener(propertyChangeListener53);
        java.lang.String str55 = timePeriodValues50.getDescription();
        int int56 = timePeriodValues50.getMinStartIndex();
        int int57 = timePeriodValues50.getMaxEndIndex();
        int int58 = timePeriodValues50.getMinEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues61 = timePeriodValues50.createCopy(0, (int) (short) -1);
        int int62 = timePeriodValues61.getMaxStartIndex();
        boolean boolean63 = timePeriodValue13.equals((java.lang.Object) timePeriodValues61);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
        org.junit.Assert.assertNotNull(timePeriod16);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Value" + "'", str26.equals("Value"));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 2019L + "'", long28 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "TimePeriodValue[2019,3]" + "'", str33.equals("TimePeriodValue[2019,3]"));
        org.junit.Assert.assertNull(str40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNull(str55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + (-1) + "'", int56 == (-1));
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-1) + "'", int57 == (-1));
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + (-1) + "'", int58 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-1) + "'", int62 == (-1));
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year8.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year8.previous();
        java.lang.Object obj15 = null;
        int int16 = year8.compareTo(obj15);
        java.lang.Number number17 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue18 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, number17);
        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (double) 1593676799999L);
        long long21 = year8.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1577865599999L + "'", long21 == 1577865599999L);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        timePeriodValues1.setKey((java.lang.Comparable) 100L);
        int int6 = timePeriodValues1.getMaxMiddleIndex();
        int int7 = timePeriodValues1.getMaxEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = timePeriodValues1.createCopy(11, 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues10);
    }

//    @Test
//    public void test210() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test210");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass1 = day0.getClass();
//        long long2 = day0.getLastMillisecond();
//        java.lang.String str3 = day0.toString();
//        long long4 = day0.getFirstMillisecond();
//        java.lang.String str5 = day0.toString();
//        java.lang.Object obj6 = null;
//        boolean boolean7 = day0.equals(obj6);
//        org.jfree.data.time.SerialDate serialDate8 = day0.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate9 = day0.getSerialDate();
//        java.util.Date date10 = day0.getEnd();
//        org.junit.Assert.assertNotNull(wildcardClass1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560495599999L + "'", long2 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "13-June-2019" + "'", str5.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertNotNull(date10);
//    }

//    @Test
//    public void test211() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test211");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getSerialIndex();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 100);
//        java.util.Date date4 = year0.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
//        timePeriodValues6.addChangeListener(seriesChangeListener7);
//        int int9 = timePeriodValues6.getMinMiddleIndex();
//        java.lang.Class<?> wildcardClass10 = timePeriodValues6.getClass();
//        java.util.Date date11 = null;
//        java.util.TimeZone timeZone12 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date11, timeZone12);
//        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        timePeriodValues15.setNotify(true);
//        java.beans.PropertyChangeListener propertyChangeListener18 = null;
//        timePeriodValues15.removePropertyChangeListener(propertyChangeListener18);
//        int int20 = timePeriodValues15.getItemCount();
//        int int21 = timePeriodValues15.getMaxMiddleIndex();
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
//        timePeriodValues15.add((org.jfree.data.time.TimePeriod) year22, (double) 6);
//        org.jfree.data.time.TimePeriodValue timePeriodValue26 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year22, (java.lang.Number) 2019L);
//        java.util.Date date27 = year22.getEnd();
//        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date27, timeZone28);
//        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(date4, timeZone28);
//        org.jfree.data.time.TimePeriodValues timePeriodValues32 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener33 = null;
//        timePeriodValues32.addChangeListener(seriesChangeListener33);
//        int int35 = timePeriodValues32.getMinMiddleIndex();
//        java.lang.Class<?> wildcardClass36 = timePeriodValues32.getClass();
//        java.util.Date date37 = null;
//        java.util.TimeZone timeZone38 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date37, timeZone38);
//        org.jfree.data.time.TimePeriodValues timePeriodValues41 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        timePeriodValues41.setNotify(true);
//        java.beans.PropertyChangeListener propertyChangeListener44 = null;
//        timePeriodValues41.removePropertyChangeListener(propertyChangeListener44);
//        int int46 = timePeriodValues41.getItemCount();
//        int int47 = timePeriodValues41.getMaxMiddleIndex();
//        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year();
//        timePeriodValues41.add((org.jfree.data.time.TimePeriod) year48, (double) 6);
//        org.jfree.data.time.TimePeriodValue timePeriodValue52 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year48, (java.lang.Number) 2019L);
//        java.util.Date date53 = year48.getEnd();
//        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date53, timeZone54);
//        org.jfree.data.time.TimePeriodValues timePeriodValues57 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        timePeriodValues57.setNotify(true);
//        java.beans.PropertyChangeListener propertyChangeListener60 = null;
//        timePeriodValues57.removePropertyChangeListener(propertyChangeListener60);
//        int int62 = timePeriodValues57.getItemCount();
//        int int63 = timePeriodValues57.getMaxMiddleIndex();
//        org.jfree.data.time.Year year64 = new org.jfree.data.time.Year();
//        timePeriodValues57.add((org.jfree.data.time.TimePeriod) year64, (double) 6);
//        org.jfree.data.time.TimePeriodValue timePeriodValue68 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year64, (java.lang.Number) 2019L);
//        java.util.Date date69 = year64.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod70 = new org.jfree.data.time.SimpleTimePeriod(date53, date69);
//        java.util.TimeZone timeZone71 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year72 = new org.jfree.data.time.Year(date53, timeZone71);
//        org.jfree.data.time.Year year73 = new org.jfree.data.time.Year(date4, timeZone71);
//        boolean boolean75 = year73.equals((java.lang.Object) 12);
//        java.util.Date date76 = year73.getStart();
//        java.lang.String str77 = year73.toString();
//        org.jfree.data.time.Day day78 = new org.jfree.data.time.Day();
//        long long79 = day78.getSerialIndex();
//        int int80 = year73.compareTo((java.lang.Object) day78);
//        java.util.Calendar calendar81 = null;
//        try {
//            day78.peg(calendar81);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(timeZone28);
//        org.junit.Assert.assertNull(regularTimePeriod29);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass36);
//        org.junit.Assert.assertNull(regularTimePeriod39);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertNotNull(timeZone54);
//        org.junit.Assert.assertNull(regularTimePeriod55);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-1) + "'", int63 == (-1));
//        org.junit.Assert.assertNotNull(date69);
//        org.junit.Assert.assertNotNull(timeZone71);
//        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
//        org.junit.Assert.assertNotNull(date76);
//        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "2019" + "'", str77.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long79 + "' != '" + 43629L + "'", long79 == 43629L);
//        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 0 + "'", int80 == 0);
//    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        boolean boolean5 = timePeriodValues1.equals((java.lang.Object) (short) 0);
        timePeriodValues1.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=0]");
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.Object obj2 = seriesChangeEvent1.getSource();
        java.lang.Object obj3 = seriesChangeEvent1.getSource();
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + (byte) 0 + "'", obj2.equals((byte) 0));
        org.junit.Assert.assertTrue("'" + obj3 + "' != '" + (byte) 0 + "'", obj3.equals((byte) 0));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMinEndIndex();
        boolean boolean6 = timePeriodValues1.isEmpty();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        int int8 = timePeriodValues1.getMaxMiddleIndex();
        timePeriodValues1.fireSeriesChanged();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate11 = day10.getSerialDate();
        java.lang.Object obj12 = null;
        boolean boolean13 = day10.equals(obj12);
        java.lang.Object obj14 = null;
        boolean boolean15 = day10.equals(obj14);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day10, (double) 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "2019");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDescription("31-December-2019");
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (java.lang.Number) 100);
        java.util.Date date11 = year7.getStart();
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (java.lang.Number) (short) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year7.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod14, (java.lang.Number) (-1));
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 100);
        java.util.Date date21 = year17.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener24 = null;
        timePeriodValues23.addChangeListener(seriesChangeListener24);
        int int26 = timePeriodValues23.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass27 = timePeriodValues23.getClass();
        java.util.Date date28 = null;
        java.util.TimeZone timeZone29 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass27, date28, timeZone29);
        org.jfree.data.time.TimePeriodValues timePeriodValues32 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues32.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener35 = null;
        timePeriodValues32.removePropertyChangeListener(propertyChangeListener35);
        int int37 = timePeriodValues32.getItemCount();
        int int38 = timePeriodValues32.getMaxMiddleIndex();
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
        timePeriodValues32.add((org.jfree.data.time.TimePeriod) year39, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue43 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year39, (java.lang.Number) 2019L);
        java.util.Date date44 = year39.getEnd();
        java.util.TimeZone timeZone45 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass27, date44, timeZone45);
        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year(date21, timeZone45);
        org.jfree.data.time.TimePeriodValues timePeriodValues49 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener50 = null;
        timePeriodValues49.addChangeListener(seriesChangeListener50);
        int int52 = timePeriodValues49.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass53 = timePeriodValues49.getClass();
        java.util.Date date54 = null;
        java.util.TimeZone timeZone55 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass53, date54, timeZone55);
        org.jfree.data.time.TimePeriodValues timePeriodValues58 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues58.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener61 = null;
        timePeriodValues58.removePropertyChangeListener(propertyChangeListener61);
        int int63 = timePeriodValues58.getItemCount();
        int int64 = timePeriodValues58.getMaxMiddleIndex();
        org.jfree.data.time.Year year65 = new org.jfree.data.time.Year();
        timePeriodValues58.add((org.jfree.data.time.TimePeriod) year65, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue69 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year65, (java.lang.Number) 2019L);
        java.util.Date date70 = year65.getEnd();
        java.util.TimeZone timeZone71 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass53, date70, timeZone71);
        org.jfree.data.time.Year year73 = new org.jfree.data.time.Year(date21, timeZone71);
        java.util.TimeZone timeZone74 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day75 = new org.jfree.data.time.Day(date21, timeZone74);
        org.jfree.data.time.Year year76 = new org.jfree.data.time.Year(date21);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year76, (double) 4);
        java.lang.String str79 = year76.toString();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2019L + "'", long18 == 2019L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(timeZone45);
        org.junit.Assert.assertNull(regularTimePeriod46);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass53);
        org.junit.Assert.assertNull(regularTimePeriod56);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + (-1) + "'", int64 == (-1));
        org.junit.Assert.assertNotNull(date70);
        org.junit.Assert.assertNotNull(timeZone71);
        org.junit.Assert.assertNull(regularTimePeriod72);
        org.junit.Assert.assertNotNull(timeZone74);
        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "2019" + "'", str79.equals("2019"));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
        timePeriodFormatException9.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
        timePeriodFormatException14.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("Value");
        timePeriodFormatException16.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
        timePeriodFormatException9.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException23 = new org.jfree.data.time.TimePeriodFormatException("2019");
        timePeriodFormatException19.addSuppressed((java.lang.Throwable) timePeriodFormatException23);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
        java.lang.Throwable throwable26 = null;
        try {
            timePeriodFormatException1.addSuppressed(throwable26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 100);
        java.util.Date date4 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues6.addChangeListener(seriesChangeListener7);
        int int9 = timePeriodValues6.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass10 = timePeriodValues6.getClass();
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date11, timeZone12);
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues15.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timePeriodValues15.removePropertyChangeListener(propertyChangeListener18);
        int int20 = timePeriodValues15.getItemCount();
        int int21 = timePeriodValues15.getMaxMiddleIndex();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        timePeriodValues15.add((org.jfree.data.time.TimePeriod) year22, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue26 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year22, (java.lang.Number) 2019L);
        java.util.Date date27 = year22.getEnd();
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date27, timeZone28);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(date4, timeZone28);
        org.jfree.data.time.TimePeriodValues timePeriodValues32 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener33 = null;
        timePeriodValues32.addChangeListener(seriesChangeListener33);
        int int35 = timePeriodValues32.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass36 = timePeriodValues32.getClass();
        java.util.Date date37 = null;
        java.util.TimeZone timeZone38 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date37, timeZone38);
        org.jfree.data.time.TimePeriodValues timePeriodValues41 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues41.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener44 = null;
        timePeriodValues41.removePropertyChangeListener(propertyChangeListener44);
        int int46 = timePeriodValues41.getItemCount();
        int int47 = timePeriodValues41.getMaxMiddleIndex();
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year();
        timePeriodValues41.add((org.jfree.data.time.TimePeriod) year48, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue52 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year48, (java.lang.Number) 2019L);
        java.util.Date date53 = year48.getEnd();
        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date53, timeZone54);
        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year(date4, timeZone54);
        java.util.TimeZone timeZone57 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(date4, timeZone57);
        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year();
        long long60 = year59.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue62 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year59, (java.lang.Number) 100);
        java.util.Date date63 = year59.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues65 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener66 = null;
        timePeriodValues65.addChangeListener(seriesChangeListener66);
        int int68 = timePeriodValues65.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass69 = timePeriodValues65.getClass();
        java.util.Date date70 = null;
        java.util.TimeZone timeZone71 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass69, date70, timeZone71);
        org.jfree.data.time.TimePeriodValues timePeriodValues74 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues74.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener77 = null;
        timePeriodValues74.removePropertyChangeListener(propertyChangeListener77);
        int int79 = timePeriodValues74.getItemCount();
        int int80 = timePeriodValues74.getMaxMiddleIndex();
        org.jfree.data.time.Year year81 = new org.jfree.data.time.Year();
        timePeriodValues74.add((org.jfree.data.time.TimePeriod) year81, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue85 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year81, (java.lang.Number) 2019L);
        java.util.Date date86 = year81.getEnd();
        java.util.TimeZone timeZone87 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod88 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass69, date86, timeZone87);
        org.jfree.data.time.Year year89 = new org.jfree.data.time.Year(date63, timeZone87);
        org.jfree.data.time.Day day90 = new org.jfree.data.time.Day(date4, timeZone87);
        long long91 = day90.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertNotNull(timeZone54);
        org.junit.Assert.assertNull(regularTimePeriod55);
        org.junit.Assert.assertNotNull(timeZone57);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 2019L + "'", long60 == 2019L);
        org.junit.Assert.assertNotNull(date63);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + (-1) + "'", int68 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass69);
        org.junit.Assert.assertNull(regularTimePeriod72);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 0 + "'", int79 == 0);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + (-1) + "'", int80 == (-1));
        org.junit.Assert.assertNotNull(date86);
        org.junit.Assert.assertNotNull(timeZone87);
        org.junit.Assert.assertNull(regularTimePeriod88);
        org.junit.Assert.assertTrue("'" + long91 + "' != '" + 43466L + "'", long91 == 43466L);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(1L, (long) 8);
        long long3 = simpleTimePeriod2.getEndMillis();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 8L + "'", long3 == 8L);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        int int11 = timePeriodValues1.getMaxEndIndex();
        java.lang.String str12 = timePeriodValues1.getRangeDescription();
        timePeriodValues1.setKey((java.lang.Comparable) 7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener15);
        timePeriodValues1.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=4]");
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Value" + "'", str12.equals("Value"));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMinEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = timePeriodValues1.createCopy(6, (int) (byte) 100);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener13);
        int int15 = timePeriodValues10.getItemCount();
        int int16 = timePeriodValues10.getMaxMiddleIndex();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) year17, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year17.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year17.previous();
        java.lang.Object obj24 = null;
        int int25 = year17.compareTo(obj24);
        timePeriodValues1.setKey((java.lang.Comparable) year17);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException28 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
        java.lang.Throwable[] throwableArray29 = timePeriodFormatException28.getSuppressed();
        int int30 = year17.compareTo((java.lang.Object) timePeriodFormatException28);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(throwableArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        int int11 = timePeriodValues1.getMaxEndIndex();
        java.lang.String str12 = timePeriodValues1.getRangeDescription();
        int int13 = timePeriodValues1.getMaxEndIndex();
        java.lang.String str14 = timePeriodValues1.getDescription();
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Value" + "'", str12.equals("Value"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNull(str14);
    }

//    @Test
//    public void test222() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test222");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
//        long long3 = year2.getSerialIndex();
//        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year2, (java.lang.Number) 100);
//        java.lang.Object obj6 = timePeriodValue5.clone();
//        int int7 = day0.compareTo(obj6);
//        int int8 = day0.getDayOfMonth();
//        java.lang.String str9 = day0.toString();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
//        org.junit.Assert.assertNotNull(obj6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 13 + "'", int8 == 13);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "13-June-2019" + "'", str9.equals("13-June-2019"));
//    }

//    @Test
//    public void test223() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test223");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass1 = day0.getClass();
//        long long2 = day0.getLastMillisecond();
//        java.lang.String str3 = day0.toString();
//        long long4 = day0.getFirstMillisecond();
//        long long5 = day0.getSerialIndex();
//        java.util.Calendar calendar6 = null;
//        try {
//            day0.peg(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560495599999L + "'", long2 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43629L + "'", long5 == 43629L);
//    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        java.util.Date date0 = null;
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues2.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues2.removePropertyChangeListener(propertyChangeListener5);
        int int7 = timePeriodValues2.getItemCount();
        int int8 = timePeriodValues2.getMaxMiddleIndex();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        timePeriodValues2.add((org.jfree.data.time.TimePeriod) year9, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year9, (java.lang.Number) 2019L);
        java.util.Date date14 = year9.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
        timePeriodValues16.addChangeListener(seriesChangeListener17);
        int int19 = timePeriodValues16.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass20 = timePeriodValues16.getClass();
        java.util.Date date21 = null;
        java.util.TimeZone timeZone22 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass20, date21, timeZone22);
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues25.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener28 = null;
        timePeriodValues25.removePropertyChangeListener(propertyChangeListener28);
        int int30 = timePeriodValues25.getItemCount();
        int int31 = timePeriodValues25.getMaxMiddleIndex();
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        timePeriodValues25.add((org.jfree.data.time.TimePeriod) year32, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue36 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year32, (java.lang.Number) 2019L);
        java.util.Date date37 = year32.getEnd();
        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass20, date37, timeZone38);
        org.jfree.data.time.TimePeriodValues timePeriodValues41 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues41.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener44 = null;
        timePeriodValues41.removePropertyChangeListener(propertyChangeListener44);
        int int46 = timePeriodValues41.getItemCount();
        int int47 = timePeriodValues41.getMaxMiddleIndex();
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year();
        timePeriodValues41.add((org.jfree.data.time.TimePeriod) year48, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue52 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year48, (java.lang.Number) 2019L);
        java.util.Date date53 = year48.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod54 = new org.jfree.data.time.SimpleTimePeriod(date37, date53);
        long long55 = simpleTimePeriod54.getEndMillis();
        long long56 = simpleTimePeriod54.getStartMillis();
        boolean boolean58 = simpleTimePeriod54.equals((java.lang.Object) 0);
        java.util.Date date59 = simpleTimePeriod54.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues61 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues61.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener64 = null;
        timePeriodValues61.removePropertyChangeListener(propertyChangeListener64);
        int int66 = timePeriodValues61.getItemCount();
        int int67 = timePeriodValues61.getMaxMiddleIndex();
        org.jfree.data.time.Year year68 = new org.jfree.data.time.Year();
        timePeriodValues61.add((org.jfree.data.time.TimePeriod) year68, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue72 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year68, (java.lang.Number) 2019L);
        java.util.Date date73 = year68.getEnd();
        org.jfree.data.time.Year year74 = new org.jfree.data.time.Year(date73);
        java.util.TimeZone timeZone75 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day76 = new org.jfree.data.time.Day(date73, timeZone75);
        org.jfree.data.time.Day day77 = new org.jfree.data.time.Day(date59, timeZone75);
        org.jfree.data.time.Day day78 = new org.jfree.data.time.Day(date14, timeZone75);
        try {
            org.jfree.data.time.Year year79 = new org.jfree.data.time.Year(date0, timeZone75);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(timeZone38);
        org.junit.Assert.assertNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1577865599999L + "'", long55 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1577865599999L + "'", long56 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + (-1) + "'", int67 == (-1));
        org.junit.Assert.assertNotNull(date73);
        org.junit.Assert.assertNotNull(timeZone75);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(serialDate1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(serialDate1);
        java.util.Calendar calendar4 = null;
        try {
            long long5 = day3.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
    }

//    @Test
//    public void test226() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test226");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass1 = day0.getClass();
//        long long2 = day0.getLastMillisecond();
//        long long3 = day0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
//        org.junit.Assert.assertNotNull(wildcardClass1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560495599999L + "'", long2 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43629L + "'", long3 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year8.previous();
        java.util.Date date14 = year8.getEnd();
        int int15 = year8.getYear();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 2019L);
        java.lang.Class<?> wildcardClass13 = year8.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues15.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timePeriodValues15.removePropertyChangeListener(propertyChangeListener18);
        int int20 = timePeriodValues15.getItemCount();
        int int21 = timePeriodValues15.getMaxMiddleIndex();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        timePeriodValues15.add((org.jfree.data.time.TimePeriod) year22, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue26 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year22, (java.lang.Number) 2019L);
        boolean boolean27 = year8.equals((java.lang.Object) 2019L);
        long long28 = year8.getSerialIndex();
        long long29 = year8.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue31 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, 1.0d);
        timePeriodValue31.setValue((java.lang.Number) (-1L));
        timePeriodValue31.setValue((java.lang.Number) (-1.0f));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 2019L + "'", long28 == 2019L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 2019L + "'", long29 == 2019L);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(2019);
        long long2 = year1.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 2019L);
        java.util.Date date13 = year8.getEnd();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date13);
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date13, "13-June-2019", "31-December-2019");
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date13);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(date13);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues3.setNotify(true);
        boolean boolean7 = timePeriodValues3.equals((java.lang.Object) (short) 0);
        boolean boolean8 = year0.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        timePeriodValues10.setKey((java.lang.Comparable) 100L);
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues16.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timePeriodValues16.removePropertyChangeListener(propertyChangeListener19);
        int int21 = timePeriodValues16.getItemCount();
        int int22 = timePeriodValues16.getMaxMiddleIndex();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        timePeriodValues16.add((org.jfree.data.time.TimePeriod) year23, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue27 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year23, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year23.previous();
        timePeriodValues10.setKey((java.lang.Comparable) year23);
        int int30 = year0.compareTo((java.lang.Object) year23);
        java.lang.String str31 = year0.toString();
        java.lang.Object obj32 = null;
        boolean boolean33 = year0.equals(obj32);
        java.util.Date date34 = year0.getStart();
        org.jfree.data.time.TimePeriodValue timePeriodValue36 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, 0.0d);
        java.lang.Object obj37 = null;
        int int38 = year0.compareTo(obj37);
        long long39 = year0.getLastMillisecond();
        int int40 = year0.getYear();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "2019" + "'", str31.equals("2019"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1577865599999L + "'", long39 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2019 + "'", int40 == 2019);
    }

//    @Test
//    public void test232() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test232");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getMiddleMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate5 = day4.getSerialDate();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
//        boolean boolean7 = day0.equals((java.lang.Object) serialDate5);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day0.next();
//        java.lang.String str9 = day0.toString();
//        int int10 = day0.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560452399999L + "'", long2 == 1560452399999L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "13-June-2019" + "'", str9.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 13 + "'", int10 == 13);
//    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(1L, (long) 1);
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener4);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 100);
        java.util.Date date4 = year0.getStart();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 1560409200000L);
        int int7 = year0.getYear();
        long long8 = year0.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546329600000L + "'", long8 == 1546329600000L);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        boolean boolean2 = timePeriodValues1.getNotify();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener3);
        timePeriodValues1.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesChangeEvent[source=0]");
        timePeriodValues1.setDomainDescription("TimePeriodValue[2019,100.0]");
        java.lang.Comparable comparable9 = timePeriodValues1.getKey();
        int int10 = timePeriodValues1.getMinMiddleIndex();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + (byte) 1 + "'", comparable9.equals((byte) 1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener13);
        int int15 = timePeriodValues10.getItemCount();
        int int16 = timePeriodValues10.getMaxMiddleIndex();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) year17, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 2019L);
        java.util.Date date22 = year17.getEnd();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date22, timeZone23);
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues26.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timePeriodValues26.removePropertyChangeListener(propertyChangeListener29);
        int int31 = timePeriodValues26.getItemCount();
        int int32 = timePeriodValues26.getMaxMiddleIndex();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        timePeriodValues26.add((org.jfree.data.time.TimePeriod) year33, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue37 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year33, (java.lang.Number) 2019L);
        java.util.Date date38 = year33.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(date22, date38);
        long long40 = simpleTimePeriod39.getEndMillis();
        long long41 = simpleTimePeriod39.getStartMillis();
        java.util.Date date42 = simpleTimePeriod39.getStart();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1577865599999L + "'", long40 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1577865599999L + "'", long41 == 1577865599999L);
        org.junit.Assert.assertNotNull(date42);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("TimePeriodValue[13-June-2019,8.0]");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        java.lang.String str12 = timePeriodFormatException6.toString();
        org.jfree.data.general.SeriesException seriesException14 = new org.jfree.data.general.SeriesException("");
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) seriesException14);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesChangeEvent[source=0]" + "'", str12.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesChangeEvent[source=0]"));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year11, (java.lang.Number) 100);
        timePeriodValues1.add(timePeriodValue14);
        java.lang.String str16 = timePeriodValues1.getDescription();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 100);
        java.util.Date date21 = year17.getStart();
        org.jfree.data.time.TimePeriodValue timePeriodValue23 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) (short) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues25.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener28 = null;
        timePeriodValues25.removePropertyChangeListener(propertyChangeListener28);
        java.lang.String str30 = timePeriodValues25.getDescription();
        boolean boolean31 = year17.equals((java.lang.Object) timePeriodValues25);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 43629L);
        long long34 = year17.getSerialIndex();
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2019L + "'", long12 == 2019L);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2019L + "'", long18 == 2019L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 2019L + "'", long34 == 2019L);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("TimePeriodValue[2019,100]");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMinEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = timePeriodValues1.createCopy(6, (int) (byte) 100);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener13);
        int int15 = timePeriodValues10.getItemCount();
        int int16 = timePeriodValues10.getMaxMiddleIndex();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) year17, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year17.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year17.previous();
        java.lang.Object obj24 = null;
        int int25 = year17.compareTo(obj24);
        timePeriodValues1.setKey((java.lang.Comparable) year17);
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues28.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timePeriodValues28.removePropertyChangeListener(propertyChangeListener31);
        int int33 = timePeriodValues28.getItemCount();
        int int34 = timePeriodValues28.getMaxMiddleIndex();
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
        timePeriodValues28.add((org.jfree.data.time.TimePeriod) year35, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue39 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year35, (java.lang.Number) 2019L);
        java.util.Date date40 = year35.getEnd();
        long long41 = year35.getMiddleMillisecond();
        long long42 = year35.getSerialIndex();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year35, (double) 0);
        java.lang.String str45 = timePeriodValues1.getDescription();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1562097599999L + "'", long41 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 2019L + "'", long42 == 2019L);
        org.junit.Assert.assertNull(str45);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener13);
        int int15 = timePeriodValues10.getItemCount();
        int int16 = timePeriodValues10.getMaxMiddleIndex();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) year17, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 2019L);
        java.util.Date date22 = year17.getEnd();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date22, timeZone23);
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues26.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timePeriodValues26.removePropertyChangeListener(propertyChangeListener29);
        int int31 = timePeriodValues26.getItemCount();
        int int32 = timePeriodValues26.getMaxMiddleIndex();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        timePeriodValues26.add((org.jfree.data.time.TimePeriod) year33, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue37 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year33, (java.lang.Number) 2019L);
        java.util.Date date38 = year33.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(date22, date38);
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date22);
        org.jfree.data.time.SerialDate serialDate41 = day40.getSerialDate();
        int int42 = day40.getYear();
        java.util.Calendar calendar43 = null;
        try {
            long long44 = day40.getFirstMillisecond(calendar43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 2019 + "'", int42 == 2019);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year11, (java.lang.Number) 100);
        timePeriodValues1.add(timePeriodValue14);
        java.lang.Object obj16 = timePeriodValue14.clone();
        java.lang.Object obj17 = timePeriodValue14.clone();
        java.lang.Object obj18 = new java.lang.Object();
        boolean boolean19 = timePeriodValue14.equals(obj18);
        java.lang.String str20 = timePeriodValue14.toString();
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2019L + "'", long12 == 2019L);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "TimePeriodValue[2019,100]" + "'", str20.equals("TimePeriodValue[2019,100]"));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 2019L);
        java.lang.Number number13 = timePeriodValue12.getValue();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 2019L + "'", number13.equals(2019L));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year8.previous();
        java.lang.String str14 = year8.toString();
        long long15 = year8.getFirstMillisecond();
        java.util.Calendar calendar16 = null;
        try {
            long long17 = year8.getFirstMillisecond(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019" + "'", str14.equals("2019"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1546329600000L + "'", long15 == 1546329600000L);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMinEndIndex();
        java.lang.String str6 = timePeriodValues1.getRangeDescription();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue8 = timePeriodValues1.getDataItem(13);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 13, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Value" + "'", str6.equals("Value"));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 100);
        java.util.Date date4 = year0.getStart();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) (short) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year0.previous();
        long long8 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 2019L);
        long long11 = year0.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
    }

//    @Test
//    public void test247() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test247");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        timePeriodValues1.setNotify(true);
//        timePeriodValues1.setKey((java.lang.Comparable) 100L);
//        timePeriodValues1.setKey((java.lang.Comparable) (short) 100);
//        timePeriodValues1.setDomainDescription("Time");
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        int int11 = day10.getMonth();
//        long long12 = day10.getMiddleMillisecond();
//        long long13 = day10.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate14 = day10.getSerialDate();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate14);
//        timePeriodValues1.setKey((java.lang.Comparable) day15);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560452399999L + "'", long12 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560409200000L + "'", long13 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate14);
//    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        boolean boolean5 = timePeriodValues1.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year6, (java.lang.Number) 100);
        java.lang.Object obj10 = timePeriodValue9.clone();
        java.lang.String str11 = timePeriodValue9.toString();
        boolean boolean13 = timePeriodValue9.equals((java.lang.Object) 100);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        boolean boolean15 = timePeriodValue9.equals((java.lang.Object) day14);
        timePeriodValues1.add(timePeriodValue9);
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener17);
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener19);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "TimePeriodValue[2019,100]" + "'", str11.equals("TimePeriodValue[2019,100]"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener13);
        int int15 = timePeriodValues10.getItemCount();
        int int16 = timePeriodValues10.getMaxMiddleIndex();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) year17, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 2019L);
        java.util.Date date22 = year17.getEnd();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date22, timeZone23);
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues26.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timePeriodValues26.removePropertyChangeListener(propertyChangeListener29);
        int int31 = timePeriodValues26.getItemCount();
        int int32 = timePeriodValues26.getMaxMiddleIndex();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        timePeriodValues26.add((org.jfree.data.time.TimePeriod) year33, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue37 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year33, (java.lang.Number) 2019L);
        java.util.Date date38 = year33.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(date22, date38);
        org.jfree.data.time.TimePeriodValues timePeriodValues41 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues41.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener44 = null;
        timePeriodValues41.removePropertyChangeListener(propertyChangeListener44);
        java.lang.String str46 = timePeriodValues41.getDescription();
        int int47 = timePeriodValues41.getMinStartIndex();
        timePeriodValues41.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues52 = timePeriodValues41.createCopy(0, 1);
        boolean boolean53 = simpleTimePeriod39.equals((java.lang.Object) 0);
        long long54 = simpleTimePeriod39.getEndMillis();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNull(str46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1577865599999L + "'", long54 == 1577865599999L);
    }

//    @Test
//    public void test250() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test250");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getMiddleMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        timePeriodValues5.setNotify(true);
//        java.beans.PropertyChangeListener propertyChangeListener8 = null;
//        timePeriodValues5.removePropertyChangeListener(propertyChangeListener8);
//        int int10 = timePeriodValues5.getItemCount();
//        int int11 = timePeriodValues5.getMaxMiddleIndex();
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
//        timePeriodValues5.add((org.jfree.data.time.TimePeriod) year12, (double) 6);
//        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year12, (java.lang.Number) 2019L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year12.previous();
//        java.lang.String str18 = year12.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year12.next();
//        java.lang.Number number20 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod19, number20);
//        int int22 = day0.compareTo((java.lang.Object) regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560452399999L + "'", long2 == 1560452399999L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "2019" + "'", str18.equals("2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        int int11 = timePeriodValues1.getItemCount();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues13.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues13.removePropertyChangeListener(propertyChangeListener16);
        int int18 = timePeriodValues13.getItemCount();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        long long20 = year19.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue22 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year19, (java.lang.Number) 100);
        java.lang.Object obj23 = timePeriodValue22.clone();
        timePeriodValues13.add(timePeriodValue22);
        java.lang.String str25 = timePeriodValue22.toString();
        java.lang.Object obj26 = timePeriodValue22.clone();
        timePeriodValues1.add(timePeriodValue22);
        timePeriodValue22.setValue((java.lang.Number) 10.0f);
        org.jfree.data.time.TimePeriod timePeriod30 = timePeriodValue22.getPeriod();
        org.jfree.data.time.TimePeriod timePeriod31 = timePeriodValue22.getPeriod();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 2019L + "'", long20 == 2019L);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "TimePeriodValue[2019,100]" + "'", str25.equals("TimePeriodValue[2019,100]"));
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertNotNull(timePeriod30);
        org.junit.Assert.assertNotNull(timePeriod31);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues1);
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues7.setNotify(true);
        timePeriodValues7.setKey((java.lang.Comparable) 100L);
        timePeriodValues7.setKey((java.lang.Comparable) (short) 100);
        java.lang.String str14 = timePeriodValues7.getRangeDescription();
        int int15 = timePeriodValues7.getMinStartIndex();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        long long17 = year16.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year16, (java.lang.Number) 100);
        java.util.Date date20 = year16.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener23 = null;
        timePeriodValues22.addChangeListener(seriesChangeListener23);
        int int25 = timePeriodValues22.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass26 = timePeriodValues22.getClass();
        java.util.Date date27 = null;
        java.util.TimeZone timeZone28 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass26, date27, timeZone28);
        org.jfree.data.time.TimePeriodValues timePeriodValues31 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues31.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener34 = null;
        timePeriodValues31.removePropertyChangeListener(propertyChangeListener34);
        int int36 = timePeriodValues31.getItemCount();
        int int37 = timePeriodValues31.getMaxMiddleIndex();
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
        timePeriodValues31.add((org.jfree.data.time.TimePeriod) year38, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue42 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year38, (java.lang.Number) 2019L);
        java.util.Date date43 = year38.getEnd();
        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass26, date43, timeZone44);
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year(date20, timeZone44);
        org.jfree.data.time.TimePeriodValues timePeriodValues48 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener49 = null;
        timePeriodValues48.addChangeListener(seriesChangeListener49);
        int int51 = timePeriodValues48.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass52 = timePeriodValues48.getClass();
        java.util.Date date53 = null;
        java.util.TimeZone timeZone54 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass52, date53, timeZone54);
        org.jfree.data.time.TimePeriodValues timePeriodValues57 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues57.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener60 = null;
        timePeriodValues57.removePropertyChangeListener(propertyChangeListener60);
        int int62 = timePeriodValues57.getItemCount();
        int int63 = timePeriodValues57.getMaxMiddleIndex();
        org.jfree.data.time.Year year64 = new org.jfree.data.time.Year();
        timePeriodValues57.add((org.jfree.data.time.TimePeriod) year64, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue68 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year64, (java.lang.Number) 2019L);
        java.util.Date date69 = year64.getEnd();
        java.util.TimeZone timeZone70 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass52, date69, timeZone70);
        org.jfree.data.time.TimePeriodValues timePeriodValues73 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues73.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener76 = null;
        timePeriodValues73.removePropertyChangeListener(propertyChangeListener76);
        int int78 = timePeriodValues73.getItemCount();
        int int79 = timePeriodValues73.getMaxMiddleIndex();
        org.jfree.data.time.Year year80 = new org.jfree.data.time.Year();
        timePeriodValues73.add((org.jfree.data.time.TimePeriod) year80, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue84 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year80, (java.lang.Number) 2019L);
        java.util.Date date85 = year80.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod86 = new org.jfree.data.time.SimpleTimePeriod(date69, date85);
        java.util.TimeZone timeZone87 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year88 = new org.jfree.data.time.Year(date69, timeZone87);
        org.jfree.data.time.Year year89 = new org.jfree.data.time.Year(date20, timeZone87);
        boolean boolean91 = year89.equals((java.lang.Object) 12);
        timePeriodValues7.add((org.jfree.data.time.TimePeriod) year89, (double) 'a');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod94 = year89.previous();
        java.lang.Number number95 = null;
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year89, number95);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Value" + "'", str14.equals("Value"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2019L + "'", long17 == 2019L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(timeZone44);
        org.junit.Assert.assertNull(regularTimePeriod45);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1) + "'", int51 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass52);
        org.junit.Assert.assertNull(regularTimePeriod55);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-1) + "'", int63 == (-1));
        org.junit.Assert.assertNotNull(date69);
        org.junit.Assert.assertNotNull(timeZone70);
        org.junit.Assert.assertNull(regularTimePeriod71);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 0 + "'", int78 == 0);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + (-1) + "'", int79 == (-1));
        org.junit.Assert.assertNotNull(date85);
        org.junit.Assert.assertNotNull(timeZone87);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod94);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        boolean boolean2 = timePeriodValues1.getNotify();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener3);
        java.lang.Object obj5 = timePeriodValues1.clone();
        try {
            org.jfree.data.time.TimePeriod timePeriod7 = timePeriodValues1.getTimePeriod(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 100);
        java.lang.Object obj4 = timePeriodValue3.clone();
        java.lang.String str5 = timePeriodValue3.toString();
        boolean boolean7 = timePeriodValue3.equals((java.lang.Object) 100);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        boolean boolean9 = timePeriodValue3.equals((java.lang.Object) day8);
        org.jfree.data.time.SerialDate serialDate10 = day8.getSerialDate();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) serialDate10, "org.jfree.data.general.SeriesChangeEvent[source=4]", "");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "TimePeriodValue[2019,100]" + "'", str5.equals("TimePeriodValue[2019,100]"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(serialDate10);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 'a', (long) 100);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues3.setNotify(true);
        boolean boolean7 = timePeriodValues3.equals((java.lang.Object) (short) 0);
        boolean boolean8 = year0.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        timePeriodValues10.setKey((java.lang.Comparable) 100L);
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues16.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timePeriodValues16.removePropertyChangeListener(propertyChangeListener19);
        int int21 = timePeriodValues16.getItemCount();
        int int22 = timePeriodValues16.getMaxMiddleIndex();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        timePeriodValues16.add((org.jfree.data.time.TimePeriod) year23, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue27 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year23, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year23.previous();
        timePeriodValues10.setKey((java.lang.Comparable) year23);
        int int30 = year0.compareTo((java.lang.Object) year23);
        java.lang.String str31 = year0.toString();
        long long32 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues34 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues34.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener37 = null;
        timePeriodValues34.removePropertyChangeListener(propertyChangeListener37);
        java.lang.String str39 = timePeriodValues34.getDescription();
        int int40 = timePeriodValues34.getMinStartIndex();
        int int41 = timePeriodValues34.getMaxEndIndex();
        timePeriodValues34.setDomainDescription("");
        int int44 = timePeriodValues34.getMaxEndIndex();
        java.lang.String str45 = timePeriodValues34.getRangeDescription();
        java.lang.Class<?> wildcardClass46 = timePeriodValues34.getClass();
        boolean boolean47 = year0.equals((java.lang.Object) timePeriodValues34);
        long long48 = year0.getSerialIndex();
        long long49 = year0.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "2019" + "'", str31.equals("2019"));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 2019L + "'", long32 == 2019L);
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "Value" + "'", str45.equals("Value"));
        org.junit.Assert.assertNotNull(wildcardClass46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 2019L + "'", long48 == 2019L);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1577865599999L + "'", long49 == 1577865599999L);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        boolean boolean5 = timePeriodValues1.equals((java.lang.Object) (short) 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener6);
        timePeriodValues1.setRangeDescription("hi!");
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 100);
        java.lang.Object obj4 = timePeriodValue3.clone();
        java.lang.String str5 = timePeriodValue3.toString();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getSerialIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues9.setNotify(true);
        boolean boolean13 = timePeriodValues9.equals((java.lang.Object) (short) 0);
        boolean boolean14 = year6.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues16.setNotify(true);
        timePeriodValues16.setKey((java.lang.Comparable) 100L);
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues22.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener25 = null;
        timePeriodValues22.removePropertyChangeListener(propertyChangeListener25);
        int int27 = timePeriodValues22.getItemCount();
        int int28 = timePeriodValues22.getMaxMiddleIndex();
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
        timePeriodValues22.add((org.jfree.data.time.TimePeriod) year29, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue33 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year29, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = year29.previous();
        timePeriodValues16.setKey((java.lang.Comparable) year29);
        int int36 = year6.compareTo((java.lang.Object) year29);
        java.lang.String str37 = year6.toString();
        java.lang.Object obj38 = null;
        boolean boolean39 = year6.equals(obj38);
        java.util.Date date40 = year6.getStart();
        boolean boolean41 = timePeriodValue3.equals((java.lang.Object) date40);
        org.jfree.data.time.TimePeriodValues timePeriodValues43 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener44 = null;
        timePeriodValues43.addChangeListener(seriesChangeListener44);
        int int46 = timePeriodValues43.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass47 = timePeriodValues43.getClass();
        java.util.Date date48 = null;
        java.util.TimeZone timeZone49 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass47, date48, timeZone49);
        org.jfree.data.time.TimePeriodValues timePeriodValues52 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues52.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener55 = null;
        timePeriodValues52.removePropertyChangeListener(propertyChangeListener55);
        int int57 = timePeriodValues52.getItemCount();
        int int58 = timePeriodValues52.getMaxMiddleIndex();
        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year();
        timePeriodValues52.add((org.jfree.data.time.TimePeriod) year59, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue63 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year59, (java.lang.Number) 2019L);
        java.util.Date date64 = year59.getEnd();
        java.util.TimeZone timeZone65 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass47, date64, timeZone65);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod67 = new org.jfree.data.time.SimpleTimePeriod(date40, date64);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "TimePeriodValue[2019,100]" + "'", str5.equals("TimePeriodValue[2019,100]"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "2019" + "'", str37.equals("2019"));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass47);
        org.junit.Assert.assertNull(regularTimePeriod50);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + (-1) + "'", int58 == (-1));
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertNotNull(timeZone65);
        org.junit.Assert.assertNull(regularTimePeriod66);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        int int11 = timePeriodValues1.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener12);
        int int14 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDomainDescription("hi!");
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

//    @Test
//    public void test260() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test260");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getMiddleMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0);
//        java.util.Calendar calendar5 = null;
//        try {
//            day0.peg(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560452399999L + "'", long2 == 1560452399999L);
//        org.junit.Assert.assertNotNull(serialDate3);
//    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 100);
        java.util.Date date4 = year0.getStart();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) (short) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year0.previous();
        long long8 = year0.getSerialIndex();
        java.lang.Object obj9 = null;
        boolean boolean10 = year0.equals(obj9);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

//    @Test
//    public void test262() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test262");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        timePeriodValues1.setNotify(true);
//        timePeriodValues1.setKey((java.lang.Comparable) 100L);
//        timePeriodValues1.setKey((java.lang.Comparable) (short) 100);
//        java.lang.String str8 = timePeriodValues1.getRangeDescription();
//        int int9 = timePeriodValues1.getMinStartIndex();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
//        timePeriodValues1.removeChangeListener(seriesChangeListener10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        int int13 = day12.getMonth();
//        long long14 = day12.getMiddleMillisecond();
//        org.jfree.data.time.SerialDate serialDate15 = day12.getSerialDate();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate17 = day16.getSerialDate();
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(serialDate17);
//        boolean boolean19 = day12.equals((java.lang.Object) serialDate17);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(serialDate17);
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day20, (java.lang.Number) 0);
//        int int23 = timePeriodValues1.getMinStartIndex();
//        java.beans.PropertyChangeListener propertyChangeListener24 = null;
//        timePeriodValues1.addPropertyChangeListener(propertyChangeListener24);
//        java.lang.Comparable comparable26 = timePeriodValues1.getKey();
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Value" + "'", str8.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560452399999L + "'", long14 == 1560452399999L);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//        org.junit.Assert.assertTrue("'" + comparable26 + "' != '" + (short) 100 + "'", comparable26.equals((short) 100));
//    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        timePeriodValues1.setNotify(true);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener10);
        int int12 = timePeriodValues1.getMaxEndIndex();
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener13);
        boolean boolean15 = timePeriodValues1.isEmpty();
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        int int11 = timePeriodValues1.getMaxMiddleIndex();
        int int12 = timePeriodValues1.getMaxEndIndex();
        java.lang.Comparable comparable13 = null;
        try {
            timePeriodValues1.setKey(comparable13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        timePeriodValues1.setNotify(true);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year10, (java.lang.Number) 100);
        timePeriodValue13.setValue((java.lang.Number) 3);
        org.jfree.data.time.TimePeriod timePeriod16 = timePeriodValue13.getPeriod();
        timePeriodValues1.add(timePeriodValue13);
        boolean boolean18 = timePeriodValues1.getNotify();
        int int19 = timePeriodValues1.getItemCount();
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
        org.junit.Assert.assertNotNull(timePeriod16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
    }

//    @Test
//    public void test266() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test266");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        timePeriodValues1.setNotify(true);
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
//        int int6 = timePeriodValues1.getItemCount();
//        int int7 = timePeriodValues1.getMaxMiddleIndex();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
//        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 2019L);
//        java.util.Date date13 = year8.getEnd();
//        long long14 = year8.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass15 = year8.getClass();
//        java.lang.Class class16 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass15);
//        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass15);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        java.lang.String str19 = day18.toString();
//        java.util.Date date20 = day18.getStart();
//        java.lang.Class class21 = null;
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate23 = day22.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day22.next();
//        java.util.Date date25 = day22.getEnd();
//        org.jfree.data.time.TimePeriodValues timePeriodValues27 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener28 = null;
//        timePeriodValues27.addChangeListener(seriesChangeListener28);
//        int int30 = timePeriodValues27.getMinMiddleIndex();
//        java.lang.Class<?> wildcardClass31 = timePeriodValues27.getClass();
//        java.util.Date date32 = null;
//        java.util.TimeZone timeZone33 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass31, date32, timeZone33);
//        org.jfree.data.time.TimePeriodValues timePeriodValues36 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        timePeriodValues36.setNotify(true);
//        java.beans.PropertyChangeListener propertyChangeListener39 = null;
//        timePeriodValues36.removePropertyChangeListener(propertyChangeListener39);
//        int int41 = timePeriodValues36.getItemCount();
//        int int42 = timePeriodValues36.getMaxMiddleIndex();
//        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year();
//        timePeriodValues36.add((org.jfree.data.time.TimePeriod) year43, (double) 6);
//        org.jfree.data.time.TimePeriodValue timePeriodValue47 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year43, (java.lang.Number) 2019L);
//        java.util.Date date48 = year43.getEnd();
//        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass31, date48, timeZone49);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance(class21, date25, timeZone49);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = org.jfree.data.time.RegularTimePeriod.createInstance(class17, date20, timeZone49);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1562097599999L + "'", long14 == 1562097599999L);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertNotNull(class16);
//        org.junit.Assert.assertNotNull(class17);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "13-June-2019" + "'", str19.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertNull(regularTimePeriod34);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertNotNull(timeZone49);
//        org.junit.Assert.assertNull(regularTimePeriod50);
//        org.junit.Assert.assertNull(regularTimePeriod51);
//        org.junit.Assert.assertNotNull(regularTimePeriod52);
//    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year8.previous();
        java.util.Date date14 = year8.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year8.previous();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
    }

//    @Test
//    public void test268() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test268");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        int int2 = day0.getMonth();
//        java.lang.String str3 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.next();
//        int int5 = day0.getYear();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener13);
        int int15 = timePeriodValues10.getItemCount();
        int int16 = timePeriodValues10.getMaxMiddleIndex();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) year17, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 2019L);
        java.util.Date date22 = year17.getEnd();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date22, timeZone23);
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues26.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timePeriodValues26.removePropertyChangeListener(propertyChangeListener29);
        int int31 = timePeriodValues26.getItemCount();
        int int32 = timePeriodValues26.getMaxMiddleIndex();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        timePeriodValues26.add((org.jfree.data.time.TimePeriod) year33, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue37 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year33, (java.lang.Number) 2019L);
        java.util.Date date38 = year33.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(date22, date38);
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year(date22);
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date22);
        java.lang.String str42 = day41.toString();
        int int43 = day41.getMonth();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "31-December-2019" + "'", str42.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 12 + "'", int43 == 12);
    }

//    @Test
//    public void test270() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test270");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        timePeriodValues1.setNotify(true);
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
//        java.lang.String str6 = timePeriodValues1.getDescription();
//        int int7 = timePeriodValues1.getMinStartIndex();
//        int int8 = timePeriodValues1.getMaxEndIndex();
//        timePeriodValues1.setDomainDescription("");
//        java.beans.PropertyChangeListener propertyChangeListener11 = null;
//        timePeriodValues1.removePropertyChangeListener(propertyChangeListener11);
//        java.lang.String str13 = timePeriodValues1.getDomainDescription();
//        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        timePeriodValues15.setNotify(true);
//        java.beans.PropertyChangeListener propertyChangeListener18 = null;
//        timePeriodValues15.removePropertyChangeListener(propertyChangeListener18);
//        java.lang.String str20 = timePeriodValues15.getDescription();
//        int int21 = timePeriodValues15.getMinStartIndex();
//        timePeriodValues15.fireSeriesChanged();
//        boolean boolean23 = timePeriodValues1.equals((java.lang.Object) timePeriodValues15);
//        int int24 = timePeriodValues1.getMaxStartIndex();
//        int int25 = timePeriodValues1.getMaxStartIndex();
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass27 = day26.getClass();
//        long long28 = day26.getLastMillisecond();
//        long long29 = day26.getMiddleMillisecond();
//        timePeriodValues1.setKey((java.lang.Comparable) day26);
//        long long31 = day26.getSerialIndex();
//        long long32 = day26.getSerialIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues34 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        timePeriodValues34.setNotify(true);
//        java.beans.PropertyChangeListener propertyChangeListener37 = null;
//        timePeriodValues34.removePropertyChangeListener(propertyChangeListener37);
//        int int39 = timePeriodValues34.getItemCount();
//        int int40 = timePeriodValues34.getMaxMiddleIndex();
//        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
//        timePeriodValues34.add((org.jfree.data.time.TimePeriod) year41, (double) 6);
//        org.jfree.data.time.TimePeriodValue timePeriodValue45 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year41, (java.lang.Number) 2019L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = year41.previous();
//        java.lang.String str47 = year41.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = year41.next();
//        java.lang.Number number49 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue50 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod48, number49);
//        int int51 = day26.compareTo((java.lang.Object) regularTimePeriod48);
//        java.util.Date date52 = day26.getStart();
//        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year(date52);
//        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day(date52);
//        org.junit.Assert.assertNull(str6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertNull(str20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass27);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560495599999L + "'", long28 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560452399999L + "'", long29 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 43629L + "'", long31 == 43629L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 43629L + "'", long32 == 43629L);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "2019" + "'", str47.equals("2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod48);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
//        org.junit.Assert.assertNotNull(date52);
//    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener11);
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues14.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timePeriodValues14.removePropertyChangeListener(propertyChangeListener17);
        int int19 = timePeriodValues14.getItemCount();
        int int20 = timePeriodValues14.getMaxMiddleIndex();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        timePeriodValues14.add((org.jfree.data.time.TimePeriod) year21, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue25 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year21, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year21.previous();
        java.util.Date date27 = year21.getEnd();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year21, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimePeriodValue timePeriodValue31 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year21, (double) (short) 100);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(date27);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(1, (int) ' ', 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        int int11 = timePeriodValues1.getMaxEndIndex();
        int int12 = timePeriodValues1.getMaxEndIndex();
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("Value");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        java.lang.Throwable[] throwableArray8 = timePeriodFormatException6.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
        timePeriodFormatException14.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        timePeriodFormatException12.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        java.lang.String str21 = timePeriodFormatException10.toString();
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesChangeEvent[source=0]" + "'", str21.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesChangeEvent[source=0]"));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues3.setNotify(true);
        boolean boolean7 = timePeriodValues3.equals((java.lang.Object) (short) 0);
        boolean boolean8 = year0.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        timePeriodValues10.setKey((java.lang.Comparable) 100L);
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues16.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timePeriodValues16.removePropertyChangeListener(propertyChangeListener19);
        int int21 = timePeriodValues16.getItemCount();
        int int22 = timePeriodValues16.getMaxMiddleIndex();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        timePeriodValues16.add((org.jfree.data.time.TimePeriod) year23, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue27 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year23, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year23.previous();
        timePeriodValues10.setKey((java.lang.Comparable) year23);
        int int30 = year0.compareTo((java.lang.Object) year23);
        int int31 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = year0.next();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2019 + "'", int31 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener11);
        java.lang.String str13 = timePeriodValues1.getDomainDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues15.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timePeriodValues15.removePropertyChangeListener(propertyChangeListener18);
        java.lang.String str20 = timePeriodValues15.getDescription();
        int int21 = timePeriodValues15.getMinStartIndex();
        timePeriodValues15.fireSeriesChanged();
        boolean boolean23 = timePeriodValues1.equals((java.lang.Object) timePeriodValues15);
        int int24 = timePeriodValues1.getMaxStartIndex();
        timePeriodValues1.setRangeDescription("TimePeriodValue[2019,100.0]");
        boolean boolean27 = timePeriodValues1.getNotify();
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        int int11 = timePeriodValues1.getItemCount();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues13.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues13.removePropertyChangeListener(propertyChangeListener16);
        int int18 = timePeriodValues13.getItemCount();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        long long20 = year19.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue22 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year19, (java.lang.Number) 100);
        java.lang.Object obj23 = timePeriodValue22.clone();
        timePeriodValues13.add(timePeriodValue22);
        java.lang.String str25 = timePeriodValue22.toString();
        java.lang.Object obj26 = timePeriodValue22.clone();
        timePeriodValues1.add(timePeriodValue22);
        timePeriodValue22.setValue((java.lang.Number) 10.0f);
        timePeriodValue22.setValue((java.lang.Number) 1593676799999L);
        org.jfree.data.time.TimePeriodValues timePeriodValues33 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues33.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener36 = null;
        timePeriodValues33.removePropertyChangeListener(propertyChangeListener36);
        java.lang.String str38 = timePeriodValues33.getDescription();
        int int39 = timePeriodValues33.getMinStartIndex();
        int int40 = timePeriodValues33.getMaxEndIndex();
        timePeriodValues33.setDomainDescription("");
        int int43 = timePeriodValues33.getMaxEndIndex();
        java.lang.String str44 = timePeriodValues33.getRangeDescription();
        boolean boolean45 = timePeriodValues33.isEmpty();
        boolean boolean46 = timePeriodValue22.equals((java.lang.Object) timePeriodValues33);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 2019L + "'", long20 == 2019L);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "TimePeriodValue[2019,100]" + "'", str25.equals("TimePeriodValue[2019,100]"));
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "Value" + "'", str44.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 2019L);
        java.util.Date date13 = year8.getEnd();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date13);
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date13, timeZone15);
        long long17 = day16.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day16.next();
        org.jfree.data.time.SerialDate serialDate19 = day16.getSerialDate();
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day16, (java.lang.Number) 8.0d);
        long long22 = day16.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 43830L + "'", long17 == 43830L);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1577865599999L + "'", long22 == 1577865599999L);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        int int8 = timePeriodValues1.getItemCount();
        java.lang.String str9 = timePeriodValues1.getRangeDescription();
        int int10 = timePeriodValues1.getMaxMiddleIndex();
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Value" + "'", str9.equals("Value"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener7);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timePeriodValues10.addChangeListener(seriesChangeListener11);
        int int13 = timePeriodValues10.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass14 = timePeriodValues10.getClass();
        java.util.Date date15 = null;
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass14, date15, timeZone16);
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues19.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timePeriodValues19.removePropertyChangeListener(propertyChangeListener22);
        int int24 = timePeriodValues19.getItemCount();
        int int25 = timePeriodValues19.getMaxMiddleIndex();
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        timePeriodValues19.add((org.jfree.data.time.TimePeriod) year26, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue30 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year26, (java.lang.Number) 2019L);
        java.util.Date date31 = year26.getEnd();
        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass14, date31, timeZone32);
        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues35.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener38 = null;
        timePeriodValues35.removePropertyChangeListener(propertyChangeListener38);
        int int40 = timePeriodValues35.getItemCount();
        int int41 = timePeriodValues35.getMaxMiddleIndex();
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
        timePeriodValues35.add((org.jfree.data.time.TimePeriod) year42, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue46 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year42, (java.lang.Number) 2019L);
        java.util.Date date47 = year42.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod48 = new org.jfree.data.time.SimpleTimePeriod(date31, date47);
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year(date31, timeZone49);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = year50.previous();
        timePeriodValues1.setKey((java.lang.Comparable) regularTimePeriod51);
        java.lang.Comparable comparable53 = timePeriodValues1.getKey();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNotNull(regularTimePeriod51);
        org.junit.Assert.assertNotNull(comparable53);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("TimePeriodValue[13-June-2019,8.0]");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        java.lang.String str12 = timePeriodFormatException6.toString();
        java.lang.Throwable throwable13 = null;
        try {
            timePeriodFormatException6.addSuppressed(throwable13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesChangeEvent[source=0]" + "'", str12.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesChangeEvent[source=0]"));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener11);
        java.lang.String str13 = timePeriodValues1.getDomainDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener14);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener16 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener16);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year8.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year8.previous();
        java.lang.Object obj15 = null;
        int int16 = year8.compareTo(obj15);
        long long17 = year8.getSerialIndex();
        int int18 = year8.getYear();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2019L + "'", long17 == 2019L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
        timePeriodFormatException9.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
        timePeriodFormatException14.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("Value");
        timePeriodFormatException16.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
        timePeriodFormatException9.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException23 = new org.jfree.data.time.TimePeriodFormatException("2019");
        timePeriodFormatException19.addSuppressed((java.lang.Throwable) timePeriodFormatException23);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException27 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException29 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException31 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException33 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
        timePeriodFormatException31.addSuppressed((java.lang.Throwable) timePeriodFormatException33);
        timePeriodFormatException29.addSuppressed((java.lang.Throwable) timePeriodFormatException31);
        timePeriodFormatException27.addSuppressed((java.lang.Throwable) timePeriodFormatException31);
        timePeriodFormatException19.addSuppressed((java.lang.Throwable) timePeriodFormatException27);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        boolean boolean5 = timePeriodValues1.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year6, (java.lang.Number) 100);
        java.lang.Object obj10 = timePeriodValue9.clone();
        java.lang.String str11 = timePeriodValue9.toString();
        boolean boolean13 = timePeriodValue9.equals((java.lang.Object) 100);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        boolean boolean15 = timePeriodValue9.equals((java.lang.Object) day14);
        timePeriodValues1.add(timePeriodValue9);
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener17);
        timePeriodValues1.setRangeDescription("TimePeriodValue[13-June-2019,8.0]");
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues22.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener25 = null;
        timePeriodValues22.removePropertyChangeListener(propertyChangeListener25);
        java.lang.String str27 = timePeriodValues22.getDescription();
        int int28 = timePeriodValues22.getMinStartIndex();
        timePeriodValues22.setNotify(true);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        long long32 = year31.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue34 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year31, (java.lang.Number) 100);
        timePeriodValue34.setValue((java.lang.Number) 3);
        org.jfree.data.time.TimePeriod timePeriod37 = timePeriodValue34.getPeriod();
        timePeriodValues22.add(timePeriodValue34);
        org.jfree.data.time.TimePeriodValues timePeriodValues40 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues40.setNotify(true);
        timePeriodValues40.setKey((java.lang.Comparable) 100L);
        timePeriodValues40.setKey((java.lang.Comparable) (short) 100);
        java.lang.String str47 = timePeriodValues40.getRangeDescription();
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year();
        long long49 = year48.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue51 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year48, (java.lang.Number) 100);
        timePeriodValues40.add(timePeriodValue51);
        boolean boolean53 = timePeriodValue34.equals((java.lang.Object) timePeriodValues40);
        java.lang.String str54 = timePeriodValue34.toString();
        org.jfree.data.time.TimePeriodValues timePeriodValues56 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues56.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener59 = null;
        timePeriodValues56.removePropertyChangeListener(propertyChangeListener59);
        java.lang.String str61 = timePeriodValues56.getDescription();
        int int62 = timePeriodValues56.getMinStartIndex();
        int int63 = timePeriodValues56.getMaxEndIndex();
        timePeriodValues56.setDomainDescription("");
        int int66 = timePeriodValues56.getMaxEndIndex();
        boolean boolean68 = timePeriodValues56.equals((java.lang.Object) (-1L));
        boolean boolean69 = timePeriodValue34.equals((java.lang.Object) timePeriodValues56);
        timePeriodValues1.add(timePeriodValue34);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "TimePeriodValue[2019,100]" + "'", str11.equals("TimePeriodValue[2019,100]"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 2019L + "'", long32 == 2019L);
        org.junit.Assert.assertNotNull(timePeriod37);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "Value" + "'", str47.equals("Value"));
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 2019L + "'", long49 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "TimePeriodValue[2019,3]" + "'", str54.equals("TimePeriodValue[2019,3]"));
        org.junit.Assert.assertNull(str61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-1) + "'", int62 == (-1));
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-1) + "'", int63 == (-1));
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + (-1) + "'", int66 == (-1));
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Value");
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year11, (java.lang.Number) 100);
        timePeriodValues1.add(timePeriodValue14);
        java.lang.String str16 = timePeriodValues1.getDescription();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 100);
        java.util.Date date21 = year17.getStart();
        org.jfree.data.time.TimePeriodValue timePeriodValue23 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) (short) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues25.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener28 = null;
        timePeriodValues25.removePropertyChangeListener(propertyChangeListener28);
        java.lang.String str30 = timePeriodValues25.getDescription();
        boolean boolean31 = year17.equals((java.lang.Object) timePeriodValues25);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 43629L);
        java.beans.PropertyChangeListener propertyChangeListener34 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener34);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2019L + "'", long12 == 2019L);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2019L + "'", long18 == 2019L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues3.setNotify(true);
        boolean boolean7 = timePeriodValues3.equals((java.lang.Object) (short) 0);
        boolean boolean8 = year0.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        timePeriodValues10.setKey((java.lang.Comparable) 100L);
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues16.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timePeriodValues16.removePropertyChangeListener(propertyChangeListener19);
        int int21 = timePeriodValues16.getItemCount();
        int int22 = timePeriodValues16.getMaxMiddleIndex();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        timePeriodValues16.add((org.jfree.data.time.TimePeriod) year23, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue27 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year23, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year23.previous();
        timePeriodValues10.setKey((java.lang.Comparable) year23);
        int int30 = year0.compareTo((java.lang.Object) year23);
        java.lang.String str31 = year0.toString();
        int int32 = year0.getYear();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "2019" + "'", str31.equals("2019"));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2019 + "'", int32 == 2019);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year8.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year8.previous();
        java.lang.Object obj15 = null;
        int int16 = year8.compareTo(obj15);
        java.lang.Number number17 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue18 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, number17);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        long long20 = year19.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue22 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year19, (java.lang.Number) 100);
        java.util.Date date23 = year19.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener26 = null;
        timePeriodValues25.addChangeListener(seriesChangeListener26);
        int int28 = timePeriodValues25.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass29 = timePeriodValues25.getClass();
        java.util.Date date30 = null;
        java.util.TimeZone timeZone31 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass29, date30, timeZone31);
        org.jfree.data.time.TimePeriodValues timePeriodValues34 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues34.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener37 = null;
        timePeriodValues34.removePropertyChangeListener(propertyChangeListener37);
        int int39 = timePeriodValues34.getItemCount();
        int int40 = timePeriodValues34.getMaxMiddleIndex();
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
        timePeriodValues34.add((org.jfree.data.time.TimePeriod) year41, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue45 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year41, (java.lang.Number) 2019L);
        java.util.Date date46 = year41.getEnd();
        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass29, date46, timeZone47);
        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year(date23, timeZone47);
        org.jfree.data.time.TimePeriodValues timePeriodValues51 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener52 = null;
        timePeriodValues51.addChangeListener(seriesChangeListener52);
        int int54 = timePeriodValues51.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass55 = timePeriodValues51.getClass();
        java.util.Date date56 = null;
        java.util.TimeZone timeZone57 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass55, date56, timeZone57);
        org.jfree.data.time.TimePeriodValues timePeriodValues60 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues60.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener63 = null;
        timePeriodValues60.removePropertyChangeListener(propertyChangeListener63);
        int int65 = timePeriodValues60.getItemCount();
        int int66 = timePeriodValues60.getMaxMiddleIndex();
        org.jfree.data.time.Year year67 = new org.jfree.data.time.Year();
        timePeriodValues60.add((org.jfree.data.time.TimePeriod) year67, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue71 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year67, (java.lang.Number) 2019L);
        java.util.Date date72 = year67.getEnd();
        java.util.TimeZone timeZone73 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass55, date72, timeZone73);
        org.jfree.data.time.Year year75 = new org.jfree.data.time.Year(date23, timeZone73);
        boolean boolean76 = timePeriodValue18.equals((java.lang.Object) date23);
        org.jfree.data.time.Day day77 = new org.jfree.data.time.Day(date23);
        org.jfree.data.time.TimePeriodValues timePeriodValues79 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues79.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener82 = null;
        timePeriodValues79.removePropertyChangeListener(propertyChangeListener82);
        int int84 = timePeriodValues79.getItemCount();
        int int85 = timePeriodValues79.getMaxMiddleIndex();
        org.jfree.data.time.Year year86 = new org.jfree.data.time.Year();
        timePeriodValues79.add((org.jfree.data.time.TimePeriod) year86, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue90 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year86, (java.lang.Number) 2019L);
        java.util.Date date91 = year86.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod92 = new org.jfree.data.time.SimpleTimePeriod(date23, date91);
        java.util.Date date93 = simpleTimePeriod92.getStart();
        java.util.Date date94 = simpleTimePeriod92.getEnd();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 2019L + "'", long20 == 2019L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertNull(regularTimePeriod32);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(timeZone47);
        org.junit.Assert.assertNull(regularTimePeriod48);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1) + "'", int54 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass55);
        org.junit.Assert.assertNull(regularTimePeriod58);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + (-1) + "'", int66 == (-1));
        org.junit.Assert.assertNotNull(date72);
        org.junit.Assert.assertNotNull(timeZone73);
        org.junit.Assert.assertNull(regularTimePeriod74);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 0 + "'", int84 == 0);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + (-1) + "'", int85 == (-1));
        org.junit.Assert.assertNotNull(date91);
        org.junit.Assert.assertNotNull(date93);
        org.junit.Assert.assertNotNull(date94);
    }

//    @Test
//    public void test290() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test290");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getSerialIndex();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 100);
//        java.util.Date date4 = year0.getStart();
//        java.lang.String str5 = year0.toString();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        int int7 = day6.getMonth();
//        long long8 = day6.getMiddleMillisecond();
//        org.jfree.data.time.SerialDate serialDate9 = day6.getSerialDate();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate11 = day10.getSerialDate();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(serialDate11);
//        boolean boolean13 = day6.equals((java.lang.Object) serialDate11);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(serialDate11);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate11);
//        boolean boolean16 = year0.equals((java.lang.Object) day15);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560452399999L + "'", long8 == 1560452399999L);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues1.createCopy(0, 0);
        int int10 = timePeriodValues9.getMaxStartIndex();
        timePeriodValues9.setDescription("TimePeriodValue[13-June-2019,8.0]");
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(timePeriodValues9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

//    @Test
//    public void test292() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test292");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass1 = day0.getClass();
//        long long2 = day0.getLastMillisecond();
//        java.lang.String str3 = day0.toString();
//        long long4 = day0.getFirstMillisecond();
//        java.lang.String str5 = day0.toString();
//        java.lang.Object obj6 = null;
//        boolean boolean7 = day0.equals(obj6);
//        org.jfree.data.time.SerialDate serialDate8 = day0.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate9 = day0.getSerialDate();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(serialDate9);
//        org.junit.Assert.assertNotNull(wildcardClass1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560495599999L + "'", long2 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "13-June-2019" + "'", str5.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(serialDate9);
//    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue7 = timePeriodValues1.getDataItem(12);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 12, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

//    @Test
//    public void test294() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test294");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        timePeriodValues1.setNotify(true);
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
//        java.lang.String str6 = timePeriodValues1.getDescription();
//        int int7 = timePeriodValues1.getMinStartIndex();
//        int int8 = timePeriodValues1.getMaxEndIndex();
//        timePeriodValues1.setDomainDescription("");
//        java.beans.PropertyChangeListener propertyChangeListener11 = null;
//        timePeriodValues1.removePropertyChangeListener(propertyChangeListener11);
//        java.lang.String str13 = timePeriodValues1.getDomainDescription();
//        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        timePeriodValues15.setNotify(true);
//        java.beans.PropertyChangeListener propertyChangeListener18 = null;
//        timePeriodValues15.removePropertyChangeListener(propertyChangeListener18);
//        java.lang.String str20 = timePeriodValues15.getDescription();
//        int int21 = timePeriodValues15.getMinStartIndex();
//        timePeriodValues15.fireSeriesChanged();
//        boolean boolean23 = timePeriodValues1.equals((java.lang.Object) timePeriodValues15);
//        int int24 = timePeriodValues1.getMaxStartIndex();
//        int int25 = timePeriodValues1.getMaxStartIndex();
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass27 = day26.getClass();
//        long long28 = day26.getLastMillisecond();
//        long long29 = day26.getMiddleMillisecond();
//        timePeriodValues1.setKey((java.lang.Comparable) day26);
//        java.lang.String str31 = timePeriodValues1.getDomainDescription();
//        int int32 = timePeriodValues1.getMinMiddleIndex();
//        timePeriodValues1.setNotify(true);
//        org.junit.Assert.assertNull(str6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertNull(str20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass27);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560495599999L + "'", long28 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560452399999L + "'", long29 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "" + "'", str31.equals(""));
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
//    }

//    @Test
//    public void test295() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test295");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        timePeriodValues1.setNotify(true);
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
//        int int6 = timePeriodValues1.getItemCount();
//        int int7 = timePeriodValues1.getMaxMiddleIndex();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
//        int int11 = timePeriodValues1.getMinMiddleIndex();
//        int int12 = timePeriodValues1.getMinStartIndex();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass14 = day13.getClass();
//        long long15 = day13.getLastMillisecond();
//        long long16 = day13.getSerialIndex();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day13, (double) '4');
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560495599999L + "'", long15 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 43629L + "'", long16 == 43629L);
//    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) ' ');
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timePeriodValues4.addChangeListener(seriesChangeListener5);
        int int7 = timePeriodValues4.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass8 = timePeriodValues4.getClass();
        boolean boolean9 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValues4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 100);
        java.util.Date date4 = year0.getStart();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 1560452399999L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) ' ');
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (java.lang.Number) 6);
        java.util.Date date5 = simpleTimePeriod2.getStart();
        org.junit.Assert.assertNotNull(date5);
    }

//    @Test
//    public void test299() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test299");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        timePeriodValues1.setNotify(true);
//        timePeriodValues1.setKey((java.lang.Comparable) 100L);
//        timePeriodValues1.setKey((java.lang.Comparable) (short) 100);
//        java.lang.String str8 = timePeriodValues1.getRangeDescription();
//        int int9 = timePeriodValues1.getMinStartIndex();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
//        timePeriodValues1.removeChangeListener(seriesChangeListener10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        int int13 = day12.getMonth();
//        long long14 = day12.getMiddleMillisecond();
//        org.jfree.data.time.SerialDate serialDate15 = day12.getSerialDate();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate17 = day16.getSerialDate();
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(serialDate17);
//        boolean boolean19 = day12.equals((java.lang.Object) serialDate17);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(serialDate17);
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day20, (java.lang.Number) 0);
//        int int23 = timePeriodValues1.getMinStartIndex();
//        java.beans.PropertyChangeListener propertyChangeListener24 = null;
//        timePeriodValues1.addPropertyChangeListener(propertyChangeListener24);
//        java.lang.Class<?> wildcardClass26 = timePeriodValues1.getClass();
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Value" + "'", str8.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560452399999L + "'", long14 == 1560452399999L);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues3.setNotify(true);
        boolean boolean7 = timePeriodValues3.equals((java.lang.Object) (short) 0);
        boolean boolean8 = year0.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        timePeriodValues10.setKey((java.lang.Comparable) 100L);
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues16.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timePeriodValues16.removePropertyChangeListener(propertyChangeListener19);
        int int21 = timePeriodValues16.getItemCount();
        int int22 = timePeriodValues16.getMaxMiddleIndex();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        timePeriodValues16.add((org.jfree.data.time.TimePeriod) year23, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue27 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year23, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year23.previous();
        timePeriodValues10.setKey((java.lang.Comparable) year23);
        int int30 = year0.compareTo((java.lang.Object) year23);
        java.lang.String str31 = year0.toString();
        long long32 = year0.getSerialIndex();
        long long33 = year0.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "2019" + "'", str31.equals("2019"));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 2019L + "'", long32 == 2019L);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 2019L + "'", long33 == 2019L);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(5, 5, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(1L, (long) 1);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass4 = day3.getClass();
        int int5 = day3.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day3, (double) 8);
        boolean boolean8 = simpleTimePeriod2.equals((java.lang.Object) 8);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year11, (java.lang.Number) 100);
        timePeriodValues1.add(timePeriodValue14);
        java.lang.String str16 = timePeriodValues1.getDescription();
        int int17 = timePeriodValues1.getMinMiddleIndex();
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2019L + "'", long12 == 2019L);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

//    @Test
//    public void test304() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test304");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        int int2 = day0.getMonth();
//        java.lang.String str3 = day0.toString();
//        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0, "TimePeriodValue[2019,3]", "TimePeriodValue[2019,3]");
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass1 = day0.getClass();
        int int2 = day0.getMonth();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues4.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues4.removePropertyChangeListener(propertyChangeListener7);
        java.lang.String str9 = timePeriodValues4.getDescription();
        int int10 = timePeriodValues4.getMinStartIndex();
        int int11 = timePeriodValues4.getMaxEndIndex();
        timePeriodValues4.setDomainDescription("");
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timePeriodValues4.removePropertyChangeListener(propertyChangeListener14);
        java.lang.String str16 = timePeriodValues4.getDomainDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues18.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timePeriodValues18.removePropertyChangeListener(propertyChangeListener21);
        java.lang.String str23 = timePeriodValues18.getDescription();
        int int24 = timePeriodValues18.getMinStartIndex();
        timePeriodValues18.fireSeriesChanged();
        boolean boolean26 = timePeriodValues4.equals((java.lang.Object) timePeriodValues18);
        java.beans.PropertyChangeListener propertyChangeListener27 = null;
        timePeriodValues18.addPropertyChangeListener(propertyChangeListener27);
        boolean boolean29 = day0.equals((java.lang.Object) timePeriodValues18);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        int int11 = timePeriodValues1.getMaxEndIndex();
        java.lang.String str12 = timePeriodValues1.getRangeDescription();
        timePeriodValues1.setKey((java.lang.Comparable) 7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener15);
        timePeriodValues1.setRangeDescription("");
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener21 = null;
        timePeriodValues20.addChangeListener(seriesChangeListener21);
        int int23 = timePeriodValues20.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass24 = timePeriodValues20.getClass();
        java.util.Date date25 = null;
        java.util.TimeZone timeZone26 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date25, timeZone26);
        org.jfree.data.time.TimePeriodValues timePeriodValues29 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues29.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener32 = null;
        timePeriodValues29.removePropertyChangeListener(propertyChangeListener32);
        int int34 = timePeriodValues29.getItemCount();
        int int35 = timePeriodValues29.getMaxMiddleIndex();
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        timePeriodValues29.add((org.jfree.data.time.TimePeriod) year36, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue40 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year36, (java.lang.Number) 2019L);
        java.util.Date date41 = year36.getEnd();
        java.util.TimeZone timeZone42 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date41, timeZone42);
        org.jfree.data.time.TimePeriodValues timePeriodValues45 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues45.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener48 = null;
        timePeriodValues45.removePropertyChangeListener(propertyChangeListener48);
        int int50 = timePeriodValues45.getItemCount();
        int int51 = timePeriodValues45.getMaxMiddleIndex();
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year();
        timePeriodValues45.add((org.jfree.data.time.TimePeriod) year52, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue56 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year52, (java.lang.Number) 2019L);
        java.util.Date date57 = year52.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod58 = new org.jfree.data.time.SimpleTimePeriod(date41, date57);
        long long59 = simpleTimePeriod58.getEndMillis();
        long long60 = simpleTimePeriod58.getStartMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues62 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues62.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener65 = null;
        timePeriodValues62.removePropertyChangeListener(propertyChangeListener65);
        int int67 = timePeriodValues62.getItemCount();
        int int68 = timePeriodValues62.getMaxMiddleIndex();
        org.jfree.data.time.Year year69 = new org.jfree.data.time.Year();
        timePeriodValues62.add((org.jfree.data.time.TimePeriod) year69, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue73 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year69, (java.lang.Number) 2019L);
        java.util.Date date74 = year69.getEnd();
        long long75 = year69.getFirstMillisecond();
        boolean boolean76 = simpleTimePeriod58.equals((java.lang.Object) long75);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod58, (java.lang.Number) 10);
        java.lang.Object obj79 = timePeriodValues1.clone();
        int int80 = timePeriodValues1.getMinMiddleIndex();
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Value" + "'", str12.equals("Value"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(timeZone42);
        org.junit.Assert.assertNull(regularTimePeriod43);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1) + "'", int51 == (-1));
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 1577865599999L + "'", long59 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1577865599999L + "'", long60 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + (-1) + "'", int68 == (-1));
        org.junit.Assert.assertNotNull(date74);
        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 1546329600000L + "'", long75 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(obj79);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 0 + "'", int80 == 0);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        timePeriodValues1.setNotify(true);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener10);
        timePeriodValues1.setRangeDescription("31-December-2019");
        int int14 = timePeriodValues1.getItemCount();
        int int15 = timePeriodValues1.getMinEndIndex();
        int int16 = timePeriodValues1.getItemCount();
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener13);
        int int15 = timePeriodValues10.getItemCount();
        int int16 = timePeriodValues10.getMaxMiddleIndex();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) year17, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 2019L);
        java.util.Date date22 = year17.getEnd();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date22, timeZone23);
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues26.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timePeriodValues26.removePropertyChangeListener(propertyChangeListener29);
        int int31 = timePeriodValues26.getItemCount();
        int int32 = timePeriodValues26.getMaxMiddleIndex();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        timePeriodValues26.add((org.jfree.data.time.TimePeriod) year33, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue37 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year33, (java.lang.Number) 2019L);
        java.util.Date date38 = year33.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(date22, date38);
        long long40 = simpleTimePeriod39.getEndMillis();
        long long41 = simpleTimePeriod39.getStartMillis();
        boolean boolean43 = simpleTimePeriod39.equals((java.lang.Object) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues45 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener46 = null;
        timePeriodValues45.addChangeListener(seriesChangeListener46);
        int int48 = timePeriodValues45.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass49 = timePeriodValues45.getClass();
        java.util.Date date50 = null;
        java.util.TimeZone timeZone51 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass49, date50, timeZone51);
        org.jfree.data.time.TimePeriodValues timePeriodValues54 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues54.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener57 = null;
        timePeriodValues54.removePropertyChangeListener(propertyChangeListener57);
        int int59 = timePeriodValues54.getItemCount();
        int int60 = timePeriodValues54.getMaxMiddleIndex();
        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year();
        timePeriodValues54.add((org.jfree.data.time.TimePeriod) year61, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue65 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year61, (java.lang.Number) 2019L);
        java.util.Date date66 = year61.getEnd();
        java.util.TimeZone timeZone67 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass49, date66, timeZone67);
        org.jfree.data.time.TimePeriodValues timePeriodValues70 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues70.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener73 = null;
        timePeriodValues70.removePropertyChangeListener(propertyChangeListener73);
        int int75 = timePeriodValues70.getItemCount();
        int int76 = timePeriodValues70.getMaxMiddleIndex();
        org.jfree.data.time.Year year77 = new org.jfree.data.time.Year();
        timePeriodValues70.add((org.jfree.data.time.TimePeriod) year77, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue81 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year77, (java.lang.Number) 2019L);
        java.util.Date date82 = year77.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod83 = new org.jfree.data.time.SimpleTimePeriod(date66, date82);
        long long84 = simpleTimePeriod83.getEndMillis();
        long long85 = simpleTimePeriod83.getStartMillis();
        boolean boolean87 = simpleTimePeriod83.equals((java.lang.Object) 0);
        java.util.Date date88 = simpleTimePeriod83.getStart();
        boolean boolean89 = simpleTimePeriod39.equals((java.lang.Object) simpleTimePeriod83);
        org.jfree.data.time.TimePeriodValues timePeriodValues91 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener92 = null;
        timePeriodValues91.addChangeListener(seriesChangeListener92);
        int int94 = timePeriodValues91.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass95 = timePeriodValues91.getClass();
        boolean boolean96 = simpleTimePeriod39.equals((java.lang.Object) timePeriodValues91);
        java.lang.String str97 = timePeriodValues91.getRangeDescription();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1577865599999L + "'", long40 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1577865599999L + "'", long41 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass49);
        org.junit.Assert.assertNull(regularTimePeriod52);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1) + "'", int60 == (-1));
        org.junit.Assert.assertNotNull(date66);
        org.junit.Assert.assertNotNull(timeZone67);
        org.junit.Assert.assertNull(regularTimePeriod68);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 0 + "'", int75 == 0);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + (-1) + "'", int76 == (-1));
        org.junit.Assert.assertNotNull(date82);
        org.junit.Assert.assertTrue("'" + long84 + "' != '" + 1577865599999L + "'", long84 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long85 + "' != '" + 1577865599999L + "'", long85 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertNotNull(date88);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + true + "'", boolean89 == true);
        org.junit.Assert.assertTrue("'" + int94 + "' != '" + (-1) + "'", int94 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass95);
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + false + "'", boolean96 == false);
        org.junit.Assert.assertTrue("'" + str97 + "' != '" + "Value" + "'", str97.equals("Value"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        timePeriodFormatException9.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
        timePeriodFormatException17.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException22 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException24 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
        timePeriodFormatException22.addSuppressed((java.lang.Throwable) timePeriodFormatException24);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException27 = new org.jfree.data.time.TimePeriodFormatException("Value");
        timePeriodFormatException24.addSuppressed((java.lang.Throwable) timePeriodFormatException27);
        timePeriodFormatException17.addSuppressed((java.lang.Throwable) timePeriodFormatException27);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException31 = new org.jfree.data.time.TimePeriodFormatException("2019");
        timePeriodFormatException27.addSuppressed((java.lang.Throwable) timePeriodFormatException31);
        timePeriodFormatException9.addSuppressed((java.lang.Throwable) timePeriodFormatException27);
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        java.lang.String str35 = timePeriodFormatException3.toString();
        java.lang.Throwable[] throwableArray36 = timePeriodFormatException3.getSuppressed();
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesChangeEvent[source=0]" + "'", str35.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesChangeEvent[source=0]"));
        org.junit.Assert.assertNotNull(throwableArray36);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (byte) 100, 3, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 2019L);
        long long13 = year8.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue15 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (double) 7);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        int int2 = year0.getYear();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        long long4 = year3.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year3, (java.lang.Number) 100);
        timePeriodValue6.setValue((java.lang.Number) 3);
        org.jfree.data.time.TimePeriod timePeriod9 = timePeriodValue6.getPeriod();
        java.lang.Object obj10 = timePeriodValue6.clone();
        int int11 = year0.compareTo((java.lang.Object) timePeriodValue6);
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
        timePeriodValues13.addChangeListener(seriesChangeListener14);
        int int16 = timePeriodValues13.getMinMiddleIndex();
        int int17 = timePeriodValues13.getMinEndIndex();
        boolean boolean18 = year0.equals((java.lang.Object) int17);
        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 1593676799999L);
        org.jfree.data.time.TimePeriod timePeriod21 = timePeriodValue20.getPeriod();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertNotNull(timePeriod9);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(timePeriod21);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 100);
        java.util.Date date4 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues6.addChangeListener(seriesChangeListener7);
        int int9 = timePeriodValues6.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass10 = timePeriodValues6.getClass();
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date11, timeZone12);
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues15.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timePeriodValues15.removePropertyChangeListener(propertyChangeListener18);
        int int20 = timePeriodValues15.getItemCount();
        int int21 = timePeriodValues15.getMaxMiddleIndex();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        timePeriodValues15.add((org.jfree.data.time.TimePeriod) year22, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue26 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year22, (java.lang.Number) 2019L);
        java.util.Date date27 = year22.getEnd();
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date27, timeZone28);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(date4, timeZone28);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year30.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues33 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues33.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener36 = null;
        timePeriodValues33.removePropertyChangeListener(propertyChangeListener36);
        java.lang.String str38 = timePeriodValues33.getDescription();
        int int39 = timePeriodValues33.getMinStartIndex();
        int int40 = timePeriodValues33.getMaxEndIndex();
        timePeriodValues33.setDomainDescription("");
        java.beans.PropertyChangeListener propertyChangeListener43 = null;
        timePeriodValues33.removePropertyChangeListener(propertyChangeListener43);
        int int45 = timePeriodValues33.getMaxEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues48 = timePeriodValues33.createCopy(5, (int) '#');
        int int49 = year30.compareTo((java.lang.Object) '#');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year8.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year8.previous();
        java.lang.Object obj15 = null;
        int int16 = year8.compareTo(obj15);
        java.lang.Number number17 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue18 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, number17);
        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, 8.0d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues3.setNotify(true);
        boolean boolean7 = timePeriodValues3.equals((java.lang.Object) (short) 0);
        boolean boolean8 = year0.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        timePeriodValues10.setKey((java.lang.Comparable) 100L);
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues16.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timePeriodValues16.removePropertyChangeListener(propertyChangeListener19);
        int int21 = timePeriodValues16.getItemCount();
        int int22 = timePeriodValues16.getMaxMiddleIndex();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        timePeriodValues16.add((org.jfree.data.time.TimePeriod) year23, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue27 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year23, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year23.previous();
        timePeriodValues10.setKey((java.lang.Comparable) year23);
        int int30 = year0.compareTo((java.lang.Object) year23);
        int int31 = year23.getYear();
        int int33 = year23.compareTo((java.lang.Object) (short) 10);
        java.lang.String str34 = year23.toString();
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
        long long36 = year35.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue38 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year35, (java.lang.Number) 100);
        java.util.Date date39 = year35.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues41 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener42 = null;
        timePeriodValues41.addChangeListener(seriesChangeListener42);
        int int44 = timePeriodValues41.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass45 = timePeriodValues41.getClass();
        java.util.Date date46 = null;
        java.util.TimeZone timeZone47 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass45, date46, timeZone47);
        org.jfree.data.time.TimePeriodValues timePeriodValues50 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues50.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener53 = null;
        timePeriodValues50.removePropertyChangeListener(propertyChangeListener53);
        int int55 = timePeriodValues50.getItemCount();
        int int56 = timePeriodValues50.getMaxMiddleIndex();
        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year();
        timePeriodValues50.add((org.jfree.data.time.TimePeriod) year57, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue61 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year57, (java.lang.Number) 2019L);
        java.util.Date date62 = year57.getEnd();
        java.util.TimeZone timeZone63 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass45, date62, timeZone63);
        org.jfree.data.time.Year year65 = new org.jfree.data.time.Year(date39, timeZone63);
        org.jfree.data.time.TimePeriodValues timePeriodValues67 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener68 = null;
        timePeriodValues67.addChangeListener(seriesChangeListener68);
        int int70 = timePeriodValues67.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass71 = timePeriodValues67.getClass();
        java.util.Date date72 = null;
        java.util.TimeZone timeZone73 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass71, date72, timeZone73);
        org.jfree.data.time.TimePeriodValues timePeriodValues76 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues76.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener79 = null;
        timePeriodValues76.removePropertyChangeListener(propertyChangeListener79);
        int int81 = timePeriodValues76.getItemCount();
        int int82 = timePeriodValues76.getMaxMiddleIndex();
        org.jfree.data.time.Year year83 = new org.jfree.data.time.Year();
        timePeriodValues76.add((org.jfree.data.time.TimePeriod) year83, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue87 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year83, (java.lang.Number) 2019L);
        java.util.Date date88 = year83.getEnd();
        java.util.TimeZone timeZone89 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod90 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass71, date88, timeZone89);
        org.jfree.data.time.Year year91 = new org.jfree.data.time.Year(date39, timeZone89);
        java.util.TimeZone timeZone92 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day93 = new org.jfree.data.time.Day(date39, timeZone92);
        int int94 = day93.getYear();
        boolean boolean95 = year23.equals((java.lang.Object) day93);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod96 = year23.next();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2019 + "'", int31 == 2019);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "2019" + "'", str34.equals("2019"));
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 2019L + "'", long36 == 2019L);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass45);
        org.junit.Assert.assertNull(regularTimePeriod48);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + (-1) + "'", int56 == (-1));
        org.junit.Assert.assertNotNull(date62);
        org.junit.Assert.assertNotNull(timeZone63);
        org.junit.Assert.assertNull(regularTimePeriod64);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + (-1) + "'", int70 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass71);
        org.junit.Assert.assertNull(regularTimePeriod74);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 0 + "'", int81 == 0);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + (-1) + "'", int82 == (-1));
        org.junit.Assert.assertNotNull(date88);
        org.junit.Assert.assertNotNull(timeZone89);
        org.junit.Assert.assertNull(regularTimePeriod90);
        org.junit.Assert.assertNotNull(timeZone92);
        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 2019 + "'", int94 == 2019);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod96);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year8.previous();
        int int14 = year8.getYear();
        java.util.Calendar calendar15 = null;
        try {
            long long16 = year8.getLastMillisecond(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        try {
            org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 2019L);
        java.util.Date date13 = year8.getEnd();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(date13);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener13);
        int int15 = timePeriodValues10.getItemCount();
        int int16 = timePeriodValues10.getMaxMiddleIndex();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) year17, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 2019L);
        java.util.Date date22 = year17.getEnd();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date22, timeZone23);
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues26.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timePeriodValues26.removePropertyChangeListener(propertyChangeListener29);
        int int31 = timePeriodValues26.getItemCount();
        int int32 = timePeriodValues26.getMaxMiddleIndex();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        timePeriodValues26.add((org.jfree.data.time.TimePeriod) year33, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue37 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year33, (java.lang.Number) 2019L);
        java.util.Date date38 = year33.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(date22, date38);
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date22);
        int int41 = day40.getMonth();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 12 + "'", int41 == 12);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 100);
        java.util.Date date4 = year0.getStart();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) (short) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues8.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues8.removePropertyChangeListener(propertyChangeListener11);
        java.lang.String str13 = timePeriodValues8.getDescription();
        boolean boolean14 = year0.equals((java.lang.Object) timePeriodValues8);
        int int15 = year0.getYear();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 0);
        java.lang.String str2 = seriesChangeEvent1.toString();
        java.lang.String str3 = seriesChangeEvent1.toString();
        java.lang.String str4 = seriesChangeEvent1.toString();
        java.lang.String str5 = seriesChangeEvent1.toString();
        java.lang.String str6 = seriesChangeEvent1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=0]" + "'", str2.equals("org.jfree.data.general.SeriesChangeEvent[source=0]"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=0]" + "'", str3.equals("org.jfree.data.general.SeriesChangeEvent[source=0]"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=0]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=0]"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=0]" + "'", str5.equals("org.jfree.data.general.SeriesChangeEvent[source=0]"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=0]" + "'", str6.equals("org.jfree.data.general.SeriesChangeEvent[source=0]"));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues1.createCopy(0, 0);
        timePeriodValues9.delete(11, (int) (byte) 1);
        int int13 = timePeriodValues9.getMinEndIndex();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(timePeriodValues9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getMinStartIndex();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues3.setNotify(true);
        boolean boolean7 = timePeriodValues3.equals((java.lang.Object) (short) 0);
        boolean boolean8 = year0.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        timePeriodValues10.setKey((java.lang.Comparable) 100L);
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues16.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timePeriodValues16.removePropertyChangeListener(propertyChangeListener19);
        int int21 = timePeriodValues16.getItemCount();
        int int22 = timePeriodValues16.getMaxMiddleIndex();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        timePeriodValues16.add((org.jfree.data.time.TimePeriod) year23, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue27 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year23, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year23.previous();
        timePeriodValues10.setKey((java.lang.Comparable) year23);
        int int30 = year0.compareTo((java.lang.Object) year23);
        java.lang.String str31 = year0.toString();
        long long32 = year0.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        java.lang.String str36 = timePeriodValues35.getDescription();
        int int37 = year0.compareTo((java.lang.Object) timePeriodValues35);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "2019" + "'", str31.equals("2019"));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 2019L + "'", long32 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 100);
        java.lang.Object obj4 = timePeriodValue3.clone();
        java.lang.String str5 = timePeriodValue3.toString();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getSerialIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues9.setNotify(true);
        boolean boolean13 = timePeriodValues9.equals((java.lang.Object) (short) 0);
        boolean boolean14 = year6.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues16.setNotify(true);
        timePeriodValues16.setKey((java.lang.Comparable) 100L);
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues22.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener25 = null;
        timePeriodValues22.removePropertyChangeListener(propertyChangeListener25);
        int int27 = timePeriodValues22.getItemCount();
        int int28 = timePeriodValues22.getMaxMiddleIndex();
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
        timePeriodValues22.add((org.jfree.data.time.TimePeriod) year29, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue33 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year29, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = year29.previous();
        timePeriodValues16.setKey((java.lang.Comparable) year29);
        int int36 = year6.compareTo((java.lang.Object) year29);
        java.lang.String str37 = year6.toString();
        java.lang.Object obj38 = null;
        boolean boolean39 = year6.equals(obj38);
        java.util.Date date40 = year6.getStart();
        boolean boolean41 = timePeriodValue3.equals((java.lang.Object) date40);
        java.util.TimeZone timeZone42 = null;
        try {
            org.jfree.data.time.Year year43 = new org.jfree.data.time.Year(date40, timeZone42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "TimePeriodValue[2019,100]" + "'", str5.equals("TimePeriodValue[2019,100]"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "2019" + "'", str37.equals("2019"));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

//    @Test
//    public void test326() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test326");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        timePeriodValues1.setNotify(true);
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
//        java.lang.String str6 = timePeriodValues1.getDescription();
//        int int7 = timePeriodValues1.getMinStartIndex();
//        int int8 = timePeriodValues1.getMaxEndIndex();
//        timePeriodValues1.setDomainDescription("");
//        java.beans.PropertyChangeListener propertyChangeListener11 = null;
//        timePeriodValues1.removePropertyChangeListener(propertyChangeListener11);
//        java.lang.String str13 = timePeriodValues1.getDomainDescription();
//        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        timePeriodValues15.setNotify(true);
//        java.beans.PropertyChangeListener propertyChangeListener18 = null;
//        timePeriodValues15.removePropertyChangeListener(propertyChangeListener18);
//        java.lang.String str20 = timePeriodValues15.getDescription();
//        int int21 = timePeriodValues15.getMinStartIndex();
//        timePeriodValues15.fireSeriesChanged();
//        boolean boolean23 = timePeriodValues1.equals((java.lang.Object) timePeriodValues15);
//        int int24 = timePeriodValues1.getMaxStartIndex();
//        int int25 = timePeriodValues1.getMaxStartIndex();
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass27 = day26.getClass();
//        long long28 = day26.getLastMillisecond();
//        long long29 = day26.getMiddleMillisecond();
//        timePeriodValues1.setKey((java.lang.Comparable) day26);
//        java.lang.String str31 = timePeriodValues1.getDomainDescription();
//        int int32 = timePeriodValues1.getMinMiddleIndex();
//        timePeriodValues1.fireSeriesChanged();
//        org.junit.Assert.assertNull(str6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertNull(str20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass27);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560495599999L + "'", long28 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560452399999L + "'", long29 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "" + "'", str31.equals(""));
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
//    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener11);
        java.lang.String str13 = timePeriodValues1.getDomainDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues15.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timePeriodValues15.removePropertyChangeListener(propertyChangeListener18);
        java.lang.String str20 = timePeriodValues15.getDescription();
        int int21 = timePeriodValues15.getMinStartIndex();
        timePeriodValues15.fireSeriesChanged();
        boolean boolean23 = timePeriodValues1.equals((java.lang.Object) timePeriodValues15);
        int int24 = timePeriodValues1.getMaxMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener25 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener25);
        java.beans.PropertyChangeListener propertyChangeListener27 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener27);
        int int29 = timePeriodValues1.getMinMiddleIndex();
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMinEndIndex();
        boolean boolean6 = timePeriodValues1.isEmpty();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener8);
        timePeriodValues1.fireSeriesChanged();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year11, (java.lang.Number) 100);
        timePeriodValue14.setValue((java.lang.Number) 3);
        org.jfree.data.time.TimePeriod timePeriod17 = timePeriodValue14.getPeriod();
        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue(timePeriod17, (double) 6);
        org.jfree.data.time.TimePeriod timePeriod20 = timePeriodValue19.getPeriod();
        java.lang.Object obj21 = timePeriodValue19.clone();
        timePeriodValue19.setValue((java.lang.Number) 43629L);
        timePeriodValues1.add(timePeriodValue19);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        long long26 = year25.getSerialIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues28.setNotify(true);
        boolean boolean32 = timePeriodValues28.equals((java.lang.Object) (short) 0);
        boolean boolean33 = year25.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues35.setNotify(true);
        timePeriodValues35.setKey((java.lang.Comparable) 100L);
        org.jfree.data.time.TimePeriodValues timePeriodValues41 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues41.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener44 = null;
        timePeriodValues41.removePropertyChangeListener(propertyChangeListener44);
        int int46 = timePeriodValues41.getItemCount();
        int int47 = timePeriodValues41.getMaxMiddleIndex();
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year();
        timePeriodValues41.add((org.jfree.data.time.TimePeriod) year48, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue52 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year48, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = year48.previous();
        timePeriodValues35.setKey((java.lang.Comparable) year48);
        int int55 = year25.compareTo((java.lang.Object) year48);
        boolean boolean56 = timePeriodValue19.equals((java.lang.Object) year48);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2019L + "'", long12 == 2019L);
        org.junit.Assert.assertNotNull(timePeriod17);
        org.junit.Assert.assertNotNull(timePeriod20);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 2019L + "'", long26 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod53);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMinEndIndex();
        boolean boolean6 = timePeriodValues1.isEmpty();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        java.lang.Class<?> wildcardClass8 = timePeriodValues1.getClass();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 2019L);
        java.util.Date date13 = year8.getEnd();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date13);
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date13, "13-June-2019", "31-December-2019");
        timePeriodValues17.setDescription("hi!");
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(date13);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 0.0f);
        java.lang.Object obj2 = seriesChangeEvent1.getSource();
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + 0.0f + "'", obj2.equals(0.0f));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 100);
        java.util.Date date4 = year0.getStart();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) (short) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year0.previous();
        long long8 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 1593676799999L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 2019L);
        int int13 = year8.getYear();
        long long14 = year8.getLastMillisecond();
        int int15 = year8.getYear();
        long long16 = year8.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        timePeriodValues1.setNotify(true);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener10);
        int int12 = timePeriodValues1.getMaxEndIndex();
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener13);
        int int15 = timePeriodValues1.getMaxMiddleIndex();
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 2019L);
        java.util.Date date13 = year8.getEnd();
        long long14 = year8.getFirstMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues16.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timePeriodValues16.removePropertyChangeListener(propertyChangeListener19);
        java.lang.String str21 = timePeriodValues16.getDescription();
        int int22 = timePeriodValues16.getMinStartIndex();
        int int23 = timePeriodValues16.getMaxEndIndex();
        timePeriodValues16.setDomainDescription("");
        int int26 = timePeriodValues16.getMaxMiddleIndex();
        timePeriodValues16.setNotify(true);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener29 = null;
        timePeriodValues16.removeChangeListener(seriesChangeListener29);
        int int31 = year8.compareTo((java.lang.Object) timePeriodValues16);
        long long32 = year8.getLastMillisecond();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent33 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) year8);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1577865599999L + "'", long32 == 1577865599999L);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        timePeriodValues1.setNotify(true);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year10, (java.lang.Number) 100);
        timePeriodValue13.setValue((java.lang.Number) 3);
        org.jfree.data.time.TimePeriod timePeriod16 = timePeriodValue13.getPeriod();
        timePeriodValues1.add(timePeriodValue13);
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues19.setNotify(true);
        timePeriodValues19.setKey((java.lang.Comparable) 100L);
        timePeriodValues19.setKey((java.lang.Comparable) (short) 100);
        java.lang.String str26 = timePeriodValues19.getRangeDescription();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        long long28 = year27.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue30 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year27, (java.lang.Number) 100);
        timePeriodValues19.add(timePeriodValue30);
        boolean boolean32 = timePeriodValue13.equals((java.lang.Object) timePeriodValues19);
        timePeriodValue13.setValue((java.lang.Number) 43830L);
        java.lang.Number number35 = timePeriodValue13.getValue();
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
        org.junit.Assert.assertNotNull(timePeriod16);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Value" + "'", str26.equals("Value"));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 2019L + "'", long28 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + number35 + "' != '" + 43830L + "'", number35.equals(43830L));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Value");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable throwable3 = null;
        try {
            timePeriodFormatException1.addSuppressed(throwable3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year11, (java.lang.Number) 100);
        timePeriodValues1.add(timePeriodValue14);
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = timePeriodValues1.createCopy(7, 5);
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = timePeriodValues18.createCopy(4, 0);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2019L + "'", long12 == 2019L);
        org.junit.Assert.assertNotNull(timePeriodValues18);
        org.junit.Assert.assertNotNull(timePeriodValues21);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        java.lang.String str11 = year8.toString();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues13.setNotify(true);
        boolean boolean17 = timePeriodValues13.equals((java.lang.Object) (short) 0);
        int int18 = year8.compareTo((java.lang.Object) boolean17);
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) boolean17);
        int int20 = timePeriodValues19.getMinStartIndex();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2019" + "'", str11.equals("2019"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues3.setNotify(true);
        boolean boolean7 = timePeriodValues3.equals((java.lang.Object) (short) 0);
        boolean boolean8 = year0.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        timePeriodValues10.setKey((java.lang.Comparable) 100L);
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues16.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timePeriodValues16.removePropertyChangeListener(propertyChangeListener19);
        int int21 = timePeriodValues16.getItemCount();
        int int22 = timePeriodValues16.getMaxMiddleIndex();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        timePeriodValues16.add((org.jfree.data.time.TimePeriod) year23, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue27 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year23, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year23.previous();
        timePeriodValues10.setKey((java.lang.Comparable) year23);
        int int30 = year0.compareTo((java.lang.Object) year23);
        int int31 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = year0.previous();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2019 + "'", int31 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 100);
        java.util.Date date4 = year0.getStart();
        java.lang.String str5 = year0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year0.next();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = year0.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        timePeriodValues1.setKey((java.lang.Comparable) 100L);
        int int6 = timePeriodValues1.getMaxStartIndex();
        timePeriodValues1.setDomainDescription("TimePeriodValue[13-June-2019,8.0]");
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year11, (java.lang.Number) 100);
        timePeriodValues1.add(timePeriodValue14);
        java.lang.String str16 = timePeriodValues1.getDescription();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 100);
        java.util.Date date21 = year17.getStart();
        org.jfree.data.time.TimePeriodValue timePeriodValue23 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) (short) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues25.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener28 = null;
        timePeriodValues25.removePropertyChangeListener(propertyChangeListener28);
        java.lang.String str30 = timePeriodValues25.getDescription();
        boolean boolean31 = year17.equals((java.lang.Object) timePeriodValues25);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 43629L);
        timePeriodValues1.setRangeDescription("2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException37 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException39 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=0]");
        timePeriodFormatException37.addSuppressed((java.lang.Throwable) timePeriodFormatException39);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException42 = new org.jfree.data.time.TimePeriodFormatException("Value");
        timePeriodFormatException39.addSuppressed((java.lang.Throwable) timePeriodFormatException42);
        boolean boolean44 = timePeriodValues1.equals((java.lang.Object) timePeriodFormatException39);
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year();
        long long46 = year45.getSerialIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues48 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues48.setNotify(true);
        boolean boolean52 = timePeriodValues48.equals((java.lang.Object) (short) 0);
        boolean boolean53 = year45.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues55 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues55.setNotify(true);
        timePeriodValues55.setKey((java.lang.Comparable) 100L);
        org.jfree.data.time.TimePeriodValues timePeriodValues61 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues61.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener64 = null;
        timePeriodValues61.removePropertyChangeListener(propertyChangeListener64);
        int int66 = timePeriodValues61.getItemCount();
        int int67 = timePeriodValues61.getMaxMiddleIndex();
        org.jfree.data.time.Year year68 = new org.jfree.data.time.Year();
        timePeriodValues61.add((org.jfree.data.time.TimePeriod) year68, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue72 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year68, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = year68.previous();
        timePeriodValues55.setKey((java.lang.Comparable) year68);
        int int75 = year45.compareTo((java.lang.Object) year68);
        java.lang.String str76 = year45.toString();
        java.lang.Object obj77 = null;
        boolean boolean78 = year45.equals(obj77);
        java.util.Date date79 = year45.getStart();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year45, (java.lang.Number) (-1.0f));
        java.beans.PropertyChangeListener propertyChangeListener82 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener82);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2019L + "'", long12 == 2019L);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2019L + "'", long18 == 2019L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 2019L + "'", long46 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + (-1) + "'", int67 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod73);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 0 + "'", int75 == 0);
        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "2019" + "'", str76.equals("2019"));
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(date79);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener13);
        int int15 = timePeriodValues10.getItemCount();
        int int16 = timePeriodValues10.getMaxMiddleIndex();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) year17, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 2019L);
        java.util.Date date22 = year17.getEnd();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date22, timeZone23);
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues26.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timePeriodValues26.removePropertyChangeListener(propertyChangeListener29);
        int int31 = timePeriodValues26.getItemCount();
        int int32 = timePeriodValues26.getMaxMiddleIndex();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        timePeriodValues26.add((org.jfree.data.time.TimePeriod) year33, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue37 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year33, (java.lang.Number) 2019L);
        java.util.Date date38 = year33.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(date22, date38);
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date22);
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year(date22);
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year(date22);
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year(date22);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(date38);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener13);
        int int15 = timePeriodValues10.getItemCount();
        int int16 = timePeriodValues10.getMaxMiddleIndex();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) year17, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 2019L);
        java.util.Date date22 = year17.getEnd();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date22, timeZone23);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        long long26 = year25.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue28 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year25, (java.lang.Number) 100);
        java.util.Date date29 = year25.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues31 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener32 = null;
        timePeriodValues31.addChangeListener(seriesChangeListener32);
        int int34 = timePeriodValues31.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass35 = timePeriodValues31.getClass();
        java.util.Date date36 = null;
        java.util.TimeZone timeZone37 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass35, date36, timeZone37);
        org.jfree.data.time.TimePeriodValues timePeriodValues40 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues40.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener43 = null;
        timePeriodValues40.removePropertyChangeListener(propertyChangeListener43);
        int int45 = timePeriodValues40.getItemCount();
        int int46 = timePeriodValues40.getMaxMiddleIndex();
        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year();
        timePeriodValues40.add((org.jfree.data.time.TimePeriod) year47, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue51 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year47, (java.lang.Number) 2019L);
        java.util.Date date52 = year47.getEnd();
        java.util.TimeZone timeZone53 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass35, date52, timeZone53);
        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year(date29, timeZone53);
        org.jfree.data.time.TimePeriodValues timePeriodValues57 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener58 = null;
        timePeriodValues57.addChangeListener(seriesChangeListener58);
        int int60 = timePeriodValues57.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass61 = timePeriodValues57.getClass();
        java.util.Date date62 = null;
        java.util.TimeZone timeZone63 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass61, date62, timeZone63);
        org.jfree.data.time.TimePeriodValues timePeriodValues66 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues66.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener69 = null;
        timePeriodValues66.removePropertyChangeListener(propertyChangeListener69);
        int int71 = timePeriodValues66.getItemCount();
        int int72 = timePeriodValues66.getMaxMiddleIndex();
        org.jfree.data.time.Year year73 = new org.jfree.data.time.Year();
        timePeriodValues66.add((org.jfree.data.time.TimePeriod) year73, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue77 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year73, (java.lang.Number) 2019L);
        java.util.Date date78 = year73.getEnd();
        java.util.TimeZone timeZone79 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass61, date78, timeZone79);
        org.jfree.data.time.TimePeriodValues timePeriodValues82 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues82.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener85 = null;
        timePeriodValues82.removePropertyChangeListener(propertyChangeListener85);
        int int87 = timePeriodValues82.getItemCount();
        int int88 = timePeriodValues82.getMaxMiddleIndex();
        org.jfree.data.time.Year year89 = new org.jfree.data.time.Year();
        timePeriodValues82.add((org.jfree.data.time.TimePeriod) year89, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue93 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year89, (java.lang.Number) 2019L);
        java.util.Date date94 = year89.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod95 = new org.jfree.data.time.SimpleTimePeriod(date78, date94);
        java.util.TimeZone timeZone96 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year97 = new org.jfree.data.time.Year(date78, timeZone96);
        org.jfree.data.time.Year year98 = new org.jfree.data.time.Year(date29, timeZone96);
        org.jfree.data.time.Year year99 = new org.jfree.data.time.Year(date22, timeZone96);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 2019L + "'", long26 == 2019L);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertNull(regularTimePeriod38);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertNotNull(timeZone53);
        org.junit.Assert.assertNull(regularTimePeriod54);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1) + "'", int60 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass61);
        org.junit.Assert.assertNull(regularTimePeriod64);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 0 + "'", int71 == 0);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + (-1) + "'", int72 == (-1));
        org.junit.Assert.assertNotNull(date78);
        org.junit.Assert.assertNotNull(timeZone79);
        org.junit.Assert.assertNull(regularTimePeriod80);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 0 + "'", int87 == 0);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + (-1) + "'", int88 == (-1));
        org.junit.Assert.assertNotNull(date94);
        org.junit.Assert.assertNotNull(timeZone96);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        timePeriodValues1.setKey((java.lang.Comparable) 100L);
        timePeriodValues1.setKey((java.lang.Comparable) (short) 100);
        java.lang.String str8 = timePeriodValues1.getRangeDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year9, (java.lang.Number) 100);
        timePeriodValues1.add(timePeriodValue12);
        java.lang.Object obj14 = timePeriodValue12.clone();
        java.lang.String str15 = timePeriodValue12.toString();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Value" + "'", str8.equals("Value"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "TimePeriodValue[2019,100]" + "'", str15.equals("TimePeriodValue[2019,100]"));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        int int9 = timePeriodValues1.getMinEndIndex();
        int int10 = timePeriodValues1.getItemCount();
        java.lang.Comparable comparable11 = timePeriodValues1.getKey();
        int int12 = timePeriodValues1.getMaxMiddleIndex();
        int int13 = timePeriodValues1.getMaxEndIndex();
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + (byte) 1 + "'", comparable11.equals((byte) 1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        int int5 = timePeriodValues1.getMinEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = timePeriodValues1.createCopy(6, (int) (byte) 100);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener13);
        int int15 = timePeriodValues10.getItemCount();
        int int16 = timePeriodValues10.getMaxMiddleIndex();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) year17, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year17.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year17.previous();
        java.lang.Object obj24 = null;
        int int25 = year17.compareTo(obj24);
        timePeriodValues1.setKey((java.lang.Comparable) year17);
        java.util.Date date27 = year17.getEnd();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(date27);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        int int7 = timePeriodValues1.getMinStartIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setDomainDescription("");
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener11);
        int int13 = timePeriodValues1.getMaxEndIndex();
        java.lang.Comparable comparable14 = timePeriodValues1.getKey();
        timePeriodValues1.fireSeriesChanged();
        timePeriodValues1.fireSeriesChanged();
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + (byte) 1 + "'", comparable14.equals((byte) 1));
    }

//    @Test
//    public void test350() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test350");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getMiddleMillisecond();
//        long long3 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate6 = day5.getSerialDate();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate6);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(serialDate6);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(serialDate6);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(serialDate6);
//        boolean boolean11 = day0.equals((java.lang.Object) serialDate6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day0.previous();
//        int int13 = day0.getYear();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560452399999L + "'", long2 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("TimePeriodValue[2019,100.0]");
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getItemCount();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year8, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year8.previous();
        java.lang.String str14 = year8.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year8.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year8.previous();
        long long17 = year8.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019" + "'", str14.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1546329600000L + "'", long17 == 1546329600000L);
    }

//    @Test
//    public void test353() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test353");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getMiddleMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate5 = day4.getSerialDate();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
//        boolean boolean7 = day0.equals((java.lang.Object) serialDate5);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(serialDate5);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(serialDate5);
//        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        timePeriodValues11.setNotify(true);
//        java.beans.PropertyChangeListener propertyChangeListener14 = null;
//        timePeriodValues11.removePropertyChangeListener(propertyChangeListener14);
//        java.lang.String str16 = timePeriodValues11.getDescription();
//        int int17 = timePeriodValues11.getMinStartIndex();
//        int int18 = timePeriodValues11.getMaxEndIndex();
//        int int19 = timePeriodValues11.getMinEndIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues22 = timePeriodValues11.createCopy(0, (int) (short) -1);
//        int int23 = day9.compareTo((java.lang.Object) 0);
//        long long24 = day9.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560452399999L + "'", long2 == 1560452399999L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNull(str16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560495599999L + "'", long24 == 1560495599999L);
//    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener13);
        int int15 = timePeriodValues10.getItemCount();
        int int16 = timePeriodValues10.getMaxMiddleIndex();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) year17, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 2019L);
        java.util.Date date22 = year17.getEnd();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date22, timeZone23);
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues26.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timePeriodValues26.removePropertyChangeListener(propertyChangeListener29);
        int int31 = timePeriodValues26.getItemCount();
        int int32 = timePeriodValues26.getMaxMiddleIndex();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        timePeriodValues26.add((org.jfree.data.time.TimePeriod) year33, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue37 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year33, (java.lang.Number) 2019L);
        java.util.Date date38 = year33.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(date22, date38);
        long long40 = simpleTimePeriod39.getEndMillis();
        long long41 = simpleTimePeriod39.getStartMillis();
        boolean boolean43 = simpleTimePeriod39.equals((java.lang.Object) 0);
        java.util.Date date44 = simpleTimePeriod39.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues46 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener47 = null;
        timePeriodValues46.addChangeListener(seriesChangeListener47);
        int int49 = timePeriodValues46.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass50 = timePeriodValues46.getClass();
        java.util.Date date51 = null;
        java.util.TimeZone timeZone52 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass50, date51, timeZone52);
        org.jfree.data.time.TimePeriodValues timePeriodValues55 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues55.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener58 = null;
        timePeriodValues55.removePropertyChangeListener(propertyChangeListener58);
        int int60 = timePeriodValues55.getItemCount();
        int int61 = timePeriodValues55.getMaxMiddleIndex();
        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year();
        timePeriodValues55.add((org.jfree.data.time.TimePeriod) year62, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue66 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year62, (java.lang.Number) 2019L);
        java.util.Date date67 = year62.getEnd();
        java.util.TimeZone timeZone68 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass50, date67, timeZone68);
        org.jfree.data.time.TimePeriodValues timePeriodValues71 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues71.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener74 = null;
        timePeriodValues71.removePropertyChangeListener(propertyChangeListener74);
        int int76 = timePeriodValues71.getItemCount();
        int int77 = timePeriodValues71.getMaxMiddleIndex();
        org.jfree.data.time.Year year78 = new org.jfree.data.time.Year();
        timePeriodValues71.add((org.jfree.data.time.TimePeriod) year78, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue82 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year78, (java.lang.Number) 2019L);
        java.util.Date date83 = year78.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod84 = new org.jfree.data.time.SimpleTimePeriod(date67, date83);
        java.util.TimeZone timeZone85 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year86 = new org.jfree.data.time.Year(date67, timeZone85);
        boolean boolean87 = simpleTimePeriod39.equals((java.lang.Object) date67);
        java.util.Date date88 = simpleTimePeriod39.getEnd();
        java.util.Date date89 = simpleTimePeriod39.getStart();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1577865599999L + "'", long40 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1577865599999L + "'", long41 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertNull(regularTimePeriod53);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
        org.junit.Assert.assertNotNull(date67);
        org.junit.Assert.assertNotNull(timeZone68);
        org.junit.Assert.assertNull(regularTimePeriod69);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 0 + "'", int76 == 0);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + (-1) + "'", int77 == (-1));
        org.junit.Assert.assertNotNull(date83);
        org.junit.Assert.assertNotNull(timeZone85);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertNotNull(date88);
        org.junit.Assert.assertNotNull(date89);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        boolean boolean2 = timePeriodValues1.getNotify();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener3);
        timePeriodValues1.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesChangeEvent[source=0]");
        java.lang.Comparable comparable7 = timePeriodValues1.getKey();
        int int8 = timePeriodValues1.getMinMiddleIndex();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + (byte) 1 + "'", comparable7.equals((byte) 1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

//    @Test
//    public void test356() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test356");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass1 = day0.getClass();
//        long long2 = day0.getLastMillisecond();
//        java.lang.String str3 = day0.toString();
//        java.lang.String str4 = day0.toString();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass6 = day5.getClass();
//        long long7 = day5.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
//        timePeriodValues9.setNotify(true);
//        java.beans.PropertyChangeListener propertyChangeListener12 = null;
//        timePeriodValues9.removePropertyChangeListener(propertyChangeListener12);
//        java.lang.String str14 = timePeriodValues9.getDescription();
//        int int15 = timePeriodValues9.getMinStartIndex();
//        int int16 = timePeriodValues9.getMaxEndIndex();
//        int int17 = day5.compareTo((java.lang.Object) int16);
//        java.util.Date date18 = day5.getStart();
//        int int19 = day5.getYear();
//        int int20 = day0.compareTo((java.lang.Object) int19);
//        org.junit.Assert.assertNotNull(wildcardClass1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560495599999L + "'", long2 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "13-June-2019" + "'", str4.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560495599999L + "'", long7 == 1560495599999L);
//        org.junit.Assert.assertNull(str14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 100);
        timePeriodValue3.setValue((java.lang.Number) 3);
        org.jfree.data.time.TimePeriod timePeriod6 = timePeriodValue3.getPeriod();
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue(timePeriod6, (double) 6);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener13);
        int int15 = timePeriodValues10.getItemCount();
        int int16 = timePeriodValues10.getMaxMiddleIndex();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) year17, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 2019L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year17.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year17.previous();
        java.lang.Object obj24 = null;
        int int25 = year17.compareTo(obj24);
        java.lang.Number number26 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue27 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, number26);
        java.lang.Object obj28 = timePeriodValue27.clone();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent29 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValue27);
        boolean boolean30 = timePeriodValue8.equals((java.lang.Object) seriesChangeEvent29);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(timePeriod6);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues10.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener13);
        int int15 = timePeriodValues10.getItemCount();
        int int16 = timePeriodValues10.getMaxMiddleIndex();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) year17, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 2019L);
        java.util.Date date22 = year17.getEnd();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date22, timeZone23);
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues26.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timePeriodValues26.removePropertyChangeListener(propertyChangeListener29);
        int int31 = timePeriodValues26.getItemCount();
        int int32 = timePeriodValues26.getMaxMiddleIndex();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        timePeriodValues26.add((org.jfree.data.time.TimePeriod) year33, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue37 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year33, (java.lang.Number) 2019L);
        java.util.Date date38 = year33.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(date22, date38);
        long long40 = simpleTimePeriod39.getEndMillis();
        long long41 = simpleTimePeriod39.getStartMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues43 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1);
        timePeriodValues43.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener46 = null;
        timePeriodValues43.removePropertyChangeListener(propertyChangeListener46);
        int int48 = timePeriodValues43.getItemCount();
        int int49 = timePeriodValues43.getMaxMiddleIndex();
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
        timePeriodValues43.add((org.jfree.data.time.TimePeriod) year50, (double) 6);
        org.jfree.data.time.TimePeriodValue timePeriodValue54 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year50, (java.lang.Number) 2019L);
        java.util.Date date55 = year50.getEnd();
        long long56 = year50.getFirstMillisecond();
        boolean boolean57 = simpleTimePeriod39.equals((java.lang.Object) long56);
        java.util.Date date58 = simpleTimePeriod39.getEnd();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1577865599999L + "'", long40 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1577865599999L + "'", long41 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1546329600000L + "'", long56 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(date58);
    }
}

