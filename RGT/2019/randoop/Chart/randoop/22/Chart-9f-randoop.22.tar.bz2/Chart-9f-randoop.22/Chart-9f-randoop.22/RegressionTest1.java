import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test01");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date1);
        java.lang.Object obj4 = seriesChangeEvent3.getSource();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test02");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, 0, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test03");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(2147483647);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 520764324 + "'", int1 == 520764324);
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test04");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        int int3 = day0.compareTo((java.lang.Object) 2147483647);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date5);
        int int7 = day0.compareTo((java.lang.Object) date5);
        java.lang.Class class8 = null;
        java.util.Date date9 = null;
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance(class8, date9, timeZone10);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date5, timeZone10);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date5);
        int int14 = month13.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month13.previous();
        org.jfree.data.time.Year year16 = month13.getYear();
        long long17 = month13.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(year16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1559372400000L + "'", long17 == 1559372400000L);
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test05");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(2);
        java.lang.Object obj4 = null;
        boolean boolean5 = spreadsheetDate3.equals(obj4);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(3);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(serialDate7);
        java.lang.String str9 = serialDate7.toString();
        int int10 = spreadsheetDate3.compare(serialDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(2);
        int int13 = spreadsheetDate12.toSerial();
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance(3);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(serialDate15);
        java.lang.String str17 = serialDate15.toString();
        serialDate15.setDescription("");
        boolean boolean20 = spreadsheetDate12.isOnOrAfter(serialDate15);
        int int21 = spreadsheetDate3.compare((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.createInstance(3);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(serialDate23);
        boolean boolean25 = spreadsheetDate3.isOnOrAfter(serialDate23);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(2);
        int int28 = spreadsheetDate27.toSerial();
        int int29 = spreadsheetDate27.toSerial();
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
        java.util.Date date32 = day31.getStart();
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.createInstance(date32);
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.addDays(1900, serialDate33);
        boolean boolean35 = spreadsheetDate3.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate27, serialDate34);
        java.lang.String str36 = spreadsheetDate3.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate(2);
        int int39 = spreadsheetDate38.toSerial();
        int int40 = spreadsheetDate38.toSerial();
        boolean boolean41 = spreadsheetDate3.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate38);
        org.jfree.data.time.SerialDate serialDate42 = null;
        try {
            boolean boolean43 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate38, serialDate42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2-January-1900" + "'", str9.equals("2-January-1900"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "2-January-1900" + "'", str17.equals("2-January-1900"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2 + "'", int28 == 2);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2 + "'", int29 == 2);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2 + "'", int39 == 2);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2 + "'", int40 == 2);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
    }

//    @Test
//    public void test06() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test06");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) 9999);
//        timeSeriesDataItem4.setValue((java.lang.Number) 24234L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = timeSeriesDataItem4.getPeriod();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.util.Date date9 = day8.getStart();
//        int int11 = day8.compareTo((java.lang.Object) 2147483647);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        java.util.Date date13 = day12.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(date13);
//        int int15 = day8.compareTo((java.lang.Object) date13);
//        java.lang.Class class16 = null;
//        java.util.Date date17 = null;
//        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date17, timeZone18);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date13, timeZone18);
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(date13);
//        int int22 = month21.getMonth();
//        java.lang.Class class26 = null;
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class26);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        long long29 = day28.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries27.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day28, (double) (-1));
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        java.util.Date date33 = day32.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond(date33);
//        java.util.Date date35 = fixedMillisecond34.getEnd();
//        long long36 = fixedMillisecond34.getMiddleMillisecond();
//        timeSeries27.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
//        int int38 = timeSeries27.getMaximumItemCount();
//        java.lang.String str39 = timeSeries27.getDomainDescription();
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day();
//        java.util.Date date41 = day40.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond(date41);
//        java.util.Date date43 = fixedMillisecond42.getEnd();
//        long long44 = fixedMillisecond42.getMiddleMillisecond();
//        long long45 = fixedMillisecond42.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = timeSeries27.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond42);
//        int int47 = month21.compareTo((java.lang.Object) timeSeries27);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = month21.next();
//        boolean boolean49 = timeSeriesDataItem4.equals((java.lang.Object) month21);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertNotNull(timeZone18);
//        org.junit.Assert.assertNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 43626L + "'", long29 == 43626L);
//        org.junit.Assert.assertNull(timeSeriesDataItem31);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560150000000L + "'", long36 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2147483647 + "'", int38 == 2147483647);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "hi!" + "'", str39.equals("hi!"));
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1560150000000L + "'", long44 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1560150000000L + "'", long45 == 1560150000000L);
//        org.junit.Assert.assertNull(timeSeriesDataItem46);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod48);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test07");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        java.lang.Object obj2 = null;
        boolean boolean3 = spreadsheetDate1.equals(obj2);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(3);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        java.lang.String str7 = serialDate5.toString();
        int int8 = spreadsheetDate1.compare(serialDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(2);
        int int11 = spreadsheetDate10.toSerial();
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance(3);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(serialDate13);
        java.lang.String str15 = serialDate13.toString();
        serialDate13.setDescription("");
        boolean boolean18 = spreadsheetDate10.isOnOrAfter(serialDate13);
        int int19 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance(3);
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(serialDate21);
        boolean boolean23 = spreadsheetDate1.isOnOrAfter(serialDate21);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(2);
        int int26 = spreadsheetDate25.toSerial();
        int int27 = spreadsheetDate25.toSerial();
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
        java.util.Date date30 = day29.getStart();
        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.createInstance(date30);
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.addDays(1900, serialDate31);
        boolean boolean33 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate25, serialDate32);
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
        java.util.Date date36 = day35.getStart();
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.createInstance(date36);
        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.addDays(1900, serialDate37);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate(2);
        java.lang.Object obj41 = null;
        boolean boolean42 = spreadsheetDate40.equals(obj41);
        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.createInstance(3);
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(serialDate44);
        java.lang.String str46 = serialDate44.toString();
        int int47 = spreadsheetDate40.compare(serialDate44);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate49 = new org.jfree.data.time.SpreadsheetDate(2);
        int int50 = spreadsheetDate49.toSerial();
        org.jfree.data.time.SerialDate serialDate52 = org.jfree.data.time.SerialDate.createInstance(3);
        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day(serialDate52);
        java.lang.String str54 = serialDate52.toString();
        serialDate52.setDescription("");
        boolean boolean57 = spreadsheetDate49.isOnOrAfter(serialDate52);
        int int58 = spreadsheetDate40.compare((org.jfree.data.time.SerialDate) spreadsheetDate49);
        org.jfree.data.time.SerialDate serialDate60 = org.jfree.data.time.SerialDate.createInstance(3);
        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day(serialDate60);
        boolean boolean62 = spreadsheetDate40.isOnOrAfter(serialDate60);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate64 = new org.jfree.data.time.SpreadsheetDate(2);
        int int65 = spreadsheetDate64.toSerial();
        int int66 = spreadsheetDate64.toSerial();
        org.jfree.data.time.Day day68 = new org.jfree.data.time.Day();
        java.util.Date date69 = day68.getStart();
        org.jfree.data.time.SerialDate serialDate70 = org.jfree.data.time.SerialDate.createInstance(date69);
        org.jfree.data.time.SerialDate serialDate71 = org.jfree.data.time.SerialDate.addDays(1900, serialDate70);
        boolean boolean72 = spreadsheetDate40.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate64, serialDate71);
        java.lang.String str73 = spreadsheetDate40.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate75 = new org.jfree.data.time.SpreadsheetDate(2);
        int int76 = spreadsheetDate75.toSerial();
        int int77 = spreadsheetDate75.toSerial();
        boolean boolean78 = spreadsheetDate40.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate75);
        boolean boolean79 = spreadsheetDate1.isInRange(serialDate38, (org.jfree.data.time.SerialDate) spreadsheetDate40);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate81 = new org.jfree.data.time.SpreadsheetDate(2);
        int int82 = spreadsheetDate81.toSerial();
        org.jfree.data.time.SerialDate serialDate84 = org.jfree.data.time.SerialDate.createInstance(3);
        org.jfree.data.time.Day day85 = new org.jfree.data.time.Day(serialDate84);
        java.lang.String str86 = serialDate84.toString();
        serialDate84.setDescription("");
        boolean boolean89 = spreadsheetDate81.isOnOrAfter(serialDate84);
        boolean boolean90 = spreadsheetDate40.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate81);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2-January-1900" + "'", str7.equals("2-January-1900"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2 + "'", int11 == 2);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2-January-1900" + "'", str15.equals("2-January-1900"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2 + "'", int26 == 2);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2 + "'", int27 == 2);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertNotNull(serialDate38);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "2-January-1900" + "'", str46.equals("2-January-1900"));
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 2 + "'", int50 == 2);
        org.junit.Assert.assertNotNull(serialDate52);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "2-January-1900" + "'", str54.equals("2-January-1900"));
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertNotNull(serialDate60);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 2 + "'", int65 == 2);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 2 + "'", int66 == 2);
        org.junit.Assert.assertNotNull(date69);
        org.junit.Assert.assertNotNull(serialDate70);
        org.junit.Assert.assertNotNull(serialDate71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertNull(str73);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 2 + "'", int76 == 2);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 2 + "'", int77 == 2);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + true + "'", boolean79 == true);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 2 + "'", int82 == 2);
        org.junit.Assert.assertNotNull(serialDate84);
        org.junit.Assert.assertTrue("'" + str86 + "' != '" + "2-January-1900" + "'", str86.equals("2-January-1900"));
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test08");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (-1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test09");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(8);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test10");
        java.lang.Class class0 = null;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        java.util.Date date2 = day1.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone4);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date2);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        java.util.Date date8 = day7.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(date8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond9.previous();
        java.lang.Class class11 = null;
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        java.util.Date date13 = day12.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(date13);
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date13, timeZone15);
        int int17 = fixedMillisecond9.compareTo((java.lang.Object) timeZone15);
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(date2, timeZone15);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        java.util.Date date20 = day19.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond(date20);
        java.util.Date date22 = fixedMillisecond21.getStart();
        java.lang.Class<?> wildcardClass23 = date22.getClass();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
        java.util.Date date25 = day24.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond(date25);
        java.util.Date date27 = fixedMillisecond26.getStart();
        java.lang.Class<?> wildcardClass28 = date27.getClass();
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
        java.util.Date date30 = day29.getStart();
        int int32 = day29.compareTo((java.lang.Object) 2147483647);
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
        java.util.Date date34 = day33.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond(date34);
        int int36 = day29.compareTo((java.lang.Object) date34);
        java.lang.Class class37 = null;
        java.util.Date date38 = null;
        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance(class37, date38, timeZone39);
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date34, timeZone39);
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month(date34);
        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass28, date34, timeZone43);
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date22, timeZone43);
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day();
        java.util.Date date47 = day46.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond(date47);
        java.util.Date date49 = fixedMillisecond48.getStart();
        java.lang.Class<?> wildcardClass50 = date49.getClass();
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day();
        java.util.Date date52 = day51.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond53 = new org.jfree.data.time.FixedMillisecond(date52);
        java.util.Date date54 = fixedMillisecond53.getStart();
        java.lang.Class<?> wildcardClass55 = date54.getClass();
        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day();
        java.util.Date date57 = day56.getStart();
        int int59 = day56.compareTo((java.lang.Object) 2147483647);
        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day();
        java.util.Date date61 = day60.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond62 = new org.jfree.data.time.FixedMillisecond(date61);
        int int63 = day56.compareTo((java.lang.Object) date61);
        java.lang.Class class64 = null;
        java.util.Date date65 = null;
        java.util.TimeZone timeZone66 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = org.jfree.data.time.RegularTimePeriod.createInstance(class64, date65, timeZone66);
        org.jfree.data.time.Day day68 = new org.jfree.data.time.Day(date61, timeZone66);
        org.jfree.data.time.Month month69 = new org.jfree.data.time.Month(date61);
        java.util.TimeZone timeZone70 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass55, date61, timeZone70);
        org.jfree.data.time.Day day72 = new org.jfree.data.time.Day(date49, timeZone70);
        org.jfree.data.time.Day day73 = new org.jfree.data.time.Day(date22, timeZone70);
        org.jfree.data.time.Month month74 = new org.jfree.data.time.Month(date2, timeZone70);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate76 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.Day day78 = new org.jfree.data.time.Day();
        java.util.Date date79 = day78.getStart();
        org.jfree.data.time.SerialDate serialDate80 = day78.getSerialDate();
        org.jfree.data.time.Day day81 = new org.jfree.data.time.Day(serialDate80);
        org.jfree.data.time.SerialDate serialDate82 = org.jfree.data.time.SerialDate.addMonths((int) (short) 0, serialDate80);
        boolean boolean83 = spreadsheetDate76.isOnOrAfter(serialDate82);
        int int84 = month74.compareTo((java.lang.Object) boolean83);
        org.jfree.data.time.Day day86 = new org.jfree.data.time.Day();
        java.util.Date date87 = day86.getStart();
        org.jfree.data.time.SerialDate serialDate88 = day86.getSerialDate();
        org.jfree.data.time.Day day89 = new org.jfree.data.time.Day(serialDate88);
        org.jfree.data.time.SerialDate serialDate90 = org.jfree.data.time.SerialDate.addMonths((int) (short) 0, serialDate88);
        org.jfree.data.time.Day day91 = new org.jfree.data.time.Day(serialDate90);
        boolean boolean92 = month74.equals((java.lang.Object) day91);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNotNull(timeZone39);
        org.junit.Assert.assertNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(timeZone43);
        org.junit.Assert.assertNull(regularTimePeriod44);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertNotNull(wildcardClass55);
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
        org.junit.Assert.assertNotNull(timeZone66);
        org.junit.Assert.assertNull(regularTimePeriod67);
        org.junit.Assert.assertNotNull(timeZone70);
        org.junit.Assert.assertNull(regularTimePeriod71);
        org.junit.Assert.assertNotNull(date79);
        org.junit.Assert.assertNotNull(serialDate80);
        org.junit.Assert.assertNotNull(serialDate82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 1 + "'", int84 == 1);
        org.junit.Assert.assertNotNull(date87);
        org.junit.Assert.assertNotNull(serialDate88);
        org.junit.Assert.assertNotNull(serialDate90);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
    }

//    @Test
//    public void test11() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test11");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        long long6 = day5.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.util.Date date10 = day9.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond(date10);
//        java.util.Date date12 = fixedMillisecond11.getEnd();
//        long long13 = fixedMillisecond11.getMiddleMillisecond();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11);
//        int int15 = timeSeries4.getMaximumItemCount();
//        java.lang.String str16 = timeSeries4.getDomainDescription();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        java.util.Date date18 = day17.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day17.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day17.previous();
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        long long22 = day21.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries4.createCopy(regularTimePeriod20, (org.jfree.data.time.RegularTimePeriod) day21);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener24 = null;
//        timeSeries23.addChangeListener(seriesChangeListener24);
//        long long26 = timeSeries23.getMaximumItemAge();
//        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.createInstance(3);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(serialDate28);
//        java.lang.String str30 = serialDate28.toString();
//        org.jfree.data.time.SerialDate serialDate32 = serialDate28.getFollowingDayOfWeek((int) (short) 1);
//        boolean boolean33 = timeSeries23.equals((java.lang.Object) (short) 1);
//        java.lang.Object obj34 = timeSeries23.clone();
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        java.util.Date date36 = day35.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond(date36);
//        java.util.Date date38 = fixedMillisecond37.getStart();
//        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.createInstance(3);
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(serialDate40);
//        int int42 = fixedMillisecond37.compareTo((java.lang.Object) day41);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = day41.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day41, (double) 9999);
//        java.lang.Class class47 = null;
//        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, class47);
//        timeSeries48.setDescription("");
//        boolean boolean51 = timeSeriesDataItem45.equals((java.lang.Object) "");
//        try {
//            timeSeries23.add(timeSeriesDataItem45, true);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43626L + "'", long6 == 43626L);
//        org.junit.Assert.assertNull(timeSeriesDataItem8);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560150000000L + "'", long13 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2147483647 + "'", int15 == 2147483647);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 43626L + "'", long22 == 43626L);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 9223372036854775807L + "'", long26 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(serialDate28);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "2-January-1900" + "'", str30.equals("2-January-1900"));
//        org.junit.Assert.assertNotNull(serialDate32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(obj34);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(serialDate40);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod43);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test12");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        int int3 = day0.compareTo((java.lang.Object) 2147483647);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date5);
        int int7 = day0.compareTo((java.lang.Object) date5);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date5);
        int int9 = month8.getYearValue();
        long long10 = month8.getFirstMillisecond();
        long long11 = month8.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1559372400000L + "'", long10 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1559372400000L + "'", long11 == 1559372400000L);
    }

//    @Test
//    public void test13() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test13");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
//        java.util.Date date3 = fixedMillisecond2.getEnd();
//        long long4 = fixedMillisecond2.getMiddleMillisecond();
//        long long5 = fixedMillisecond2.getSerialIndex();
//        java.lang.Class class9 = null;
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        long long12 = day11.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day11, (double) (-1));
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        java.util.Date date16 = day15.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond(date16);
//        java.util.Date date18 = fixedMillisecond17.getEnd();
//        long long19 = fixedMillisecond17.getMiddleMillisecond();
//        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
//        int int21 = timeSeries10.getMaximumItemCount();
//        java.lang.String str22 = timeSeries10.getDescription();
//        boolean boolean23 = fixedMillisecond2.equals((java.lang.Object) timeSeries10);
//        java.lang.Class class27 = null;
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class27);
//        java.lang.String str29 = timeSeries28.getDescription();
//        java.util.Collection collection30 = timeSeries28.getTimePeriods();
//        java.lang.String str31 = timeSeries28.getDescription();
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        java.util.Date date33 = day32.getStart();
//        int int35 = day32.compareTo((java.lang.Object) 2147483647);
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
//        java.util.Date date37 = day36.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond(date37);
//        int int39 = day32.compareTo((java.lang.Object) date37);
//        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(date37);
//        long long41 = month40.getSerialIndex();
//        int int42 = month40.getMonth();
//        timeSeries28.delete((org.jfree.data.time.RegularTimePeriod) month40);
//        java.lang.Class class44 = null;
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day();
//        java.util.Date date46 = day45.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond(date46);
//        java.util.TimeZone timeZone48 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance(class44, date46, timeZone48);
//        org.jfree.data.time.SerialDate serialDate50 = org.jfree.data.time.SerialDate.createInstance(date46);
//        timeSeries28.setKey((java.lang.Comparable) serialDate50);
//        int int52 = fixedMillisecond2.compareTo((java.lang.Object) serialDate50);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560150000000L + "'", long4 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560150000000L + "'", long5 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 43626L + "'", long12 == 43626L);
//        org.junit.Assert.assertNull(timeSeriesDataItem14);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560150000000L + "'", long19 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2147483647 + "'", int21 == 2147483647);
//        org.junit.Assert.assertNull(str22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNull(str29);
//        org.junit.Assert.assertNotNull(collection30);
//        org.junit.Assert.assertNull(str31);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 24234L + "'", long41 == 24234L);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 6 + "'", int42 == 6);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNotNull(timeZone48);
//        org.junit.Assert.assertNull(regularTimePeriod49);
//        org.junit.Assert.assertNotNull(serialDate50);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
//    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test14");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(2);
        java.lang.Object obj3 = null;
        boolean boolean4 = spreadsheetDate2.equals(obj3);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(3);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate6);
        java.lang.String str8 = serialDate6.toString();
        int int9 = spreadsheetDate2.compare(serialDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(2);
        int int12 = spreadsheetDate11.toSerial();
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(3);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate14);
        java.lang.String str16 = serialDate14.toString();
        serialDate14.setDescription("");
        boolean boolean19 = spreadsheetDate11.isOnOrAfter(serialDate14);
        int int20 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.createInstance(3);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(serialDate22);
        boolean boolean24 = spreadsheetDate2.isOnOrAfter(serialDate22);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(2);
        int int27 = spreadsheetDate26.toSerial();
        int int28 = spreadsheetDate26.toSerial();
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
        java.util.Date date31 = day30.getStart();
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.createInstance(date31);
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.addDays(1900, serialDate32);
        boolean boolean34 = spreadsheetDate2.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate26, serialDate33);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate(2);
        java.lang.Object obj39 = null;
        boolean boolean40 = spreadsheetDate38.equals(obj39);
        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.createInstance(3);
        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(serialDate42);
        java.lang.String str44 = serialDate42.toString();
        int int45 = spreadsheetDate38.compare(serialDate42);
        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate38);
        org.jfree.data.time.SerialDate serialDate47 = org.jfree.data.time.SerialDate.addMonths((int) '#', serialDate46);
        boolean boolean48 = spreadsheetDate26.isBefore(serialDate47);
        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.addDays(9, (org.jfree.data.time.SerialDate) spreadsheetDate26);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate(2);
        java.lang.Object obj52 = null;
        boolean boolean53 = spreadsheetDate51.equals(obj52);
        org.jfree.data.time.SerialDate serialDate55 = org.jfree.data.time.SerialDate.createInstance(3);
        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day(serialDate55);
        java.lang.String str57 = serialDate55.toString();
        int int58 = spreadsheetDate51.compare(serialDate55);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate60 = new org.jfree.data.time.SpreadsheetDate(2);
        int int61 = spreadsheetDate60.toSerial();
        org.jfree.data.time.SerialDate serialDate63 = org.jfree.data.time.SerialDate.createInstance(3);
        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day(serialDate63);
        java.lang.String str65 = serialDate63.toString();
        serialDate63.setDescription("");
        boolean boolean68 = spreadsheetDate60.isOnOrAfter(serialDate63);
        int int69 = spreadsheetDate51.compare((org.jfree.data.time.SerialDate) spreadsheetDate60);
        org.jfree.data.time.SerialDate serialDate71 = org.jfree.data.time.SerialDate.createInstance(3);
        org.jfree.data.time.Day day72 = new org.jfree.data.time.Day(serialDate71);
        boolean boolean73 = spreadsheetDate51.isOnOrAfter(serialDate71);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate75 = new org.jfree.data.time.SpreadsheetDate(2);
        int int76 = spreadsheetDate75.toSerial();
        int int77 = spreadsheetDate75.toSerial();
        org.jfree.data.time.Day day79 = new org.jfree.data.time.Day();
        java.util.Date date80 = day79.getStart();
        org.jfree.data.time.SerialDate serialDate81 = org.jfree.data.time.SerialDate.createInstance(date80);
        org.jfree.data.time.SerialDate serialDate82 = org.jfree.data.time.SerialDate.addDays(1900, serialDate81);
        boolean boolean83 = spreadsheetDate51.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate75, serialDate82);
        java.lang.String str84 = spreadsheetDate51.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate86 = new org.jfree.data.time.SpreadsheetDate(2);
        int int87 = spreadsheetDate86.toSerial();
        int int88 = spreadsheetDate86.toSerial();
        boolean boolean89 = spreadsheetDate51.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate86);
        boolean boolean90 = spreadsheetDate26.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate86);
        org.jfree.data.time.Day day91 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate26);
        int int92 = spreadsheetDate26.toSerial();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2-January-1900" + "'", str8.equals("2-January-1900"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "2-January-1900" + "'", str16.equals("2-January-1900"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2 + "'", int27 == 2);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2 + "'", int28 == 2);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "2-January-1900" + "'", str44.equals("2-January-1900"));
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(serialDate55);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "2-January-1900" + "'", str57.equals("2-January-1900"));
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + (-1) + "'", int58 == (-1));
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 2 + "'", int61 == 2);
        org.junit.Assert.assertNotNull(serialDate63);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "2-January-1900" + "'", str65.equals("2-January-1900"));
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
        org.junit.Assert.assertNotNull(serialDate71);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 2 + "'", int76 == 2);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 2 + "'", int77 == 2);
        org.junit.Assert.assertNotNull(date80);
        org.junit.Assert.assertNotNull(serialDate81);
        org.junit.Assert.assertNotNull(serialDate82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + true + "'", boolean83 == true);
        org.junit.Assert.assertNull(str84);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 2 + "'", int87 == 2);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 2 + "'", int88 == 2);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + true + "'", boolean89 == true);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + true + "'", boolean90 == true);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 2 + "'", int92 == 2);
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test15");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.setNotify(true);
        java.lang.String str7 = timeSeries4.getRangeDescription();
        timeSeries4.setDescription("hi!");
        java.util.Collection collection10 = timeSeries4.getTimePeriods();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(2);
        java.lang.Object obj13 = null;
        boolean boolean14 = spreadsheetDate12.equals(obj13);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.createInstance(3);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(serialDate16);
        java.lang.String str18 = serialDate16.toString();
        int int19 = spreadsheetDate12.compare(serialDate16);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(2);
        int int22 = spreadsheetDate21.toSerial();
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance(3);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(serialDate24);
        java.lang.String str26 = serialDate24.toString();
        serialDate24.setDescription("");
        boolean boolean29 = spreadsheetDate21.isOnOrAfter(serialDate24);
        int int30 = spreadsheetDate12.compare((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.createInstance(3);
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(serialDate32);
        boolean boolean34 = spreadsheetDate12.isOnOrAfter(serialDate32);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(2);
        int int37 = spreadsheetDate36.toSerial();
        int int38 = spreadsheetDate36.toSerial();
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day();
        java.util.Date date41 = day40.getStart();
        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.createInstance(date41);
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.addDays(1900, serialDate42);
        boolean boolean44 = spreadsheetDate12.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate36, serialDate43);
        timeSeries4.setKey((java.lang.Comparable) spreadsheetDate12);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "2-January-1900" + "'", str18.equals("2-January-1900"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2 + "'", int22 == 2);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "2-January-1900" + "'", str26.equals("2-January-1900"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 2 + "'", int37 == 2);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2 + "'", int38 == 2);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
    }

//    @Test
//    public void test16() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test16");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
//        java.util.Date date3 = fixedMillisecond2.getEnd();
//        long long4 = fixedMillisecond2.getMiddleMillisecond();
//        java.util.Date date5 = fixedMillisecond2.getTime();
//        java.util.Date date6 = fixedMillisecond2.getStart();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560150000000L + "'", long4 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(date6);
//    }

//    @Test
//    public void test17() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test17");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        long long6 = day5.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.util.Date date10 = day9.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond(date10);
//        java.util.Date date12 = fixedMillisecond11.getEnd();
//        long long13 = fixedMillisecond11.getMiddleMillisecond();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11);
//        int int15 = timeSeries4.getMaximumItemCount();
//        java.lang.String str16 = timeSeries4.getDomainDescription();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        java.util.Date date18 = day17.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day17.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day17.previous();
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        long long22 = day21.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries4.createCopy(regularTimePeriod20, (org.jfree.data.time.RegularTimePeriod) day21);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        java.util.Date date25 = day24.getStart();
//        int int27 = day24.compareTo((java.lang.Object) 2147483647);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        java.util.Date date29 = day28.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond(date29);
//        int int31 = day24.compareTo((java.lang.Object) date29);
//        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date29);
//        timeSeries4.setKey((java.lang.Comparable) date29);
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date29);
//        java.lang.String str35 = timeSeries34.getDomainDescription();
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43626L + "'", long6 == 43626L);
//        org.junit.Assert.assertNull(timeSeriesDataItem8);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560150000000L + "'", long13 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2147483647 + "'", int15 == 2147483647);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 43626L + "'", long22 == 43626L);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Time" + "'", str35.equals("Time"));
//    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test18");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(3);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(serialDate1);
        java.lang.String str3 = day2.toString();
        org.jfree.data.time.SerialDate serialDate4 = day2.getSerialDate();
        java.util.Calendar calendar5 = null;
        try {
            day2.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2-January-1900" + "'", str3.equals("2-January-1900"));
        org.junit.Assert.assertNotNull(serialDate4);
    }

//    @Test
//    public void test19() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test19");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        long long6 = day5.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.util.Date date10 = day9.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond(date10);
//        java.util.Date date12 = fixedMillisecond11.getEnd();
//        long long13 = fixedMillisecond11.getMiddleMillisecond();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11);
//        int int15 = timeSeries4.getMaximumItemCount();
//        java.lang.String str16 = timeSeries4.getDescription();
//        timeSeries4.setDescription("");
//        java.lang.Class class22 = null;
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class22);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        long long25 = day24.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries23.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day24, (double) (-1));
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        java.util.Date date29 = day28.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond(date29);
//        java.util.Date date31 = fixedMillisecond30.getEnd();
//        long long32 = fixedMillisecond30.getMiddleMillisecond();
//        timeSeries23.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30);
//        java.beans.PropertyChangeListener propertyChangeListener34 = null;
//        timeSeries23.removePropertyChangeListener(propertyChangeListener34);
//        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries4.addAndOrUpdate(timeSeries23);
//        java.lang.Object obj37 = timeSeries23.clone();
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
//        java.util.Date date39 = day38.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond(date39);
//        java.util.Date date41 = fixedMillisecond40.getStart();
//        java.lang.Class<?> wildcardClass42 = date41.getClass();
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
//        java.util.Date date44 = day43.getStart();
//        int int46 = day43.compareTo((java.lang.Object) 2147483647);
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
//        java.util.Date date48 = day47.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond49 = new org.jfree.data.time.FixedMillisecond(date48);
//        int int50 = day43.compareTo((java.lang.Object) date48);
//        java.lang.Class class51 = null;
//        java.util.Date date52 = null;
//        java.util.TimeZone timeZone53 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance(class51, date52, timeZone53);
//        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day(date48, timeZone53);
//        org.jfree.data.time.Month month56 = new org.jfree.data.time.Month(date48);
//        java.util.TimeZone timeZone57 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass42, date48, timeZone57);
//        org.jfree.data.time.SerialDate serialDate59 = org.jfree.data.time.SerialDate.createInstance(date48);
//        timeSeries23.setKey((java.lang.Comparable) date48);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43626L + "'", long6 == 43626L);
//        org.junit.Assert.assertNull(timeSeriesDataItem8);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560150000000L + "'", long13 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2147483647 + "'", int15 == 2147483647);
//        org.junit.Assert.assertNull(str16);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 43626L + "'", long25 == 43626L);
//        org.junit.Assert.assertNull(timeSeriesDataItem27);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560150000000L + "'", long32 == 1560150000000L);
//        org.junit.Assert.assertNotNull(timeSeries36);
//        org.junit.Assert.assertNotNull(obj37);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNotNull(wildcardClass42);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
//        org.junit.Assert.assertNotNull(timeZone53);
//        org.junit.Assert.assertNull(regularTimePeriod54);
//        org.junit.Assert.assertNotNull(timeZone57);
//        org.junit.Assert.assertNull(regularTimePeriod58);
//        org.junit.Assert.assertNotNull(serialDate59);
//    }

//    @Test
//    public void test20() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test20");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        long long6 = day5.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.util.Date date10 = day9.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond(date10);
//        java.util.Date date12 = fixedMillisecond11.getEnd();
//        long long13 = fixedMillisecond11.getMiddleMillisecond();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11);
//        int int15 = timeSeries4.getMaximumItemCount();
//        java.lang.String str16 = timeSeries4.getDescription();
//        java.lang.String str17 = timeSeries4.getDescription();
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43626L + "'", long6 == 43626L);
//        org.junit.Assert.assertNull(timeSeriesDataItem8);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560150000000L + "'", long13 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2147483647 + "'", int15 == 2147483647);
//        org.junit.Assert.assertNull(str16);
//        org.junit.Assert.assertNull(str17);
//    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test21");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.setNotify(true);
        java.lang.String str7 = timeSeries4.getRangeDescription();
        timeSeries4.setDescription("hi!");
        java.util.Collection collection10 = timeSeries4.getTimePeriods();
        timeSeries4.setDomainDescription("Wed Dec 31 16:00:00 PST 1969");
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(collection10);
    }

//    @Test
//    public void test22() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test22");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        java.util.Date date2 = day1.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone4);
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date2);
//        java.lang.String str7 = serialDate6.toString();
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10-June-2019" + "'", str7.equals("10-June-2019"));
//    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test23");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((-452), year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test24() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test24");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        long long6 = day5.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.util.Date date10 = day9.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond(date10);
//        java.util.Date date12 = fixedMillisecond11.getEnd();
//        long long13 = fixedMillisecond11.getMiddleMillisecond();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11);
//        int int15 = timeSeries4.getMaximumItemCount();
//        java.lang.String str16 = timeSeries4.getDescription();
//        boolean boolean17 = timeSeries4.isEmpty();
//        java.lang.Class<?> wildcardClass18 = timeSeries4.getClass();
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43626L + "'", long6 == 43626L);
//        org.junit.Assert.assertNull(timeSeriesDataItem8);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560150000000L + "'", long13 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2147483647 + "'", int15 == 2147483647);
//        org.junit.Assert.assertNull(str16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test25");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.setNotify(true);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) '#');
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond8.previous();
        java.util.Calendar calendar11 = null;
        long long12 = fixedMillisecond8.getMiddleMillisecond(calendar11);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 35L + "'", long12 == 35L);
    }

//    @Test
//    public void test26() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test26");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        long long6 = day5.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.util.Date date10 = day9.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond(date10);
//        java.util.Date date12 = fixedMillisecond11.getEnd();
//        long long13 = fixedMillisecond11.getMiddleMillisecond();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11);
//        timeSeries4.setKey((java.lang.Comparable) 1.0d);
//        long long17 = timeSeries4.getMaximumItemAge();
//        java.beans.PropertyChangeListener propertyChangeListener18 = null;
//        timeSeries4.removePropertyChangeListener(propertyChangeListener18);
//        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance(3);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(serialDate21);
//        java.lang.String str23 = day22.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day22, (java.lang.Number) 5);
//        try {
//            timeSeries4.update(4, (java.lang.Number) 2147483647);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43626L + "'", long6 == 43626L);
//        org.junit.Assert.assertNull(timeSeriesDataItem8);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560150000000L + "'", long13 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 9223372036854775807L + "'", long17 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "2-January-1900" + "'", str23.equals("2-January-1900"));
//        org.junit.Assert.assertNull(timeSeriesDataItem25);
//    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test27");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(2);
        java.lang.Object obj5 = null;
        boolean boolean6 = spreadsheetDate4.equals(obj5);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance(3);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(serialDate8);
        java.lang.String str10 = serialDate8.toString();
        int int11 = spreadsheetDate4.compare(serialDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(2);
        int int14 = spreadsheetDate13.toSerial();
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.createInstance(3);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(serialDate16);
        java.lang.String str18 = serialDate16.toString();
        serialDate16.setDescription("");
        boolean boolean21 = spreadsheetDate13.isOnOrAfter(serialDate16);
        int int22 = spreadsheetDate4.compare((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance(3);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(serialDate24);
        boolean boolean26 = spreadsheetDate4.isOnOrAfter(serialDate24);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(2);
        int int29 = spreadsheetDate28.toSerial();
        int int30 = spreadsheetDate28.toSerial();
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
        java.util.Date date33 = day32.getStart();
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.createInstance(date33);
        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.addDays(1900, serialDate34);
        boolean boolean36 = spreadsheetDate4.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate28, serialDate35);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate(2);
        java.lang.Object obj41 = null;
        boolean boolean42 = spreadsheetDate40.equals(obj41);
        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.createInstance(3);
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(serialDate44);
        java.lang.String str46 = serialDate44.toString();
        int int47 = spreadsheetDate40.compare(serialDate44);
        org.jfree.data.time.SerialDate serialDate48 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate40);
        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.addMonths((int) '#', serialDate48);
        boolean boolean50 = spreadsheetDate28.isBefore(serialDate49);
        org.jfree.data.time.SerialDate serialDate51 = org.jfree.data.time.SerialDate.addDays(9, (org.jfree.data.time.SerialDate) spreadsheetDate28);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate53 = new org.jfree.data.time.SpreadsheetDate(2);
        java.lang.Object obj54 = null;
        boolean boolean55 = spreadsheetDate53.equals(obj54);
        org.jfree.data.time.SerialDate serialDate57 = org.jfree.data.time.SerialDate.createInstance(3);
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(serialDate57);
        java.lang.String str59 = serialDate57.toString();
        int int60 = spreadsheetDate53.compare(serialDate57);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate62 = new org.jfree.data.time.SpreadsheetDate(2);
        int int63 = spreadsheetDate62.toSerial();
        org.jfree.data.time.SerialDate serialDate65 = org.jfree.data.time.SerialDate.createInstance(3);
        org.jfree.data.time.Day day66 = new org.jfree.data.time.Day(serialDate65);
        java.lang.String str67 = serialDate65.toString();
        serialDate65.setDescription("");
        boolean boolean70 = spreadsheetDate62.isOnOrAfter(serialDate65);
        int int71 = spreadsheetDate53.compare((org.jfree.data.time.SerialDate) spreadsheetDate62);
        org.jfree.data.time.SerialDate serialDate73 = org.jfree.data.time.SerialDate.createInstance(3);
        org.jfree.data.time.Day day74 = new org.jfree.data.time.Day(serialDate73);
        boolean boolean75 = spreadsheetDate53.isOnOrAfter(serialDate73);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate77 = new org.jfree.data.time.SpreadsheetDate(2);
        int int78 = spreadsheetDate77.toSerial();
        int int79 = spreadsheetDate77.toSerial();
        org.jfree.data.time.Day day81 = new org.jfree.data.time.Day();
        java.util.Date date82 = day81.getStart();
        org.jfree.data.time.SerialDate serialDate83 = org.jfree.data.time.SerialDate.createInstance(date82);
        org.jfree.data.time.SerialDate serialDate84 = org.jfree.data.time.SerialDate.addDays(1900, serialDate83);
        boolean boolean85 = spreadsheetDate53.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate77, serialDate84);
        java.lang.String str86 = spreadsheetDate53.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate88 = new org.jfree.data.time.SpreadsheetDate(2);
        int int89 = spreadsheetDate88.toSerial();
        int int90 = spreadsheetDate88.toSerial();
        boolean boolean91 = spreadsheetDate53.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate88);
        boolean boolean92 = spreadsheetDate28.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate88);
        org.jfree.data.time.Day day93 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate28);
        boolean boolean94 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate28);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2-January-1900" + "'", str10.equals("2-January-1900"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "2-January-1900" + "'", str18.equals("2-January-1900"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2 + "'", int29 == 2);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2 + "'", int30 == 2);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "2-January-1900" + "'", str46.equals("2-January-1900"));
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "2-January-1900" + "'", str59.equals("2-January-1900"));
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1) + "'", int60 == (-1));
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 2 + "'", int63 == 2);
        org.junit.Assert.assertNotNull(serialDate65);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "2-January-1900" + "'", str67.equals("2-January-1900"));
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 0 + "'", int71 == 0);
        org.junit.Assert.assertNotNull(serialDate73);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 2 + "'", int78 == 2);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 2 + "'", int79 == 2);
        org.junit.Assert.assertNotNull(date82);
        org.junit.Assert.assertNotNull(serialDate83);
        org.junit.Assert.assertNotNull(serialDate84);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + true + "'", boolean85 == true);
        org.junit.Assert.assertNull(str86);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 2 + "'", int89 == 2);
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 2 + "'", int90 == 2);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + true + "'", boolean91 == true);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + true + "'", boolean92 == true);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
    }

//    @Test
//    public void test28() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test28");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
//        java.util.Date date3 = fixedMillisecond2.getEnd();
//        long long4 = fixedMillisecond2.getMiddleMillisecond();
//        long long5 = fixedMillisecond2.getSerialIndex();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) fixedMillisecond2);
//        java.lang.String str7 = seriesChangeEvent6.toString();
//        java.lang.Object obj8 = seriesChangeEvent6.getSource();
//        java.lang.String str9 = seriesChangeEvent6.toString();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560150000000L + "'", long4 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560150000000L + "'", long5 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=Mon Jun 10 00:00:00 PDT 2019]" + "'", str7.equals("org.jfree.data.general.SeriesChangeEvent[source=Mon Jun 10 00:00:00 PDT 2019]"));
//        org.junit.Assert.assertNotNull(obj8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=Mon Jun 10 00:00:00 PDT 2019]" + "'", str9.equals("org.jfree.data.general.SeriesChangeEvent[source=Mon Jun 10 00:00:00 PDT 2019]"));
//    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test29");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test30");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(3);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(serialDate1);
        java.lang.String str3 = serialDate1.toString();
        serialDate1.setDescription("");
        org.jfree.data.time.SerialDate serialDate7 = serialDate1.getFollowingDayOfWeek(6);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(serialDate1);
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2-January-1900" + "'", str3.equals("2-January-1900"));
        org.junit.Assert.assertNotNull(serialDate7);
    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test31");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        timeSeries4.setNotify(true);
        java.lang.String str7 = timeSeries4.getRangeDescription();
        timeSeries4.setDescription("hi!");
        java.util.Collection collection10 = timeSeries4.getTimePeriods();
        timeSeries4.setMaximumItemCount(100);
        java.util.List list13 = timeSeries4.getItems();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        java.util.Date date15 = day14.getStart();
        int int17 = day14.compareTo((java.lang.Object) 2147483647);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        java.util.Date date19 = day18.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond(date19);
        int int21 = day14.compareTo((java.lang.Object) date19);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(date19);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date19);
        java.lang.Number number24 = null;
        try {
            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) day23, number24, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
    }

//    @Test
//    public void test32() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test32");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        long long6 = day5.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.util.Date date10 = day9.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond(date10);
//        java.util.Date date12 = fixedMillisecond11.getEnd();
//        long long13 = fixedMillisecond11.getMiddleMillisecond();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11);
//        int int15 = timeSeries4.getMaximumItemCount();
//        java.lang.String str16 = timeSeries4.getDomainDescription();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        java.util.Date date18 = day17.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond(date18);
//        java.util.Date date20 = fixedMillisecond19.getEnd();
//        long long21 = fixedMillisecond19.getMiddleMillisecond();
//        long long22 = fixedMillisecond19.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
//        java.lang.Class class27 = null;
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "", "ERROR : Relative To String", class27);
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries4.addAndOrUpdate(timeSeries28);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        java.util.Date date31 = day30.getEnd();
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        java.util.Date date33 = day32.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond(date33);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = fixedMillisecond34.previous();
//        java.lang.Class class36 = null;
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
//        java.util.Date date38 = day37.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond(date38);
//        java.util.TimeZone timeZone40 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance(class36, date38, timeZone40);
//        int int42 = fixedMillisecond34.compareTo((java.lang.Object) timeZone40);
//        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year(date31, timeZone40);
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day();
//        java.util.Date date45 = day44.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond(date45);
//        java.util.Date date47 = fixedMillisecond46.getStart();
//        java.lang.Class<?> wildcardClass48 = date47.getClass();
//        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day();
//        java.util.Date date50 = day49.getStart();
//        int int52 = day49.compareTo((java.lang.Object) 2147483647);
//        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day();
//        java.util.Date date54 = day53.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond55 = new org.jfree.data.time.FixedMillisecond(date54);
//        int int56 = day49.compareTo((java.lang.Object) date54);
//        java.lang.Class class57 = null;
//        java.util.Date date58 = null;
//        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = org.jfree.data.time.RegularTimePeriod.createInstance(class57, date58, timeZone59);
//        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day(date54, timeZone59);
//        org.jfree.data.time.Month month62 = new org.jfree.data.time.Month(date54);
//        java.util.TimeZone timeZone63 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass48, date54, timeZone63);
//        int int65 = year43.compareTo((java.lang.Object) date54);
//        java.lang.Class class66 = null;
//        org.jfree.data.time.Day day67 = new org.jfree.data.time.Day();
//        java.util.Date date68 = day67.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond69 = new org.jfree.data.time.FixedMillisecond(date68);
//        java.util.TimeZone timeZone70 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = org.jfree.data.time.RegularTimePeriod.createInstance(class66, date68, timeZone70);
//        org.jfree.data.time.SerialDate serialDate72 = org.jfree.data.time.SerialDate.createInstance(date68);
//        org.jfree.data.time.Day day73 = new org.jfree.data.time.Day();
//        java.util.Date date74 = day73.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond75 = new org.jfree.data.time.FixedMillisecond(date74);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = fixedMillisecond75.previous();
//        java.lang.Class class77 = null;
//        org.jfree.data.time.Day day78 = new org.jfree.data.time.Day();
//        java.util.Date date79 = day78.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond80 = new org.jfree.data.time.FixedMillisecond(date79);
//        java.util.TimeZone timeZone81 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod82 = org.jfree.data.time.RegularTimePeriod.createInstance(class77, date79, timeZone81);
//        int int83 = fixedMillisecond75.compareTo((java.lang.Object) timeZone81);
//        org.jfree.data.time.Month month84 = new org.jfree.data.time.Month(date68, timeZone81);
//        org.jfree.data.time.Month month85 = new org.jfree.data.time.Month(date54, timeZone81);
//        org.jfree.data.time.Year year86 = month85.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem88 = timeSeries29.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month85, (java.lang.Number) 0L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43626L + "'", long6 == 43626L);
//        org.junit.Assert.assertNull(timeSeriesDataItem8);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560150000000L + "'", long13 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2147483647 + "'", int15 == 2147483647);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560150000000L + "'", long21 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560150000000L + "'", long22 == 1560150000000L);
//        org.junit.Assert.assertNull(timeSeriesDataItem23);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(timeZone40);
//        org.junit.Assert.assertNull(regularTimePeriod41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertNotNull(wildcardClass48);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
//        org.junit.Assert.assertNotNull(timeZone59);
//        org.junit.Assert.assertNull(regularTimePeriod60);
//        org.junit.Assert.assertNotNull(timeZone63);
//        org.junit.Assert.assertNull(regularTimePeriod64);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1 + "'", int65 == 1);
//        org.junit.Assert.assertNotNull(date68);
//        org.junit.Assert.assertNotNull(timeZone70);
//        org.junit.Assert.assertNull(regularTimePeriod71);
//        org.junit.Assert.assertNotNull(serialDate72);
//        org.junit.Assert.assertNotNull(date74);
//        org.junit.Assert.assertNotNull(regularTimePeriod76);
//        org.junit.Assert.assertNotNull(date79);
//        org.junit.Assert.assertNotNull(timeZone81);
//        org.junit.Assert.assertNull(regularTimePeriod82);
//        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 1 + "'", int83 == 1);
//        org.junit.Assert.assertNotNull(year86);
//        org.junit.Assert.assertNull(timeSeriesDataItem88);
//    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test33");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
        java.lang.String str5 = timeSeries4.getDescription();
        java.util.Collection collection6 = timeSeries4.getTimePeriods();
        java.lang.String str7 = timeSeries4.getDescription();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        java.util.Date date9 = day8.getStart();
        int int11 = day8.compareTo((java.lang.Object) 2147483647);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        java.util.Date date13 = day12.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(date13);
        int int15 = day8.compareTo((java.lang.Object) date13);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date13);
        long long17 = month16.getSerialIndex();
        int int18 = month16.getMonth();
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) month16);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
        java.util.Date date21 = day20.getStart();
        int int23 = day20.compareTo((java.lang.Object) 2147483647);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
        java.util.Date date25 = day24.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond(date25);
        int int27 = day20.compareTo((java.lang.Object) date25);
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(date25);
        long long29 = month28.getFirstMillisecond();
        java.lang.String str30 = month28.toString();
        try {
            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) month28, (java.lang.Number) 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(collection6);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 24234L + "'", long17 == 24234L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1559372400000L + "'", long29 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "June 2019" + "'", str30.equals("June 2019"));
    }

//    @Test
//    public void test34() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test34");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        fixedMillisecond0.peg(calendar1);
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getFirstMillisecond(calendar3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560192398642L + "'", long4 == 1560192398642L);
//    }

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test35");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(2);
        int int3 = spreadsheetDate2.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(2);
        java.lang.Object obj6 = null;
        boolean boolean7 = spreadsheetDate5.equals(obj6);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(3);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(serialDate9);
        java.lang.String str11 = serialDate9.toString();
        int int12 = spreadsheetDate5.compare(serialDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(2);
        int int15 = spreadsheetDate14.toSerial();
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(3);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(serialDate17);
        java.lang.String str19 = serialDate17.toString();
        serialDate17.setDescription("");
        boolean boolean22 = spreadsheetDate14.isOnOrAfter(serialDate17);
        int int23 = spreadsheetDate5.compare((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance(3);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(serialDate25);
        boolean boolean27 = spreadsheetDate5.isOnOrAfter(serialDate25);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(2);
        int int30 = spreadsheetDate29.toSerial();
        int int31 = spreadsheetDate29.toSerial();
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
        java.util.Date date34 = day33.getStart();
        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.createInstance(date34);
        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.addDays(1900, serialDate35);
        boolean boolean37 = spreadsheetDate5.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate29, serialDate36);
        java.lang.String str38 = spreadsheetDate5.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate(2);
        int int41 = spreadsheetDate40.toSerial();
        int int42 = spreadsheetDate40.toSerial();
        boolean boolean43 = spreadsheetDate5.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate40);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate(2);
        java.lang.Object obj46 = null;
        boolean boolean47 = spreadsheetDate45.equals(obj46);
        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.createInstance(3);
        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(serialDate49);
        java.lang.String str51 = serialDate49.toString();
        int int52 = spreadsheetDate45.compare(serialDate49);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate54 = new org.jfree.data.time.SpreadsheetDate(2);
        int int55 = spreadsheetDate54.toSerial();
        org.jfree.data.time.SerialDate serialDate57 = org.jfree.data.time.SerialDate.createInstance(3);
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(serialDate57);
        java.lang.String str59 = serialDate57.toString();
        serialDate57.setDescription("");
        boolean boolean62 = spreadsheetDate54.isOnOrAfter(serialDate57);
        int int63 = spreadsheetDate45.compare((org.jfree.data.time.SerialDate) spreadsheetDate54);
        org.jfree.data.time.SerialDate serialDate65 = org.jfree.data.time.SerialDate.createInstance(3);
        org.jfree.data.time.Day day66 = new org.jfree.data.time.Day(serialDate65);
        boolean boolean67 = spreadsheetDate45.isOnOrAfter(serialDate65);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate69 = new org.jfree.data.time.SpreadsheetDate(2);
        int int70 = spreadsheetDate69.toSerial();
        int int71 = spreadsheetDate69.toSerial();
        org.jfree.data.time.Day day73 = new org.jfree.data.time.Day();
        java.util.Date date74 = day73.getStart();
        org.jfree.data.time.SerialDate serialDate75 = org.jfree.data.time.SerialDate.createInstance(date74);
        org.jfree.data.time.SerialDate serialDate76 = org.jfree.data.time.SerialDate.addDays(1900, serialDate75);
        boolean boolean77 = spreadsheetDate45.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate69, serialDate76);
        org.jfree.data.time.SerialDate serialDate79 = org.jfree.data.time.SerialDate.createInstance(3);
        org.jfree.data.time.Day day80 = new org.jfree.data.time.Day(serialDate79);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = day80.next();
        org.jfree.data.time.SerialDate serialDate82 = day80.getSerialDate();
        boolean boolean83 = spreadsheetDate40.isInRange(serialDate76, serialDate82);
        boolean boolean84 = spreadsheetDate2.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate40);
        org.jfree.data.time.SerialDate serialDate85 = org.jfree.data.time.SerialDate.addDays((int) (byte) 1, (org.jfree.data.time.SerialDate) spreadsheetDate40);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2 + "'", int3 == 2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2-January-1900" + "'", str11.equals("2-January-1900"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "2-January-1900" + "'", str19.equals("2-January-1900"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2 + "'", int30 == 2);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2 + "'", int31 == 2);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 2 + "'", int41 == 2);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 2 + "'", int42 == 2);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "2-January-1900" + "'", str51.equals("2-January-1900"));
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 2 + "'", int55 == 2);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "2-January-1900" + "'", str59.equals("2-January-1900"));
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertNotNull(serialDate65);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 2 + "'", int70 == 2);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 2 + "'", int71 == 2);
        org.junit.Assert.assertNotNull(date74);
        org.junit.Assert.assertNotNull(serialDate75);
        org.junit.Assert.assertNotNull(serialDate76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
        org.junit.Assert.assertNotNull(serialDate79);
        org.junit.Assert.assertNotNull(regularTimePeriod81);
        org.junit.Assert.assertNotNull(serialDate82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertNotNull(serialDate85);
    }

//    @Test
//    public void test36() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test36");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
//        timeSeries4.setNotify(true);
//        java.lang.String str7 = timeSeries4.getRangeDescription();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        long long14 = day13.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (double) (-1));
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        java.util.Date date18 = day17.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond(date18);
//        java.util.Date date20 = fixedMillisecond19.getEnd();
//        long long21 = fixedMillisecond19.getMiddleMillisecond();
//        timeSeries12.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
//        java.beans.PropertyChangeListener propertyChangeListener23 = null;
//        timeSeries12.removePropertyChangeListener(propertyChangeListener23);
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        java.util.Date date26 = day25.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond(date26);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = fixedMillisecond27.previous();
//        long long29 = fixedMillisecond27.getMiddleMillisecond();
//        timeSeries12.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, (double) 'a');
//        java.lang.Class class36 = null;
//        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class36);
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
//        long long39 = day38.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day38, (double) (-1));
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
//        java.util.Date date43 = day42.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond(date43);
//        java.util.Date date45 = fixedMillisecond44.getEnd();
//        long long46 = fixedMillisecond44.getMiddleMillisecond();
//        timeSeries37.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond44);
//        java.beans.PropertyChangeListener propertyChangeListener48 = null;
//        timeSeries37.removePropertyChangeListener(propertyChangeListener48);
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day();
//        java.util.Date date51 = day50.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond(date51);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = fixedMillisecond52.previous();
//        long long54 = fixedMillisecond52.getMiddleMillisecond();
//        timeSeries37.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond52);
//        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day();
//        java.util.Date date57 = day56.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond58 = new org.jfree.data.time.FixedMillisecond(date57);
//        java.util.Date date59 = fixedMillisecond58.getEnd();
//        long long60 = fixedMillisecond58.getMiddleMillisecond();
//        long long61 = fixedMillisecond58.getSerialIndex();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent62 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) fixedMillisecond58);
//        boolean boolean63 = timeSeries37.equals((java.lang.Object) fixedMillisecond58);
//        java.lang.Class class67 = null;
//        org.jfree.data.time.TimeSeries timeSeries68 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class67);
//        org.jfree.data.time.Day day69 = new org.jfree.data.time.Day();
//        long long70 = day69.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem72 = timeSeries68.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day69, (double) (-1));
//        org.jfree.data.time.Day day73 = new org.jfree.data.time.Day();
//        java.util.Date date74 = day73.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond75 = new org.jfree.data.time.FixedMillisecond(date74);
//        java.util.Date date76 = fixedMillisecond75.getEnd();
//        long long77 = fixedMillisecond75.getMiddleMillisecond();
//        timeSeries68.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond75);
//        int int79 = timeSeries68.getMaximumItemCount();
//        java.lang.String str80 = timeSeries68.getDomainDescription();
//        org.jfree.data.time.Day day81 = new org.jfree.data.time.Day();
//        java.util.Date date82 = day81.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod83 = day81.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod84 = day81.previous();
//        org.jfree.data.time.Day day85 = new org.jfree.data.time.Day();
//        long long86 = day85.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries87 = timeSeries68.createCopy(regularTimePeriod84, (org.jfree.data.time.RegularTimePeriod) day85);
//        java.util.Collection collection88 = timeSeries37.getTimePeriodsUniqueToOtherSeries(timeSeries68);
//        timeSeries37.setDomainDescription("hi!");
//        java.util.Collection collection91 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries37);
//        timeSeries4.fireSeriesChanged();
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 43626L + "'", long14 == 43626L);
//        org.junit.Assert.assertNull(timeSeriesDataItem16);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560150000000L + "'", long21 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560150000000L + "'", long29 == 1560150000000L);
//        org.junit.Assert.assertNull(timeSeriesDataItem32);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 43626L + "'", long39 == 43626L);
//        org.junit.Assert.assertNull(timeSeriesDataItem41);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1560150000000L + "'", long46 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date51);
//        org.junit.Assert.assertNotNull(regularTimePeriod53);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1560150000000L + "'", long54 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date57);
//        org.junit.Assert.assertNotNull(date59);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1560150000000L + "'", long60 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 1560150000000L + "'", long61 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 43626L + "'", long70 == 43626L);
//        org.junit.Assert.assertNull(timeSeriesDataItem72);
//        org.junit.Assert.assertNotNull(date74);
//        org.junit.Assert.assertNotNull(date76);
//        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 1560150000000L + "'", long77 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 2147483647 + "'", int79 == 2147483647);
//        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "hi!" + "'", str80.equals("hi!"));
//        org.junit.Assert.assertNotNull(date82);
//        org.junit.Assert.assertNotNull(regularTimePeriod83);
//        org.junit.Assert.assertNotNull(regularTimePeriod84);
//        org.junit.Assert.assertTrue("'" + long86 + "' != '" + 43626L + "'", long86 == 43626L);
//        org.junit.Assert.assertNotNull(timeSeries87);
//        org.junit.Assert.assertNotNull(collection88);
//        org.junit.Assert.assertNotNull(collection91);
//    }

//    @Test
//    public void test37() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test37");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        java.util.Date date3 = day2.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond4.previous();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        java.util.Date date8 = day7.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(date8);
//        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date8, timeZone10);
//        int int12 = fixedMillisecond4.compareTo((java.lang.Object) timeZone10);
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date1, timeZone10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) 1L);
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class20);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        long long23 = day22.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries21.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day22, (double) (-1));
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        java.util.Date date27 = day26.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond(date27);
//        java.util.Date date29 = fixedMillisecond28.getEnd();
//        long long30 = fixedMillisecond28.getMiddleMillisecond();
//        timeSeries21.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28);
//        timeSeries21.setKey((java.lang.Comparable) 1.0d);
//        java.lang.Class<?> wildcardClass34 = timeSeries21.getClass();
//        timeSeries21.setMaximumItemCount(8);
//        java.lang.Class class40 = null;
//        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class40);
//        timeSeries41.setNotify(true);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        timeSeries41.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond45);
//        java.util.Collection collection47 = timeSeries41.getTimePeriods();
//        boolean boolean48 = timeSeries21.equals((java.lang.Object) collection47);
//        int int49 = year13.compareTo((java.lang.Object) collection47);
//        long long50 = year13.getLastMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(timeZone10);
//        org.junit.Assert.assertNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 43626L + "'", long23 == 43626L);
//        org.junit.Assert.assertNull(timeSeriesDataItem25);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560150000000L + "'", long30 == 1560150000000L);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNotNull(collection47);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1577865599999L + "'", long50 == 1577865599999L);
//    }

//    @Test
//    public void test38() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test38");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        int int3 = day0.compareTo((java.lang.Object) 2147483647);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.util.Date date5 = day4.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date5);
//        int int7 = day0.compareTo((java.lang.Object) date5);
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date5);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date5);
//        int int10 = day9.getDayOfMonth();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
//    }

//    @Test
//    public void test39() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test39");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
//        java.util.Date date3 = fixedMillisecond2.getEnd();
//        long long4 = fixedMillisecond2.getMiddleMillisecond();
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond2.getFirstMillisecond(calendar5);
//        java.util.Calendar calendar7 = null;
//        long long8 = fixedMillisecond2.getFirstMillisecond(calendar7);
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond2.getFirstMillisecond(calendar9);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond2.next();
//        java.util.Calendar calendar12 = null;
//        long long13 = fixedMillisecond2.getMiddleMillisecond(calendar12);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560150000000L + "'", long4 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560150000000L + "'", long6 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560150000000L + "'", long8 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560150000000L + "'", long10 == 1560150000000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560150000000L + "'", long13 == 1560150000000L);
//    }

    @Test
    public void test40() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test40");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        java.lang.Object obj2 = null;
        boolean boolean3 = spreadsheetDate1.equals(obj2);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(3);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        java.lang.String str7 = serialDate5.toString();
        int int8 = spreadsheetDate1.compare(serialDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(2);
        int int11 = spreadsheetDate10.toSerial();
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance(3);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(serialDate13);
        java.lang.String str15 = serialDate13.toString();
        serialDate13.setDescription("");
        boolean boolean18 = spreadsheetDate10.isOnOrAfter(serialDate13);
        int int19 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance(3);
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(serialDate21);
        boolean boolean23 = spreadsheetDate1.isOnOrAfter(serialDate21);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(2);
        int int26 = spreadsheetDate25.toSerial();
        int int27 = spreadsheetDate25.toSerial();
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
        java.util.Date date30 = day29.getStart();
        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.createInstance(date30);
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.addDays(1900, serialDate31);
        boolean boolean33 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate25, serialDate32);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(2);
        java.lang.Object obj38 = null;
        boolean boolean39 = spreadsheetDate37.equals(obj38);
        org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.createInstance(3);
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(serialDate41);
        java.lang.String str43 = serialDate41.toString();
        int int44 = spreadsheetDate37.compare(serialDate41);
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate37);
        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.addMonths((int) '#', serialDate45);
        boolean boolean47 = spreadsheetDate25.isBefore(serialDate46);
        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day();
        java.util.Date date51 = day50.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond(date51);
        java.util.Date date53 = fixedMillisecond52.getStart();
        java.lang.Class<?> wildcardClass54 = date53.getClass();
        java.lang.Class class55 = null;
        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day();
        java.util.Date date57 = day56.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond58 = new org.jfree.data.time.FixedMillisecond(date57);
        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = org.jfree.data.time.RegularTimePeriod.createInstance(class55, date57, timeZone59);
        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day();
        java.util.Date date62 = day61.getStart();
        int int64 = day61.compareTo((java.lang.Object) 2147483647);
        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day();
        java.util.Date date66 = day65.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond67 = new org.jfree.data.time.FixedMillisecond(date66);
        int int68 = day61.compareTo((java.lang.Object) date66);
        java.lang.Class class69 = null;
        java.util.Date date70 = null;
        java.util.TimeZone timeZone71 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = org.jfree.data.time.RegularTimePeriod.createInstance(class69, date70, timeZone71);
        org.jfree.data.time.Day day73 = new org.jfree.data.time.Day(date66, timeZone71);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass54, date57, timeZone71);
        org.jfree.data.time.TimeSeries timeSeries75 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean47, "ERROR : Relative To String", "June 2019", (java.lang.Class) wildcardClass54);
        java.lang.Object obj76 = timeSeries75.clone();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2-January-1900" + "'", str7.equals("2-January-1900"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2 + "'", int11 == 2);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2-January-1900" + "'", str15.equals("2-January-1900"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2 + "'", int26 == 2);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2 + "'", int27 == 2);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "2-January-1900" + "'", str43.equals("2-January-1900"));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertNotNull(wildcardClass54);
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertNotNull(timeZone59);
        org.junit.Assert.assertNull(regularTimePeriod60);
        org.junit.Assert.assertNotNull(date62);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1 + "'", int64 == 1);
        org.junit.Assert.assertNotNull(date66);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 1 + "'", int68 == 1);
        org.junit.Assert.assertNotNull(timeZone71);
        org.junit.Assert.assertNull(regularTimePeriod72);
        org.junit.Assert.assertNull(regularTimePeriod74);
        org.junit.Assert.assertNotNull(obj76);
    }

//    @Test
//    public void test41() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test41");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#', "hi!", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        long long6 = day5.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1));
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.util.Date date10 = day9.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond(date10);
//        java.util.Date date12 = fixedMillisecond11.getEnd();
//        long long13 = fixedMillisecond11.getMiddleMillisecond();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11);
//        timeSeries4.setKey((java.lang.Comparable) 1.0d);
//        long long17 = timeSeries4.getMaximumItemAge();
//        java.beans.PropertyChangeListener propertyChangeListener18 = null;
//        timeSeries4.removePropertyChangeListener(propertyChangeListener18);
//        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance(3);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(serialDate21);
//        java.lang.String str23 = day22.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day22, (java.lang.Number) 5);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener26 = null;
//        timeSeries4.removeChangeListener(seriesChangeListener26);
//        boolean boolean28 = timeSeries4.isEmpty();
//        boolean boolean29 = timeSeries4.isEmpty();
//        int int30 = timeSeries4.getMaximumItemCount();
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43626L + "'", long6 == 43626L);
//        org.junit.Assert.assertNull(timeSeriesDataItem8);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560150000000L + "'", long13 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 9223372036854775807L + "'", long17 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "2-January-1900" + "'", str23.equals("2-January-1900"));
//        org.junit.Assert.assertNull(timeSeriesDataItem25);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2147483647 + "'", int30 == 2147483647);
//    }
//}

