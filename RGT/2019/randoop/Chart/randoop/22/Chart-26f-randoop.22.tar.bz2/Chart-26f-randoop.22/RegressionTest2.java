import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        boolean boolean1 = minMaxCategoryRenderer0.isDrawLines();
        minMaxCategoryRenderer0.setDrawLines(true);
        java.awt.Paint paint4 = minMaxCategoryRenderer0.getGroupPaint();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test02");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("Category Plot");
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test03");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        java.lang.Object obj2 = piePlot3D1.clone();
        java.awt.Font font4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Paint paint5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("hi!", font4, paint5);
        piePlot3D1.setLabelFont(font4);
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        boolean boolean9 = piePlot3D1.equals((java.lang.Object) color8);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test04");
        int int0 = org.jfree.data.time.SerialDate.FIRST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test05");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = xYPlot7.getAxisOffset();
        java.lang.String str9 = rectangleInsets8.toString();
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D13 = rectangleInsets8.createInsetRectangle(rectangle2D10, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str9.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test06");
        java.awt.Color color0 = java.awt.Color.ORANGE;
        int int1 = color0.getRGB();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-14336) + "'", int1 == (-14336));
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test07");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        float float6 = dateAxis5.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) dateAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis8, xYItemRenderer9);
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) dateAxis8, valueAxis11, xYItemRenderer12);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer15 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint17 = stackedAreaRenderer15.getSeriesItemLabelPaint(100);
        stackedAreaRenderer15.setAutoPopulateSeriesPaint(false);
        java.awt.Stroke stroke21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        stackedAreaRenderer15.setSeriesStroke(100, stroke21);
        xYPlot13.setRangeZeroBaselineStroke(stroke21);
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("");
        float float27 = dateAxis26.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset24, (org.jfree.chart.axis.ValueAxis) dateAxis26, (org.jfree.chart.axis.ValueAxis) dateAxis29, xYItemRenderer30);
        java.awt.Paint paint32 = xYPlot31.getRangeTickBandPaint();
        java.awt.Color color33 = org.jfree.chart.ChartColor.DARK_BLUE;
        xYPlot31.setNoDataMessagePaint((java.awt.Paint) color33);
        xYPlot31.clearRangeAxes();
        xYPlot31.setOutlineVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation39 = xYPlot31.getRangeAxisLocation((int) (short) 1);
        org.jfree.data.general.DatasetGroup datasetGroup40 = xYPlot31.getDatasetGroup();
        org.jfree.data.category.CategoryDataset categoryDataset41 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot42 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset41);
        org.jfree.chart.JFreeChart jFreeChart43 = multiplePiePlot42.getPieChart();
        java.awt.Image image44 = jFreeChart43.getBackgroundImage();
        xYPlot31.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart43);
        org.jfree.chart.util.RectangleInsets rectangleInsets46 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        xYPlot31.setAxisOffset(rectangleInsets46);
        org.jfree.chart.plot.ValueMarker valueMarker50 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        valueMarker50.setLabel("");
        org.jfree.chart.util.Layer layer53 = org.jfree.chart.util.Layer.FOREGROUND;
        xYPlot31.addDomainMarker((int) '4', (org.jfree.chart.plot.Marker) valueMarker50, layer53);
        java.util.Collection collection55 = xYPlot13.getDomainMarkers(layer53);
        java.lang.String str56 = layer53.toString();
        java.util.Collection collection57 = categoryPlot0.getRangeMarkers((int) ' ', layer53);
        float float58 = categoryPlot0.getForegroundAlpha();
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 2.0f + "'", float6 == 2.0f);
        org.junit.Assert.assertNull(paint17);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + float27 + "' != '" + 2.0f + "'", float27 == 2.0f);
        org.junit.Assert.assertNull(paint32);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(axisLocation39);
        org.junit.Assert.assertNull(datasetGroup40);
        org.junit.Assert.assertNotNull(jFreeChart43);
        org.junit.Assert.assertNull(image44);
        org.junit.Assert.assertNotNull(rectangleInsets46);
        org.junit.Assert.assertNotNull(layer53);
        org.junit.Assert.assertNull(collection55);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "Layer.FOREGROUND" + "'", str56.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection57);
        org.junit.Assert.assertTrue("'" + float58 + "' != '" + 1.0f + "'", float58 == 1.0f);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test08");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        java.lang.Object obj1 = shapeList0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test09");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        java.awt.Paint paint1 = lineRenderer3D0.getWallPaint();
        lineRenderer3D0.setXOffset(1.0E-5d);
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test10");
        double[] doubleArray2 = new double[] {};
        double[] doubleArray3 = new double[] {};
        double[] doubleArray4 = new double[] {};
        double[][] doubleArray5 = new double[][] { doubleArray2, doubleArray3, doubleArray4 };
        org.jfree.data.category.CategoryDataset categoryDataset6 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("cyan", "GradientPaintTransformType.HORIZONTAL", doubleArray5);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        float float10 = dateAxis9.getTickMarkOutsideLength();
        dateAxis9.setNegativeArrowVisible(false);
        org.jfree.chart.plot.Plot plot13 = dateAxis9.getPlot();
        double double14 = dateAxis9.getUpperBound();
        java.awt.Shape shape15 = dateAxis9.getDownArrow();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer17 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint19 = stackedAreaRenderer17.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator21 = stackedAreaRenderer17.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator22 = stackedAreaRenderer17.getBaseItemLabelGenerator();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer25 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.lang.Boolean boolean27 = stackedAreaRenderer25.getSeriesVisibleInLegend(10);
        boolean boolean28 = stackedAreaRenderer25.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator29 = stackedAreaRenderer25.getLegendItemURLGenerator();
        java.awt.Paint paint31 = stackedAreaRenderer25.lookupSeriesFillPaint((int) ' ');
        stackedAreaRenderer17.setSeriesPaint(1, paint31);
        org.jfree.chart.title.TextTitle textTitle35 = new org.jfree.chart.title.TextTitle("");
        java.awt.Font font36 = textTitle35.getFont();
        java.awt.Paint paint37 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.text.TextLine textLine38 = new org.jfree.chart.text.TextLine("", font36, paint37);
        stackedAreaRenderer17.setBaseItemLabelPaint(paint37, false);
        stackedAreaRenderer17.setBaseItemLabelsVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis9, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer17);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor44 = categoryPlot43.getDomainGridlinePosition();
        org.jfree.chart.util.SortOrder sortOrder45 = categoryPlot43.getRowRenderingOrder();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer46 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean48 = lineAndShapeRenderer46.getSeriesShapesVisible((int) (short) 1);
        java.awt.Font font51 = lineAndShapeRenderer46.getItemLabelFont((int) (byte) 0, 6);
        int int52 = categoryPlot43.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer46);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(categoryDataset6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNull(plot13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNull(paint19);
        org.junit.Assert.assertNull(categoryItemLabelGenerator21);
        org.junit.Assert.assertNull(categoryItemLabelGenerator22);
        org.junit.Assert.assertNull(boolean27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator29);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(categoryAnchor44);
        org.junit.Assert.assertNotNull(sortOrder45);
        org.junit.Assert.assertNull(boolean48);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test11");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod3 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 100, (long) 100);
        org.jfree.data.gantt.Task task4 = new org.jfree.data.gantt.Task("Last", (org.jfree.data.time.TimePeriod) simpleTimePeriod3);
        java.util.Date date5 = simpleTimePeriod3.getEnd();
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test12");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Paint paint8 = xYPlot7.getRangeTickBandPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier9 = null;
        xYPlot7.setDrawingSupplier(drawingSupplier9);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = xYPlot7.getDatasetRenderingOrder();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer13 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint15 = stackedAreaRenderer13.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator17 = stackedAreaRenderer13.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator18 = stackedAreaRenderer13.getBaseItemLabelGenerator();
        java.util.Date date20 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date21 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date22 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange23 = new org.jfree.data.time.DateRange(date21, date22);
        org.jfree.data.gantt.Task task24 = new org.jfree.data.gantt.Task("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", date20, date21);
        boolean boolean25 = stackedAreaRenderer13.equals((java.lang.Object) task24);
        boolean boolean26 = xYPlot7.equals((java.lang.Object) boolean25);
        org.jfree.chart.event.PlotChangeListener plotChangeListener27 = null;
        xYPlot7.addChangeListener(plotChangeListener27);
        java.awt.Paint paint29 = xYPlot7.getRangeCrosshairPaint();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
        org.junit.Assert.assertNull(paint15);
        org.junit.Assert.assertNull(categoryItemLabelGenerator17);
        org.junit.Assert.assertNull(categoryItemLabelGenerator18);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(paint29);
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test13");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test14");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        boolean boolean1 = minMaxCategoryRenderer0.isDrawLines();
        minMaxCategoryRenderer0.setDrawLines(true);
        javax.swing.Icon icon4 = minMaxCategoryRenderer0.getMinIcon();
        boolean boolean5 = minMaxCategoryRenderer0.isDrawLines();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator6 = minMaxCategoryRenderer0.getLegendItemLabelGenerator();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(icon4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator6);
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test15");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Paint paint8 = xYPlot7.getRangeTickBandPaint();
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_BLUE;
        xYPlot7.setNoDataMessagePaint((java.awt.Paint) color9);
        xYPlot7.clearRangeAxes();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = xYPlot7.getAxisOffset();
        org.jfree.chart.util.Layer layer14 = null;
        java.util.Collection collection15 = xYPlot7.getDomainMarkers(0, layer14);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder16 = xYPlot7.getDatasetRenderingOrder();
        xYPlot7.setWeight((int) (short) -1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNotNull(datasetRenderingOrder16);
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test16");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Paint paint8 = xYPlot7.getRangeTickBandPaint();
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_BLUE;
        xYPlot7.setNoDataMessagePaint((java.awt.Paint) color9);
        xYPlot7.clearRangeAxes();
        xYPlot7.setOutlineVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation15 = xYPlot7.getRangeAxisLocation((int) (short) 1);
        org.jfree.data.general.DatasetGroup datasetGroup16 = xYPlot7.getDatasetGroup();
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot18 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset17);
        org.jfree.chart.JFreeChart jFreeChart19 = multiplePiePlot18.getPieChart();
        java.awt.Image image20 = jFreeChart19.getBackgroundImage();
        xYPlot7.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart19);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        xYPlot7.setAxisOffset(rectangleInsets22);
        org.jfree.chart.plot.ValueMarker valueMarker26 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        valueMarker26.setLabel("");
        org.jfree.chart.util.Layer layer29 = org.jfree.chart.util.Layer.FOREGROUND;
        xYPlot7.addDomainMarker((int) '4', (org.jfree.chart.plot.Marker) valueMarker26, layer29);
        java.awt.Paint paint31 = valueMarker26.getOutlinePaint();
        valueMarker26.setLabel("12/31/69 4:00 PM");
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNull(datasetGroup16);
        org.junit.Assert.assertNotNull(jFreeChart19);
        org.junit.Assert.assertNull(image20);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(layer29);
        org.junit.Assert.assertNotNull(paint31);
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test17");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test18");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test19");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("{0}");
        java.awt.Font font4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Paint paint5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("hi!", font4, paint5);
        org.jfree.chart.text.TextFragment textFragment7 = new org.jfree.chart.text.TextFragment("ThreadContext", font4);
        float float8 = textFragment7.getBaselineOffset();
        textLine1.removeFragment(textFragment7);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.0f + "'", float8 == 0.0f);
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test20");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Paint paint2 = multiplePiePlot1.getOutlinePaint();
        multiplePiePlot1.setLimit((double) (byte) 0);
        multiplePiePlot1.setAggregatedItemsKey((java.lang.Comparable) (byte) 10);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test21");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer3 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint5 = stackedAreaRenderer3.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator7 = stackedAreaRenderer3.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator8 = stackedAreaRenderer3.getBaseItemLabelGenerator();
        double double9 = stackedAreaRenderer3.getItemLabelAnchorOffset();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = stackedAreaRenderer3.getNegativeItemLabelPosition((int) 'a', (int) (short) -1);
        java.awt.Paint paint13 = null;
        stackedAreaRenderer3.setBasePaint(paint13, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = stackedAreaRenderer3.getBasePositiveItemLabelPosition();
        stackedAreaRenderer1.setBasePositiveItemLabelPosition(itemLabelPosition16, true);
        double double19 = itemLabelPosition16.getAngle();
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNull(categoryItemLabelGenerator7);
        org.junit.Assert.assertNull(categoryItemLabelGenerator8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertNotNull(itemLabelPosition12);
        org.junit.Assert.assertNotNull(itemLabelPosition16);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test22");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer2 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Color color4 = java.awt.Color.CYAN;
        stackedAreaRenderer2.setSeriesFillPaint(2, (java.awt.Paint) color4, true);
        org.jfree.chart.title.LegendGraphic legendGraphic7 = new org.jfree.chart.title.LegendGraphic(shape0, (java.awt.Paint) color4);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer8 = legendGraphic7.getFillPaintTransformer();
        double double9 = legendGraphic7.getContentYOffset();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        float float12 = dateAxis11.getTickMarkOutsideLength();
        dateAxis11.setNegativeArrowVisible(false);
        org.jfree.chart.plot.Plot plot15 = dateAxis11.getPlot();
        double double16 = dateAxis11.getUpperBound();
        java.awt.Shape shape17 = dateAxis11.getDownArrow();
        java.awt.Shape shape18 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        boolean boolean19 = org.jfree.chart.util.ShapeUtilities.equal(shape17, shape18);
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("");
        float float23 = dateAxis22.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot(xYDataset20, (org.jfree.chart.axis.ValueAxis) dateAxis22, (org.jfree.chart.axis.ValueAxis) dateAxis25, xYItemRenderer26);
        java.awt.Paint paint28 = xYPlot27.getRangeTickBandPaint();
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_BLUE;
        xYPlot27.setNoDataMessagePaint((java.awt.Paint) color29);
        xYPlot27.clearRangeAxes();
        xYPlot27.setOutlineVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation35 = xYPlot27.getRangeAxisLocation((int) (short) 1);
        java.awt.Paint paint36 = xYPlot27.getDomainCrosshairPaint();
        org.jfree.chart.title.LegendGraphic legendGraphic37 = new org.jfree.chart.title.LegendGraphic(shape17, paint36);
        org.jfree.data.xy.XYDataset xYDataset38 = null;
        org.jfree.data.xy.XYDataset xYDataset39 = null;
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis("");
        float float42 = dateAxis41.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer45 = null;
        org.jfree.chart.plot.XYPlot xYPlot46 = new org.jfree.chart.plot.XYPlot(xYDataset39, (org.jfree.chart.axis.ValueAxis) dateAxis41, (org.jfree.chart.axis.ValueAxis) dateAxis44, xYItemRenderer45);
        org.jfree.chart.axis.ValueAxis valueAxis47 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer48 = null;
        org.jfree.chart.plot.XYPlot xYPlot49 = new org.jfree.chart.plot.XYPlot(xYDataset38, (org.jfree.chart.axis.ValueAxis) dateAxis44, valueAxis47, xYItemRenderer48);
        java.awt.Stroke stroke50 = xYPlot49.getRangeZeroBaselineStroke();
        legendGraphic37.setLineStroke(stroke50);
        legendGraphic7.setLineStroke(stroke50);
        java.awt.Stroke stroke53 = legendGraphic7.getOutlineStroke();
        java.awt.Color color54 = java.awt.Color.orange;
        legendGraphic7.setOutlinePaint((java.awt.Paint) color54);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(gradientPaintTransformer8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 2.0f + "'", float12 == 2.0f);
        org.junit.Assert.assertNull(plot15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 2.0f + "'", float23 == 2.0f);
        org.junit.Assert.assertNull(paint28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertTrue("'" + float42 + "' != '" + 2.0f + "'", float42 == 2.0f);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNull(stroke53);
        org.junit.Assert.assertNotNull(color54);
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test23");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.text.TextFragment textFragment2 = new org.jfree.chart.text.TextFragment("cyan", font1);
        java.awt.Font font3 = textFragment2.getFont();
        java.awt.Paint paint4 = textFragment2.getPaint();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test24");
        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        java.lang.String str3 = year2.toString();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(10, year2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month4.next();
        int int6 = month4.getYearValue();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test25");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) (short) 10);
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (short) 100, serialDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test26");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Paint paint8 = xYPlot7.getRangeTickBandPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier9 = null;
        xYPlot7.setDrawingSupplier(drawingSupplier9);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = xYPlot7.getDatasetRenderingOrder();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer13 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint15 = stackedAreaRenderer13.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator17 = stackedAreaRenderer13.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator18 = stackedAreaRenderer13.getBaseItemLabelGenerator();
        java.util.Date date20 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date21 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date22 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange23 = new org.jfree.data.time.DateRange(date21, date22);
        org.jfree.data.gantt.Task task24 = new org.jfree.data.gantt.Task("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", date20, date21);
        boolean boolean25 = stackedAreaRenderer13.equals((java.lang.Object) task24);
        boolean boolean26 = xYPlot7.equals((java.lang.Object) boolean25);
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot28 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset27);
        org.jfree.chart.JFreeChart jFreeChart29 = multiplePiePlot28.getPieChart();
        xYPlot7.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart29);
        java.awt.Graphics2D graphics2D31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.data.gantt.TaskSeries taskSeries34 = new org.jfree.data.gantt.TaskSeries("{0}");
        taskSeries34.removeAll();
        org.jfree.data.gantt.Task task37 = taskSeries34.get("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        java.util.List list38 = taskSeries34.getTasks();
        xYPlot7.drawDomainTickBands(graphics2D31, rectangle2D32, list38);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
        org.junit.Assert.assertNull(paint15);
        org.junit.Assert.assertNull(categoryItemLabelGenerator17);
        org.junit.Assert.assertNull(categoryItemLabelGenerator18);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(jFreeChart29);
        org.junit.Assert.assertNull(task37);
        org.junit.Assert.assertNotNull(list38);
    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test27");
        org.jfree.data.time.DateRange dateRange0 = new org.jfree.data.time.DateRange();
        double double2 = dateRange0.constrain((double) 6);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test28");
        org.jfree.chart.renderer.OutlierListCollection outlierListCollection0 = new org.jfree.chart.renderer.OutlierListCollection();
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test29");
        java.text.DateFormat dateFormat2 = null;
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit3 = new org.jfree.chart.axis.DateTickUnit((int) (short) -1, 15, dateFormat2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DateTickUnit.getMillisecondCount() : unit must be one of the constants YEAR, MONTH, DAY, HOUR, MINUTE, SECOND or MILLISECOND defined in the DateTickUnit class. Do *not* use the constants defined in java.util.Calendar.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test30");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Paint paint3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("hi!", font2, paint3);
        boolean boolean5 = ringPlot0.equals((java.lang.Object) "hi!");
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent6 = null;
        ringPlot0.markerChanged(markerChangeEvent6);
        java.awt.Font font8 = ringPlot0.getLabelFont();
        double double9 = ringPlot0.getSectionDepth();
        boolean boolean10 = ringPlot0.getSeparatorsVisible();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.2d + "'", double9 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test31");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D0.configure();
        double double2 = categoryAxis3D0.getLowerMargin();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test32");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(0.0d, 1.0d);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.text.TextLine textLine8 = new org.jfree.chart.text.TextLine("", font6, paint7);
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", font6, (org.jfree.chart.plot.Plot) piePlot9, false);
        stackedBarRenderer3D2.setSeriesItemLabelFont((int) '4', font6);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = stackedBarRenderer3D2.getNegativeItemLabelPositionFallback();
        stackedBarRenderer3D2.setAutoPopulateSeriesFillPaint(true);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(itemLabelPosition13);
    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test33");
        org.jfree.chart.ui.Licences licences0 = new org.jfree.chart.ui.Licences();
        java.lang.String str1 = licences0.getGPL();
    }

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test34");
        org.jfree.data.KeyToGroupMap keyToGroupMap1 = new org.jfree.data.KeyToGroupMap((java.lang.Comparable) (byte) 100);
        java.lang.Object obj2 = keyToGroupMap1.clone();
        java.util.Date date3 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date4 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange(date3, date4);
        int int6 = keyToGroupMap1.getGroupIndex((java.lang.Comparable) date4);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test35");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.trimHeight(0.0d);
        double double4 = rectangleInsets0.extendWidth((double) (short) 100);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            rectangleInsets0.trim(rectangle2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-8.0d) + "'", double2 == (-8.0d));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 116.0d + "'", double4 == 116.0d);
    }

    @Test
    public void test36() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test36");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test37");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.text.TextFragment textFragment2 = new org.jfree.chart.text.TextFragment("cyan", font1);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        float float5 = dateAxis4.getTickMarkOutsideLength();
        dateAxis4.setNegativeArrowVisible(false);
        double double8 = dateAxis4.getFixedDimension();
        java.awt.Shape shape9 = dateAxis4.getRightArrow();
        boolean boolean10 = textFragment2.equals((java.lang.Object) shape9);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 2.0f + "'", float5 == 2.0f);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test38() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test38");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        basicProjectInfo0.setVersion("JFreeChart version 1.0.6.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nhi!");
    }

    @Test
    public void test39() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test39");
        java.lang.String[] strArray0 = org.jfree.data.time.SerialDate.getMonths();
        java.lang.Number[][] numberArray1 = null;
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 1L };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 1L };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset7 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray0, numberArray1, numberArray6);
        java.lang.String[] strArray8 = org.jfree.data.time.SerialDate.getMonths();
        java.lang.Number[][] numberArray9 = null;
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 1L };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 1L };
        java.lang.Number[][] numberArray14 = new java.lang.Number[][] { numberArray11, numberArray13 };
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset15 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray8, numberArray9, numberArray14);
        java.lang.String[] strArray16 = org.jfree.data.time.SerialDate.getMonths();
        java.lang.Number[][] numberArray17 = null;
        java.lang.Number[] numberArray19 = new java.lang.Number[] { 1L };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 1L };
        java.lang.Number[][] numberArray22 = new java.lang.Number[][] { numberArray19, numberArray21 };
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset23 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray16, numberArray17, numberArray22);
        java.lang.Number[] numberArray24 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray25 = new java.lang.Number[][] { numberArray24 };
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset26 = new org.jfree.data.category.DefaultIntervalCategoryDataset(numberArray17, numberArray25);
        java.lang.String[] strArray27 = org.jfree.data.time.SerialDate.getMonths();
        java.lang.Number[][] numberArray28 = null;
        java.lang.Number[] numberArray30 = new java.lang.Number[] { 1L };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 1L };
        java.lang.Number[][] numberArray33 = new java.lang.Number[][] { numberArray30, numberArray32 };
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset34 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray27, numberArray28, numberArray33);
        java.lang.Number[] numberArray35 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray36 = new java.lang.Number[][] { numberArray35 };
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset37 = new org.jfree.data.category.DefaultIntervalCategoryDataset(numberArray28, numberArray36);
        try {
            org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset38 = new org.jfree.data.category.DefaultIntervalCategoryDataset((java.lang.Comparable[]) strArray0, (java.lang.Comparable[]) strArray8, numberArray25, numberArray36);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The number of series keys does not match the number of series in the data.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(numberArray35);
        org.junit.Assert.assertNotNull(numberArray36);
    }

    @Test
    public void test40() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test40");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.clear();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        boolean boolean5 = numberAxis3D4.getAutoRangeIncludesZero();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D8 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0.0f, 100.0d);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean10 = lineAndShapeRenderer9.getBaseLinesVisible();
        lineAndShapeRenderer9.setSeriesLinesVisible(0, (java.lang.Boolean) false);
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator18 = new org.jfree.chart.urls.StandardCategoryURLGenerator("ThreadContext", "(C)opyright 2000-2007, by Object Refinery Limited and Contributors", "");
        lineAndShapeRenderer9.setSeriesURLGenerator(9999, (org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator18);
        stackedBarRenderer3D8.setBaseURLGenerator((org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator18);
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D8);
        double double22 = categoryAxis3D2.getUpperMargin();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
    }

    @Test
    public void test41() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test41");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Paint paint8 = xYPlot7.getRangeTickBandPaint();
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_BLUE;
        xYPlot7.setNoDataMessagePaint((java.awt.Paint) color9);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor11 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE2;
        boolean boolean12 = xYPlot7.equals((java.lang.Object) itemLabelAnchor11);
        java.awt.Font font14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Paint paint15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.block.LabelBlock labelBlock16 = new org.jfree.chart.block.LabelBlock("hi!", font14, paint15);
        labelBlock16.setToolTipText("{0}");
        labelBlock16.setToolTipText("hi!");
        java.lang.String str21 = labelBlock16.getToolTipText();
        labelBlock16.setToolTipText("hi!");
        org.jfree.data.general.Dataset dataset24 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent25 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) "hi!", dataset24);
        xYPlot7.datasetChanged(datasetChangeEvent25);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(itemLabelAnchor11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
    }

    @Test
    public void test42() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test42");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean1 = lineAndShapeRenderer0.getBaseLinesVisible();
        java.awt.Shape shape4 = lineAndShapeRenderer0.getItemShape(6, 1);
        boolean boolean7 = lineAndShapeRenderer0.isItemLabelVisible((int) (byte) 10, 4);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D8 = new org.jfree.chart.axis.CategoryAxis3D();
        java.lang.Object obj9 = categoryAxis3D8.clone();
        float float10 = categoryAxis3D8.getMaximumCategoryLabelWidthRatio();
        categoryAxis3D8.setCategoryLabelPositionOffset(100);
        boolean boolean13 = lineAndShapeRenderer0.equals((java.lang.Object) categoryAxis3D8);
        categoryAxis3D8.setCategoryLabelPositionOffset(9);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test43() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test43");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        float float3 = dateAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Paint paint8 = xYPlot7.getRangeTickBandPaint();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        float float12 = dateAxis11.getTickMarkOutsideLength();
        dateAxis11.setNegativeArrowVisible(false);
        float float15 = dateAxis11.getTickMarkInsideLength();
        xYPlot7.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis) dateAxis11);
        org.jfree.chart.util.Layer layer17 = null;
        java.util.Collection collection18 = xYPlot7.getDomainMarkers(layer17);
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("");
        float float21 = dateAxis20.getTickMarkOutsideLength();
        dateAxis20.setNegativeArrowVisible(false);
        float float24 = dateAxis20.getTickMarkInsideLength();
        java.util.Date date25 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date26 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.DateRange dateRange27 = new org.jfree.data.time.DateRange(date25, date26);
        dateAxis20.setRange((org.jfree.data.Range) dateRange27);
        double double29 = dateAxis20.getFixedAutoRange();
        xYPlot7.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis20);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent31 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot7);
        xYPlot7.setBackgroundImageAlignment((int) (short) 1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        java.awt.geom.Point2D point2D36 = null;
        xYPlot7.zoomDomainAxes((double) 1L, plotRenderingInfo35, point2D36);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer39 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        stackedAreaRenderer39.setBaseItemLabelsVisible(false);
        boolean boolean42 = xYPlot7.equals((java.lang.Object) false);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 2.0f + "'", float12 == 2.0f);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.0f + "'", float15 == 0.0f);
        org.junit.Assert.assertNull(collection18);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 2.0f + "'", float21 == 2.0f);
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 0.0f + "'", float24 == 0.0f);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test44() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test44");
        java.awt.Paint paint0 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test45() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test45");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        java.lang.Object obj1 = booleanList0.clone();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer3 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint5 = stackedAreaRenderer3.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator7 = stackedAreaRenderer3.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator8 = stackedAreaRenderer3.getBaseItemLabelGenerator();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer11 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.lang.Boolean boolean13 = stackedAreaRenderer11.getSeriesVisibleInLegend(10);
        boolean boolean14 = stackedAreaRenderer11.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator15 = stackedAreaRenderer11.getLegendItemURLGenerator();
        java.awt.Paint paint17 = stackedAreaRenderer11.lookupSeriesFillPaint((int) ' ');
        stackedAreaRenderer3.setSeriesPaint(1, paint17);
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle("");
        java.awt.Font font22 = textTitle21.getFont();
        java.awt.Paint paint23 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.text.TextLine textLine24 = new org.jfree.chart.text.TextLine("", font22, paint23);
        stackedAreaRenderer3.setBaseItemLabelPaint(paint23, false);
        boolean boolean27 = booleanList0.equals((java.lang.Object) paint23);
        java.lang.Boolean boolean29 = booleanList0.getBoolean((int) 'a');
        org.jfree.chart.title.TextTitle textTitle31 = new org.jfree.chart.title.TextTitle("");
        java.awt.Font font32 = textTitle31.getFont();
        java.awt.Color color33 = java.awt.Color.RED;
        textTitle31.setPaint((java.awt.Paint) color33);
        boolean boolean35 = booleanList0.equals((java.lang.Object) color33);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNull(categoryItemLabelGenerator7);
        org.junit.Assert.assertNull(categoryItemLabelGenerator8);
        org.junit.Assert.assertNull(boolean13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(boolean29);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test46() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test46");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState((double) 2);
        double[] doubleArray4 = new double[] {};
        double[] doubleArray5 = new double[] {};
        double[] doubleArray6 = new double[] {};
        double[][] doubleArray7 = new double[][] { doubleArray4, doubleArray5, doubleArray6 };
        org.jfree.data.category.CategoryDataset categoryDataset8 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("cyan", "GradientPaintTransformType.HORIZONTAL", doubleArray7);
        org.jfree.data.KeyToGroupMap keyToGroupMap10 = new org.jfree.data.KeyToGroupMap((java.lang.Comparable) (byte) 100);
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset8, keyToGroupMap10);
        java.util.List list12 = keyToGroupMap10.getGroups();
        axisState1.setTicks(list12);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(categoryDataset8);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(list12);
    }

    @Test
    public void test47() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test47");
        java.text.DateFormat dateFormat2 = null;
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit3 = new org.jfree.chart.axis.DateTickUnit((int) (byte) -1, 0, dateFormat2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DateTickUnit.getMillisecondCount() : unit must be one of the constants YEAR, MONTH, DAY, HOUR, MINUTE, SECOND or MILLISECOND defined in the DateTickUnit class. Do *not* use the constants defined in java.util.Calendar.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test48() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test48");
        java.awt.Shape shape4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
        boolean boolean7 = org.jfree.chart.util.ShapeUtilities.equal(shape4, shape6);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity10 = new org.jfree.chart.entity.TickLabelEntity(shape6, "", "ThreadContext");
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_RED;
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        float float15 = dateAxis14.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset12, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer18);
        java.awt.Paint paint20 = xYPlot19.getRangeTickBandPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier21 = null;
        xYPlot19.setDrawingSupplier(drawingSupplier21);
        org.jfree.chart.axis.AxisLocation axisLocation23 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        xYPlot19.setDomainAxisLocation(axisLocation23, false);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent26 = null;
        xYPlot19.notifyListeners(plotChangeEvent26);
        java.awt.Paint paint28 = xYPlot19.getRangeZeroBaselinePaint();
        java.awt.Stroke stroke29 = xYPlot19.getRangeGridlineStroke();
        org.jfree.chart.plot.RingPlot ringPlot30 = new org.jfree.chart.plot.RingPlot();
        java.awt.Font font32 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Paint paint33 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.block.LabelBlock labelBlock34 = new org.jfree.chart.block.LabelBlock("hi!", font32, paint33);
        boolean boolean35 = ringPlot30.equals((java.lang.Object) "hi!");
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent36 = null;
        ringPlot30.markerChanged(markerChangeEvent36);
        java.awt.Font font38 = ringPlot30.getLabelFont();
        double double39 = ringPlot30.getSectionDepth();
        java.awt.Paint paint40 = ringPlot30.getSeparatorPaint();
        org.jfree.chart.LegendItem legendItem41 = new org.jfree.chart.LegendItem("CategoryAnchor.MIDDLE", "JFreeChart", "[Jun 10, 2019 8:40:16 AM --> Jun 10, 2019 8:40:16 AM]", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", shape6, (java.awt.Paint) color11, stroke29, paint40);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 2.0f + "'", float15 == 2.0f);
        org.junit.Assert.assertNull(paint20);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(font38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.2d + "'", double39 == 0.2d);
        org.junit.Assert.assertNotNull(paint40);
    }

    @Test
    public void test49() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test49");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image1 = null;
        projectInfo0.setLogo(image1);
        projectInfo0.setCopyright("hi!");
        org.junit.Assert.assertNotNull(projectInfo0);
    }

    @Test
    public void test50() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test50");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D(0.0d, 0.25d);
        double double3 = size2D2.getHeight();
        java.lang.Object obj4 = size2D2.clone();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.25d + "'", double3 == 0.25d);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test51() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test51");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        double[] doubleArray3 = new double[] {};
        double[] doubleArray4 = new double[] {};
        double[] doubleArray5 = new double[] {};
        double[][] doubleArray6 = new double[][] { doubleArray3, doubleArray4, doubleArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("cyan", "GradientPaintTransformType.HORIZONTAL", doubleArray6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("");
        float float11 = dateAxis10.getTickMarkOutsideLength();
        dateAxis10.setNegativeArrowVisible(false);
        org.jfree.chart.plot.Plot plot14 = dateAxis10.getPlot();
        double double15 = dateAxis10.getUpperBound();
        java.awt.Shape shape16 = dateAxis10.getDownArrow();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer18 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Paint paint20 = stackedAreaRenderer18.getSeriesItemLabelPaint(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator22 = stackedAreaRenderer18.getSeriesItemLabelGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator23 = stackedAreaRenderer18.getBaseItemLabelGenerator();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer26 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.lang.Boolean boolean28 = stackedAreaRenderer26.getSeriesVisibleInLegend(10);
        boolean boolean29 = stackedAreaRenderer26.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator30 = stackedAreaRenderer26.getLegendItemURLGenerator();
        java.awt.Paint paint32 = stackedAreaRenderer26.lookupSeriesFillPaint((int) ' ');
        stackedAreaRenderer18.setSeriesPaint(1, paint32);
        org.jfree.chart.title.TextTitle textTitle36 = new org.jfree.chart.title.TextTitle("");
        java.awt.Font font37 = textTitle36.getFont();
        java.awt.Paint paint38 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.text.TextLine textLine39 = new org.jfree.chart.text.TextLine("", font37, paint38);
        stackedAreaRenderer18.setBaseItemLabelPaint(paint38, false);
        stackedAreaRenderer18.setBaseItemLabelsVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis10, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer18);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor45 = categoryPlot44.getDomainGridlinePosition();
        org.jfree.chart.util.SortOrder sortOrder46 = categoryPlot44.getRowRenderingOrder();
        defaultKeyedValues0.sortByValues(sortOrder46);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate52 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate54 = new org.jfree.data.time.SpreadsheetDate(2);
        int int55 = spreadsheetDate52.compare((org.jfree.data.time.SerialDate) spreadsheetDate54);
        boolean boolean56 = spreadsheetDate50.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate52);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate58 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate60 = new org.jfree.data.time.SpreadsheetDate(2);
        int int61 = spreadsheetDate58.compare((org.jfree.data.time.SerialDate) spreadsheetDate60);
        boolean boolean62 = spreadsheetDate50.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate58);
        int int63 = spreadsheetDate58.getMonth();
        defaultKeyedValues0.insertValue(0, (java.lang.Comparable) spreadsheetDate58, (double) (short) 10);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 2.0f + "'", float11 == 2.0f);
        org.junit.Assert.assertNull(plot14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNull(paint20);
        org.junit.Assert.assertNull(categoryItemLabelGenerator22);
        org.junit.Assert.assertNull(categoryItemLabelGenerator23);
        org.junit.Assert.assertNull(boolean28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator30);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(categoryAnchor45);
        org.junit.Assert.assertNotNull(sortOrder46);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
    }
}

